# 裁员广进-release · 安装说明（企业级交付版）

> **先读 `00-开始阅读-完整说明.md`**（唯一权威说明书：红线、目录、量化能力、两条使用路径、九条契约、FAQ、验收）。
> 本文件只是 DSH 路径的 3 分钟快速上手。

这是一个 DSH 模式包：给桌面版 DSH 增加两个预设模式——

- **裁员广进（token-lean）**：主会话省 token 模式（13 插件精简配置）；
- **只读子代理（scout，显示名「· 只读子代理（内部，勿直接对话）」）**：只读子代理预设（4 插件，`write:false` + `edit:false`，禁写盘）；仅用于主会话的子代理委派，**不要直接对话**。

`targetRuntime: 0.2.1-rc.2`。其他版本请勿安装：预检工具的权威键表按该版本采集，跨版本必须重新采集（见 `docs/COMPATIBILITY.md`）。

## 包内容

- `presets\`：两段 preset 片段（YAML）
- `tools\`：`schema-preflight.cjs`（漂移预检器 + 版本契约）、`run-fixtures.cjs`（12 夹具批量跑）、`selftest.ps1`（自证全流程）、`runtime-probe.ps1`（只读 node 探测排障）、`regen-manifest.ps1`（重算 MANIFEST）
- `fixtures\`：12 个校验夹具 + `schema.mini.json`（4 插件权威结构，自带，免 schema 也能 12/12）
- `vendor\js-yaml\`：**内置 js-yaml 4.3.2（MIT）副本**——本包自带 YAML 解析依赖，无需联网安装
- `vendor\keys\`：按运行时版本分的权威键表（`0.2.1-rc.2.json` 等）
- `install.ps1 / verify.ps1 / uninstall.ps1`：安装 / 验证 / 卸载
- `build\repackage.ps1`：打成 `dist\裁员广进-release-<version>.zip` + `.sha256`
- `docs\`：70-P0 补测执行包、71-坑清单 16–28、72-清理清单、73-可适配经验、74-修复说明、75-企业级改造说明、76-0.3.2 修复说明、77-0.3.3 修复说明、78-0.4.0 改造说明、79-截断质量测试、80-私人 agent 省钱契约、COMPATIBILITY
- `EVAL-GUIDE.md`：给测评者（同学 AI）的完整流程说明；`LICENSE` / `THIRD-PARTY-NOTICES.md`：许可说明
- `kit\`：**与框架无关**的「省钱契约」套件（0.5.0 新增）—— 纯 JSON policy + 零依赖 Node 判定器，把工具封顶 / 输出封顶 / 截断诚实 / 分页 / 压缩 / 子代理隔离 / 限流 / 遥测这六条契约变成可判定件，不依赖本包的安装器或任何 agent 框架

## 前置条件

1. Windows + Windows PowerShell 5.1（系统自带即可）。
2. DSH 桌面版运行时 **0.2.1-rc.2**。
3. `node` 可用（**零假设自动探测 v2**：脚本按 `-NodeExe` → `$env:DSH_DESKTOP_NODE_EXECUTABLE` → `-DshHome` 下 5 候选（含 `<DSH安装目录>\DeepSeek Harness.exe` 电子主程序回退）→ PATH `node` 顺序探测，每个候选用 `--version` 实测可用性（超时 10s）；都不行才报错并给可复制命令）。**干净机器没有 node 也能装**：传 `-DshHome "<DSH安装目录>"` 即可，脚本会用 Electron 主程序当 node（自动设置 `ELECTRON_RUN_AS_NODE=1`）；也可显式 `-NodeExe "<DSH安装目录>\DeepSeek Harness.exe"`。
4. 权威 schema（**可选但建议**）：
   - **桌面 profile 无法导出 schema**（`--dump-config-schema` 被 Electron 独占，是死路，不要试）；
   - 替代：用**非 desktop** profile（web / headless 等）导出：`dsh <非desktop profile> --dump-config-schema > schema.json`；
   - 该 schema **不含 preset 层插件**——预检工具对这部分靠内置权威键表兜底（坑 24），不影响校验可用性；
   - 完全没有 schema 也能跑：`verify.ps1` 默认用自带的 `fixtures/schema.mini.json` 跑 **12/12**；若连 mini 都没有则 PARTIAL 7/7（均 exit 0）。

## 安装（含自证，干净机器一条命令即可）

> 干净机器没有 node 也没关系：**只要传 `-DshHome "<DSH安装目录>"`**，脚本会自动探测到 `<DSH安装目录>\DeepSeek Harness.exe`（Electron 主程序）并把它当 node 用（自动设置 `ELECTRON_RUN_AS_NODE=1`，调用完恢复）。也可显式 `-NodeExe "<DSH安装目录>\DeepSeek Harness.exe"`。排障可先跑 `tools\runtime-probe.ps1`（只读探测，输出 JSON）。

```powershell
# 0) （可选）排障：只读探测 node 候选，输出 JSON，不写任何文件、不改配置
powershell -ExecutionPolicy Bypass -File .\tools\runtime-probe.ps1 -DshHome "<DSH安装目录>"

# 1) 自证：在 %TEMP% 用合成 patch 跑通 安装→验证→卸载，绝不碰真实 cordis.patch.yml
powershell -ExecutionPolicy Bypass -File .\tools\selftest.ps1 -DshHome "<DSH安装目录>"

# 2) 演练：只打印将插入的内容，不落盘、不建备份、不加锁
powershell -ExecutionPolicy Bypass -File .\install.ps1 -ProfilePatch <你的cordis.patch.yml路径> -RuntimeVersion 0.2.1-rc.2 -DshHome "<DSH安装目录>" -DryRun

# 3) 真装（自动先备份为 *.bak-<时间戳>-release；版本契约：传版本/装目录，或显式授权）
powershell -ExecutionPolicy Bypass -File .\install.ps1 -ProfilePatch <你的cordis.patch.yml路径> -RuntimeVersion 0.2.1-rc.2 -DshHome "<DSH安装目录>"
#   版本三选一（至少一个）：-RuntimeVersion 0.2.1-rc.2 / -DshHome <DSH安装目录> / -AllowUnknownRuntime
#   可选 -SchemaPath schema.json 做 schema + 键表双重校验
#   干净机器无 node：务必加 -DshHome "<DSH安装目录>"（或 -NodeExe 指向 Electron 主程序）

# 4) 重启 DSH 桌面应用后，模式下拉应出现「裁员广进」与「· 只读子代理（内部，勿直接对话）」

# 5) 验证（默认零假设即过：有 mini schema → 12/12；无 schema → PARTIAL 7/7；均 exit 0）
powershell -ExecutionPolicy Bypass -File .\verify.ps1 -DshHome "<DSH安装目录>"
#   强制严格（无完整 -Schema 即 exit 1）：加 -StrictSchema；提供完整 schema：加 -Schema schema.json
```

安装成功的判据：脚本输出「全部校验通过」，且**重启 DSH 后**模式下拉出现「裁员广进」与「· 只读子代理（内部，勿直接对话）」。

- 版本护栏：`-RuntimeVersion` 传错（如 0.3.0）且无 `-AllowUnknownRuntime` → 写盘前即拒绝并回滚；不传版本且无法探测 → 拒绝并提示 `-AllowUnknownRuntime`。
- 版本探测：脚本按 `-RuntimeVersion` → `<DSH安装目录>\resources\runtime\primary-runtime\runtime.json` 的 `desktopVersion` → `resources\runtime\package.json` → `resources\runtime\node_modules\@deepseek-ai\dsh\package.json` 顺序探测 DSH 版本；**根目录的 `version` 文件是 Electron 版本（形状同为 `x.y.z`），绝不用来判定 DSH 版本**。若版本探测失败，先跑 `tools\runtime-probe.ps1 -DshHome "<DSH安装目录>"`（输出含 `versionDetect`：`selected`/`source`/`electronVersionGuess`，只读不写）排障；必要时显式 `-RuntimeVersion 0.2.1-rc.2`。
- 安装脚本对目标文件**字节保真**：BOM、行尾（CRLF/LF）、末尾换行按原样恢复；写盘全程加锁 + 原子替换，任何异常回滚到备份，不留半写状态。
- **安装日志（sidecar）**：安装成功后会生成 `<patch>.lean-journal.json`，记录装前 sha256 与插入方式；
  `uninstall.ps1` 据此**精确逆操作**并校验「字节级还原」，完成后自动删除该日志。请勿手工编辑或提前删除它。

## 验证（无 schema 时的部分/全量验证）

```powershell
# 默认即有 schema.mini.json → 期望输出含 TOTAL=12 PASS=12 FAIL=0，退出码 0
powershell -ExecutionPolicy Bypass -File .\verify.ps1
# 显式完整 schema → 同样 12/12
powershell -ExecutionPolicy Bypass -File .\verify.ps1 -Schema schema.json
# 严格模式：没有完整 -Schema 即 exit 1（拒绝静默通过）
powershell -ExecutionPolicy Bypass -File .\verify.ps1 -StrictSchema
```

## 卸载（强制收尾）

```powershell
powershell -ExecutionPolicy Bypass -File .\uninstall.ps1 -ProfilePatch <你的cordis.patch.yml路径>
# 可选 -PurgeBackups：额外清理本包产生的 *.bak-*-release / *.bak-*-uninstall 历史备份（默认保留）
```

卸载后核对（应返回 0 条命中）：

```powershell
Select-String -Path <你的cordis.patch.yml路径> -Pattern 'preset-token-lean|preset-scout'
```

并重启 DSH 确认模式下拉不再出现这两个模式。卸载脚本按原字节形态写回（含 BOM/行尾），并回收安装时多加的空行——「装→卸」后文件应与装前完全一致（sha256 不变）。卸载同样加锁 + 原子替换。

## 已知限制（如实）

- 广进模式 `readMaxBytes=65536`（0.4.0 由 24576 上调）：这是**单次读取的字节上限**，超过仍会截断并提示 `Use offset=N to continue.`，但可用 offset 续读拿全（见 preset 内的「分页契约」硬规则；测法见 `docs\79-截断质量测试.md` 的第 4 题执行包）。
- 「· 只读子代理（内部，勿直接对话）」会出现在模式下拉中，**无法隐藏**（运行时行为：DSH 只要 preset 存在就会列出，无法从用户可见的下拉里去除）；它仅供主会话的子代理委派使用，请勿直接对话。
- 预设层插件的 schema 无法从 CLI 导出，工具靠内置权威键表兜底；升级运行时后键表必须重新采集（见 `docs/COMPATIBILITY.md`）。
- schema 缺失时用 mini/默认键表的 12/12 或 7/7 是**受控验证**（类型用例由 mini/键表覆盖或跳过），不等于「提供了完整运行时 schema 的全量校验」。
