# CHANGELOG

## 0.5.2 — 2026-10-24（吸收萌源 7 条适配反馈：口径/兼容，无判定变更）

> 来源：萌源（Electron 渲染层 agent loop，非本包框架）real 接入 0.5.1 后的反馈。**7 条均为文档/口径/兼容改进，0 个 bug，C1–C9 + E1 的 PASS/FAIL/UNVERIFIED 规则一律未动。**

- **M1** `output.capBytes` 补"字节非字符"说明 + UTF-8 换算示例（schema description + portability 注记）。
- **M2** `prefix` 补量测口径：只计**静态基线**（system 固定部分 + 工具 schema 序列化字节），运行时动态注入（记忆/技能/计划/检索）不计入（schema description + README C9 同义句）。
- **M3** `summarize()` 的 usage 读支持网关别名（按序取第一个存在的，全缺按 0 不编造）：`inputTokens←inputTokens|prompt_tokens|input_tokens`；`outputTokens←outputTokens|completion_tokens|output_tokens`；`cacheReadTokens←cacheReadTokens|prompt_cache_hit_tokens|cache_read_input_tokens`。README 加 OpenAI/DeepSeek/Anthropic 映射表。
- **M4** README + prompt-pagination 各加一句"E1 只读 JSONL 的 `reportedTotal`，不依赖横幅位置"。
- **M5** README 加"带 SSRF/安全门的框架用公网长文（如 gutenberg 84-0.txt）验横幅，别绕安全门"（场景提示，非要求）。
- **M6** C7 PASS evidence 追加"（宿主声明值，lint 不校验真实性；对外报告须标注配额来源）"；README/schema rateLimit 描述补"声明非实测，须写明来源"。
- **M7** 新增 `--report-note`：开启时末行 JSON 追加 `reportNote` 字段并打印一行，说明"哪些是声明、哪些是实测"，防接入方贴给上级时误读；不带时输出不变。

## 0.5.1 — 2026-10-23（kit 修 5 条宿主反馈 + 宿主接入自检）

> 反馈来自真实宿主 research-orb v0.7.0 的接入：kit 原样落地、8 契约已有实测证据，但暴露 5 个问题，本轮逐条修。

### 修复（P1–P5）
- **P1** `subagent.inUse`：新增该字段（默认 `true`，不写视为在用）。`inUse:false`（诚实声明"本项目无子代理"）时 C6 由 PASS 降级为 **UNVERIFIED**——"声明不用"不再被读成"已达成隔离"。
- **P2** C1 新增 `--tool-count <N>` 最简入参（无需再造 `{tools:[...]}` 适配器）；`--agent-config` 保留，仍支持 `tools[]`/`functions[]`/数组/数字四形态。README 补三种形态最小示例。
- **P3** 新增 **C9 静态前缀预算**（`prefix:{systemBytes,toolSchemaBytes,maxTotalBytes}`）：缺失→UNVERIFIED、超预算或字段≤0→FAIL、合规→PASS；新增 `--baseline <calls.jsonl>` 算 `avgInputTokens` delta 与 `savedPct`（只记录，不 FAIL）。
- **P4** `--observed` 文件缺失或 0 条有效行时 E1 判 **UNVERIFIED**（不再误判 FAIL）；新增 `--fixture`（等价内置样例 `eval/sample.jsonl`）供宿主接入自检。
- **P5** 统计逻辑抽到 `kit/eval/lib/summarize.mjs`（导出 `summarize(records)`），`policy-lint --observed` 与 `summarize-calls.mjs` 共用；`--observed` 一次输出全部统计字段 + E1 判定，不再跑两遍。

### 新增
- `--selftest-host`：自包含（不读外部文件）宿主接入自证——内置 policy + 样例跑 C1–C9 + E1，做 ≥3 组**双向断言**（C1：13 过/20 不过；C6：inUse:false→UNVERIFIED；E1：样本 PASS/空 UNVERIFIED；另加 C9 prefix 双向），输出「宿主接入自检报告」+ `SELFTEST: PASS (n/n)`。

### 文档 / schema 同步
- `policy.schema.json`：加 `subagent.inUse` 与可选 `prefix`；`policy.example.json`：加 `subagent.inUse:true`（`prefix` 故意留空→默认 C9 UNVERIFIED）。
- `kit/README.md`：宿主接入四步 + `--selftest-host` + C9/inUse 说明 + E1 前置（无数据用 `--fixture`）+ C1 三形态示例 + stripBom 说明。
- `kit/portability.md`：每栈补"静态前缀预算怎么量"（system + tool schema 字节数）。
- 全 `kit` 强制 stripBom（PowerShell 5.1 写 JSON 常带 BOM）。

## 0.5.0 — 2026-10-22（kit：与框架无关的「省钱契约」套件）

> 外部非 agent 框架项目只拿走了模式包的封顶数字，却把六条契约只落了 2 条；本包的 12 夹具与 score-* 因依赖框架 schema 而不可移植。本轮把六条契约做成**任何框架都能跑**的可判定件。

### 新增（均在 `kit\`，零依赖、零框架耦合）
- `kit/policy.schema.json`：policy.json 的 JSON Schema（draft-07 子集），字段名照抄任务规范。
- `kit/policy.example.json`：把「裁员广进」语义翻成纯 JSON（maxTools 13 / capBytes 65536 / capLines 800 / `Found {shown} of {total}` / 压缩 0.8·0.2·4096 / 子代理只读·depth1·8192 / 限流 10·20 / 遥测全五项）。
- `kit/policy-lint.mjs`（核心）：检查 C1–C8 + 观测 E1；每条给 ID/判定/证据/修复建议；末尾 JSON 汇总 + 退出码（FAIL→1 / 全 PASS 或含 UNVERIFIED→0 / 参数读错→2）；**仅用 Node 内置模块，不 require 任何第三方**。
- `kit/prompt-pagination.md`：可直接粘进任意 system prompt 的中 / 英分页·截断诚实契约文本。
- `kit/portability.md`：OpenAI / Anthropic / LangChain / LangGraph / MCP / vLLM·Ollama / n8n / 自建 ReAct 共 8 行的挂载点对照表（≤3 行片段）。
- `kit/README.md`：3 分钟上手 + 与模式包关系 + 不适用场景。
- `kit/eval/summarize-calls.mjs` + `kit/eval/sample.jsonl`：观测日志汇总（截断率 / 上报率 / token 成本代理）+ 6 行样例。

### 约束达成
- 零依赖：全 `kit` 仅 `node:fs` / `node:path` / `node:url`，无 js-yaml、无第三方。
- 零框架耦合：`kit` 内不含 `cordis` / `dsh` / `agentPreset` / `asar` / `preset`（README 一句溯源说明亦不含这些字面量）。
- 纯 JSON 输入：policy / agent-config 均走 JSON，不引入 YAML 解析。

## 0.4.4 — 2026-10-22（三重压力测试终局结论 + persona 计数硬规则）

> 三个场景（定向读 / 全量扫描 / grep 上限）实测均**无质量代价**；据此把"计数类问题不得把上限当总数"写进 persona 硬规则。

### 结论（逐字采信主管实测，未重新论证）
- 定向读（给定行区间 2500–2510，3000 行 / 84 KB）：标准 11/11、广进 11/11（2 秒）。
- 全量扫描（11 个 MARK，不知位置）：标准 11/11、广进 11/11（grep + Select-String 交叉核对）。
- 上限压力（200 个 MARK，> grepMaxMatches=150）：标准 200、广进 200（自述 grep 提示 `Found 150 of 200`，改用 Select-String 全量核对得 200）。
- **机制**：上限**如实报总数**（`Found X of Y`）+ 模型换方法自救 = 无代价；自救是行为风险，非结构缺陷。

### 修改
- `presets/token-lean.yml`：**仅**在 persona 的 `suffix` 追加一条「计数/统计类问题」硬规则（0.4.4 新增，附实测依据写在文件头注释）：若工具返回出现 `Found X of Y`（或等效"共 Y 条、只显示 X 条"），必须报告 **Y** 或换方式核对到 Y 为止，不得把 X 当总数。`scout.yml` 未动。
- `docs/82-grep上限测试.md`：加「§实测结果（2026-10-22）」表 + 三条要点（上限诚实 / 模型自救 / 行为风险限定）。
- `32-对外结论卡.md`：§7 升为最终版（三场景全对、广进更快、机制、限定 DSH 0.2.1-rc.2 + 三类任务）；删去"未测前不得宣称"字样；§1 质量指针同步指向三类实验。
- `tools/score-scan.ps1`：本版未改（0.4.3 已具备上限判定，无需补 `-Expected`）。

## 0.4.3 — 2026-10-22（grep 上限测试 + 快照步长 + 评分器上限判定）

> 测的不是"能不能读全"，而是**"命中结果上限后，模型会不会把上限当成总数"**——比"没翻页"更隐蔽。

### 新增
- `docs/82-grep上限测试.md`：为什么测（裁员广进 `grepMaxMatches=150`；scout 250；运行时 schema 默认 250）、生成命令 + 预期 sha256、逐字题面、四种判分、解读指引、必须由人跑两段会话（广进 + 标准对照）。
- 项目 `70-grep上限实验包.md`（一页：谁做什么 / 三步 / 四种判定 / 结果填哪）。
- `tools/make-snapshot.ps1` 增 `-MarkStep`（默认 **1**，保持老口径 900–910 连续、向后兼容）：
  `-MarkStart 500 -MarkCount 200 -MarkStep 10` → 3000 行 / **200 个 MARK** / 行号 500,510,…,2490（最后一个 = 500+199×10） / 86,000 B ≈ 84 KB / **同参数两次 sha256 一致**。
- `tools/score-scan.ps1` 增"上限命中"判定（**参数不变**）：
  - `expected` 从快照实算（不写死）；
  - `found == 150`（preset 的 `grepMaxMatches`）且 `missing>0` → `verdict=疑似命中grep上限`；
  - `declaresCap` 检测诚实声明词（150 / 上限 / 截断 / 只显示 / showing / truncat；`150` 用数字边界，避免误命中 `MARK-1500`）；
  - 退出码：编造→1；命中上限**未声明**→1；漏（found<expected 且非上限）→1；否则 0。

### 自测（AI 本机实跑）
- `make-snapshot -MarkStep`：3000 行 / 200 个 MARK / 行号 500…2490 / 两次 sha256 一致；默认口径仍 900–910 连续（向后兼容已验证）。
- `score-scan` 四份合成答案：200→`无代价`(0)；150+声明→`疑似命中grep上限`(0)；150 不声明→`疑似命中grep上限`(**1**)；`MARK-9999`→`编造`(**1**)。

### 待执行（主管）
- 用 `docs/82` 逐字题面跑两段真实对话（裁员广进 + 标准对照），`score-scan` 判分。

## 0.4.2 — 2026-10-22（记录截断实验结论 + 全量扫描硬变体 + 评分器检测修复）

### 实测结果（2026-10-22，逐字采信，不重新论证）
- 快照 `big`：3000 行 / 84,110 字节；目标行 2500–2510。
- 标准：4 秒，11/11，注明「本次读取范围为 2490–2519 行」；广进：2 秒，11/11，未注明读取范围。
- `score-truncation`：两者 11/11，`verdict=未观察到质量代价`。
- **结论：未观察到质量代价（限定：问题已给行区间，模型可定向读）**。本次未记录 UI 用量，下次需记录（不编造 token）。
- 洞察：给行号＝定向读（offset 取窗），`readLimit=800` / `readMaxBytes=65536` 没咬到人；真正风险＝**"必须扫全文件"** → 新增硬变体。

### 新增
- `docs/81-全量扫描测试.md`：硬变体（不给位置，必须覆盖 3000 行 = ≥4 次 800 行读取）；逐字题面、11 个真值（`MARK-2500…2510`）、四种判分。
- `tools/score-scan.ps1`：从快照抽 `MARK-\d{4}` 真值、答案抽同集合，算 found/missing/extra；`extra>0`→`编造` 且退出码 1；不调模型、不写文件。
- 项目 `69-全量扫描实验包.md`；`docs/79` 增 §八实测结果；`32-对外结论卡` 增 §7 质量段。

### 修复
- `tools/score-truncation.ps1` 的 `mentionsOffset` 漏检：
  - 补正则：`读取范围|offset=|limit=|第\s*\d+\s*[–-]\s*\d+\s*行|range`。
  - **根因**：PS5.1 `Get-Content` 默认按 ANSI 读答案文件，UTF-8 中文被读花 → 加 `Read-TextSmart`（BOM / UTF-16 / 严格 UTF-8 / GBK 回退）。
  - 实测：标准答案「读取范围为 2490–2519 行」→ `mentionsOffset=True`（修复前 False）。

### 自测（AI 本机实跑）
- score-scan：11/11→`无代价`、0→`代价成立`、混入 `MARK-9999`→`编造` exit 1。
- score-truncation：`mentionsOffset` 由 False 变 True。
- MANIFEST 重算、zip 重打后解压 `verify` 12/12。

### 待执行（主管）
- 用 `docs/81` 硬题面跑两段真实对话，`score-scan` 判分（全量扫描是否掉质量）。

## 0.4.1 — 2026-10-21（截断实验包 + 自审修复）

### 新增
- `tools/make-snapshot.ps1`：确定性快照生成器（`-Out / -Lines 1200 / -Seed 20261021`）。每行 `L####|k=<8hex>|v=<seed派生>`，第 900–910 行含 `MARK-0900…0910`；UTF-8 无 BOM、LF、末行换行；打印 sha256 与行数；**同 seed 两次 sha256 一致**。
- `tools/score-truncation.ps1`：自动评分器（只用 Get-Content/正则，不调模型）。抽第 900–910 行，归一化比对，输出 `quoted/exact/mentionsOffset/declaresTruncation` + 一行结论 + JSON；退出码 0。
- `docs/79-截断质量测试.md` 重写为可执行包（为什么能测截断 / 三步执行 / 逐字题面 / 记录表 / 判分表 / 如何解读）。
- 项目侧 `68-截断实验包.md`（一页：谁做什么、怎么判、结果填哪）。

### 自审修复（第二轮要求）
- **EVAL-GUIDE**：第 4 题旧口径 `readMaxBytes=24576` → `65536`（`readLimit=800` 才是行数截断主因）；生成命令改用 `tools/make-snapshot.ps1`；题面改为逐字版并指向 `docs/79`。
- **install.ps1 / uninstall.ps1**：catch 分支原 `throw`（失败路径无结构化输出）改为 `Emit-Fail`，使**每条失败路径**末行都是 `{"ok":false,"stage":…,"cause":…,"detail":…}`。

### 自审 8 条结论（逐条）
1. 过时数字：`24576` 仅余于 `docs/70`（历史 P0 执行包，已被 79 取代，**不在本轮可写范围**）；EVAL-GUIDE 的 `24576` 已改 `65536`；`13 插件/4 插件` 与现状一致；`spill/落盘/按路径读回` 无 read 错误承诺（token-lean 只剩"不落盘、无 spill 路径"否定句；余为 DryRun 不写盘/缩进偏移/写 preset 的合法用法）。
2. scout 一致性：`agentPreset: scout`/`allowedAgentPresets` 引用 **id=scout**（未改）；order 7<8；README/EVAL-GUIDE 用新显示名——无问题。
3. `--batch` 契约：L224 同时接受 `{tasks:[…]}` 与裸数组（两形态实跑均 ok）；install 两处均带 runtimeVersion/dshHome/allowUnknownRuntime；cause 不丢（bad→UNKNOWN_KEY）。
4. 结构化失败：4 脚本失败路径均改 `Emit-Fail`（本轮补 install/uninstall 两处 `throw`）；枚举仅 13 类；verify 失败末行实测为结构化 JSON。
5. 文档↔行为：README/EVAL-GUIDE/COMPATIBILITY/75/77 与代码核对；"已验证"均附命令。
6. MANIFEST：regen 后条数 = 磁盘可分发文件数（= 总文件 − 1 MANIFEST 自身，且 dist/.bak-/.lock/.tmp-/.lean-journal 排除）。
7. 脱敏：8 类模式 release + 68 全库 0 命中。
8. 回归：两 cjs `node --check`、全 `.ps1` ParseFile、两 preset js-yaml 解析、`verify.ps1` 12/12（本机 `-NodeExe` 跑通；`-DshHome` 真机标待执行）。

### 自测（AI 本机实跑）
- make-snapshot：同 seed sha256 一致（`41a5b322…`）、1200 行、`MARK-0900…0910`、无 BOM/LF/末行换行。
- score-truncation：全对→`未观察到质量代价`；漏 3 行→`质量代价成立`；标准也漏→`实验无效`。

### 待执行（主管）
- 跑两段真实对话并用 `score-truncation` 判分；`install -DshHome` 真装 / `selftest` 6/6 / 四样本字节还原 / `repackage` 出 zip。

## 0.4.0 — 2026-10-21（修假文案 + 大文件质量 + 降噪 + 吸收 ops 两条 + 泛化规范）

### P0 修「假文案」
- `presets/token-lean.yml` 描述（原约 L25）与 persona suffix（原约 L33-34）原写「超限落盘、可按路径读回」「给出 spill 文件路径，按路径读回」——在 0.2.1-rc.2 上**是假的**：`dsh-tool-fs` 的 read 截断只输出 `(Output capped… Use offset=N to continue.)`，**不落盘、无 spill 路径**；只有 base 的 spill-policy 对超大工具结果落盘。
- 改写为真实行为：**用 offset 续读**；显式注明「只有 base spill-policy 对超大工具结果落盘，read 自身从不落盘」。全文 grep 确认其余 `落盘/偏移` 均为合法用法（DryRun 不落盘＝不写盘、缩进偏移、install 落盘＝写 preset）。
- `docs/78-0.4.0改造说明.md` 给出「文案 ↔ 真实行为」逐句对照表。

### P0 大文件质量
- persona 增硬规则：出现 `Output capped` / `Use offset=N to continue.` 必须 **offset 续读**直到覆盖所需区间，引用截断区须**注明 offset 范围**。
- `readMaxBytes` **24576 → 65536**（token-lean + scout；`readLimit` 保持 800，`readMaxLineLength` 保持 1200）。README 注明「单次读取字节上限，超出仍可 offset 续读」。
- 新增 `docs/79-截断质量测试.md`：标准/广进各一次的「读第 900–910 行逐行引用」可粘贴题面 + 判分口径（逐行 / 注明 offset / 漏行）。

### P1 降噪
- `presets/scout.yml` 的 `name` → `· 只读子代理（内部，勿直接对话）`；README 已知边界说明「出现在下拉是运行时行为，无法隐藏」；`token-lean.order=7 < scout.order=8` 不变。install/uninstall/EVAL-GUIDE 文案同步。

### P1 吸收 ops 两条
- **批量校验**：`tools/schema-preflight.cjs` 新增 `--batch <spec.json>`——一次调用跑多个子任务，输出统一 JSON `{ok, exitCode, results:[{task, ok, exitCode, stdout, stderr, cause}]}`；**失败定位到子任务、cause 枚举不变、退出码语义不变**。`install.ps1` 的两处 schema-preflight 改走 `--batch`（保留 runtimeVersion/dshHome 透传）。设计上以子进程复用单跑逻辑，零行为回归（不减少进程数，进程内合并不在 0.4.0 范围）。
- **脚本级结构化失败**：`install/uninstall/verify/selftest` 增 `Emit-Fail`，失败末行输出 `{"ok":false,"stage":<install|verify|uninstall|selftest>,"cause":<枚举>,"detail":"…"}`；枚举复用现有 10 类 + `LOCKED`/`NODE_NOT_FOUND`/`PRECONDITION`；人类可读信息仍用 Write-Host，JSON 用 stdout 保证末行。

### P1 泛化规范
- 新增 `docs/80-私人agent省钱契约.md`：面向非 DSH 自建 agent 的 6 条可移植规则 + 8 栈映射（OpenAI/Anthropic/LangChain/LangGraph/MCP/vLLM·Ollama/n8n/自建 ReAct，每栈挂载点 + ≤8 行伪代码 + 该栈特有的坑）+ 3 条验证指标 + 不适用边界。

### 静态自检（本 AI）
- `node --check`：schema-preflight.cjs / run-fixtures.cjs 均 SYNTAX OK。
- YAML：两 preset 可解析（顶层 1 item）。`--batch` 冒烟：pass→ok、bad→cause=UNKNOWN_KEY、双子任务→均 ok。
- `verify.ps1` 12/12 PASS；失败末行为结构化 JSON（exit 2）。四改后 `.ps1` ParseFile OK。
- 运行时端到端（install 真装 / selftest 6/6 / 四样本字节还原 / repackage zip）标【待主管执行】。

## 0.3.3 — 2026-10-21（版本探测误判修复 P1 + 定版）

0.3.2 已在同学真机实测通过（逐字采信）：node 探测命中 `...\node\bin\node.exe`（v24.21.0）、selftest 5/5、
verify 12/12、安装后 205 行、卸载 205→28 行且 **sha256 与装前完全一致**、MANIFEST 66/66 全匹配、装后产物确定性一致。
**唯一 P1**：`-DshHome` 且不传 `-RuntimeVersion` 时，版本门禁读到 `<DshHome>\version`（内容 `44.7.0`，那是 **Electron**
版本），误判"不支持的运行时版本：44.7.0"，写盘前 exit 1（零写入、无半装，但 DryRun 不打印内容、文档命令失效）。
真实 DSH 版本在 `<DshHome>\resources\runtime\primary-runtime\runtime.json` 的 `desktopVersion` 字段（`0.2.1-rc.2`）。

### 根因
- `detectDshVersion` 把根目录 `version`（Electron 版本，形状同样是 `x.y.z`）当作 DSH 运行时版本来源 → 拿到 `44.7.0`，
  键表 `44.7.0.json` 不存在 → 版本契约拒绝。

### 修复点（tools/schema-preflight.cjs）
- **候选顺序重写**（命中即返回，记录 source 与逐候选结果）：
  1. `-RuntimeVersion`（最高优先，不变）；
  2. `<DshHome>\resources\runtime\primary-runtime\runtime.json` → 字段 `desktopVersion`（缺失时退到同文件 `version` / `runtimeVersion`）；
  3. `<DshHome>\resources\runtime\package.json` → `version`；
  4. `<DshHome>\resources\runtime\node_modules\@deepseek-ai\dsh\package.json` → `version`；
  5. 都不存在 → 返回 `unknown`（**不再读根目录 `version`**）。
- **根目录 `version` 处理**：仅作为 `evidence.electronVersionGuess` 参考输出，**不参与判定**；无法靠格式区分 Electron 版本与 DSH 版本（同形 `x.y.z`），故彻底排除。
- **新增 `--print-version`**：输出 JSON `{ok, selected, source, candidates:[{path,exists,value,reason}], evidence:{electronVersionGuess}}`，只读不写，退出码恒 0，供 selftest 与排障。
- **版本比较容错**：允许前后空白、`v` 前缀（`v0.2.1-rc.2` 视为 `0.2.1-rc.2`）；与键表按字符串全等（大小写敏感），不做 semver 范围推断。
- **unknown 错误信息增强**：探测不到时列出「已尝试的候选与各自结果」及"（根目录 version 为 Electron 版本，不参与判定）"，不再只说"不支持"。

### 配套改动
- `tools/runtime-probe.ps1`：输出 JSON 增 `versionDetect` 段 `{selected, source, candidates[], electronVersionGuess}`，仍只读不写。
- `tools/selftest.ps1`：新增第 6 步「版本探测优先级 (runtime.json 优先于 version)」——%TEMP% 构造合成 DSH 树（runtime.json 写 `desktopVersion=0.2.1-rc.2` + 根 `version=44.7.0`），断言 `selected=0.2.1-rc.2` 且 `source=primary-runtime/runtime.json`、断言不会得到 `44.7.0`；全程仅碰 %TEMP% 合成文件。
- 文档：README 补 `--print-version` 排障句与"根 version 是 Electron 版本"说明；EVAL-GUIDE 报告模板加版本探测行 + 已知现象；COMPATIBILITY 版本来源列写 `desktopVersion`；75 §G4 追加版本来源优先级与 Electron 排除。

### 0.3.2 同学真机实测通过项（逐字采信，不得回退）
- node 探测命中 `...\node\bin\node.exe`（v24.21.0），selftest 5/5 全过
- verify `TOTAL=12 PASS=12 FAIL=0`，exit 0
- 安装：205 行、原子替换、回读校验通过、纯 LF 未被转 CRLF
- 卸载：205→28 行、**字节级还原 True**、sha256 与装前完全一致、journal 已删
- MANIFEST 66/66 全匹配；装后产物确定性一致
- 上述通过项中暴露的唯一 P1 已在本版（0.3.3）修复

## 0.3.2 — 2026-10-21（零假设 node 探测修复 + 版本门禁负向夹具）

第三方干净机器（Win11 / PowerShell 5.1.26100 / DSH 0.2.1-rc.2 + Electron 44.7.0，机器上**没有 node**）实测发现唯一 P0：
原 `Resolve-NodeExe` 在真正干净的 DSH 桌面机上全部落空 → selftest/install/verify 均 `exit 2`。
根因：DSH 桌面机不导出 `DSH_DESKTOP_NODE_EXECUTABLE`，`<DshHome>\resources\runtime\` 下没有可用 `node.exe`
（`bin\node` 是 `#!/bin/sh` 脚本，Windows 不可执行；`primary-runtime\dependencies\node\` 下也没有 `node.exe`），PATH 里也没有 node；
**唯一可用的 node 是 `<DshHome>\DeepSeek Harness.exe`**（Electron 主程序，靠 `ELECTRON_RUN_AS_NODE=1` 当 node）。

### 修复点
- **P0 `Resolve-NodeExe` v2**（`install.ps1` / `verify.ps1` 同款实现）：候选顺序 `-NodeExe`（显式，不可用即报错不静默跳候选）
  → `$env:DSH_DESKTOP_NODE_EXECUTABLE` → `-DshHome` 下 5 候选（含 `<DshHome>\DeepSeek Harness.exe` 电子回退）→ `<DshHome>` 根任意 `DeepSeek*Harness*.exe` → PATH `node`；
  **每个命中候选都用 `node --version` 实测可用性（超时 10s）**，Electron 候选须带 `ELECTRON_RUN_AS_NODE=1`；全失败打印逐条候选 + 原因 + 可复制命令。
- **Electron 调用约定**：一旦解析到 Electron 主程序，所有子进程调用（版本预检 / schema 校验 / run-fixtures）都带 `ELECTRON_RUN_AS_NODE=1`，调用后恢复原值（finally 保证）；脚本打印 `node 解析：<路径>（来源：<候选>）`。
- **新增 `tools/runtime-probe.ps1`**：只读探测各候选（exists/usable/reason/version），输出 JSON `{ok, candidates:[...], selected}`，不写文件不改配置，排障先跑它。
- **`selftest.ps1` 增强**：新增 `-DshHome`/`-NodeExe` 透传；每步 `detail` 追加 node 解析路径与来源、失败追加候选列表；失败时打印可复制修复命令；新增第 5 步「版本门禁负向（0.9.9 应拒绝且零写入）」。
- 文档同步：README / EVAL-GUIDE 改为「一条命令即可 + Electron 回退 + 排障先跑 runtime-probe」；COMPATIBILITY 新增该实测环境；75 追加 §G1 补充；LICENSE-NOTES 运行依赖补一句。

### 第三方实测已通过项（同学报告，逐字采信，不得回退）
- DryRun 零写入（sha256 不变、无 .bak、无 .lock/.tmp-*）
- 缩进自适应（片段 4 空格 → 目标 2 空格，偏移 -2 正确）
- 安装：原子替换、回读校验、journal 生成、28→205 行、纯 LF 未被转 CRLF、结构正确
- verify：`TOTAL=12 PASS=12 FAIL=0`、`判定：PASS`、exit 0（mini schema 生效、F8 文件描述符重定向不再 EPERM）
- 卸载：205→28 行、**字节级还原 True**、sha256 与装前完全一致、journal 已删、备份已清
- 安装期间运行中的 DSH 未回写配置（并发安全 OK）
- 唯一 P0：加 `-DshHome` 后 `Resolve-NodeExe` 命中 `DeepSeek Harness.exe` 并跑通 DryRun 与安装

## 0.3.1 — 2026-10-21（主管运行时验收修复）

0.3.0 交付后，主管在本机执行了完整运行时验收（selftest / 安装 / 卸载 / 版本门禁 / 并发锁 / 字节保真），
发现并修复 4 个**只有真跑才会暴露**的缺陷：

- **R1 片段缩进未对齐**：片段固定 4 空格，而目标 patch 的 `- insert:` 子项常见为 2 空格 → 追加后拼出
  `bad indentation of a sequence entry`，安装校验失败并回滚。改为**按目标块子项缩进动态对齐**（任意 2/4 空格均可）。
- **R2 无 insert 时漏写头行**：目标文件没有 `- insert:` 时，原先只追加了空行+片段，**没写 `- insert:` 头行**，
  导致片段被当成上一个顶层项的子项。已补上（并在原文末行非空时补一个分隔空行）。
- **R3 卸载无法字节还原**：仅凭行内容无法区分"原文自带尾部空行"与"安装新增空行"，且卸载按**装后**布局写回
  （末尾换行/BOM/行尾）。改为 **install 写 sidecar 日志 `<patch>.lean-journal.json`**（记录 originalSha256、
  是否新建块、是否加空行、原始 trailingNewline/eolCRLF/hasBom），**uninstall 按日志精确逆操作并校验 sha256**，
  完成后删除日志。
- **R4 退出码被 `Write-Error` 吞掉**：`$ErrorActionPreference='Stop'` 下 `Write-Error` 先抛异常，
  设计的 `exit 3`（并发锁）/`exit 2`（文件缺失）变成 exit 1。统一改为 `Write-Host`，退出码恢复为 3/2。

### 本次运行时验收结果（本机实测）
- `tools/selftest.ps1`：**ok=true，4/4 步全过**（DryRun 零写入 / install / verify 12/12 / uninstall sha256 回装前）
- `verify.ps1`：默认（mini schema）**12/12 exit 0**；`-StrictSchema` exit 1；带真实 schema **12/12**
- 字节保真往返：**LF 无 BOM / CRLF 带 BOM / 无末尾换行 / 有末尾换行 / insert 2 空格 / insert 4 空格 / 无 insert**
  七类样本，装→卸后 **sha256 与装前完全一致**
- 版本门禁：`-RuntimeVersion 0.9.9` → 拒绝且文件未改；不给版本且探测不到 → 拒绝并提示 `-AllowUnknownRuntime`
- 并发锁：持锁时 install **exit 3**；目标不存在 **exit 2**；只读目标 → 失败回滚且文件未改
- 半装守卫：只有一段 preset 时拒绝安装、文件未改
- 打包自洽：`build/repackage.ps1` 产物解压后，`selftest` 4/4、`verify` 12/12、脱敏 0 命中

## 0.3.0 — 2026-10-21（企业级交付门槛 G1–G6）

把「本机可用的原型」提升为「可发布的企业级交付物」。逐条对照与自检见 `docs/75-企业级改造说明.md` 与项目内 `64-企业级门槛对照.md`。


- **G1 零假设安装**：`install.ps1` / `verify.ps1` 的 `-NodeExe` 默认值改为空，运行时按 `DSH_DESKTOP_NODE_EXECUTABLE` → `-DshHome` 内 `resources/runtime/node[.exe]` → PATH `node` 顺序自动探测，全部失败才报错并给出三种解法；不再隐式依赖 PATH 里有 node。`verify.ps1` 默认零假设即通过（有 `fixtures/schema.mini.json` 时 12/12，否则 PARTIAL 7/7，均 exit 0）；`-StrictSchema` 恢复「无完整 schema 即 exit 1」。README 三步改四步（selftest → install -DryRun → install → 重启验证 → uninstall）。
- **G2 原子与可中断**：`install.ps1` / `uninstall.ps1` 进入写操作前创建 `<patch>.lock`（`FileShare.None`，被占用则 exit 3），finally 释放；先写 `<patch>.tmp-<pid>`，校验通过后再 `[System.IO.File]::Replace` 原子替换，任何异常都回滚到备份，不留下半写状态。
- **G4 版本契约**：`schema-preflight.cjs` 的权威键表（plugins/required/types/deprecated）抽到 `vendor/keys/<version>.json`（当前 `0.2.1-rc.2.json`）；版本探测顺序 `-RuntimeVersion` → `-DshHome` 自动探测 `resources/runtime/package.json` / app.asar 旁 `version` 文件 → 都拿不到则拒绝并提示 `-AllowUnknownRuntime`；键表文件不存在或版本不一致且未授权 → 拒绝（exit 3）。新增 `--version-check` / `--list-versions` / `--dsh-home` / `--allow-unknown-runtime`。`install.ps1` 写盘前用 `--version-check` 预检。
- **G5 自证验证**：新增 `tools/selftest.ps1`（在 `%TEMP%` 用合成 patch 跑通 DryRun 零写入 → install exit 0 → verify 12/12 → uninstall sha256 回装前 → 清理，绝不触碰真实 `cordis.patch.yml`，输出 JSON `{ok, steps[], exitCode}`）；新增 `fixtures/schema.mini.json`（从真实 schema 抽取 4 个插件 tool-subagent/tool-fs/tool-fs-search/tool-web 的 `$defs` 与 if/then，无本机路径，用量 13.9 KB）。`verify.ps1` 无 `-Schema` 时优先用 mini，没有才降级 PARTIAL。`run-fixtures.cjs` 调用工具时统一加 `--allow-unknown-runtime`，避免夹具验证被版本门禁误拒。
- **G6 交付工程化**：新增 `build/repackage.ps1`（生成 `dist/裁员广进-release-<version>.zip` + 同名 `.sha256`，排除 `dist\` 与 `*.bak-*`）；`LICENSE`（本包 MIT）+ `THIRD-PARTY-NOTICES.md`（js-yaml 4.3.2 MIT 原文）；`docs/COMPATIBILITY.md`（版本/键表/支持矩阵）；`uninstall.ps1` 新增 `-PurgeBackups`（清理 `*.bak-*-release` 与 `*.bak-*-uninstall`，默认不删）。

### 交付物新增/改写清单（0.3.0）
- 新增：`tools/selftest.ps1`、`fixtures/schema.mini.json`、`build/repackage.ps1`、`vendor/keys/0.2.1-rc.2.json`、`LICENSE`、`THIRD-PARTY-NOTICES.md`、`docs/COMPATIBILITY.md`、`docs/75-企业级改造说明.md`
- 改写：`install.ps1`（G1/G2/G4）、`uninstall.ps1`（G2/G6）、`verify.ps1`（G1/G5）、`tools/schema-preflight.cjs`（G4）、`tools/run-fixtures.cjs`（G5）、`README.md`、`EVAL-GUIDE.md`、`tools/regen-manifest.ps1`
- 全目录脱敏维持 8 模式 0 命中；四个 .ps1 均 UTF-8 with BOM 且 PSParser 解析通过；两个 .cjs 经 `node --check` 通过（均需【待主管执行】真实验证）

## 0.2.0-fix1 — 2026-10-20

针对外部测评确认的 4 个 P0 + 5 个 P1/P2 缺陷的修复（逐条详情见 `docs/74-修复说明.md`）：

- **F1** install.ps1：目标 patch 以 `- insert:` 结尾时不再越界（追加到末尾分支），DryRun 与真装同分支
- **F2** install.ps1：`Invoke-NodeCapture` 捕获式调用（Start-Process + 临时文件重定向，native stderr 不再触发 Stop）；插入→校验→判定整段 try/catch，异常回滚并打印 md5；半装态（只有一段 preset）拒绝安装并提示先卸载
- **F3** vendor/js-yaml/：内置 js-yaml 4.3.2（MIT）副本；加载顺序 DSH_PROFILE_DIR → vendor → require('js-yaml') → 明确报错 exit 2；js-yaml 源码零改动，LICENSE 保留
- **F4** install.ps1：DryRun 移到备份之前，DryRun 路径零写入（不落盘、不建 .bak）
- **F5** install/uninstall.ps1：写回按原文件字节形态恢复（BOM/行尾/末尾换行）；uninstall 回收安装时多加的空行，回读断言两段消失 + 行数账目
- **F6** install.ps1：删除硬编码 `--runtime-version`，改为可选 `-RuntimeVersion`（传错版本 FAIL 且回滚；不传提示"跳过版本护栏"）
- **F7** run-fixtures.cjs 新增 `--no-type`（7 非类型夹具，TOTAL=7）；工具 schema 改为可选（缺失时降级仅权威键表判定）；verify.ps1 新增 `-AllowNoSchema`（PARTIAL 7/7 exit 0；不带开关仍告警 exit 1）；README/EVAL-GUIDE 写明"桌面 profile 无法导出 schema"及非 desktop 替代
- **F8** run-fixtures.cjs：spawnSync stdio 改 `['ignore', fdOut, fdErr]` 临时文件重定向，沙箱内不再 EPERM
- **F9** 全目录脱敏扩到 8 个模式（新增：AI_Workspace 盘符路径、dsh-orb 版本串、xixi 盘符路径、一个 5 位数字串；原有：机器用户名、构建机盘符路径、T3 实验名、p16 目录名——完整清单见任务 F9 与 docs/74，此处不逐字引用以免自指命中）；71 号坑 27 的 tgz 路径改 `<被删的 tgz 路径>`；EVAL-GUIDE 的 dsh-orb 句改通用表述
- 新增：`vendor/js-yaml/**`、`LICENSE-NOTES.md`、`docs/74-修复说明.md`、`tools/regen-manifest.ps1`
- MANIFEST.json 已按 0.2.0-fix1 磁盘状态重算（含全部新增文件）；后续可用 `tools/regen-manifest.ps1` 随时重算

## 1.0.0 — 2026-10-20

首个对外分发版。

### 新增
- `presets/token-lean.yml`：裁员广进主模式（13 插件，0.2.1-rc.2 形态）
- `presets/scout.yml`：只读子代理预设（4 插件，`write:false` + `edit:false`）
- `tools/schema-preflight.cjs`：Schema 漂移预检器（10 类 cause + OK；`--preset/--schema/--json/--runtime-version/--profile-package`）
- `tools/run-fixtures.cjs`：12 夹具批量验证器（UNLISTED / MISSING 双防御）
- `fixtures/`：12 个校验夹具（6 旧功能 + 5 type + 1 个 PRESET_PARSE_ERROR 负向）
- `install.ps1 / verify.ps1 / uninstall.ps1`：参数化安装 / 验证 / 卸载（UTF-8 with BOM，兼容 PS 5.1）
- `docs/`：70-P0 执行包、71-坑清单 16–28、72-清理清单（脱敏版）、73-可适配经验
- `EVAL-GUIDE.md`：测评者全流程说明（含强制卸载与核对命令）

### 与构建机原版的差异（3 个受控改写文件）
- `presets/*.yml`：仅「# 来源：」注释行脱敏（原含构建机绝对路径），正文逐字保留
- `tools/schema-preflight.cjs`：① 头部加 release 说明（CURATED 键表针对 0.2.1-rc.2 采集）；② `loadYaml()` 移除内置本机路径，改为 `DSH_PROFILE_DIR` 环境变量 → `require('js-yaml')`；③ js-yaml 缺失错误文案同步更新。其余逐字保留
- 以上两处差异在 `MANIFEST.json` 中以 `identicalToSource: false` + `note` 标注，`sha256Source` 一并列出

### 明确不分发
- 50–62 号历史文档、`72a-cleanup.ps1`、`_schema-desktop.json`、`drift-drill-report.json`、`drift-drill.cjs`、`preset-check.mjs`、`preset-config-validate.mjs`、`bundle-甲/apply.ps1`、`rollback.ps1`、`INSTALL.md`——理由见 `MANIFEST.json` 的 `excluded` 数组

### 打包自检摘要（AI 只读核验，2026-10-20）
- 磁盘文件数 = 27（含 MANIFEST.json 自身）；MANIFEST 条目 = 26（不含自身）——一致
- 脱敏 grep（任务 §6.3 的四组模式：机器用户名 / 构建机盘符路径 / T3 实验名 / p16 实验目录，全目录含 MANIFEST 与本文件）= 0 命中
- 三个 .ps1 均为 UTF-8 with BOM（`ef bb bf`）且 PSParser 解析通过（未执行脚本）
- 逐字复制文件 sha256 与源一致（Python 断言 `identicalToSource` 全部通过）
