﻿# uninstall.ps1 —— 反向删除「裁员广进(token-lean) + 只读子代理(scout)」两段 preset
#
# 用法：
#   powershell -ExecutionPolicy Bypass -File .\uninstall.ps1 -ProfilePatch <cordis.patch.yml> [-KeepBackup] [-PurgeBackups]
#
# 0.3.0 改造：
#   G2 原子与可中断：进入写操作前创建 <patch>.lock（FileShare.None，已占用则 exit 3）；
#                     先写 <patch>.tmp-<pid>，校验通过后 [System.IO.File]::Replace 原子替换。
#   G6 -PurgeBackups：额外删除本包自己创建的 *.bak-*-release 与 *.bak-*-uninstall（默认不删）。
# 0.2.0-fix1 修复（F5）：
#   * 写回按原文件字节形态恢复（BOM / 行尾 CRLF|LF / 末尾换行），不再整文件转 CRLF、不再吃 BOM；
#   * 删除两段 preset 的同时回收安装时多加的空行（项前 1 个 + 项后 1 个）；
#   * 完成后回读断言：两段消失、且删除行数与预期一致。
# 卸载后需重启 DSH 桌面应用，模式下拉才会消失这两项。

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$ProfilePatch,
    [switch]$KeepBackup,
    [switch]$PurgeBackups
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---- 0.4.0：脚本级结构化失败（最后一行输出一行 JSON） ----
function Emit-Fail {
    param([string]$Stage, [string]$Cause, [string]$Detail, [int]$Code = 1)
    $obj = [ordered]@{ ok = $false; stage = $Stage; cause = $Cause; detail = $Detail }
    [Console]::Out.WriteLine((ConvertTo-Json -InputObject $obj -Compress))
    exit $Code
}

function Get-Md5 { param($p) (Get-FileHash -Algorithm MD5 -LiteralPath $p).Hash }

# ---- F5：字节保真读写（与 install.ps1 同实现） ----
function Read-TextWithLayout {
    param([string]$Path)
    $sr = New-Object System.IO.StreamReader($Path, $true)
    $text = $sr.ReadToEnd()
    $sr.Close()
    $hasBom = $false
    $bytes = [System.IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) { $hasBom = $true }
    $crlfCount = [regex]::Matches($text, "`r`n").Count
    $lfOnlyCount = [regex]::Matches($text, "(?<!`r)`n").Count
    $eolCRLF = ($crlfCount -ge $lfOnlyCount)
    $hadTrailingNewline = $false
    if ($text.EndsWith("`r`n")) { $text = $text.Substring(0, $text.Length - 2); $hadTrailingNewline = $true }
    elseif ($text.EndsWith("`n")) { $text = $text.Substring(0, $text.Length - 1); $hadTrailingNewline = $true }
    $lineArray = $text -split "`r`n|`n"
    return @{ Lines = $lineArray; HasBom = $hasBom; EolCRLF = $eolCRLF; TrailingNewline = $hadTrailingNewline }
}

function Write-TextWithLayout {
    param([string]$Path, [object]$Layout, [string[]]$NewLines)
    $nl = "`r`n"
    if (-not $Layout.EolCRLF) { $nl = "`n" }
    $text = ($NewLines -join $nl)
    if ($Layout.TrailingNewline) { $text += $nl }
    $enc = New-Object System.Text.UTF8Encoding $Layout.HasBom
    [System.IO.File]::WriteAllText($Path, $text, $enc)
}

if (-not (Test-Path -LiteralPath $ProfilePatch)) { Write-Host ('目标文件不存在：' + $ProfilePatch); Emit-Fail -Stage 'uninstall' -Cause 'PRECONDITION' -Detail ('目标文件不存在：' + $ProfilePatch) -Code 2 }

$layout = Read-TextWithLayout -Path $ProfilePatch
$lines = $layout.Lines
$beforeCount = $lines.Count
$beforeMd5 = Get-Md5 $ProfilePatch
Write-Host ('删除前：行数=' + $beforeCount + '  md5=' + $beforeMd5)

# ---- 安装日志（journal）：优先按 install 记录的"到底加了什么"精确逆操作 ----
$journalPath = $ProfilePatch + '.lean-journal.json'
$journal = $null
if (Test-Path -LiteralPath $journalPath) {
    try { $journal = Get-Content -LiteralPath $journalPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch { $journal = $null }
    if ($journal) {
        Write-Host '检测到安装日志，将按日志精确逆操作。'
        # 按日志恢复"装前"的字节布局（末尾换行 / 行尾 / BOM），否则 sha256 无法还原
        $names = $journal.PSObject.Properties.Name
        if ($names -contains 'trailingNewline') { $layout.TrailingNewline = [bool]$journal.trailingNewline }
        if ($names -contains 'eolCRLF')         { $layout.EolCRLF = [bool]$journal.eolCRLF }
        if ($names -contains 'hasBom')          { $layout.HasBom = [bool]$journal.hasBom }
    }
}
$jHas = { param($n) $journal -and ($journal.PSObject.Properties.Name -contains $n) }

# ---- 顶层项切分：顶格 "- " 开头的行是一个项的起点（含 "- insert:" 与两段 preset） ----
$topIdxs = @()
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -match '^- ') { $topIdxs += $i }
}
$ranges = @()
for ($k = 0; $k -lt $topIdxs.Count; $k++) {
    $start = $topIdxs[$k]
    if ($k + 1 -lt $topIdxs.Count) { $end = $topIdxs[$k + 1] } else { $end = $lines.Count }
    $ranges += , @($start, $end)
}

# ---- 找出我们的两段 preset 所在块 ----
# 【2026-10-21 主管修·回退修复】install 把片段插在 `- insert:` 之下（缩进 4），
# 只认顶格 `^- ` 会永远找不到 → 卸载静默跳过。改为按 `- id: preset-xxx` 的实际缩进删到块尾。
$removeRanges = @()
$foundToken = $false; $foundScout = $false
for ($i = 0; $i -lt $lines.Count; $i++) {
    $m = [regex]::Match($lines[$i], '^(\s*)- id: (preset-token-lean|preset-scout)\s*$')
    if (-not $m.Success) { continue }
    $indent = $m.Groups[1].Value.Length
    $end = $lines.Count
    for ($j = $i + 1; $j -lt $lines.Count; $j++) {
        $l = $lines[$j]
        if ($l.Trim() -eq '') { continue }
        $ind = $l.Length - $l.TrimStart().Length
        if ($ind -lt $indent) { $end = $j; break }
        if ($ind -eq $indent -and $l.TrimStart().StartsWith('- ')) { $end = $j; break }
    }
    $removeRanges += , @($i, $end)
    if ($m.Groups[2].Value -eq 'preset-token-lean') { $foundToken = $true } else { $foundScout = $true }
    $i = $end - 1
}
if (-not $foundToken -and -not $foundScout) {
    Write-Host '未发现 preset-token-lean / preset-scout，无需卸载。'
    exit 0
}
if (-not $foundToken -or -not $foundScout) {
    Write-Warning ('只找到其中一段（token-lean=' + $foundToken + ' scout=' + $foundScout + '），仍将删除已找到的段。')
}

# ---- 标记待删行：项范围 + 安装时多加的空行（项前 1 个、项后 1 个） ----
$drop = @{}
foreach ($r in $removeRanges) {
    for ($i = $r[0]; $i -lt $r[1]; $i++) { $drop[$i] = $true }
}
foreach ($r in $removeRanges) {
    if ($r[0] -gt 0 -and $lines[$r[0] - 1] -eq '') { $drop[$r[0] - 1] = $true }
    if ($r[1] -lt $lines.Count -and $lines[$r[1]] -eq '') { $drop[$r[1]] = $true }
}

# ---- 变空的 - insert: 行一并清理 ----
$childCount = @{}
foreach ($r in $ranges) {
    if ($lines[$r[0]] -ne '- insert:') { continue }
    $cnt = 0
    for ($i = $r[0] + 1; $i -lt $r[1]; $i++) { if (-not $drop.ContainsKey($i)) { $cnt++ } }
    $childCount[$r[0]] = $cnt
}
foreach ($k in @($childCount.Keys)) {
    if ($childCount[$k] -eq 0) {
        $drop[$k] = $true
        # 依据安装日志决定是否回收 `- insert:` 前的空行：
        #   addedBlankBeforeInsert=true  → 该空行是 install 加的，必须删；
        #   false                        → 原文自带，必须保留。
        # 无日志时退回启发式（k-1 空且 k-2 非空 → 视为 install 加的）。
        if ($k - 1 -ge 0 -and $lines[$k - 1] -eq '') {
            $dropIt = $null
            if ($journal -and ($journal.PSObject.Properties.Name -contains 'addedBlankBeforeInsert')) {
                $dropIt = [bool]$journal.addedBlankBeforeInsert
            } else {
                if ($k - 2 -lt 0) { $dropIt = $true }
                elseif ($lines[$k - 2] -ne '') { $dropIt = $true }
                else { $dropIt = $false }
            }
            if ($dropIt) { $drop[$k - 1] = $true }
        }
    }
}

$newLines = @()
for ($i = 0; $i -lt $lines.Count; $i++) {
    if (-not $drop.ContainsKey($i)) { $newLines += $lines[$i] }
}
$expectedCount = $beforeCount - $drop.Keys.Count

# ---- G2：加锁（写操作临界区开始） ----
$lockPath = $ProfilePatch + '.lock'
$lockStream = $null
try {
    $lockStream = [System.IO.File]::Open($lockPath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
} catch {
    Write-Host '另一个安装/卸载正在进行（检测到 <patch>.lock 被占用），退出。请确认没有并发运行后重试。'
    Emit-Fail -Stage 'uninstall' -Cause 'LOCKED' -Detail '检测到 <patch>.lock 被占用（并发安装/卸载）' -Code 3
}

$backup = $ProfilePatch + '.bak-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-uninstall'
$tmpPath = $ProfilePatch + '.tmp-' + $pid
try {
    # G2：先写临时文件，校验通过后再原子替换
    Write-TextWithLayout -Path $tmpPath -Layout $layout -NewLines $newLines
    $tLayout = Read-TextWithLayout -Path $tmpPath
    $tT = $false; $tS = $false
    foreach ($l in $tLayout.Lines) {
        if ($l -match '^\s*- id: preset-token-lean\s*$') { $tT = $true }
        if ($l -match '^\s*- id: preset-scout\s*$')      { $tS = $true }
    }
    if ($tT -or $tS) {
        throw '原子写临时文件校验失败：两段 preset 仍残留在临时文件中'
    }
    # 原子替换：tmp → patch，原 patch 存入 backup
    [System.IO.File]::Replace($tmpPath, $ProfilePatch, $backup)
    Write-Host ('已删除两段 preset（原子替换）；原文件备份至：' + $backup)
} catch {
    Write-Host '卸载过程抛出异常，已回滚……'
    if (Test-Path -LiteralPath $backup) {
        Copy-Item -LiteralPath $backup -Destination $ProfilePatch -Force
        Write-Host ('回滚后 md5 = ' + (Get-Md5 $ProfilePatch))
    } else {
        Write-Host '（无备份可回滚，目标文件应未被改动）'
    }
    Emit-Fail -Stage 'uninstall' -Cause 'PRECONDITION' -Detail ('卸载异常：' + $_.Exception.Message) -Code 1
} finally {
    if ($lockStream) { try { $lockStream.Close() } catch {} ; Remove-Item -LiteralPath $lockPath -Force -ErrorAction SilentlyContinue }
    if (Test-Path -LiteralPath $tmpPath) { Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue }
}

$afterLayout = Read-TextWithLayout -Path $ProfilePatch
$afterCount = $afterLayout.Lines.Count
$afterMd5 = Get-Md5 $ProfilePatch
Write-Host ('删除后：行数=' + $afterCount + '  md5=' + $afterMd5)

# ---- 回读断言 ----
$t = $false; $s = $false
foreach ($l in $afterLayout.Lines) {
    if ($l -match '^\s*- id: preset-token-lean\s*$') { $t = $true }
    if ($l -match '^\s*- id: preset-scout\s*$')      { $s = $true }
}
if ($t -or $s) {
    Write-Warning '回读失败：两段 preset 仍未删净，自动回滚……'
    Copy-Item -LiteralPath $backup -Destination $ProfilePatch -Force
    Write-Host ('回滚后 md5 = ' + (Get-Md5 $ProfilePatch))
    Emit-Fail -Stage 'uninstall' -Cause 'PRECONDITION' -Detail '回读失败：两段 preset 仍未删净，已回滚' -Code 1
}
Write-Host '回读断言 1/2 通过：两段 preset 已全部消失。'
if ($afterCount -ne $expectedCount) {
    Write-Warning ('回读断言 2/2 未通过：行数 ' + $afterCount + ' 与预期 ' + $expectedCount + ' 不一致（不影响 preset 已删净的结论，请人工核对周边空行）。')
} else {
    Write-Host ('回读断言 2/2 通过：行数 = 删前行数 - 删除行数（' + $beforeCount + ' - ' + $drop.Keys.Count + ' = ' + $expectedCount + '）。')
}

# ---- 备份处理 ----
# 【2026-10-21 主管修】按安装日志校验"字节级还原"，并删除日志本身（它也是 install 创建的文件）。
if ($journal -and ($journal.PSObject.Properties.Name -contains 'originalSha256')) {
    $nowSha = (Get-FileHash -Algorithm SHA256 -LiteralPath $ProfilePatch).Hash
    $restored = ($nowSha -eq [string]$journal.originalSha256)
    Write-Host ('字节级还原（对安装前 sha256）：' + $restored)
    if (-not $restored) { Write-Warning '还原后 sha256 与安装前不一致，请用安装前备份人工核对。' }
}
if (Test-Path -LiteralPath $journalPath) {
    Remove-Item -LiteralPath $journalPath -Force -ErrorAction SilentlyContinue
    Write-Host '安装日志已删除。'
}

if ($KeepBackup) {
    Write-Host ('临时备份已保留：' + $backup)
} else {
    Remove-Item -LiteralPath $backup -Force -Confirm:$false
    Write-Host '临时备份已清理（如需保留请加 -KeepBackup 重跑）。'
}

# ---- G6：-PurgeBackups 额外清理历史备份 ----
if ($PurgeBackups) {
    $dir = Split-Path -Parent $ProfilePatch
    $gone = @()
    foreach ($pat in @('*.bak-*-release', '*.bak-*-uninstall')) {
        foreach ($b in @(Get-ChildItem -LiteralPath $dir -Filter $pat -File -ErrorAction SilentlyContinue)) {
            Remove-Item -LiteralPath $b.FullName -Force -Confirm:$false -ErrorAction SilentlyContinue
            $gone += $b.Name
        }
    }
    if ($gone.Count -gt 0) { Write-Host ('-PurgeBackups：已清理历史备份 ' + $gone.Count + ' 个：' + ($gone -join ', ')) }
    else { Write-Host '-PurgeBackups：未发现本包历史备份。' }
}

Write-Host '卸载完成。【必须重启 DSH 桌面应用】后：模式下拉不再出现「裁员广进」与「· 只读子代理（内部，勿直接对话）」。'
exit 0
