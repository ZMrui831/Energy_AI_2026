# 兼容性矩阵（COMPATIBILITY）

本包的权威键表与预检逻辑按 **运行时版本** 采集；不同运行时必须用对应版本的键表（`vendor/keys/<version>.json`），
**不得跨版本复用**。键表缺失且未加 `-AllowUnknownRuntime` 时，安装会被拒绝。

| DSH 版本            | 键表文件                          | 是否支持 | 验证日期   | 备注                                                        |
|---------------------|-----------------------------------|----------|------------|-------------------------------------------------------------|
| 0.2.1-rc.2          | `vendor/keys/0.2.1-rc.2.json`     | 是       | 2026-10-21 | 当前唯一随包键表；CURATED 键表/类型/必填按此版本采集；版本来源：`<DSH安装目录>\resources\runtime\primary-runtime\runtime.json` 的 `desktopVersion` |
| 其他版本            | （暂无）                          | 否       | —          | 需按 0.2.1-rc.2 同法重新采集键表并放入 `vendor/keys/` 后支持 |

## 已实测环境（零假设 node 探测）

| 系统 / PS / DSH / Electron / 是否有 node | 结果 | 日期 | 说明 |
|---|---|---|---|
| Win11 / PS 5.1.26100 / DSH 0.2.1-rc.2 / Electron 44.7.0 / 干净机器（**无 node**） | 通过 | 2026-10-21 | 第三方同学机实测：加 `-DshHome` 后 `Resolve-NodeExe` 命中 `DeepSeek Harness.exe`（Electron 主程序当 node，自动 `ELECTRON_RUN_AS_NODE=1`），DryRun / 安装 / verify / 卸载全部通过；字节级还原、并发安全均 OK |

## 如何新增一个运行时版本的支持

1. 用该运行时的桌面/非桌面 profile 导出权威键表（插件键名、类型、必填、已删键）。
2. 写入 `vendor/keys/<version>.json`，结构同 `0.2.1-rc.2.json`：`{ runtime, plugins, required, types, deprecated }`。
3. 用 `tools/selftest.ps1` 与本包 `fixtures/` 复测（必要时更新 fixture 或键表）。
4. 在上方表格补一行，并更新 `MANIFEST.json` 的 `targetRuntime`。

## 版本探测顺序（install.ps1 → schema-preflight.cjs）

1. 显式 `-RuntimeVersion <v>`（最高优先，不变）；
2. 否则 `-DshHome <DSH安装目录>` 按以下顺序探测 **DSH 运行时版本**（命中即返回，记录 source 与逐候选结果）：
   - `<DSH安装目录>\resources\runtime\primary-runtime\runtime.json` 的 `desktopVersion`（该字段缺失时退到同文件 `version` / `runtimeVersion`）；
   - `<DSH安装目录>\resources\runtime\package.json` 的 `version`；
   - `<DSH安装目录>\resources\runtime\node_modules\@deepseek-ai\dsh\package.json` 的 `version`；
3. **根目录 `<DSH安装目录>\version` 是 Electron 版本（形状同为 `x.y.z`），绝不参与 DSH 版本判定**；仅在 `--print-version` 的 `evidence.electronVersionGuess` 中作参考输出；
4. 都不存在 → 返回 `unknown`，拒绝安装并提示加 `-AllowUnknownRuntime`（显式逃生，会打印警告并以内置默认键表 0.2.1-rc.2 兜底）。

## 已知不跨版本项

- `persona` / `toolFilter` / `backgroundMode` / `enableRunInBackground` 在 0.2.1-rc.2 已被删除，出现即判 `DEPRECATED_KEY`。
- 预设层插件的 config schema 无法从 CLI 导出，工具对这部分靠内置权威键表兜底（见 `schema-preflight.cjs`）。
