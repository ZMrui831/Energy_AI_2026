# 80 · 私人 agent 省钱契约（非 DSH 自建 agent 版）

> 读者：**自建 agent** 的开发者（不依赖 DSH 运行时）。本文把「裁员广进」在 DSH 0.2.1-rc.2 上验证过的省钱手法，抽象成 **6 条可移植规则 + 8 栈映射 + 3 条验证指标 + 不适用边界**。所有"省了多少"的数字都要你在自己栈上实测，本文只给口径与挂载点，运行时效果标【待主管执行】。

## 一、六条可移植规则

**① 工具表裁剪（按任务类保留最小集）**
把"全量工具表"按任务类拆成 2–3 个小集合（读 / 写 / 执行 / 检索），按 `task_class` 只注入当前需要的最小集。理由：每个工具的 `name + description + 参数 schema` 都进系统提示，是**每轮固定前缀成本**；工具越多模型越易误选、越易把无关 schema 也计费。落地：启动时按任务选 `tool subset`；长尾工具用 feature flag 默认关。

**② 单次输出封顶 + 分页契约**
任何"返回可能很大"的工具（读文件、抓网页、跑命令）都要有单次字节/行/字符上限；超限时**不要把整块塞进上下文**，而返回"前缀 + 明确续读游标"（`offset` / `cursor` / `next_page`），并在系统提示里写死：出现 `Output capped` / `Use offset=N to continue.` 时**必须用游标续读直到覆盖所需区间，引用被截断区域要注明游标范围**。理由：封顶把"不可控大块"变成"可控分页"，分页契约防止模型编造未读内容。落地：工具返回 `{content, truncated:true, cursor:{offset:N}}`；提示里写明续读硬规则。

**③ 上下文压缩阈值**
设占用比阈值（如 0.8）+ headroom（如 4096 tokens），**超过才**触发压缩；压缩保留"头部 system + 最近若干轮 + 锚点摘要"，中间历史摘要化。理由：压缩是兜底不是常态——阈值太早会频繁丢信息、太晚会 OOM/爆费。落地：token 计数用 provider 的 usage 或本地估算；`thresholdRatio=0.8 / headroomTokens=4096 / retainRatio=0.2` 是可用起点。

**④ 子代理隔离（只读 / 预算 / 深度=1）**
把"探索型"任务丢给子代理：**只读工具集** + **工具调用次数预算** + **禁止再起子代理（maxDepth=1）** + **一次性前台返回蒸馏结果**。理由：探索的中间过程消耗发生在**另一个上下文窗口**，主循环只收蒸馏结论，避免长历史全量压在主循环（那样反而更贵）。落地：`subagent(tools=readonly, budget=20, max_depth=1, return=distilled)`。

**⑤ 固定前缀最小化（不重复复述默认值）**
系统提示、工具默认值、模型默认参数**不要每轮/每个 preset 重述**，只写"与默认不同的必要覆盖"。理由：固定前缀每轮都计费，且重述会破坏 provider 的前缀缓存（prompt caching）；重述默认值还会把上游未来的默认改进钉死在旧值。落地：prefix 只放不可变身份 + 硬规则；配置只写覆盖键。

**⑥ 成本遥测（每轮 input / output / cache）**
每轮记录 `input_tokens` / `output_tokens` / `cache_read` / `cache_write`、工具调用数、耗时；按会话与任务聚合落盘（JSONL）。理由：没有度量就没有优化，能定位"哪一步在烧 token"。落地：调用后读 `usage` 字段落盘；对齐第三节三条指标。

## 二、8 栈映射（挂载点 + 伪代码 + 该栈特有的坑）

### 1. OpenAI（Chat Completions / Responses）
挂载点：`tools=[...]` 裁剪、`max_tokens`/`max_output_tokens` 封顶、prompt caching（前缀稳定才命中）。
```
tools = pick_tools(task_class)                 # 只传最小集
r = client.chat.completions.create(model=m, messages=msgs, tools=tools, max_tokens=2048)
if r.choices[0].finish_reason == 'length':     # length = 被截断，不是完成
    msgs.append(cursor_msg)
log_usage(r.usage)                             # input / output / cached
```
坑：工具 schema 越多、前缀越长，prompt cache 越难命中；`finish_reason=length` 必须当"续读"处理，别当正常结束。

### 2. Anthropic（Messages）
挂载点：`tools`、`max_tokens`、`system`（前缀缓存用 `cache_control`）、`stop_reason`。
```
system = [{"type":"text","text":PREFIX,"cache_control":{"type":"ephemeral"}}]
r = client.messages.create(model=m, system=system, tools=tools, max_tokens=2048, messages=msgs)
if r.stop_reason == 'max_tokens':
    msgs.append(cursor_msg)
log(r.usage.input_tokens, r.usage.output_tokens, r.usage.cache_read_input_tokens)
```
坑：`cache_control` 要放在**稳定前缀的末尾**；`stop_reason=max_tokens` 表示输出被截，不是正常结束。

### 3. LangChain
挂载点：`bind_tools([...])` 裁剪、`trim_messages` 窗口、`RunnableWithMessageHistory`。
```
llm = ChatX(...).bind_tools(pick_tools(task_class))
hist = trim_messages(history, max_tokens=K, strategy='last', token_counter=count)
ai = llm.invoke([system_msg] + hist + [human])
if ai.response_metadata.get('finish_reason') == 'length':
    follow_cursor()
```
坑：默认 `trim_messages` 可能把 system 也裁掉（要 `include_system`）；`bind_tools` 每轮重发 schema，注意前缀稳定。

### 4. LangGraph
挂载点：state 只放蒸馏结果、`recursion_limit`、子图做隔离、checkpoint。
```
g = StateGraph(S)
g.add_node('plan', plan); g.add_node('explore', explore_subgraph)
g.add_edge('plan','explore'); g.add_edge('explore', END)
app = g.compile(checkpointer=mem)
app.invoke(init, config={'recursion_limit': 12})
```
坑：state 若把**全量探索历史**写进去，等同于没隔离；`recursion_limit` 是深度刹车，别设太大。

### 5. MCP（Model Context Protocol）
挂载点：server 只暴露必要 tools、client 按 session 选择 server、tool 结果封顶。
```
client = MCPClient(['fs-readonly','web-readonly'])   # 只连只读 server
tools = client.list_tools()                          # 裁剪后再交给模型
res = client.call_tool('read', {'path':p, 'limit':2000})
if res.get('truncated'): follow_cursor(res['cursor'])
```
坑：每个 server 的全部 tool 都会进上下文，**连太多 server = 工具表爆炸**；tool 结果默认可能无上限。

### 6. vLLM / Ollama（本地推理）
挂载点：`max_tokens`、`stop`、KV cache 复用（`--enable-prefix-caching`）、并发批。
```
r = client.generate(model=m, prompt=prefix+turn, max_tokens=2048, stop=['</s>'])
if r['finish_reason'] == 'length':
    follow_cursor()
# 服务端开 prefix caching：前缀逐字稳定才复用 KV
```
坑：本地模型没有云端 `usage` 字段，token 要自己数；prefix caching 要求前缀逐字稳定（任何动态内容进前缀都会失效）。

### 7. n8n（低代码编排）
挂载点：AI Agent 节点的 tool 子节点只挂必要项、`max iterations`、Memory 节点设窗口。
```
Agent(tools=[ReadFile, WebFetch], maxIterations=8)
Memory(window=10)
IF(truncated) -> Set(offset) -> loop back to ReadFile
```
坑：可视化节点很容易"全挂"导致工具表很大；循环节点没有刹车会跑飞，务必设 `maxIterations`。

### 8. 自建 ReAct
挂载点：自实现 tool registry 裁剪、observation 封顶、scratchpad 压缩、step 预算。
```
tools = registry.smallest_for(task_class)
for step in range(MAX_STEPS):
    act = llm(prefix, scratchpad, tools)
    if act.done: break
    obs = truncate(tools.run(act), cap=4096)     # observation 封顶
    scratchpad.append(act, obs)
    if tokens(scratchpad) > THRESH: scratchpad = compress(scratchpad)
```
坑：**scratchpad 无界增长是最大烧钱点**；observation 不封顶会一次吃满上下文。

## 三、三条验证指标

1. **token 下降幅度** = `(基线 input+output − 优化后 input+output) / 基线`。同题同模型对照，建议一次只改一条规则，目标 ≥ 30%（以实测为准）。
2. **截断区正确率** = 在"需要中段内容"的题上，逐行/逐字段正确的比例。配合分页契约应接近 100%；低于基线说明"续读契约"没落地好。
3. **未授权工具调用数** = 越权次数（只读子代理调写工具/执行命令、越权访问未授权路径），**必须恒为 0**。>0 即视为接线错误，优先修复。

## 四、不适用（诚实边界）

- **需要精读大文件中段、且无法分页**（如要求整体结构推理、跨段引用极密）：分页续读会多次往返，反而更慢更贵——应改为"本地预处理 / 切片索引 / 预摘要"，不要硬套本契约。
- **需要多级子代理编排**（子代理再分子代理、树状分解）：`maxDepth=1` 的隔离契约不适用，需要另一套预算分配与死循环防护（本契约只覆盖单层隔离）。

> 一句话：这套契约的目标是"**把不可控的大块变成可控的分页，把探索挪到另一个窗口，把固定前缀压到最小**"。它不承诺"更聪明"，只承诺"同样的活更便宜、更可预期"。
