﻿# install.ps1 —— 安装「裁员广进(token-lean) + 只读子代理(scout)」两段 preset
#
# 用法：
#   powershell -ExecutionPolicy Bypass -File .\install.ps1 -ProfilePatch <cordis.patch.yml> `
#     [-SchemaPath <schema.json>] [-RuntimeVersion <v>] [-DshHome <DSH安装目录>] `
#     [-NodeExe <node>] [-AllowUnknownRuntime] [-DryRun]
#
# 0.3.0 改造：
#   G1 零假设安装 v2：默认 -NodeExe='' → 按 DSH_DESKTOP_NODE_EXECUTABLE → -DshHome 内 5 候选（含 DeepSeek Harness.exe 电子回退）→ PATH node；
#                     每个候选用 --version 实测可用性（超时 10s）；电子主程序须 ELECTRON_RUN_AS_NODE=1；全失败报错给可复制命令。
#   G2 原子与可中断：进入写操作前创建 <patch>.lock（FileShare.None，已占用则 exit 3）；
#                     先写 <patch>.tmp-<pid>，校验通过后 [System.IO.File]::Replace 原子替换；
#                     try/catch/finally 覆盖「版本预检→写入→校验→判定」，异常即回滚。
#   G4 版本契约：写盘前用 schema-preflight.cjs --version-check 预检；不支持/未知版本且未授权则 exit 1 拒绝。
#   （F1/F2/F4/F5/F6：末尾 insert 不越界、崩溃回滚、DryRun 零写入、字节保真、版本护栏可选 等已保留。）
# 本脚本不含任何构建机绝对路径。

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$ProfilePatch,
    [string]$SchemaPath = '',
    [string]$RuntimeVersion = '',
    [string]$DshHome = '',
    [string]$NodeExe = '',
    [switch]$AllowUnknownRuntime,
    [switch]$DryRun
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---- 0.4.0：脚本级结构化失败（最后一行输出一行 JSON；人类可读信息仍用 Write-Host 打印） ----
# 枚举：现有 10 类 finding cause + LOCKED / NODE_NOT_FOUND / PRECONDITION（另加本脚本专属）。
function Emit-Fail {
    param([string]$Stage, [string]$Cause, [string]$Detail, [int]$Code = 1)
    $obj = [ordered]@{ ok = $false; stage = $Stage; cause = $Cause; detail = $Detail }
    $json = ConvertTo-Json -InputObject $obj -Compress
    [Console]::Out.WriteLine($json)
    exit $Code
}

$FragToken = Join-Path $PSScriptRoot 'presets\token-lean.yml'
$FragScout = Join-Path $PSScriptRoot 'presets\scout.yml'
$Tool = Join-Path $PSScriptRoot 'tools\schema-preflight.cjs'

function Get-Md5 { param($p) (Get-FileHash -Algorithm MD5 -LiteralPath $p).Hash }

# ---- G1：零假设定位 node v2（去掉对 PATH 里 node 的隐式依赖；含 Electron 主程序回退） ----
# 候选顺序：① -NodeExe（显式；不可用即报错，不静默跳候选） ② $env:DSH_DESKTOP_NODE_EXECUTABLE
# ③ -DshHome 下 5 候选（含 <DshHome>\DeepSeek Harness.exe） ④ DshHome 根任意 DeepSeek*Harness*.exe
# ⑤ PATH node。每个命中候选都用 `--version` 实测可用性（超时 10s）；Electron 候选须带 ELECTRON_RUN_AS_NODE=1。
function Test-NodeCandidate {
    param([string]$Path, [bool]$IsElectron, [string]$Source)
    $exists = Test-Path -LiteralPath $Path -PathType Leaf
    if (-not $exists) {
        return [PSCustomObject]@{
            Usable = $false; Reason = '不存在'; Result = $null
            Tried  = @([PSCustomObject]@{ path = $Path; source = $Source; exists = $false; usable = $false; reason = '不存在'; version = $null })
        }
    }
    $prev = $env:ELECTRON_RUN_AS_NODE
    if ($IsElectron) { $env:ELECTRON_RUN_AS_NODE = '1' }
    $ok = $false; $reason = ''; $ver = $null
    try {
        $tmpOut = [System.IO.Path]::GetTempFileName()
        $tmpErr = [System.IO.Path]::GetTempFileName()
        try {
            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName = $Path
            $psi.Arguments = '--version'
            $psi.UseShellExecute = $false
            $psi.RedirectStandardOutput = $true
            $psi.RedirectStandardError = $true
            $psi.CreateNoWindow = $true
            $proc = New-Object System.Diagnostics.Process
            $proc.StartInfo = $psi
            if (-not $proc.Start()) { throw '无法启动进程' }
            if (-not $proc.WaitForExit(10000)) {
                try { $proc.Kill() } catch {}
                $reason = '超时(>10s)'
            } else {
                $so = $proc.StandardOutput.ReadToEnd().Trim()
                $se = $proc.StandardError.ReadToEnd().Trim()
                if ($proc.ExitCode -eq 0 -and ($so -match '^v\d+\.')) {
                    $ok = $true; $ver = $so
                } else {
                    $reason = "exit=$($proc.ExitCode); stdout='$so'; stderr='$se'"
                }
            }
        } finally {
            Remove-Item -LiteralPath $tmpOut -Force -ErrorAction SilentlyContinue
            Remove-Item -LiteralPath $tmpErr -Force -ErrorAction SilentlyContinue
        }
    } catch {
        $reason = ('异常: ' + $_.Exception.Message)
    } finally {
        if ($IsElectron) {
            if ($null -eq $prev) { Remove-Item env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue }
            else { $env:ELECTRON_RUN_AS_NODE = $prev }
        }
    }
    return [PSCustomObject]@{
        Usable = $ok; Reason = $reason
        Result = [PSCustomObject]@{ Path = $Path; Source = $Source; Version = $ver; IsElectron = $IsElectron; Tried = $null; Failed = $false }
        Tried  = @([PSCustomObject]@{ path = $Path; source = $Source; exists = $true; usable = $ok; reason = $reason; version = $ver })
    }
}

function Resolve-NodeExe {
    param([string]$Explicit, [string]$DshHome)
    $tried = @()
    # ① 显式 -NodeExe：给了就必须可用，不可用 → 直接报错（不静默跳到其它候选）
    if ($Explicit -ne '') {
        if (-not (Test-Path -LiteralPath $Explicit -PathType Leaf)) {
            Write-Host ('指定的 -NodeExe 不存在：' + $Explicit)
            Emit-Fail -Stage 'install' -Cause 'NODE_NOT_FOUND' -Detail ('指定的 -NodeExe 不存在：' + $Explicit) -Code 2
        }
        $r = Test-NodeCandidate -Path $Explicit -IsElectron ($Explicit -match 'DeepSeek.*Harness.*\.exe') -Source '-NodeExe'
        $tried += $r.Tried
        if (-not $r.Usable) {
            Write-Host ('指定的 -NodeExe 不可用（无法作为 node 运行）：' + $Explicit)
            Write-Host ('  失败原因：' + $r.Reason)
            Emit-Fail -Stage 'install' -Cause 'NODE_NOT_FOUND' -Detail ('指定的 -NodeExe 不可用：' + $Explicit + '；原因：' + $r.Reason) -Code 2
        }
        $r.Result.Tried = $tried
        return $r.Result
    }
    # ② 环境变量
    if ($env:DSH_DESKTOP_NODE_EXECUTABLE -and (Test-Path -LiteralPath $env:DSH_DESKTOP_NODE_EXECUTABLE -PathType Leaf)) {
        $r = Test-NodeCandidate -Path $env:DSH_DESKTOP_NODE_EXECUTABLE -IsElectron ($env:DSH_DESKTOP_NODE_EXECUTABLE -match 'DeepSeek.*Harness.*\.exe') -Source '$env:DSH_DESKTOP_NODE_EXECUTABLE'
        $tried += $r.Tried
        if ($r.Usable) { $r.Result.Tried = $tried; return $r.Result }
    }
    # ③ -DshHome 下候选（含 Electron 主程序回退）
    if ($DshHome -ne '') {
        $base = $DshHome.TrimEnd('\').TrimEnd('/')
        $cands = @(
            [PSCustomObject]@{ Path = "$base\resources\runtime\bin\node.exe"; IsElectron = $false; Source = 'DshHome:resources/runtime/bin/node.exe' },
            [PSCustomObject]@{ Path = "$base\resources\runtime\primary-runtime\dependencies\node\node.exe"; IsElectron = $false; Source = 'DshHome:primary-runtime/.../node.exe' },
            [PSCustomObject]@{ Path = "$base\resources\runtime\primary-runtime\dependencies\node\bin\node.exe"; IsElectron = $false; Source = 'DshHome:primary-runtime/.../bin/node.exe' },
            [PSCustomObject]@{ Path = "$base\resources\runtime\node.exe"; IsElectron = $false; Source = 'DshHome:resources/runtime/node.exe' },
            [PSCustomObject]@{ Path = "$base\DeepSeek Harness.exe"; IsElectron = $true; Source = 'DshHome:DeepSeek Harness.exe' }
        )
        if (Test-Path -LiteralPath $base -PathType Container) {
            Get-ChildItem -LiteralPath $base -Filter 'DeepSeek*Harness*.exe' -File -ErrorAction SilentlyContinue | ForEach-Object {
                if ($_.FullName -ne "$base\DeepSeek Harness.exe") {
                    $cands += [PSCustomObject]@{ Path = $_.FullName; IsElectron = $true; Source = 'DshHome:root/DeepSeek*Harness*.exe' }
                }
            }
        }
        foreach ($c in $cands) {
            $r = Test-NodeCandidate -Path $c.Path -IsElectron $c.IsElectron -Source $c.Source
            $tried += $r.Tried
            if ($r.Usable) { $r.Result.Tried = $tried; return $r.Result }
        }
    }
    # ⑤ PATH node
    $pn = Get-Command node -ErrorAction SilentlyContinue
    if ($pn) {
        $r = Test-NodeCandidate -Path $pn.Source -IsElectron ($pn.Source -match 'DeepSeek.*Harness.*\.exe') -Source 'PATH:node'
        $tried += $r.Tried
        if ($r.Usable) { $r.Result.Tried = $tried; return $r.Result }
    }
    return [PSCustomObject]@{ Path = $null; Source = $null; Version = $null; IsElectron = $false; Failed = $true; Tried = $tried }
}

$script:NodeIsElectron = $false
$resolved = Resolve-NodeExe -Explicit $NodeExe -DshHome $DshHome
if ($resolved.Failed) {
    Write-Host '探测 node 全部失败。逐条候选与原因：'
    foreach ($t in $resolved.Tried) {
        $st = if ($t.usable) { 'OK' } elseif ($t.exists) { '存在但不可用' } else { '不存在' }
        Write-Host ('  候选 ' + $t.source + ' -> ' + $t.path + ' [' + $st + ']' + $(if ($t.reason) { '  原因: ' + $t.reason }))
    }
    Write-Host @'
可复制命令（任选其一）：
  powershell -ExecutionPolicy Bypass -File .\install.ps1 -ProfilePatch <patch> -DshHome "<DSH安装目录>"
  powershell -ExecutionPolicy Bypass -File .\install.ps1 -ProfilePatch <patch> -NodeExe "<DSH安装目录>\DeepSeek Harness.exe"
若用 Electron 主程序当 node，脚本会自动设置 ELECTRON_RUN_AS_NODE=1。
'@
    Emit-Fail -Stage 'install' -Cause 'NODE_NOT_FOUND' -Detail '探测 node 全部失败（详见上方逐条候选）' -Code 2
}
$NodeExe = $resolved.Path
$script:NodeIsElectron = $resolved.IsElectron
Write-Host ('node 解析：' + $resolved.Path + '（来源：' + $resolved.Source + '）')
if ($resolved.IsElectron) { Write-Host '（Electron 主程序当 node：后续调用自动设置 ELECTRON_RUN_AS_NODE=1）' }

# ---- F5：字节保真读写（BOM / 行尾 / 末尾换行） ----
function Read-TextWithLayout {
    param([string]$Path)
    $sr = New-Object System.IO.StreamReader($Path, $true)
    $text = $sr.ReadToEnd()
    $sr.Close()
    $hasBom = $false
    $bytes = [System.IO.File]::ReadAllBytes($Path)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) { $hasBom = $true }
    $crlfCount = [regex]::Matches($text, "`r`n").Count
    $lfOnlyCount = [regex]::Matches($text, "(?<!`r)`n").Count
    $eolCRLF = ($crlfCount -ge $lfOnlyCount)
    $hadTrailingNewline = $false
    if ($text.EndsWith("`r`n")) { $text = $text.Substring(0, $text.Length - 2); $hadTrailingNewline = $true }
    elseif ($text.EndsWith("`n")) { $text = $text.Substring(0, $text.Length - 1); $hadTrailingNewline = $true }
    $lineArray = $text -split "`r`n|`n"
    return @{ Lines = $lineArray; HasBom = $hasBom; EolCRLF = $eolCRLF; TrailingNewline = $hadTrailingNewline }
}

function Write-TextWithLayout {
    param([string]$Path, [object]$Layout, [string[]]$NewLines)
    $nl = "`r`n"
    if (-not $Layout.EolCRLF) { $nl = "`n" }
    $text = ($NewLines -join $nl)
    if ($Layout.TrailingNewline) { $text += $nl }
    $enc = New-Object System.Text.UTF8Encoding $Layout.HasBom
    [System.IO.File]::WriteAllText($Path, $text, $enc)
}

# ---- F2：捕获式调用 node（native stderr 不再触发 Stop；临时文件重定向） ----
# 若解析到的是 Electron 主程序（IsElectron），调用前设置 ELECTRON_RUN_AS_NODE=1，调用后恢复原值。
function Invoke-NodeCapture {
    param([string]$NodeExe, [string[]]$NodeArgs)
    $tmpOut = [System.IO.Path]::GetTempFileName()
    $tmpErr = [System.IO.Path]::GetTempFileName()
    $prev = $env:ELECTRON_RUN_AS_NODE
    if ($script:NodeIsElectron) { $env:ELECTRON_RUN_AS_NODE = '1' }
    try {
        $argStr = ($NodeArgs | ForEach-Object { '"' + ($_ -replace '"', '') + '"' }) -join ' '
        $p = Start-Process -FilePath $NodeExe -ArgumentList $argStr -Wait -PassThru -NoNewWindow -RedirectStandardOutput $tmpOut -RedirectStandardError $tmpErr
        $so = [System.IO.File]::ReadAllText($tmpOut)
        $se = [System.IO.File]::ReadAllText($tmpErr)
        return @{ ExitCode = $p.ExitCode; Stdout = $so; Stderr = $se }
    } finally {
        if ($script:NodeIsElectron) {
            if ($null -eq $prev) { Remove-Item env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue }
            else { $env:ELECTRON_RUN_AS_NODE = $prev }
        }
        Remove-Item -LiteralPath $tmpOut -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $tmpErr -Force -ErrorAction SilentlyContinue
    }
}

# ---- 前置检查 ----
if (-not (Test-Path -LiteralPath $ProfilePatch)) { Write-Host ('目标文件不存在：' + $ProfilePatch); Emit-Fail -Stage 'install' -Cause 'PRECONDITION' -Detail ('目标文件不存在：' + $ProfilePatch) -Code 2 }
if (-not (Test-Path -LiteralPath $FragToken))   { Write-Host ('片段缺失：' + $FragToken); Emit-Fail -Stage 'install' -Cause 'PRECONDITION' -Detail ('片段缺失：' + $FragToken) -Code 2 }
if (-not (Test-Path -LiteralPath $FragScout))   { Write-Host ('片段缺失：' + $FragScout); Emit-Fail -Stage 'install' -Cause 'PRECONDITION' -Detail ('片段缺失：' + $FragScout) -Code 2 }
if (-not (Test-Path -LiteralPath $Tool))        { Write-Host ('校验工具缺失：' + $Tool); Emit-Fail -Stage 'install' -Cause 'PRECONDITION' -Detail ('校验工具缺失：' + $Tool) -Code 2 }

# ---- 读取（字节保真） ----
$layout = Read-TextWithLayout -Path $ProfilePatch
$lines = $layout.Lines

# ---- 幂等检查 ----
$tokenPresent = $false; $scoutPresent = $false
foreach ($l in $lines) {
    if ($l -match '^\s*- id: preset-token-lean\s*$') { $tokenPresent = $true }
    if ($l -match '^\s*- id: preset-scout\s*$')      { $scoutPresent = $true }
}
if ($tokenPresent -and $scoutPresent) {
    Write-Host '已安装，跳过（幂等）：检测到 preset-token-lean 与 preset-scout 均已存在。'
    exit 0
}

# ---- F2.3：半装态守卫（在写入任何东西之前拒绝） ----
if ($tokenPresent -or $scoutPresent) {
    Write-Host '检测到半装状态，请先运行 uninstall.ps1 再安装'
    Write-Host ('（preset-token-lean=' + $tokenPresent + ' preset-scout=' + $scoutPresent + '）')
    Emit-Fail -Stage 'install' -Cause 'PRECONDITION' -Detail ('检测到半装状态（token-lean=' + $tokenPresent + ' scout=' + $scoutPresent + '）') -Code 1
}

# ---- 锚点：≥1 取最后一个 - insert:；0 个则在文件末尾新建 ----
$anchorIdxs = @()
for ($i = 0; $i -lt $lines.Count; $i++) {
    if ($lines[$i] -eq '- insert:') { $anchorIdxs += $i }
}
if ($anchorIdxs.Count -ge 1) {
    $anchorIdx = $anchorIdxs[$anchorIdxs.Count - 1]
    Write-Host ('锚点 - insert: 命中 ' + $anchorIdxs.Count + ' 次，取最后一个（行 ' + ($anchorIdx + 1) + '）')
} else {
    $anchorIdx = -1
    Write-Host '未发现 - insert: 块 → 将在文件末尾新建一个 insert 块'
}

# ---- 构造插入片段（剥离片段文件头注释，保留正文） ----
function Get-FragmentBody {
    param($path)
    $out = @(); $inBody = $false
    foreach ($l in [System.IO.File]::ReadAllLines($path)) {
        if (-not $inBody) {
            if ($l -match '^\s*- id: preset-(token-lean|scout)\s*$') { $inBody = $true } else { continue }
        }
        if ($inBody) { $out += $l }
    }
    return $out
}
$frag = @()
$frag += Get-FragmentBody $FragToken
$frag += Get-FragmentBody $FragScout

# ---- 缩进对齐：把片段基准缩进调整为目标 insert 块的子项缩进 ----
# 【2026-10-21 主管修】片段固定 4 空格，但目标 patch 的 insert 子项常见是 2 空格；
# 直接追加会拼出非法 YAML（bad indentation of a sequence entry），导致校验失败并回滚。
$childIndent = 2
if ($anchorIdx -ge 0) {
    for ($i = $anchorIdx + 1; $i -lt $lines.Count; $i++) {
        $l = $lines[$i]
        if ($l.Trim() -eq '') { continue }
        if ($l -match '^- ') { break }
        $childIndent = $l.Length - $l.TrimStart().Length
        break
    }
}
$fragBase = 0
foreach ($l in $frag) { if ($l.Trim() -ne '') { $fragBase = $l.Length - $l.TrimStart().Length; break } }
$delta = $childIndent - $fragBase
$fragIndented = @()
foreach ($l in $frag) {
    if ($l.Trim() -eq '') { $fragIndented += ''; continue }
    $ni = ($l.Length - $l.TrimStart().Length) + $delta
    if ($ni -lt 0) { $ni = 0 }
    $fragIndented += (' ' * $ni) + $l.TrimStart()
}
Write-Host ('缩进对齐：目标子项缩进=' + $childIndent + '，片段基准=' + $fragBase + '，偏移=' + $delta)

# ---- 构建 newLines（F1：末尾 insert 不越界） ----
if ($anchorIdx -lt 0) {
    # 【2026-10-21 主管修】原来漏写 `- insert:` 头行，导致片段被当成上一个顶层项的子项 → YAML 非法。
    $newLines = @()
    $newLines += $lines
    if ($lines.Count -gt 0 -and $lines[$lines.Count - 1].Trim() -ne '') { $newLines += '' }
    $newLines += '- insert:'
    $newLines += $fragIndented
} else {
    # insert 块结束位置 = 下一个顶格 "- " 项
    $endIdx = $lines.Count
    for ($i = $anchorIdx + 1; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match '^- ') { $endIdx = $i; break }
    }
    if ($endIdx -ge $lines.Count) {
        # F1：insert 块是最后一个顶层项 → 直接追加到末尾，不做越界切片
        Write-Host 'insert 块位于文件末尾：片段将追加到文件末尾'
        $newLines = @()
        $newLines += $lines[0..($endIdx - 1)]
        $newLines += ''
        $newLines += $fragIndented
    } else {
        $newLines = @()
        $newLines += $lines[0..($endIdx - 1)]
        $newLines += ''
        $newLines += $fragIndented
        $newLines += ''
        $newLines += $lines[$endIdx..($lines.Count - 1)]
    }
}

# ---- 安装日志（journal）：记录本次到底改了什么，供 uninstall 精确逆操作 ----
# 【2026-10-21 主管修】仅靠行内容无法区分"原文自带尾部空行"与"install 新增空行"，
# 会导致卸载后多/少一个换行。改为写一份 sidecar 日志，卸载按日志逆操作，并可校验字节级还原。
$origSha = (Get-FileHash -Algorithm SHA256 -LiteralPath $ProfilePatch).Hash
$insertCreated = ($anchorIdx -lt 0)
$lastLineNonBlank = ($lines.Count -gt 0 -and $lines[$lines.Count - 1].Trim() -ne '')
$addedBlankBeforeInsert = ($insertCreated -and $lastLineNonBlank)
$addedBlankBeforeFrag = ($anchorIdx -ge 0 -and $endIdx -ge $lines.Count)
$journalPath = $ProfilePatch + '.lean-journal.json'

# ---- G4：写盘前版本契约预检（只读，不落盘）—— 走 --batch 统一接口（0.4.0） ----
$batchPath = Join-Path $env:TEMP ('lean-batch-' + [System.Guid]::NewGuid().ToString('N') + '.json')
$batchTasks = @([ordered]@{
    task = 'version-check'
    preset = $ProfilePatch
    runtimeVersion = if ($RuntimeVersion -ne '') { $RuntimeVersion } else { $null }
    dshHome = if ($DshHome -ne '') { $DshHome } else { $null }
    allowUnknownRuntime = [bool]$AllowUnknownRuntime
})
[System.IO.File]::WriteAllText($batchPath, (ConvertTo-Json -InputObject $batchTasks -Depth 4 -Compress), (New-Object System.Text.UTF8Encoding $false))
$rv = Invoke-NodeCapture -NodeExe $NodeExe -NodeArgs @($Tool, '--batch', $batchPath)
Remove-Item -LiteralPath $batchPath -Force -ErrorAction SilentlyContinue
if ($rv.ExitCode -ne 0) {
    Write-Host ('版本契约预检未通过（batch 退出码 ' + $rv.ExitCode + '），已拒绝安装，未做任何写入。')
    Write-Host $rv.Stdout
    if ($rv.Stderr -ne '') { Write-Host '[stderr]'; Write-Host $rv.Stderr }
    Emit-Fail -Stage 'install' -Cause 'VERSION_CONTRACT_REFUSED' -Detail ('版本契约预检未通过（batch 退出码 ' + $rv.ExitCode + '）') -Code 1
}
try {
    $bj = $rv.Stdout | ConvertFrom-Json -ErrorAction Stop
    $vc = ($bj.results | Where-Object { $_.task -eq 'version-check' } | Select-Object -First 1)
    if ($vc -and -not $vc.ok) {
        Write-Host ('版本契约预检未通过（子任务 cause=' + $vc.cause + '），已拒绝安装，未做任何写入。')
        Emit-Fail -Stage 'install' -Cause $(if ($vc.cause) { $vc.cause } else { 'VERSION_CONTRACT_REFUSED' }) -Detail '版本契约预检未通过（version-check 子任务）' -Code 1
    }
} catch { /* 解析失败则信任上面的退出码判定 */ }

# ---- F4：DryRun 在任何写入（含锁/备份）之前退出 ----
if ($DryRun) {
    Write-Host '==== DryRun：将写入以下内容（不落盘、不建备份、不加锁）===='
    $newLines | ForEach-Object { Write-Host $_ }
    Write-Host '==== DryRun 结束，未修改目标文件，未创建备份/锁 ===='
    exit 0
}

# ---- G2：加锁（写操作临界区开始） ----
$lockPath = $ProfilePatch + '.lock'
$lockStream = $null
try {
    $lockStream = [System.IO.File]::Open($lockPath, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
} catch {
    Write-Host '另一个安装/卸载正在进行（检测到 <patch>.lock 被占用），退出。请确认没有并发运行后重试。'
    Emit-Fail -Stage 'install' -Cause 'LOCKED' -Detail '检测到 <patch>.lock 被占用（并发安装/卸载）' -Code 3
}

# ---- 原子写 + 校验 + 判定（G2；异常即回滚） ----
$backup = $ProfilePatch + '.bak-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-release'
$tmpPath = $ProfilePatch + '.tmp-' + $pid
try {
    # G2：先写临时文件，校验通过后再原子替换
    Write-TextWithLayout -Path $tmpPath -Layout $layout -NewLines $newLines
    $tLayout = Read-TextWithLayout -Path $tmpPath
    $tT = $false; $tS = $false
    foreach ($l in $tLayout.Lines) {
        if ($l -match '^\s*- id: preset-token-lean\s*$') { $tT = $true }
        if ($l -match '^\s*- id: preset-scout\s*$')      { $tS = $true }
    }
    if (-not ($tT -and $tS)) {
        throw '原子写临时文件校验失败：两段 preset 未同时写入临时文件'
    }
    # 原子替换：tmp → patch，原 patch 存入 backup
    [System.IO.File]::Replace($tmpPath, $ProfilePatch, $backup)
    Write-Host ('已插入两段 preset（原子替换）；原文件备份至：' + $backup)

    $okAll = $true
    $checkLayout = Read-TextWithLayout -Path $ProfilePatch
    $cT = $false; $cS = $false
    foreach ($l in $checkLayout.Lines) {
        if ($l -match '^\s*- id: preset-token-lean\s*$') { $cT = $true }
        if ($l -match '^\s*- id: preset-scout\s*$')      { $cS = $true }
    }
    if ($cT -and $cS) { Write-Host '回读校验：两段 preset 均存在。' }
    else { Write-Warning '回读校验失败：插入后未同时找到两段 preset'; $okAll = $false }

    # G4 + F2：插入后做 schema + 键表校验（对真实 patch 文件）—— 走 --batch 统一接口（0.4.0）
    $batchPath = Join-Path $env:TEMP ('lean-batch-' + [System.Guid]::NewGuid().ToString('N') + '.json')
    $batchTasks = @([ordered]@{
        task = 'preset'
        preset = $ProfilePatch
        schema = if ($SchemaPath -ne '' -and (Test-Path -LiteralPath $SchemaPath)) { $SchemaPath } else { $null }
        runtimeVersion = if ($RuntimeVersion -ne '') { $RuntimeVersion } else { $null }
        dshHome = if ($DshHome -ne '') { $DshHome } else { $null }
        allowUnknownRuntime = [bool]$AllowUnknownRuntime
    })
    [System.IO.File]::WriteAllText($batchPath, (ConvertTo-Json -InputObject $batchTasks -Depth 4 -Compress), (New-Object System.Text.UTF8Encoding $false))
    $r = Invoke-NodeCapture -NodeExe $NodeExe -NodeArgs @($Tool, '--batch', $batchPath)
    Remove-Item -LiteralPath $batchPath -Force -ErrorAction SilentlyContinue
    Write-Host $r.Stdout
    if ($r.Stderr -ne '') { Write-Host '[stderr]'; Write-Host $r.Stderr }
    $batchOk = $true; $batchCause = $null
    try {
        $bj = $r.Stdout | ConvertFrom-Json -ErrorAction Stop
        $pr = ($bj.results | Where-Object { $_.task -eq 'preset' } | Select-Object -First 1)
        if (-not $pr -or -not $pr.ok) { $batchOk = $false; $batchCause = if ($pr) { $pr.cause } else { 'BATCH_NO_PRESET_RESULT' } }
    } catch { $batchOk = $false; $batchCause = 'BATCH_JSON_PARSE_FAIL' }
    if ($r.ExitCode -ne 0 -or -not $batchOk) {
        Write-Warning ('schema/键表校验未通过（cause=' + $batchCause + '）')
        $okAll = $false
    }

    if (-not $okAll) {
        Write-Host '校验未全部通过，已回滚……'
        Copy-Item -LiteralPath $backup -Destination $ProfilePatch -Force
        Write-Host ('回滚后 md5 = ' + (Get-Md5 $ProfilePatch))
        Write-Host ('备份   md5 = ' + (Get-Md5 $backup))
        Write-Host ('一致：' + ((Get-Md5 $ProfilePatch) -eq (Get-Md5 $backup)))
        Emit-Fail -Stage 'install' -Cause $(if ($batchCause) { $batchCause } else { 'PRECONDITION' }) -Detail '校验未全部通过，已回滚到备份' -Code 1
    }
} catch {
    Write-Host '安装过程抛出异常，已回滚……'
    if (Test-Path -LiteralPath $backup) {
        Copy-Item -LiteralPath $backup -Destination $ProfilePatch -Force
        Write-Host ('回滚后 md5 = ' + (Get-Md5 $ProfilePatch))
    } else {
        Write-Host '（无备份可回滚，目标文件应未被改动）'
    }
    Emit-Fail -Stage 'install' -Cause 'PRECONDITION' -Detail ('安装异常：' + $_.Exception.Message) -Code 1
} finally {
    if ($lockStream) { try { $lockStream.Close() } catch {} ; Remove-Item -LiteralPath $lockPath -Force -ErrorAction SilentlyContinue }
    if (Test-Path -LiteralPath $tmpPath) { Remove-Item -LiteralPath $tmpPath -Force -ErrorAction SilentlyContinue }
}

$j = [ordered]@{
    version                 = '0.3.0'
    installedAt             = (Get-Date).ToString('o')
    originalSha256          = $origSha
    insertCreated           = $insertCreated
    addedBlankBeforeInsert  = $addedBlankBeforeInsert
    addedBlankBeforeFrag    = $addedBlankBeforeFrag
    fragIndent              = $childIndent
    trailingNewline         = [bool]$layout.TrailingNewline
    eolCRLF                 = [bool]$layout.EolCRLF
    hasBom                  = [bool]$layout.HasBom
}
[System.IO.File]::WriteAllText($journalPath, ($j | ConvertTo-Json), (New-Object System.Text.UTF8Encoding($false)))
Write-Host ('安装日志已写入：' + $journalPath)
Write-Host '全部校验通过。重启 DSH 桌面应用后，模式下拉应出现「裁员广进」与「· 只读子代理（内部，勿直接对话）」。'
exit 0
