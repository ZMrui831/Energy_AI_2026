#!/usr/bin/env node
'use strict';

/**
 * run-fixtures.cjs — 夹具全量跑 + 自检
 *
 * 遍历 --dir 下所有 *.yml，逐个以子进程调用 schema-preflight 工具，
 * 与内嵌期望表比对 cause / 退出码，输出对齐结果表。
 *
 * 用法：
 *   node tools/run-fixtures.cjs [--dir <夹具目录>] [--schema <schema.json>] [--tool <schema-preflight.cjs>] [--no-type]
 *
 * 参数：
 *   --dir <目录>     夹具目录，默认 fixtures
 *   --schema <文件>  schema 文件，【可选】：缺省时工具降级为仅内置权威键表判定
 *   --tool <文件>    校验工具，默认 schema-preflight.cjs
 *   --no-type        跳过 5 个 type-*.yml 类型用例，只跑 7 个非类型夹具（输出 TOTAL=7）
 *
 * 退出码：0 = 全部 PASS；1 = 有 FAIL（含 UNLISTED/MISSING）；2 = 环境错误（路径不存在等）
 *
 * 仅依赖 Node 内置模块：fs / path / os / child_process。默认路径均相对当前工作目录（项目根）。
 */

const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawnSync } = require('child_process');

// ---------- 期望表（按任务规格原样照抄，勿改） ----------
const EXPECTED = {
  'bad-persona.yml':        { cause: 'DEPRECATED_KEY',     exit: 1 },
  'bad-toolfilter.yml':     { cause: 'DEPRECATED_KEY',     exit: 1 },
  'bad-backgroundmode.yml': { cause: 'DEPRECATED_KEY',     exit: 1 },
  'bad-unknown.yml':        { cause: 'UNKNOWN_KEY',        exit: 1 },
  'bad-missing.yml':        { cause: 'MISSING_REQUIRED',   exit: 1 },
  'bad-parse.yml':          { cause: 'PRESET_PARSE_ERROR', exit: 2 },
  'good.yml':               { cause: 'OK',                 exit: 0 },
  'type-bool-string.yml':   { cause: 'TYPE_MISMATCH',      exit: 1 },
  'type-num-string.yml':    { cause: 'TYPE_MISMATCH',      exit: 1 },
  'type-array-scalar.yml':  { cause: 'TYPE_MISMATCH',      exit: 1 },
  'type-ok-js.yml':         { cause: 'OK',                 exit: 0 },
  'type-ok-normal.yml':     { cause: 'OK',                 exit: 0 },
};

// 已知 cause 池：用于从 stderr 兜底提取（exit=2 时 cause 可能只出现在 stderr）
const KNOWN_CAUSES = [
  'PRESET_PARSE_ERROR',
  'MISSING_REQUIRED',
  'DEPRECATED_KEY',
  'TYPE_MISMATCH',
  'UNKNOWN_KEY',
];

// ---------- 参数解析 ----------
function printHelp() {
  console.log(
    [
      '用法: node tools/run-fixtures.cjs [--dir <夹具目录>] [--schema <schema.json>] [--tool <schema-preflight.cjs>] [--no-type]',
      '',
      '参数:',
      '  --dir <目录>     夹具目录，默认 fixtures',
      '  --schema <文件>  schema 文件，可选；缺省时工具仅按内置权威键表判定',
      '  --tool <文件>    校验工具，默认 schema-preflight.cjs',
      '  --no-type        跳过 5 个 type-*.yml 类型用例（输出 TOTAL=7）',
      '',
      '退出码: 0=全部 PASS, 1=有 FAIL, 2=环境错误',
    ].join('\n')
  );
}

function parseArgs(argv) {
  const opts = { dir: 'fixtures', schema: '', tool: 'schema-preflight.cjs', noType: false };
  const valued = { '--dir': 'dir', '--schema': 'schema', '--tool': 'tool' };
  const flags = { '--no-type': 'noType' };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-h' || a === '--help') {
      printHelp();
      process.exit(0);
    }
    if (flags[a]) { opts[flags[a]] = true; continue; }
    const key = valued[a];
    if (!key) {
      console.error(`[run-fixtures] 未知参数: ${a}`);
      printHelp();
      process.exit(2);
    }
    const v = argv[++i];
    if (v === undefined || v === '') {
      console.error(`[run-fixtures] 参数 ${a} 缺少值`);
      process.exit(2);
    }
    opts[key] = v;
  }
  return opts;
}

// ---------- 终端对齐工具（中文/全角按 2 列宽计） ----------
function charWidth(ch) {
  const cp = ch.codePointAt(0);
  if (
    (cp >= 0x1100 && cp <= 0x115f) || // Hangul Jamo
    (cp >= 0x2e80 && cp <= 0xa4cf) || // CJK 部首/符号/统表意/注音
    (cp >= 0xac00 && cp <= 0xd7a3) || // Hangul
    (cp >= 0xf900 && cp <= 0xfaff) || // CJK 兼容表意
    (cp >= 0xfe30 && cp <= 0xfe4f) || // CJK 兼容形式
    (cp >= 0xff00 && cp <= 0xff60) || // 全角形式
    (cp >= 0xffe0 && cp <= 0xffe6) // 全角符号
  ) {
    return 2;
  }
  return 1;
}

function displayWidth(str) {
  let w = 0;
  for (const ch of str) w += charWidth(ch);
  return w;
}

function padCell(str, width) {
  return str + ' '.repeat(Math.max(width - displayWidth(str), 0));
}

// ---------- JSON 宽松提取（容忍 stdout 里混入非 JSON 日志行） ----------
function extractJson(stdout) {
  const start = stdout.indexOf('{');
  if (start === -1) return null;
  const end = stdout.lastIndexOf('}');
  if (end <= start) return null;
  try {
    return JSON.parse(stdout.slice(start, end + 1));
  } catch {
    return null;
  }
}

// ---------- 子进程调用工具 ----------
// F8：stdio 用文件描述符 ['ignore', fdOut, fdErr]，不依赖管道——
// 在 DSH 沙箱等受限环境里 pipe 会整批 EPERM，临时文件重定向不受影响。
function runTool(toolPath, presetPath, schemaPath) {
  // G4：夹具验证只关心 preset/schema 正确性，不绑定具体运行时版本；
  // 版本契约由 install.ps1 在写盘前强制，这里统一用 --allow-unknown-runtime 走内置默认键表，
  // 避免工具因"未提供版本"而拒绝（否则 12/12 与 7/7 都跑不出来）。
  const args = [toolPath, '--preset', presetPath, '--json', '--allow-unknown-runtime'];
  if (schemaPath) args.push('--schema', schemaPath);

  const stamp = process.pid + '-' + Date.now() + '-' + Math.floor(Math.random() * 1e6);
  const tmpOut = path.join(os.tmpdir(), 'run-fixtures-out-' + stamp + '.txt');
  const tmpErr = path.join(os.tmpdir(), 'run-fixtures-err-' + stamp + '.txt');
  let fdOut = null;
  let fdErr = null;
  try {
    fdOut = fs.openSync(tmpOut, 'w');
    fdErr = fs.openSync(tmpErr, 'w');
    const r = spawnSync(process.execPath, args, { stdio: ['ignore', fdOut, fdErr] });
    if (r.error) {
      return { exitCode: -1, stdout: '', stderr: 'spawn error: ' + r.error.message, causes: [] };
    }
    const exitCode = r.status === null ? -1 : r.status; // 被信号杀死等异常情况
    let stdout = '';
    let stderr = '';
    try { stdout = fs.readFileSync(tmpOut, 'utf8'); } catch { stdout = ''; }
    try { stderr = fs.readFileSync(tmpErr, 'utf8'); } catch { stderr = ''; }

    // 1) 优先从 --json 输出的 findings[].cause 提取
    let causes = [];
    const parsed = extractJson(stdout);
    if (parsed && Array.isArray(parsed.findings)) {
      causes = parsed.findings
        .map((f) => (f && typeof f.cause === 'string' ? f.cause : null))
        .filter(Boolean);
    }
    // 1b) 顶层 cause（解析失败等错误路径可能只有 {ok:false,cause}，没有 findings）
    if (causes.length === 0 && parsed && typeof parsed.cause === 'string') {
      causes = [parsed.cause];
    }
    // 1c) 再从 stdout 文本里抓 [CAUSE] 方括号形式（非 --json 路径）
    if (causes.length === 0 && stdout) {
      const m = /\[([A-Z][A-Z0-9_]{3,})\]/.exec(stdout);
      if (m) causes = [m[1]];
    }

    // 2) 兜底：从 stderr 提取已知 cause token（覆盖 PRESET_PARSE_ERROR 只写 stderr 的情况）
    if (causes.length === 0 && stderr) {
      for (const c of KNOWN_CAUSES) {
        if (stderr.includes(c)) {
          causes = [c];
          break;
        }
      }
    }

    return { exitCode, stdout, stderr, causes };
  } finally {
    if (fdOut !== null) { try { fs.closeSync(fdOut); } catch { /* ignore */ } }
    if (fdErr !== null) { try { fs.closeSync(fdErr); } catch { /* ignore */ } }
    try { fs.unlinkSync(tmpOut); } catch { /* ignore */ }
    try { fs.unlinkSync(tmpErr); } catch { /* ignore */ }
  }
}

// ---------- 表格输出 ----------
function printTable(rows) {
  const headers = ['夹具', '期望', '实际(cause)', '退出码', 'PASS/FAIL'];
  const table = rows.map((r) => [
    r.fixture,
    r.expected,
    r.actual,
    r.exit,
    r.pass ? 'PASS' : 'FAIL',
  ]);

  const widths = headers.map((h, i) =>
    Math.max(displayWidth(h), ...table.map((row) => displayWidth(row[i])))
  );

  const line = (cells) => cells.map((c, i) => padCell(c, widths[i])).join(' | ');
  const sep = widths.map((w) => '-'.repeat(w)).join('-+-');

  console.log(line(headers));
  console.log(sep);
  for (const row of table) console.log(line(row));
}

// ---------- 主流程 ----------
function main() {
  const opts = parseArgs(process.argv.slice(2));
  const skipType = !!opts.noType;

  const dir = path.resolve(opts.dir);
  const toolPath = path.resolve(opts.tool);
  const schemaPath = opts.schema ? path.resolve(opts.schema) : '';

  // 前置环境检查（fail fast，避免夹具连续空跑）。schema 为可选（F7）。
  if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) {
    console.error(`[run-fixtures] 夹具目录不存在或不是目录: ${dir}`);
    process.exitCode = 2;
    return;
  }
  if (!fs.existsSync(toolPath)) {
    console.error(`[run-fixtures] 工具不存在: ${toolPath}`);
    process.exitCode = 2;
    return;
  }
  if (schemaPath && !fs.existsSync(schemaPath)) {
    console.error(`[run-fixtures] schema 不存在: ${schemaPath}`);
    process.exitCode = 2;
    return;
  }

  if (skipType) {
    console.log('模式：--no-type（跳过 5 个 type-*.yml 类型用例，仅跑 7 个非类型夹具）');
  }

  const files = fs
    .readdirSync(dir)
    .filter((f) => f.toLowerCase().endsWith('.yml') && fs.statSync(path.join(dir, f)).isFile())
    .sort();

  const rows = [];
  const present = new Set();

  for (const file of files) {
    if (skipType && file.indexOf('type-') === 0) continue; // F7：--no-type 跳过类型用例
    present.add(file);
    const exp = EXPECTED[file];

    // 期望表之外的新 .yml → UNLISTED，计入 FAIL（防悄悄漏测）
    if (!exp) {
      rows.push({ fixture: file, expected: 'UNLISTED', actual: '-', exit: '-', pass: false });
      continue;
    }

    const { exitCode, stderr, causes } = runTool(toolPath, path.join(dir, file), schemaPath);
    const actualCause = causes.length > 0 ? causes[0] : exitCode === 0 ? 'OK' : '?';

    // 判定：期望 OK → 只要退出码 0；其他 → 退出码匹配 且 cause 出现在 findings 或 stderr
    let pass;
    if (exp.cause === 'OK') {
      pass = exitCode === 0;
    } else {
      pass = exitCode === exp.exit && (causes.includes(exp.cause) || stderr.includes(exp.cause));
    }

    rows.push({
      fixture: file,
      expected: exp.cause,
      actual: actualCause,
      exit: String(exitCode),
      pass,
    });
  }

  // 期望表里有、目录里没有 → MISSING，同样计入 FAIL（防目录传错导致假全绿）
  for (const [file, exp] of Object.entries(EXPECTED)) {
    if (skipType && file.indexOf('type-') === 0) continue; // F7：--no-type 不查类型用例缺失
    if (!present.has(file)) {
      rows.push({
        fixture: file,
        expected: exp.cause,
        actual: 'MISSING',
        exit: '-',
        pass: false,
      });
    }
  }

  printTable(rows);

  const passCount = rows.filter((r) => r.pass).length;
  const failCount = rows.length - passCount;
  console.log(`\nTOTAL=${rows.length} PASS=${passCount} FAIL=${failCount}`);

  process.exitCode = failCount > 0 ? 1 : 0;
}

main();
