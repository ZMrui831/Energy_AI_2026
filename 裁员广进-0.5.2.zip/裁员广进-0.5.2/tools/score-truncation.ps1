﻿# score-truncation.ps1 —— 截断质量自动评分器（0.4.1）
#
# 用法：
#   powershell -ExecutionPolicy Bypass -File .\tools\score-truncation.ps1 `
#       -Snapshot <快照> -StdAnswer <std.txt> -LeanAnswer <lean.txt> [-Start 900] [-End 910]
#
# 行为（只用 Get-Content / 正则 / 字符串比较，不调用任何模型，不写除 stdout 之外的文件）：
#   1) 从快照抽出第 Start–End 行（默认 900–910，含两端，共 11 行）；
#   2) 对两份答案做归一化比对（去行首尾空白、去 L####| 前缀差异、去 markdown 引用/列表/编号符号）；
#   3) 每个模式输出：quoted=<命中行数>/N、exact=<逐字命中>/N、mentionsOffset、declaresTruncation；
#   4) 一行结论：标准 11/11 且广进 <11/11 → 质量代价成立；两者都 11/11 → 未观察到质量代价；
#      标准也 <11/11 → 实验无效（标准模式也答错，检查题面）；
#   5) 输出 JSON {ok,start,end,expectedLines,std{},lean{},verdict}；评分器自身失败才非 0。
# 本脚本不含任何构建机绝对路径。

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Snapshot,
    [Parameter(Mandatory = $true)][string]$StdAnswer,
    [Parameter(Mandatory = $true)][string]$LeanAnswer,
    [int]$Start = 900,
    [int]$End = 910
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Norm([string]$line) {
    if ($null -eq $line) { return '' }
    $s = $line.Trim()
    $s = $s -replace '^(>\s*)+', ''
    $s = $s -replace '^([-*+]\s+)+', ''
    $s = $s -replace '^[\(\[]?\d+[\)\.\]]\s*', ''
$s = $s -replace '^\d+\s*[:：|]\s*', ''   # 900: / 900： / 900| 前缀
    $s = $s -replace '^L\d{4}\s*\|\s*', ''
    $s = $s -replace '^`+|`+$', ''
    $s = $s -replace '\s*\|\s*', '|'
    $s = $s -replace '\s+', ' '
    return $s.Trim()
}

function Score-Answer([string[]]$answerLines, [string[]]$expected) {
    $quoted = 0; $exact = 0
    $normAns = @($answerLines | ForEach-Object { Norm $_ } | Where-Object { $_ -ne '' })
    foreach ($e in $expected) {
        $ne = Norm $e
        if ($ne -eq '') { continue }
        $isExact = $false; $isQuote = $false
        foreach ($a in $normAns) {
            if ($a -eq $ne) { $isExact = $true; break }
            if ($a.Contains($ne)) { $isQuote = $true }
        }
        if ($isExact) { $exact++; $quoted++ }
        elseif ($isQuote) { $quoted++ }
    }
    return @{ quoted = $quoted; exact = $exact }
}

# 0.4.2：答案文件可能是 UTF-8 无 BOM / UTF-8 BOM / UTF-16 / GBK；PS5.1 的 Get-Content 默认按 ANSI 读，
# 会把中文读花导致 mentionsOffset 漏检（本次标准答案「读取范围…」就被判 False 的根因之一）。
function Read-TextSmart([string]$path) {
    $bytes = [System.IO.File]::ReadAllBytes($path)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        return [System.Text.Encoding]::UTF8.GetString($bytes, 3, $bytes.Length - 3)
    }
    if ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
        return [System.Text.Encoding]::Unicode.GetString($bytes, 2, $bytes.Length - 2)
    }
    if ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF) {
        return [System.Text.Encoding]::BigEndianUnicode.GetString($bytes, 2, $bytes.Length - 2)
    }
    $strict = New-Object System.Text.UTF8Encoding($false, $true)
    try { return $strict.GetString($bytes) } catch { return [System.Text.Encoding]::Default.GetString($bytes) }
}

try {
    $snapLines = @(Get-Content -LiteralPath $Snapshot -Encoding UTF8)
    if ($snapLines.Count -lt $End) {
        throw ('快照行数不足：' + $snapLines.Count + ' < End=' + $End)
    }
    $expected = @($snapLines[($Start - 1)..($End - 1)])
    $expCount = $expected.Count

    $stdText = (Read-TextSmart $StdAnswer)
    $leanText = (Read-TextSmart $LeanAnswer)
    $stdLines = @($stdText -split "`r?`n")
    $leanLines = @($leanText -split "`r?`n")

    $sStd = Score-Answer -answerLines $stdLines -expected $expected
    $sLean = Score-Answer -answerLines $leanLines -expected $expected

    # 0.4.2：补漏检——标准答案写「读取范围为 2490–2519 行」应判 True。
    $offRx = [regex]'(?i)offset|续读|第\s*8\d\d|use offset|next page|cursor|读取范围|offset=|limit=|第\s*\d+\s*[–-]\s*\d+\s*行|range'
    $truncRx = [regex]'截断|未包含|需继续读|继续读|未读到|未读取'
    $stdOff = $offRx.IsMatch($stdText); $leanOff = $offRx.IsMatch($leanText)
    $stdTrunc = $truncRx.IsMatch($stdText); $leanTrunc = $truncRx.IsMatch($leanText)

    if ($sStd.quoted -lt $expCount) { $verdict = '实验无效（标准模式也答错，检查题面）' }
    elseif ($sLean.quoted -lt $expCount) { $verdict = '质量代价成立' }
    else { $verdict = '未观察到质量代价' }

    Write-Host ("expected lines = {0} (第 {1}–{2} 行)" -f $expCount, $Start, $End)
    Write-Host ("std  : quoted={0}/{1} exact={2}/{1} mentionsOffset={3} declaresTruncation={4}" -f $sStd.quoted, $expCount, $sStd.exact, $stdOff, $stdTrunc)
    Write-Host ("lean : quoted={0}/{1} exact={2}/{1} mentionsOffset={3} declaresTruncation={4}" -f $sLean.quoted, $expCount, $sLean.exact, $leanOff, $leanTrunc)
    Write-Host ("结论：{0}" -f $verdict)

    $json = [ordered]@{
        ok            = $true
        start         = $Start
        end           = $End
        expectedLines = $expCount
        std           = [ordered]@{ quoted = $sStd.quoted; exact = $sStd.exact; mentionsOffset = $stdOff; declaresTruncation = $stdTrunc }
        lean          = [ordered]@{ quoted = $sLean.quoted; exact = $sLean.exact; mentionsOffset = $leanOff; declaresTruncation = $leanTrunc }
        verdict       = $verdict
    }
    Write-Output (ConvertTo-Json $json -Depth 5)
    exit 0
} catch {
    $json = [ordered]@{ ok = $false; error = $_.Exception.Message }
    Write-Output (ConvertTo-Json $json -Depth 5)
    exit 1
}
