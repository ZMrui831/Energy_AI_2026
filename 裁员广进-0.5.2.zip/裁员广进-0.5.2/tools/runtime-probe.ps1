﻿# runtime-probe.ps1 —— 只读探测 node 候选（排障用；不写任何文件、不改任何配置）
#
# 用法：
#   powershell -ExecutionPolicy Bypass -File .\tools\runtime-probe.ps1 [-DshHome <DSH安装目录>] [-NodeExe <node>]
#
# 行为：
#   * 与 install/verify 同款 Resolve-NodeExe 探测逻辑（含 Electron 主程序回退）；
#   * 每个候选只执行 `--version` 实测可用性（超时 10s），不改变目标文件、不写备份/日志；
#   * 输出 JSON：{ ok, candidates:[{path, source, exists, usable, reason, version}], selected, versionDetect:{selected, source, candidates[], electronVersionGuess} }；
#   * 探测失败也输出 JSON（ok=false），不抛异常。
# 本脚本不含任何构建机绝对路径。

[CmdletBinding()]
param([string]$DshHome = '', [string]$NodeExe = '')
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---- 与 install/verify 同款：候选可用性实测 ----
function Test-NodeCandidate {
    param([string]$Path, [bool]$IsElectron, [string]$Source)
    $exists = Test-Path -LiteralPath $Path -PathType Leaf
    if (-not $exists) {
        return [PSCustomObject]@{
            Usable = $false; Reason = '不存在'; Result = $null
            Tried  = @([PSCustomObject]@{ path = $Path; source = $Source; exists = $false; usable = $false; reason = '不存在'; version = $null })
        }
    }
    $prev = $env:ELECTRON_RUN_AS_NODE
    if ($IsElectron) { $env:ELECTRON_RUN_AS_NODE = '1' }
    $ok = $false; $reason = ''; $ver = $null
    try {
        $tmpOut = [System.IO.Path]::GetTempFileName()
        $tmpErr = [System.IO.Path]::GetTempFileName()
        try {
            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName = $Path
            $psi.Arguments = '--version'
            $psi.UseShellExecute = $false
            $psi.RedirectStandardOutput = $true
            $psi.RedirectStandardError = $true
            $psi.CreateNoWindow = $true
            $proc = New-Object System.Diagnostics.Process
            $proc.StartInfo = $psi
            if (-not $proc.Start()) { throw '无法启动进程' }
            if (-not $proc.WaitForExit(10000)) {
                try { $proc.Kill() } catch {}
                $reason = '超时(>10s)'
            } else {
                $so = $proc.StandardOutput.ReadToEnd().Trim()
                $se = $proc.StandardError.ReadToEnd().Trim()
                if ($proc.ExitCode -eq 0 -and ($so -match '^v\d+\.')) {
                    $ok = $true; $ver = $so
                } else {
                    $reason = "exit=$($proc.ExitCode); stdout='$so'; stderr='$se'"
                }
            }
        } finally {
            Remove-Item -LiteralPath $tmpOut -Force -ErrorAction SilentlyContinue
            Remove-Item -LiteralPath $tmpErr -Force -ErrorAction SilentlyContinue
        }
    } catch {
        $reason = ('异常: ' + $_.Exception.Message)
    } finally {
        if ($IsElectron) {
            if ($null -eq $prev) { Remove-Item env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue }
            else { $env:ELECTRON_RUN_AS_NODE = $prev }
        }
    }
    return [PSCustomObject]@{
        Usable = $ok; Reason = $reason
        Result = [PSCustomObject]@{ Path = $Path; Source = $Source; Version = $ver; IsElectron = $IsElectron; Tried = $null; Failed = $false }
        Tried  = @([PSCustomObject]@{ path = $Path; source = $Source; exists = $true; usable = $ok; reason = $reason; version = $ver })
    }
}

function Resolve-NodeExe {
    param([string]$Explicit, [string]$DshHome)
    $tried = @()
    if ($Explicit -ne '') {
        if (-not (Test-Path -LiteralPath $Explicit -PathType Leaf)) {
            Write-Host ('指定的 -NodeExe 不存在：' + $Explicit)
            exit 2
        }
        $r = Test-NodeCandidate -Path $Explicit -IsElectron ($Explicit -match 'DeepSeek.*Harness.*\.exe') -Source '-NodeExe'
        $tried += $r.Tried
        if (-not $r.Usable) {
            Write-Host ('指定的 -NodeExe 不可用（无法作为 node 运行）：' + $Explicit)
            Write-Host ('  失败原因：' + $r.Reason)
            exit 2
        }
        $r.Result.Tried = $tried
        return $r.Result
    }
    if ($env:DSH_DESKTOP_NODE_EXECUTABLE -and (Test-Path -LiteralPath $env:DSH_DESKTOP_NODE_EXECUTABLE -PathType Leaf)) {
        $r = Test-NodeCandidate -Path $env:DSH_DESKTOP_NODE_EXECUTABLE -IsElectron ($env:DSH_DESKTOP_NODE_EXECUTABLE -match 'DeepSeek.*Harness.*\.exe') -Source '$env:DSH_DESKTOP_NODE_EXECUTABLE'
        $tried += $r.Tried
        if ($r.Usable) { $r.Result.Tried = $tried; return $r.Result }
    }
    if ($DshHome -ne '') {
        $base = $DshHome.TrimEnd('\').TrimEnd('/')
        $cands = @(
            [PSCustomObject]@{ Path = "$base\resources\runtime\bin\node.exe"; IsElectron = $false; Source = 'DshHome:resources/runtime/bin/node.exe' },
            [PSCustomObject]@{ Path = "$base\resources\runtime\primary-runtime\dependencies\node\node.exe"; IsElectron = $false; Source = 'DshHome:primary-runtime/.../node.exe' },
            [PSCustomObject]@{ Path = "$base\resources\runtime\primary-runtime\dependencies\node\bin\node.exe"; IsElectron = $false; Source = 'DshHome:primary-runtime/.../bin/node.exe' },
            [PSCustomObject]@{ Path = "$base\resources\runtime\node.exe"; IsElectron = $false; Source = 'DshHome:resources/runtime/node.exe' },
            [PSCustomObject]@{ Path = "$base\DeepSeek Harness.exe"; IsElectron = $true; Source = 'DshHome:DeepSeek Harness.exe' }
        )
        if (Test-Path -LiteralPath $base -PathType Container) {
            Get-ChildItem -LiteralPath $base -Filter 'DeepSeek*Harness*.exe' -File -ErrorAction SilentlyContinue | ForEach-Object {
                if ($_.FullName -ne "$base\DeepSeek Harness.exe") {
                    $cands += [PSCustomObject]@{ Path = $_.FullName; IsElectron = $true; Source = 'DshHome:root/DeepSeek*Harness*.exe' }
                }
            }
        }
        foreach ($c in $cands) {
            $r = Test-NodeCandidate -Path $c.Path -IsElectron $c.IsElectron -Source $c.Source
            $tried += $r.Tried
            if ($r.Usable) { $r.Result.Tried = $tried; return $r.Result }
        }
    }
    $pn = Get-Command node -ErrorAction SilentlyContinue
    if ($pn) {
        $r = Test-NodeCandidate -Path $pn.Source -IsElectron ($pn.Source -match 'DeepSeek.*Harness.*\.exe') -Source 'PATH:node'
        $tried += $r.Tried
        if ($r.Usable) { $r.Result.Tried = $tried; return $r.Result }
    }
    return [PSCustomObject]@{ Path = $null; Source = $null; Version = $null; IsElectron = $false; Failed = $true; Tried = $tried }
}

$resolved = Resolve-NodeExe -Explicit $NodeExe -DshHome $DshHome
$candidates = @()
foreach ($t in $resolved.Tried) {
    $candidates += [ordered]@{ path = $t.path; source = $t.source; exists = [bool]$t.exists; usable = [bool]$t.usable; reason = $t.reason; version = $t.version }
}
$selected = $null
if (-not $resolved.Failed) {
    $selected = [ordered]@{ path = $resolved.Path; source = $resolved.Source; version = $resolved.Version; isElectron = [bool]$resolved.IsElectron }
}

# ---- 版本探测（只读）：用已解析的 node 跑 schema-preflight.cjs --print-version ----
# 让第三方一条命令看清「node 从哪来、版本从哪来」。仍不写任何文件、不改任何配置。
$versionDetect = $null
if ($DshHome -ne '' -and -not $resolved.Failed) {
    $nodeBin = $resolved.Path
    $prevEnv = $env:ELECTRON_RUN_AS_NODE
    if ($resolved.IsElectron) { $env:ELECTRON_RUN_AS_NODE = '1' }
    try {
        $pvRaw = & $nodeBin (Join-Path $PSScriptRoot 'schema-preflight.cjs') --print-version --dsh-home $DshHome 2>$null
        $pvJson = ($pvRaw -join "`n")
        $pv = $pvJson | ConvertFrom-Json -ErrorAction SilentlyContinue
        if ($pv) {
            $vcands = @()
            foreach ($c in $pv.candidates) {
                $vcands += [ordered]@{ path = $c.path; exists = [bool]$c.exists; value = $c.value; reason = $c.reason }
            }
            $versionDetect = [ordered]@{
                selected = $pv.selected
                source = $pv.source
                candidates = $vcands
                electronVersionGuess = $pv.evidence.electronVersionGuess
            }
        }
    } catch {
        # 忽略：versionDetect 留空，不阻断 node 探测主流程
    } finally {
        if ($resolved.IsElectron) {
            if ($null -eq $prevEnv) { Remove-Item env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue }
            else { $env:ELECTRON_RUN_AS_NODE = $prevEnv }
        }
    }
}
if ($null -eq $versionDetect) {
    $versionDetect = [ordered]@{ selected = $null; source = $null; candidates = @(); electronVersionGuess = $null }
}

$out = [ordered]@{ ok = (-not $resolved.Failed); candidates = $candidates; selected = $selected; versionDetect = $versionDetect }
Write-Host (ConvertTo-Json $out -Depth 4)
exit 0
