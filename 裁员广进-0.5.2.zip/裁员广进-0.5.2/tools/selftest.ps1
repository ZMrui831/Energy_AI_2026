﻿# selftest.ps1 —— 自证验证：在 %TEMP% 用合成 patch 跑通「安装→验证→卸载」全流程
#
# 用法：
#   powershell -ExecutionPolicy Bypass -File .\tools\selftest.ps1 [-DshHome <DSH安装目录>] [-NodeExe <node>]
#
# 关键约束（G5）：
#   * 绝不读取/写入真实 cordis.patch.yml；脚本内不含任何真实 profile 路径。
#   * 全程在 %TEMP%\dsh-lean-selftest-<guid> 内进行，结束清理临时目录。
#   * 步骤：install -DryRun（断言零写入）→ install（断言 exit 0）→ verify（断言 12/12）
#          → uninstall（断言 sha256 回到装前）→ 版本门禁负向（0.9.9 应拒绝且零写入）
#          → 版本探测优先级（runtime.json 优先于根目录 Electron version）→ 清理
#          → 输出 JSON {ok, steps[], exitCode}。
#   * -DshHome / -NodeExe 会原样透传给 install/verify（干净机器无 node 时用 Electron 主程序当 node）。
# 本脚本依赖：PowerShell 5.1；node 由 verify/install 自动探测（可透传 -DshHome/-NodeExe）。
# 注意：SELFTEST 仅验证「安装器自身的行为正确性」，不验证某个真实运行时能否加载 preset
#       （那需要真实 DSH 环境，由人工或 eval 完成）。

[CmdletBinding()]
param([string]$DshHome = '', [string]$NodeExe = '')
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---- 0.4.0：脚本级结构化失败（最后一行输出一行 JSON） ----
function Emit-Fail {
    param([string]$Stage, [string]$Cause, [string]$Detail, [int]$Code = 1)
    $obj = [ordered]@{ ok = $false; stage = $Stage; cause = $Cause; detail = $Detail }
    [Console]::Out.WriteLine((ConvertTo-Json -InputObject $obj -Compress))
    exit $Code
}

$Root = Split-Path -Parent $PSScriptRoot            # release 包根
$Install = Join-Path $Root 'install.ps1'
$Uninstall = Join-Path $Root 'uninstall.ps1'
$Verify = Join-Path $Root 'verify.ps1'
if (-not (Test-Path -LiteralPath $Install))   { Write-Host ('install.ps1 缺失：' + $Install); Emit-Fail -Stage 'selftest' -Cause 'PRECONDITION' -Detail ('install.ps1 缺失：' + $Install) -Code 2 }
if (-not (Test-Path -LiteralPath $Uninstall)) { Write-Host ('uninstall.ps1 缺失：' + $Uninstall); Emit-Fail -Stage 'selftest' -Cause 'PRECONDITION' -Detail ('uninstall.ps1 缺失：' + $Uninstall) -Code 2 }
if (-not (Test-Path -LiteralPath $Verify))    { Write-Host ('verify.ps1 缺失：' + $Verify); Emit-Fail -Stage 'selftest' -Cause 'PRECONDITION' -Detail ('verify.ps1 缺失：' + $Verify) -Code 2 }

# 透传给 install/verify 的 node 解析参数
$ExtraArgs = @()
if ($DshHome -ne '') { $ExtraArgs += @('-DshHome', $DshHome) }
if ($NodeExe -ne '') { $ExtraArgs += @('-NodeExe', $NodeExe) }

$TempDir = Join-Path $env:TEMP ('dsh-lean-selftest-' + [guid]::NewGuid().ToString('N'))
$Synth = Join-Path $TempDir 'cordis.patch.yml'
$steps = @()

function Add-Step { param($Name, $Pass, $ExitCode, $Detail) $script:steps += [ordered]@{ name = $Name; pass = [bool]$Pass; exitCode = $ExitCode; detail = $Detail } }
function Get-NodeLine { param($Out) if ($Out -match 'node 解析：(.+)') { return $Matches[1].Trim() }; return '' }
function Get-TriedInfo {
    param($Out)
    $lines = ($Out -split "`n" | Where-Object { $_ -match '候选 |原因:|探测 node 全部失败|失败原因' })
    if ($lines.Count -eq 0) { return '' }
    return ($lines -join ' | ')
}
function Run-Ps { param($Script) $out = & powershell -ExecutionPolicy Bypass -NoProfile -File $Script 2>&1 | Out-String; $code = $LASTEXITCODE; return @{ out = $out; code = $code } }

# 为第 6 步解析一个「能跑 node 脚本」的可执行文件（与 install/verify 同款候选顺序，含 Electron 主程序回退）。
# 仅用于运行 schema-preflight.cjs --print-version，不写任何文件。
function Resolve-NodeForSelfTest {
    param([string]$Explicit, [string]$DshHome)
    if ($Explicit -ne '') { return @{ path = $Explicit; isElectron = ($Explicit -match 'DeepSeek.*Harness.*\.exe') } }
    if ($DshHome -ne '') {
        $base = $DshHome.TrimEnd('\').TrimEnd('/')
        $cands = @(
            "$base\resources\runtime\bin\node.exe",
            # 【2026-10-21 主管修】补上 primary-runtime 候选（与 install.ps1 同序）。
            # 缺这两条会在标准 DSH 布局上误选 DeepSeek Harness.exe，导致 --print-version 输出不可解析。
            "$base\resources\runtime\primary-runtime\dependencies\node\node.exe",
            "$base\resources\runtime\primary-runtime\dependencies\node\bin\node.exe",
            "$base\resources\runtime\node.exe",
            "$base\DeepSeek Harness.exe"
        )
        foreach ($c in $cands) {
            if (Test-Path -LiteralPath $c -PathType Leaf) { return @{ path = $c; isElectron = ($c -match 'DeepSeek.*Harness.*\.exe') } }
        }
        $pn = Get-ChildItem -LiteralPath $base -Filter 'DeepSeek*Harness*.exe' -File -ErrorAction SilentlyContinue | Select-Object -First 1
        if ($pn) { return @{ path = $pn.FullName; isElectron = $true } }
    }
    $cmd = Get-Command node -ErrorAction SilentlyContinue
    if ($cmd) { return @{ path = $cmd.Source; isElectron = $false } }
    return @{ path = $null; isElectron = $false }
}

try {
    New-Item -ItemType Directory -Path $TempDir -Force | Out-Null

    # 合成 patch（极简，仅含一个 - insert: 块，供 install 锚定；不含任何真实配置）
    $content = @'
# 合成 patch（selftest 专用，非真实配置）
- insert:
  - id: preset-dummy
    name: '@deepseek-ai/dsh-dummy'
    config: {}
'@
    [System.IO.File]::WriteAllText($Synth, $content, (New-Object System.Text.UTF8Encoding $false))
    $beforeHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $Synth).Hash

    # ---- Step 1：DryRun 零写入 ----
    $h1 = (Get-FileHash -Algorithm SHA256 -LiteralPath $Synth).Hash
    $r = & powershell -ExecutionPolicy Bypass -NoProfile -File $Install -ProfilePatch $Synth -RuntimeVersion '0.2.1-rc.2' -AllowUnknownRuntime -DryRun @ExtraArgs 2>&1 | Out-String
    $code1 = $LASTEXITCODE
    $h2 = (Get-FileHash -Algorithm SHA256 -LiteralPath $Synth).Hash
    $zeroWrite = ($h1 -eq $h2)
    $pass1 = ($code1 -eq 0 -and $zeroWrite)
    $d1 = ("exit=$code1; sha256-before==after=$zeroWrite")
    $nl1 = Get-NodeLine $r
    if ($nl1) { $d1 += ('; node=' + $nl1) }
    if (-not $pass1) { $ti = Get-TriedInfo $r; if ($ti) { $d1 += ('; tried=' + $ti) } }
    Add-Step 'install -DryRun (零写入)' $pass1 $code1 $d1

    # ---- Step 2：install exit 0 ----
    $r = & powershell -ExecutionPolicy Bypass -NoProfile -File $Install -ProfilePatch $Synth -RuntimeVersion '0.2.1-rc.2' -AllowUnknownRuntime @ExtraArgs 2>&1 | Out-String
    $code2 = $LASTEXITCODE
    $afterInstallHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $Synth).Hash
    $changed = ($afterInstallHash -ne $beforeHash)
    $hasBoth = (Select-String -LiteralPath $Synth -Pattern 'preset-token-lean' -Quiet) -and (Select-String -LiteralPath $Synth -Pattern 'preset-scout' -Quiet)
    $pass2 = ($code2 -eq 0 -and $changed -and $hasBoth)
    $d2 = ("exit=$code2; 文件已变更=$changed; 含两段preset=$hasBoth")
    $nl2 = Get-NodeLine $r
    if ($nl2) { $d2 += ('; node=' + $nl2) }
    if (-not $pass2) { $ti = Get-TriedInfo $r; if ($ti) { $d2 += ('; tried=' + $ti) } }
    Add-Step 'install (写入+校验)' $pass2 $code2 $d2

    # ---- Step 3：verify 12/12 ----
    $r = & powershell -ExecutionPolicy Bypass -NoProfile -File $Verify @ExtraArgs 2>&1 | Out-String
    $code3 = $LASTEXITCODE
    $twelve = ($r -match 'TOTAL=12 PASS=12 FAIL=0')
    $pass3 = ($code3 -eq 0 -and $twelve)
    $d3 = ("exit=$code3; 12/12=$twelve")
    $nl3 = Get-NodeLine $r
    if ($nl3) { $d3 += ('; node=' + $nl3) }
    if (-not $pass3) { $ti = Get-TriedInfo $r; if ($ti) { $d3 += ('; tried=' + $ti) } }
    Add-Step 'verify (12/12)' $pass3 $code3 $d3

    # ---- Step 4：uninstall → sha256 回到装前 ----
    $r = & powershell -ExecutionPolicy Bypass -NoProfile -File $Uninstall -ProfilePatch $Synth 2>&1 | Out-String
    $code4 = $LASTEXITCODE
    $afterHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $Synth).Hash
    $restored = ($afterHash -eq $beforeHash)
    $gone = -not ((Select-String -LiteralPath $Synth -Pattern 'preset-token-lean' -Quiet) -or (Select-String -LiteralPath $Synth -Pattern 'preset-scout' -Quiet))
    $pass4 = ($code4 -eq 0 -and $restored -and $gone)
    Add-Step 'uninstall (sha256 回装前)' $pass4 $code4 ("exit=$code4; sha256回装前=$restored; 两段已移除=$gone")

    # ---- Step 5：版本门禁负向（0.9.9 应拒绝且零写入） ----
    $Synth2 = Join-Path $TempDir 'cordis2.patch.yml'
    [System.IO.File]::WriteAllText($Synth2, $content, (New-Object System.Text.UTF8Encoding $false))
    $h1b = (Get-FileHash -Algorithm SHA256 -LiteralPath $Synth2).Hash
    $r = & powershell -ExecutionPolicy Bypass -NoProfile -File $Install -ProfilePatch $Synth2 -RuntimeVersion '0.9.9' @ExtraArgs 2>&1 | Out-String
    $code5 = $LASTEXITCODE
    $h2b = (Get-FileHash -Algorithm SHA256 -LiteralPath $Synth2).Hash
    $zero5 = ($h1b -eq $h2b)
    $pass5 = ($code5 -ne 0 -and $zero5)
    $d5 = ("exit=$code5; 文件未改=$zero5")
    $nl5 = Get-NodeLine $r
    if ($nl5) { $d5 += ('; node=' + $nl5) }
    if (-not $pass5) { $ti = Get-TriedInfo $r; if ($ti) { $d5 += ('; tried=' + $ti) } }
    Add-Step '版本门禁负向 (0.9.9 应拒绝)' $pass5 $code5 $d5

    # ---- Step 6：版本探测优先级 (runtime.json 优先于 version) ----
    # 在 %TEMP% 构造合成 DSH 树：primary-runtime/runtime.json 写 desktopVersion，
    # 根 version 写 44.7.0（模拟 Electron 版本文件）。断言探测优先取 runtime.json，绝不取根 version。
    $SynthDsh = Join-Path $TempDir 'fake-dsh'
    $rjDir = Join-Path $SynthDsh 'resources\runtime\primary-runtime'
    New-Item -ItemType Directory -Path $rjDir -Force | Out-Null
    [System.IO.File]::WriteAllText((Join-Path $rjDir 'runtime.json'), '{"desktopVersion":"0.2.1-rc.2"}', (New-Object System.Text.UTF8Encoding $false))
    [System.IO.File]::WriteAllText((Join-Path $SynthDsh 'version'), '44.7.0', (New-Object System.Text.UTF8Encoding $false))

    $nr = Resolve-NodeForSelfTest -Explicit $NodeExe -DshHome $DshHome
    $pass6 = $false; $code6 = $null; $d6 = ''
    if ($nr.path) {
        $prevEnv = $env:ELECTRON_RUN_AS_NODE
        if ($nr.isElectron) { $env:ELECTRON_RUN_AS_NODE = '1' }
        try {
            $pvOut = & $nr.path (Join-Path $Root 'tools/schema-preflight.cjs') --print-version --dsh-home $SynthDsh 2>$null
            $pvJson = ($pvOut -join "`n")
            $pv = $pvJson | ConvertFrom-Json -ErrorAction SilentlyContinue
            if ($pv) {
                $pass6 = ($pv.selected -eq '0.2.1-rc.2' -and $pv.source -eq 'primary-runtime/runtime.json' -and $pv.selected -ne '44.7.0')
                $d6 = ('detected=' + $pv.selected + '; source=' + $pv.source + '; electronGuess=' + $pv.evidence.electronVersionGuess)
            } else {
                $d6 = '无法解析 --print-version 输出'
            }
        } catch {
            $d6 = ('异常: ' + $_.Exception.Message)
        } finally {
            if ($nr.isElectron) {
                if ($null -eq $prevEnv) { Remove-Item env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue }
                else { $env:ELECTRON_RUN_AS_NODE = $prevEnv }
            }
        }
        $code6 = $LASTEXITCODE
    } else {
        $d6 = '未解析到 node（需 -DshHome 或 -NodeExe 或 PATH node 才能运行 --print-version）'
    }
    Add-Step '版本探测优先级 (runtime.json 优先于 version)' $pass6 $code6 $d6

} catch {
    Add-Step 'exception' $false 1 ($_.Exception.Message)
} finally {
    if (Test-Path -LiteralPath $TempDir) { Remove-Item -LiteralPath $TempDir -Recurse -Force -ErrorAction SilentlyContinue }
}

$ok = $true
foreach ($s in $steps) { if (-not $s.pass) { $ok = $false } }
$result = [ordered]@{
    ok = $ok
    steps = $steps
    exitCode = if ($ok) { 0 } else { 1 }
}
Write-Host (ConvertTo-Json $result -Depth 4)

if (-not $ok) {
    Write-Host @'
[selftest 失败] 常见原因与可复制修复命令：
  · 干净机器无 node：传 -DshHome 让脚本自动探测 Electron 主程序（DeepSeek Harness.exe）：
      powershell -ExecutionPolicy Bypass -File .\tools\selftest.ps1 -DshHome "<DSH安装目录>"
  · 或显式指定 Electron 主程序当 node：
      powershell -ExecutionPolicy Bypass -File .\tools\selftest.ps1 -NodeExe "<DSH安装目录>\DeepSeek Harness.exe"
  · 先排障：powershell -ExecutionPolicy Bypass -File .\tools\runtime-probe.ps1 -DshHome "<DSH安装目录>"
若用 Electron 主程序当 node，脚本会自动设置 ELECTRON_RUN_AS_NODE=1。
'@
    $failedNames = (@($steps | Where-Object { -not $_.pass } | ForEach-Object { $_.name }) -join '；')
    Emit-Fail -Stage 'selftest' -Cause 'PRECONDITION' -Detail ('失败步骤：' + $failedNames) -Code 1
}
exit $result.exitCode
