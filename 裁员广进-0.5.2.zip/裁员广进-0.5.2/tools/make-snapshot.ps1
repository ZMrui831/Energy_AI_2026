﻿# make-snapshot.ps1 —— 生成确定性截断测试快照（0.4.1）
#
# 用法：
#   powershell -ExecutionPolicy Bypass -File .\tools\make-snapshot.ps1 -Out <path> [-Lines 1200] [-Seed 20261021]
#                                                                      [-MarkStart 900] [-MarkCount 11] [-MarkStep 1]
#
# 约定：
#   * 每行固定格式：L0001|k=<8 位十六进制>|v=<seed 派生数>；行号补零到 4 位。
#   * 标记行：行号从 -MarkStart 起、步长 -MarkStep、共 -MarkCount 个行，额外带 |MARK-<行号>。
#     默认（900 / 11 / 1）＝第 900–910 行连续标记（老口径，docs/79）。
#     grep 上限测试口径（docs/82）：500 / 200 / 10 → 行号 500,510,…,2490，共 200 个。
#   * 输出 UTF-8 **无 BOM**、**LF 行尾**、**末行有换行**；生成后打印 sha256 与行数。
#   * 输出 UTF-8 **无 BOM**、**LF 行尾**、**末行有换行**；生成后打印 sha256 与行数。
#   * 完全确定性：同一 -Seed 两次运行，内容与 sha256 一致（k/v 由 SHA256(seed:行号) 派生）。
# 本脚本不含任何构建机绝对路径。

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Out,
    [int]$Lines = 1200,
    [int]$Seed = 20261021,
    # 【2026-10-22 主管加】标记区间可配置：默认 900–910（老口径，docs/79）。
    # 要测"字节上限"必须让目标行超出 readMaxBytes，把 MarkStart 调到 2500 并 -Lines 3000 即可。
    [int]$MarkStart = 900,
    [int]$MarkCount = 11,
    # 【2026-10-22 主管加】标记步长：默认 1（连续）。
    # grep 上限测试口径：-MarkStart 500 -MarkCount 200 -MarkStep 10 → 行号 500,510,…,2490，共 200 个（docs/82）。
    [int]$MarkStep = 1
)
if ($MarkStep -lt 1) { throw '-MarkStep 必须 >= 1' }
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$sha = [System.Security.Cryptography.SHA256]::Create()
$sb = New-Object System.Text.StringBuilder
try {
    for ($i = 1; $i -le $Lines; $i++) {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes(('{0}:{1}' -f $Seed, $i))
        $hash = $sha.ComputeHash($bytes)
        $hex = -join ($hash[0..3] | ForEach-Object { $_.ToString('x2') })
        $u = [BitConverter]::ToUInt32($hash, 0)
        $v = [int]($u % 900000) + $Seed
        $line = ('L{0:D4}|k={1}|v={2}' -f $i, $hex, $v)
        $off = $i - $MarkStart
        if ($off -ge 0 -and ($off % $MarkStep) -eq 0 -and $off -lt ($MarkCount * $MarkStep)) {
            $line = $line + ('|MARK-{0:D4}' -f $i)
        }
        [void]$sb.Append($line).Append("`n")
    }
} finally {
    $sha.Dispose()
}

$enc = New-Object System.Text.UTF8Encoding $false
[System.IO.File]::WriteAllText($Out, $sb.ToString(), $enc)

$h = (Get-FileHash -Algorithm SHA256 -LiteralPath $Out).Hash.ToLower()
$cnt = @(Get-Content -LiteralPath $Out).Count
Write-Host ('已生成快照：' + $Out)
Write-Host ('行数：' + $cnt)
Write-Host ('sha256：' + $h)
