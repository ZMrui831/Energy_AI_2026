﻿# regen-manifest.ps1 —— 重新生成 MANIFEST.json（遍历 release 目录，计算 SHA256）
#
# 用法：
#   powershell -ExecutionPolicy Bypass -File .\tools\regen-manifest.ps1 [-Root <release 目录>]
#
# 说明：
#   * 默认 Root = 脚本上级目录（即 release 包根）；
#   * MANIFEST.json 自身不列入 files；
#   * source/identicalToSource/note 三列来自脚本内置的来源对照表（相对路径，不含本机绝对路径）；
#   * 输出 UTF-8（无 BOM）JSON，字段与打包时一致：generatedAt / targetRuntime / files / excluded。
# 本脚本不含任何构建机绝对路径。

[CmdletBinding()]
param(
    [string]$Root = ''
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if ($Root -eq '') { $Root = Split-Path -Parent $PSScriptRoot }
$manifestPath = Join-Path $Root 'MANIFEST.json'

# 来源对照表：release 相对路径 → @{ source = 相对来源; identical = 是否逐字一致; note = 备注 }
# $null source 表示本包新建。
$Provenance = @{
    'README.md'                      = @{ source = $null; note = '本包新建（0.3.0：四步安装 + 自证 + node 自动探测 v2（含 Electron 回退）+ 版本门禁；0.3.2：Electron 主程序当 node）' }
    'EVAL-GUIDE.md'                  = @{ source = $null; note = '本包新建（0.3.0：同步四步法 + selftest + 新版 verify 默认 12/12；0.3.2：node 自动探测 v2 + Electron 回退 + 报告模板加 node 解析行）' }
    'CHANGELOG.md'                   = @{ source = $null; note = '本包新建（变更与自检摘要，含 0.3.0 G1–G6 与 0.3.2 P0 修复）' }
    'LICENSE'                        = @{ source = $null; note = '本包新建（G6：MIT 许可声明）' }
    'THIRD-PARTY-NOTICES.md'         = @{ source = $null; note = '本包新建（G6：js-yaml 4.3.2 MIT 原文与版本）' }
    'LICENSE-NOTES.md'               = @{ source = $null; note = '本包新建（第三方组件许可说明，F3.4；0.3.2：运行依赖补 ELECTRON_RUN_AS_NODE 说明）' }
    'install.ps1'                    = @{ source = $null; note = '本包新建（0.2.0-fix1：F1/F2/F4/F5/F6；0.3.0：G1 node 自动探测 / G2 锁+原子写 / G4 版本预检；0.3.2：G1 Resolve-NodeExe v2（Electron 回退 + --version 候选验证））' }
    'verify.ps1'                     = @{ source = $null; note = '本包新建（0.2.0-fix1：F7；0.3.0：G1 默认 7/7·12/12 + -StrictSchema / G5 优先 mini schema；0.3.2：G1 Resolve-NodeExe v2 同款 + -DshHome）' }
    'uninstall.ps1'                  = @{ source = $null; note = '本包新建（0.2.0-fix1：F5 字节保真；0.3.0：G2 锁+原子写 / G6 -PurgeBackups）' }
    'presets/token-lean.yml'         = @{ source = 'bundle-甲/presets/token-lean.yml'; identical = $false; note = '受控改写：仅"# 来源："注释行脱敏' }
    'presets/scout.yml'              = @{ source = 'bundle-甲/presets/scout.yml'; identical = $false; note = '受控改写：仅"# 来源："注释行脱敏' }
    'tools/schema-preflight.cjs'     = @{ source = 'tools/schema-preflight.cjs'; identical = $false; note = '受控改写：loadYaml(DSH_PROFILE_DIR→vendor→require) + schema 可选降级 + G4 键表抽到 vendor/keys + 版本探测/--version-check/--dsh-home/--allow-unknown-runtime' }
    'tools/run-fixtures.cjs'         = @{ source = 'tools/run-fixtures.cjs'; identical = $false; note = '受控改写：--no-type 与 schema 可选（F7）、stdio 文件描述符（F8）、G5 调用工具时加 --allow-unknown-runtime' }
    'tools/selftest.ps1'             = @{ source = $null; note = '本包新建（G5：%TEMP% 合成 patch 全流程自证，绝不碰真实 cordis.patch.yml；0.3.2：透传 -DshHome/-NodeExe、每步 detail 追加 node 解析、新增第 5 步版本门禁负向）' }
    'tools/regen-manifest.ps1'       = @{ source = $null; note = '本包新建（MANIFEST 重算，含 0.3.0/0.3.2 新增文件来源）' }
    'tools/runtime-probe.ps1'        = @{ source = $null; note = '本包新建（0.3.2：只读 node 候选探测排障，输出 JSON，不写文件不改配置）' }
    'tools/make-snapshot.ps1'        = @{ source = $null; note = '本包新建（0.4.1：确定性截断快照生成器，第 900–910 行含 MARK 标记）' }
    'tools/score-truncation.ps1'     = @{ source = $null; note = '本包新建（0.4.1：截断质量自动评分器；0.4.2：mentionsOffset 补检测 + 智能编码读取）' }
    'tools/score-scan.ps1'           = @{ source = $null; note = '本包新建（0.4.2：全量扫描自动评分器，MARK 集合 found/missing/extra，编造判 exit 1）' }
    'build/repackage.ps1'            = @{ source = $null; note = '本包新建（G6：dist\ 打包 + sha256）' }
    'vendor/keys/0.2.1-rc.2.json'    = @{ source = $null; note = '本包新建（G4：从 schema-preflight.cjs 抽出的权威键表/类型/必填/已删键）' }
    'fixtures/schema.mini.json'      = @{ source = $null; note = '本包新建（G5：真实 schema 抽取 4 插件 if/then + $defs，13.9KB，无本机路径）' }
    'docs/70-P0执行包.md'            = @{ source = '70-P0执行包.md'; identical = $true; note = '逐字复制' }
    'docs/71-坑清单16-28.md'         = @{ source = '71-坑清单16-28.md'; identical = $true; note = '逐字复制（坑 27 依据已脱敏）' }
    'docs/72-清理清单.md'            = @{ source = '72-清理清单.md'; identical = $true; note = '逐字复制（本就为脱敏口径书写）' }
    'docs/73-可适配经验.md'          = @{ source = '73-可适配经验.md'; identical = $true; note = '逐字复制' }
    'docs/74-修复说明.md'            = @{ source = $null; note = '本包新建（F1–F9 修复说明）' }
    'docs/75-企业级改造说明.md'       = @{ source = $null; note = '本包新建（G1–G6 逐项改造说明 + 门槛对照；0.3.2：追加 §G1 补充 Electron 回退）' }
    'docs/76-0.3.2修复说明.md'        = @{ source = $null; note = '本包新建（0.3.2：P0 根因→改法→自检点→待主管实测）' }
    'docs/77-0.3.3修复说明.md'        = @{ source = $null; note = '本包新建（0.3.3：P1 版本探测误判根因→改法→自检点→待主管实测）' }
    'docs/78-0.4.0改造说明.md'        = @{ source = $null; note = '本包新建（0.4.0：假文案↔真实行为对照 + 大文件质量 + 降噪 + 吸收 ops 两条 + 泛化规范）' }
    'docs/79-截断质量测试.md'         = @{ source = $null; note = '本包新建（0.4.0：第 4 题执行包——标准/广进两组题 + 判分口径）' }
    'docs/80-私人agent省钱契约.md'    = @{ source = $null; note = '本包新建（0.4.0：6 规则 + 8 栈映射 + 3 指标 + 不适用；面向非 DSH 自建 agent）' }
    'docs/81-全量扫描测试.md'          = @{ source = $null; note = '本包新建（0.4.2：全量扫描硬变体——MARK 集合比对 + 四种判分，编造最高优先级）' }
    'docs/82-grep上限测试.md'          = @{ source = $null; note = '本包新建（0.4.3：grep 上限测试——是否把 grepMaxMatches 当总数；疑似命中上限 + declaresCap）' }
    'docs/COMPATIBILITY.md'          = @{ source = $null; note = '本包新建（G6：版本/键表/支持矩阵；0.3.2：新增实测环境行）' }
    # ---- 0.5.0：kit（与框架无关的省钱契约套件，零依赖、零框架耦合） ----
    'kit/policy.schema.json'         = @{ source = $null; note = '本包新建（0.5.0：policy.json 的 JSON Schema draft-07 子集，字段名照抄规范）' }
    'kit/policy.example.json'        = @{ source = $null; note = '本包新建（0.5.0：把"裁员广进"封顶语义翻成纯 JSON 示例）' }
    'kit/policy-lint.mjs'            = @{ source = $null; note = '本包新建（0.5.0：六条契约可判定器 C1–C8 + 观测 E1，仅用 Node 内置模块）' }
    'kit/prompt-pagination.md'      = @{ source = $null; note = '本包新建（0.5.0：可直接粘进任意 system prompt 的中/英分页·截断诚实契约文本）' }
    'kit/portability.md'             = @{ source = $null; note = '本包新建（0.5.0：8 个主流框架的挂载点对照表，片段 ≤3 行）' }
    'kit/README.md'                 = @{ source = $null; note = '本包新建（0.5.0：kit 3 分钟上手 + 与模式包关系 + 不适用场景）' }
    'kit/eval/summarize-calls.mjs'  = @{ source = $null; note = '本包新建（0.5.0：观测日志汇总——截断率/上报率/token 成本代理；0.5.1 复用 lib）' }
    'kit/eval/sample.jsonl'         = @{ source = $null; note = '本包新建（0.5.0：≥6 行观测样例，覆盖未截断/截断报总数/截断不报总数/grep 命中上限）' }
    'kit/eval/lib/summarize.mjs'    = @{ source = $null; note = '本包新建（0.5.1：观测统计共用库，导出 summarize(records) 与 FIXTURE_RECORDS，policy-lint 与 summarize-calls 共用）' }
}

$ExcludedReasons = @(
    @{ path = '50–62 号历史文档（项目根）'; reason = '含本机路径，留在原机，未随包分发' },
    @{ path = '72a-cleanup.ps1（项目根）'; reason = '本机清理脚本，含本机绝对路径，不分发' },
    @{ path = '_schema-desktop.json（项目根）'; reason = '机器生成物；目标机须自行用非 desktop profile 导出' },
    @{ path = 'drift-drill-report.json（项目根）'; reason = '本机实测产物，非安装内容' },
    @{ path = 'tools/drift-drill.cjs（项目 tools/）'; reason = '演练器，依赖本机 schema 环境输入，非安装内容' },
    @{ path = 'tools/preset-check.mjs、tools/preset-config-validate.mjs（项目 tools/）'; reason = '依赖本机环境的历史校验器，未随包' },
    @{ path = 'bundle-甲/apply.ps1、rollback.ps1、INSTALL.md'; reason = '硬编码本机路径，已被本包参数化三脚本取代' },
    @{ path = 'dist\（build 输出）'; reason = 'repackage.ps1 生成的 zip/sha256 是分发物，不计入包内文件清单' },
    @{ path = '*.bak-* 备份文件'; reason = '安装/卸载产生的临时备份，不随包分发' }
)

# ---- 遍历 release 目录 ----
# 【2026-10-21 主管修】原来只把 dist/ 写进 excluded 说明，枚举时并未跳过 → 会把 zip/sha256 计入清单，
# 导致清单条数 > 实际包内文件数。这里真正排除：dist/、*.bak-*、*.lock、*.tmp-*、*.lean-journal.json。
$allFiles = @(Get-ChildItem -LiteralPath $Root -Recurse -File | Where-Object {
    $_.FullName -ne $manifestPath -and
    $_.FullName -notmatch '[\\/]dist[\\/]' -and
    $_.Name -notmatch '\.bak-' -and
    $_.Name -notmatch '\.lock$' -and
    $_.Name -notmatch '\.tmp-' -and
    $_.Name -notmatch '\.lean-journal\.json$'
})
$files = @()
foreach ($f in $allFiles) {
    $rel = $f.FullName.Substring($Root.Length + 1).Replace('\', '/')
    $entry = @{
        path   = $rel
        bytes  = $f.Length
        sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $f.FullName).Hash.ToLower()
    }
    if ($Provenance.ContainsKey($rel)) {
        $pv = $Provenance[$rel]
        if ($null -ne $pv.source) {
            $entry.source = $pv.source
            $entry.identicalToSource = [bool]$pv.identical
        }
        $entry.note = $pv.note
    } else {
        $entry.note = 'vendor/运行副本（来源见 LICENSE-NOTES.md）'
        if ($rel -like 'vendor/js-yaml/*') {
            $entry.source = 'node_modules/js-yaml/' + $rel.Substring('vendor/js-yaml/'.Length)
            $entry.identicalToSource = $true
            $entry.note = 'js-yaml 4.3.2 原样复制（MIT，未改动源码）'
        }
    }
    $files += $entry
}

$manifest = [ordered]@{
    generatedAt   = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:sszzz')
    targetRuntime = '0.2.1-rc.2'
    files         = $files
    excluded      = $ExcludedReasons
}
$json = $manifest | ConvertTo-Json -Depth 5
[System.IO.File]::WriteAllText($manifestPath, $json + "`n", (New-Object System.Text.UTF8Encoding $false))
Write-Host ('MANIFEST.json regenerated: files=' + $files.Count + ' excluded=' + $ExcludedReasons.Count)
