#!/usr/bin/env node
//【release 版说明】
//  * 权威键表（plugins/required/types/deprecated）按版本抽到 vendor/keys/<version>.json；
//    工具按 -RuntimeVersion 或探测到的版本读取对应键表，文件缺失且未加 -AllowUnknownRuntime 则拒绝。
//  * js-yaml 解析优先级：DSH_PROFILE_DIR → 包内置 vendor/js-yaml（MIT 4.3.2）→ require('js-yaml')。
//  * schema 可选：缺失时降级为仅权威键表（键表）判定——供 verify.ps1 的 PARTIAL / mini 路径。
// schema-preflight.cjs —— C：Schema 漂移预检器（含版本契约 G4）
//
// 目的：在**安装/重启之前**，把「preset 里用了运行时不存在的字段」这类会导致整模式加载失败的错误
// 变成一条 FAIL。本项目因 persona / toolFilter / backgroundMode 三个已删字段连续崩了三次，
// 现有校验器（preset-check / preset-config-validate）全部漏报，因为它们是"按已知 schema 校验"，
// 而这个工具是"按**运行中运行时导出的真实 schema** 校验"。
//
// 用法：
//   第一步（生成权威 schema，必须用桌面运行时，不能用 npm 0.1.7）：
//     cmd /c ""<dsh.cmd>" <profile> --dump-config-schema > schema.json 2>nul"
//   第二步：
//     node schema-preflight.cjs --preset <cordis.patch.yml> [--schema schema.json] [--json]
//                              [--runtime-version <v>] [--dsh-home <dir>] [--allow-unknown-runtime]
//                              [--version-check] [--list-versions] [--print-version] [--batch <spec.json>]
//
//  --batch <spec.json>：把 install 的多步预检合并为一次调用（PTC 思路）。
//     spec 形态：{ "tasks": [ { "task": "version-check"|"preset"|"print-version"|"list-versions",
//       "preset": "<yml>", "runtimeVersion": "<v>", "dshHome": "<dir>", "allowUnknownRuntime": bool,
//       "schema": "<json>", "profilePackage": "<json>", "json": bool } ] }
//     输出统一 JSON：{ "ok", "exitCode", "results": [ { "task","ok","exitCode","stdout","stderr","cause" } ] }。
//     失败区分到子任务（cause 枚举与单跑一致）；整体退出码 = 失败子任务退出码的最大值。
//
// 退出码：0 = OK；1 = 有 FAIL；2 = 用法/读取错误；3 = 版本契约拒绝（未知版本 / 不支持版本）
//
// 已知限制（诚实声明）：
//   * 只校验「键是否存在 / 是否必填」，不做完整 JSON Schema 递归校验（类型、anyOf 一律跳过）。
//   * 若某插件在 schema 里找不到，按 UNKNOWN_PLUGIN 报 FAIL（宁可误报，不可漏报）。

'use strict';
const fs = require('fs');
const path = require('path');
const { createRequire } = require('module');
const { spawnSync } = require('child_process');

const BUNDLED_DEFAULT_VERSION = '0.2.1-rc.2';

// ---------- 参数 ----------
const argv = process.argv.slice(2);
const opt = {
  preset: null, schema: null, json: false, runtimeVersion: null,
  profilePackage: null, dshHome: null, allowUnknownRuntime: false,
  versionCheck: false, listVersions: false, printVersion: false, batch: null,
};
for (let i = 0; i < argv.length; i++) {
  const a = argv[i];
  if (a === '--preset') opt.preset = argv[++i];
  else if (a === '--schema') opt.schema = argv[++i];
  else if (a === '--json') opt.json = true;
  else if (a === '--runtime-version') opt.runtimeVersion = argv[++i];
  else if (a === '--dsh-home') opt.dshHome = argv[++i];
  else if (a === '--allow-unknown-runtime') opt.allowUnknownRuntime = true;
  else if (a === '--version-check') opt.versionCheck = true;
  else if (a === '--list-versions') opt.listVersions = true;
  else if (a === '--print-version') opt.printVersion = true;
  else if (a === '--batch') opt.batch = argv[++i];
  else if (a === '--profile-package') opt.profilePackage = argv[++i];
  else if (a === '--list-schema-names') { /* 后面单独处理，这里只放行 */ }
  else if (a === '-h' || a === '--help') { console.log(fs.readFileSync(__filename, 'utf8').split('\n').slice(1, 30).join('\n')); process.exit(0); }
  else { console.error('未知参数：' + a); process.exit(2); }
}
// 版本自检 / 列表模式允许无 -preset；其余模式 -preset 必填（--batch 也不需顶层 -preset）
if (!opt.batch && !opt.preset && !opt.versionCheck && !opt.listVersions && !opt.printVersion) {
  console.error('用法：node schema-preflight.cjs --preset <yml> [--schema <json>] [--json] [--runtime-version <v>] [--dsh-home <dir>] [--allow-unknown-runtime] [--version-check] [--list-versions] [--print-version]');
  process.exit(2);
}

// ---------- 版本契约（G4）----------
function keysDir() { return path.join(__dirname, '..', 'vendor', 'keys'); }
function listAvailableVersions() {
  try { return fs.readdirSync(keysDir()).filter((f) => f.endsWith('.json')).map((f) => f.slice(0, -5)); }
  catch { return []; }
}

// 从 DSH 安装目录探测「DSH 运行时版本」（**不是** Electron 版本）。
// 候选顺序（命中即返回，并记录 source 与逐候选结果）：
//   1) resources/runtime/primary-runtime/runtime.json → desktopVersion
//      （该字段缺失时，再试同文件的 version / runtimeVersion，存在哪个用哪个）
//   2) resources/runtime/package.json → version
//   3) resources/runtime/node_modules/@deepseek-ai/dsh/package.json → version
//   4) 都不存在 → 返回 unknown（**绝不**读根目录 version：那是 Electron 版本，形状同样 x.y.z 无法区分）
// 根目录 version 仅作为 evidence.electronVersionGuess 参考输出，不参与判定。
function normalizeVersion(v) {
  return String(v == null ? '' : v).trim().replace(/^v/i, '');
}
function detectDshVersionDetailed(home) {
  const candidates = [];
  let electronVersionGuess = '';
  const rootVersionPath = path.join(home, 'version');
  if (fs.existsSync(rootVersionPath)) {
    try { const t = fs.readFileSync(rootVersionPath, 'utf8').trim(); if (t) electronVersionGuess = t; } catch { /* 忽略 */ }
  }
  // 候选 1：primary-runtime/runtime.json（desktopVersion 优先；缺失时退到同文件 version / runtimeVersion）
  const rjPath = path.join(home, 'resources', 'runtime', 'primary-runtime', 'runtime.json');
  let rjVal = '', rjField = '';
  if (fs.existsSync(rjPath)) {
    try {
      const rj = JSON.parse(fs.readFileSync(rjPath, 'utf8'));
      for (const fld of ['desktopVersion', 'version', 'runtimeVersion']) {
        if (rj && typeof rj[fld] === 'string' && rj[fld].trim()) { rjVal = rj[fld].trim(); rjField = fld; break; }
      }
    } catch { /* 忽略 */ }
  }
  candidates.push({
    path: rjPath, exists: fs.existsSync(rjPath), value: rjVal,
    reason: rjVal ? ('字段 ' + rjField + ' 命中') : (fs.existsSync(rjPath) ? 'desktopVersion/version/runtimeVersion 均无可用值' : '文件不存在'),
  });
  if (rjVal) return { version: rjVal, source: 'primary-runtime/runtime.json', candidates, electronVersionGuess };
  // 候选 2：resources/runtime/package.json → version
  const pjPath = path.join(home, 'resources', 'runtime', 'package.json');
  let pjVal = '';
  if (fs.existsSync(pjPath)) {
    try { const pj = JSON.parse(fs.readFileSync(pjPath, 'utf8')); if (pj && typeof pj.version === 'string' && pj.version.trim()) pjVal = pj.version.trim(); } catch { /* 忽略 */ }
  }
  candidates.push({
    path: pjPath, exists: fs.existsSync(pjPath), value: pjVal,
    reason: pjVal ? 'version 命中' : (fs.existsSync(pjPath) ? 'version 字段无可用值' : '文件不存在'),
  });
  if (pjVal) return { version: pjVal, source: 'resources/runtime/package.json', candidates, electronVersionGuess };
  // 候选 3：resources/runtime/node_modules/@deepseek-ai/dsh/package.json → version
  const dshPath = path.join(home, 'resources', 'runtime', 'node_modules', '@deepseek-ai', 'dsh', 'package.json');
  let dshVal = '';
  if (fs.existsSync(dshPath)) {
    try { const pj = JSON.parse(fs.readFileSync(dshPath, 'utf8')); if (pj && typeof pj.version === 'string' && pj.version.trim()) dshVal = pj.version.trim(); } catch { /* 忽略 */ }
  }
  candidates.push({
    path: dshPath, exists: fs.existsSync(dshPath), value: dshVal,
    reason: dshVal ? 'version 命中' : (fs.existsSync(dshPath) ? 'version 字段无可用值' : '文件不存在'),
  });
  if (dshVal) return { version: dshVal, source: 'resources/runtime/node_modules/@deepseek-ai/dsh/package.json', candidates, electronVersionGuess };
  // 全部不命中 → unknown（根目录 version 仅作 evidence，不用作版本来源）
  return { version: '', source: 'unknown', candidates, electronVersionGuess };
}
// 兼容旧调用：只返回版本字符串（命中即返回，绝不包含根目录 Electron version）
function detectDshVersion(home) {
  return detectDshVersionDetailed(home).version;
}

// 解析版本 + 键表：返回 { version, keytable }，无法解析且未授权则直接 process.exit(3)
function resolveKeytable() {
  // 归一化版本（允许前后空白与 v 前缀；与键表比较按字符串全等，不做 semver 推断）
  if (opt.runtimeVersion) opt.runtimeVersion = normalizeVersion(opt.runtimeVersion);
  let version = opt.runtimeVersion || '';
  let det = null;
  if (!version && opt.dshHome) { det = detectDshVersionDetailed(opt.dshHome); version = det.version; }
  version = normalizeVersion(version);
  if (!version) {
    if (opt.allowUnknownRuntime) {
      version = BUNDLED_DEFAULT_VERSION;
      console.error('[warn] 未提供 -RuntimeVersion 且无法从 -DshHome 探测到版本；因 -AllowUnknownRuntime 使用内置默认键表 ' + BUNDLED_DEFAULT_VERSION);
    } else {
      let msg = '无法确定运行时版本（已尝试的候选与结果）：';
      if (det) {
        for (const c of det.candidates) msg += '\n  - ' + c.path + '：exists=' + c.exists + '，value=' + (c.value || '(空)') + '，' + c.reason;
        msg += '\n  （根目录 version=' + (det.electronVersionGuess || '(无)') + ' 为 Electron 版本，形状同为 x.y.z，不参与判定）';
      }
      msg += '\n请传 -RuntimeVersion <v>，或传 -DshHome <DSH安装目录> 让其自动探测，或加 -AllowUnknownRuntime 使用内置默认键表。';
      console.error(msg);
      process.exit(3);
    }
  }
  const ktPath = path.join(keysDir(), version + '.json');
  if (fs.existsSync(ktPath)) {
    return { version, keytable: JSON.parse(fs.readFileSync(ktPath, 'utf8')) };
  }
  const avail = listAvailableVersions();
  if (opt.allowUnknownRuntime) {
    const def = path.join(keysDir(), BUNDLED_DEFAULT_VERSION + '.json');
    if (!fs.existsSync(def)) { console.error('内置默认键表缺失：' + def); process.exit(2); }
    console.error('[warn] 键表文件不存在：' + ktPath + '；因 -AllowUnknownRuntime 回退到内置默认键表 ' + BUNDLED_DEFAULT_VERSION + '（可能与实际运行时不符）');
    return { version: BUNDLED_DEFAULT_VERSION, keytable: JSON.parse(fs.readFileSync(def, 'utf8')) };
  }
  console.error('不支持的运行时版本：' + version + '。支持版本：' + (avail.length ? avail.join(', ') : '(无)') + '。请升级包或加 -AllowUnknownRuntime。');
  process.exit(3);
}

// 仅做版本契约自检（供 install.ps1 写盘前预检）
if (opt.versionCheck) {
  try { resolveKeytable(); console.log('version-check OK：版本契约通过，键表文件存在。'); process.exit(0); }
  catch (e) { console.error('version-check FAIL：' + (e && e.message ? e.message : e)); process.exit(3); }
}
if (opt.listVersions) {
  const avail = listAvailableVersions();
  console.log('可用键表版本（vendor/keys）：' + (avail.length ? avail.join(', ') : '(无)'));
  process.exit(0);
}

// 仅打印版本探测结果（供 selftest / 排障）；只读不写，退出码恒为 0
if (opt.printVersion) {
  if (!opt.dshHome) { console.error('--print-version 需要 -DshHome <DSH安装目录>'); process.exit(2); }
  const det = detectDshVersionDetailed(opt.dshHome);
  const out = {
    ok: det.version !== '',
    selected: det.version || 'unknown',
    source: det.source,
    candidates: det.candidates,
    evidence: { electronVersionGuess: det.electronVersionGuess },
  };
  console.log(JSON.stringify(out, null, 2));
  process.exit(0);
}

// ---- 批量校验（0.4.0，PTC 思路）：把 install 的多步预检合并为一次调用 ----
// 复用本文件既有单跑逻辑（子进程=同一文件），行为与原先逐次调用完全一致；
// 仅做"统一 JSON 输出 + 失败定位到子任务"，退出码语义不变。
if (opt.batch) {
  let spec;
  try {
    spec = JSON.parse(fs.readFileSync(opt.batch, 'utf8'));
  } catch (e) {
    console.log(JSON.stringify({
      ok: false, stage: 'batch', cause: 'BATCH_SPEC_ERROR',
      detail: '无法读取/解析 spec.json：' + (e && e.message ? e.message : e),
    }, null, 2));
    process.exit(2);
  }
  // 【2026-10-21 主管修】兼容两种 spec 形态：{tasks:[...]} 与裸数组 [...]。
  // install.ps1 写的是裸数组，原实现只认 spec.tasks → tasks 为空 → 报 BATCH_NO_PRESET_RESULT 并回滚。
  const tasks = Array.isArray(spec) ? spec : (Array.isArray(spec.tasks) ? spec.tasks : []);
  const results = [];
  let overallCode = 0;
  for (const t of tasks) {
    const task = t && t.task;
    const args = [];
    if (task === 'version-check') {
      if (t.preset) args.push('--preset', t.preset);
      args.push('--version-check');
      if (t.runtimeVersion) args.push('--runtime-version', String(t.runtimeVersion));
      if (t.dshHome) args.push('--dsh-home', t.dshHome);
      if (t.allowUnknownRuntime) args.push('--allow-unknown-runtime');
    } else if (task === 'preset') {
      if (t.preset) args.push('--preset', t.preset);
      if (t.schema) args.push('--schema', t.schema);
      if (t.runtimeVersion) args.push('--runtime-version', String(t.runtimeVersion));
      if (t.dshHome) args.push('--dsh-home', t.dshHome);
      if (t.allowUnknownRuntime) args.push('--allow-unknown-runtime');
      if (t.profilePackage) args.push('--profile-package', t.profilePackage);
      args.push('--json'); // 始终要结构化输出，便于抽取 cause
    } else if (task === 'print-version') {
      args.push('--print-version');
      if (t.dshHome) args.push('--dsh-home', t.dshHome);
    } else if (task === 'list-versions') {
      args.push('--list-versions');
    } else {
      results.push({ task: task || '(unknown)', ok: false, exitCode: 2, stdout: '', stderr: '', cause: 'BATCH_UNKNOWN_TASK' });
      overallCode = Math.max(overallCode, 2);
      continue;
    }
    let childOut = '', childErr = '', childCode = 0;
    try {
      const r = spawnSync(process.execPath, [__filename, ...args], { encoding: 'utf8' });
      childOut = (r.stdout || '').toString();
      childErr = (r.stderr || '').toString();
      childCode = (r.status == null) ? 2 : r.status;
    } catch (e) {
      childErr = String(e && e.message ? e.message : e);
      childCode = 2;
    }
    let ok = (childCode === 0);
    let cause = null;
    if (!ok) {
      if (task === 'version-check') cause = 'VERSION_CONTRACT_REFUSED';
      else if (task === 'preset') {
        try {
          const j = JSON.parse(childOut);
          if (j && Array.isArray(j.findings) && j.findings.length) cause = j.findings[0].cause;
          else cause = (childCode === 3 ? 'VERSION_CONTRACT_REFUSED' : 'SCHEMA_PREFLIGHT_FAIL');
        } catch { cause = (childCode === 3 ? 'VERSION_CONTRACT_REFUSED' : 'SCHEMA_PREFLIGHT_FAIL'); }
      } else if (task === 'print-version') cause = 'PRINT_VERSION_FAIL';
      else cause = 'SUBTASK_FAIL';
    }
    results.push({ task, ok, exitCode: childCode, stdout: childOut, stderr: childErr, cause });
    if (!ok) overallCode = Math.max(overallCode, childCode);
  }
  const out = { ok: overallCode === 0, exitCode: overallCode, results };
  console.log(JSON.stringify(out, null, 2));
  process.exit(overallCode);
}

// 读取类输入存在性检查（-schema 可选）
const requiredInputs = { preset: opt.preset };
if (opt.schema) requiredInputs.schema = opt.schema;
for (const [k, p] of Object.entries(requiredInputs)) {
  if (!fs.existsSync(p)) { console.error('读取失败（' + k + '）：' + p); process.exit(2); }
}

// ---------- 本文件所在项目里的 YAML 解析（带 !!js 标签）----------
function loadYaml() {
  const candidates = [];
  if (process.env.DSH_PROFILE_DIR) {
    candidates.push(path.join(process.env.DSH_PROFILE_DIR, 'package.json'));
  }
  for (const c of candidates) {
    if (!fs.existsSync(c)) continue;
    try { const req = createRequire(c); return req('js-yaml'); } catch { /* 试下一个 */ }
  }
  // release 包内置副本（MIT 4.3.2，见 vendor/js-yaml/LICENSE）：目录 require 按其 package.json main 解析
  try { return require(path.join(__dirname, '..', 'vendor', 'js-yaml')); } catch { /* 继续下一个来源 */ }
  try { return require('js-yaml'); } catch { /* 继续下一个来源 */ }
  return null;
}

// 加载权威键表（兜底到内置默认；DEPRECATED 优先取键表，缺失用内置常量）
const { keytable: CURATED } = resolveKeytable();
const DEPRECATED = (CURATED.deprecated && typeof CURATED.deprecated === 'object')
  ? CURATED.deprecated
  : { '@deepseek-ai/dsh-tool-subagent': ['persona', 'toolFilter', 'backgroundMode', 'enableRunInBackground'] };

// ---------- 解析 schema：包名 → config 子 schema ----------
function buildSchemaIndex(schemaRoot) {
  const defs = schemaRoot.$defs || {};
  const index = new Map(); // packageName -> { properties:Set, required:Set, raw }

  const resolveRef = (ref) => {
    const key = String(ref).replace('#/$defs/', '');
    return defs[key] || null;
  };
  const configOf = (node) => {
    const conf = node && node.properties && node.properties.config;
    if (!conf) return null;
    const anyOf = conf.anyOf || conf.oneOf;
    if (Array.isArray(anyOf)) {
      for (const alt of anyOf) {
        if (alt && alt.$ref) { const r = resolveRef(alt.$ref); if (r) return r; }
      }
      return null;
    }
    return conf;
  };
  const normalize = (sub) => {
    // 实测：真 schema 常常是 anyOf/allOf 组合（其中一支可能叫 unknownConfig），
    // 只读 sub.properties 会把真实键误报成 UNKNOWN_KEY（tool-fs / tool-web 就是这样被误报的）。
    const props = new Set();
    const propTypes = new Map(); // key -> { type: string | string[], enum: any[] }
    const branchRequired = [];
    const visit = (n, depth, reqOut) => {
      if (!n || typeof n !== 'object' || depth > 4) return;
      for (const k of Object.keys(n.properties || {})) {
        props.add(k);
        const ps = n.properties[k];
        if (ps && typeof ps === 'object') {
          if (Array.isArray(ps.enum)) propTypes.set(k, { enum: ps.enum });
          else if (ps.type) propTypes.set(k, { type: ps.type });
          else if (Array.isArray(ps.anyOf)) {
            const t = ps.anyOf.map((x) => x && x.type).filter(Boolean);
            if (t.length) propTypes.set(k, { type: t });
          }
        }
      }
      if (Array.isArray(n.required)) { for (const r of n.required) reqOut.add(r); }
      for (const key of ['anyOf', 'oneOf', 'allOf']) {
        if (Array.isArray(n[key])) n[key].forEach((x) => {
          if (x && x.$ref) { const r = resolveRef(x.$ref); if (r) visit(r, depth + 1, reqOut); }
          else visit(x, depth + 1, reqOut);
        });
      }
      if (n.$ref) { const r = resolveRef(n.$ref); if (r) visit(r, depth + 1, reqOut); }
    };
    const ownReq = new Set();
    visit(sub, 0, ownReq);
    branchRequired.push(ownReq);
    // 出现 unknownConfig 这种"任意键"分支时，说明该插件接受自由配置，不能按严格键校验
    const loose = JSON.stringify(sub || {}).includes('unknownConfig');
    return { properties: props, propTypes, required: ownReq, loose, raw: sub };
  };

  const items = (schemaRoot.items) || (schemaRoot.type === 'array' ? null : null);
  const allOf = (schemaRoot.allOf) || [];
  const walk = (node) => {
    if (!node) return;
    if (Array.isArray(node.allOf)) node.allOf.forEach(walk);
    if (node.if && node.then) {
      const nameConst = node.if.properties && node.if.properties.name && node.if.properties.name.const;
      if (nameConst) {
        const sub = configOf(node.then);
        if (sub) index.set(nameConst, normalize(sub));
      }
    }
    if (Array.isArray(node.oneOf)) node.oneOf.forEach(walk);
    if (Array.isArray(node.anyOf)) node.anyOf.forEach(walk);
  };

  // 顶层结构实测：{ type:'array', items:{ $ref:'#/$defs/entry' }, $defs:{ entry:{ allOf:[ {if,then}, ... ] } } }
  // 所以必须把 $defs 里的每个定义也遍历一遍（否则一条都识别不到）。
  walk(schemaRoot);
  walk(items);
  allOf.forEach(walk);
  for (const v of Object.values(defs)) walk(v);
  return index;
}

// ---------- 解析 preset：收集所有插件行 ----------
function collectRows(yaml, text) {
  const doc = yaml.load(text, { schema: yaml.DEFAULT_SCHEMA.extend([new yaml.Type('tag:yaml.org,2002:js', { kind: 'scalar' })]) });
  const rows = [];
  const visit = (node, where) => {
    if (!node) return;
    if (Array.isArray(node)) { node.forEach((n, i) => visit(n, where + '[' + i + ']')); return; }
    if (typeof node !== 'object') return;
    // 只把真正的"插件行"当行：必须同时有 id、name、config 三件套。
    // 否则会把 config.models[] 里的模型名（只有 name）、preset 的 config（有 id+name 但无 config）误当成插件。
    if (typeof node.id === 'string' && typeof node.name === 'string' &&
        node.config && typeof node.config === 'object' && !Array.isArray(node.config)) {
      rows.push({ where, id: node.id || '', name: node.name, config: node.config || {}, disabled: node.disabled });
    }
    // 递归进 insert / plugins / config.plugins
    for (const [k, v] of Object.entries(node)) {
      if (k === 'name' || k === 'id') continue;
      if (v && typeof v === 'object') visit(v, where + '.' + k);
    }
  };
  visit(doc, '$');
  return rows;
}

// !!js 标量被 js-yaml 解析为 { __jsExpr: '...' }，类型不可静态判定，类型校验须整值跳过
function isJsExpr(v) { return v && typeof v === 'object' && !Array.isArray(v) && '__jsExpr' in v; }

// ---------- 主流程 ----------
const yaml = loadYaml();
if (!yaml) { console.error('找不到 js-yaml（请先安装 js-yaml，或设置环境变量 DSH_PROFILE_DIR 指向含 node_modules 的 profile 目录）'); process.exit(2); }

let schemaRoot = null;
if (opt.schema && fs.existsSync(opt.schema)) {
  try { schemaRoot = JSON.parse(fs.readFileSync(opt.schema, 'utf8')); }
  catch (e) { console.error('schema JSON 解析失败：' + e.message); process.exit(2); }
} else {
  // F7：schema 缺失时降级为仅权威键表（键表）判定；schema 存在但结构无效仍 exit 2
  console.error('[warn] 未提供 schema 或文件不存在：仅按内置权威键表（' + (CURATED.runtime || '?') + '）判定');
}
const index = buildSchemaIndex(schemaRoot || {});
if (index.size === 0 && schemaRoot) { console.error('schema 里没有识别到任何 if/then 插件条目（结构可能变了）'); process.exit(2); }
if (process.argv.includes('--list-schema-names')) {
  console.log('schema 内插件（' + index.size + '）：');
  for (const k of [...index.keys()].sort()) console.log('  ' + k + '  props=' + index.get(k).properties.size + (index.get(k).loose ? ' [loose]' : ''));
  process.exit(0);
}

let rows;
try { rows = collectRows(yaml, fs.readFileSync(opt.preset, 'utf8')); }
catch (e) {
  // 解析失败也走机器可读枚举；并与正常路径保持**同一形状**（都带 findings[]），
  // 否则消费方（如 run-fixtures.cjs）按 findings[] 解析时会拿不到 cause。
  const fail = {
    ok: false,
    cause: 'PRESET_PARSE_ERROR',
    preset: path.basename(opt.preset),
    detail: String(e.message || e),
    findings: [{ cause: 'PRESET_PARSE_ERROR', plugin: '(preset)', where: path.basename(opt.preset), path: 'yaml', hint: String(e.message || e) }],
    warnings: [],
  };
  if (opt.json) console.log(JSON.stringify(fail, null, 2));
  else console.error('[PRESET_PARSE_ERROR] ' + fail.preset + ' :: ' + fail.detail);
  process.exit(2);
}

const findings = [];
const warnings = [];

// RUNTIME_VERSION_MISMATCH：声明版本与所用键表版本不一致。
// 若未授权 → 已在 resolveKeytable 内拒绝（exit 3）；此处只在授权时记 WARN。
if (opt.runtimeVersion && opt.runtimeVersion !== (CURATED.runtime || opt.runtimeVersion)) {
  if (opt.allowUnknownRuntime) {
    warnings.push({ cause: 'RUNTIME_VERSION_MISMATCH', plugin: '(curated-table)', where: '--runtime-version', path: 'runtime', hint: '声明 ' + opt.runtimeVersion + ' 但使用键表 ' + (CURATED.runtime || '?') + '（因 -AllowUnknownRuntime）' });
  } else {
    findings.push({ cause: 'RUNTIME_VERSION_MISMATCH', plugin: '(curated-table)', where: '--runtime-version', path: 'runtime', hint: '权威键表针对 ' + (CURATED.runtime || '?') + ' 采集；当前声明 ' + opt.runtimeVersion + '，请重新采集键表再判定' });
  }
}

// DEPENDENCY_BLOCKED：profile 的 package.json 里 file: 依赖指向不存在的文件 → 任何 pnpm 安装都会 ENOENT
if (opt.profilePackage && fs.existsSync(opt.profilePackage)) {
  try {
    const pj = JSON.parse(fs.readFileSync(opt.profilePackage, 'utf8'));
    for (const [name, spec] of Object.entries(pj.dependencies || {})) {
      const m = /^file:(.+)$/.exec(String(spec));
      if (!m) continue;
      let target = m[1].replace(/\//g, path.sep);
      if (!fs.existsSync(target)) {
        findings.push({
          cause: 'DEPENDENCY_BLOCKED', plugin: name, where: path.basename(opt.profilePackage),
          path: 'dependencies.' + name, hint: 'file: 依赖指向不存在的文件：' + m[1],
        });
      }
    }
  } catch (e) {
    warnings.push({ cause: 'PROFILE_PACKAGE_PARSE_ERROR', plugin: path.basename(opt.profilePackage), where: String(e.message || e) });
  }
}

for (const r of rows) {
  let entry = index.get(r.name);
  let source = 'schema';
  if (!entry) {
    const cur = CURATED.plugins && CURATED.plugins[r.name];
    if (cur) {
      // 把权威键表里的类型也带上，否则键表路径上 TYPE_MISMATCH 永远不触发
      const typeMap = new Map();
      const tt = (CURATED.types && CURATED.types[r.name]) || {};
      for (const [k, v] of Object.entries(tt)) typeMap.set(k, { type: v });
      entry = { properties: new Set(cur), required: new Set((CURATED.required && CURATED.required[r.name]) || []), propTypes: typeMap, loose: false };
      source = 'curated(' + (CURATED.runtime || '?') + ')';
    }
  }
  // 没有 schema 且没有权威键表 = 该插件接受自由配置（unknownConfig），不能判 FAIL。
  // 记 WARN 并跳过，避免把 dsh-local-memory / client-ui-* 这类插件误报成"未知插件"。
  if (!entry) { warnings.push({ cause: 'NO_SCHEMA_FOR_PLUGIN', plugin: r.name, where: r.where }); continue; }
  if (entry.loose) { warnings.push({ cause: 'LOOSE_CONFIG', plugin: r.name, where: r.where }); continue; }
  const keys = Object.keys(r.config || {});
  for (const k of keys) {
    if (!entry.properties.has(k)) {
      const dep = (DEPRECATED[r.name] || []).includes(k);
      findings.push({
        cause: dep ? 'DEPRECATED_KEY' : 'UNKNOWN_KEY',
        plugin: r.name, where: r.where, path: 'config.' + k, source,
        hint: dep ? '该键在本运行时已被删除，出现即抛错并让整个 preset 加载失败' : '该键不在本运行时的 schema 里',
      });
      continue;
    }
    // TYPE_MISMATCH：键存在但值与 schema 声明的类型/枚举不符。
    // 四条跳过：① 值是 !!js 表达式 {__jsExpr}（运行时原样求值，无法静态判定类型）
    //           ② 无类型信息（键表兜底未带类型 / schema 未声明 type/enum）→ 不误报
    //           ③ 该插件已因 LOOSE_CONFIG 在上层 continue（透传 unknownConfig 分支）
    //           ④ 该插件已因 NO_SCHEMA_FOR_PLUGIN 在上层 continue（无权威信息）
    if (entry.propTypes && entry.propTypes.has(k) && !isJsExpr(r.config[k])) {
      const want = entry.propTypes.get(k);
      const got = r.config[k];
      const gotType = Array.isArray(got) ? 'array' : typeof got;
      let bad = false;
      // type 可能是：字符串 "boolean,null"、数组 ["boolean","null"]、
      // 甚至 anyOf 收集后的嵌套 [["boolean","null"]]。必须深度展平，否则正常配置被误报。
      const normTypes = (t) => {
        const out = [];
        const push = (x) => {
          if (Array.isArray(x)) { x.forEach(push); return; }
          if (x === null || x === undefined) return;
          String(x).split(',').forEach((s) => { const v = s.trim(); if (v) out.push(v); });
        };
        push(t);
        return out;
      };
      if (Array.isArray(want.enum)) {
        if (!want.enum.map(String).includes(String(got))) bad = true;
      } else if (want.type) {
        // JSON Schema 的 integer 在 JS 里就是 number；typeof null === 'object' 但声明为 null 的键应通过。
        const gotT = got === null ? 'null' : gotType;
        const types = normTypes(want.type).map((t) => (t === 'integer' ? 'number' : t));
        if (!types.includes(gotT)) bad = true;
      }
      if (bad) findings.push({
        cause: 'TYPE_MISMATCH',
        plugin: r.name, where: r.where, path: 'config.' + k, source,
        expected: Array.isArray(want.enum) ? 'enum:' + want.enum.join('|') : (Array.isArray(want.type) ? 'type:' + want.type.join('|') : 'type:' + want.type),
        actual: gotType,
        hint: '该键在 schema 中声明为 ' + (Array.isArray(want.enum) ? '枚举 ' + want.enum.join('|') : want.type) + '，但 preset 给了 ' + gotType,
      });
    }
  }
  // required 只在 schema 明确声明时才查；`!!js` 表达式解析出的 __jsExpr 之类内部键不参与
  for (const req of entry.required) {
    if (req.startsWith('__')) continue;
    if (!keys.includes(req)) findings.push({ cause: 'MISSING_REQUIRED', plugin: r.name, where: r.where, path: 'config.' + req });
  }
}

const result = {
  ok: findings.length === 0,
  preset: path.basename(opt.preset),
  // 无 schema 时 opt.schema 为 null，path.basename(null) 会抛 ERR_INVALID_ARG_TYPE，这里兜底。
  schema: opt.schema ? path.basename(opt.schema) : '(none: curated-only)',
  runtime: CURATED.runtime || (opt.runtimeVersion || 'unknown'),
  pluginsInSchema: index.size,
  rowsChecked: rows.length,
  findings,
  warnings,
};
if (opt.json) console.log(JSON.stringify(result, null, 2));
else {
  console.log('=== schema 漂移预检 ===');
  console.log('preset = ' + result.preset + '；schema = ' + result.schema + '；runtime = ' + result.runtime);
  console.log('schema 内插件数 = ' + result.pluginsInSchema + '；校验行数 = ' + result.rowsChecked);
  if (result.ok) console.log('结论：OK（无未知键 / 无已删键 / 无缺必填）');
  else {
    console.log('结论：FAIL（' + findings.length + ' 处）');
    for (const f of findings) console.log('  - [' + f.cause + '] ' + f.plugin + ' @ ' + f.where + ' :: ' + f.path + (f.hint ? '（' + f.hint + '）' : ''));
  }
  if (warnings.length) {
    console.log('WARN（不计入 FAIL）：' + warnings.length + ' 处 —— 无 schema 或自由配置，跳过严格校验');
    const byCause = {};
    for (const w of warnings) byCause[w.cause] = (byCause[w.cause] || 0) + 1;
    for (const [c, n] of Object.entries(byCause)) console.log('  - ' + c + ' × ' + n);
  }
}
process.exit(result.ok ? 0 : 1);
