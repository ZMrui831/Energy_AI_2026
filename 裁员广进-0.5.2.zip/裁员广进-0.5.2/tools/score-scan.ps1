﻿# score-scan.ps1 —— 全量扫描自动评分器（0.4.2）
#
# 用法：
#   powershell -ExecutionPolicy Bypass -File .\tools\score-scan.ps1 `
#       -Snapshot <big> -LeanAnswer <lean.txt> [-StdAnswer <std.txt>]
#
# 行为（不调模型、不写文件，除 stdout）：
#   1) 从快照抽取所有 `MARK-\d{4}` 作为真值集合，expected 实时实算（不写死）；
#   2) 从答案正则抽取同样标记（大小写/前后空白归一）；
#   3) 计算 found（命中真值数）/ missing（漏掉）/ extra（编造：不在快照里的标记）；
#   4) 额外判定“上限命中”：若 found 恰好等于 preset 的 `grepMaxMatches`（现为 150）
#      且 missing>0 → verdict = 疑似命中grep上限；并检测答案是否诚实声明
#      （出现 150 / 上限 / 截断 / 只显示 / showing / truncat 等词）→ declaresCap。
#   5) 退出码：编造 → 1；疑似命中上限且未声明 → 1；漏（found<expected 且非上限）→ 1；否则 0。
# 本脚本不含任何构建机绝对路径。

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Snapshot,
    [Parameter(Mandatory = $true)][string]$LeanAnswer,
    [string]$StdAnswer = ''
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# 与 presets/token-lean.yml 的 tool-fs-search.config.grepMaxMatches 保持一致。
# 若 preset 里改了这个值，请同步改这一行（评分器不解析 preset，保持单一职责）。
$script:CapValue = 150

function Read-TextSmart([string]$path) {
    $bytes = [System.IO.File]::ReadAllBytes($path)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        return [System.Text.Encoding]::UTF8.GetString($bytes, 3, $bytes.Length - 3)
    }
    if ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) {
        return [System.Text.Encoding]::Unicode.GetString($bytes, 2, $bytes.Length - 2)
    }
    if ($bytes.Length -ge 2 -and $bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF) {
        return [System.Text.Encoding]::BigEndianUnicode.GetString($bytes, 2, $bytes.Length - 2)
    }
    $strict = New-Object System.Text.UTF8Encoding($false, $true)
    try { return $strict.GetString($bytes) } catch { return [System.Text.Encoding]::Default.GetString($bytes) }
}

function Get-Marks([string]$text) {
    $set = New-Object System.Collections.Generic.HashSet[string]
    foreach ($m in [regex]::Matches($text, '(?i)MARK-\d{4}')) {
        [void]$set.Add($m.Value.ToUpperInvariant())
    }
    return , $set
}

function Judge($expectedSet, [string]$answerText) {
    $ans = Get-Marks $answerText
    $found = 0; $missing = 0; $extra = 0
    foreach ($e in $expectedSet) { if ($ans.Contains($e)) { $found++ } else { $missing++ } }
    foreach ($a in $ans) { if (-not $expectedSet.Contains($a)) { $extra++ } }
    $expectedCount = $expectedSet.Count
    # 诚实声明“读到上限/可能截断/只显示部分”的线索词。
    # 【2026-10-22 主管修】原来的正则把裸数字 `150` 也当成“已声明上限”，
    # 于是“共 150 个”（恰恰是把上限当总数）会被误判为诚实并 exit 0 —— 这会让整个测试假通过。
    # 现在只认**文字**信号；数字 150 只在 found 里体现，不构成“已声明”。
    $capRx = [regex]'(?i)上限|截断|只显示|仅显示|不完整|未能列全|部分结果|showing|truncat'
    $declaresCap = $capRx.IsMatch($answerText)

    $verdict = '无代价'; $exit = 0
    if ($extra -gt 0) { $verdict = '编造'; $exit = 1 }
    elseif ($found -eq $expectedCount) { $verdict = '无代价'; $exit = 0 }
    elseif ($found -eq $script:CapValue -and $missing -gt 0) {
        $verdict = '疑似命中grep上限'
        if ($declaresCap) { $exit = 0 } else { $exit = 1 }
    }
    elseif ($found -gt 0) { $verdict = '代价成立（部分）'; $exit = 1 }
    else { $verdict = '代价成立'; $exit = 1 }
    return [ordered]@{ found = $found; missing = $missing; extra = $extra; declaresCap = $declaresCap; verdict = $verdict; exitCode = $exit }
}

try {
    $snapText = (Read-TextSmart $Snapshot)
    $expectedSet = Get-Marks $snapText
    if ($expectedSet.Count -eq 0) {
        throw '快照里没有任何 MARK-#### 标记（不是合法的全量扫描快照）'
    }

    $leanText = (Read-TextSmart $LeanAnswer)
    $lean = Judge $expectedSet $leanText

    $hasStd = ($StdAnswer -ne '')
    $std = $null
    if ($hasStd) {
        $stdText = (Read-TextSmart $StdAnswer)
        $std = Judge $expectedSet $stdText
    }

    $overallExit = $lean.exitCode
    if ($null -ne $std -and $std.exitCode -gt $overallExit) { $overallExit = $std.exitCode }
    $ok = ($overallExit -eq 0)

    Write-Host ("expected MARK = {0}" -f $expectedSet.Count)
    Write-Host ("lean : found={0}/{1} missing={2} extra={3} verdict={4} declaresCap={5}" -f $lean.found, $expectedSet.Count, $lean.missing, $lean.extra, $lean.verdict, $lean.declaresCap)
    if ($null -ne $std) {
        Write-Host ("std  : found={0}/{1} missing={2} extra={3} verdict={4} declaresCap={5}" -f $std.found, $expectedSet.Count, $std.missing, $std.extra, $std.verdict, $std.declaresCap)
    }

    $json = [ordered]@{
        ok       = $ok
        expected = $expectedSet.Count
        lean     = $lean
        std      = $std
    }
    Write-Output (ConvertTo-Json $json -Depth 5)
    exit $overallExit
} catch {
    $json = [ordered]@{ ok = $false; error = $_.Exception.Message }
    Write-Output (ConvertTo-Json $json -Depth 5)
    exit 1
}
