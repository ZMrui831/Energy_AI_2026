# 第三方组件许可声明（Third-Party Notices）

本交付物 `裁员广进-release` 在 `vendor/js-yaml/` 内包含了以下第三方组件的**未修改源码副本**，
按其原许可随包分发。其余脚本与 preset 由本包作者以 MIT 许可（见 `LICENSE`）发布。

## js-yaml

- 组件：js-yaml
- 版本：4.3.2
- 许可：MIT License
- 来源：https://github.com/nodeca/js-yaml （本包 `vendor/js-yaml/` 为从 npm 安装的 `js-yaml@4.3.2` 原样复制，源码未作改动；`LICENSE` 文件随包保留）
- 用途：本包的 `schema-preflight.cjs` 在目标机无 `js-yaml` 时用作内置 YAML 解析依赖（解析含 `!!js` 标签的 DSH patch）。

### js-yaml 原始 MIT 文本（4.3.2）

```
Copyright (c) 2011-2015 by Vitaly Puzrin, Jules Boussekey, and project contributors.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
```

---

## 其他依赖说明

- 本包其余 PowerShell 脚本（install/uninstall/verify/selftest/regen-manifest/repackage）与
  `tools/*.cjs`、`presets/*.yml`、`fixtures/*`、`docs/*` 均为本包作者原创，以 MIT 许可发布。
- 运行这些脚本需要宿主已具备 PowerShell 5.1 与 Node.js（由脚本自动探测，见 README「零假设安装」）。
  PowerShell 与 Node.js 各自的许可不随本包分发，由使用方按其安装来源遵守。
