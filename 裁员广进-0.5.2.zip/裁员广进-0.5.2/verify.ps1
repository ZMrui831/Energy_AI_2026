﻿# verify.ps1 —— 夹具验证关：跑 run-fixtures.cjs
#
# 用法：
#   powershell -ExecutionPolicy Bypass -File .\verify.ps1 [-Tool <schema-preflight.cjs>] [-Schema <schema.json>]
#                                                     [-NodeExe <node>] [-StrictSchema]
#
# 0.3.0 行为（G1 + G5）：
#   * 默认零假设即可验证通过（exit 0）：
#       - 无 -Schema 时优先用本包自带的 fixtures\schema.mini.json（含 4 个插件的权威结构）→ 全量 12 夹具 12/12；
#       - 若 mini schema 不存在 → 降级 PARTIAL（7/7，类型用例跳过，内置权威键表判定）。
#   * -Schema <完整schema> → 全量 12 夹具，期望 TOTAL=12 PASS=12 FAIL=0。
#   * -StrictSchema（无完整 -Schema 时）→ 拒绝静默通过，明确告警并 exit 1。
# 本脚本不含任何构建机绝对路径。

[CmdletBinding()]
param(
    [string]$Tool = '',
    [string]$Schema = '',
    [string]$NodeExe = '',
    [string]$DshHome = '',
    [switch]$StrictSchema
)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# ---- 0.4.0：脚本级结构化失败（最后一行输出一行 JSON） ----
function Emit-Fail {
    param([string]$Stage, [string]$Cause, [string]$Detail, [int]$Code = 1)
    $obj = [ordered]@{ ok = $false; stage = $Stage; cause = $Cause; detail = $Detail }
    [Console]::Out.WriteLine((ConvertTo-Json -InputObject $obj -Compress))
    exit $Code
}

# ---- G1：零假设定位 node v2（与 install.ps1 同款实现；含 Electron 主程序回退） ----
function Test-NodeCandidate {
    param([string]$Path, [bool]$IsElectron, [string]$Source)
    $exists = Test-Path -LiteralPath $Path -PathType Leaf
    if (-not $exists) {
        return [PSCustomObject]@{
            Usable = $false; Reason = '不存在'; Result = $null
            Tried  = @([PSCustomObject]@{ path = $Path; source = $Source; exists = $false; usable = $false; reason = '不存在'; version = $null })
        }
    }
    $prev = $env:ELECTRON_RUN_AS_NODE
    if ($IsElectron) { $env:ELECTRON_RUN_AS_NODE = '1' }
    $ok = $false; $reason = ''; $ver = $null
    try {
        $tmpOut = [System.IO.Path]::GetTempFileName()
        $tmpErr = [System.IO.Path]::GetTempFileName()
        try {
            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName = $Path
            $psi.Arguments = '--version'
            $psi.UseShellExecute = $false
            $psi.RedirectStandardOutput = $true
            $psi.RedirectStandardError = $true
            $psi.CreateNoWindow = $true
            $proc = New-Object System.Diagnostics.Process
            $proc.StartInfo = $psi
            if (-not $proc.Start()) { throw '无法启动进程' }
            if (-not $proc.WaitForExit(10000)) {
                try { $proc.Kill() } catch {}
                $reason = '超时(>10s)'
            } else {
                $so = $proc.StandardOutput.ReadToEnd().Trim()
                $se = $proc.StandardError.ReadToEnd().Trim()
                if ($proc.ExitCode -eq 0 -and ($so -match '^v\d+\.')) {
                    $ok = $true; $ver = $so
                } else {
                    $reason = "exit=$($proc.ExitCode); stdout='$so'; stderr='$se'"
                }
            }
        } finally {
            Remove-Item -LiteralPath $tmpOut -Force -ErrorAction SilentlyContinue
            Remove-Item -LiteralPath $tmpErr -Force -ErrorAction SilentlyContinue
        }
    } catch {
        $reason = ('异常: ' + $_.Exception.Message)
    } finally {
        if ($IsElectron) {
            if ($null -eq $prev) { Remove-Item env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue }
            else { $env:ELECTRON_RUN_AS_NODE = $prev }
        }
    }
    return [PSCustomObject]@{
        Usable = $ok; Reason = $reason
        Result = [PSCustomObject]@{ Path = $Path; Source = $Source; Version = $ver; IsElectron = $IsElectron; Tried = $null; Failed = $false }
        Tried  = @([PSCustomObject]@{ path = $Path; source = $Source; exists = $true; usable = $ok; reason = $reason; version = $ver })
    }
}

function Resolve-NodeExe {
    param([string]$Explicit, [string]$DshHome)
    $tried = @()
    if ($Explicit -ne '') {
        if (-not (Test-Path -LiteralPath $Explicit -PathType Leaf)) {
            Write-Host ('指定的 -NodeExe 不存在：' + $Explicit)
            Emit-Fail -Stage 'verify' -Cause 'NODE_NOT_FOUND' -Detail ('指定的 -NodeExe 不存在：' + $Explicit) -Code 2
        }
        $r = Test-NodeCandidate -Path $Explicit -IsElectron ($Explicit -match 'DeepSeek.*Harness.*\.exe') -Source '-NodeExe'
        $tried += $r.Tried
        if (-not $r.Usable) {
            Write-Host ('指定的 -NodeExe 不可用（无法作为 node 运行）：' + $Explicit)
            Write-Host ('  失败原因：' + $r.Reason)
            Emit-Fail -Stage 'verify' -Cause 'NODE_NOT_FOUND' -Detail ('指定的 -NodeExe 不可用：' + $Explicit + '；原因：' + $r.Reason) -Code 2
        }
        $r.Result.Tried = $tried
        return $r.Result
    }
    if ($env:DSH_DESKTOP_NODE_EXECUTABLE -and (Test-Path -LiteralPath $env:DSH_DESKTOP_NODE_EXECUTABLE -PathType Leaf)) {
        $r = Test-NodeCandidate -Path $env:DSH_DESKTOP_NODE_EXECUTABLE -IsElectron ($env:DSH_DESKTOP_NODE_EXECUTABLE -match 'DeepSeek.*Harness.*\.exe') -Source '$env:DSH_DESKTOP_NODE_EXECUTABLE'
        $tried += $r.Tried
        if ($r.Usable) { $r.Result.Tried = $tried; return $r.Result }
    }
    if ($DshHome -ne '') {
        $base = $DshHome.TrimEnd('\').TrimEnd('/')
        $cands = @(
            [PSCustomObject]@{ Path = "$base\resources\runtime\bin\node.exe"; IsElectron = $false; Source = 'DshHome:resources/runtime/bin/node.exe' },
            [PSCustomObject]@{ Path = "$base\resources\runtime\primary-runtime\dependencies\node\node.exe"; IsElectron = $false; Source = 'DshHome:primary-runtime/.../node.exe' },
            [PSCustomObject]@{ Path = "$base\resources\runtime\primary-runtime\dependencies\node\bin\node.exe"; IsElectron = $false; Source = 'DshHome:primary-runtime/.../bin/node.exe' },
            [PSCustomObject]@{ Path = "$base\resources\runtime\node.exe"; IsElectron = $false; Source = 'DshHome:resources/runtime/node.exe' },
            [PSCustomObject]@{ Path = "$base\DeepSeek Harness.exe"; IsElectron = $true; Source = 'DshHome:DeepSeek Harness.exe' }
        )
        if (Test-Path -LiteralPath $base -PathType Container) {
            Get-ChildItem -LiteralPath $base -Filter 'DeepSeek*Harness*.exe' -File -ErrorAction SilentlyContinue | ForEach-Object {
                if ($_.FullName -ne "$base\DeepSeek Harness.exe") {
                    $cands += [PSCustomObject]@{ Path = $_.FullName; IsElectron = $true; Source = 'DshHome:root/DeepSeek*Harness*.exe' }
                }
            }
        }
        foreach ($c in $cands) {
            $r = Test-NodeCandidate -Path $c.Path -IsElectron $c.IsElectron -Source $c.Source
            $tried += $r.Tried
            if ($r.Usable) { $r.Result.Tried = $tried; return $r.Result }
        }
    }
    $pn = Get-Command node -ErrorAction SilentlyContinue
    if ($pn) {
        $r = Test-NodeCandidate -Path $pn.Source -IsElectron ($pn.Source -match 'DeepSeek.*Harness.*\.exe') -Source 'PATH:node'
        $tried += $r.Tried
        if ($r.Usable) { $r.Result.Tried = $tried; return $r.Result }
    }
    return [PSCustomObject]@{ Path = $null; Source = $null; Version = $null; IsElectron = $false; Failed = $true; Tried = $tried }
}

$script:NodeIsElectron = $false
$resolved = Resolve-NodeExe -Explicit $NodeExe -DshHome $DshHome
if ($resolved.Failed) {
    Write-Host '探测 node 全部失败。逐条候选与原因：'
    foreach ($t in $resolved.Tried) {
        $st = if ($t.usable) { 'OK' } elseif ($t.exists) { '存在但不可用' } else { '不存在' }
        Write-Host ('  候选 ' + $t.source + ' -> ' + $t.path + ' [' + $st + ']' + $(if ($t.reason) { '  原因: ' + $t.reason }))
    }
    Write-Host @'
可复制命令（任选其一）：
  powershell -ExecutionPolicy Bypass -File .\verify.ps1 -DshHome "<DSH安装目录>"
  powershell -ExecutionPolicy Bypass -File .\verify.ps1 -NodeExe "<DSH安装目录>\DeepSeek Harness.exe"
若用 Electron 主程序当 node，脚本会自动设置 ELECTRON_RUN_AS_NODE=1。
'@
    Emit-Fail -Stage 'verify' -Cause 'NODE_NOT_FOUND' -Detail '探测 node 全部失败（详见上方逐条候选）' -Code 2
}
$NodeExe = $resolved.Path
$script:NodeIsElectron = $resolved.IsElectron
Write-Host ('node 解析：' + $resolved.Path + '（来源：' + $resolved.Source + '）')
if ($resolved.IsElectron) { Write-Host '（Electron 主程序当 node：后续调用自动设置 ELECTRON_RUN_AS_NODE=1）' }

# ---- G1：env 感知的 node 调用（Electron 主程序须带 ELECTRON_RUN_AS_NODE=1） ----
function Invoke-NodeScript {
    param([string[]]$ArgumentList)
    $prev = $env:ELECTRON_RUN_AS_NODE
    if ($script:NodeIsElectron) { $env:ELECTRON_RUN_AS_NODE = '1' }
    try {
        return (& $NodeExe @ArgumentList 2>&1 | Out-String)
    } finally {
        if ($script:NodeIsElectron) {
            if ($null -eq $prev) { Remove-Item env:ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue }
            else { $env:ELECTRON_RUN_AS_NODE = $prev }
        }
    }
}

if ($Tool -eq '') { $Tool = Join-Path $PSScriptRoot 'tools\schema-preflight.cjs' }
$Runner = Join-Path $PSScriptRoot 'tools\run-fixtures.cjs'
$FixtureDir = Join-Path $PSScriptRoot 'fixtures'
$MiniSchema = Join-Path $PSScriptRoot 'fixtures\schema.mini.json'

if (-not (Test-Path -LiteralPath $Runner))     { Write-Host ('runner 缺失：' + $Runner); Emit-Fail -Stage 'verify' -Cause 'PRECONDITION' -Detail ('runner 缺失：' + $Runner) -Code 2 }
if (-not (Test-Path -LiteralPath $Tool))       { Write-Host ('校验工具缺失：' + $Tool); Emit-Fail -Stage 'verify' -Cause 'PRECONDITION' -Detail ('校验工具缺失：' + $Tool) -Code 2 }
if (-not (Test-Path -LiteralPath $FixtureDir)) { Write-Host ('夹具目录缺失：' + $FixtureDir); Emit-Fail -Stage 'verify' -Cause 'PRECONDITION' -Detail ('夹具目录缺失：' + $FixtureDir) -Code 2 }

# ---- 解析 schema 来源 ----
$schemaMissing = $true
$useMini = $false
if ($Schema -ne '' -and (Test-Path -LiteralPath $Schema)) {
    $schemaMissing = $false
    Write-Host ('使用显式 schema：' + $Schema)
} else {
    if ($Schema -ne '') { Write-Warning ('指定的 -Schema 不存在：' + $Schema + '，改用默认解析') }
    # G5.3：优先用自带 mini schema；没有才 PARTIAL
    if (Test-Path -LiteralPath $MiniSchema) {
        $Schema = $MiniSchema
        $schemaMissing = $false
        $useMini = $true
        Write-Host ('未指定 -Schema：优先使用本包自带的 fixtures\schema.mini.json（4 插件权威结构）→ 全量 12 夹具')
    }
}

if ($schemaMissing) {
    # 无 schema 且无 mini → PARTIAL 7/7
    if ($StrictSchema) {
        Write-Warning '【StrictSchema】未提供完整 -Schema，且无 mini schema 可用：严格模式下拒绝静默通过。'
        Write-Warning '请传 -Schema <完整schema.json> 后再跑；或去掉 -StrictSchema 以允许 PARTIAL 验证。'
        Emit-Fail -Stage 'verify' -Cause 'PRECONDITION' -Detail 'StrictSchema 拒绝静默通过：无完整 -Schema 且无 mini schema' -Code 1
    }
    Write-Host '【PARTIAL 模式】无 schema 且无 mini schema：跳过 5 个类型用例，仅跑 7 个非类型夹具（内置权威键表判定）。'
    $out = Invoke-NodeScript -ArgumentList @($Runner, '--dir', $FixtureDir, '--tool', $Tool, '--no-type')
    Write-Host $out
    if ($out -match 'TOTAL=7 PASS=7 FAIL=0') {
        Write-Host 'PARTIAL（7/7，类型用例已跳过：无 schema）'
        exit 0
    }
    Write-Warning 'PARTIAL 验证未通过（未出现 TOTAL=7 PASS=7 FAIL=0）'
    Emit-Fail -Stage 'verify' -Cause 'PRECONDITION' -Detail 'PARTIAL 验证未通过（未出现 TOTAL=7 PASS=7 FAIL=0）' -Code 1
}

# ---- 完整 12 夹具（显式 schema 或 mini schema） ----
if ($StrictSchema -and -not $useMini -and $Schema -ne $MiniSchema) {
    Write-Host '【StrictSchema】使用完整 -Schema 进行严格全量验证。'
} elseif ($StrictSchema -and $useMini) {
    Write-Warning '【StrictSchema】当前仅 mini schema 可用（非完整 schema）；严格模式要求完整 schema，已拒绝静默通过。'
    Write-Warning '请传 -Schema <完整schema.json> 后再以 -StrictSchema 运行。'
    Emit-Fail -Stage 'verify' -Cause 'PRECONDITION' -Detail 'StrictSchema 拒绝：当前仅 mini schema 可用（非完整 schema）' -Code 1
}

Write-Host ('runner  = ' + $Runner)
Write-Host ('tool    = ' + $Tool)
Write-Host ('schema  = ' + $Schema + $(if ($useMini) { '  (mini)' } else { '' }))
Write-Host '---- run-fixtures 输出 ----'
$out = Invoke-NodeScript -ArgumentList @($Runner, '--dir', $FixtureDir, '--tool', $Tool, '--schema', $Schema)
Write-Host $out

if ($out -match 'TOTAL=12 PASS=12 FAIL=0') {
    Write-Host '判定：PASS（TOTAL=12 PASS=12 FAIL=0）'
    exit 0
}
Write-Warning '判定：FAIL（未出现 TOTAL=12 PASS=12 FAIL=0）'
Emit-Fail -Stage 'verify' -Cause 'PRECONDITION' -Detail '未出现 TOTAL=12 PASS=12 FAIL=0' -Code 1
