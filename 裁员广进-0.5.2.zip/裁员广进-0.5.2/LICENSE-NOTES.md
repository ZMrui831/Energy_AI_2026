# LICENSE-NOTES · 第三方组件许可说明

本包内含的第三方组件及其许可：

## js-yaml 4.3.2（MIT License）

- **用途**：YAML 解析（预检工具读取 preset 片段与 `!!js` 标签所需）。
- **位置**：`vendor/js-yaml/`（`index.js`、`lib/**`、`package.json`、`LICENSE`）。
- **来源**：npm 注册表 `js-yaml@4.3.2` 的官方发布物，从构建机 node_modules 原样复制。
- **改动**：**零改动**——源码、目录结构与上游一致；仅排除了一个与运行无关的构建残留临时文件（`lib/index_vite_proxy.tmp.mjs`）。
- **许可**：MIT。完整许可文本见 `vendor/js-yaml/LICENSE`。MIT 许可要求在软件副本中保留版权与许可声明——本文件与 `vendor/js-yaml/LICENSE` 即履行该义务。

## 本包其余文件

- `presets/`、`fixtures/`、`docs/`、三个 .ps1 脚本与两个 .cjs 工具均为本项目原创产物，不包含其他第三方代码。
- `tools/regen-manifest.ps1` 仅调用 PowerShell 内置 cmdlet（`Get-FileHash` / `ConvertTo-Json` 等），无第三方依赖。

## 运行依赖（node 探测）

- 本包的运行 / 校验脚本需要 node 来执行 `schema-preflight.cjs` 与 `run-fixtures.cjs`。
- 在干净的 DSH 桌面机上，node 通常并不存在；脚本会自动探测并把 **Electron 主程序**（`DeepSeek Harness.exe`）当 node 用——此时需要 `ELECTRON_RUN_AS_NODE=1`，**脚本已自动设置并在每次调用后恢复原值**，无需手动干预。
- 若改用其它方式提供 node（如显式 `-NodeExe`、环境变量 `$env:DSH_DESKTOP_NODE_EXECUTABLE`、或 PATH 里的 `node`），则无需该环境变量，脚本按同样流程探测即可。
