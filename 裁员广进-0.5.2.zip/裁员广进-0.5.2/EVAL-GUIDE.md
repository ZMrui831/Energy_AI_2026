# EVAL-GUIDE · 同学 AI 测评说明（自包含，零上下文可执行）

你在这次测评中的任务：**在一台新机器上安装一个 DSH 模式包 → 跑 4 个任务做对比测评 → 测评完必须卸载干净**。未卸载视为未完成。

---

## 1. 你的任务

- 安装本包（两个新模式：裁员广进 / · 只读子代理（内部，勿直接对话））；
- 在「标准模式」与「裁员广进模式」下各跑 4 道题，记录每题 UI 显示的用量与是否答对；
- 卸载并核对干净；
- 按第 7 节模板输出报告。

## 2. 前置检查（逐条给命令与期望）

| # | 检查 | 命令 | 期望 |
|---|---|---|---|
| 2.1 | DSH 版本 | 桌面应用「关于/设置」页查看（或 `dsh --version`，若命令存在） | `0.2.1-rc.2`；其他版本**停止测评**并在报告注明 |
| 2.2 | profile 目录存在 | `Test-Path <DSH安装目录>\profiles` 或在应用设置里找到 profile 根目录 | 存在；记下 `cordis.patch.yml` 的完整路径，下文记作 `<PATCH>` |
| 2.3 | node 探测 | 无需手动确认 | 脚本**自动探测** node（顺序：`-NodeExe` → `$env:DSH_DESKTOP_NODE_EXECUTABLE` → `-DshHome` 下 5 候选（含 `<DSH安装目录>\DeepSeek Harness.exe` 电子主程序回退）→ PATH `node`），每个候选用 `--version` 实测可用性；都不行才报错并给可复制命令。干净机器无 node 时，安装/验证/自证统一加 `-DshHome "<DSH安装目录>"`，脚本会用 Electron 主程序当 node（自动设置 `ELECTRON_RUN_AS_NODE=1`）。排障先跑 `tools\runtime-probe.ps1 -DshHome "<DSH安装目录>"`。 |
| 2.4 | 目标 patch 存在 | `Test-Path <PATCH>` | True |
| 2.5 | **先备份** | `Copy-Item <PATCH> <PATCH>.bak-eval` | 成功；报告里附备份路径 |
| 2.6 | 权威 schema（可选但建议） | `dsh <非desktop profile> --dump-config-schema > schema.json` | 生成 `schema.json` 且体积 >0 |

2.6 重要说明：**桌面 profile 无法导出 schema**（`--dump-config-schema` 被 Electron 独占，不要在 desktop profile 上浪费时间）。请用 web / headless 等**非 desktop profile** 导出；该 schema 不含 preset 层插件，校验工具对这部分靠内置权威键表兜底，不影响可用性。若连非 desktop profile 都没有：本包已自带 `fixtures/schema.mini.json`（4 个插件的权威结构），`verify.ps1` **默认即用它跑 12/12**，无需额外操作；极端情况下 mini 也缺失时降级为 PARTIAL 7/7（均 exit 0）。报告里注明实际走的哪条路径即可。

## 3. 安装（含自证；干净机器一条命令即可）

> 干净机器没有 node 也能装：每条命令后加 `-DshHome "<DSH安装目录>"`，脚本会用 `<DSH安装目录>\DeepSeek Harness.exe`（Electron 主程序）当 node（自动设置 `ELECTRON_RUN_AS_NODE=1`）；也可显式 `-NodeExe "<DSH安装目录>\DeepSeek Harness.exe"`。

```powershell
# 0) （可选）排障：只读探测 node 候选，输出 JSON，不写文件不改配置
powershell -ExecutionPolicy Bypass -File .\tools\runtime-probe.ps1 -DshHome "<DSH安装目录>"

# 1) 自证：%TEMP% 合成 patch 跑通 安装→验证→卸载（绝不碰真实 <PATCH>）
powershell -ExecutionPolicy Bypass -File .\tools\selftest.ps1 -DshHome "<DSH安装目录>"

# 2) 先演练（不落盘、不建备份、不加锁），肉眼确认 diff 只是追加两段 preset
powershell -ExecutionPolicy Bypass -File .\install.ps1 -ProfilePatch <PATCH> -RuntimeVersion 0.2.1-rc.2 -DshHome "<DSH安装目录>" -DryRun

# 3) 真装（脚本自动备份为 *.bak-<时间戳>-release；版本契约默认用内置键表）
powershell -ExecutionPolicy Bypass -File .\install.ps1 -ProfilePatch <PATCH> -RuntimeVersion 0.2.1-rc.2 -DshHome "<DSH安装目录>"
#   版本三选一（至少一个）：-RuntimeVersion 0.2.1-rc.2 / -DshHome <DSH安装目录> / -AllowUnknownRuntime
#   可选 -SchemaPath schema.json 做 schema + 键表双重校验
```

记录「自证」与「真装」两条命令的**完整输出**进报告。若没有 schema：直接按上面 `-RuntimeVersion` 安装即可（脚本会用内置键表校验），无需去掉任何参数。

## 4. 验证三关（每关都要过，任一关不过即停并报告）

| 关 | 判据 | 怎么验 |
|---|---|---|
| ① 模式出现 | 重启 DSH 后，模式下拉出现「裁员广进」与「· 只读子代理（内部，勿直接对话）」 | 截图或记录 |
| ② 子代理只读 | 切到「· 只读子代理（内部，勿直接对话）」模式，让它「在桌面创建 test.txt 写入 hello」 | 它应答复**没有 write 工具/无法写文件**；且桌面上**零新增文件**（`Get-ChildItem <桌面路径>\test.txt` 应报不存在） |
| ③ 夹具验证 | `powershell -ExecutionPolicy Bypass -File .\verify.ps1`（-DshHome "<DSH安装目录>"） | 输出末行 `TOTAL=12 PASS=12 FAIL=0`（默认用自带 `fixtures/schema.mini.json`）；提供完整 schema 时用 `.\verify.ps1 -Schema schema.json` 同样 12/12；无 schema 且无 mini 的极端情况降级 `PARTIAL（7/7）`。报告注明实际路径与 node 解析结果 |

## 5. 测评 4 个任务（每题新开会话；同题两种模式各跑一遍）

### 5.0 准备快照文件（第 4 题用）

第 4 题考察「大文件中段截断」：0.4.0 起广进模式 `readMaxBytes=65536` 且 `readLimit=800`，**首次 read 最多到第 800 行**，第 900–910 行必须用 offset 续读才拿得到。推荐直接用本包工具生成确定性快照（1200 行、第 900–910 行含 `MARK-0900…MARK-0910`、UTF-8 无 BOM、LF、末行换行）：

```powershell
powershell -ExecutionPolicy Bypass -File .\tools\make-snapshot.ps1 -Out <快照路径> -Lines 1200 -Seed 20261021
```

生成后用 `Get-Content <快照路径> | Select-Object -Index 899..909` 核对第 900–910 行；判分用 `.\tools\score-truncation.ps1`（用法与判分口径见 `docs\79-截断质量测试.md`）。

### 5.1 题目（逐字粘贴；`<…>` 换成你机器上的真实路径；四种模式×题组合各开新会话）

| 题号 | 任务文本（逐字） |
|---|---|
| 1 | 读取 `<大文件路径>`（约 1784 行，自备任意长文本；两模式用同一文件），用不超过 200 字总结该文件的核心内容，并报告该文件的总行数。 |
| 2 | 在 `<检索目标路径>` 中查找 storeDir 的所有出现位置，逐条报告所在文件与行号。 |
| 3 | 读取 `<小文件路径>`（62 行，自备任意短配置文件），回答三个问题：①这个文件是做什么用的？②里面有哪些关键配置项？③有没有明显错误或风险点？ |
| 4 | 读取 `<快照路径>`，回答第 900 行到第 910 行的原文，逐行引用，不要总结。（逐字题面、记录表与判分口径见 `docs\79-截断质量测试.md`） |

执行规则：每题**新开会话**；模式选对；任务文本**只粘贴一次**，不追问、不纠错；当场记录 UI 用量数字与对错。

### 5.2 记录表

| 任务 | 模式 | 用量(UI) | 是否答对 | 备注 |
|---|---|---|---|---|
| 1 | 标准 |  |  |  |
| 1 | 广进 |  |  |  |
| 2 | 标准 |  |  |  |
| 2 | 广进 |  |  |  |
| 3 | 标准 |  |  |  |
| 3 | 广进 |  |  |  |
| 4 | 标准 |  |  |  |
| 4 | 广进 |  |  |  |

判定：`Δ = (Σ标准 − Σ广进) / Σ标准`（4 题合计）；**第 4 题广进错、标准对 → 报告必须写「存在质量代价」**并附两段答案原文对照。

## 6. 卸载（强制，且必须核对）

```powershell
# 卸载（默认保留本次备份；加 -PurgeBackups 可一并清理历史 *.bak-* 备份）
powershell -ExecutionPolicy Bypass -File .\uninstall.ps1 -ProfilePatch <PATCH>

# 核对 1：两段 preset 已消失（期望 0 条命中）
Select-String -Path <PATCH> -Pattern 'preset-token-lean|preset-scout'

# 核对 2：重启 DSH 后，模式下拉不再出现「裁员广进」「· 只读子代理（内部，勿直接对话）」（人工确认并记录）

# 核对 3：删除 release 目录本身
Remove-Item -Recurse -Force <release 目录路径>
```

## 已知现象（测评前必读）

- 根目录 `<DSH安装目录>\version` 文件是 **Electron** 版本（如 `44.7.0`），**不是 DSH 运行时版本**；二者形状同为 `x.y.z`，无法靠格式区分，安装器**绝不会**用根目录 `version` 判定 DSH 版本。
- 真实 DSH 版本在 `<DSH安装目录>\resources\runtime\primary-runtime\runtime.json` 的 `desktopVersion` 字段（`0.2.1-rc.2`）。若版本探测异常（如自动探测不到），先跑 `tools\runtime-probe.ps1 -DshHome "<DSH安装目录>"` 看 `versionDetect`，或 `node tools\schema-preflight.cjs --print-version --dsh-home "<DSH安装目录>"`（输出 `selected`/`source`/`electronVersionGuess`，只读不写）；必要时显式 `-RuntimeVersion 0.2.1-rc.2`。

## 7. 报告模板

```
## 环境系统版本 / DSH 版本 / node 版本 / patch 路径（脱敏到盘符+文件名即可）
## node 解析结果（路径 / 来源：如 DshHome:DeepSeek Harness.exe / PATH:node / -NodeExe）
## 版本探测结果（selected/source：如 primary-runtime/runtime.json / resources/runtime/package.json；electronVersionGuess 仅供参考，不参与判定）
## 每关结果关① 关② 关③（原始输出/截图说明；verify 走的是 12/12 还是 7/7 PARTIAL 注明路径）
## 4 任务数据（5.2 表格填好 + Δ 计算值）
## 卸载核对（核对 1/2/3 的原始输出）
## 异常原始输出（若有，原样粘贴，不要转述）
```

## 8. 红线

- 不修改任何 `file:` 依赖（某 file: 依赖指向已删除的 tgz，改它属于越权）；不用任何「版本豁免」；不使用 `pnpm --frozen-lockfile`。
- 不把对方机器的完整路径写进报告（脱敏到盘符+文件名）。
- **未卸载视为未完成**；卸载后必须附核对 1 的原始输出。
