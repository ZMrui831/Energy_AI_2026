# kit · 与框架无关的「省钱契约」套件

> 本套规则翻译自一份现成的 agent 配置模式包：它的封顶数字（64KB / grep 150 / web 48000 / 工具结果 16384）
> 正是本 kit 的灵感来源。但这里**不依赖那个模式包、不依赖任何 agent 框架**——规则用纯 JSON 表达，用零依赖的 Node 脚本判定。

## 这是什么

一套把"省钱 / 防踩坑"契约变成**可判定件**的最小工具集（每条输出 PASS / FAIL / UNVERIFIED，FAIL 给修复建议）：

1. 工具表受限（C1）—— 工具数量封顶，避免 prompt 被工具清单撑爆
2. 输出封顶（C2）—— 单工具返回字节 / 行数上限
3. 截断诚实（C3）—— 命中上限时**必须报真实总数**，不得把上限当答案
4. 分页契约（C4）—— 引用截断区必须注明 offset / 页码
5. 压缩阈值（C5）—— 上下文压缩的触发与保留比例
6. 子代理隔离（C6）—— 子代理只读、深度受限（见下方 `subagent.inUse` 说明）
7. 限流（C7）—— 每分钟请求数与突发（**声明值**，lint 不校验真实性）
8. 遥测（C8）—— 必须采集的用量字段
9. 静态前缀预算（C9）—— system + tool schema 的字节数上限，并用基线算实际节省

外加一条**观测契约（E1）**：用真实调用日志验证"截断时是否真的报了总数"。

> **`subagent.inUse`**：声明"本项目不用子代理"时把 `subagent.inUse` 设为 `false`，C6 判 **UNVERIFIED**（契约不适用，**不是**"已达成隔离"）；缺省视为在用，C6 照常校验 `readonly/maxDepth/maxOutputTokens`。
> **C9 / prefix**：`prefix` 是可选字段；不声明 → C9 UNVERIFIED；声明后要求 `systemBytes+toolSchemaBytes <= maxTotalBytes`。C9 只保证"封顶存在"，**不度量实际节省**——要度量节省，喂 `--baseline`（见下）。`prefix` 只计**静态基线**（system prompt 固定部分 + 工具 schema 序列化字节），运行时动态注入（记忆/技能/计划/检索结果）不计入。

## 3 分钟上手（宿主接入四步）

**第一步：写 `policy.json`** —— 复制 `policy.example.json`，按你的场景改数字。字段名照抄，别自创。

**第二步：核对工具数（C1）** —— 三种入参任选其一（`--tool-count` 最简）：

```jsonc
{"tools":[{"name":"read"},{"name":"grep"}]}          // 形态 A：tools[] 数组
{"functions":[{"name":"read"},{"name":"grep"}]}       // 形态 B：functions[] 数组
{"tools": 13}                                          // 形态 C：直接一个数字
```

```bash
node kit/policy-lint.mjs --policy p.json --tool-count 13      # 最简：直接报个数
# 或：node kit/policy-lint.mjs --policy p.json --agent-config agent.json
```

**第三步：用 `--fixture` 跑通观测管线（E1）** —— **前置条件：E1 需要 ≥1 轮真实调用；暂无数据时用 `--fixture` 验证管线本身能跑通**（内置样例，自包含）：

```bash
node kit/policy-lint.mjs --policy p.json --fixture
```

**第四步：接真实 usage.jsonl** —— 把宿主真实调用记录存成 JSONL（每行一个调用，字段见 `eval/sample.jsonl`），跑：

```bash
node kit/policy-lint.mjs --policy p.json --observed calls.jsonl --baseline baseline.jsonl
# --baseline 可选：算 avgInputTokens(baseline) vs avgInputTokens(observed)，输出 savedPct
```

**一次性自证（强烈建议先跑）**：`node kit/policy-lint.mjs --selftest-host` —— 自包含（不读外部文件），用内置 policy + 样例跑 C1–C9 + E1，并做**双向断言**（如 C1 的 13 过 / 20 不过、C6 的 inUse:false → UNVERIFIED、E1 的样本 PASS / 空输入 UNVERIFIED），末行输出 `SELFTEST: PASS (n/n)`。宿主接入后先跑它，再跑自己的 policy。

> 注：agent-config / policy / jsonl 都是**纯 JSON**；脚本会自动 stripBom（PowerShell 5.1 写文件常带 BOM）。

## 口径与换算

- **output.capBytes 是字节数，不是字符数**：UTF-8 下中文约 3 字节/字、ASCII 1 字节；若你的框架按字符截断，请换算后填写（例如 4000 个中文字符 ≈ 12000 字节）。
- **prefix 只计静态基线**：system prompt 的固定部分 + 工具 schema 序列化字节；运行时动态注入（记忆/技能/计划/检索结果）**不计入**。接入方须在报告中如实标注口径。
- **C7 / C1 / C9 的字段都是"声明值"**：lint 只验"格式合法 + 封顶是否存在"，**不校验真实性**（C7 的 requestsPerMinute/burst、C1 的 --tool-count、C9 的 prefix 皆是）。对外引用时必须写明来源（网关配额文档 / 实测数据）。
- **只有 E1 / C9 的 savedPct 是实测**：喂了 `--observed`（E1）或 `--baseline`（C9 savedPct）才是基于真实调用日志的判定。把输出贴给上级时，加 `--report-note` 自带"哪些是声明、哪些是实测"的限定，防误读。

## 常见网关字段映射（usage → 三 token）

`eval/sample.jsonl` 的 `usage` 用规范字段名 `inputTokens / outputTokens / cacheReadTokens`；`summarize()` 也接受下列别名（按序取第一个存在的，全缺按 0，不编造）：

| 网关 | usage 原始字段 | 映射到 |
|---|---|---|
| OpenAI | `prompt_tokens` / `completion_tokens` | inputTokens / outputTokens |
| DeepSeek | `prompt_tokens` / `completion_tokens` / `prompt_cache_hit_tokens` | inputTokens / outputTokens / cacheReadTokens |
| Anthropic | `input_tokens` / `output_tokens` / `cache_read_input_tokens` | inputTokens / outputTokens / cacheReadTokens |

> **横幅位置无关**：E1 只读 JSONL 的 `reportedTotal` 字段，不依赖横幅在返回体里的位置；横幅可放开头/末尾/独立字段，只需能算出 `shown/total` 并写进 JSONL（放独立字段时，解析逻辑按你的字段名调整）。

> **带安全门（SSRF 防护）的框架怎么验横幅**：若抓取拒内网，用**公网长文**验证，例如 `https://www.gutenberg.org/files/84/84-0.txt`（数十万字符纯文本）；不要为验证去绕安全门。这是场景提示，不是要求。

## 与「模式包」的关系

语义同源，工具独立。模式包里那些"封顶数字"被原样搬进 `policy.example.json`；
但判定逻辑（`policy-lint.mjs`）只吃 JSON，不读任何框架的 schema，所以你用 OpenAI / Anthropic / LangChain / 自建 ReAct 都能跑。
怎么挂到具体框架，看 `portability.md`。

## 不适用场景

- 需要**精读大文件中段**且不能靠 offset 定向（那是另一类问题，本套件只保证"截断时诚实"，不保证"自动读全"）。
- 需要**多级子代理编排**（C6 只约束 depth=1 的浅层隔离；深树编排请用专门编排框架）。
- 需要把"省钱契约"写进训练 / 微调——本套件是**运行时判定**，不是训练数据。

## 文件清单

- `policy.schema.json` —— policy.json 的 JSON Schema（draft-07 子集，含 `subagent.inUse` 与可选 `prefix`）
- `policy.example.json` —— 示例（翻译自模式包封顶数字；`prefix` 故意留空，故默认 C9=UNVERIFIED）
- `policy-lint.mjs` —— 核心：C1–C9 + E1 可判定器（零依赖，支持 `--tool-count/--agent-config/--fixture/--observed/--baseline/--selftest-host/--report-note`）
- `prompt-pagination.md` —— 可直接粘进 system prompt 的中文 / 英文契约文本
- `portability.md` —— 8 个框架的挂载点对照表
- `eval/lib/summarize.mjs` —— 观测统计（policy-lint 与 summarize-calls 共用）
- `eval/summarize-calls.mjs` + `eval/sample.jsonl` —— 观测日志汇总 CLI 与样例
