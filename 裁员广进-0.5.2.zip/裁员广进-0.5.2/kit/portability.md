# portability.md —— 六条契约如何挂到主流框架

每一行给出：框架的**挂载点**、对应的 **policy 字段**、以及一行可粘贴片段（≤3 行）。
片段是伪代码，落到你的代码里替换变量名即可；所有片段都引用 `policy.json` 里的同名字段。

| 框架 | 挂载点 | 对应 policy 字段 | 一行可粘贴片段 |
|---|---|---|---|
| OpenAI（Responses/Assistants） | 构造请求时 | tools.maxTools, output.capBytes | `tools = pick(tools, policy.tools.maxTools); if (resp.truncated) emit(policy.output.truncationBanner)` |
| Anthropic（Messages） | 系统提示 + max_tokens | output.capBytes, telemetry | `system += PAGINATION_RULE; body.max_tokens = policy.output.capBytes` |
| LangChain | bindTools 之前 | tools.maxTools | `llm.bindTools(tools.slice(0, policy.tools.maxTools))` |
| LangGraph | subgraph 节点 | subagent.readonly, subagent.maxDepth | `subgraph(readonly=policy.subagent.readonly, depth<=policy.subagent.maxDepth)` |
| MCP | tools/list 过滤 | tools.denylist, tools.maxTools | `tools = tools.filter(t=>!policy.tools.denylist.includes(t.name)).slice(0,policy.tools.maxTools)` |
| vLLM · Ollama（经代理） | 代理层 | output.capBytes, rateLimit | `proxy.maxTokens=policy.output.capBytes; proxy.rpm=policy.rateLimit.requestsPerMinute` |
| n8n | Function 节点 | rateLimit, output.capBytes | `if (calls>policy.rateLimit.burst) return wait(); out=out.slice(0,policy.output.capBytes)` |
| 自建 ReAct 循环 | 主循环 | 全部字段 | `if (truncated) reportTotal(); if (depth>policy.subagent.maxDepth) stop()` |

> **字节口径（output.capBytes）**：填的是**字节数**不是字符数。UTF-8 下中文约 3 字节/字、ASCII 1 字节；若框架按字符截断，请换算后填写（例如 4000 个中文字符 ≈ 12000 字节）。

注：分页模式（`pagination.mode`）按框架能力选 `offset`（读区间）/ `page`（页码）/ `cursor`（游标）；
子代理隔离（`subagent.readonly`/`maxDepth`）只有在框架支持派生子代理时才生效，否则把 `subagent.inUse` 设 `false`（C6 → UNVERIFIED）。

## 静态前缀预算（C9 / `prefix`）怎么量

C9 量的是**每轮 prompt 里那份固定开销**：`systemBytes`（系统提示字节）+ `toolSchemaBytes`（工具 schema 序列化字节），
两者之和不得超过 `maxTotalBytes`。各栈怎么量这两段：

| 框架 | 怎么量静态前缀 |
|---|---|
| OpenAI | `systemBytes` = system/developer 消息的 UTF-8 字节；`toolSchemaBytes` = `JSON.stringify(tools)` 的字节（即喂进 `tools` 参数的那段）。 |
| Anthropic | `systemBytes` = `system` 字段文本字节；`toolSchemaBytes` = `tools` 数组序列化字节（input_schema 合计）。 |
| LangChain | `systemBytes` = 系统 prompt 模板字节；`toolSchemaBytes` = `bindTools` 时传入工具定义的 JSON 字节。 |
| LangGraph | 同 LangChain；子图 state schema 若也进 prompt 一并计入 `systemBytes`。 |
| MCP | `toolSchemaBytes` = `tools/list` 返回的工具描述字节（这就是客户端塞进上下文的量）；`systemBytes` 按宿主系统提示算。 |
| vLLM · Ollama | `toolSchemaBytes` = 传了 function calling 时 tools 字段字节；纯 chat 场景可把 `toolSchemaBytes` 记 0、只量 system。 |
| n8n | `systemBytes` = Function 节点里拼进上下文的提示字节；`toolSchemaBytes` = 下游 LLM 节点工具描述字节。 |
| 自建 ReAct | `systemBytes` = 系统提示字节；`toolSchemaBytes` = 工具清单序列化字节；两者用 `Buffer.byteLength(s,'utf8')` 量即可。 |

度量后把三段写进 `policy.prefix`，跑 `policy-lint` 的 C9；要量化"省了多少"，另喂 `--baseline`（未改造前的调用日志）算 `savedPct`。
