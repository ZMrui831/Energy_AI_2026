#!/usr/bin/env node
// summarize-calls.mjs —— 从观测 JSONL 汇总调用成本与"截断诚实"指标（零依赖）
// 统计逻辑复用 kit/eval/lib/summarize.mjs（与 policy-lint --observed 共用，保证一致）。
// 用法：
//   node kit/eval/summarize-calls.mjs kit/eval/sample.jsonl
//   node kit/eval/summarize-calls.mjs --input <calls.jsonl>

import { readFileSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { summarize } from './lib/summarize.mjs';

const here = dirname(fileURLToPath(import.meta.url));

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--input') out.input = argv[++i];
    else if (!argv[i].startsWith('-')) out.input = argv[i];
  }
  return out;
}
const args = parseArgs(process.argv.slice(2));
const path = resolve(args.input || (here + '/sample.jsonl'));

let raw;
try { raw = readFileSync(path, 'utf8').replace(/^﻿/, ''); }
catch (e) { process.stderr.write('[读取错误] ' + e.message + '\n'); process.exit(2); }

const records = raw.split('\n').map((s) => s.trim()).filter(Boolean)
  .map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);

const s = summarize(records);

let conclusion;
if (s.truncationRate > 0 && s.reportedTotalRate === 0) conclusion = '截断不诚实：存在截断调用但从未上报总数（C3E）';
else if (s.truncationRate > 0) conclusion = '存在截断样本且部分已上报总数：截断诚实契约基本成立';
else conclusion = '无截断记录';

const L = [];
L.push('== 调用成本与截断诚实汇总 ==');
L.push(`totalCalls          : ${s.totalCalls}`);
L.push(`truncatedCalls      : ${s.truncatedCalls}`);
L.push(`truncationRate      : ${s.truncationRate}`);
L.push(`totalReturnBytes    : ${s.totalReturnBytes}`);
L.push(`avgReturnBytes      : ${s.avgReturnBytes}`);
L.push(`reportedTotalCalls  : ${s.reportedTotalCalls}`);
L.push(`reportedTotalRate   : ${s.reportedTotalRate}`);
L.push(`avgInputTokens      : ${s.avgInputTokens}`);
L.push(`tokenSum            : ${s.tokenSum}`);
L.push(`costProxy           : ${s.costProxy}`);
L.push(`结论                : ${conclusion}`);
process.stdout.write(L.join('\n') + '\n');
process.stdout.write(JSON.stringify({ ...s, conclusion }) + '\n');
process.exit(0);
