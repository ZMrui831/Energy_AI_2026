#!/usr/bin/env node
// policy-lint.mjs —— 与框架无关的「省钱契约」可判定器（零依赖，仅用 Node 内置模块）
//
// 用法：
//   node kit/policy-lint.mjs --policy kit/policy.example.json
//   node kit/policy-lint.mjs --policy <p.json> --tool-count 13
//   node kit/policy-lint.mjs --policy <p.json> --agent-config <agent.json>
//   node kit/policy-lint.mjs --policy <p.json> --fixture
//   node kit/policy-lint.mjs --policy <p.json> --observed <calls.jsonl> [--baseline <base.jsonl>]
//   node kit/policy-lint.mjs --selftest-host
//
// 退出码：存在 FAIL → 1；全 PASS 或含 UNVERIFIED → 0；参数/读取错误 → 2。
// 设计约束：零依赖（仅 node: 内置 + 本地 ./eval/lib）；零框架耦合；纯 JSON 输入（stripBom）。

import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { summarize, FIXTURE_RECORDS } from './eval/lib/summarize.mjs';

const USAGE = `用法：
  node kit/policy-lint.mjs --policy <policy.json> [--tool-count N | --agent-config <agent.json>]
  node kit/policy-lint.mjs --policy <p.json> [--fixture | --observed <calls.jsonl>] [--baseline <base.jsonl>]
  node kit/policy-lint.mjs --selftest-host

每条契约输出 PASS / FAIL / UNVERIFIED；FAIL 会给出"改哪个字段、改成什么"。
--fixture 用内置样例跑通观测判定；--baseline 算静态前缀预算的 token 节省（savedPct）。
--report-note：在输出里追加"哪些是声明、哪些是实测"的限定，贴给上级时防误读。
末行输出 JSON 汇总；退出码：FAIL→1 / 全 PASS 或含 UNVERIFIED→0 / 参数读错→2。`;

function die(msg) { process.stderr.write('[参数/读取错误] ' + msg + '\n'); process.exit(2); }
function stripBom(s) { return typeof s === 'string' ? s.replace(/^﻿/, '') : s; }
function readText(path) { return stripBom(readFileSync(resolve(path), 'utf8')); }
function readJson(path) { return JSON.parse(readText(path)); }
function readRecords(path) {
  let raw;
  try { raw = readText(path); } catch (e) { return { records: [], error: e.message }; }
  const records = raw.split('\n').map((s) => s.trim()).filter(Boolean)
    .map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  return { records, error: null };
}
function clone(o) { return JSON.parse(JSON.stringify(o)); }
function pad(s, n) { s = String(s); return s.length >= n ? s : s + ' '.repeat(n - s.length); }
function g(obj, ...keys) { let c = obj; for (const k of keys) { if (c == null) return undefined; c = c[k]; } return c; }

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--policy') out.policy = argv[++i];
    else if (a === '--agent-config') out.agentConfig = argv[++i];
    else if (a === '--tool-count') out.toolCount = argv[++i];
    else if (a === '--observed') out.observed = argv[++i];
    else if (a === '--fixture') out.fixture = true;
    else if (a === '--baseline') out.baseline = argv[++i];
    else if (a === '--selftest-host') out.selftestHost = true;
    else if (a === '--report-note') out.reportNote = true;
    else if (a === '-h' || a === '--help') out.help = true;
  }
  return out;
}

// ---- agent-config 工具计数（四种形态） ----
function countTools(ac) {
  if (ac == null) return null;
  if (Array.isArray(ac)) return ac.length;
  if (Array.isArray(ac.tools)) return ac.tools.length;
  if (Array.isArray(ac.functions)) return ac.functions.length;
  if (typeof ac.tools === 'number') return ac.tools;
  if (typeof ac.tool_count === 'number') return ac.tool_count;
  return null;
}
function listToolNames(ac) {
  let arr = null;
  if (Array.isArray(ac)) arr = ac;
  else if (Array.isArray(ac.tools)) arr = ac.tools;
  else if (Array.isArray(ac.functions)) arr = ac.functions;
  if (!arr) return [];
  return arr.map((t) => (typeof t === 'string' ? t : (t && (t.name || (t.function && t.function.name))) || null)).filter(Boolean);
}

// ---- E1 判定（共享：main 与 selftest-host 都用它） ----
function e1Verdict(stats) {
  if (stats.totalCalls === 0)
    return { verdict: 'UNVERIFIED', evidence: '无真实调用样本（需宿主先产生 ≥1 轮调用）', fix: '用 --fixture 跑通判定，或接入真实 usage.jsonl' };
  if (stats.truncatedCalls > 0 && stats.reportedTotalCalls === 0)
    return { verdict: 'FAIL', evidence: `截断调用 ${stats.truncatedCalls}/${stats.totalCalls}，但上报总数 0 → C3E（截断却从不报总数）`, fix: '在截断时输出总数（如 "Found X of Y"），或换法核对到 Y。' };
  return { verdict: 'PASS', evidence: `截断调用 ${stats.truncatedCalls}/${stats.totalCalls}；上报总数 ${stats.reportedTotalCalls}；截断诚实契约成立`, fix: '' };
}

// 内置 policy 示例（与 kit/policy.example.json 一致，不含 prefix，供 --selftest-host 自包含使用）
const EXAMPLE_POLICY = {
  schemaVersion: 1,
  tools: { maxTools: 13, allowlist: [], denylist: [] },
  output: { capBytes: 65536, capLines: 800, truncationBanner: 'Found {shown} of {total}', requireReportTotal: true },
  pagination: { mode: 'offset', requireRangeNote: true },
  compaction: { thresholdRatio: 0.8, retainRatio: 0.2, headroomTokens: 4096 },
  subagent: { inUse: true, readonly: true, maxDepth: 1, maxOutputTokens: 8192 },
  rateLimit: { requestsPerMinute: 10, burst: 20 },
  telemetry: { fields: ['inputTokens', 'outputTokens', 'cacheReadTokens', 'toolCalls', 'truncatedCalls'] }
};

// ============ 检查定义 ============
// 每个 run(ctx) 返回 { verdict, evidence, fix } 或 null（跳过）。ctx = { policy, args, obs, obsSummary, hasObserved, baselineSummary, savedPct }
const CHECKS = [
  {
    id: 'C1', title: '工具表受限',
    run: (ctx) => {
      const policy = ctx.policy, args = ctx.args;
      const maxTools = g(policy, 'tools', 'maxTools');
      if (!(typeof maxTools === 'number' && maxTools > 0))
        return { verdict: 'FAIL', evidence: `tools.maxTools=${JSON.stringify(maxTools)}（应为正整数）`, fix: '将 tools.maxTools 设为 >0 的整数（例如 13）。' };
      if (args.toolCount !== undefined) {
        const used = Number(args.toolCount);
        if (used <= maxTools) return { verdict: 'PASS', evidence: `--tool-count=${used} <= maxTools=${maxTools}`, fix: '' };
        return { verdict: 'FAIL', evidence: `--tool-count=${used} > maxTools=${maxTools}`, fix: `裁掉超出部分，使工具数 <= ${maxTools}（当前声明 ${used}）。` };
      }
      if (args.agentConfig) {
        let ac;
        try { ac = readJson(args.agentConfig); } catch (e) { return { verdict: 'UNVERIFIED', evidence: `无法读取 agent-config：${e.message}`, fix: '确认 --agent-config 路径与 JSON 合法性。' }; }
        const used = countTools(ac);
        if (used == null)
          return { verdict: 'UNVERIFIED', evidence: 'agent-config 结构无法识别工具数（需含 tools[]/functions[]，或本身就是数组）', fix: '改用 --tool-count <N> 最简入参，或让配置暴露工具数组。' };
        if (used <= maxTools) return { verdict: 'PASS', evidence: `实际工具数=${used} <= maxTools=${maxTools}`, fix: '' };
        const names = listToolNames(ac);
        const overflow = names.length ? names : [`(共 ${used} 个)`];
        return { verdict: 'FAIL', evidence: `实际工具数=${used} > maxTools=${maxTools}`, fix: `裁掉超出部分，使工具数 <= ${maxTools}；当前工具：${overflow.join(', ')}。` };
      }
      return { verdict: 'UNVERIFIED', evidence: `tools.maxTools=${maxTools}；未提供 --tool-count/--agent-config，无法核对实际工具数`, fix: '传 --tool-count <N> 或 --agent-config <agent.json> 以比对真实工具数量。' };
    }
  },
  {
    id: 'C2', title: '输出封顶',
    run: (ctx) => {
      const policy = ctx.policy;
      const capBytes = g(policy, 'output', 'capBytes');
      if (!(typeof capBytes === 'number' && capBytes > 0 && capBytes <= 262144))
        return { verdict: 'FAIL', evidence: `output.capBytes=${JSON.stringify(capBytes)}（须 0<capBytes<=262144）`, fix: '将 output.capBytes 设为 1..262144 之间（例如 65536）。' };
      const capLines = g(policy, 'output', 'capLines');
      if (capLines !== undefined && !(typeof capLines === 'number' && capLines > 0))
        return { verdict: 'FAIL', evidence: `output.capLines=${JSON.stringify(capLines)}（若存在须 >0）`, fix: '将 output.capLines 设为正整数（例如 800），或删除该字段。' };
      return { verdict: 'PASS', evidence: `capBytes=${capBytes}${capLines !== undefined ? `; capLines=${capLines}` : ''}`, fix: '' };
    }
  },
  {
    id: 'C3', title: '截断诚实',
    run: (ctx) => {
      const policy = ctx.policy;
      const banner = g(policy, 'output', 'truncationBanner');
      const req = g(policy, 'output', 'requireReportTotal');
      const hasToken = typeof banner === 'string' && (/of/i.test(banner) || banner.includes('共'));
      if (!hasToken)
        return { verdict: 'FAIL', evidence: `truncationBanner=${JSON.stringify(banner)}（须含 'of' 或 '共'）`, fix: '让 truncationBanner 含总数占位，例如 "Found {shown} of {total}"。' };
      if (req !== true)
        return { verdict: 'FAIL', evidence: `requireReportTotal=${JSON.stringify(req)}（须为 true）`, fix: '将 output.requireReportTotal 设为 true，强制截断时上报总数。' };
      return { verdict: 'PASS', evidence: `banner 含总数标记（${JSON.stringify(banner)}）且 requireReportTotal=true`, fix: '' };
    }
  },
  {
    id: 'C4', title: '分页契约',
    run: (ctx) => {
      const policy = ctx.policy;
      const mode = g(policy, 'pagination', 'mode');
      const note = g(policy, 'pagination', 'requireRangeNote');
      const okMode = ['offset', 'page', 'cursor'].includes(mode);
      if (!okMode)
        return { verdict: 'FAIL', evidence: `pagination.mode=${JSON.stringify(mode)}（须为 offset/page/cursor）`, fix: '将 pagination.mode 设为 offset（推荐）/page/cursor。' };
      if (note !== true)
        return { verdict: 'FAIL', evidence: `pagination.requireRangeNote=${JSON.stringify(note)}（须为 true）`, fix: '将 pagination.requireRangeNote 设为 true，要求引用截断区时注明范围。' };
      return { verdict: 'PASS', evidence: `mode=${mode}; requireRangeNote=true`, fix: '' };
    }
  },
  {
    id: 'C5', title: '压缩阈值',
    run: (ctx) => {
      const policy = ctx.policy;
      const t = g(policy, 'compaction', 'thresholdRatio');
      const r = g(policy, 'compaction', 'retainRatio');
      const h = g(policy, 'compaction', 'headroomTokens');
      if (!(typeof t === 'number' && t > 0 && t < 1))
        return { verdict: 'FAIL', evidence: `thresholdRatio=${JSON.stringify(t)}（须 0<t<1）`, fix: '将 compaction.thresholdRatio 设为 (retainRatio,1) 之间（例如 0.8）。' };
      if (!(typeof r === 'number' && r > 0 && r < t))
        return { verdict: 'FAIL', evidence: `retainRatio=${JSON.stringify(r)}（须 0<retainRatio<thresholdRatio=${t}）`, fix: `将 compaction.retainRatio 设为 (0,${t}) 之间（例如 ${Math.round(t * 0.25 * 100) / 100}）。` };
      if (!(typeof h === 'number' && h > 0))
        return { verdict: 'FAIL', evidence: `headroomTokens=${JSON.stringify(h)}（须 >0）`, fix: '将 compaction.headroomTokens 设为正整数（例如 4096）。' };
      return { verdict: 'PASS', evidence: `threshold=${t}; retain=${r}; headroom=${h}`, fix: '' };
    }
  },
  {
    id: 'C6', title: '子代理隔离',
    run: (ctx) => {
      const policy = ctx.policy;
      const inUse = g(policy, 'subagent', 'inUse');
      if (inUse === false)
        return { verdict: 'UNVERIFIED', evidence: '声明未使用子代理，隔离契约不适用（不是"已达成"）', fix: '若要声明已隔离，请设 inUse:true 并给三字段（readonly/maxDepth/maxOutputTokens）' };
      const ro = g(policy, 'subagent', 'readonly');
      const md = g(policy, 'subagent', 'maxDepth');
      const mo = g(policy, 'subagent', 'maxOutputTokens');
      if (ro !== true)
        return { verdict: 'FAIL', evidence: `subagent.readonly=${JSON.stringify(ro)}（须 true）`, fix: '将 subagent.readonly 设为 true，禁止子代理写操作。' };
      if (md !== 1)
        return { verdict: 'FAIL', evidence: `subagent.maxDepth=${JSON.stringify(md)}（须 1）`, fix: '将 subagent.maxDepth 设为 1，限制子代理不再派生子代理。' };
      if (!(typeof mo === 'number' && mo >= 1024 && mo <= 16384))
        return { verdict: 'FAIL', evidence: `subagent.maxOutputTokens=${JSON.stringify(mo)}（须 1024..16384）`, fix: '将 subagent.maxOutputTokens 设为 1024..16384 之间（例如 8192）。' };
      return { verdict: 'PASS', evidence: `readonly=true; maxDepth=1; maxOutputTokens=${mo}`, fix: '' };
    }
  },
  {
    id: 'C7', title: '限流',
    run: (ctx) => {
      const policy = ctx.policy;
      const rpm = g(policy, 'rateLimit', 'requestsPerMinute');
      const burst = g(policy, 'rateLimit', 'burst');
      if (!(typeof rpm === 'number' && rpm > 0))
        return { verdict: 'FAIL', evidence: `rateLimit.requestsPerMinute=${JSON.stringify(rpm)}（须 >0）`, fix: '将 rateLimit.requestsPerMinute 设为正整数（例如 10）。' };
      if (!(typeof burst === 'number' && burst >= rpm))
        return { verdict: 'FAIL', evidence: `rateLimit.burst=${JSON.stringify(burst)} < requestsPerMinute=${rpm}`, fix: `将 rateLimit.burst 设为 >= ${rpm}（例如 ${rpm * 2}）。` };
      return { verdict: 'PASS', evidence: `rpm=${rpm}; burst=${burst}（宿主声明值，lint 不校验真实性；对外报告须标注配额来源）`, fix: '' };
    }
  },
  {
    id: 'C8', title: '遥测',
    run: (ctx) => {
      const policy = ctx.policy;
      const fields = g(policy, 'telemetry', 'fields');
      if (!Array.isArray(fields))
        return { verdict: 'FAIL', evidence: `telemetry.fields=${JSON.stringify(fields)}（须为数组）`, fix: '将 telemetry.fields 设为字段名数组。' };
      const need = ['inputTokens', 'outputTokens', 'toolCalls'];
      const missing = need.filter((f) => !fields.includes(f));
      if (missing.length)
        return { verdict: 'FAIL', evidence: `telemetry.fields=${JSON.stringify(fields)}；缺少 ${missing.join(', ')}`, fix: `在 telemetry.fields 至少加入 ${missing.join(', ')}。` };
      return { verdict: 'PASS', evidence: `fields=${JSON.stringify(fields)}`, fix: '' };
    }
  },
  {
    id: 'C9', title: '静态前缀预算',
    run: (ctx) => {
      const policy = ctx.policy;
      const pfx = g(policy, 'prefix');
      // 基线 delta（只记录，不改变判定）
      let deltaNote = '';
      if (ctx.baselineSummary) {
        const bAvg = ctx.baselineSummary.avgInputTokens;
        if (ctx.obsSummary && ctx.savedPct != null) {
          const oAvg = ctx.obsSummary.avgInputTokens;
          deltaNote = `；baseline avgInputTokens=${bAvg}，observed avgInputTokens=${oAvg}，savedPct=${(ctx.savedPct * 100).toFixed(1)}%`;
          if (!(oAvg < bAvg)) deltaNote += '；未观察到节省（基线/观测相近或更差）';
        } else {
          deltaNote = `；baseline avgInputTokens=${bAvg}（未提供 --observed/--fixture，无法算 savedPct）`;
        }
      }
      if (pfx == null)
        return { verdict: 'UNVERIFIED', evidence: '未声明静态前缀预算（prefix 缺失）' + deltaNote, fix: '在 policy 增加 "prefix": { "systemBytes": <int>, "toolSchemaBytes": <int>, "maxTotalBytes": <int> }（要求 systemBytes+toolSchemaBytes <= maxTotalBytes）。' };
      const sb = g(pfx, 'systemBytes'), tb = g(pfx, 'toolSchemaBytes'), mb = g(pfx, 'maxTotalBytes');
      const allPos = [sb, tb, mb].every((v) => typeof v === 'number' && v > 0);
      if (!allPos)
        return { verdict: 'FAIL', evidence: `prefix 字段须全为正整数：systemBytes=${JSON.stringify(sb)}, toolSchemaBytes=${JSON.stringify(tb)}, maxTotalBytes=${JSON.stringify(mb)}` + deltaNote, fix: '确保 prefix 三个字段都为正整数。' };
      if (sb + tb > mb)
        return { verdict: 'FAIL', evidence: `静态前缀超预算：systemBytes+toolSchemaBytes=${sb + tb} > maxTotalBytes=${mb}` + deltaNote, fix: `把 maxTotalBytes 提到 >= ${sb + tb}，或削减 systemBytes/toolSchemaBytes。` };
      return { verdict: 'PASS', evidence: `静态前缀 ${sb}+${tb} <= ${mb}` + deltaNote, fix: '' };
    }
  },
  {
    id: 'E1', title: '观测证据（截断诚实）',
    run: (ctx) => {
      if (!ctx.hasObserved) return null; // 未给 --observed/--fixture 则跳过
      return e1Verdict(ctx.obsSummary);
    }
  }
];

function printStats(s, source) {
  const L = [];
  L.push(`== 观测统计（${source}） ==`);
  L.push(`totalCalls          : ${s.totalCalls}`);
  L.push(`truncatedCalls      : ${s.truncatedCalls}`);
  L.push(`truncationRate      : ${s.truncationRate}`);
  L.push(`totalReturnBytes    : ${s.totalReturnBytes}`);
  L.push(`avgReturnBytes      : ${s.avgReturnBytes}`);
  L.push(`reportedTotalCalls  : ${s.reportedTotalCalls}`);
  L.push(`reportedTotalRate   : ${s.reportedTotalRate}`);
  L.push(`tokenSum            : ${s.tokenSum}`);
  L.push(`costProxy           : ${s.costProxy}`);
  process.stdout.write(L.join('\n') + '\n');
}

// ---- 宿主接入自检（自包含，不读外部文件） ----
function runSelftestHost() {
  const groups = [];
  function A(group, id, ctx, expected) {
    const c = CHECKS.find((x) => x.id === id);
    const r = c.run(ctx);
    const actual = r ? r.verdict : 'SKIP';
    groups.push({ group, check: id, expected, actual, ok: actual === expected });
  }
  // C1：--tool-count 双向
  A('C1 tool-count 双向', 'C1', { policy: EXAMPLE_POLICY, args: { toolCount: '13' } }, 'PASS');
  A('C1 tool-count 双向', 'C1', { policy: EXAMPLE_POLICY, args: { toolCount: '20' } }, 'FAIL');
  // C6：inUse 双向
  A('C6 inUse 双向', 'C6', { policy: EXAMPLE_POLICY, args: {} }, 'PASS');
  const noSub = clone(EXAMPLE_POLICY); noSub.subagent.inUse = false;
  A('C6 inUse 双向', 'C6', { policy: noSub, args: {} }, 'UNVERIFIED');
  // E1：样本 / 空 双向
  A('E1 样本/空 双向', 'E1', { policy: EXAMPLE_POLICY, args: {}, obsSummary: summarize(FIXTURE_RECORDS), hasObserved: true }, 'PASS');
  A('E1 样本/空 双向', 'E1', { policy: EXAMPLE_POLICY, args: {}, obsSummary: summarize([]), hasObserved: true }, 'UNVERIFIED');
  // C9：prefix 双向（无→UNVERIFIED / 合规→PASS / 超预算→FAIL）
  A('C9 prefix 双向', 'C9', { policy: EXAMPLE_POLICY, args: {} }, 'UNVERIFIED');
  const okP = clone(EXAMPLE_POLICY); okP.prefix = { systemBytes: 2000, toolSchemaBytes: 4000, maxTotalBytes: 8192 };
  A('C9 prefix 双向', 'C9', { policy: okP, args: {} }, 'PASS');
  const overP = clone(EXAMPLE_POLICY); overP.prefix = { systemBytes: 6000, toolSchemaBytes: 6000, maxTotalBytes: 8192 };
  A('C9 prefix 双向', 'C9', { policy: overP, args: {} }, 'FAIL');

  const L = [];
  L.push('== 宿主接入自检报告（--selftest-host，自包含，不读外部文件） ==');
  L.push('检查项                       期望          实际          结果');
  L.push('---------------------------- ------------ ------------ ----');
  for (const a of groups) L.push(`${pad(a.group + ' / ' + a.check, 28)} ${pad(a.expected, 12)} ${pad(a.actual, 12)} ${a.ok ? 'OK' : 'MISMATCH'}`);
  const nOk = groups.filter((a) => a.ok).length;
  const allOk = nOk === groups.length;
  L.push(`双向断言组数：${new Set(groups.map((a) => a.group)).size}；通过 ${nOk}/${groups.length}`);
  L.push(`SELFTEST: ${allOk ? 'PASS' : 'FAIL'} (${nOk}/${groups.length})`);
  process.stdout.write(L.join('\n') + '\n');
  process.exit(allOk ? 0 : 1);
}

// ============ 主流程 ============
const args = parseArgs(process.argv.slice(2));
if (args.help) { process.stdout.write(USAGE + '\n'); process.exit(0); }
if (args.selftestHost) { runSelftestHost(); }

if (!args.policy) die('缺少必需参数 --policy <policy.json>');
if (args.toolCount !== undefined && (!Number.isInteger(Number(args.toolCount)) || Number(args.toolCount) < 0)) die('--tool-count 须为非负整数');

let policy;
try { policy = readJson(args.policy); } catch (e) { die(`无法读取/解析 policy 文件 ${args.policy}：${e.message}`); }

// 观测数据（--fixture 用内置样例；--observed 读文件；空/缺失 → 0 条 → E1 UNVERIFIED）
let obs = null, obsSummary = null, hasObserved = false;
if (args.fixture) { obs = { records: FIXTURE_RECORDS, source: 'fixture', error: null }; hasObserved = true; }
else if (args.observed) { const rd = readRecords(args.observed); obs = { records: rd.records, source: 'observed', error: rd.error }; hasObserved = true; }
if (hasObserved) obsSummary = summarize(obs.records);

// 基线 delta
let baselineSummary = null, savedPct = null;
if (args.baseline) {
  const b = readRecords(args.baseline);
  baselineSummary = summarize(b.records);
  if (obsSummary && baselineSummary.totalCalls > 0 && baselineSummary.avgInputTokens > 0)
    savedPct = (baselineSummary.avgInputTokens - obsSummary.avgInputTokens) / baselineSummary.avgInputTokens;
}

const ctx = { policy, args, obs, obsSummary, hasObserved, baselineSummary, savedPct };

const checks = [];
let pass = 0, fail = 0, unverified = 0;
for (const c of CHECKS) {
  const r = c.run(ctx);
  if (r == null) continue;
  checks.push({ id: c.id, title: c.title, verdict: r.verdict, evidence: r.evidence, fix: r.fix });
  if (r.verdict === 'PASS') pass++;
  else if (r.verdict === 'FAIL') fail++;
  else unverified++;
}

const lines = [];
lines.push('ID   契约                判定          证据');
lines.push('---- -------------------- ------------ ----------------------------------------');
for (const c of checks) {
  lines.push(`${pad(c.id, 4)} ${pad(c.title, 18)} ${pad(c.verdict, 12)} ${c.evidence}`);
  if (c.verdict === 'FAIL' && c.fix) lines.push(`     └ 修复：${c.fix}`);
}
lines.push('');
const ok = fail === 0;
lines.push(`汇总：PASS=${pass}  FAIL=${fail}  UNVERIFIED=${unverified}  → ${ok ? 'OK（无 FAIL）' : '存在 FAIL'}`);
process.stdout.write(lines.join('\n') + '\n');

if (hasObserved) printStats(obsSummary, obs.source);

if (baselineSummary) {
  process.stdout.write(`baseline avgInputTokens=${baselineSummary.avgInputTokens}` + (savedPct != null ? `；savedPct=${(savedPct * 100).toFixed(1)}%` : '；未提供 --observed/--fixture，无法算 savedPct') + '\n');
}

const REPORT_NOTE = '声称值均来自 policy 声明；E1/C9 的实测性以 observed/baseline 是否提供为准';
if (args.reportNote) process.stdout.write('reportNote: ' + REPORT_NOTE + '\n');

const summary = { ok, pass, fail, unverified, checks };
if (hasObserved) summary.observed = obsSummary;
if (savedPct != null) summary.savedPct = Math.round(savedPct * 10000) / 10000;
if (args.reportNote) summary.reportNote = REPORT_NOTE;
process.stdout.write(JSON.stringify(summary) + '\n');

process.exit(ok ? 0 : 1);
