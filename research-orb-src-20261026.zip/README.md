# research-orb（科研悬浮球）

面向**科研学习与跟踪指导**的独立桌面悬浮球助手。**独立 dsh 系列应用**：不加载 DSH 插件、不依赖 DSH 进程、不与 dsh-orb（贾维斯）/萌源共享任何数据、端口、锁或环境变量。

## 定位
- 用户：智慧能源 / 电网方向研究者
- 能力：查背景 · 品论文 · 及时问答 · 计时与进度自动收纳 · 跟踪与指导
- 底座可复用：同一 ball 底座将来可挂 **健康助手 / 养老助手 / 通用** 等插件包（参赛与多形态复用的关键）

## 三层架构
| 层 | 内容 | 来源 |
| --- | --- | --- |
| **base 底座** | 悬浮球窗口/面板 UI/托盘/单实例、ASR、TTS、原生选择 | `vendor/orb-base/`（orb 0.4.0 冻结快照，只读复制） |
| **core 内核** | AgentCore（provider 抽象/会话/流式）、受控网络、安全写、插件宿主 | 自研 |
| **plugins 插件** | research-*（检索/阅读/笔记/计时/复盘）等 | 自研（插件契约见 docs/ARCH.md） |

## 底座来源（冻结快照）
- 来源仓库：`D:\AI_Workspace\dsh-orb-cordis`（版本 **0.4.0**）
- 冻结文件清单与 SHA-256：`vendor/orb-base/SOURCE.json`（9 个文件：panel/floating.html+css、native-selection/**）
- 约定：**只读复制、单向依赖**；后续 orb 演进**不自动同步**，需要时由主管决定重新冻结

## 目录
```
apps\desktop\      Electron 主进程与面板
  main.mjs           入口：--selftest 短路 → 否则加载 electron 起窗口 + IPC 接线
  electron 主逻辑     透明置顶球窗口 / 托盘 / 单实例 / 面板动作分发（全在 main.mjs 内）
  core-host.mjs      组合根：providers + agent + 计时/进度引擎 + 插件宿主（供主进程与自检共用）
  timer-driver.mjs   主进程计时驱动器：秒级节拍/空闲探测/通知/下行推送（与 electron 解耦，纯 node 可测）
  selftest.mjs       --selftest 的实现体（纯 node，不 import electron）
  preload.cjs        唯一窄接口：send / on / version / paths
  ui-bridge.mjs      注入 renderer 的面板桥接（输入框/流式/会话列表/设置页/文献面板/计时面板/球体角标圆环）
packages\core\     AgentCore：providers / session / agent / net / safefs / config
                    + timer（番茄钟与账本）/ progress（汇总）/ report（日报周报）/ timer-store（数据模型）
packages\plugins\  插件宿主（registry.mjs）+ 插件（hello/、research-literature/、research-timer/）
  research-literature\connectors\  arXiv / OpenAlex / Crossref / Semantic Scholar
  research-literature\lib\         记录归一/打分、PDF 抽取、卡片 schema、Orama 索引、BibTeX、RAG 问答、引用校验（DOI 双源/PDF 引文逐字命中/拒引）、严谨性修正（数值单位回溯与量纲警告/元数据完整性/强度三档渲染）
  research-timer\                  计时插件：8 条命令 + 1 张卡片（面板只是渲染器，动作原路返回命令层）
data\              运行期数据（sessions / notes / pdf / index / exports / timer / progress / reports / projects / logs / shots / secrets.json）—— 与 dsh-orb 完全分离
data\.chromium\     Electron userData（Cache / GPUCache / Local Storage / Preferences 等 Chromium 产物，阶段 3.1 起单独一层，data\ 顶层只放领域目录）
tools\             守卫与取证：guard-path / snapshot / isolation-fingerprint / shot /
                   smoke-* / probe-* / accept-stage2* / accept-stage3 + probe-stage3-scale /
                   accept-stage3-1 + probe-stage3-1（阶段 3.1 验收）/ move-chromium-cache（userData 分层迁移）/
                   accept-stage3-2（注入回归+版本单一来源）/ accept-stage4-block1（引用级可验证）/
                   accept-stage4-block2（严谨性修正）/ accept-stage4-block3（笔记操作深化）/ accept-stage4-block4（skill 安装器+docx）/ shots-stage32（stage32 GUI 截图补拍：球角标/计时面板/空闲询问/设置页）
docs\              ARCH.md（架构）、DOMAIN-smart-energy.md（领域与文献源）、DEPS.md（依赖与 license）、STAGE-LOG.md（验收记录）
```

## 运行
```cmd
start.cmd        正常启动（沙箱开启，用户入口）
start-dev.cmd    仅调试用：清 ELECTRON_RUN_AS_NODE + --no-sandbox（agent shell 内 Chromium 子进程起不来时的变通）
```
自检（不需要 electron、不发任何网络请求）：
```cmd
node apps\desktop\main.mjs --selftest          :: provider / 模型 / 插件 / 限速队列 / 降级状态
node apps\desktop\main.mjs --selftest --json   :: 机器可读，便于脚本核对
```
测试：
```cmd
node --test tests\*.test.mjs
```
命令行触发器（演示/验收用；需应用已启动，`start.cmd` 已带 `--remote-debugging-port=9336`）：
```cmd
node tools\coach-trigger.mjs --run-daily            :: 日报轮（抓屏 + 合并增量 + 归纳评分）
node tools\coach-trigger.mjs --incremental          :: 手动触发一次增量抽取
node tools\coach-trigger.mjs --perception status    :: 读感知状态（同意模式/预算级别/今日计数）
node tools\coach-trigger.mjs --perception grant     :: 替验收点一次「授权屏幕记录（本次会话）」
```
> ⚠️ `--perception grant` **不是用户授权入口**。它只是把「设置页 → 授权屏幕记录（本次会话）」这一步用脚本点掉（同一个按钮、同一条 `/perception grant` 命令、同一条 `consent-granted` 审计），**确认语义不变——仍需人在 GUI 点确认**；找不到按钮就直接失败退出（没有绕过确认的后门）。真实用户授权入口始终是应用内设置页那个按钮，命令行仅供验收/演示。
阶段 3 验收取证（真实路径，含 31 秒崩溃探针，约 1 分钟）：
```cmd
node tools\accept-stage3.mjs            :: ①~⑧ 逐项取证到 data\logs\stage3-*.{txt,json}
node tools\probe-isolation.mjs baseline --tag stage3
node tools\probe-isolation.mjs verify   --tag stage3
```
阶段 3.1 验收取证（项目/阶段/里程碑端到端 + 加速污染对照 + 文档对齐 + userData 分层，约 3 分钟）：
```cmd
node tools\accept-stage3-1.mjs          :: 7 项逐项取证，汇总落 data\logs\stage31-summary.json
node tools\probe-stage3-1.mjs fast      :: 单独跑加速场景探针（scale=60，仅取证用）
node tools\probe-stage3-1.mjs real      :: 单独跑真实场景探针（scale=1）
node tools\move-chromium-cache.mjs --dry-run   :: 预演 userData 迁移（data\ → data\.chromium\）
```
阶段 4 块 1 验收取证（引用级可验证：真实 DOI 贴置信度 / 伪造 DOI 拒引 / PDF 引文命中与不命中，约 2 分钟）：
```cmd
node tools\accept-stage4-block1.mjs      :: 9 项逐项取证，汇总落 data\logs\stage41-summary.json
```
阶段 4 块 2 验收取证（严谨性修正：三档同屏输出 / 数值单位回溯与量纲警告 / 元数据完整性 / fail-closed 回归，约 2 分钟）：
```cmd
node tools\accept-stage4-block2.mjs      :: 7 项逐项取证，汇总落 data\logs\stage42-summary.json
node tools\shots-stage32.mjs             :: stage32 GUI 截图补拍（需真实系统空闲 ≥5 分钟触发空闲询问那张）
```
阶段 4 块 3 验收取证（笔记操作深化：双向链接/模板/批量/检索/导出/Zotero 只读，真实 registry 路径，约 3 分钟）：
```cmd
node tools\accept-stage4-block3.mjs      :: 9 项逐项取证，汇总落 data\logs\stage43-summary.json（accept-b3 验收主题自清理）
```
阶段 4 块 4 验收取证（skill 安装器 + docx：两段式安装/篡改拒绝/退休目录/docx 双验证/LaTeX 成对/越界防护，约 4 分钟）：
```cmd
node tools\accept-stage4-block4.mjs      :: 9 项逐项取证，汇总落 data\logs\stage44-summary.json（卡片主题自清理；docx/tex/bib 与 .retired 退休目录常驻作证据）
```
验收加速参数（仅验收用，计时秒/真实秒，60 = 15 分钟番茄 15 秒走完）：
```cmd
set RESEARCH_ORB_TIME_SCALE=60 && start.cmd
```
加速模式下计时插件会在 `/start`、`/status` 与面板卡片三处显式提示「当前为加速测试模式，数据不计入进度」，日报/周报将加速会话单列在「测试 / 加速数据」区，不污染真实进度统计。

## 计时与进度（阶段 3）
八条命令（面板「计时」卡片同款操作；球体角标/圆环实时显示剩余时间）：

| 命令 | 作用 | 说明 |
| --- | --- | --- |
| `/start [分钟] <项目> [<阶段>]` | 开始一个番茄钟 | 1~180 自定义；首个数字 token 是分钟，其余为位置参数（`/start 25 gfm 文献综述`）；也支持 `--project <id\|名> --stage <id\|名>`；都省略则沿用上次 |
| `/pause` `/resume` `/stop` | 暂停 / 恢复 / 收尾 | 已专注时间先落账再暂停，不丢；stop 返回本次汇总 |
| `/status` | 当前计时 + 今日专注/产出 + 通知开关 | 含崩溃恢复与空闲询问的如实报告；加速模式下显式提示 |
| `/today` | 当日日报 | 专注/分项目/当日新增卡片与 .bib 计数 → `data/reports/daily-<date>.md` |
| `/weekly` | 本周周报 | 逐日重算 7 天明细 + 产出汇总去重 → `data/reports/weekly-<周一>.md` |
| `/project [list\|new\|add-stage\|done]` | 项目与阶段管理 | 计时归类的最小单位；`new [<id>] <名称>` 可显式指定 id，`done <项目> [<阶段>] [<里程碑>]` 支持阶段级里程碑 |

- **segment 计账制**：专注时长的唯一计账单位是当天 `data/timer/<日期>.jsonl` 的 `segment` 行，「当天专注 = 当天 segment.sec 求和」永远可重算；跨午夜自动切分
- **崩溃恢复不静默改写**：按最后一次心跳（30s）收尾，心跳后的未知间隔作为 gap 如实报告，不猜不补；状态损坏时磁盘一个字节不改，`/start` 可开新账
- **空闲 >5 分钟只询问**：保留还是扣除由用户定，不操作则不做任何改动
- **加速数据单列、不污染进度**：`RESEARCH_ORB_TIME_SCALE≠1` 的会话其 segment/stop 行不进 progress 汇总与日报/周报「专注时长」，单列「测试 / 加速数据」区；启用时三处显式提示（账本 schema 与排除规则见 docs/ARCH.md）
- **项目/阶段两级汇总**：日报「分项目」按 `项目 → 阶段` 两级展示（数据来自当日账本的 projectId/stageId），项目或阶段已删时如实标注「项目已删除/阶段已删除」而非丢时段
- **空态友好**：`data/projects/` 缺失或为空时 `/status`、`/today`、面板卡片均正常渲染（显示「未归类」），不报错
- **日报/周报是派生品**：随时可删随时可重建；LLM 润色只影响"复盘与建议"一小段，失败/超时/返回空都回落纯模板
- 通知可一键关闭（设置页或计时面板），关闭后计时本身不受影响

## 科研核心（阶段 2 + P-R4 块 3-4）
七条命令（面板「设置 → 插件卡片 → 打开文献面板」也能图形化操作）：

| 命令 | 作用 | 说明 |
| --- | --- | --- |
| `/find <关键词\|主题别名>` | 四源并联检索 → 去重 → 按 venue+年份+引用数打分 | 别名如 `gfm`/`hvdc`/`microgrid`；`--max N --min N`；候选落 `data/index/candidates/` |
| `/card <DOI \| PDF 路径>` | 生成 16 字段研究卡片并归档 | `--find 1,3,5` 批量；`--topic <名>` 换主题；`--heuristic` 跳过模型 |
| `/bib <主题>` | 导出 `data/exports/<主题>-<日期>.bib` | 导出后用 citation-js 回读自检（条数 + DOI 必须一致） |
| `/recall <问题>` | 对已归档卡片做混合检索问答 | **答案末尾必附由检索层生成的出处表**；中文提问会自动补英文检索式 |
| `/verify doi <DOI>` / `/verify quote <引文> --pdf <路径>` | 引用级校验（产品红线） | DOI 经 Crossref/OpenAlex 双源解析 + 题录模糊比对**贴置信度**；PDF 引文**归一化后逐字命中**才放行；校验失败输出「引用校验失败（原因）」并拒引；`--title/--year/--author` 给题录断言 |
| `/verify numbers <文本> [--pdf <路径>]` | 数值与单位校验（块 2） | 抽取 `p.u./MW/MVA/kV/H/Hz/%` 等量纲并**回溯原文**（命中/失败逐条呈现）；量纲一致性警告（多功率基准、MW/MVA 混用、有功>视在、数量级范围）；没有原文就明说「无法回溯」，不假装校验过 |
| `/verify meta <DOI\|URL\|PDF路径>` | 元数据完整性（块 2） | 预印本标记（arXiv/SSRN 等）+ arXiv 版本（v1/v2）+ 检索时间 + DOI 可解析性缺项，缺什么**显式列什么**；PDF 来源显式提示「无 DOI，题录未经权威源解析」 |
| `/verify answer --file <断言JSON>` | 多断言总装（块 2 验收口径） | 一段输出同屏三档强度（图例常显）+ 来源清单/拒引区 + **未验证断言区** + 数值与单位、元数据提示两区；unverified 断言绝不进结论区 |
| `/note new <topic> <slug> --template 综述\|方法\|实验\|失败` | 模板建卡（块 3） | 模板定义在插件 `templates.json`（可改不改码）；预置 `template/<类>` 与 `project/<主题>` 标签 + 骨架 sections；手动 slug 不覆盖已有卡 |
| `/note links <slug>` | 双向链接（块 3） | 正文 `[[slug]]`；`data/notes/.links.json` 反向索引（查询前强制重建，手改文件也准）；两侧查询（本卡引用/被谁引用）+ 全库悬空链接清单 |
| `/note batch --topic <t> [--pick 1,2,3] [--tag A,B] [--status done]` | 批量操作（块 3） | 批量打标签（front-matter 原路过 schema）+ 批量改状态（draft/reading/done，存 meta 侧车——16 字段红线外数据）；每卡变更落 plugins.jsonl 审计；**重渲染保留用户批注与 [[链接]]** |
| `/note find <query> [--tag X] [--project gfm] [--status done]` | 笔记检索（块 3） | 有 query 走 Orama 混合检索（中文自动补英文检索式，与 /recall 同策略）+ 过滤；无 query 纯维度过滤；`--project` 双路命中（主题目录 或 `project/X` 标签） |
| `/note export <主题> [--slug <s>] [--docx] [--latex]` / `/note zotero <路径>` / `/note image <图片路径> --topic <t>` | 导出与互通（块 3-4） | Markdown 单篇/整主题合并（目录+大纲结构）；**`--docx` 真导出**（标题层级/元信息表/批注，zip 解包 + 项目内受管 venv python-docx 双验证）；**`--latex` 出 `.tex`+`.bib` 成对**（citation-js 自检）；Zotero 只读互通：.bib / CSL-JSON → 候选集（适配器只 import 读函数，静态断言无任何写路径，绝不写 Zotero 目录）；`/note image` 占位卡（source/image + ocr-pending，OCR 留接口） |

- 字段表严格取自 `docs/DOMAIN-smart-energy.md` 第 4 节（16 个，含中文全角括号的 `读数（0-5）`）；schema 不符**不写盘**
- 书目字段（title/authors/venue/year/doi/url）只来自连接器元数据，**LLM 只负责 7 个解释性字段**
- 索引是派生品：真相是 `data/notes/**.md`；Orama 序列化坏了会自动重建；同一篇论文归到多个主题时按论文身份去重并记 warn
- 合规：只取公开元数据与开放全文；不抓付费全文、不绕鉴权；sci-hub 类域名仍被 denied
- 引用红线（P-R4 块 1）：无来源不出结论——未经校验的断言集中进「未验证断言」区，禁止混在正文当结论；结论强度三档（已证实/推断/待验证）强制渲染，图例常显
- 严谨性修正（P-R4 块 2）：数值与单位回溯原文 + 量纲一致性警告（只提示不静默修）；元数据完整性缺项显式提示（预印本/arXiv 版本/检索时间/DOI 可解析性）；渲染层 fail-closed——断言缺 `effective` 一律按「待验证」处理，任何字段缺失都兜底为可读文案，绝不出 undefined

## 模型
- `deepseek-api`：官方 API（`data\secrets.json` 的 deepseek.apiKey）
- `school-gateway`：学校 Anthropic 兼容网关（baseUrl/token **运行时**从 `~/.claude/settings.json` 直读，密钥不复制）
- 不使用 Ollama（本机性能不足）

## 限速与降级（阶段 1）
- 令牌桶按 `provider:model` 分桶；`deepseek-reasoner` 严格 **10 次/分钟**，超限**排队**（不丢请求、不直发）
- 429 指数退避 2/4/8/16/32s（最多 5 次）；所有出网写 `data/logs/net.jsonl`
- reasoner 连续失败（限流/超时/5xx 一类）达阈值 → **自动改走 deepseek-chat**，并在面板与 `sessions/*.jsonl` 的 notice 行**明示**「已降级到 deepseek-chat（原因…）」
- 面板状态栏实时显示：当前 provider·模型 / 限速队列长度 / reasoner 本分钟用量 / 降级状态

## 当前状态
- [x] 骨架、安全设施占位、底座冻结、secrets 模板
- [x] 阶段 0：Electron 骨架可跑 + 隔离/网络测试全绿（**主管已核验，见 docs/STAGE-LOG.md**）
- [x] 阶段 1：AgentCore（双 provider）+ 插件宿主 + 会话落盘 + 面板可对话（**主管已核验**）
- [x] 阶段 2：文献检索 + PDF 抽取 + 卡片笔记 + 混合检索索引 + 引用导出（**主管已核验**）
- [x] 阶段 3：计时与进度自动收纳（番茄钟/崩溃恢复/日报周报，**12/12 验收通过**；GUI 截图已于 P-R4 块 2 期补拍 → `data\shots\stage32-*.png`，取证中顺带修掉计时面板死循环与 add-stage 名称引用两个真 bug）
- [x] 阶段 3.1：项目/阶段/里程碑端到端 + 加速数据不污染进度（单列 + 显式提示）+ 文档逐字段对齐 + userData 分层（`data\.chromium\`，**7/7 验收通过**；遗留：GPU 环境级崩溃与本项目无因果关系，待桌面环境复核 GUI）
- [x] P-R4 块 1：引用级可验证（产品红线）——DOI 双源解析贴置信度 / PDF 引文归一化逐字命中 / 拒引带原因 / 未验证断言专区 / 强度三档强制渲染（**9/9 验收通过**，含真实 DOI 与伪造 DOI 实测）
- [x] P-R4 块 2：严谨性修正——数值与单位回溯原文 + 量纲警告 / 元数据完整性（预印本·arXiv 版本·检索时间·DOI 可解析性缺项）/ 三档同屏总装 + 未验证断言区 / 渲染层 fail-closed 修复（主管复核必修项，含变异测试）
- [x] P-R5：非影响性 use（L1 无头浏览器 + L4 让路 + 进程收尾纪律/合规自检/隔离五查）——版本 0.4.0-phase4.2
- [x] P-R6：解耦成型（4 形态 pack）+ 主题/外观（CSS 变量自建，3 套）+ 演示/打包/企业雏形——版本 0.4.0-phase4.2
- [x] P-R6.1：外观微调（6 条实拍评审）+ **版本收敛 0.6.0**（package.json 唯一真相，托盘/设置页/8×plugin.json/4×pack.json 全派生）+ dataonts 目录就绪 + ARCH 口径更正
- [x] P-R4 块 3：笔记操作深化——[[slug]] 双向链接与反向索引（悬空可列）/ 四类模板（插件 templates.json 可改不改码）/ 批量打标签改状态（审计落日志，重渲染保留批注与链接）/ 标签+项目维度检索 / Markdown 单篇与合并导出（含 Word .docx / LaTeX .tex+.bib，见块 4）/ Zotero 只读互通（无写路径静态断言）；**版本单一来源必修**：package.json 升 0.4.0-phase4.2，托盘/设置页/plugin.json/插件常量全部派生（四处一致钉死）
- [x] P-R4 块 4：skill 适配性安装器 + docx——依赖评审（DEPS.md §6，选 docx@9.11.0 纯 JS/零 install 脚本，--save-exact --ignore-scripts）；两段式安装（权限清单确认 + sha256 白名单逐文件校验，篡改必拒）；卸载只移不删（.retired）；权限沙箱越界抛错零写入（单测）；**docx 真跑**（标题层级/元信息表/批注，zip 解包 + python-docx 双验证）；LaTeX .tex+.bib 成对；截图转 MD 占位卡（OCR 留接口）；禁自动更新/远程执行
- [ ] P-R4 总验收：全链路回归 + 汇报
- [ ] 阶段 4：跟踪与指导（周复盘/薄弱点/导师沟通草稿）
- [ ] 阶段 5：插件化多形态（科研/健康/养老/通用）+ 打包
