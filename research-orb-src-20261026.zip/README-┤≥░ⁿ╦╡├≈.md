# 打包说明（research-orb 全量副本）

> 生成时间：2026-10-26 14:21 ｜ 来源：`D:\explorer!\research-orb`（**源目录未做任何修改**）
> 方式：robocopy /E /MT:16 全量复制 ｜ 校验：文件数 80,660、体积 2.28 GB，与源完全一致

## 一、这个包是什么
research-orb「问源」的完整工作副本：源码 + 测试 + 工具 + 文档 + 运行数据 + 回滚点。
用于归档 / 换机复跑 / 上传 GitHub 前取材。

## 二、体积构成（决定 GitHub 怎么传）
| 目录 | 体积 | 是否该进 GitHub |
|---|---|---|
| `.snapshots` | **1,756 MB** | ❌ 回滚点（GitHub 单文件 100MB 限制 / 仓库建议 <1GB） |
| `data` | 492 MB | ❌ 本机运行数据（会话/日志/截图/DB），含真实使用痕迹 |
| `.venv` | 43.6 MB | ❌ Python 虚拟环境 |
| `node_modules` | 29.3 MB | ❌ 由 `package-lock.json` 还原 |
| `tests` | 8.8 MB | ✅ 要（含夹具图片） |
| `dist-package` | 3.3 MB | ❌ 打包产物 |
| `tools` | 2.5 MB | ✅ 要 |
| `packages` | 2.0 MB | ✅ 要（核心） |
| `docs` | 0.7 MB | ✅ 要 |
| `apps` | 0.4 MB | ✅ 要 |
| `vendor` | 0.1 MB | ✅ 要（冻结快照，必须原样） |

**建议入库体积 ≈ 15 MB**。

## 三、上传 GitHub 建议
1. 把同目录 `.gitignore.github` 改名 `.gitignore`，再 `git init`
2. **不要** `git add -A` 全量；先过滤再 `git status` 复核
3. 提交前跑 `node tools\run-tests.mjs`（期望 **962/962**）与 `node tools\check-imports.mjs`（0 失败）
4. 若要带 demo 数据，放 `docs/demo-fixtures/` 且**脱敏**（原图/聊天/密钥一律不带）

## 四、复跑（拿到包就能跑）
```powershell
cd <包路径>
$env:CODEBUDDY_SAFE_DELETE_ENABLED='0'
node tools\run-tests.mjs          # 962/962
node tools\check-imports.mjs      # 0/526
node tools\check-pack-ui.mjs
node tools\accept-s74-wake.mjs    # 10/10
node tools\redteam-demo.mjs       # 红队 5/5
```
Electron 验收（需图形环境，且**不能有其它实例在跑**）：`node tools\accept-s51-e2e.mjs` → 26/26