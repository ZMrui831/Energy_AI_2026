// tests/cu-geom.test.mjs —— S45·P2 第 3 条：坐标纯函数单测。
//
// 覆盖主管点名的四种情形：正常屏 / 负原点 / 多屏拼接 / 越界（null 而非 clamp）。
// 真机那块屏的 bounds（{x:280,y:89,width:1360,height:871}）直接当作 fixture 写死，
// 于是"本机实测过一次"这件事以后可以被复算，不用再截一次屏。

import test from 'node:test'
import assert from 'node:assert/strict'

import { centerOf, roundTripError, screenAt, toAbsolute, toNormalized, validBounds } from '../packages/core/src/tools/impl/cu-geom.mjs'

/** 本机实测（2026-10-24 probe）：单屏，原点在 (280,89)。 */
const LOCAL = { index: 0, bounds: { x: 280, y: 89, width: 1360, height: 871 }, scale: 1, windowId: 1 }
/** 负原点（副屏在主屏左侧的典型布局）。 */
const NEG = { index: 1, bounds: { x: -1920, y: -160, width: 1920, height: 1080 }, scale: 1, windowId: 2 }

test('cu-geom: 正常屏 —— 归一化与绝对互转', () => {
  assert.deepEqual(toAbsolute(LOCAL.bounds, 0, 0), [280, 89])
  assert.deepEqual(toAbsolute(LOCAL.bounds, 1000, 1000), [280 + 1360, 89 + 871])
  assert.deepEqual(toAbsolute(LOCAL.bounds, 500, 500), [280 + 680, 89 + 435.5])
  assert.deepEqual(toNormalized(LOCAL.bounds, 280, 89), [0, 0])
  assert.deepEqual(toNormalized(LOCAL.bounds, 280 + 1360, 89 + 871), [1000, 1000])
})

test('cu-geom: 往返可逆（容差 1e-6，误差必须来自浮点而非换算写歪）', () => {
  for (const [ax, ay] of [[280, 89], [900, 500], [1640, 960], [1234.5, 456.25]]) {
    const r = roundTripError(LOCAL.bounds, ax, ay)
    assert.equal(r && r.ok, true, `往返应可逆 @ ${ax},${ay} -> err=${r && r.err}`)
  }
})

test('cu-geom: 负原点 —— bounds.x/y 可为负，不能取绝对值', () => {
  assert.deepEqual(toAbsolute(NEG.bounds, 0, 0), [-1920, -160])
  assert.deepEqual(toAbsolute(NEG.bounds, 1000, 1000), [0, 920])
  assert.deepEqual(toNormalized(NEG.bounds, -1920, -160), [0, 0])
  assert.deepEqual(toNormalized(NEG.bounds, -960, 380), [500, 500])
  // 负原点屏上"点 -500"是合法的，不是越界
  assert.notEqual(toNormalized(NEG.bounds, -1000, 0), null)
})

test('cu-geom: 多屏拼接 —— screenAt 能定位到正确的那块屏', () => {
  const screens = [LOCAL, NEG]
  const hitMain = screenAt(screens, 900, 500)
  const hitSecond = screenAt(screens, -1000, 400)
  assert.equal(hitMain.index, 0)
  assert.equal(hitSecond.index, 1)
  assert.deepEqual(hitMain.normalized, toNormalized(LOCAL.bounds, 900, 500))
  // 两屏都不覆盖的点 -> null（不许退化到"最近的一块屏"）
  assert.equal(screenAt(screens, 5000, 5000), null)
  assert.equal(screenAt([], 0, 0), null)
})

test('cu-geom: 越界返回 null —— 绝不 clamp（clamp 会把点到屏外粉饰成点到边上）', () => {
  assert.equal(toNormalized(LOCAL.bounds, 279, 500), null, 'x 比左边界小 1px 也算越界')
  assert.equal(toNormalized(LOCAL.bounds, 280 + 1361, 500), null)
  assert.equal(toNormalized(LOCAL.bounds, 900, 88), null)
  assert.equal(toNormalized(LOCAL.bounds, 900, 89 + 872), null)
  assert.equal(toAbsolute(LOCAL.bounds, -1, 500), null)
  assert.equal(toAbsolute(LOCAL.bounds, 1001, 500), null)
  assert.equal(toAbsolute(LOCAL.bounds, Number.NaN, 500), null)
  assert.equal(toAbsolute(LOCAL.bounds, Number.POSITIVE_INFINITY, 500), null)
})

test('cu-geom: bounds 非法一律 null（宽高为 0 / 字段缺失 / 非对象）', () => {
  assert.equal(validBounds(null), null)
  assert.equal(validBounds({ x: 0, y: 0, width: 0, height: 100 }), null)
  assert.equal(validBounds({ x: 0, y: 0, width: 100 }), null)
  assert.equal(validBounds('bounds'), null)
  assert.equal(toAbsolute({ x: 0, y: 0, width: 0, height: 0 }, 500, 500), null)
  assert.equal(toNormalized({ x: 0, y: 0, width: -100, height: 100 }, 0, 0), null)
})

test('cu-geom: centerOf —— UIA 的 control rect 中心（含退化矩形）', () => {
  assert.deepEqual(centerOf({ x: 100, y: 200, width: 40, height: 20 }), [120, 210])
  assert.deepEqual(centerOf({ x: 0, y: 0, width: 0, height: 0 }), [0, 0])
  assert.equal(centerOf(null), null)
  assert.equal(centerOf({ x: 0, y: 0, width: '宽', height: 10 }), null)
})

test('cu-geom: UI 桥 rect → 归一化 → 绝对 → 再归一化，结果一致（不做二次 DPI 缩放）', () => {
  const rect = { x: 300, y: 120, width: 200, height: 40 }
  const abs = centerOf(rect)
  const norm = toNormalized(LOCAL.bounds, abs[0], abs[1])
  assert.notEqual(norm, null)
  const back = toAbsolute(LOCAL.bounds, norm[0], norm[1])
  assert.ok(Math.abs(back[0] - abs[0]) < 1e-6 && Math.abs(back[1] - abs[1]) < 1e-6)
  // scale 一律不参与：scale=2 的屏与 scale=1 应得到同一个归一化值
  const hidpi = { ...LOCAL, bounds: { ...LOCAL.bounds }, scale: 2 }
  assert.deepEqual(toNormalized(hidpi.bounds, abs[0], abs[1]), norm)
})
