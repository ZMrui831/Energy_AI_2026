// tests/tools-executor.test.mjs
//
// 执行器闸门（P-R7）：**这是整套工具层最关键的一批钉子**。
// 覆盖：未登记工具、参数缺失（不猜）、拒绝根、根外、红线、confirm 未批准/超时不执行、
// grant 只抹 confirm、写前快照、/undo 复原、写后读回校验失败自动回滚、审计字段齐全。
//
// 全部用内存文件系统（tests/helpers/fake-fs.mjs），不落真实磁盘、可反复跑。

import test from 'node:test'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { appendFileSync, existsSync, mkdirSync } from 'node:fs'
import { dirname, resolve } from 'node:path'

import { createPathResolver } from '../packages/core/src/tools/paths.mjs'
import { createToolRegistry, defineTool } from '../packages/core/src/tools/registry.mjs'
import { createPolicy, createGrantStore, TIER } from '../packages/core/src/tools/permissions.mjs'
import { createRollback } from '../packages/core/src/tools/rollback.mjs'
import { createToolExecutor } from '../packages/core/src/tools/executor.mjs'
import { createFakeFs } from './helpers/fake-fs.mjs'
import { logPath } from '../packages/core/src/safefs.mjs'

const ROOT = resolve(import.meta.dirname, '..')
const DESKTOP = 'D:\\Desktop'
const OUT = 'D:\\AI_Workspace\\_out'

const paths = createPathResolver({
  root: ROOT,
  home: process.env.USERPROFILE,
  env: { USERPROFILE: process.env.USERPROFILE },
  desktopReader: () => DESKTOP,
})

const sha = (s) => createHash('sha256').update(Buffer.from(String(s), 'utf8')).digest('hex')

/** 造一个带两个工具的 registry：只读 ping 与写文件 write。 */
function build({ fs, confirm, grants, onEvent, toolTiers, auditPath, auditRows } = {}) {
  const fakeFs = fs || createFakeFs()
  const registry = createToolRegistry()
  registry.register(
    defineTool({
      id: 'demo.ping',
      label: '试通',
      description: '只读探针',
      params: { type: 'object', properties: { path: { type: 'string' } }, required: ['path'], additionalProperties: false },
      targetsOf: (a) => [a.path],
      run: (args) => ({ pong: true, path: args.path }),
    }),
  )
  registry.register(
    defineTool({
      id: 'demo.write',
      label: '写文件',
      description: '写一个文件',
      params: {
        type: 'object',
        properties: { path: { type: 'string' }, content: { type: 'string' } },
        required: ['path', 'content'],
        additionalProperties: false,
      },
      targetsOf: (a) => [a.path],
      write: true,
      run: (args, ctx) => {
        // __probe__ 是"确实执行了"的旁证（拒绝路径下它必须不存在）
        fakeFs.writeFileSync(ROOT + '\\__probe__', args.content)
        const p = ctx.paths.resolveInput(args.path).path
        const buf = Buffer.from(String(args.content), 'utf8')
        fakeFs.writeFileSync(p, buf)
        return { path: p, bytes: buf.length, hash: sha(buf) }
      },
    }),
  )
  const policy = createPolicy({ paths, toolTiers: { 'demo.ping': TIER.AUTO, 'demo.write': TIER.CONFIRM, ...(toolTiers || {}) } })
  const rollback = createRollback({ root: ROOT + '\\data\\snapshots', fs: fakeFs })
  const executor = createToolExecutor({
    registry,
    policy,
    grants: grants || createGrantStore(),
    paths,
    rollback,
    fs: fakeFs,
    ...(confirm ? { confirm } : {}),
    ...(onEvent ? { onEvent } : {}),
    ...(auditPath ? { auditPath } : {}),
    // 注入式审计：把审计行收进内存数组，测试直接读它
    audit: (rec) => {
      if (auditRows) auditRows.push(rec)
      else appendRealAudit(auditPath, rec)
    },
  })
  return { registry, policy, rollback, executor, fs: fakeFs }
}

function appendRealAudit(path, rec) {
  const p = path || logPath('tool.jsonl')
  if (!existsSync(dirname(p))) mkdirSync(dirname(p), { recursive: true })
  appendFileSync(p, JSON.stringify(rec) + '\n', 'utf8')
}

// ---------------------------------------------------------------- 闸门

test('exec: 未登记的工具一律拒绝（fail-closed）', async () => {
  const { executor } = build()
  const r = await executor.run({ toolId: 'nope.tool', args: {}, origin: 'test' })
  assert.equal(r.ok, false)
  assert.equal(r.error.code, 'E_TOOL_UNKNOWN')
  assert.equal(r.denied, false, '未登记属于错误而非策略拒绝，两者在审计里要能区分')
})

test('exec: 缺少必填参数 -> 拒绝，绝不猜测补全', async () => {
  const { executor } = build()
  const r = await executor.run({ toolId: 'demo.write', args: { path: 'project:a.txt' }, origin: 'test' })
  assert.equal(r.ok, false)
  assert.equal(r.error.code, 'E_BAD_ARGS')
  assert.match(r.error.message, /content/)
})

test('exec: 多传未声明参数（additionalProperties=false）-> 拒绝', async () => {
  const { executor } = build()
  const r = await executor.run({ toolId: 'demo.ping', args: { path: 'project:a', extra: 1 }, origin: 'test' })
  assert.equal(r.error.code, 'E_BAD_ARGS')
  assert.match(r.error.message, /extra/)
})

test('exec: 拒绝根内即使 tier=auto 也拒绝，且**没有执行**', async () => {
  const fs = createFakeFs()
  const { executor } = build({ fs })
  const r = await executor.run({ toolId: 'demo.ping', args: { path: 'D:\\dsh-orb-project\\x' }, origin: 'test' })
  assert.equal(r.ok, false)
  assert.equal(r.error.code, 'E_ROOT_DENIED')
  assert.equal(r.denied, true)
})

test('exec: 授权根外 -> E_OUTSIDE_ROOTS（桌面别名之外的普通目录）', async () => {
  const { executor } = build()
  const r = await executor.run({ toolId: 'demo.ping', args: { path: `${process.env.USERPROFILE}\\Documents\\x` }, origin: 'test' })
  assert.equal(r.error.code, 'E_OUTSIDE_ROOTS')
})

test('exec: 红线文件（data\\secrets.json）即使在项目根内也拒绝', async () => {
  const { executor } = build()
  const r = await executor.run({ toolId: 'demo.ping', args: { path: 'project:data/secrets.json' }, origin: 'test' })
  assert.equal(r.error.code, 'E_REDLINE')
})

test('exec: desktop: 别名解析到系统登记桌面（D:\\Desktop），并落在该授权根内', async () => {
  const { executor } = build()
  const r = await executor.run({ toolId: 'demo.ping', args: { path: 'desktop:a.txt' }, origin: 'test' })
  assert.equal(r.ok, true)
  assert.deepEqual(r.targets, [DESKTOP + '\\a.txt'])
})

test('exec: 授权根 D:\\AI_Workspace\\_out 可写（第三个授权根）', async () => {
  const { executor } = build({ confirm: async () => ({ approved: true }) })
  const r = await executor.run({ toolId: 'demo.write', args: { path: OUT + '\\a.txt', content: 'hi' }, origin: 'test' })
  assert.equal(r.ok, true)
  assert.deepEqual(r.targets, [OUT + '\\a.txt'])
})

// ---------------------------------------------------------------- 确认

test('exec: confirm 档 —— 用户拒绝 => 不执行（且没有快照、没有写）', async () => {
  const fs = createFakeFs()
  const { executor, rollback } = build({ fs, confirm: async () => ({ approved: false }) })
  const r = await executor.run({ toolId: 'demo.write', args: { path: 'project:a.txt', content: 'x' }, origin: 'test' })
  assert.equal(r.ok, false)
  assert.equal(r.notExecuted, true)
  assert.equal(r.error.code, 'E_USER_DENIED')
  assert.equal(fs.existsSync(ROOT + '\\__probe__'), false, '拒绝后绝不能有任何副作用')
  assert.equal(rollback.list().length, 0, '拒绝的路径不该留下快照')
})

test('exec: confirm 档 —— **没有确认处理器时一律不执行**（headless fail-closed）', async () => {
  const fs = createFakeFs()
  const { executor } = build({ fs })
  const r = await executor.run({ toolId: 'demo.write', args: { path: 'project:a.txt', content: 'x' }, origin: 'test' })
  assert.equal(r.notExecuted, true)
  assert.equal(fs.existsSync(ROOT + '\\__probe__'), false)
})

test('exec: confirm 超时 = 不执行（不是默认放行）', async () => {
  const fs = createFakeFs()
  const never = () => new Promise(() => {}) // 永不回答
  const { executor } = build({ fs, confirm: never })
  const ex = createToolExecutor({
    registry: build({ fs }).registry,
    policy: createPolicy({ paths, toolTiers: { 'demo.write': TIER.CONFIRM } }),
    grants: createGrantStore(),
    paths,
    rollback: createRollback({ root: ROOT + '\\data\\snapshots', fs }),
    fs,
    confirm: never,
    confirmTimeoutMs: 60,
  })
  const r = await ex.run({ toolId: 'demo.write', args: { path: 'project:a.txt', content: 'x' }, origin: 'test' })
  assert.equal(r.ok, false)
  assert.equal(r.notExecuted, true)
  assert.equal(r.error.code, 'E_CONFIRM_TIMEOUT')
  assert.equal(fs.existsSync(ROOT + '\\__probe__'), false)
})

test('exec: 勾选"本次会话同类不再询问"后，同类工具不再询问（但档案不同类仍要问）', async () => {
  const grants = createGrantStore()
  let asked = 0
  const { executor } = build({
    grants,
    confirm: async () => {
      asked += 1
      return { approved: true, remember: true }
    },
  })
  const a = await executor.run({ toolId: 'demo.write', args: { path: 'project:a.txt', content: '1' }, origin: 'test' })
  assert.equal(a.ok, true)
  assert.equal(asked, 1)
  const b = await executor.run({ toolId: 'demo.write', args: { path: 'project:b.txt', content: '2' }, origin: 'test' })
  assert.equal(b.ok, true)
  assert.equal(asked, 1, '已授权同类，第二次不该再问')
  assert.equal(grants.has('demo.write'), true)
})

test('exec: grant 只抹 confirm，抹不掉 deny（拒绝根依然拒绝）', async () => {
  const grants = createGrantStore()
  grants.grant('demo.ping')
  const { executor } = build({ grants })
  const r = await executor.run({ toolId: 'demo.ping', args: { path: 'C:\\Windows\\x' }, origin: 'test' })
  assert.equal(r.error.code, 'E_ROOT_DENIED')
})

// ---------------------------------------------------------------- 快照 / 撤销

test('exec: 覆盖已存在文件前先快照，/undo 能原样复原', async () => {
  const fs = createFakeFs({ [ROOT + '\\a.txt']: '原始内容' })
  const { executor } = build({ fs, confirm: async () => ({ approved: true }) })
  const before = sha('原始内容')
  const r = await executor.run({ toolId: 'demo.write', args: { path: 'project:a.txt', content: '新内容' }, origin: 'test' })
  assert.equal(r.ok, true)
  assert.equal(r.undoable, true)
  assert.ok(r.snapshotId)
  const undone = executor.undoLast()
  assert.deepEqual(undone.restored, [ROOT + '\\a.txt'])
  assert.equal(sha(fs.readFileSync(ROOT + '\\a.txt').toString()), before, '撤销后必须与原始内容字节一致')
})

test('exec: 新建文件的撤销 = 删掉新建的（不会留下空文件）', async () => {
  const fs = createFakeFs()
  const { executor } = build({ fs, confirm: async () => ({ approved: true }) })
  const r = await executor.run({ toolId: 'demo.write', args: { path: 'project:new.txt', content: 'x' }, origin: 'test' })
  assert.equal(r.ok, true)
  const undone = executor.undoLast()
  assert.deepEqual(undone.removed, [ROOT + '\\new.txt'])
})

test('exec: /undo list 给出可撤销清单，撤销后再撤销会报 E_ALREADY_UNDONE', async () => {
  const { executor } = build({ confirm: async () => ({ approved: true }) })
  await executor.run({ toolId: 'demo.write', args: { path: 'project:a.txt', content: '1' }, origin: 'test' })
  const list = executor.undoList()
  assert.equal(list.length, 1)
  assert.equal(list[0].toolId, 'demo.write')
  executor.undoLast()
  assert.throws(() => executor.undoLast(), (e) => e.code === 'E_ALREADY_UNDONE')
})

// ---------------------------------------------------------------- 读回校验

test('exec: 写后读回校验一致 -> 通过（verified.hashMatch=true）', async () => {
  const fs = createFakeFs()
  const { executor } = build({ fs, confirm: async () => ({ approved: true }) })
  fs.writeFileSync(ROOT + '\\a.txt', 'x') // 让 rollback 的 existsSync 走通
  const r = await executor.run({ toolId: 'demo.write', args: { path: 'project:a.txt', content: 'abc' }, origin: 'test' })
  assert.equal(r.ok, true)
  assert.equal(r.verified.hashMatch, true)
  assert.equal(r.verified.bytesMatch, true)
})

test('exec: 写后读回校验失败（工具说写了但文件不存在）-> E_WRITE_VERIFY 并自动回滚', async () => {
  const fs = createFakeFs()
  const registry = createToolRegistry()
  registry.register(
    defineTool({
      id: 'demo.liar',
      label: '说谎的写',
      description: '宣称写了但没写',
      params: {
        type: 'object',
        properties: { path: { type: 'string' } },
        required: ['path'],
        additionalProperties: false,
      },
      targetsOf: (a) => [a.path],
      write: true,
      run: (a) => ({ path: a.path, bytes: 3, hash: 'deadbeef' }), // 撒谎
    }),
  )
  const policy = createPolicy({ paths, toolTiers: { 'demo.liar': TIER.AUTO } })
  const rollback = createRollback({ root: ROOT + '\\data\\snapshots', fs })
  const executor = createToolExecutor({
    registry, policy, paths, rollback, fs,
    grants: createGrantStore(),
  })
  const r = await executor.run({ toolId: 'demo.liar', args: { path: 'project:ghost.txt' }, origin: 'test' })
  assert.equal(r.ok, false)
  assert.equal(r.error.code, 'E_WRITE_VERIFY')
  assert.equal(r.rolledBack, true, '校验失败必须自动回滚')
})

// ---------------------------------------------------------------- 审计与事件

test('exec: 审计字段齐全（ts/toolId/args/decision/targets/result/hash/durationMs）', async () => {
  const rows = []
  const { executor } = build({
    confirm: async () => ({ approved: true }),
    auditRows: rows,
  })
  await executor.run({ toolId: 'demo.write', args: { path: 'project:a.txt', content: 'hello' }, origin: 'unit' })
  assert.equal(rows.length, 1)
  const row = rows[0]
  for (const k of ['ts', 'sessionId', 'origin', 'toolId', 'args', 'targets', 'decision', 'tier', 'result', 'hash', 'durationMs']) {
    assert.ok(k in row, `审计缺字段 ${k}`)
  }
  assert.equal(row.toolId, 'demo.write')
  assert.equal(row.result, 'ok')
  assert.equal(row.origin, 'unit')
  assert.ok(row.hash, '审计必须带 sha256')
  assert.ok(row.targets[0].startsWith('D:'), '审计里的路径必须是绝对路径（不是相对串）')
})

test('exec: 被拒绝也要落审计（拒绝是可追责的动作）', async () => {
  const rows = []
  const { executor } = build({ auditRows: rows })
  await executor.run({ toolId: 'demo.ping', args: { path: 'C:\\Windows\\x' }, origin: 'unit' })
  assert.equal(rows.length, 1)
  assert.equal(rows[0].result, 'denied')
  assert.equal(rows[0].code, 'E_ROOT_DENIED')
  assert.ok(rows[0].reason, '拒绝原因必须写进审计')
})

test('exec: 参数摘要不会把整篇正文塞进审计（长文本被截断）', async () => {
  const rows = []
  const { executor } = build({ confirm: async () => ({ approved: true }), auditRows: rows })
  await executor.run({ toolId: 'demo.write', args: { path: 'project:a.txt', content: 'x'.repeat(5000) }, origin: 'unit' })
  const s = JSON.stringify(rows[0].args)
  assert.ok(s.length < 800, `参数摘要应被截断，实际 ${s.length} 字符`)
  assert.match(rows[0].args.content, /…\(\d+\)$/)
})

test('exec: 事件流 start → confirm → done 齐全（界面据此渲染"正在做什么"）', async () => {
  const seen = []
  const { executor } = build({
    confirm: async () => ({ approved: true }),
    onEvent: (ev) => seen.push(ev.type),
  })
  await executor.run({ toolId: 'demo.write', args: { path: 'project:a.txt', content: 'x' }, origin: 'test' })
  assert.deepEqual(seen, ['tool:confirm', 'tool:start', 'tool:done'])
})

test('exec: 拒绝时事件是 tool:denied，且不产生 tool:start', async () => {
  const seen = []
  const { executor } = build({ onEvent: (ev) => seen.push(ev.type) })
  await executor.run({ toolId: 'demo.ping', args: { path: 'C:\\Windows\\x' }, origin: 'test' })
  assert.deepEqual(seen, ['tool:denied'])
})

// ---------------------------------------------------------------- 路径解析错误

test('exec: 路径解析失败（穿越/UNC/非法别名）-> 拒绝且不执行', async () => {
  const { executor } = build({ confirm: async () => ({ approved: true }) })
  for (const p of ['project:../outside', '\\\\srv\\share\\x', 'bogus:a']) {
    const r = await executor.run({ toolId: 'demo.ping', args: { path: p }, origin: 'test' })
    assert.equal(r.ok, false, p)
    assert.ok(['E_TRAVERSAL', 'E_UNC', 'E_UNKNOWN_ALIAS'].includes(r.error.code), `${p} -> ${r.error.code}`)
  }
})
