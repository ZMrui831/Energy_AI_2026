// tests/perception-import.test.mjs
//
// S3 感知事件导入测试。只测纯逻辑 + fake store（绝不 import A 路的 db.mjs、
// 绝不调用 defaultStore、绝不写真实 data/perception）。

import { test } from 'node:test'
import assert from 'node:assert/strict'
import os from 'node:os'
import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { importPerceptionEvents, parseEventLine } from '../packages/core/src/lifecycle/import.mjs'

// ---------------------------------------------------------------- 夹具

/** fake store：记录 upsert 调用与 audit 事件，支持 (ts,kind) 幂等查询。 */
function fakeStore() {
  const obs = []
  const audits = []
  const byKey = new Map() // `${created_atMs}|${kind}` -> rec
  return {
    obs,
    audits,
    upsertObservation(rec) {
      obs.push(rec)
      byKey.set(`${Date.parse(rec.created_at)}|${rec.kind}`, rec)
    },
    findObservationBySourceKey(ts, kind) {
      return byKey.get(`${ts}|${kind}`) ?? null
    },
    insertAuditEvent(e) {
      audits.push(e)
    },
  }
}

function makeTmp() {
  return mkdtempSync(join(os.tmpdir(), 'orb-imp-'))
}

function writeEvents(dir, name, lines) {
  writeFileSync(join(dir, name), lines.join('\n') + '\n', 'utf8')
}

// ---------------------------------------------------------------- parseEventLine

test('parseEventLine: 合法事件/空行/坏 JSON/缺字段/tick-batch 各分支', () => {
  const ok = parseEventLine('{"ts":1700000000000,"type":"window-switch","title":"文档"}')
  assert.equal(ok.ok, true)
  assert.match(ok.rec.id, /^obs_1700000000000_[0-9a-f]{10}$/)
  assert.equal(ok.rec.kind, 'window-switch')
  assert.equal(ok.rec.ts, 1700000000000)
  assert.equal(ok.rec.rawSha256.length, 64)

  assert.equal(parseEventLine('').ok, false)
  assert.equal(parseEventLine('   ').ok, false)
  assert.equal(parseEventLine('not-json{').ok, false)
  assert.equal(parseEventLine('[1,2,3]').ok, false) // 数组不是事件对象
  assert.equal(parseEventLine('{"type":"x"}').ok, false) // 缺 ts
  assert.equal(parseEventLine('{"ts":"bad","type":"x"}').ok, false) // ts 不可解析
  assert.equal(parseEventLine('{"ts":1}').ok, false) // 缺 type

  const tb = parseEventLine('{"ts":1700000000000,"type":"tick-batch","events":[]}')
  assert.equal(tb.ok, false)
  assert.equal(tb.isTickBatch, true)
})

// ---------------------------------------------------------------- 导入行为

test('importPerceptionEvents: 正常事件行导入，fake store 收到规范字段', () => {
  const dir = makeTmp()
  try {
    writeEvents(dir, 'events-20261017.jsonl', [
      '{"ts":1700000000000,"type":"window-switch","pid":1,"title":"主文件夹 - 文件资源管理器"}',
      '{"ts":1700000000500,"type":"idle-start","idleMs":5922}',
    ])
    const store = fakeStore()
    const res = importPerceptionEvents({ store, perceptionDir: dir, now: 1700000100000 })
    assert.equal(res.skipped, false)
    assert.equal(res.files, 1)
    assert.equal(res.imported, 2)
    assert.equal(res.skippedDuplicates, 0)
    assert.equal(res.skippedMalformed, 0)
    assert.equal(res.skippedTickBatch, 0)
    // store 收到规范化 observation 记录
    assert.equal(store.obs.length, 2)
    const [a, b] = store.obs
    assert.match(a.id, /^obs_1700000000000_[0-9a-f]{10}$/)
    assert.equal(a.kind, 'window-switch')
    assert.equal(a.source_frame_id, null)
    assert.equal(a.ocr_excerpt, null)
    assert.equal(a.created_at, new Date(1700000000000).toISOString())
    assert.equal(b.kind, 'idle-start')
    // 审计事件一条，带 summary
    assert.equal(store.audits.length, 1)
    assert.equal(store.audits[0].kind, 'perception-imported')
    assert.equal(store.audits[0].metadata.imported, 2)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('importPerceptionEvents: 幂等——同一文件跑两遍，第二遍 imported=0', () => {
  const dir = makeTmp()
  try {
    writeEvents(dir, 'events-20261017.jsonl', [
      '{"ts":1700000000000,"type":"window-switch"}',
      '{"ts":1700000001000,"type":"window-switch"}',
      '{"ts":1700000002000,"type":"idle-end"}',
    ])
    const store = fakeStore()
    const first = importPerceptionEvents({ store, perceptionDir: dir })
    assert.equal(first.imported, 3)
    const second = importPerceptionEvents({ store, perceptionDir: dir })
    assert.equal(second.skipped, false)
    assert.equal(second.imported, 0)
    assert.equal(second.skippedDuplicates, 3)
    assert.equal(store.obs.length, 3) // 没有重复写入
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('importPerceptionEvents: 畸形行跳过计数不抛、不中断后续好行', () => {
  const dir = makeTmp()
  try {
    writeEvents(dir, 'events-20261017.jsonl', [
      '完全不是 JSON',
      '{"ts":1700000000000,"type":"window-switch"}',
      '{"no-ts":true}',
      '',
      '{"ts":1700000001000,"type":"idle-end"}',
    ])
    const store = fakeStore()
    const res = importPerceptionEvents({ store, perceptionDir: dir })
    assert.equal(res.imported, 2)
    assert.equal(res.skippedMalformed, 3) // 坏 JSON + 缺 ts + 空行
    assert.equal(res.skippedTickBatch, 0)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('importPerceptionEvents: tick-batch 行跳过且计数，不进 store', () => {
  const dir = makeTmp()
  try {
    writeEvents(dir, 'events-20261017.jsonl', [
      '{"ts":1700000000000,"type":"tick-batch","events":[{"type":"window-switch"}]}',
      '{"ts":1700000001000,"type":"tick-batch","events":[]}',
      '{"ts":1700000002000,"type":"window-switch"}',
    ])
    const store = fakeStore()
    const res = importPerceptionEvents({ store, perceptionDir: dir })
    assert.equal(res.imported, 1)
    assert.equal(res.skippedTickBatch, 2)
    assert.equal(store.obs.length, 1)
    assert.equal(store.obs[0].kind, 'window-switch')
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('importPerceptionEvents: 目录不存在/空目录 → {skipped:true} 且不抛', () => {
  const store = fakeStore()
  // 目录不存在
  const missing = join(os.tmpdir(), 'orb-imp-not-exist-' + Date.now())
  let res
  assert.doesNotThrow(() => {
    res = importPerceptionEvents({ store, perceptionDir: missing })
  })
  assert.deepEqual(res, { skipped: true, note: '未发现 S2 数据，跳过' })
  // 空目录
  const dir = makeTmp()
  try {
    assert.doesNotThrow(() => {
      res = importPerceptionEvents({ store, perceptionDir: dir })
    })
    assert.equal(res.skipped, true)
    // 有目录但无 events-*.jsonl
    writeFileSync(join(dir, 'summary-20261017.jsonl'), '{}\n', 'utf8')
    res = importPerceptionEvents({ store, perceptionDir: dir })
    assert.equal(res.skipped, true)
    assert.equal(store.obs.length, 0)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('importPerceptionEvents: id 只含 ts+哈希前缀，无 title/文件名等敏感信息', () => {
  const dir = makeTmp()
  try {
    const secretTitle = '机密项目密码123456'
    writeEvents(dir, 'events-x-secret.jsonl', [
      `{"ts":1700000000000,"type":"window-switch","title":"${secretTitle}","process":"explorer.exe"}`,
    ])
    const store = fakeStore()
    importPerceptionEvents({ store, perceptionDir: dir })
    assert.equal(store.obs.length, 1)
    const id = store.obs[0].id
    assert.equal(id.includes(secretTitle), false)
    assert.equal(id.includes('explorer'), false)
    assert.equal(id.includes('secret'), false)
    assert.match(id, /^obs_\d{13}_[0-9a-f]{10}$/)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('importPerceptionEvents: 1 万行解析性能冒烟 <3s', () => {
  const dir = makeTmp()
  try {
    const lines = Array.from(
      { length: 10000 },
      (_, i) => `{"ts":${1700000000000 + i},"type":"window-switch","pid":${i}}`,
    )
    writeEvents(dir, 'events-big.jsonl', lines)
    const store = fakeStore()
    const t0 = performance.now()
    const res = importPerceptionEvents({ store, perceptionDir: dir })
    const ms = performance.now() - t0
    assert.equal(res.imported, 10000)
    assert.ok(ms < 3000, `导入 1 万行耗时 ${ms.toFixed(0)}ms，应 <3000ms`)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('importPerceptionEvents: 多文件按文件名排序处理 + 缺 insertAuditEvent 也能跑', () => {
  const dir = makeTmp()
  try {
    writeEvents(dir, 'events-20261016.jsonl', ['{"ts":1700000000000,"type":"a"}'])
    writeEvents(dir, 'events-20261017.jsonl', ['{"ts":1700000001000,"type":"b"}'])
    const obs = []
    const storeNoAudit = {
      upsertObservation: (r) => obs.push(r),
      findObservationBySourceKey: () => null,
      // 无 insertAuditEvent —— 接口可选降级
    }
    const res = importPerceptionEvents({ store: storeNoAudit, perceptionDir: dir })
    assert.equal(res.files, 2)
    assert.equal(res.imported, 2)
    assert.equal(obs.length, 2)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('importPerceptionEvents: 未注入 store 抛 E_NO_STORE（显式契约）', () => {
  const dir = makeTmp()
  try {
    assert.throws(() => importPerceptionEvents({ perceptionDir: dir }), /E_NO_STORE/)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})
