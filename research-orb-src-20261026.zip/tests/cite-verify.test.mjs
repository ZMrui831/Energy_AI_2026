// tests/cite-verify.test.mjs
//
// 引用校验器（P-R4 块 1，产品红线）的离线回归。
// 三个校验器的依赖（resolveDoi / readPdfText / resolveUrl）全部注入桩，
// 不发任何真实请求 —— 真实世界的三用例由 tools/accept-stage4-block1.mjs 取证。
//
// 验收口径在本文件里的对应：
//   ① 真实 DOI 正确引用（贴校验置信度）        → verifyDoiSource 首条 + renderVerifyReport
//   ② 伪造 DOI 被拒（贴拒绝理由）              → verifyDoiSource 404 分支
//   ③ PDF quote 命中与不命中各一例             → verifyQuoteSource 两条

import test from 'node:test'
import assert from 'node:assert/strict'

import {
  STRENGTHS,
  TITLE_STRONG,
  TITLE_THRESHOLD,
  authorOverlap,
  compareClaimToMeta,
  longestPrefixHit,
  normalizeSource,
  normalizeSources,
  normalizeText,
  renderRejectedLine,
  renderSourceLine,
  renderVerifiedAnswer,
  renderVerifyReport,
  titleSimilarity,
  verifyAssertion,
  verifyDoiSource,
  verifyQuoteSource,
  verifySource,
  verifyUrlSource,
  yearAgreement,
} from '../packages/plugins/research-literature/lib/cite-verify.mjs'
import { mapCrossrefItem } from '../packages/plugins/research-literature/connectors/crossref.mjs'

// ---------------------------------------------------------------------------
// 夹具：一条真实文献的 Crossref 原始条目（形状与线上响应一致）
// ---------------------------------------------------------------------------

const REAL_DOI = '10.1109/lcsys.2020.3044551'
const REAL_TITLE = 'Grid-Forming Frequency Shaping Control for Low-Inertia Power Systems'
const REAL_CROSSREF_ITEM = {
  DOI: REAL_DOI,
  title: [REAL_TITLE],
  author: [
    { given: 'Yan', family: 'Jiang' },
    { given: 'Andrey', family: 'Bernstein' },
    { given: 'Petr', family: 'Vorobev' },
  ],
  'container-title': ['IEEE Control Systems Letters'],
  issued: { 'date-parts': [[2021, 1, 1]] },
  'is-referenced-by-count': 120,
  URL: `https://doi.org/${REAL_DOI}`,
  type: 'journal-article',
}
const REAL_RECORD = mapCrossrefItem(REAL_CROSSREF_ITEM)

const resolveRealDoi = async (doi) => {
  if (doi === REAL_DOI) return { source: 'crossref', url: 'https://api.crossref.org/works/' + REAL_DOI, record: REAL_RECORD }
  const err = new Error(`Crossref: 未找到 DOI -> ${doi}`)
  err.code = 'E_HTTP_404'
  err.status = 404
  throw err
}

const norm = (s) => normalizeSource(s).source

// ---------------------------------------------------------------------------
// sources 结构规范化
// ---------------------------------------------------------------------------

test('normalizeSource: kind 推断（DOI 三种写法 / PDF / URL）', () => {
  assert.equal(norm({ ref: '10.1109/lcsys.2020.3044551' }).kind, 'doi')
  assert.equal(norm({ ref: 'doi:10.1109/TPWRS.2024.1' }).kind, 'doi')
  assert.equal(norm({ ref: 'https://doi.org/10.1109/TPWRS.2024.1' }).kind, 'doi')
  assert.equal(norm({ ref: 'D:/papers/a.pdf', locator: { quote: 'q' } }).kind, 'pdf')
  assert.equal(norm({ ref: 'papers/a.pdf', locator: { quote: 'q' } }).kind, 'pdf')
  assert.equal(norm({ ref: 'https://example.org/paper' }).kind, 'url')
  // 回归：URL 里全是斜杠，不得被误判成 PDF 路径
  assert.equal(norm({ ref: 'https://ar5iv.org/html/10.1109/lcsys.2020.3044551' }).kind, 'url')
  assert.equal(norm({ ref: 'https://example.org/paper.pdf' }).kind, 'url')
})

test('normalizeSource: DOI 归一（去 doi: 前缀与 doi.org 包装）', () => {
  assert.equal(norm({ ref: 'doi:10.1109/TPWRS.2024.1' }).ref, '10.1109/tpwrs.2024.1')
  assert.equal(norm({ ref: 'https://dx.doi.org/10.1109/TPWRS.2024.1' }).ref, '10.1109/tpwrs.2024.1')
})

test('normalizeSource: 结构非法一律拒绝（不猜）', () => {
  assert.equal(normalizeSource({}).ok, false)
  assert.match(normalizeSource({}).error, /缺少 ref/)
  assert.equal(normalizeSource({ kind: 'isbn', ref: 'x' }).ok, false)
  assert.match(normalizeSource({ kind: 'isbn', ref: 'x' }).error, /kind 非法/)
  // PDF 引用没有引文 → 拒绝（没有可逐字命中的东西，校验无从做起）
  assert.equal(normalizeSource({ kind: 'pdf', ref: 'a.pdf' }).ok, false)
  assert.match(normalizeSource({ kind: 'pdf', ref: 'a.pdf' }).error, /locator\.quote/)
  assert.equal(normalizeSource({ ref: 'not-a-thing' }).ok, false)
  assert.match(normalizeSource({ ref: 'not-a-thing' }).error, /无法推断来源 kind/)
})

test('normalizeSource: locator 规范化 + claim 简写', () => {
  const s = norm({ ref: 'a.pdf', locator: { page: '5', section: ' Results ', quote: '  improved frequency nadir  ' } })
  assert.equal(s.locator.page, 5)
  assert.equal(s.locator.section, 'Results')
  assert.equal(s.locator.quote, 'improved frequency nadir')
  const c = norm({ ref: REAL_DOI, title: '  T ', year: 2021, authors: 'Jiang, Yan; Bernstein' })
  assert.deepEqual(c.claim, { title: 'T', year: 2021, authors: ['Jiang', 'Yan', 'Bernstein'] })
  // --year 无值（splitFlags 会给 true）→ 视为未提供，不是 "true 年"
  assert.equal(norm({ ref: REAL_DOI, year: true }).claim, null)
})

test('normalizeSources: 一条非法整体失败（引用清单不掺沙子）', () => {
  const bad = normalizeSources([{ ref: REAL_DOI }, { kind: 'pdf', ref: 'a.pdf' }])
  assert.equal(bad.ok, false)
  assert.match(bad.errors[0], /第 2 条来源/)
  assert.equal(normalizeSources(undefined).ok, true)
})

// ---------------------------------------------------------------------------
// 相似度原语
// ---------------------------------------------------------------------------

test('normalizeText: 去空白/标点/大小写，保留字母数字与 CJK', () => {
  assert.equal(normalizeText('Grid-Forming, Inertia!'), 'gridforminginertia')
  assert.equal(normalizeText('  电网  构网  '), '电网构网')
  assert.equal(normalizeText(null), '')
})

test('titleSimilarity: 完全相同 1；大小写标点差异仍 1；无关接近 0', () => {
  assert.equal(titleSimilarity(REAL_TITLE, REAL_TITLE), 1)
  assert.equal(titleSimilarity(REAL_TITLE, REAL_TITLE.toLowerCase().replace(/-/g, ' ')), 1)
  const unrelated = titleSimilarity(REAL_TITLE, 'A Deep Learning Approach to Household Load Forecasting')
  assert.ok(unrelated < TITLE_THRESHOLD, `无关标题相似度应低于门槛，实际 ${unrelated}`)
  assert.equal(titleSimilarity('', ''), 1)
  assert.equal(titleSimilarity('abc', ''), 0)
  // 局部增删（副标题差异）应仍在门槛之上
  const partial = titleSimilarity(REAL_TITLE, REAL_TITLE + ': A Tutorial')
  assert.ok(partial >= TITLE_THRESHOLD, `加副标题后应仍过门槛，实际 ${partial}`)
})

test('authorOverlap / yearAgreement: 姓级重合与年份容差', () => {
  const a = authorOverlap(['Yan Jiang', 'Andrey Bernstein'], ['Yan Jiang', 'Andrey Bernstein', 'Petr Vorobev'])
  assert.equal(a.score, 1)
  assert.deepEqual(a.matched.sort(), ['bernstein', 'jiang'])
  assert.equal(authorOverlap(['Someone Else'], ['Yan Jiang']).score, 0)
  assert.equal(authorOverlap([], ['Yan Jiang']).score, 0)
  assert.match(authorOverlap([], ['Yan Jiang']).note, /作者信息缺失/)

  assert.equal(yearAgreement(2021, 2021).score, 1)
  assert.equal(yearAgreement(2021, 2022).score, 0.5, 'online-first 差 1 年按半分')
  assert.match(yearAgreement(2021, 2022).note, /online-first/)
  assert.equal(yearAgreement(2021, 2015).score, 0)
  assert.equal(yearAgreement(null, 2021).score, 0, '缺年份按 0 计（保守）')
})

test('compareClaimToMeta: 置信度 = 0.6 标题 + 0.2 年份 + 0.2 作者；缺项按 0', () => {
  const full = compareClaimToMeta({ title: REAL_TITLE, year: 2021, authors: ['Yan Jiang', 'Andrey Bernstein'] }, REAL_RECORD)
  assert.equal(full.titleSim, 1)
  assert.equal(full.confidence, 1)
  const noYear = compareClaimToMeta({ title: REAL_TITLE, authors: ['Yan Jiang'] }, REAL_RECORD)
  assert.equal(noYear.confidence, 0.8, '0.6×1 + 0.2×0 + 0.2×1')
  assert.match(noYear.mismatches.join('；'), /年份缺失/)
})

// ---------------------------------------------------------------------------
// ① 真实 DOI：正确引用贴置信度
// ---------------------------------------------------------------------------

test('verifyDoiSource: 真实 DOI + 完整题录断言 → 已证实，贴置信度', async () => {
  const s = norm({ ref: REAL_DOI, title: REAL_TITLE, year: 2021, authors: ['Yan Jiang', 'Andrey Bernstein', 'Petr Vorobev'] })
  const r = await verifyDoiSource(s, { resolveDoi: resolveRealDoi })
  assert.equal(r.status, 'verified')
  assert.equal(r.metaChecked, true)
  assert.equal(r.confidence, 1)
  assert.equal(r.strong, true)
  assert.equal(r.resolvedBy, 'crossref')
  assert.equal(r.meta.title, REAL_TITLE)
  assert.equal(r.meta.year, 2021)
  // 报告里必须能直接看到置信度（验收口径：贴校验置信度）
  const report = renderVerifyReport(r)
  assert.match(report, /引用校验通过（已证实）/)
  assert.match(report, /校验置信度：1\.00/)
  assert.match(report, new RegExp(`标题相似度：1\\.0000（门槛 ${TITLE_THRESHOLD}）`))
})

test('verifyDoiSource: 标题轻微差异（过门槛不过强匹配线）仍 verified', async () => {
  const s = norm({ ref: REAL_DOI, title: REAL_TITLE + ' with Extra Suffix Words Here', year: 2021 })
  const r = await verifyDoiSource(s, { resolveDoi: resolveRealDoi })
  assert.equal(r.status, 'verified')
  assert.equal(r.strong, false, '相似度未达强匹配线')
  assert.ok(r.confidence > 0.6 && r.confidence < 1)
})

// ---------------------------------------------------------------------------
// ② 伪造 DOI：被拒 + 拒绝理由
// ---------------------------------------------------------------------------

test('verifyDoiSource: 伪造 DOI（双源 404）→ 拒引，理由写明双源均未收录', async () => {
  const s = norm({ ref: '10.9999/fake.doi.12345', title: 'Some Fabricated Paper Title' })
  const r = await verifyDoiSource(s, { resolveDoi: resolveRealDoi })
  assert.equal(r.status, 'rejected')
  assert.match(r.reason, /Crossref 与 OpenAlex 均未收录/)
  assert.match(r.reason, /10\.9999\/fake\.doi\.12345/)
  const report = renderVerifyReport(r)
  assert.match(report, /引用校验失败（DOI 无法解析：Crossref 与 OpenAlex 均未收录该 DOI/)
  assert.match(report, /不得出现在任何结论中/)
  assert.match(renderRejectedLine(r), /^DOI 10\.9999\/fake\.doi\.12345｜引用校验失败（/)
})

test('verifyDoiSource: 标题不匹配 → 拒引，理由带相似度数值', async () => {
  const s = norm({ ref: REAL_DOI, title: 'Totally Different Paper About Batteries', year: 2021 })
  const r = await verifyDoiSource(s, { resolveDoi: resolveRealDoi })
  assert.equal(r.status, 'rejected')
  assert.match(r.reason, /标题不匹配：相似度 0\.\d+ 低于门槛 0\.6/)
  assert.match(r.reason, /Totally Different Paper About Batteries/)
})

test('verifyDoiSource: 网络错误 → unverifiable（环境问题，不是引用失败）', async () => {
  const s = norm({ ref: REAL_DOI, title: REAL_TITLE })
  const r = await verifyDoiSource(s, {
    resolveDoi: async () => {
      const err = new Error('connect ECONNRESET')
      err.code = 'E_NET'
      throw err
    },
  })
  assert.equal(r.status, 'unverifiable')
  assert.match(r.reason, /网络\/服务原因未完成/)
})

test('verifyDoiSource: 无题录断言 → 弱通过（metaChecked=false，不假装强校验）', async () => {
  const s = norm({ ref: REAL_DOI })
  const r = await verifyDoiSource(s, { resolveDoi: resolveRealDoi })
  assert.equal(r.status, 'verified')
  assert.equal(r.metaChecked, false)
  assert.equal(r.confidence, null)
  assert.match(renderVerifyReport(r), /弱通过/)
})

test('verifyDoiSource: 未注入 resolveDoi → unverifiable', async () => {
  const r = await verifyDoiSource(norm({ ref: REAL_DOI }), {})
  assert.equal(r.status, 'unverifiable')
  assert.match(r.reason, /未注入 DOI 解析能力/)
})

// ---------------------------------------------------------------------------
// ③ PDF quote：命中与不命中各一例
// ---------------------------------------------------------------------------

// 与 data/fixtures/sample-paper.pdf 抽取文本同源的桩（测试不依赖 unpdf）
const PDF_TEXT = [
  'Grid-Forming Inverter Control for Inertia Support in Low-Inertia Grids',
  'Abstract',
  'This paper studies grid-forming inverter control and virtual synchronous generator based inertia emulation.',
  'Introduction',
  'High penetration renewable generation reduces system inertia and threatens frequency stability.',
  'Method',
  'We propose a droop plus virtual inertia controller tuned by a small-signal model.',
  'Results',
  'Simulations on a modified IEEE 9-bus system show improved frequency nadir by 32 percent.',
  'Conclusion',
  'The proposed controller improves frequency stability in low-inertia power systems.',
  'References',
  '[1] Some Author, Some Paper, 2020.',
].join('\n')
const readPdfText = async () => ({ text: PDF_TEXT, pages: 1 })

test('verifyQuoteSource: 引文逐字命中（容忍空白/换行/标点差异）→ verified', async () => {
  // 故意把原文里跨行的句子连起来、换掉标点，归一化后应仍命中
  const s = norm({
    ref: 'D:/papers/sample.pdf',
    locator: { quote: 'Simulations on a modified IEEE 9-bus system show improved frequency nadir by 32 percent.', page: 1 },
  })
  const r = await verifyQuoteSource(s, { readPdfText })
  assert.equal(r.status, 'verified')
  assert.equal(r.confidence, 1)
  assert.equal(r.detail.claimedPage, 1)
  assert.match(renderVerifyReport(r), /归一化后逐字命中/)
  assert.match(renderSourceLine(r), /引文逐字命中（1 页 \/ 622 字符）/)
})

test('verifyQuoteSource: 引文不命中 → 拒引，理由带规模与前缀命中诊断', async () => {
  const s = norm({ ref: 'D:/papers/sample.pdf', locator: { quote: 'the inertia constant H equals exactly 5 seconds in all cases' } })
  const r = await verifyQuoteSource(s, { readPdfText })
  assert.equal(r.status, 'rejected')
  assert.match(r.reason, /未在 PDF 全文中逐字命中/)
  assert.match(r.reason, /最长前缀命中 \d+%/)
  assert.ok(r.detail.prefixHit < 1)
})

test('verifyQuoteSource: 前缀部分命中时诊断值介于 0 与 1 之间', async () => {
  const s = norm({ ref: 'a.pdf', locator: { quote: 'We propose a droop plus virtual inertia controller tuned by a deep neural network' } })
  const r = await verifyQuoteSource(s, { readPdfText })
  assert.equal(r.status, 'rejected')
  assert.ok(r.detail.prefixHit > 0.5 && r.detail.prefixHit < 1, `前缀命中应在中段，实际 ${r.detail.prefixHit}`)
})

test('verifyQuoteSource: PDF 读不到 / 无文本 → unverifiable（不是引用失败）', async () => {
  const s = norm({ ref: 'missing.pdf', locator: { quote: 'anything' } })
  const r1 = await verifyQuoteSource(s, {
    readPdfText: async () => {
      const err = new Error('PDF 不存在或不可读 -> missing.pdf')
      err.code = 'E_PDF_NOT_FOUND'
      throw err
    },
  })
  assert.equal(r1.status, 'unverifiable')
  assert.match(r1.reason, /PDF 无法读取/)
  const r2 = await verifyQuoteSource(s, { readPdfText: async () => ({ text: '', pages: 3 }) })
  assert.equal(r2.status, 'unverifiable')
  assert.match(r2.reason, /未抽取到任何文本/)
})

test('verifyQuoteSource: 分页文本可用时核验声称页码（命中/不符）', async () => {
  const pages = ['cover page text', 'Simulations on a modified IEEE 9-bus system show improved frequency nadir by 32 percent.', 'references']
  const withPages = async () => ({ text: pages.join('\n'), pages: 3, pageTexts: pages })
  const hit = await verifyQuoteSource(norm({ ref: 'a.pdf', locator: { quote: 'improved frequency nadir by 32 percent', page: 2 } }), { readPdfText: withPages })
  assert.equal(hit.detail.pageVerified, true)
  assert.equal(hit.detail.hitPage, 2)
  const wrong = await verifyQuoteSource(norm({ ref: 'a.pdf', locator: { quote: 'improved frequency nadir by 32 percent', page: 1 } }), { readPdfText: withPages })
  assert.equal(wrong.detail.pageVerified, false)
  // 只给合并文本时，页码只是转述，不谎称核验
  const noPages = await verifyQuoteSource(norm({ ref: 'a.pdf', locator: { quote: 'improved frequency nadir by 32 percent', page: 2 } }), { readPdfText })
  assert.equal(noPages.detail.pageVerified, null)
})

// ---------------------------------------------------------------------------
// URL 校验
// ---------------------------------------------------------------------------

test('verifyUrlSource: doi.org 链接等价于 DOI 引用（转双源解析，kind 不变）', async () => {
  // 显式 kind:'url'：doi.org 链接推断时会被归一成 doi 类，这里钉的是"显式 URL 形态"的路径
  const s = normalizeSource({ kind: 'url', ref: `https://doi.org/${REAL_DOI}`, title: REAL_TITLE, year: 2021, authors: ['Yan Jiang'] }).source
  const r = await verifyUrlSource(s, { resolveDoi: resolveRealDoi })
  assert.equal(r.status, 'verified')
  assert.equal(r.kind, 'url')
  assert.equal(r.via, 'doi')
  assert.equal(r.confidence, 1, '作者重合按 min(断言数,解析数) 为分母：单个作者全中即满分')
})

test('verifyUrlSource: 普通 URL 取到标题可比对；域名不在白名单 → unverifiable', async () => {
  const ok = await verifyUrlSource(norm({ ref: 'https://ar5iv.org/html/10.1109/lcsys.2020.3044551', title: REAL_TITLE }), {
    resolveUrl: async () => ({ title: REAL_TITLE }),
  })
  assert.equal(ok.status, 'verified')
  assert.equal(ok.confidence, 0.6, 'URL 只能验标题：0.6×1，年份作者无源可比')
  const blocked = await verifyUrlSource(norm({ ref: 'https://sci-hub.se/paper', title: REAL_TITLE }), {
    resolveUrl: async () => {
      const err = new Error('E_DOMAIN_NOT_ALLOWED')
      err.code = 'E_DOMAIN_NOT_ALLOWED'
      throw err
    },
  })
  assert.equal(blocked.status, 'unverifiable')
  assert.match(blocked.reason, /不在出网白名单/)
  const mismatch = await verifyUrlSource(norm({ ref: 'https://ar5iv.org/html/x', title: 'Unrelated Battery Paper' }), {
    resolveUrl: async () => ({ title: REAL_TITLE }),
  })
  assert.equal(mismatch.status, 'rejected')
  assert.match(mismatch.reason, /标题不匹配/)
})

// ---------------------------------------------------------------------------
// verifySource 分派与结构拒绝
// ---------------------------------------------------------------------------

test('verifySource: 来源结构非法 → rejected（不进任何结论）', async () => {
  const r = await verifySource({ kind: 'pdf', ref: 'a.pdf' }, { readPdfText })
  assert.equal(r.status, 'rejected')
  assert.match(r.reason, /来源结构非法/)
})

// ---------------------------------------------------------------------------
// 强度机（三档 + 降级）
// ---------------------------------------------------------------------------

test('verifyAssertion: 有 verified 源 → proven（哪怕声称 inferred）', async () => {
  const r = await verifyAssertion(
    { text: '构网型逆变器可提供惯量支撑', strength: 'inferred', sources: [{ ref: REAL_DOI, title: REAL_TITLE, year: 2021 }] },
    { resolveDoi: resolveRealDoi },
  )
  assert.equal(r.claimed, 'inferred')
  assert.equal(r.effective, 'proven')
  assert.equal(r.downgraded, false)
  assert.equal(r.confidence, 0.8)
})

test('verifyAssertion: 声称 proven 但唯一来源被拒 → 降级 unverified 并记原因', async () => {
  const r = await verifyAssertion(
    { text: '某伪造文献声称惯量常数为 5s', strength: 'proven', sources: [{ ref: '10.9999/fake.doi.12345', title: 'Fabricated' }] },
    { resolveDoi: resolveRealDoi },
  )
  assert.equal(r.effective, 'unverified')
  assert.equal(r.downgraded, true)
  assert.match(r.downgradeReason, /全部 1 个来源校验失败/)
  assert.equal(r.unverified, true)
})

test('verifyAssertion: 无来源的 proven 断言 → unverified（无来源不出结论）', async () => {
  const r = await verifyAssertion({ text: '没有来源的结论', strength: 'proven' }, { resolveDoi: resolveRealDoi })
  assert.equal(r.effective, 'unverified')
  assert.match(r.downgradeReason, /未提供任何来源/)
})

test('verifyAssertion: 声称 inferred 且无源 → 保持 inferred（允许存在，但显式标注）', async () => {
  const r = await verifyAssertion({ text: '模型推测', strength: 'inferred' }, {})
  assert.equal(r.effective, 'inferred')
  assert.equal(r.downgraded, false)
})

test('verifyAssertion: 声称 unverified → 保持 unverified，不算降级', async () => {
  const r = await verifyAssertion({ text: '自认待验证', strength: 'unverified' }, {})
  assert.equal(r.effective, 'unverified')
  assert.equal(r.downgraded, false)
})

// ---------------------------------------------------------------------------
// 总装渲染：角标 / 来源清单 / 拒引 / 未验证断言区
// ---------------------------------------------------------------------------

test('renderVerifiedAnswer: 四件套齐全，unverified 绝不进正文结论区', async () => {
  const assertions = await Promise.all([
    verifyAssertion(
      { text: '构网型控制可改善低惯量系统频率稳定性', strength: 'proven', sources: [{ ref: REAL_DOI, title: REAL_TITLE, year: 2021, authors: ['Yan Jiang', 'Andrey Bernstein'] }] },
      { resolveDoi: resolveRealDoi },
    ),
    verifyAssertion({ text: '惯量支撑策略或可推广至含储能场景', strength: 'inferred' }, {}),
    verifyAssertion({ text: '某结论引用了一篇不存在的文献', strength: 'proven', sources: [{ ref: '10.9999/fake.doi.12345', title: 'Fabricated Paper' }] }, { resolveDoi: resolveRealDoi }),
    verifyAssertion({ text: '引文与原文不符的结论', strength: 'proven', sources: [{ ref: 'a.pdf', locator: { quote: 'this sentence is not in the pdf at all' } }] }, { readPdfText }),
    verifyAssertion({ text: '无任何来源的断言', strength: 'proven' }, {}),
  ])
  const out = renderVerifiedAnswer({ lead: '问题：构网型逆变器能否支撑低惯量系统？', assertions })

  // 结论区：proven 带角标与档位；inferred 显式标注；两者都在
  const conclusion = out.split('【来源清单】')[0]
  assert.match(conclusion, /- 构网型控制可改善低惯量系统频率稳定性 \[1\] —— 已证实/)
  assert.match(conclusion, /- 惯量支撑策略或可推广至含储能场景 —— 推断/)
  // unverified 的三条都不在结论区
  assert.ok(!conclusion.includes('不存在的文献'))
  assert.ok(!conclusion.includes('引文与原文不符'))
  assert.ok(!conclusion.includes('无任何来源的断言'))

  // 来源清单：由校验器追加，编号从 1 开始
  assert.match(out, /【来源清单】（由引用校验器追加，非模型输出）/)
  assert.match(out, new RegExp(`\\[1\\] doi:${REAL_DOI}｜${REAL_TITLE.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`))

  // 拒引区：两条 rejected（伪造 DOI + 引文不命中），都带「引用校验失败（原因）」
  assert.match(out, /【引用校验失败】（未通过校验的来源，禁止作为结论依据）/)
  assert.match(out, /拒引｜DOI 10\.9999\/fake\.doi\.12345｜引用校验失败（DOI 无法解析：Crossref 与 OpenAlex 均未收录该 DOI/)
  assert.match(out, /拒引｜PDF 引文 a\.pdf｜引用校验失败（引文未在 PDF 全文中逐字命中/)

  // 未验证断言区：降级两条 + 无源一条
  assert.match(out, /【未验证断言】（无来源或校验未通过，不得作为结论）/)
  assert.match(out, /- 某结论引用了一篇不存在的文献 —— 待验证（全部 1 个来源校验失败）/)
  assert.match(out, /- 引文与原文不符的结论 —— 待验证（全部 1 个来源校验失败）/)
  assert.match(out, /- 无任何来源的断言 —— 待验证（未提供任何来源）/)
})

test('renderVerifiedAnswer: 空断言列表有明确空态', () => {
  const out = renderVerifiedAnswer({ assertions: [] })
  assert.match(out, /【结论】\n（没有任何已证实或推断级别的结论）/)
})

test('renderVerifiedAnswer: 忘记先校验（裸断言无 effective）→ fail-closed 进未验证区，绝不出 undefined', () => {
  // 主管复核实测的 fail-open 场景：直接调渲染、没先跑 verifyAssertions。
  // 有源断言（带 verified 空壳）与无源断言都缺 effective 字段。
  const out = renderVerifiedAnswer({
    assertions: [
      { text: '带来源但没先校验的断言', sources: [{ kind: 'doi', ref: '10.1109/x' }], verified: [], rejected: [], unverifiable: [] },
      { text: '完全裸的无源断言' },
      null, // 连断言对象都不是 → 同样按待验证处理，不能崩
    ],
  })

  // 1) 任何情况下不得输出 undefined
  assert.ok(!out.includes('undefined'), `输出含 undefined：\n${out}`)

  // 2) 两条裸断言都不得进结论区
  const conclusion = out.split(/【来源清单】|【引用校验失败】|【未验证断言】/)[0]
  assert.ok(!conclusion.includes('带来源但没先校验的断言'), `结论区混入未校验断言：\n${conclusion}`)
  assert.ok(!conclusion.includes('完全裸的无源断言'))

  // 3) 都归入未验证区，并写明"未先校验"的处理依据
  assert.match(out, /【未验证断言】（无来源或校验未通过，不得作为结论）/)
  assert.match(out, /- 带来源但没先校验的断言 —— 待验证（未先经 verifyAssertions 校验，按待验证处理）/)
  assert.match(out, /- 完全裸的无源断言 —— 待验证（未先经 verifyAssertions 校验，按待验证处理）/)

  // 4) 档位/拒因字段缺失时的兜底文案（输出可读，绝无 undefined）
  assert.ok(!out.includes('—— undefined'))
  assert.match(renderRejectedLine({ kind: 'doi', ref: '10.1109/x' }), /引用校验失败（原因未给出）/)
  assert.match(renderSourceLine(null), /来源条目异常/)
  const bare = renderSourceLine({})
  assert.ok(!bare.includes('undefined'), bare)
  assert.match(bare, /\(无 ref\)/)
})

// ---------------------------------------------------------------------------
// 三档枚举的渲染口径（块 2 强制渲染也从这里取）
// ---------------------------------------------------------------------------

test('STRENGTHS: 三档枚举值与任务书一致', () => {
  assert.deepEqual({ ...STRENGTHS }, { proven: '已证实', inferred: '推断', unverified: '待验证' })
  assert.ok(TITLE_STRONG > TITLE_THRESHOLD)
})

// ---------------------------------------------------------------------------
// 验收口径镜像（与 tools/accept-stage4-block1.mjs 同参数，离线桩版）
// ---------------------------------------------------------------------------

test('验收镜像：真实 DOI / 伪造 DOI / PDF 引文命中与不命中', async () => {
  // 用例 1：真实 DOI 正确引用，贴置信度
  const c1 = await verifyAssertion(
    {
      text: 'Grid-Forming Frequency Shaping Control 可改善低惯量系统频率响应',
      strength: 'proven',
      sources: [{ ref: REAL_DOI, title: REAL_TITLE, year: 2021, authors: ['Yan Jiang', 'Andrey Bernstein', 'Petr Vorobev'] }],
    },
    { resolveDoi: resolveRealDoi },
  )
  assert.equal(c1.effective, 'proven')
  assert.ok(c1.confidence > 0.9, `真实 DOI 置信度应 >0.9，实际 ${c1.confidence}`)

  // 用例 2：伪造 DOI 被拒，理由可读
  const c2 = await verifyAssertion(
    { text: '该文献给出了 32% 的频率最低点改善', strength: 'proven', sources: [{ ref: '10.9999/fake.doi.12345', title: 'Fabricated Paper About Frequency Nadir' }] },
    { resolveDoi: resolveRealDoi },
  )
  assert.equal(c2.rejected.length, 1)
  assert.match(c2.rejected[0].reason, /Crossref 与 OpenAlex 均未收录/)

  // 用例 3a：PDF 引文命中
  const c3a = await verifyAssertion(
    { text: '仿真显示频率最低点改善 32%', strength: 'proven', sources: [{ ref: 'D:/papers/sample.pdf', locator: { quote: 'Simulations on a modified IEEE 9-bus system show improved frequency nadir by 32 percent.', page: 1 } }] },
    { readPdfText },
  )
  assert.equal(c3a.effective, 'proven')
  assert.equal(c3a.verified.length, 1)

  // 用例 3b：PDF 引文不命中
  const c3b = await verifyAssertion(
    { text: '仿真显示频率最低点改善 90%', strength: 'proven', sources: [{ ref: 'D:/papers/sample.pdf', locator: { quote: 'Simulations show improved frequency nadir by 90 percent.' } }] },
    { readPdfText },
  )
  assert.equal(c3b.effective, 'unverified')
  assert.match(c3b.rejected[0].reason, /未在 PDF 全文中逐字命中/)
})
