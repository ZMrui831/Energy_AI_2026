// tests/modes.test.mjs
//
// S22·B 单元钉子：运行模式的「数据驱动 + 封顶生效 + 可回退」核心不变量。
// 覆盖：listModes / setMode 审计写入配置 / capOf 取当前档 / readonly 权限叠加 /
// capOf 缺省回落 FALLBACK / 非法 mode 拒绝 / loadMode 字段对齐。
//
// 红线：不依赖 DSH、不碰 %USERPROFILE%\.dsh\**、不落地非 modes 文件（setMode 仅写
// data/config.json 的 mode 字段并追加 data/logs/mode.jsonl，后者有 try/catch 兜底）。

import test from 'node:test'
import assert from 'node:assert/strict'
import * as modes from '../packages/core/src/modes.mjs'

const KB = 1024

test('listModes 返回 3 个可用模式（standard/lean/readonly）', () => {
  const list = modes.listModes()
  const ids = list.map((m) => m.id)
  assert.deepEqual(ids.sort(), ['lean', 'readonly', 'standard'])
  for (const m of list) assert.ok(m.name && m.description, `模式 ${m.id} 缺 name/description`)
})

test('setMode(standard) 后 currentModeId 与 capOf(readMaxBytes) 与今日等价', () => {
  modes.setMode('standard')
  assert.equal(modes.currentModeId(), 'standard')
  assert.equal(modes.capOf('readMaxBytes'), 200 * KB, 'standard 读上限应 = 200KB（与今天 LIMITS.READ_BYTES 一致）')
  assert.equal(modes.capOf('toolResultCapChars'), 6000, 'standard 工具结果上限应 = 6000（与今天 agent TOOL_RESULT_CHARS 一致）')
})

test('setMode(lean) 后各封顶对齐 token-lean 字段', () => {
  modes.setMode('lean')
  assert.equal(modes.currentModeId(), 'lean')
  assert.equal(modes.capOf('readMaxBytes'), 64 * KB)
  assert.equal(modes.capOf('readLimitLines'), 800)
  assert.equal(modes.capOf('readMaxLineChars'), 1200)
  assert.equal(modes.capOf('grepMaxMatches'), 150)
  assert.equal(modes.capOf('grepMaxLineChars'), 400)
  assert.equal(modes.capOf('webFetchMaxChars'), 48000)
  assert.equal(modes.capOf('webSearchMaxResults'), 5)
  assert.equal(modes.capOf('toolResultCapChars'), 16384)
})

test('readonly 叠加 denyWrite/denyExec；standard 二者皆 false', () => {
  modes.setMode('readonly')
  const ro = modes.currentModePermissions()
  assert.ok(ro && ro.denyWrite === true && ro.denyExec === true, 'readonly 应禁止写盘与执行')
  modes.setMode('standard')
  const st = modes.currentModePermissions()
  assert.ok(st === null || (st.denyWrite === false && st.denyExec === false), 'standard 不应叠加拒绝')
})

test('capOf 缺省回落 FALLBACK（standard 未声明字段不丢值）', () => {
  modes.setMode('standard')
  // standard.json 未显式声明 readLimitLines / readMaxLineChars → 回落 FALLBACK（0 = 不限制）
  assert.equal(modes.capOf('readLimitLines'), 0)
  assert.equal(modes.capOf('readMaxLineChars'), 0)
  // 完全未知的 cap 名：无 fallback 参数时应回落 FALLBACK 或 undefined，且不抛
  assert.equal(modes.capOf('nonexistent-cap-xyz', 1234), 1234, '带 fallback 参数时应返回该 fallback')
  assert.equal(modes.capOf('nonexistent-cap-xyz'), undefined, '无 fallback 且 FALLBACK 无此项时为 undefined')
})

test('setMode 拒绝非法 mode（不污染当前模式）', () => {
  modes.setMode('standard')
  assert.throws(() => modes.setMode('bogus'), /未知模式/)
  assert.equal(modes.currentModeId(), 'standard', '非法切换不应改变当前模式')
})

test('loadMode(lean) 字段与 token-lean 逐一对齐', () => {
  const m = modes.loadMode('lean')
  assert.equal(m.id, 'lean')
  assert.equal(m.caps.readMaxBytes, 64 * KB)
  assert.equal(m.caps.grepMaxMatches, 150)
  assert.equal(m.caps.webFetchMaxChars, 48000)
  assert.equal(m.caps.toolResultCapChars, 16384)
  assert.deepEqual(m.permissions, { denyWrite: false, denyExec: false })
})

test('三档 readMaxBytes 递减：standard(200K) > lean(64K)，readonly 复用 standard', () => {
  modes.setMode('standard'); const s = modes.capOf('readMaxBytes')
  modes.setMode('lean'); const l = modes.capOf('readMaxBytes')
  modes.setMode('readonly'); const r = modes.capOf('readMaxBytes')
  assert.ok(s > l, 'standard 应比 lean 读得多')
  assert.equal(r, s, 'readonly 复用 standard 封顶')
  // restore-mode-after-test：本条测试把模式切到 readonly，必须复位，否则后续测试读到只读模式
  modes.setMode('standard')
})

process.on('exit', () => { try { modes.setMode('standard') } catch { /* 尽力 */ } })
