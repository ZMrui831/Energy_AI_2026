// tests/budget.test.mjs
//
// §5.5 硬预算与 7 级降级回归（纯函数，无盘、无 electron）。
// 覆盖：7 级各自触发 + 至少 2 例恢复 + 边界（CPU 恰好 3%/3.01%、内存恰好 300MB）。

import test from 'node:test'
import assert from 'node:assert/strict'

import {
  evaluateBudget,
  nextBudgetLevel,
  levelFor,
  trigger,
  DEFAULT_THRESHOLDS,
  MAX_LEVEL,
} from '../packages/core/src/budget.mjs'

/** 全部正常的基线指标（无任何超限）。 */
const OK = {
  cpuP95: 5, cpuAvg: 1, memMB: 200, diskAddedGB: 0.1,
  diskFreeGB: 50, batteryPct: 100, charging: true,
}

test('budget: 正常指标 → 级别 0 不降级', () => {
  const r = evaluateBudget(OK)
  assert.equal(r.level, 0)
  assert.equal(r.downgraded, false)
  assert.equal(r.recovered, false)
  assert.deepEqual(r.actions, [])
})

test('budget: 级1 P95 CPU>12% 触发（S58 起无动作：视觉不再关，只剩诊断可见）', () => {
  const r = evaluateBudget({ ...OK, cpuP95: 13 })
  assert.equal(r.level, 1)
  // S58·P0-2：disable-visual-model 永久移除（视觉免费，关它只有损失；且此前无消费者=审计撒谎）
  assert.deepEqual(r.actions, [])
  assert.ok(!r.actions.includes('disable-visual-model'))
})

test('budget: 级2 平均 CPU>3% 触发「OCR 间隔×2」', () => {
  const r = evaluateBudget({ ...OK, cpuAvg: 4 })
  assert.equal(r.level, 2)
  assert.ok(r.actions.includes('ocr-interval-x2'))
  assert.ok(!r.actions.includes('disable-visual-model')) // S58：视觉降级动作已移除
})

test('budget: 级3 内存>300MB 触发「截图间隔×2」', () => {
  const r = evaluateBudget({ ...OK, memMB: 350 })
  assert.equal(r.level, 3)
  assert.ok(r.actions.includes('shot-interval-x2'))
})

test('budget: 级4 磁盘日增>0.5GB 触发「停原图只留元数据」', () => {
  const r = evaluateBudget({ ...OK, diskAddedGB: 0.6 })
  assert.equal(r.level, 4)
  assert.ok(r.actions.includes('stop-original-images'))
})

test('budget: 级5 内存>600MB 触发「停云调用切规则摘要」', () => {
  const r = evaluateBudget({ ...OK, memMB: 650 })
  assert.equal(r.level, 5)
  assert.ok(r.actions.includes('stop-cloud-rule-summary'))
})

test('budget: 级6 磁盘剩余<1GB 触发「立即停截图」', () => {
  const r = evaluateBudget({ ...OK, diskFreeGB: 0.8 })
  assert.equal(r.level, 6)
  assert.ok(r.actions.includes('stop-screenshots-disk'))
})

test('budget: 级7 电量<10% 且未充电 触发「只采元数据」', () => {
  const r = evaluateBudget({ ...OK, batteryPct: 8, charging: false })
  assert.equal(r.level, 7)
  assert.ok(r.actions.includes('metadata-only-battery'))
})

test('budget: 级7 电量低但正在充电 → 不触发级7', () => {
  const r = evaluateBudget({ ...OK, batteryPct: 8, charging: true })
  assert.equal(r.level, 0)
})

test('budget: 边界 CPU 恰好 3%（不触发级2），3.01% 触发', () => {
  assert.equal(trigger(2, { cpuAvg: 3 }, DEFAULT_THRESHOLDS), false, '恰好 3% 不算超限')
  assert.equal(trigger(2, { cpuAvg: 3.01 }, DEFAULT_THRESHOLDS), true, '3.01% 超限')
})

test('budget: 边界 内存恰好 300MB（不触发级3），300.01 触发', () => {
  assert.equal(trigger(3, { memMB: 300 }, DEFAULT_THRESHOLDS), false)
  assert.equal(trigger(3, { memMB: 300.01 }, DEFAULT_THRESHOLDS), true)
})

test('budget: 边界 P95 恰好 12%（不触发级1），12.01 触发', () => {
  assert.equal(trigger(1, { cpuP95: 12 }, DEFAULT_THRESHOLDS), false)
  assert.equal(trigger(1, { cpuP95: 12.01 }, DEFAULT_THRESHOLDS), true)
})

test('budget: 恢复① 从级3降到级0（内存回到 200MB）', () => {
  const high = evaluateBudget({ ...OK, memMB: 400 })
  assert.equal(high.level, 3)
  const recovered = nextBudgetLevel(3, { ...OK, memMB: 200 })
  assert.equal(recovered.level, 0)
  assert.equal(recovered.recovered, true)
  assert.equal(recovered.downgraded, false)
})

test('budget: 恢复② 从级6降到级4（磁盘剩余回升，但日增仍超限）', () => {
  const high = evaluateBudget({ ...OK, diskFreeGB: 0.5, diskAddedGB: 0.6 })
  assert.equal(high.level, 6) // 6（磁盘不足）+ 4（日增）=> 最高 6
  const recovered = nextBudgetLevel(6, { ...OK, diskFreeGB: 50, diskAddedGB: 0.6 })
  assert.equal(recovered.level, 4) // 仅剩日增超限
  assert.equal(recovered.recovered, true)
})

test('budget: 单调升级 — 同时多指标超限取最高级别', () => {
  const r = evaluateBudget({
    ...OK,
    cpuP95: 13, cpuAvg: 4, memMB: 650, diskAddedGB: 0.6, diskFreeGB: 0.5,
    batteryPct: 5, charging: false,
  })
  assert.equal(r.level, MAX_LEVEL) // 7
  // S58：L1 已无动作（视觉降级移除）→ L2..L7 共 6 个动作
  assert.equal(r.actions.length, 6)
})

test('budget: 可配阈值 — 放宽 CPU 阈值后原先超限不再触发', () => {
  const r = evaluateBudget({ ...OK, cpuP95: 13 }, { thresholds: { cpuP95: 20 } })
  assert.equal(r.level, 0)
})
