// tests/packs.test.mjs
//
// P-R6 块 A：多形态（pack）解耦的验收测试。
//   1) pack 清单可读、契约完整（id/plugins/theme/ui/entry）
//   2) 切 pack 后命令表随之变化；非本 pack 的命令明确不可用（E_NO_COMMAND）
//   3) 数据按 pack 隔离到 data\packs\<pack>\
//   4) 每个 pack 至少有 1 条真实可用命令（真跑一遍，不是只看清单）
//   5) **底座零学科词**：shell + core 源码不得出现学科/业务词

import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, relative, sep } from 'node:path'

import { PROJECT_ROOT, dataPath } from '../packages/core/src/safefs.mjs'
import { loadSettings, saveSettings, DEFAULT_SETTINGS } from '../packages/core/src/settings.mjs'
import { scanPacks, listPacks, normalizePackManifest } from '../packages/core/src/packs.mjs'
import { createCoreHost } from '../apps/desktop/core-host.mjs'

const PACKS_DIR = join(PROJECT_ROOT, 'packages', 'packs')

// ---------------------------------------------------------------------------
// 1) pack 清单与契约
// ---------------------------------------------------------------------------
test('packs: 四个形态都可发现且清单完整', () => {
  const packs = listPacks()
  const ids = packs.map((p) => p.id).sort()
  assert.deepEqual(ids, ['eldercare', 'general', 'health', 'research'])
  for (const p of packs) {
    assert.equal(p.error, null, `pack ${p.id} 清单错误：${p.error}`)
    assert.ok(p.plugins.length >= 1, `pack ${p.id} 至少要引用 1 个插件`)
    assert.ok(p.commands.length >= 1, `pack ${p.id} 至少要声明 1 条命令`)
    assert.ok(typeof p.theme === 'string' && p.theme, `pack ${p.id} 必须声明默认主题`)
    assert.ok(p.version, `pack ${p.id} 必须有 version`)
  }
})

test('packs: research 沿用全部科研能力，其它 pack 不含科研插件', () => {
  const packs = listPacks()
  const research = packs.find((p) => p.id === 'research')
  for (const pid of ['research-literature', 'research-browser', 'research-timer']) {
    assert.ok(research.plugins.includes(pid), `research pack 应含 ${pid}`)
  }
  for (const id of ['general', 'health', 'eldercare']) {
    const p = packs.find((x) => x.id === id)
    for (const pid of ['research-literature', 'research-browser', 'research-timer']) {
      assert.equal(p.plugins.includes(pid), false, `${id} pack 不应含科研插件 ${pid}`)
    }
  }
})

test('packs: normalizePackManifest 拒绝非法 id / entry 穿越', () => {
  assert.throws(() => normalizePackManifest({ id: '../evil' }), (e) => e.code === 'E_BAD_PACK_ID')
  assert.throws(() => normalizePackManifest({ id: 'ok', entry: '../../x.mjs' }), (e) => e.code === 'E_BAD_PACK_ENTRY')
  assert.throws(() => normalizePackManifest({ id: 'ok', entry: 'C:/abs.mjs' }), (e) => e.code === 'E_BAD_PACK_ENTRY')
  // ui 里的穿越项被静默丢弃（不生效）
  const m = normalizePackManifest({ id: 'ok', ui: ['ui/a.js', '../../../evil.js'] })
  assert.deepEqual(m.ui, ['ui/a.js'])
})

// ---------------------------------------------------------------------------
// 2) 切 pack：命令表随之变化 + 非本 pack 命令不可用
// ---------------------------------------------------------------------------
test('packs: 切 pack 后命令表变化，非本 pack 命令返回 E_NO_COMMAND', async () => {
  const host = createCoreHost()
  try {
    await host.activatePackById('research', { persist: false })
    const researchCmds = new Set(host.packStatus().commands)
    for (const c of ['find', 'card', 'verify', 'web', 'start', 'today']) {
      assert.ok(researchCmds.has(c), `research 应有 ${c}`)
    }

    const r = await host.activatePackById('general', { persist: false })
    assert.ok(r.enabled.includes('office-notes'), 'general 应启用 office-notes')
    assert.ok(r.disabled.includes('research-literature'), 'research-literature 应被停用')

    const generalCmds = new Set(host.packStatus().commands)
    assert.ok(generalCmds.has('note'), 'general 应有 note')
    assert.equal(generalCmds.has('find'), false, 'general 不该有 find')
    assert.equal(generalCmds.has('web'), false, 'general 不该有 web')

    const denied = await host.registry.runCommand('find', '构网型')
    assert.equal(denied.ok, false)
    assert.equal(denied.error, 'E_NO_COMMAND', '非本 pack 的命令必须明确不可用')
  } finally {
    await host.dispose()
  }
})

test('packs: 每个 pack 至少有 1 条真实可用命令（真跑）', async () => {
  const host = createCoreHost()
  const probes = {
    research: ['status', ''],
    general: ['note', 'pack-test-entry'],
    health: ['health', 'log pack-test 正常'],
    eldercare: ['elder', 'say 你好'],
  }
  try {
    for (const [packId, [cmd, args]] of Object.entries(probes)) {
      const r = await host.activatePackById(packId, { persist: false })
      assert.ok(r.enabled.length >= 1, `${packId} 至少要启用 1 个插件`)
      const res = await host.registry.runCommand(cmd, args)
      assert.equal(res.ok, true, `${packId} 的 /${cmd} 必须可用：${res.error}`)
      assert.ok(res.value && typeof res.value.text === 'string' && res.value.text.length > 0, `${packId} 的 /${cmd} 必须有文本输出`)
    }
  } finally {
    await host.dispose()
  }
})

// ---------------------------------------------------------------------------
// 3) 数据按 pack 隔离
// ---------------------------------------------------------------------------
test('packs: 领域插件数据落 data/packs/<pack>/（scopes 声明 + 夹逼）', async () => {
  const host = createCoreHost()
  try {
    await host.activatePackById('health', { persist: false })
    const res = await host.registry.runCommand('health', 'log pack隔离测试 正常')
    assert.equal(res.ok, true, res.error)
    const p = dataPath('packs', 'health', 'journal.jsonl')
    assert.ok(existsSync(p), `健康数据必须落在 ${p}`)
    const last = readFileSync(p, 'utf8').trim().split('\n').pop()
    assert.match(last, /pack隔离测试/)
    // research pack 的数据目录不应被 health pack 写到
    const foreign = dataPath('packs', 'research')
    // （research 目录可能由 research pack 创建；这里只断言 health 没写进别人的 dataRoot）
    assert.equal(res.value.text.includes('data/packs/health/'), true, '输出应指明数据目录')
  } finally {
    await host.dispose()
  }
})

// ---------------------------------------------------------------------------
// 4) 底座零学科词（shell + core）
// ---------------------------------------------------------------------------
/** 剥离注释与字符串字面量，只留可执行代码。 */
function stripCommentsAndStrings(text) {
  let out = ''
  let i = 0
  while (i < text.length) {
    const c = text[i]
    const nx = text[i + 1]
    if (c === '/' && nx === '/') { while (i < text.length && text[i] !== '\n') i += 1; continue }
    if (c === '/' && nx === '*') { i += 2; while (i < text.length && !(text[i] === '*' && text[i + 1] === '/')) i += 1; i += 2; continue }
    if (c === '"' || c === "'" || c === '`') {
      const q = c
      i += 1
      while (i < text.length) {
        if (text[i] === '\\') { i += 2; continue }
        if (text[i] === q) { i += 1; break }
        i += 1
      }
      out += '""'
      continue
    }
    out += c
    i += 1
  }
  return out
}

function collect(dir, out = []) {
  let names = []
  try { names = readdirSync(dir, { withFileTypes: true }) } catch { return out }
  for (const n of names) {
    if (n.name.startsWith('.')) continue
    const p = join(dir, n.name)
    if (n.isDirectory()) collect(p, out)
    else if (/\.(mjs|cjs|js|json)$/.test(n.name)) out.push(p)
  }
  return out
}

const SHELL_DIR = join(PROJECT_ROOT, 'apps', 'desktop')
const CORE_DIR = join(PROJECT_ROOT, 'packages', 'core')

/** 学科/业务词（研究领域 + 其它垂直领域）。shell 与 core 一律零容忍。 */
const DOMAIN_WORDS = [
  'arxiv', 'doi', '文献', '论文', 'citation', 'bibtex', 'zotero', 'overleaf', 'latex',
  '笔记', '健康', '养老', '医院', '用药', '血压',
]

test('底座零学科词：shell（apps/desktop）源码零命中（含注释与字符串）', () => {
  const files = collect(SHELL_DIR)
  assert.ok(files.length >= 4, 'shell 至少要扫到 main/ui-bridge/core-host/timer-driver')
  for (const f of files) {
    const text = readFileSync(f, 'utf8')
    for (const w of DOMAIN_WORDS) {
      assert.equal(text.includes(w), false, `${relative(PROJECT_ROOT, f)} 命中学科词「${w}」`)
    }
  }
})

test('底座零学科词：core（packages/core）源码零命中', () => {
  // domains.json 是【数据】不是代码（白名单按领域可换），故排除；
  // 其余 .mjs 一律扫描。
  const files = collect(CORE_DIR).filter((f) => !f.endsWith('domains.json'))
  assert.ok(files.length >= 8, 'core 至少要扫到 net/safefs/registry 等')
  for (const f of files) {
    const text = readFileSync(f, 'utf8')
    for (const w of DOMAIN_WORDS) {
      assert.equal(text.includes(w), false, `${relative(PROJECT_ROOT, f)} 命中学科词「${w}」`)
    }
  }
})

test('底座零学科词：core 的网络白名单来自数据文件而非源码', () => {
  // arxiv 等学科域名只能出现在 domains.json（数据）里，不出现在任何 .mjs 源码里
  const domainsFile = join(CORE_DIR, 'src', 'domains.json')
  assert.ok(existsSync(domainsFile), 'packages/core/src/domains.json 必须存在')
  const doc = JSON.parse(readFileSync(domainsFile, 'utf8'))
  assert.ok(Array.isArray(doc.allowedDomains) && doc.allowedDomains.length >= 7)
  for (const f of collect(CORE_DIR).filter((p) => p.endsWith('.mjs'))) {
    assert.equal(readFileSync(f, 'utf8').includes('arxiv'), false, `${relative(PROJECT_ROOT, f)} 不得含 arxiv`)
  }
})

// ---------------------------------------------------------------------------
// 5) 配置读写
// ---------------------------------------------------------------------------
test('settings: 默认值 = research + teal + personal；写读一致', () => {
  // 用 DEFAULT_SETTINGS 作判据（不硬编码字面量），并在离开时恢复现场，
  // 避免本测试把 config.json 改坏影响其它用例。
  const before = loadSettings()
  try {
    saveSettings({ activePack: DEFAULT_SETTINGS.activePack, theme: DEFAULT_SETTINGS.theme, edition: DEFAULT_SETTINGS.edition })
    const s = loadSettings()
    assert.equal(s.activePack, DEFAULT_SETTINGS.activePack)
    assert.equal(s.theme, DEFAULT_SETTINGS.theme)
    assert.equal(s.edition, 'personal')
    assert.ok(s.enabledPacks.includes(s.activePack))
  } finally {
    saveSettings({ activePack: before.activePack, theme: before.theme, edition: before.edition })
  }
})

test('settings: 非法 edition 被拒且不写盘', () => {
  const before = readFileSync(dataPath('config.json'), 'utf8')
  assert.throws(() => saveSettings({ edition: 'ultimate' }), /非法 edition/)
  const after = readFileSync(dataPath('config.json'), 'utf8')
  assert.equal(before, after, '非法 edition 不得改动 config.json')
})
