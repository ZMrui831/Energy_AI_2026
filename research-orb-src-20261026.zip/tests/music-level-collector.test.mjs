// tests/music-level-collector.test.mjs
//
// Pure-node contract tests for the S13 music level collection layer.
// ZERO real PowerShell, ZERO real process spawning: every scenario injects a
// fake spawn / fake kill / fake isAlive so `node --test
// tests/music-level-collector.test.mjs` is deterministic and Electron-free.
// (Without an injected killTreeImpl, stop() would fall back to the real
// defaultKillTree and spawn a real taskkill.exe -- slow and non-hermetic.)

import test from 'node:test'
import assert from 'node:assert/strict'
import { EventEmitter } from 'node:events'
import { PassThrough } from 'node:stream'

import {
  createLevelCollector,
  parseLine,
  listOwnPowershell,
  killTreeArgs,
  defaultKillTree,
  levelCollectorPath,
  DEFAULT_POLL_MS,
} from '../packages/plugins/music/level-collector.mjs'

/** No-op tree kill: keeps stop() hermetic (no real taskkill.exe in tests). */
const noKill = () => {}

// ---------------------------------------------------------------------------
// Fake child process (stands in for the real powershell.exe child).
// - is an EventEmitter (has .on / .emit like ChildProcess)
// - has .stdout (PassThrough, supports setEncoding + write)
// - has .kill() that flips a flag and (optionally) notifies a liveness map
// ---------------------------------------------------------------------------
function makeFakeChild({ pid = 4242, autoExit = false, exitAfter = 0, aliveMap = null } = {}) {
  const child = new EventEmitter()
  const stdout = new PassThrough()
  const stderr = new PassThrough()
  child.stdout = stdout
  child.stderr = stderr
  child.pid = pid
  child.killed = false
  child.kill = function () {
    this.killed = true
    if (aliveMap) aliveMap[pid] = false
    setImmediate(() => this.emit('exit', null, 'SIGTERM'))
  }
  if (autoExit) setImmediate(() => child.emit('exit', 1, null))
  if (exitAfter > 0) setTimeout(() => child.emit('exit', 1, null), exitAfter)
  return child
}

function levelLine(over = {}) {
  const obj = { ts: 1730000000000, peak: 0.5, ...over }
  return JSON.stringify(obj)
}

function errorLine(reason = 'no-endpoint:8007048F') {
  return JSON.stringify({ ts: 1730000000000, error: reason })
}

/** Resolve after N event-loop ticks (let PassThrough chunks flush). */
function ticks(n = 3) {
  return new Promise((resolve) => {
    let left = n
    const step = () => (left-- <= 0 ? resolve() : setImmediate(step))
    setImmediate(step)
  })
}

// ---------------------------------------------------------------------------
// T1: parseLine happy path (fixed schema {ts, peak}, boundaries tolerated)
// ---------------------------------------------------------------------------
test('parseLine: valid {"ts":..,"peak":..} -> ok:true with normalized sample', () => {
  const r = parseLine(levelLine({ ts: 1730000000123, peak: 0.7315 }))
  assert.equal(r.ok, true)
  assert.deepEqual(r.sample, { ts: 1730000000123, peak: 0.7315 })
  // boundaries 0 and 1 are legal peaks
  assert.equal(parseLine(levelLine({ peak: 0 })).ok, true)
  assert.equal(parseLine(levelLine({ peak: 1 })).ok, true)
  // surrounding whitespace / CRLF tail / stray BOM tolerated
  assert.equal(parseLine('  ' + levelLine() + '  \r').ok, true)
  assert.equal(parseLine('\ufeff' + levelLine()).ok, true)
})

// ---------------------------------------------------------------------------
// T2: parseLine fault tolerance (never throws) + error-line classification
// ---------------------------------------------------------------------------
test('parseLine: dirty input -> ok:false, never throws', () => {
  assert.equal(parseLine('').ok, false) // empty
  assert.equal(parseLine('   ').ok, false) // whitespace only
  assert.equal(parseLine('not json at all').ok, false) // invalid json
  assert.equal(parseLine('{"ts":1}').ok, false) // missing peak
  assert.equal(parseLine('{"peak":0.5}').ok, false) // missing ts
  assert.equal(parseLine('{"ts":"x","peak":0.5}').ok, false) // bad type
  assert.equal(parseLine('{"ts":1,"peak":"0.5"}').ok, false) // bad type
  assert.equal(parseLine('{"ts":1,"peak":1.5}').ok, false) // peak out of range
  assert.equal(parseLine('{"ts":1,"peak":-0.1}').ok, false) // peak out of range
  assert.equal(parseLine('[1,2,3]').ok, false) // array, not object
  assert.equal(parseLine('null').ok, false) // null
  assert.equal(parseLine('\ufeff').ok, false) // BOM only
  assert.equal(parseLine('\ufeffgarbage').ok, false) // BOM + garbage

  // helper error line is CLASSIFIED (drives backoff restart), not swallowed
  const err = parseLine(errorLine())
  assert.equal(err.ok, false)
  assert.equal(err.reason, 'error-line')
  assert.equal(err.error, 'no-endpoint:8007048F')
})

// ---------------------------------------------------------------------------
// T3: healthy stream -> onSample receives parsed samples; spawn argv order
// ---------------------------------------------------------------------------
test('collector: healthy stream -> 3 samples with exact fields; spawn argv order', async () => {
  const received = []
  const spawnCalls = []
  const child = makeFakeChild({ pid: 55501 })
  const controller = createLevelCollector({
    spawnImpl: (cmd, args, opts) => {
      spawnCalls.push({ cmd, args, opts })
      return child
    },
    killTreeImpl: noKill,
    onSample: (s) => received.push(s),
    parentPid: 4242,
    pollMs: 33,
  })
  controller.start()

  assert.equal(spawnCalls.length, 1)
  const call = spawnCalls[0]
  assert.equal(call.cmd, 'powershell.exe')
  // argv order is the cross-file contract (level-collector.ps1 reads args[0]=parentPid, args[1]=pollMs)
  // NOTE: -ExecutionPolicy Bypass is inserted before -File (local unsigned helper must not be
  // blocked by a RemoteSigned/AllSigned host policy).
  assert.deepEqual(call.args, ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', levelCollectorPath, '4242', '33'])
  assert.equal(call.opts.windowsHide, true)

  // 1) two complete lines in one chunk (second uses CRLF)
  child.stdout.write(levelLine({ ts: 1, peak: 0.25 }) + '\n' + levelLine({ ts: 2, peak: 0.5 }) + '\r\n')
  // 2) a line split across two writes
  const third = levelLine({ ts: 3, peak: 0.75 })
  child.stdout.write(third.slice(0, 12))
  child.stdout.write(third.slice(12) + '\n')

  await ticks()
  assert.equal(received.length, 3)
  assert.deepEqual(received.map((s) => s.ts), [1, 2, 3])
  assert.deepEqual(received.map((s) => s.peak), [0.25, 0.5, 0.75])
  assert.deepEqual(received[0], { ts: 1, peak: 0.25 })

  const res = controller.stop()
  assert.equal(res.pid, 55501)
})

// ---------------------------------------------------------------------------
// T4: dirty stdout (half line / empty / BOM / non-JSON / missing fields)
//     -> no throw, no callback; the stream recovers afterwards
// ---------------------------------------------------------------------------
test('collector: dirty stdout -> no throw, no callback, stream recovers', async () => {
  const received = []
  const child = makeFakeChild({ pid: 55502 })
  const controller = createLevelCollector({
    spawnImpl: () => child,
    killTreeImpl: noKill,
    onSample: (s) => received.push(s),
  })
  controller.start()

  child.stdout.write('\n') // empty line
  child.stdout.write('   \n') // whitespace only
  child.stdout.write('\ufeff\n') // BOM only
  child.stdout.write('not json\n') // invalid json
  child.stdout.write('{"ts":1}\n') // missing peak
  child.stdout.write('{"ts":1,"peak":9}\n') // peak out of range
  const half = levelLine({ ts: 7, peak: 0.1 })
  child.stdout.write(half.slice(0, 8)) // half line: no newline yet

  await ticks()
  assert.equal(received.length, 0, 'no callback for any dirty / partial line')

  child.stdout.write(half.slice(8) + '\n') // complete the split line
  await ticks()
  assert.equal(received.length, 1)
  assert.deepEqual(received[0], { ts: 7, peak: 0.1 })
  controller.stop()
})

// ---------------------------------------------------------------------------
// T5: helper error line -> ONE failure + ONE backoff restart (default 500ms)
// ---------------------------------------------------------------------------
test('collector: helper error line -> one failure, one backoff restart (delay 500)', () => {
  let spawnCount = 0
  const children = []
  const restarts = []
  let settle = null
  const controller = createLevelCollector({
    spawnImpl: () => {
      spawnCount += 1
      const c = makeFakeChild({ pid: 55510 + spawnCount })
      children.push(c)
      return c
    },
    killTreeImpl: noKill,
    baseDelay: 500, // explicit default
    onRestart: (info) => {
      restarts.push(info)
      // Defer: the rest of the timer callback (audit line + respawn) runs
      // synchronously after onRestart returns, so by the next tick the fresh
      // child has been spawned.
      setImmediate(() => {
        try {
          assert.equal(restarts.length, 1, 'exactly one backoff step')
          assert.equal(info.delay, 500, 'first backoff delay = baseDelay (500)')
          assert.equal(info.restarts, 1)
          assert.equal(controller.restartCount(), 1)
          assert.equal(spawnCount, 2, 'exactly one fresh child spawned')
          controller.stop()
          settle.resolve()
        } catch (e) {
          settle.reject(e)
        }
      })
    },
  })
  controller.start()

  // The helper reports a fatal collection error and exits; the error line
  // ALONE (no exit event needed here) must drive exactly one backoff restart.
  children[0].stdout.write(errorLine() + '\n')

  return new Promise((resolve, reject) => {
    settle = { resolve, reject }
    setTimeout(() => reject(new Error('no restart within 3s')), 3000)
  })
})

// ---------------------------------------------------------------------------
// T6: spawn contract details (defaults + clamping) and lifecycle idempotence
// ---------------------------------------------------------------------------
test('collector: default parentPid = process.pid, default pollMs = 33, clamped [10,1000]', () => {
  const calls = []
  const controllers = []
  const spawnImpl = (cmd, args) => {
    calls.push(args)
    return makeFakeChild({ pid: 60000 + calls.length })
  }
  const c1 = createLevelCollector({ spawnImpl, killTreeImpl: noKill })
  controllers.push(c1)
  c1.start()
  // args: [..., -File, <ps1>, parentPid, pollMs]  -> parentPid at 6, pollMs at 7
  assert.equal(calls[0][6], String(process.pid))
  assert.equal(calls[0][7], '33')
  assert.equal(DEFAULT_POLL_MS, 33)

  controllers.push(createLevelCollector({ spawnImpl, killTreeImpl: noKill, pollMs: 5 })) // below floor
  controllers.push(createLevelCollector({ spawnImpl, killTreeImpl: noKill, pollMs: 9999 })) // above ceiling
  controllers[1].start()
  assert.equal(calls[1][7], '10')
  controllers[2].start()
  assert.equal(calls[2][7], '1000')

  for (const c of controllers) c.stop()
})

test('collector: no start() -> no spawn; double start() idempotent; start after stop re-arms', () => {
  let spawnCount = 0
  const controller = createLevelCollector({
    spawnImpl: () => {
      spawnCount += 1
      return makeFakeChild({ pid: 55530 + spawnCount })
    },
    killTreeImpl: noKill,
    baseDelay: 50,
  })
  assert.equal(spawnCount, 0, 'createLevelCollector alone must not spawn')

  controller.start()
  controller.start() // idempotent
  assert.equal(spawnCount, 1)
  assert.equal(controller.isRunning(), true)
  assert.equal(controller.pid(), 55531)

  controller.stop()
  assert.equal(controller.isRunning(), false)

  controller.start() // re-arm after stop (driver on/off cycles)
  assert.equal(spawnCount, 2)
  assert.equal(controller.pid(), 55532)
  controller.stop()
})

// ---------------------------------------------------------------------------
// T7: stop() races -- spawn-after-stop is impossible (race gates)
// ---------------------------------------------------------------------------
test('collector: stop() then child exit -> no respawn (exit-handler gate)', async () => {
  let spawnCount = 0
  const child = makeFakeChild({ pid: 55520 })
  const controller = createLevelCollector({
    spawnImpl: () => {
      spawnCount += 1
      return child
    },
    killTreeImpl: noKill,
    baseDelay: 50,
  })
  controller.start()
  controller.stop() // synchronous, BEFORE the exit event is delivered
  child.emit('exit', 1, null)

  await new Promise((r) => setTimeout(r, 150)) // > baseDelay: a restart would have fired
  assert.equal(spawnCount, 1, 'no respawn after stop()')
  assert.equal(controller.restartCount(), 0)
})

test('collector: pending restart timer + stop() -> no respawn (timer gate)', async () => {
  let spawnCount = 0
  const child = makeFakeChild({ pid: 55521, autoExit: true })
  const controller = createLevelCollector({
    spawnImpl: () => {
      spawnCount += 1
      return child
    },
    killTreeImpl: noKill,
    baseDelay: 100,
  })
  controller.start()
  await ticks(2) // let the auto-exit land -> restart scheduled at ~100ms
  controller.stop() // stop BEFORE the timer fires

  await new Promise((r) => setTimeout(r, 250))
  assert.equal(spawnCount, 1, 'pending restart timer must not spawn after stop()')
  assert.equal(controller.restartCount(), 0)
})

test('collector: stop() from inside the restart callback -> spawnChild entry gate refuses', async () => {
  let spawnCount = 0
  const child = makeFakeChild({ pid: 55522, autoExit: true })
  const controller = createLevelCollector({
    spawnImpl: () => {
      spawnCount += 1
      return child
    },
    killTreeImpl: noKill,
    baseDelay: 30,
    // Re-entrant stop inside the timer callback: spawnChild's entry gate
    // (stopped) must refuse the respawn even though the callback already
    // passed its own gate. Gate 2 (pre-spawn re-check) is the adjacent
    // belt-and-braces line with no yield in between.
    onRestart: () => controller.stop(),
  })
  controller.start()

  await new Promise((r) => setTimeout(r, 200))
  assert.equal(spawnCount, 1, 'entry gate blocked the respawn after in-callback stop()')
  assert.equal(controller.restartCount(), 1)
  assert.equal(controller.isRunning(), false)
})

test('collector: error line + stop() before the timer -> no respawn', async () => {
  let spawnCount = 0
  const child = makeFakeChild({ pid: 55523 })
  const controller = createLevelCollector({
    spawnImpl: () => {
      spawnCount += 1
      return child
    },
    killTreeImpl: noKill,
    baseDelay: 100,
  })
  controller.start()
  child.stdout.write(errorLine() + '\n') // schedules a restart at ~100ms
  await ticks(2)
  controller.stop()

  await new Promise((r) => setTimeout(r, 200))
  assert.equal(spawnCount, 1)
  assert.equal(controller.restartCount(), 0)
})

// ---------------------------------------------------------------------------
// T8: stop() kills only our own pid tree, SYNCHRONOUSLY (taskkill /T /F)
// ---------------------------------------------------------------------------
test('collector: stop() kills own pid tree synchronously; taskkill argv is /PID /T /F', () => {
  const aliveMap = { 7001: true }
  const child = makeFakeChild({ pid: 7001, aliveMap })
  const killTreeCalls = []
  let killTreeReturned = false
  const controller = createLevelCollector({
    spawnImpl: () => child,
    killTreeImpl: (pid) => {
      killTreeCalls.push(pid)
      killTreeReturned = true
    },
    isAlive: (p) => !!aliveMap[p],
  })
  controller.start()
  assert.equal(controller.isRunning(), true)
  assert.equal(controller.pid(), 7001)

  const res = controller.stop()
  assert.equal(res.pid, 7001)
  assert.equal(killTreeReturned, true, 'killTree already ran when stop() returned (synchronous)')
  assert.deepEqual(killTreeCalls, [7001], 'tree kill used our own PID only')
  assert.equal(child.killed, true, 'child.kill() was invoked')
  assert.equal(aliveMap[7001], false, 'liveness probe reports pid dead (no residue)')
  assert.equal(controller.isRunning(), false)
  assert.equal(controller.restartCount(), 0, 'stop must not schedule a restart')

  // residue self-check pure function agrees
  const check = listOwnPowershell([7001], (p) => !!aliveMap[p])
  assert.equal(check.allExited, true)

  // default tree-kill argv: ONLY our own PID, /T (tree) /F (force), hidden
  assert.deepEqual(killTreeArgs(7001), ['/PID', '7001', '/T', '/F'])
  const execCalls = []
  defaultKillTree(7001, (cmd, args, opts) => execCalls.push({ cmd, args, opts }))
  assert.equal(execCalls.length, 1)
  assert.equal(execCalls[0].cmd, 'taskkill')
  assert.deepEqual(execCalls[0].args, ['/PID', '7001', '/T', '/F'])
  assert.equal(execCalls[0].opts.windowsHide, true)
  // a failing taskkill (already dead) is swallowed, never thrown from stop()
  assert.doesNotThrow(() => defaultKillTree(1, () => {
    throw new Error('process not found')
  }))
})

// ---------------------------------------------------------------------------
// T9: exponential backoff sequence 500/1000/2000/4000 (capped at maxDelay)
// ---------------------------------------------------------------------------
test('collector: exponential backoff sequence, capped at maxDelay', () => {
  let spawnCount = 0
  const delays = []
  const controller = createLevelCollector({
    spawnImpl: () => {
      spawnCount += 1
      return makeFakeChild({ pid: 55540 + spawnCount, autoExit: true }) // dies immediately
    },
    killTreeImpl: noKill,
    baseDelay: 50,
    maxDelay: 1000,
    onRestart: (info) => delays.push(info.delay),
  })
  controller.start()

  return new Promise((resolve, reject) => {
    const guard = setTimeout(() => reject(new Error('backoff did not progress: ' + JSON.stringify(delays))), 5000)
    const check = () => {
      if (delays.length >= 6) {
        clearTimeout(guard)
        try {
          // delay = min(maxDelay, baseDelay * 2^failures) with PRIOR failure count
          assert.deepEqual(delays, [50, 100, 200, 400, 800, 1000])
          controller.stop()
          resolve()
        } catch (e) {
          reject(e)
        }
      } else {
        setTimeout(check, 20)
      }
    }
    setTimeout(check, 20)
  })
})

// ---------------------------------------------------------------------------
// T10: a healthy run past healthMs resets the backoff counter
// ---------------------------------------------------------------------------
test('collector: healthy uptime past healthMs resets failures (backoff restarts at base)', () => {
  let spawnCount = 0
  const delays = []
  const controller = createLevelCollector({
    spawnImpl: () => {
      spawnCount += 1
      return makeFakeChild({
        pid: 55550 + spawnCount,
        autoExit: spawnCount === 1, // child #1 dies instantly
        exitAfter: spawnCount === 2 ? 300 : 0, // child #2 lives past healthMs
      })
    },
    killTreeImpl: noKill,
    baseDelay: 50,
    maxDelay: 1000,
    healthMs: 120,
    onRestart: (info) => delays.push(info.delay),
  })
  controller.start()

  return new Promise((resolve, reject) => {
    const guard = setTimeout(() => reject(new Error('no second restart: ' + JSON.stringify(delays))), 4000)
    const check = () => {
      if (delays.length >= 2) {
        clearTimeout(guard)
        try {
          assert.equal(delays[0], 50) // first failure: 50 * 2^0
          assert.equal(delays[1], 50, 'failures reset by healthy uptime -> back to base delay')
          controller.stop()
          resolve()
        } catch (e) {
          reject(e)
        }
      } else {
        setTimeout(check, 20)
      }
    }
    setTimeout(check, 20)
  })
})

// ---------------------------------------------------------------------------
// T11: spawn failure (EPERM etc.) counts as a failure and backs off, no throw
// ---------------------------------------------------------------------------
test('collector: spawn failure -> backoff, no throw', () => {
  let attempts = 0
  const delays = []
  const controller = createLevelCollector({
    spawnImpl: () => {
      attempts += 1
      throw new Error('spawn EPERM')
    },
    killTreeImpl: noKill,
    baseDelay: 40,
    onRestart: (info) => delays.push(info.delay),
  })
  assert.doesNotThrow(() => controller.start(), 'start() must not throw on spawn failure')

  return new Promise((resolve, reject) => {
    const guard = setTimeout(() => reject(new Error('no retry: ' + JSON.stringify(delays))), 3000)
    const check = () => {
      if (delays.length >= 2) {
        clearTimeout(guard)
        try {
          assert.deepEqual(delays, [40, 80])
          assert.ok(attempts >= 3, 'each backoff step retries the spawn')
          controller.stop()
          resolve()
        } catch (e) {
          reject(e)
        }
      } else {
        setTimeout(check, 20)
      }
    }
    setTimeout(check, 20)
  })
})

// ---------------------------------------------------------------------------
// T12: listOwnPowershell pure residue self-check
// ---------------------------------------------------------------------------
test('listOwnPowershell: reports alive vs exited across injected pids', () => {
  const state = { 1: true, 2: false, 3: true }
  const isAlive = (p) => !!state[p]
  const r1 = listOwnPowershell([1, 2, 3], isAlive)
  assert.equal(r1.allExited, false)
  assert.deepEqual(r1.alive.sort((a, b) => a - b), [1, 3])

  state[1] = false
  state[3] = false
  const r2 = listOwnPowershell([1, 2, 3], isAlive)
  assert.equal(r2.allExited, true)
  assert.deepEqual(r2.alive, [])

  // single pid (non-array) accepted
  const r3 = listOwnPowershell(1, () => false)
  assert.equal(r3.allExited, true)

  // a throwing probe counts as dead, never crashes the check
  const r4 = listOwnPowershell([9], () => {
    throw new Error('boom')
  })
  assert.equal(r4.allExited, true)

  // null / empty input tolerated
  assert.deepEqual(listOwnPowershell(null, isAlive).pids, [])
})
