// tests/router.test.mjs —— S25·1B 分层路由：选档/回落/令牌桶/usage/无密钥引用
import { test, beforeEach, afterEach } from 'node:test'
import assert from 'node:assert/strict'
import { mkdirSync, rmSync, writeFileSync, readFileSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, dataPath } from '../packages/core/src/safefs.mjs'
import { TASK_CLASSES, routeOf, createRateLimiter, createRouter } from '../packages/core/src/router.mjs'

const ROOT = dataPath('tmp', 's25-router-test')
let DIR
let n = 0

beforeEach(() => {
  n += 1
  DIR = `${ROOT}-${n}`
  rmSync(DIR, { recursive: true, force: true })
  mkdirSync(DIR, { recursive: true })
})
afterEach(() => { rmSync(DIR, { recursive: true, force: true }) })

const PROVIDERS = {
  cheap: { providerId: 'school-gateway', model: 'qwen' },
  flagship: { providerId: 'deepseek-api', model: 'deepseek-chat' },
}

test('router: 档位路由映射（extract→cheap；summarize/score-plan/reason→flagship；未知→null）', () => {
  assert.equal(routeOf('extract'), 'cheap')
  assert.equal(routeOf('summarize'), 'flagship')
  assert.equal(routeOf('score-plan'), 'flagship')
  assert.equal(routeOf('reason'), 'flagship')
  assert.equal(routeOf('bogus'), null)
  assert.deepEqual([...TASK_CLASSES], ['extract', 'summarize', 'score-plan', 'reason'])
})

test('router: 未注入 invoke → E_NO_INVOKE（本模块不直接出网）', () => {
  assert.throws(() => createRouter({ providers: PROVIDERS }), /invoke/)
})

test('router: extract 走 cheap；usage 行含 provider/model/taskClass/fallback', async () => {
  const usagePath = join(DIR, 'usage.jsonl')
  const seen = []
  const r = createRouter({
    providers: PROVIDERS,
    invoke: async (p) => { seen.push(p); return { text: 'ok-cheap', tokens: 12 } },
    usagePath,
  })
  const out = await r.run('extract', { prompt: 'x' })
  assert.equal(out.ok, true)
  assert.equal(out.tier, 'cheap')
  assert.equal(out.fallback, false)
  assert.equal(seen[0].tier, 'cheap')
  assert.equal(seen[0].provider.model, 'qwen')
  const row = JSON.parse(readFileSync(usagePath, 'utf8').trim())
  assert.equal(row.taskClass, 'extract')
  assert.equal(row.providerId, 'school-gateway')
  assert.equal(row.model, 'qwen')
  assert.equal(row.fallback, false)
  assert.equal(row.tokens, 12)
})

test('router: cheap 失败 → 回落旗舰一次 + route-fallback 审计 + usage fallback=true', async () => {
  const usagePath = join(DIR, 'usage.jsonl')
  const audits = []
  let flag = false
  const r = createRouter({
    providers: PROVIDERS,
    invoke: async (p) => {
      if (p.tier === 'cheap' && !flag) { flag = true; throw Object.assign(new Error('boom'), { code: 'E_HTTP_500' }) }
      return { text: 'flagship-ok' }
    },
    audit: (rec) => audits.push(rec),
    usagePath,
  })
  const out = await r.run('extract', { prompt: 'x' })
  assert.equal(out.ok, true)
  assert.equal(out.tier, 'flagship')
  assert.equal(out.fallback, true)
  assert.equal(audits.filter((a) => a.kind === 'route-fallback').length, 1)
  const rows = readFileSync(usagePath, 'utf8').trim().split('\n').map((l) => JSON.parse(l))
  assert.equal(rows.length, 2, '两跳各落一行 usage')
  assert.equal(rows[1].fallback, true)
  assert.equal(rows[1].model, 'deepseek-chat')
})

test('router: reason 永远旗舰且失败不回落（旗舰已最高档）', async () => {
  const audits = []
  const r = createRouter({
    providers: PROVIDERS,
    invoke: async () => { throw new Error('flagship down') },
    audit: (rec) => audits.push(rec),
    usagePath: join(DIR, 'usage.jsonl'),
  })
  const out = await r.run('reason', { prompt: 'x' })
  assert.equal(out.ok, false)
  assert.equal(out.tier, 'flagship')
  assert.equal(out.fallback, false, '旗舰失败不再回落')
  assert.equal(audits.filter((a) => a.kind === 'route-fallback').length, 0)
})

test('router: 未知 taskClass → E_TASK_CLASS，不消耗请求', async () => {
  let calls = 0
  const r = createRouter({ providers: PROVIDERS, invoke: async () => { calls += 1; return { text: 'x' } } })
  await assert.rejects(() => r.run('bogus', {}), /E_TASK_CLASS|未知任务档位/)
  assert.equal(calls, 0)
})

test('router: 令牌桶桶空排队不失败（capPerMin=2，5 连发全部成功且出现等待）', async () => {
  const waits = []
  const limiter = createRateLimiter({
    capPerMin: 2,
    sleep: async (ms) => { waits.push(ms) }, // 虚拟等待：立刻 resolve，验证“排队不失败”语义
  })
  for (let i = 0; i < 5; i++) await limiter.acquire()
  assert.ok(waits.length >= 3, `桶空后应出现排队等待，实际 waits=${JSON.stringify(waits)}`)
  assert.ok(waits.every((w) => w >= 0))
})

test('router: providers.json 只存引用不含明文密钥（读真实数据文件）', () => {
  const p = dataPath('providers.json')
  assert.ok(existsSync(p), 'providers.json 应存在')
  const raw = readFileSync(p, 'utf8')
  assert.ok(!/sk-[A-Za-z0-9]{16,}/.test(raw), '不得含 sk- 形态密钥')
  const doc = JSON.parse(raw)
  assert.equal(doc.cheap.model, 'qwen')
  assert.match(doc.cheap.authRef, /^claude-settings:/, 'cheap 密钥应为 claude-settings 引用')
  assert.match(doc.flagship.authRef, /^secrets:/, 'flagship 密钥应为 secrets 引用')
})
