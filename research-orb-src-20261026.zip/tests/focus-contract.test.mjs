import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const MAIN = readFileSync(join(ROOT, 'apps', 'desktop', 'main.mjs'), 'utf8')

// S67·4-B：聚焦契约——唯一入口 activateForInteraction；被动展示（showInactive）不聚焦

function fnRanges(src) {
  const lines = src.split('\n')
  const out = []
  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(/^\s*function\s+([A-Za-z_$][\w$]*)\s*\(/)
    if (!m) continue
    let depth = 0, started = false, end = -1
    for (let j = i; j < lines.length; j++) {
      for (const ch of lines[j]) { if (ch === '{') { depth++; started = true } else if (ch === '}') depth-- }
      if (started && depth === 0) { end = j; break }
    }
    out.push({ name: m[1], start: i, end })
  }
  return out
}

function enclosing(ranges, idx) {
  let best = null
  for (const r of ranges) if (r.start <= idx && idx <= r.end && (!best || (r.end - r.start) < (best.end - best.start))) best = r
  return best ? best.name : '(top-level)'
}

test('F-E1 存在唯一聚焦入口 activateForInteraction', () => {
  assert.match(MAIN, /function activateForInteraction\s*\(/)
})

test('F-E2 所有 .focus() 调用点均在 activateForInteraction 内', () => {
  const ranges = fnRanges(MAIN)
  const sites = []
  MAIN.split('\n').forEach((l, i) => {
    if (!/\.focus\(\)/.test(l)) return
    if (/^\s*(\*|\/\/)/.test(l)) return
    sites.push({ line: i + 1, fn: enclosing(ranges, i) })
  })
  assert.ok(sites.length >= 1, '应至少有一处 .focus()（activateForInteraction 内）')
  const bad = sites.filter((s) => s.fn !== 'activateForInteraction')
  assert.deepEqual(bad, [], '聚焦越界：' + JSON.stringify(bad))
})

test('F-E3 被动展示走 showInactive，且不直接调用 focus', () => {
  assert.match(MAIN, /win\.showInactive\(\)/)
  assert.match(MAIN, /else\s*\{\s*win\.showInactive\(\)/)
  // showWindow 的 activate 分支只经 activateForInteraction，不直接 .focus()
  const ranges = fnRanges(MAIN)
  const show = ranges.filter((r) => r.name === 'showWindow').sort((a, b) => (a.end - a.start) - (b.end - b.start))[0]
  assert.ok(show, 'showWindow 函数存在')
  const body = MAIN.split('\n').slice(show.start, show.end + 1).join('\n')
  assert.ok(/activateForInteraction\(win\)/.test(body), 'activate 分支应调用 activateForInteraction')
  assert.ok(!/\.focus\(\)/.test(body), 'showWindow 内不得直接调用 .focus()')
})
