// tests/agent.test.mjs
//
// AgentCore 回归：会话落盘（JSONL 追加）、多轮历史、中断、降级（明示不静默）、
// DegradeController 状态机、status() 快照。全程用假 provider，不走真实网络。

import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'

import { createAgent, DegradeController, DEGRADE_FALLBACK_MODEL, degradeMessage, isReasonerFailure } from '../packages/core/src/agent.mjs'
import * as sessions from '../packages/core/src/session.mjs'
import { EVENT } from '../packages/core/src/providers/index.mjs'

/** 清理测试遗留文件：用"截断"而不是删除。
 *  原因：宿主环境有批量删除保护，删到一定次数会直接抛 SAFE_DELETE_BULK_CONFIRM_REQUIRED，
 *  把与被删文件毫无关系的测试一起带崩（实测：agent.test.mjs 整文件失败）。
 *  测试的本意只是"从这个文件重新开始"，截断即可，顺带少一份误删风险。
 *  多余的实参（如 { force: true }）会被忽略，保持调用点不必改写。 */
const truncateFile = (p) => {
  try {
    writeFileSync(p, '')
  } catch {
    /* 文件不存在等情形直接忽略 */
  }
}

const cleanup = []
const track = (id) => {
  cleanup.push(sessions.sessionPath(id))
  return id
}
test.after(() => {
  for (const p of cleanup) truncateFile(p, { force: true })
})

/** 假 provider：script[model] 决定行为，'fail' 直接报 429，'slow' 流式慢放。 */
function fake({ id = 'fake', models = ['deepseek-chat', 'deepseek-reasoner'], script = {} } = {}) {
  return {
    id,
    name: id,
    kind: 'fake',
    defaultModel: models[0],
    describe: () => ({ id, name: id, kind: 'fake', defaultModel: models[0], models: [...models] }),
    describeConfig: () => ({ ready: true, models: [...models], baseUrl: 'https://fake.invalid', key: 'sk-f***' }),
    hasModel: (m) => models.includes(m),
    async listModels() {
      return models.map((m) => ({ id: m, name: m }))
    },
    async *chat({ model, signal }) {
      const b = script[model] || script.__default || '默认回复'
      if (b === 'fail') {
        yield { type: EVENT.ERROR, code: 'E_RATE_LIMITED', status: 429, retryable: true, message: `${id}: HTTP 429`, provider: id, model }
        return
      }
      if (b === 'auth') {
        yield { type: EVENT.ERROR, code: 'E_AUTH', status: 401, retryable: false, message: `${id}: HTTP 401`, provider: id, model }
        return
      }
      if (b === 'slow') {
        for (const ch of ['甲', '乙', '丙', '丁']) {
          if (signal && signal.aborted) {
            yield { type: EVENT.ERROR, code: 'E_ABORTED', message: '请求已被用户中断', retryable: false, aborted: true, provider: id, model }
            return
          }
          await new Promise((r) => setTimeout(r, 25))
          yield { type: EVENT.DELTA, text: ch, channel: 'content' }
        }
        yield { type: EVENT.DONE, text: '甲乙丙丁', provider: id, model, usage: null, finishReason: 'stop' }
        return
      }
      for (const ch of b) yield { type: EVENT.DELTA, text: ch, channel: 'content' }
      yield { type: EVENT.DONE, text: b, provider: id, model, usage: { total_tokens: 3 }, finishReason: 'stop' }
    },
  }
}

const registry = (list) => {
  const map = new Map(list.map((p) => [p.id, p]))
  return {
    list: () => [...map.values()],
    byId: (id) => map.get(id) || null,
    has: (id) => map.has(id),
    net: { queueState: () => ({ waiting: 0, limited: 0, requests: 0, retried: 0, denied: 0, exhausted: 0, reasonerWindowUsed: 0, reasonerLimitPerMinute: 10, buckets: [] }) },
  }
}

// ---------------------------------------------------------------------------
// session
// ---------------------------------------------------------------------------

test('session: createSession 生成合法 id 与首行元信息', () => {
  const s = sessions.createSession({ title: '标题', provider: 'fake', model: 'deepseek-chat' })
  track(s.id)
  assert.match(s.id, /^s-\d{8}-\d{6}-[0-9a-f]{4}$/)
  assert.ok(existsSync(s.path))
  const meta = JSON.parse(readFileSync(s.path, 'utf8').split('\n')[0])
  assert.equal(meta.type, 'session')
  assert.equal(meta.title, '标题')
})

test('session: 追加写是 JSONL，读回坏行只跳过不报废', () => {
  const s = sessions.createSession({ title: 't' })
  track(s.id)
  sessions.appendUser(s.id, 'u1')
  sessions.appendAssistant(s.id, { text: 'a1', provider: 'fake', model: 'deepseek-chat' })
  const raw = readFileSync(s.path, 'utf8')
  assert.ok(raw.endsWith('\n'), '必须每行以 \\n 收尾（追加写语义）')
  assert.ok(!raw.trimStart().startsWith('['), '不能是单个 JSON 数组')

  // 手工塞一行坏数据
  writeFileSync(s.path, raw + '{not json}\n')
  const back = sessions.readSession(s.id)
  assert.equal(back.turns.length, 2)
  assert.equal(back.badLines, 1)
})

test('session: deriveTitle 压平空白并截断', () => {
  assert.equal(sessions.deriveTitle('  多  行\n文本  '), '多 行 文本')
  assert.equal(sessions.deriveTitle(''), '新会话')
  assert.equal(sessions.deriveTitle('x'.repeat(100)).length, 41)
})

test('session: 非法 id 一律拒绝（路径穿越防线）', () => {
  for (const bad of ['../../evil', 'a/b', '', 'x'.repeat(80), 'a b']) {
    assert.throws(() => sessions.sessionPath(bad), (e) => e.code === 'E_BAD_SESSION_ID', `应拒绝 ${bad}`)
  }
})

test('session: historyMessages 按角色回放，可带 system 与 limit', () => {
  const s = sessions.createSession({ title: 't' })
  track(s.id)
  sessions.appendUser(s.id, 'u1')
  sessions.appendAssistant(s.id, { text: 'a1' })
  sessions.appendUser(s.id, 'u2')
  assert.deepEqual(sessions.historyMessages(s.id), [
    { role: 'user', content: 'u1' },
    { role: 'assistant', content: 'a1' },
    { role: 'user', content: 'u2' },
  ])
  assert.equal(sessions.historyMessages(s.id, { system: 'SYS' })[0].role, 'system')
  assert.equal(sessions.historyMessages(s.id, { limit: 2 }).length, 2)
})

test('session: listSessions 能列出并带轮数', () => {
  const s = sessions.createSession({ title: '可列出' })
  track(s.id)
  sessions.appendUser(s.id, 'x')
  const row = sessions.listSessions().find((r) => r.id === s.id)
  assert.ok(row)
  assert.equal(row.title, '可列出')
  assert.equal(row.turns, 1)
})

// ---------------------------------------------------------------------------
// agent 基础轮次
// ---------------------------------------------------------------------------

test('agent: 一轮跑通 —— 事件顺序 start→delta→done，消息与回复都落盘', async () => {
  const p = fake({ script: { __default: '答案 42' } })
  const agent = createAgent({ providers: registry([p]), systemPrompt: 'SYS' })
  const events = []
  const r = await agent.runTurn({ providerId: 'fake', message: '问题', onEvent: (e) => events.push(e) })
  track(r.sessionId)

  assert.equal(r.text, '答案 42')
  assert.equal(r.error, null)
  assert.equal(r.degraded, false)
  assert.equal(events[0].type, 'start')
  assert.equal(events[events.length - 1].type, 'done')
  assert.equal(events.filter((e) => e.type === 'delta').map((e) => e.text).join(''), '答案 42')

  const persisted = sessions.readSession(r.sessionId)
  assert.equal(persisted.turns.length, 2)
  assert.equal(persisted.turns[0].type, 'user')
  assert.equal(persisted.turns[0].text, '问题')
  assert.equal(persisted.turns[1].type, 'assistant')
  assert.equal(persisted.turns[1].text, '答案 42')
  assert.equal(persisted.meta.title, '问题')
  assert.ok(persisted.turns[1].ms >= 0)
})

test('agent: 多轮复用同一会话，历史被回放给 provider', async () => {
  const seen = []
  const p = fake({ script: { __default: 'ok' } })
  const spy = {
    ...p,
    async *chat(args) {
      seen.push(args.messages.map((m) => `${m.role}:${m.content}`))
      yield* p.chat(args)
    },
  }
  const agent = createAgent({ providers: registry([spy]), systemPrompt: null })
  const r1 = await agent.runTurn({ providerId: 'fake', message: '第一问' })
  track(r1.sessionId)
  await agent.runTurn({ sessionId: r1.sessionId, providerId: 'fake', message: '第二问' })

  assert.equal(seen.length, 2)
  assert.deepEqual(seen[1], ['user:第一问', 'assistant:ok', 'user:第二问'])
  assert.equal(sessions.readSession(r1.sessionId).turns.length, 4)
})

test('agent: 中断后 aborted=true，部分文本照样落盘', async () => {
  const p = fake({ script: { __default: 'slow' } })
  const agent = createAgent({ providers: registry([p]) })
  const ac = new AbortController()
  const events = []
  const pending = agent.runTurn({ providerId: 'fake', message: '慢慢来', signal: ac.signal, onEvent: (e) => events.push(e) })
  setTimeout(() => ac.abort(), 60)
  const r = await pending
  track(r.sessionId)
  assert.equal(r.aborted, true)
  assert.ok(r.text.length > 0 && r.text.length < 4, `部分文本应为 1~3 字，实际 ${JSON.stringify(r.text)}`)
  assert.ok(events.some((e) => e.type === 'aborted'))
  assert.equal(sessions.readSession(r.sessionId).turns[1].aborted, true)
})

test('agent: 取消前的 signal 直接短路，不产生任何请求', async () => {
  let called = 0
  const p = fake({ script: { __default: 'x' } })
  const spy = { ...p, async *chat(args) { called += 1; yield* p.chat(args) } }
  const agent = createAgent({ providers: registry([spy]) })
  const ac = new AbortController()
  ac.abort()
  const r = await agent.runTurn({ providerId: 'fake', message: 'q', signal: ac.signal })
  track(r.sessionId)
  assert.equal(called, 0)
  assert.equal(r.aborted, true)
})

test('agent: 未知 provider 直接抛 E_NO_PROVIDER', async () => {
  const agent = createAgent({ providers: registry([fake()]) })
  await assert.rejects(() => agent.runTurn({ providerId: 'nope', message: 'q' }), (e) => e.code === 'E_NO_PROVIDER')
})

// ---------------------------------------------------------------------------
// 降级
// ---------------------------------------------------------------------------

test('agent: reasoner 连续失败达阈值 → 明示降级并同轮改走 deepseek-chat', async () => {
  const p = fake({ script: { 'deepseek-reasoner': 'fail', 'deepseek-chat': '降级后的答案' } })
  const agent = createAgent({ providers: registry([p]), degradeAfter: 3 })

  const r1 = await agent.runTurn({ providerId: 'fake', model: 'deepseek-reasoner', message: '1' })
  const r2 = await agent.runTurn({ providerId: 'fake', model: 'deepseek-reasoner', message: '2' })
  track(r1.sessionId)
  track(r2.sessionId)
  assert.equal(r1.degraded, false)
  assert.equal(r1.error.code, 'E_RATE_LIMITED', '阈值内只如实报错')
  assert.equal(r2.degraded, false)
  assert.equal(r2.notices[0].code, 'E_REASONER_FAIL')
  assert.match(r2.notices[0].message, /2\/3/)

  const events = []
  const r3 = await agent.runTurn({ providerId: 'fake', model: 'deepseek-reasoner', message: '3', onEvent: (e) => events.push(e) })
  track(r3.sessionId)
  assert.equal(r3.degraded, true)
  assert.equal(r3.model, DEGRADE_FALLBACK_MODEL)
  assert.equal(r3.text, '降级后的答案')
  assert.equal(r3.error, null)

  const degrade = events.find((e) => e.type === 'degrade')
  assert.ok(degrade, '必须发出 degrade 事件，不得静默')
  assert.equal(degrade.from, 'deepseek-reasoner')
  assert.equal(degrade.to, DEGRADE_FALLBACK_MODEL)
  assert.equal(degrade.message, degradeMessage(degrade.reason))

  // notice 必须落盘（事后可追溯）
  const persisted = sessions.readSession(r3.sessionId)
  assert.ok(persisted.notices.some((n) => n.code === 'E_DEGRADED'))
  assert.equal(persisted.turns[1].degraded, true)
  assert.equal(persisted.turns[1].model, DEGRADE_FALLBACK_MODEL)
})

test('agent: 降级态对后续轮次和后续会话都生效', async () => {
  const p = fake({ script: { 'deepseek-reasoner': 'fail', 'deepseek-chat': 'chat 兜底' } })
  const agent = createAgent({ providers: registry([p]), degradeAfter: 1 })
  const r1 = await agent.runTurn({ providerId: 'fake', model: 'deepseek-reasoner', message: 'a' })
  track(r1.sessionId)
  assert.equal(r1.degraded, true)
  const r2 = await agent.runTurn({ providerId: 'fake', model: 'deepseek-reasoner', message: 'b' })
  track(r2.sessionId)
  assert.equal(r2.degraded, true)
  assert.equal(r2.model, 'deepseek-chat')
  assert.equal(r2.text, 'chat 兜底')
})

test('agent: 成功一次即清零失败计数（阈值判断是"连续"失败）', async () => {
  let mode = 'fail'
  const provider = {
    id: 'fake',
    name: 'fake',
    kind: 'fake',
    defaultModel: 'deepseek-chat',
    describe: () => ({ id: 'fake', name: 'fake', kind: 'fake', defaultModel: 'deepseek-chat', models: ['deepseek-chat', 'deepseek-reasoner'] }),
    describeConfig: () => ({ ready: true, models: ['deepseek-chat', 'deepseek-reasoner'] }),
    hasModel: () => true,
    async listModels() {
      return []
    },
    async *chat(args) {
      if (mode === 'fail') {
        yield { type: EVENT.ERROR, code: 'E_TIMEOUT', retryable: true, message: 'boom', provider: 'fake', model: args.model }
        return
      }
      yield { type: EVENT.DELTA, text: 'ok', channel: 'content' }
      yield { type: EVENT.DONE, text: 'ok', provider: 'fake', model: args.model }
    },
  }
  const agent = createAgent({ providers: registry([provider]), degradeAfter: 2 })
  const r1 = await agent.runTurn({ providerId: 'fake', model: 'deepseek-reasoner', message: '1' })
  track(r1.sessionId)
  assert.equal(agent.degrade.get('fake').failures, 1)
  mode = 'ok'
  const r2 = await agent.runTurn({ providerId: 'fake', model: 'deepseek-reasoner', message: '2' })
  track(r2.sessionId)
  assert.equal(r2.error, null)
  assert.equal(agent.degrade.get('fake').failures, 0)
})

test('agent: 不可重试的鉴权错误不触发降级（降级只针对限流/超时/5xx 一类）', async () => {
  assert.equal(isReasonerFailure({ type: EVENT.ERROR, code: 'E_AUTH', retryable: false }), false)
  assert.equal(isReasonerFailure({ type: EVENT.ERROR, code: 'E_RATE_LIMITED', retryable: true }), true)
  assert.equal(isReasonerFailure({ type: EVENT.ERROR, code: 'E_ABORTED', aborted: true, retryable: false }), false)

  const p = fake({ script: { 'deepseek-reasoner': 'auth' } })
  const agent = createAgent({ providers: registry([p]), degradeAfter: 1 })
  const r = await agent.runTurn({ providerId: 'fake', model: 'deepseek-reasoner', message: 'q' })
  track(r.sessionId)
  assert.equal(r.degraded, false)
  assert.equal(r.error.code, 'E_AUTH')
})

test('DegradeController: 阈值前不降级、到点降级且 newlyDegraded 只报一次', () => {
  const dc = new DegradeController({ threshold: 2 })
  const a = dc.recordFailure('p', { model: 'deepseek-reasoner', reason: 'r1' })
  const b = dc.recordFailure('p', { model: 'deepseek-reasoner', reason: 'r2' })
  const c = dc.recordFailure('p', { model: 'deepseek-reasoner', reason: 'r3' })
  assert.deepEqual([a.degraded, b.degraded, b.newlyDegraded, c.degraded, c.newlyDegraded], [false, true, true, true, false])
  assert.equal(dc.get('p').count, 1, '降级事件只应计一次')
  dc.reset('p')
  assert.equal(dc.get('p').degraded, false)
  assert.equal(dc.get('p').failures, 0)
})

test('DegradeController: 每个 provider 独立计数', () => {
  const dc = new DegradeController({ threshold: 1 })
  dc.recordFailure('a', { reason: 'x' })
  assert.equal(dc.get('a').degraded, true)
  assert.equal(dc.get('b').degraded, false)
  assert.equal(dc.snapshot().length, 2)
})

// ---------------------------------------------------------------------------
// status
// ---------------------------------------------------------------------------

test('agent: status() 汇总 provider / 降级 / 队列', async () => {
  const p = fake()
  const agent = createAgent({ providers: registry([p]) })
  const st = agent.status()
  assert.equal(st.providers.length, 1)
  assert.equal(st.providers[0].id, 'fake')
  assert.equal(st.providers[0].config.ready, true)
  assert.equal(st.queue.reasonerLimitPerMinute, 10)
  assert.equal(st.queue.retried, 0)
  assert.ok(Array.isArray(st.degrade))
})
