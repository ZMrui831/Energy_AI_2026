import { test } from 'node:test'
import assert from 'node:assert/strict'
import { parseAsrStdout } from '../packages/core/src/voice.mjs'

// S67·4-D：Python ASR 子进程输出编码（cp936 → UTF-8）回归

test('V-E1 中文 stdout → 解析出正确中文', () => {
  const buf = Buffer.from('{"ok":true,"text":"今天北京天气晴，适合出门散步","audioSec":6.2}\n', 'utf8')
  const r = parseAsrStdout(buf)
  assert.equal(r.ok, true)
  assert.equal(r.parsed.text, '今天北京天气晴，适合出门散步')
})

test('V-E2 混入进度/警告行时仍能取到 JSON', () => {
  const buf = Buffer.from('loading model...\nprogress 50%\n{"ok":true,"text":"远程会议"}\n', 'utf8')
  const r = parseAsrStdout(buf)
  assert.equal(r.ok, true)
  assert.equal(r.parsed.text, '远程会议')
})

test('V-E3 非 UTF-8 字节序列 → E_VOICE_DECODE（不静默乱码）', () => {
  const buf = Buffer.from([0x80, 0x81, 0xff, 0x7b, 0x7d])
  const r = parseAsrStdout(buf)
  assert.equal(r.ok, false)
  assert.equal(r.code, 'E_VOICE_DECODE')
})

test('V-E4 无 JSON 行 → E_VOICE_NO_JSON', () => {
  const buf = Buffer.from('no json here\nplain text\n', 'utf8')
  const r = parseAsrStdout(buf)
  assert.equal(r.ok, false)
  assert.equal(r.code, 'E_VOICE_NO_JSON')
})
