// tests/timer.test.mjs
//
// 计时引擎离线回归：预设/状态机/计账/跨午夜/崩溃恢复/空闲询问/加速/心跳/设置。
//
// 全部用【虚拟时钟 + 内存 store】：now() 注入，时间跳变不需要真实等待；
// store 用 createMemoryStore（或包一层的计数 store），一个字节都不落盘。

import test from 'node:test'
import assert from 'node:assert/strict'

import {
  HEARTBEAT_MS,
  IDLE_ASK_SEC,
  MAX_MINUTES,
  POMODORO_PRESETS,
  TimerError,
  createTimer,
} from '../packages/core/src/timer.mjs'
import { createMemoryStore, dayKeyOf } from '../packages/core/src/timer-store.mjs'

// 本地时间 2026-01-15 10:00:00 作为基准（跨午夜用例另起 23:59:50 的基准）
const T0 = new Date(2026, 0, 15, 10, 0, 0).getTime()

function makeClock(startMs = T0) {
  const c = { t: startMs }
  c.now = () => c.t
  c.advance = (ms) => {
    c.t += ms
    return c.t
  }
  c.set = (ms) => {
    c.t = ms
    return c.t
  }
  return c
}

/** 包一层计数 store：崩溃恢复"磁盘一个字节都不改"要靠它作证。 */
function countingStore(inner) {
  const writes = { state: 0, settings: 0, day: [] }
  return {
    ...inner,
    writeState(obj) {
      writes.state += 1
      inner.writeState(obj)
    },
    writeSettings(obj) {
      writes.settings += 1
      inner.writeSettings(obj)
    },
    appendDay(k, r) {
      writes.day.push(k)
      inner.appendDay(k, r)
    },
    _writes: writes,
  }
}

function setup({ timeScale = 1, startMs } = {}) {
  const clock = makeClock(startMs)
  const store = countingStore(createMemoryStore())
  const timer = createTimer({ store, now: clock.now, timeScale })
  return { clock, store, timer }
}

/** 当天专注秒数 = 当天 segment.sec 求和（账本的唯一口径）。 */
function focusOf(store, dayKey) {
  return store
    .readDay(dayKey)
    .filter((r) => r.type === 'segment')
    .reduce((s, r) => s + (Number(r.sec) || 0), 0)
}

// ---------------------------------------------------------------------------
// 预设与参数校验
// ---------------------------------------------------------------------------

test('timer: 预设冻结为 15/25/45，上限 180 分钟', () => {
  assert.deepEqual([...POMODORO_PRESETS], [15, 25, 45])
  assert.equal(MAX_MINUTES, 180)
  assert.equal(IDLE_ASK_SEC, 300)
  assert.equal(HEARTBEAT_MS, 30_000)
})

test('timer: 必须注入 store，否则 E_NO_STORE', () => {
  assert.throws(() => createTimer({}), (e) => e instanceof TimerError && e.code === 'E_NO_STORE')
  assert.throws(() => createTimer({ store: {} }), (e) => e.code === 'E_NO_STORE')
})

test('timer: start 记录 mode/plannedSec/sessionId，默认 25 分钟', () => {
  const { clock, timer } = setup()
  const snap = timer.start({})
  assert.equal(snap.status, 'running')
  assert.equal(snap.plannedSec, 1500)
  assert.equal(snap.mode, 'pomodoro-25')
  assert.equal(snap.remainingSec, 1500)
  assert.match(snap.sessionId, /^t-\d{8}-\d{6}-[0-9a-f]{4}$/)
  assert.equal(snap.timeScale, 1)
  assert.equal(snap.dayKey, '2026-01-15')
})

test('timer: 预设与自定义时长分别落 mode', () => {
  const { timer } = setup()
  assert.equal(timer.start({ minutes: 15 }).mode, 'pomodoro-15')
  timer.stop()
  assert.equal(timer.start({ minutes: 45 }).mode, 'pomodoro-45')
  timer.stop()
  const s = timer.start({ minutes: 90 })
  assert.equal(s.mode, 'custom')
  assert.equal(s.plannedSec, 5400)
})

test('timer: 非法时长一律 E_BAD_MINUTES（0 / 181 / 小数 / 非数字 / NaN）', () => {
  const { timer } = setup()
  for (const bad of [0, -5, 181, 1.5, {}, null, NaN, Infinity, 'abc', '']) {
    assert.throws(() => timer.start({ minutes: bad }), (e) => e.code === 'E_BAD_MINUTES', `minutes=${String(bad)} 必须被拒`)
  }
  // 数字字符串是命令行的自然输入（/start 25），Number() 后合法就放行
  assert.equal(timer.start({ minutes: '25' }).plannedSec, 1500)
})

test('timer: 状态机拒绝 —— 运行中/暂停中不能重复开始，空闲时不能暂停/恢复/停止', () => {
  const { timer } = setup()
  timer.start({ minutes: 25 })
  assert.throws(() => timer.start({ minutes: 15 }), (e) => e.code === 'E_TIMER_RUNNING')
  timer.pause()
  assert.throws(() => timer.start({ minutes: 15 }), (e) => e.code === 'E_TIMER_PAUSED')
  assert.throws(() => timer.pause(), (e) => e.code === 'E_TIMER_NOT_RUNNING')
  timer.resume()
  assert.throws(() => timer.resume(), (e) => e.code === 'E_TIMER_NOT_PAUSED')
  timer.stop()
  assert.throws(() => timer.pause(), (e) => e.code === 'E_TIMER_NOT_RUNNING')
  assert.throws(() => timer.resume(), (e) => e.code === 'E_TIMER_NOT_PAUSED')
  assert.throws(() => timer.stop(), (e) => e.code === 'E_TIMER_NOT_RUNNING')
})

// ---------------------------------------------------------------------------
// 暂停 / 恢复 / 停止计账
// ---------------------------------------------------------------------------

test('timer: 暂停落 segment、恢复后续跑、停止收尾，当天专注=Σsegment.sec', () => {
  const { clock, store, timer } = setup()
  timer.start({ minutes: 25 })
  clock.advance(10 * 60_000) // 专注 10 分钟
  const paused = timer.pause()
  assert.equal(paused.status, 'paused')
  assert.equal(paused.accumulatedSec, 600)
  assert.equal(paused.remainingSec, 900)

  clock.advance(5 * 60_000) // 暂停 5 分钟：不计账
  assert.equal(timer.status().accumulatedSec, 600, '暂停期间 accumulatedSec 不增长')

  timer.resume()
  clock.advance(5 * 60_000) // 再专注 5 分钟
  const out = timer.stop()
  assert.equal(out.summary.totalSec, 900)
  assert.equal(out.summary.completed, false)
  assert.equal(out.summary.overrunSec, 0)
  assert.equal(out.summary.reason, 'user')
  assert.equal(out.status, 'idle')

  // 账本口径：两段 segment（pause 600 + final 300）
  const segs = store.readDay('2026-01-15').filter((r) => r.type === 'segment')
  assert.equal(segs.length, 2)
  assert.deepEqual(segs.map((s) => s.kind), ['pause', 'final'])
  assert.equal(focusOf(store, '2026-01-15'), 900)
  assert.equal(segs[0].sec + segs[1].sec, out.summary.totalSec)
})

test('timer: 停止记录 lastStop，随后 status 仍可见', () => {
  const { timer } = setup()
  timer.start({ minutes: 15 })
  timer.stop({ reason: 'user' })
  const snap = timer.status()
  assert.equal(snap.status, 'idle')
  assert.ok(snap.lastStop && snap.lastStop.totalSec === 0)
  assert.equal(snap.lastStop.reason, 'user')
})

test('timer: 提前停止与超时停止都如实反映在 summary', () => {
  const { clock, timer } = setup()
  timer.start({ minutes: 10 })
  clock.advance(3 * 60_000)
  const early = timer.stop()
  assert.equal(early.summary.totalSec, 180)
  assert.equal(early.summary.completed, false)
  assert.equal(early.summary.overrunSec, 0)

  timer.start({ minutes: 10 })
  clock.advance(12 * 60_000) // 超时 2 分钟
  const over = timer.stop()
  assert.equal(over.summary.totalSec, 720)
  assert.equal(over.summary.completed, true)
  assert.equal(over.summary.overrunSec, 120)
})

test('timer: tick 到点自动收尾（justCompleted + reason=completed）', () => {
  const { clock, store, timer } = setup()
  timer.start({ minutes: 15 })
  clock.advance(14 * 60_000 + 59_000)
  let out = timer.tick()
  assert.equal(out.justCompleted, undefined)
  assert.equal(out.status, 'running')
  clock.advance(1_000)
  out = timer.tick()
  assert.equal(out.justCompleted, true)
  assert.equal(out.summary.reason, 'completed')
  assert.equal(out.summary.completed, true)
  assert.equal(out.status, 'idle')
  // 收尾后当天专注恰好 900，且状态回到空闲
  assert.equal(focusOf(store, '2026-01-15'), 900)
  assert.equal(timer.status().status, 'idle')
})

// ---------------------------------------------------------------------------
// 跨午夜切分
// ---------------------------------------------------------------------------

test('timer: 跨午夜自动切分，两天各自计账、dayKey 正确', () => {
  const before = new Date(2026, 0, 15, 23, 59, 50).getTime()
  const { clock, store, timer } = setup({ startMs: before })
  timer.start({ minutes: 25 })
  clock.advance(20_000) // 23:59:50 -> 00:00:10（跨过本地午夜）
  const out = timer.tick()
  assert.equal(out.justMidnight, true)
  assert.equal(out.segmentStartedAt, new Date(2026, 0, 16, 0, 0, 0).getTime())

  clock.advance(5 * 60_000) // 第二天再专注 5 分钟（00:00:10 -> 00:05:10）
  timer.stop()

  const d15 = store.readDay('2026-01-15').filter((r) => r.type === 'segment')
  const d16 = store.readDay('2026-01-16').filter((r) => r.type === 'segment')
  assert.equal(d15.length, 1)
  assert.equal(d15[0].dayKey, '2026-01-15')
  assert.equal(d15[0].sec, 10, '23:59:50 到午夜只有 10 秒')
  assert.equal(d15[0].kind, 'midnight')
  assert.equal(d16.length, 1)
  assert.equal(d16[0].dayKey, '2026-01-16')
  assert.equal(d16[0].sec, 310, '00:00:00 到 00:05:10 共 310 秒')
  assert.equal(d16[0].kind, 'final')
  // 两天之和 = 本次专注总和
  assert.equal(focusOf(store, '2026-01-15') + focusOf(store, '2026-01-16'), 320)
})

test('timer: 暂停跨越午夜也切分（暂停段本身按午夜拆成两半）', () => {
  const before = new Date(2026, 0, 15, 23, 59, 30).getTime()
  const { clock, store, timer } = setup({ startMs: before })
  timer.start({ minutes: 30 })
  clock.advance(45_000) // 23:59:30 -> 00:00:15
  timer.pause() // 暂停段 45 秒被午夜拆开：30s 在前一天、15s 在第二天
  assert.equal(focusOf(store, '2026-01-15'), 30)
  assert.equal(focusOf(store, '2026-01-16'), 15)
  clock.advance(60_000) // 暂停中（不产生新段）
  timer.resume()
  clock.advance(2 * 60_000)
  timer.stop()
  assert.equal(focusOf(store, '2026-01-15'), 30)
  assert.equal(focusOf(store, '2026-01-16'), 135, '15（暂停尾段）+ 120（恢复后）')
})

// ---------------------------------------------------------------------------
// 崩溃恢复
// ---------------------------------------------------------------------------

test('timer: recover 无活动会话时什么都不做', () => {
  const { timer } = setup()
  assert.deepEqual(timer.recover(), { recovered: false, reason: 'no-active-session' })
})

test('timer: recover 按最后一次心跳收尾，心跳后的未知间隔如实报告为 gap', () => {
  const { clock, store, timer } = setup()
  timer.start({ minutes: 25 })
  clock.advance(10 * 60_000)
  timer.tick() // 心跳推进到当前
  const hb = store.readState().heartbeatAt
  assert.equal(hb, T0 + 10 * 60_000)

  // 模拟进程死亡 2 分钟后重启：新引擎、同一个 store
  clock.advance(2 * 60_000)
  const timer2 = createTimer({ store, now: clock.now })
  const out = timer2.recover()
  assert.equal(out.recovered, true)
  assert.equal(out.record.recordedSec, 600, '只记录到心跳为止')
  assert.equal(out.record.gapSec, 120, '心跳后的 2 分钟是 gap，不猜不补')
  assert.equal(out.record.totalSec, 600)
  assert.equal(out.record.remainingSec, 900)
  assert.equal(out.record.status, 'running')

  // 落账与状态
  const segs = store.readDay('2026-01-15').filter((r) => r.type === 'segment')
  assert.equal(segs.length, 1)
  assert.equal(segs[0].kind, 'interrupted')
  assert.equal(segs[0].sec, 600)
  const st = store.readState()
  assert.equal(st.status, 'idle')
  assert.ok(st.lastInterrupted && st.lastInterrupted.gapSec === 120)
  // 快照里能看到上次中断的说明
  assert.ok(timer2.status().lastInterrupted)
  // 恢复后可以正常开新账
  assert.equal(timer2.start({ minutes: 15 }).status, 'running')
})

test('timer: recover 对暂停中的会话只报告 gap，不补记运行段', () => {
  const { clock, store, timer } = setup()
  timer.start({ minutes: 25 })
  clock.advance(6 * 60_000)
  timer.pause()
  clock.advance(3 * 60_000) // 暂停中进程死掉
  const timer2 = createTimer({ store, now: clock.now })
  const out = timer2.recover()
  assert.equal(out.recovered, true)
  assert.equal(out.record.status, 'paused')
  assert.equal(out.record.recordedSec, 0, '暂停态没有运行段可记')
  assert.equal(out.record.gapSec, 180)
  assert.equal(out.record.totalSec, 360)
  assert.equal(focusOf(store, '2026-01-15'), 360, '之前暂停时落的 360 秒不受影响')
})

test('timer: 状态损坏时 recover 不写一个字节，只报 corrupt', () => {
  const inner = createMemoryStore()
  const store = countingStore(inner)
  inner.writeState({
    status: 'running',
    sessionId: 't-20260115-100000-abcd',
    startedAt: 'not-a-timestamp', // 坏字段
    segmentStartedAt: T0,
    heartbeatAt: T0,
    plannedSec: 1500,
    accumulatedSec: 0,
  })
  const timer = createTimer({ store, now: () => T0 + 60_000 })
  const out = timer.recover()
  assert.equal(out.recovered, false)
  assert.equal(out.corrupt, true)
  assert.ok(out.problems.includes('startedAt'))
  assert.equal(store._writes.state, 0, '损坏态绝不写 state.json')
  assert.equal(store._writes.day.length, 0, '损坏态绝不追加 day jsonl')
  // 损坏标记只进内存：status 报得出来，磁盘原样
  const snap = timer.status()
  assert.ok(snap.corrupt && snap.corrupt.problems.includes('startedAt'))
  assert.equal(inner.readState().startedAt, 'not-a-timestamp')
  // 显式开始新计时 = 用户动作，覆盖坏状态并清掉内存标记
  const started = timer.start({ minutes: 15 })
  assert.equal(started.status, 'running')
  assert.equal(timer.status().corrupt, null)
})

test('timer: recover 检出 ts-order 问题（startedAt 晚于心跳超过容忍度）', () => {
  const inner = createMemoryStore()
  inner.writeState({
    status: 'running',
    sessionId: 't-20260115-100000-abcd',
    startedAt: T0 + 10 * 60_000,
    segmentStartedAt: T0 + 10 * 60_000,
    heartbeatAt: T0,
    plannedSec: 1500,
    accumulatedSec: 0,
  })
  const timer = createTimer({ store: inner, now: () => T0 + 11 * 60_000 })
  const out = timer.recover()
  assert.equal(out.corrupt, true)
  assert.ok(out.problems.includes('ts-order'))
})

// ---------------------------------------------------------------------------
// 空闲询问（>5 分钟）：只询问、不静默改写
// ---------------------------------------------------------------------------

test('timer: noteIdle 记下询问起点，重复调用不叠加', () => {
  const { clock, store, timer } = setup()
  timer.start({ minutes: 25 })
  clock.advance(10 * 60_000)
  const first = timer.noteIdle(420)
  assert.ok(first.idlePrompt)
  assert.equal(first.idlePrompt.idleSec, 420)
  const askedAt = first.idlePrompt.askedAt

  clock.advance(60_000)
  const second = timer.noteIdle(480)
  assert.equal(second.idlePrompt.askedAt, askedAt, '已有未决询问时不刷新起点')
  const prompts = store.readDay('2026-01-15').filter((r) => r.type === 'idle.prompt')
  assert.equal(prompts.length, 1, '同一询问只落一行')
  assert.equal(prompts[0].idleSec, 420)
})

test('timer: 非运行态 noteIdle 无操作', () => {
  const { store, timer } = setup()
  assert.equal(timer.noteIdle(400).status, 'idle')
  timer.start({ minutes: 25 })
  timer.pause()
  const snap = timer.noteIdle(400)
  assert.equal(snap.idlePrompt, null)
  assert.equal(store.readDay('2026-01-15').filter((r) => r.type === 'idle.prompt').length, 0)
})

test('timer: resolveIdle 保留 = 不动账；扣除 = 补落 idle-trim 段并前移段起点', () => {
  const { clock, store, timer } = setup()
  timer.start({ minutes: 25 })
  clock.advance(10 * 60_000) // 专注 10 分钟
  timer.noteIdle(400)
  clock.advance(5 * 60_000) // 空闲 5 分钟

  // 扣除：[段起点, 询问起点] 的 600 秒先落账，段起点挪到 now
  const afterCut = timer.resolveIdle({ keep: false })
  assert.equal(afterCut.idlePrompt, null)
  assert.equal(afterCut.accumulatedSec, 600)
  assert.equal(afterCut.segmentStartedAt, T0 + 15 * 60_000)
  const segs = store.readDay('2026-01-15').filter((r) => r.type === 'segment')
  assert.equal(segs.length, 1)
  assert.equal(segs[0].kind, 'idle-trim')
  assert.equal(segs[0].sec, 600)
  const resolve = store.readDay('2026-01-15').find((r) => r.type === 'idle.resolve')
  assert.equal(resolve.keep, false)
  assert.equal(resolve.keptSec, 600)
  assert.equal(resolve.discardSec, 300, '询问后到现在这 5 分钟被剪掉')

  // 剪完继续跑 2 分钟再停止：总账 = 600 + 120，与 Σsegment.sec 一致
  clock.advance(2 * 60_000)
  const out = timer.stop()
  assert.equal(out.summary.totalSec, 720)
  assert.equal(focusOf(store, '2026-01-15'), 720)
})

test('timer: resolveIdle 保留 = 空闲时间照常计为专注', () => {
  const { clock, store, timer } = setup()
  timer.start({ minutes: 25 })
  clock.advance(10 * 60_000)
  timer.noteIdle(400)
  clock.advance(5 * 60_000)
  const afterKeep = timer.resolveIdle({ keep: true })
  assert.equal(afterKeep.idlePrompt, null)
  assert.equal(afterKeep.accumulatedSec, 0, '保留不清累计')
  const resolve = store.readDay('2026-01-15').find((r) => r.type === 'idle.resolve')
  assert.equal(resolve.keep, true)
  // 没有 idle-trim 段：20 分钟（10 专注 + 5 空闲保留 + 5 专注）全算专注
  clock.advance(5 * 60_000)
  const out = timer.stop()
  assert.equal(out.summary.totalSec, 1200)
  assert.equal(focusOf(store, '2026-01-15'), 1200)
  assert.equal(store.readDay('2026-01-15').filter((r) => r.type === 'segment' && r.kind === 'idle-trim').length, 0)
})

test('timer: 没有未决询问时 resolveIdle 无操作', () => {
  const { clock, timer } = setup()
  timer.start({ minutes: 25 })
  clock.advance(60_000)
  const before = timer.status()
  const after = timer.resolveIdle({ keep: false })
  assert.equal(after.accumulatedSec, before.accumulatedSec)
  assert.equal(after.segmentStartedAt, before.segmentStartedAt)
})

// ---------------------------------------------------------------------------
// timeScale 加速路径与真实路径（同一套代码）
// ---------------------------------------------------------------------------

test('timer: timeScale=60 时 15 分钟番茄 15 秒真实时间走完', () => {
  const { clock, store, timer } = setup({ timeScale: 60 })
  const snap = timer.start({ minutes: 15 })
  assert.equal(snap.plannedSec, 900, '计划仍是 900 计时秒')
  clock.advance(5_000)
  const mid = timer.status()
  assert.equal(mid.elapsedSec, 300, '5 真实秒 = 300 计时秒')
  assert.equal(mid.remainingSec, 600)
  clock.advance(10_000) // 累计 15 真实秒 = 900 计时秒
  const out = timer.tick()
  assert.equal(out.justCompleted, true)
  assert.equal(out.summary.totalSec, 900)
  assert.equal(focusOf(store, '2026-01-15'), 900)
})

test('timer: timeScale=1 是真实时长路径（1 分钟番茄 60 秒真实走完）', () => {
  const { clock, timer } = setup({ timeScale: 1 })
  timer.start({ minutes: 1 })
  clock.advance(59_000)
  assert.equal(timer.tick().justCompleted, undefined)
  clock.advance(1_000)
  assert.equal(timer.tick().justCompleted, true)
})

test('timer: timeScale 缩放同样作用于 segment.sec（会计账按计时秒）', () => {
  const { clock, store, timer } = setup({ timeScale: 60 })
  timer.start({ minutes: 15 })
  clock.advance(10_000) // 10 真实秒
  timer.pause()
  const segs = store.readDay('2026-01-15').filter((r) => r.type === 'segment')
  assert.equal(segs[0].sec, 600)
  assert.equal(focusOf(store, '2026-01-15'), 600)
})

test('timer: timeScale 非正数按 1 处理（防呆）', () => {
  const clock = makeClock()
  for (const bad of [0, -1, NaN, '60']) {
    const timer = createTimer({ store: createMemoryStore(), now: clock.now, timeScale: bad })
    assert.equal(timer.status().timeScale, 1, `timeScale=${String(bad)} 必须退回 1`)
  }
})

// ---------------------------------------------------------------------------
// 心跳
// ---------------------------------------------------------------------------

test('timer: 心跳每 30 秒真实时间一次（崩溃恢复的时间边界）', () => {
  const { clock, store, timer } = setup()
  timer.start({ minutes: 25 })
  clock.advance(29_000)
  timer.tick()
  assert.equal(store.readState().heartbeatAt, T0, '29 秒不写心跳')
  clock.advance(2_000) // 31 秒
  timer.tick()
  assert.equal(store.readState().heartbeatAt, T0 + 31_000, '超过 30 秒写心跳')
})

test('timer: 心跳写盘走 audit:false（默认 store 经 safeWrite，不污染 writes.jsonl）', () => {
  // 这条钉的是默认 store 的接线：state.json 用 audit:false，见 timer-store.mjs。
  // 行为上不可直接观测 audit，这里至少确认默认 store 的 writeState 存在且可调用。
  const { timer } = setup()
  assert.equal(typeof timer.status, 'function')
})

// ---------------------------------------------------------------------------
// 设置
// ---------------------------------------------------------------------------

test('timer: 通知开关默认开，setNotifications 落盘并可读回', () => {
  const { store, timer } = setup()
  assert.deepEqual(timer.getSettings(), { notifications: true })
  assert.deepEqual(timer.setNotifications(false), { notifications: false })
  assert.deepEqual(timer.getSettings(), { notifications: false })
  assert.deepEqual(store.readSettings(), { notifications: false })
  assert.equal(timer.status().settings.notifications, false)
  assert.deepEqual(timer.setNotifications(true), { notifications: true })
  assert.equal(timer.status().settings.notifications, true)
})

test('timer: settings 里只有 notifications===false 才关（其它值按开处理）', () => {
  const inner = createMemoryStore()
  inner.writeSettings({ notifications: 0 })
  const timer = createTimer({ store: inner, now: () => T0 })
  assert.equal(timer.getSettings().notifications, true)
})

// ---------------------------------------------------------------------------
// 快照计算与综合对账
// ---------------------------------------------------------------------------

test('timer: remainingSec 随运行实时缩减，快照字段齐全', () => {
  const { clock, timer } = setup()
  timer.start({ minutes: 25, projectId: 'p1', stageId: 's1' })
  clock.advance(60_000)
  const snap = timer.status()
  assert.equal(snap.elapsedSec, 60)
  assert.equal(snap.remainingSec, 1440)
  assert.equal(snap.projectId, 'p1')
  assert.equal(snap.stageId, 's1')
  assert.equal(snap.accumulatedSec, 0)
  // 段起点/开始时间都记了（恢复与对账的依据）
  assert.equal(snap.startedAt, T0)
  assert.equal(snap.segmentStartedAt, T0)
})

test('timer: 综合场景 —— 暂停/恢复/空闲扣除/跨午夜混合后 Σsegment.sec 仍可重算', () => {
  const before = new Date(2026, 0, 15, 23, 57, 0).getTime()
  const { clock, store, timer } = setup({ startMs: before })
  timer.start({ minutes: 30 })
  clock.advance(2 * 60_000) // 23:59:00
  timer.pause() // 段①：120s（前一天）
  clock.advance(90_000) // 暂停中跨午夜
  timer.resume()
  clock.advance(60_000) // 00:01:30
  timer.noteIdle(300)
  clock.advance(60_000) // 空闲 1 分钟
  timer.resolveIdle({ keep: false }) // 段②：60s（后一天）；剪掉 60s
  clock.advance(2 * 60_000)
  const out = timer.stop() // 段③：120s（后一天）

  const total = focusOf(store, '2026-01-15') + focusOf(store, '2026-01-16')
  assert.equal(focusOf(store, '2026-01-15'), 120)
  assert.equal(focusOf(store, '2026-01-16'), 180)
  assert.equal(total, out.summary.totalSec, '收尾总数与账本求和永远一致')
  // 每个 segment 行字段齐全
  for (const dk of ['2026-01-15', '2026-01-16']) {
    for (const seg of store.readDay(dk).filter((r) => r.type === 'segment')) {
      for (const f of ['type', 'ts', 'dayKey', 'from', 'to', 'sec', 'kind', 'sessionId']) {
        assert.ok(seg[f] !== undefined, `segment 缺字段 ${f}`)
      }
      assert.equal(seg.dayKey, dk)
    }
  }
})

test('timer: dayKeyOf 用本地时区（与用户同 calendar）', () => {
  const d = new Date(2026, 0, 15, 23, 59, 59)
  assert.equal(dayKeyOf(d.getTime()), '2026-01-15')
  assert.equal(dayKeyOf(d.getTime() + 1_000), '2026-01-16')
})
