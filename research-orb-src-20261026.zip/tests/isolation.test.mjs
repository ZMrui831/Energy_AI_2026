// tests/isolation.test.mjs
//
// 隔离与硬边界回归测试（依据 SAFETY.md 第 1/2/3/6/7 节、README 三层架构约定）。
// 只读不写：唯一会落盘的是 data/logs/ 下的探针与审计行，全部在项目根内。

import test from 'node:test'
import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { existsSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'

import {
  PROJECT_ROOT,
  LOG_DIR,
  SafeFsError,
  WRITES_LOG,
  assertInsideRoot,
  protectedZoneOf,
  safeWrite,
  logPath,
} from '../packages/core/src/safefs.mjs'

/**
 * 清理测试遗留文件：用"截断"而不是删除。
 * 原因：宿主环境有批量删除保护，删到一定次数会直接抛 SAFE_DELETE_BULK_CONFIRM_REQUIRED，
 * 把与被删文件毫无关系的测试一起带崩（实测：agent.test.mjs 整文件失败）。
 * 测试的本意只是"从这个文件重新开始"，截断即可，顺带少一份误删风险。
 * 多余的实参（如 { force: true }）会被忽略，调用点不必改写。
 */
const truncateFile = (p) => {
  try {
    writeFileSync(p, '')
  } catch {
    /* 文件不存在等情形直接忽略 */
  }
}

// S74c·P0-3：这里原来硬编码仓库绝对路径 —— 把仓库**复制**到别处后，测试仍指向原仓库，
// 于是副本跑出来的是"原仓库的结果"（实测 931/933）。改用 safefs 导出的 PROJECT_ROOT（按模块位置推导）。
const ROOT = PROJECT_ROOT
const DESKTOP = join(ROOT, 'apps', 'desktop')

const RUNTIME_SOURCES = [
  join(DESKTOP, 'main.mjs'),
  join(DESKTOP, 'preload.cjs'),
  join(DESKTOP, 'ui-bridge.mjs'),
  join(ROOT, 'packages', 'core', 'src', 'safefs.mjs'),
  join(ROOT, 'packages', 'core', 'src', 'net.mjs'),
]

const readSource = (p) => readFileSync(p, 'utf8')
const sha256 = (p) => createHash('sha256').update(readFileSync(p)).digest('hex').toUpperCase()

function readJsonl(p) {
  if (!existsSync(p)) return []
  return readFileSync(p, 'utf8')
    .split('\n')
    .filter((l) => l.trim().length > 0)
    .map((l) => JSON.parse(l))
}

// ---------------------------------------------------------------------------
// 1. 唯一可写根
// ---------------------------------------------------------------------------

test(`唯一可写根 = SAFETY.md 声明的 ${ROOT}`, () => {
  assert.equal(PROJECT_ROOT, ROOT)
  assert.equal(assertInsideRoot(join(ROOT, 'data', 'logs')), join(ROOT, 'data', 'logs'))
  assert.ok(WRITES_LOG.startsWith(LOG_DIR))
})

test('safeWrite 在根内可写，且每次写都落 writes.jsonl 审计（ts/path/bytes）', () => {
  const probe = logPath('isolation-probe.jsonl')
  truncateFile(probe, { force: true })

  const result2 = safeWrite(probe, '{"probe":1}\n', { append: true })
  assert.equal(result2.path, probe)
  assert.equal(result2.bytes, 12)
  assert.ok(existsSync(probe))

  const auditLines = readJsonl(WRITES_LOG)
  // 按探针专属路径过滤并取"最后一次"（而非取全文件最后一行）：
  // 1) node --test 按文件并行，其它用例（如 settings 用例写 config.json）也会并发
  //    追加到同一份 writes.jsonl，"最后一行"判定会偶发竞争失败；
  // 2) writes.jsonl 跨多次运行累积，同一探针路径会出现多行，需取最新一条。
  const mine = auditLines.filter((l) => l.path === probe)
  assert.ok(mine.length >= 1, `writes.jsonl 至少应有一条探针审计行（实际 ${mine.length}）`)
  const last = mine[mine.length - 1]
  assert.equal(last.bytes, result2.bytes)
  assert.equal(last.mode, 'append')
  assert.ok(Number.isFinite(Date.parse(last.ts)), 'ts 必须是可解析的 ISO 时间')
  assert.ok(!('protected' in last), '普通路径不应带 protected 标记')

  truncateFile(probe, { force: true })
})

test('safeWrite 拒绝全部硬红线路径（禁写区），且绝不创建目标文件', () => {
  const forbidden = [
    `${process.env.USERPROFILE}\\.dsh\\x.txt`,
    `${process.env.USERPROFILE}\\.dsh\\profiles\\desktop\\node_modules\\dsh-orb\\write-test.txt`,
    'D:\\AI_Workspace\\dsh-orb-cordis\\packages\\helper\\src\\main.ts',
    'D:\\AI_Workspace\\island-desktop\\x.txt',
    'D:\\AI_Workspace\\island\\x.txt',
    'D:\\dsh-orb-project\\ledger\\x.json',
    join(ROOT, '..', 'evil.txt'),
    join(ROOT, '..', 'dsh-orb-project', 'x.json'),
    join(ROOT, 'data', '..', '..', 'dsh-orb-project', 'x.json'),
    '../../evil-relative.txt',
  ]

  for (const target of forbidden) {
    assert.throws(
      () => safeWrite(target, 'must not be written'),
      (err) => {
        assert.ok(err instanceof SafeFsError, `${target} 应抛 SafeFsError`)
        assert.equal(err.code, 'E_OUTSIDE_ROOT', `${target} 应判为越界`)
        return true
      },
      `safeWrite 必须拒绝 ${target}`,
    )
  }

  assert.ok(!existsSync(`${process.env.USERPROFILE}\\.dsh\\x.txt`))
  assert.ok(!existsSync(join(ROOT, '..', 'evil.txt')))
  // 相对越界路径按 safeWrite 的实际解析口径（相对 cwd）复算，避免误判
  assert.ok(!existsSync(resolve('../../evil-relative.txt')), '相对越界路径不得被创建')
})

test('assertInsideRoot 拒绝空路径/非字符串/含空字节路径', () => {
  assert.throws(() => assertInsideRoot(''), (e) => e.code === 'E_BAD_PATH')
  assert.throws(() => assertInsideRoot(undefined), (e) => e.code === 'E_BAD_PATH')
  assert.throws(() => assertInsideRoot(join(ROOT, 'data', 'a\0b')), (e) => e.code === 'E_BAD_PATH')
})

test('vendor 冻结区与快照区是受保护写入区（打标记不静默）', () => {
  assert.equal(protectedZoneOf(join(ROOT, 'vendor', 'orb-base', 'panel', 'floating.html')), 'frozen-vendor-snapshot')
  assert.equal(protectedZoneOf(join(ROOT, 'vendor')), 'frozen-vendor-snapshot')
  assert.equal(protectedZoneOf(join(ROOT, '.snapshots', 'x', 'y')), 'phase-snapshot-archive')
  assert.equal(protectedZoneOf(join(ROOT, 'data', 'logs', 'writes.jsonl')), null)
  assert.equal(protectedZoneOf(join(ROOT, 'apps', 'desktop', 'main.mjs')), null)
})

test('tools/guard-path.mjs: 越界 exit 1，根内 exit 0', () => {
  const guard = join(ROOT, 'tools', 'guard-path.mjs')

  const bad = spawnSync(process.execPath, [guard, `${process.env.USERPROFILE}\\.dsh\\x.txt`], { encoding: 'utf8' })
  assert.equal(bad.status, 1, '越界路径必须 exit 1')
  assert.match(bad.stderr, /拒绝越界写入/)
  assert.match(bad.stderr, /\.dsh/)

  const bad2 = spawnSync(process.execPath, [guard, 'D:\\dsh-orb-project\\x.json'], { encoding: 'utf8' })
  assert.equal(bad2.status, 1)

  const ok = spawnSync(process.execPath, [guard, join(ROOT, 'data', 'logs', 'ok.jsonl')], { encoding: 'utf8' })
  assert.equal(ok.status, 0, '根内路径必须 exit 0')
  assert.match(ok.stdout, /guard-path: OK/)

  const noArgs = spawnSync(process.execPath, [guard], { encoding: 'utf8' })
  assert.equal(noArgs.status, 2, '无参数应 exit 2')
})

// ---------------------------------------------------------------------------
// 2. vendor 冻结快照完整性（证明底座只读复制、一字未改）
// ---------------------------------------------------------------------------

test('vendor/orb-base 与 SOURCE.json 冻结哈希逐字节一致', () => {
  const manifestPath = join(ROOT, 'vendor', 'orb-base', 'SOURCE.json')
  const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'))
  assert.equal(manifest.orbVersion, '0.4.0')
  assert.equal(manifest.files.length, 9, '冻结清单应为 9 个文件')

  for (const entry of manifest.files) {
    const abs = join(ROOT, ...entry.target.split('/'))
    assert.ok(existsSync(abs), `冻结文件缺失: ${entry.target}`)
    assert.equal(sha256(abs), entry.sha256.toUpperCase(), `冻结文件被改动: ${entry.target}`)
    assert.equal(statSync(abs).size, entry.bytes, `冻结文件字节数不符: ${entry.target}`)
  }
})

// ---------------------------------------------------------------------------
// 3. 命名空间隔离（不得复用 dsh-orb / 萌源的 IPC、环境变量、锁）
// ---------------------------------------------------------------------------

// 自有通道：只认 research-orb: 前缀的字面量（node:fs 这类内置 scheme 不属于 IPC 通道）。
const OWN_CHANNEL = /'(research-orb:[a-z0-9-]+)'/g
// 必须为空的"撞名"通道：dsh-orb 的 orb:* 前缀、任何带 dsh 字样的通道。
const FOREIGN_CHANNEL = /'(orb:[a-z0-9-]+|dsh[a-z0-9-]*:[a-z0-9-]+)'/i
const EXPECTED_CHANNELS = [
  'research-orb:drag',
  'research-orb:info',
  'research-orb:main-event',
  // S55·C4 推荐收听：唯一新增通道 —— 渲染层请主进程打开"https + 域名白名单"页面。
  // 主进程侧二次校验（见 main.mjs LISTEN_SITES_DEFAULT / cfg.listenSites），renderer 拼不出任意 URL。
  'research-orb:open-external',
  'research-orb:single-instance',
  'research-orb:ui-event',
  'research-orb:window',
]

test('IPC 通道名全部走 research-orb: 前缀，且不与 orb:/dsh 前缀冲突', () => {
  const found = new Set()
  for (const file of [join(DESKTOP, 'main.mjs'), join(DESKTOP, 'preload.cjs')]) {
    const src = readSource(file)
    for (const m of src.matchAll(OWN_CHANNEL)) found.add(m[1])
    const foreign = src.match(FOREIGN_CHANNEL)
    assert.equal(foreign, null, `${file} 出现与 dsh-orb 撞名的通道 ${foreign && foreign[1]}`)
  }
  assert.deepEqual(
    [...found].sort(),
    EXPECTED_CHANNELS,
    '自有通道集合必须恰好是这 6 个（5 个 IPC 通道 + 1 个单实例标签）',
  )
})

test('主进程确实注册了每个通道的收发端点', () => {
  const main = readSource(join(DESKTOP, 'main.mjs'))
  for (const key of ['info', 'uiEvent', 'window', 'drag']) {
    assert.ok(main.includes(`CH.${key}`), `main.mjs 必须使用通道常量 CH.${key}`)
  }
  assert.ok(/ipcMain\.on\(CH\.info/.test(main), 'info 通道必须注册同步处理')
  assert.ok(/ipcMain\.on\(CH\.uiEvent/.test(main), 'ui-event 通道必须注册处理')
  assert.ok(/ipcMain\.on\(CH\.window/.test(main), 'window 通道必须注册处理')
  assert.ok(/ipcMain\.on\(CH\.drag/.test(main), 'drag 通道必须注册处理')
  assert.ok(main.includes('webContents.send(CH.mainEvent'), '主进程必须通过 main-event 通道回推状态')

  const preload = readSource(join(DESKTOP, 'preload.cjs'))
  assert.ok(/SEND_CHANNELS\s*=\s*Object\.freeze\(\{/.test(preload), 'preload 必须用冻结的动作名白名单')
  assert.ok(preload.includes('ipcRenderer.on(MAIN_CHANNEL'), 'preload 必须订阅主进程事件')
})

test('运行时不读 dsh-orb 的环境变量（DSH_ORB_*）', () => {
  for (const file of RUNTIME_SOURCES) {
    const src = readSource(file)
    assert.ok(!/DSH_ORB_/.test(src), `${file} 不得引用 DSH_ORB_* 环境变量`)
    assert.ok(!/DSH_ORB_ELECTRON_PATH/.test(src), `${file} 必须硬编码 electron 路径，不得借用 dsh-orb 变量`)
    if (/\bprocess\.env\b/.test(src)) {
      for (const m of src.matchAll(/process\.env\.([A-Za-z_][A-Za-z0-9_]*)/g)) {
        // S33·C / S34·P0：ORB_LOG_DIR 与 ORB_DATA_DIR 是任务书批准的隔离变量（其余仍须 RESEARCH_ORB_ 前缀）
        assert.match(m[1], /^(RESEARCH_ORB_|ORB_LOG_DIR$|ORB_DATA_DIR$)/, `${file} 使用的环境变量 ${m[1]} 必须自带 RESEARCH_ORB_ 前缀（ORB_LOG_DIR/ORB_DATA_DIR 为批准例外）`)
      }
    }
  }
})

test('main.mjs 先固化 userData 再抢单实例锁（锁名随之独立）', () => {
  const src = readSource(join(DESKTOP, 'main.mjs'))
  const iUserData = src.indexOf("setPath('userData'")
  const iLock = src.indexOf('requestSingleInstanceLock')
  assert.ok(iUserData > -1, 'main.mjs 必须调用 app.setPath(\'userData\')')
  assert.ok(iLock > -1, 'main.mjs 必须调用 app.requestSingleInstanceLock')
  assert.ok(iUserData < iLock, 'userData 必须先于单实例锁设置，否则会与 dsh-orb 撞锁')

  assert.ok(src.includes("const DATA_DIR = join(ROOT, 'data')"), 'userData 必须指向项目内 data 目录')
  // 阶段 3.1 卫生：Chromium/Electron 的 userData 单独一层 data\.chromium，
  // data\ 顶层只放领域目录；仍在项目内、仍先于单实例锁，锁独立性不变。
  assert.ok(src.includes("const USER_DATA_DIR = join(DATA_DIR, '.chromium')"))
  assert.ok(src.includes("app.setPath('userData', USER_DATA_DIR)"))
  assert.ok(src.includes("'research-orb:single-instance'"), '单实例回调必须带独立命名空间标签')
})

test('preload.cjs 只暴露 send/on/version/paths/openExternal，不暴露 node 原生能力', () => {
  const src = readSource(join(DESKTOP, 'preload.cjs'))
  const exposed = src.match(/exposeInMainWorld\(\s*'researchOrb'\s*,\s*\{([^}]*)\}/)
  assert.ok(exposed, 'preload 必须用 contextBridge.exposeInMainWorld(\'researchOrb\', {...})')

  const keys = exposed[1]
    .split(',')
    .map((k) => k.trim().split(':')[0].trim())
    .filter(Boolean)
  assert.deepEqual(keys.sort(), ['on', 'openExternal', 'paths', 'send', 'version'])

  assert.ok(!/require\(\s*'node:/.test(src), 'preload 不得 require node: 模块')
  assert.ok(!/require\(\s*"(fs|path|child_process|os)"/.test(src), 'preload 不得 require 文件/进程模块')
  assert.ok(!/process\.binding|globalThis\.process\s*=|nodeIntegration/.test(src))
  assert.ok(!/return\s+ipcRenderer\b/.test(src), 'preload 不得把 ipcRenderer 直接抛出')
  assert.ok(!/exposeInMainWorld\([^,]+,\s*ipcRenderer\s*\)/.test(src), 'preload 不得整个暴露 ipcRenderer')
})

// ---------------------------------------------------------------------------
// 4. SAFETY.md 第 3 节：禁止行为（静态扫描兜底）
// ---------------------------------------------------------------------------

test('源码不含 SAFETY.md 第 3 节禁止的行为模式', () => {
  const banned = [
    { re: /\bschtasks\b/i, what: '计划任务' },
    { re: /\bshut\s?down\b/i, what: '关机' },
    { re: /\blogoff\b/i, what: '注销' },
    { re: /taskkill/i, what: '杀进程' },
    { re: /\breg(\.exe)?\b\s+add/i, what: '改注册表' },
    { re: /autoUpdater|electron-updater|setFeedURL/i, what: '自动更新' },
    { re: /\bdsh\s+plugin\s+(add|update)\b/i, what: 'dsh 插件增改' },
    { re: /\bnpm\s+(install|i)\s+(-g|--global)\b/i, what: '全局 npm 安装' },
    { re: /\b(electron|orb|arm64|x64)-[0-9.]+\.zip\b/i, what: '远程下载执行' },
  ]
  const files = [...RUNTIME_SOURCES, join(ROOT, 'tools', 'guard-path.mjs'), join(ROOT, 'tools', 'snapshot.mjs'), join(ROOT, 'start.cmd')]
  for (const file of files) {
    const src = readSource(file)
    for (const { re, what } of banned) {
      assert.ok(!re.test(src), `${file} 命中禁止行为[${what}]：${re}`)
    }
  }
})

test('阶段 0 不触碰密钥来源（secrets.json / ~/.claude）', () => {
  for (const file of RUNTIME_SOURCES) {
    const src = readSource(file)
    assert.ok(!/secrets\.json/.test(src), `${file} 阶段 0 不得读写 secrets.json`)
    assert.ok(!/\.claude/.test(src), `${file} 阶段 0 不得读学校网关凭据`)
  }
})

// ---------------------------------------------------------------------------
// 5. start.cmd 契约
// ---------------------------------------------------------------------------

test('start.cmd 为纯 ASCII，且使用指定 electron.exe 启动', () => {
  const raw = readFileSync(join(ROOT, 'start.cmd'))
  for (let i = 0; i < raw.length; i += 1) {
    assert.ok(raw[i] < 0x80, `start.cmd 第 ${i} 字节非 ASCII（0x${raw[i].toString(16)}）`)
  }
  const src = raw.toString('utf8')
  assert.match(src, /D:\\AI_Workspace\\dsh-orb-electron\\electron\.exe/, '必须使用既有 electron.exe，不得自行下载')
  assert.match(src, /apps\\desktop\\main\.mjs/, '必须启动 apps/desktop/main.mjs')
  assert.match(src, /set\s+"?ELECTRON_RUN_AS_NODE="?/, '必须清空继承来的 ELECTRON_RUN_AS_NODE，否则 GUI 会退化成纯 node')
  assert.ok(!/DSH_ORB_ELECTRON_PATH/.test(src))
  assert.ok(!/npm|install|download|curl|powershell/i.test(src), 'start.cmd 不得包含安装/下载动作')
})
