// tests/shell-metachar.test.mjs
//
// S67·1-A 回归：shell.run 元字符绕过 / 明文禁用首词 / git 子命令降级。
//
// 所有断言走纯函数 classifyCommand()（与 run() 同一条判定链路，零进程派生）。

import test from 'node:test'
import assert from 'node:assert/strict'
import {
  classifyCommand,
  hasShellMetachar,
  isGitAllowed,
  BANNED_FIRST_TOKENS,
  GIT_ALLOWED_SUBS,
} from '../packages/core/src/tools/impl/shell.mjs'

test('metachar: & 命令拼接被拒 E_SHELL_METACHAR', () => {
  const v = classifyCommand('echo hi & del important.txt')
  assert.equal(v.ok, false)
  assert.equal(v.code, 'E_SHELL_METACHAR')
})

test('metachar: | 管道被拒', () => {
  assert.equal(classifyCommand('dir | findstr x').code, 'E_SHELL_METACHAR')
})

test('metachar: 重定向 < > 被拒', () => {
  assert.equal(classifyCommand('echo hi > a.txt').code, 'E_SHELL_METACHAR')
  assert.equal(classifyCommand('sort < a.txt').code, 'E_SHELL_METACHAR')
})

test('metachar: 子shell ( ) 与变量 $ 被拒', () => {
  assert.equal(classifyCommand('echo $(whoami)').code, 'E_SHELL_METACHAR')
  assert.equal(classifyCommand('echo (dir)').code, 'E_SHELL_METACHAR')
})

test('metachar: 换行被拒', () => {
  assert.equal(classifyCommand('echo hi\n del x').code, 'E_SHELL_METACHAR')
  assert.equal(hasShellMetachar('echo hi\r\n del x').code, 'E_SHELL_METACHAR')
})

test('metachar: 白名单命令无元字符仍放行（不过度拒绝）', () => {
  for (const c of ['dir', 'echo hello', 'findstr "x" a.md', 'git status', 'type data\\config.json']) {
    assert.equal(classifyCommand(c).ok, true, c)
  }
})

test('first-token 禁用: 裸 del/rd/rmdir 无参数也拒 E_CMD_BANNED', () => {
  for (const c of ['del foo.txt', 'rd build', 'rmdir x', 'format', 'diskpart', 'takeown /f x', 'icacls x']) {
    const v = classifyCommand(c)
    assert.equal(v.ok, false, c)
    assert.equal(v.code, 'E_CMD_BANNED', c)
    assert.ok(BANNED_FIRST_TOKENS.has(c.split(/\s+/)[0].toLowerCase()), '首词应在 BANNED_FIRST_TOKENS：' + c)
  }
})

test('git 仅放行只读子命令，push/clean/reset/rebase 拒', () => {
  assert.equal(classifyCommand('git push origin main').code, 'E_CMD_BANNED')
  assert.equal(classifyCommand('git clean -f').code, 'E_CMD_BANNED')
  assert.equal(classifyCommand('git reset --hard').code, 'E_CMD_BANNED')
  assert.equal(classifyCommand('git rebase main').code, 'E_CMD_BANNED')
  assert.equal(classifyCommand('git commit -m x').code, 'E_CMD_BANNED')
  assert.equal(isGitAllowed('git status'), true)
  assert.ok(GIT_ALLOWED_SUBS.includes('rev-parse'))
})

test('git 放行: status/diff/log/show/rev-parse/branch --list 通过', () => {
  for (const c of ['git status', 'git diff', 'git log', 'git show HEAD', 'git rev-parse HEAD', 'git branch --list']) {
    const v = classifyCommand(c)
    assert.equal(v.ok, true, c + ' 应放行，实得 ' + JSON.stringify(v))
  }
})
