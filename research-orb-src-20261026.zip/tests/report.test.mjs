// tests/report.test.mjs
//
// 日报 / 周报离线回归（任务书交付 4 的硬规则）：
//   · 【纯模板必生成】没有任何计时记录、没有任何产出、LLM 完全不可用，
//     三件事各自发生或同时发生时，报告文件都必须能生成；
//   · 【LLM 失败回落】润色只是"复盘与建议"一小段：抛错 / 超时（此处以抛错代理）/
//     返回空 / ask 根本不是函数，都只让那一段回落到模板文案，其余部分不受影响；
//   · 报告是派生品：随时可删随时可重建，删掉不影响计时账本（内存 store 作证）。
//
// 全部用内存 store + 手搓的进度对象（或 progress 引擎现场汇总），不落盘。

import test from 'node:test'
import assert from 'node:assert/strict'

import {
  buildDailyReport,
  buildWeeklyReport,
  fmtDuration,
  polishReview,
  renderDailyTemplate,
  renderWeeklyTemplate,
} from '../packages/core/src/report.mjs'
import { createProgress } from '../packages/core/src/progress.mjs'
import { addDays, createMemoryStore, weekMondayOf } from '../packages/core/src/timer-store.mjs'

// 固定一个周三作为"今天"，周报周一日期可推算
const T0 = new Date(2026, 0, 14, 10, 0, 0).getTime() // 2026-01-14 是周三
const DAY = '2026-01-14'
const MONDAY = weekMondayOf(T0) // 2026-01-12

/** 用 progress 引擎现场汇总出日报数据（segment 行是唯一计账口径）。 */
function dayProgress(dayKey, { segments = [], starts = 0, stops = 0, interrupted = 0, cards = [], bib = [] } = {}) {
  const store = createMemoryStore()
  for (const s of segments) {
    store.appendDay(dayKey, { type: 'segment', ts: new Date(T0).toISOString(), sec: s.sec, projectId: s.projectId || null })
  }
  for (let i = 0; i < starts; i += 1) {
    store.appendDay(dayKey, { type: 'start', ts: new Date(T0).toISOString(), sessionId: `s-${i}` })
  }
  for (let i = 0; i < stops; i += 1) {
    store.appendDay(dayKey, { type: 'stop', ts: new Date(T0).toISOString(), sessionId: `s-${i}`, completed: true })
  }
  for (let i = 0; i < interrupted; i += 1) {
    store.appendDay(dayKey, { type: 'interrupted', ts: new Date(T0).toISOString(), sessionId: `s-x${i}` })
  }
  store._setOutputs(dayKey, {
    cards: cards.map((rel) => ({ rel, mtimeMs: T0 })),
    bib: bib.map((rel) => ({ rel, mtimeMs: T0 })),
  })
  const progress = createProgress({ store, now: () => T0 })
  return { store, progress: progress.summarizeDay(dayKey) }
}

/** 空进度对象（没有任何记录、没有任何产出的最裸形态）。 */
function emptyProgress(dayKey = DAY) {
  return dayProgress(dayKey).progress
}

// ---------------------------------------------------------------------------
// fmtDuration 各档
// ---------------------------------------------------------------------------

test('report: fmtDuration 覆盖 0 秒 / 秒 / 分秒 / 分钟 / 小时 / 小时+分钟 / 异常值', () => {
  assert.equal(fmtDuration(0), '0 分钟')
  assert.equal(fmtDuration(45), '45 秒')
  assert.equal(fmtDuration(90), '1 分 30 秒')
  assert.equal(fmtDuration(50 * 60), '50 分钟')
  assert.equal(fmtDuration(3600), '1 小时')
  assert.equal(fmtDuration(3600 + 25 * 60), '1 小时 25 分钟')
  assert.equal(fmtDuration(-5), '0 分钟') // 负值按 0 处理
  assert.equal(fmtDuration(NaN), '0 分钟')
  assert.equal(fmtDuration('abc'), '0 分钟')
  assert.equal(fmtDuration(undefined), '0 分钟')
})

// ---------------------------------------------------------------------------
// 硬规则 1：纯模板必生成
// ---------------------------------------------------------------------------

test('report: 空数据 + 无产出 + LLM 不可用，日报仍然生成且含"暂无记录"文案', async () => {
  const store = createMemoryStore()
  const res = await buildDailyReport({ progress: emptyProgress(), store }) // 不传 ask
  assert.equal(res.polished, false)
  assert.ok(res.path.endsWith(`daily-${DAY}.md`))
  assert.ok(res.markdown.includes(`# 科研日报 · ${DAY}（周三）`))
  assert.ok(res.markdown.includes('（无计时记录）')) // 分项目区
  assert.ok(res.markdown.includes('今日暂无')) // 产出区
  assert.ok(res.markdown.includes('专注时长：**0 分钟**（0 段计账）'))
  assert.ok(res.markdown.includes('AI 复盘未启用或生成失败')) // 复盘段回落模板文案
  // 文件真的写进去了（内存 store 里能读回，且内容与返回值一致）
  assert.equal(store.readReport('daily', DAY), res.markdown)
})

test('report: 三缺一也不影响生成——有计时无产出 / 有产出无计时', async () => {
  // 有计时、无产出
  const a = dayProgress(DAY, { segments: [{ sec: 1500, projectId: null }], starts: 1 })
  const storeA = createMemoryStore()
  const resA = await buildDailyReport({ progress: a.progress, store: storeA })
  assert.ok(resA.markdown.includes('专注时长：**25 分钟**（1 段计账）'))
  assert.ok(resA.markdown.includes('新增研究卡片：今日暂无'))

  // 有产出、无计时
  const b = dayProgress(DAY, { cards: ['data/notes/a.md', 'data/notes/b.md'], bib: ['data/exports/r.bib'] })
  const storeB = createMemoryStore()
  const resB = await buildDailyReport({ progress: b.progress, store: storeB })
  assert.ok(resB.markdown.includes('（无计时记录）'))
  assert.ok(resB.markdown.includes('新增研究卡片：2'))
  assert.ok(resB.markdown.includes('`data/notes/a.md`'))
  assert.ok(resB.markdown.includes('新增引用导出：1'))
  assert.ok(resB.markdown.includes('`data/exports/r.bib`'))
})

test('report: 周报纯模板对空周也生成完整 7 天明细表', async () => {
  const store = createMemoryStore()
  const progress = createProgress({ store, now: () => T0 })
  const week = progress.summarizeWeek(MONDAY)
  const res = await buildWeeklyReport({ week, store })
  assert.equal(res.polished, false)
  assert.ok(res.path.endsWith(`weekly-${MONDAY}.md`))
  assert.ok(res.markdown.includes(`# 科研周报 · ${MONDAY} ~ ${addDays(MONDAY, 6)}`))
  // 表头 + 恰好 7 行数据行
  assert.ok(res.markdown.includes('| 日期 | 星期 | 专注 | 会话 | 完成 | 新增卡片 | 新增 bib |'))
  const rows = res.markdown.split('\n').filter((l) => l.startsWith(`| ${MONDAY}`) || /^\| 2026-01-1[3-9] \|/.test(l))
  assert.equal(rows.length, 7)
  for (const row of rows) {
    assert.ok(/^\| \d{4}-\d{2}-\d{2} \| 周[日一二三四五六] \| /.test(row), `明细行格式不对：${row}`)
  }
  assert.ok(res.markdown.includes('（0/7 天有记录）'.replace('0', String(week.activeDays))))
  assert.ok(res.markdown.includes('AI 复盘未启用或生成失败'))
  assert.equal(store.readReport('weekly', MONDAY), res.markdown)
})

// ---------------------------------------------------------------------------
// 硬规则 2：LLM 失败回落（只影响"复盘与建议"一小段）
// ---------------------------------------------------------------------------

const GOOD_REPLY = '今日投入集中在 25 分钟番茄，产出 1 张卡片，节奏匹配，明天继续保持。'

test('report: ask 抛错 -> 回落纯模板，数据部分与落盘不受影响', async () => {
  const { store, progress } = dayProgress(DAY, { segments: [{ sec: 1500 }], starts: 1, stops: 1 })
  const before = renderDailyTemplate(progress)
  const res = await buildDailyReport({
    progress,
    store,
    ask: async () => {
      throw new Error('llm exploded')
    },
  })
  assert.equal(res.polished, false)
  // 只有复盘段是指占位符，其他部分与纯模板逐字节一致
  const expected = before.replace('（AI 复盘未启用或生成失败 —— 以上数据部分不受影响，可稍后用 /today 重试。）', '（AI 复盘未启用或生成失败 —— 以上数据部分不受影响，可稍后用 /today 重试。）')
  assert.equal(res.markdown, expected)
  assert.ok(res.markdown.includes('专注时长：**25 分钟**')) // 数据部分完好
  assert.equal(store.readReport('daily', DAY), res.markdown) // 落盘完好
})

test('report: ask 返回空字符串 / 非字符串 -> 回落纯模板', async () => {
  const { store, progress } = dayProgress(DAY, { segments: [{ sec: 600 }] })
  const res1 = await buildDailyReport({ progress, store, ask: async () => '' })
  assert.equal(res1.polished, false)
  assert.ok(res1.markdown.includes('AI 复盘未启用或生成失败'))

  const res2 = await buildDailyReport({ progress, store, ask: async () => ({ notText: true }) })
  assert.equal(res2.polished, false)
  assert.ok(res2.markdown.includes('AI 复盘未启用或生成失败'))

  const res3 = await buildDailyReport({ progress, store, ask: async () => '   \n  ' }) // 只有空白
  assert.equal(res3.polished, false)
})

test('report: ask 不是函数（null / 字符串）-> 回落纯模板', async () => {
  const { store, progress } = dayProgress(DAY, {})
  const res1 = await buildDailyReport({ progress, store, ask: null })
  assert.equal(res1.polished, false)
  const res2 = await buildDailyReport({ progress, store, ask: 'not-a-function' })
  assert.equal(res2.polished, false)
})

test('report: LLM 润色成功 -> 复盘段整段替换，polished=true', async () => {
  const { store, progress } = dayProgress(DAY, { segments: [{ sec: 1500 }], starts: 1 })
  const res = await buildDailyReport({ progress, store, ask: async () => GOOD_REPLY })
  assert.equal(res.polished, true)
  assert.ok(res.markdown.includes(GOOD_REPLY))
  assert.ok(!res.markdown.includes('AI 复盘未启用或生成失败')) // 占位符被换掉
  // 数据部分仍然在
  assert.ok(res.markdown.includes('专注时长：**25 分钟**'))
  assert.ok(res.markdown.includes('## 一、计时总览'))
  assert.equal(store.readReport('daily', DAY), res.markdown)
})

test('report: 周报 LLM 失败也只回落复盘段（逐日数据完好）', async () => {
  const store = createMemoryStore()
  const progress = createProgress({ store, now: () => T0 })
  // 周一 / 周三各记一段
  store.appendDay(MONDAY, { type: 'segment', ts: new Date(T0).toISOString(), sec: 900 })
  store.appendDay(addDays(MONDAY, 2), { type: 'segment', ts: new Date(T0).toISOString(), sec: 1800 })
  const week = progress.summarizeWeek(MONDAY)
  assert.equal(week.focusSec, 2700)

  const res = await buildWeeklyReport({ week, store, ask: async () => { throw new Error('boom') } })
  assert.equal(res.polished, false)
  assert.ok(res.markdown.includes('专注时长：**45 分钟**（2/7 天有记录）'))
  assert.ok(res.markdown.includes('AI 复盘未启用或生成失败'))
  // 明细里周一 15 分钟、周三 30 分钟
  assert.ok(res.markdown.includes(`| ${MONDAY} | 周一 | 15 分钟 |`))
  assert.ok(res.markdown.includes(`| ${addDays(MONDAY, 2)} | 周三 | 30 分钟 |`))

  const res2 = await buildWeeklyReport({ week, store, ask: async () => GOOD_REPLY })
  assert.equal(res2.polished, true)
  assert.ok(res2.markdown.includes(GOOD_REPLY))
})

test('report: polishReview 超长回复按 maxChars 截断（只截复盘段）', async () => {
  const long = '啊'.repeat(1000)
  const r = await polishReview({ kind: 'daily', progress: emptyProgress(), ask: async () => long, maxChars: 100 })
  assert.equal(r.polished, true)
  assert.equal(r.text.length, 101) // 100 + '…'
  assert.ok(r.text.endsWith('…'))
})

// ---------------------------------------------------------------------------
// 模板细节：星期、分项目、会话统计
// ---------------------------------------------------------------------------

test('report: 日报模板含星期、分项目行与会话统计', async () => {
  const { store, progress } = dayProgress(DAY, {
    segments: [
      { sec: 900, projectId: 'p1' },
      { sec: 600, projectId: 'p1' },
      { sec: 300 },
    ],
    starts: 2,
    stops: 1,
    interrupted: 1,
  })
  // 给 p1 一个项目名（项目可能已删 -> 标注）
  store.writeProject({ id: 'p1', name: '构网型逆变器', stages: [], createdAt: new Date(T0).toISOString() })
  const p2 = createProgress({ store, now: () => T0 }).summarizeDay(DAY)
  assert.equal(p2.focusSec, 1800)
  assert.equal(p2.byProject[0].name, '构网型逆变器')
  assert.equal(p2.byProject[0].focusSec, 1500)

  const res = await buildDailyReport({ progress: p2, store })
  assert.ok(res.markdown.includes('- 构网型逆变器：25 分钟'))
  assert.ok(res.markdown.includes('- 未归类：5 分钟'))
  assert.ok(res.markdown.includes('计时会话：2 个（完成 1 · 中断 1）'))
  assert.ok(res.markdown.includes('专注时长：**30 分钟**（3 段计账）'))
})

test('report: 项目已删除时标注而不是崩溃', async () => {
  const { store, progress } = dayProgress(DAY, { segments: [{ sec: 600, projectId: 'ghost' }] })
  const res = await buildDailyReport({ progress, store })
  assert.ok(res.markdown.includes('ghost（项目已删除）'))
})

test('report: 报告是派生品——删掉再建，账本不受影响', async () => {
  const { store, progress } = dayProgress(DAY, { segments: [{ sec: 1200 }] })
  const first = await buildDailyReport({ progress, store })
  assert.ok(store.readReport('daily', DAY))
  // 模拟删除（内存 store 没有 unlink，用写 null 之外的方式：直接换新 store 再建）
  const store2 = createMemoryStore()
  const second = await buildDailyReport({ progress, store: store2 })
  // 同一进度对象 -> 两份报告内容一致（随时可重建）
  assert.equal(second.markdown, first.markdown)
  // 账本（day jsonl）一行未动
  assert.equal(store.readDay(DAY).length, 1)
  assert.equal(store.readDay(DAY)[0].sec, 1200)
})

test('report: weekdayOf 已知日期（周三/周一/周日）', async () => {
  const { store, progress } = dayProgress(DAY, {})
  assert.ok(renderDailyTemplate(progress).includes('（周三）'))
  const mon = createProgress({ store: createMemoryStore(), now: () => new Date(2026, 0, 12).getTime() }).summarizeWeek(MONDAY)
  assert.ok(renderWeeklyTemplate(mon).includes('## 二、每日明细'))
  // 周一那行必须是周一
  assert.ok(mon.days[0].dayKey === MONDAY)
})

// ---------------------------------------------------------------------------
// 加速/测试数据单列区（阶段 3.1）
// ---------------------------------------------------------------------------

test('report: 日报单列「测试/加速数据」区，上方专注只含真实会话', async () => {
  const store = createMemoryStore()
  const progress = createProgress({ store, now: () => T0 })
  // 真实会话 scale=1：900s；加速会话 scale=60：3600s（1 分钟番茄 1 秒真实走完的量级）
  store.appendDay(DAY, { type: 'start', ts: new Date(T0).toISOString(), sessionId: 'real-1', timeScale: 1 })
  store.appendDay(DAY, { type: 'segment', ts: new Date(T0).toISOString(), sec: 900, sessionId: 'real-1' })
  store.appendDay(DAY, { type: 'start', ts: new Date(T0).toISOString(), sessionId: 'fast-1', timeScale: 60 })
  store.appendDay(DAY, { type: 'segment', ts: new Date(T0).toISOString(), sec: 3600, sessionId: 'fast-1' })
  const p = progress.summarizeDay(DAY)
  const md = renderDailyTemplate(p)
  assert.ok(md.includes('专注时长：**15 分钟**'), '加速的 3600s 不得计入专注时长')
  assert.ok(md.includes('计时会话：1 个'), '加速会话不得计入会话数')
  assert.ok(md.includes('## 测试 / 加速数据（不计入上方统计）'))
  assert.ok(md.includes('加速会话：1 个（RESEARCH_ORB_TIME_SCALE≠1 时产生，验收/演示用）'))
  assert.ok(md.includes('加速计时：1 小时（1 段计账，已从上方专注时长中排除）'))
  // 落盘路径与纯模板一致（buildDailyReport 照常工作）
  const res = await buildDailyReport({ progress: p, store })
  assert.equal(res.markdown, md)
  assert.ok(store.readReport('daily', DAY).includes('测试 / 加速数据'))
})

test('report: 没有加速会话时日报/周报都不出现「测试/加速数据」段', () => {
  const store = createMemoryStore()
  const progress = createProgress({ store, now: () => T0 })
  store.appendDay(DAY, { type: 'segment', ts: new Date(T0).toISOString(), sec: 900 })
  const md = renderDailyTemplate(progress.summarizeDay(DAY))
  assert.ok(!md.includes('测试 / 加速数据'))
  assert.ok(!md.includes('加速会话'))
  const weekMd = renderWeeklyTemplate(progress.summarizeWeek(MONDAY))
  assert.ok(!weekMd.includes('测试 / 加速数据'))
})

test('report: 周报同样单列加速区（逐日 scaled 汇总）', () => {
  const store = createMemoryStore()
  const progress = createProgress({ store, now: () => T0 })
  store.appendDay(DAY, { type: 'start', ts: new Date(T0).toISOString(), sessionId: 'real-1', timeScale: 1 })
  store.appendDay(DAY, { type: 'segment', ts: new Date(T0).toISOString(), sec: 900, sessionId: 'real-1' })
  store.appendDay(DAY, { type: 'start', ts: new Date(T0).toISOString(), sessionId: 'fast-1', timeScale: 60 })
  store.appendDay(DAY, { type: 'segment', ts: new Date(T0).toISOString(), sec: 5400, sessionId: 'fast-1' })
  const week = progress.summarizeWeek(MONDAY)
  const md = renderWeeklyTemplate(week)
  assert.ok(md.includes('专注时长：**15 分钟**（1/7 天有记录）'))
  assert.ok(md.includes('## 测试 / 加速数据（不计入上方统计）'))
  assert.ok(md.includes('加速计时：1 小时 30 分钟（1 段计账，已从上方专注时长中排除）'))
})

test('report: 日报分项目带阶段细分（时间归到 项目 / 阶段）', () => {
  const store = createMemoryStore()
  const progress = createProgress({ store, now: () => T0 })
  const p = progress.projects.create({ name: '电网构网型逆变器惯量支撑' })
  progress.projects.addStage(p.id, { name: '文献综述' })
  store.appendDay(DAY, { type: 'segment', ts: new Date(T0).toISOString(), sec: 900, projectId: p.id, stageId: 's1' })
  store.appendDay(DAY, { type: 'segment', ts: new Date(T0).toISOString(), sec: 300, projectId: p.id, stageId: 's1', kind: 'final' })
  const md = renderDailyTemplate(progress.summarizeDay(DAY))
  assert.ok(md.includes('- 电网构网型逆变器惯量支撑：20 分钟'))
  assert.ok(md.includes('  - 文献综述：20 分钟'), '阶段细分必须以子行出现在分项目下')
})
