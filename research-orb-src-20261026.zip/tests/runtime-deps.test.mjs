import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync, existsSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createRequire } from 'node:module'

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(import.meta.url)
const EXPECTED = ['@citation-js/core', '@citation-js/plugin-bibtex', '@orama/orama', 'docx', 'gray-matter', 'unpdf']

// S67·4-C：运行时依赖"锁定并随包提供"的可验证性

test('D-E1 6 个运行时依赖均可 import()', async () => {
  const fail = []
  for (const d of EXPECTED) {
    try { await import(d) } catch (e) { fail.push(d + ':' + (e && e.code)) }
  }
  assert.deepEqual(fail, [], '不可加载：' + fail.join(', '))
})

test('D-E2 package.json dependencies 覆盖 6 个依赖', () => {
  const pkg = JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8'))
  const deps = Object.keys(pkg.dependencies || {})
  for (const d of EXPECTED) assert.ok(deps.includes(d), 'package.json 缺 ' + d)
})

test('D-E3 node_modules 随包存在（护栏前提）', () => {
  assert.ok(existsSync(join(ROOT, 'node_modules')), 'node_modules 不存在')
})
