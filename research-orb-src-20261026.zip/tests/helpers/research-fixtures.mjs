// tests/helpers/research-fixtures.mjs
//
// 阶段 2 的离线测试夹具。
//
// 两个核心物件：
//   1) makeMemoryScope() —— 与宿主 ctx.fs.scope(...) **同接口**的内存实现。
//      为什么不用真的宿主观：真 scope 会把测试数据写进项目的 data/ 目录，
//      跑几次测试就在 data/notes 里留一堆垃圾卡片，而且测试之间互相污染。
//      路径夹逼/授权那部分由 tests/plugins.test.mjs 用真宿主单独钉（那是宿主的职责，
//      不是插件的职责）——插件这边只需要一个"行为一致"的落盘目标。
//   2) makeStubNet() —— 拦在 net.request 层的桩。连接器拿到的永远是"像 net 的东西"，
//      于是"连接器必须走 net"这件事在测试里被顺带证伪/证实：如果哪个连接器偷偷用全局 fetch，
//      这个桩就不会被调用，断言 calls 长度时立刻暴露。

const ALLOWED = ['export.arxiv.org', 'api.openalex.org', 'api.crossref.org', 'api.semanticscholar.org']

function normPath(p) {
  return String(p ?? '')
    .replace(/\\/g, '/')
    .replace(/^\/+|\/+$/g, '')
}

/** 与宿主 scoped fs 同接口的内存实现。 */
export function makeMemoryScope(name = 'mem') {
  const files = new Map()
  const writes = []

  const scope = {
    name,
    root: `<memory:${name}>`,
    path: (p) => `<memory:${name}>/${normPath(p)}`,
    exists: (p) => files.has(normPath(p)),
    read: (p) => {
      const k = normPath(p)
      if (!files.has(k)) {
        const err = new Error(`E_PLUGIN_FS_NOT_FOUND -> ${k}`)
        err.code = 'E_PLUGIN_FS_NOT_FOUND'
        throw err
      }
      return files.get(k)
    },
    readJson: (p) => JSON.parse(scope.read(p)),
    write: (p, data) => {
      const k = normPath(p)
      const s = typeof data === 'string' ? data : JSON.stringify(data, null, 2)
      files.set(k, s)
      writes.push({ path: k, bytes: Buffer.byteLength(s) })
      return { path: scope.path(k), bytes: Buffer.byteLength(s) }
    },
    append: (p, data) => {
      const k = normPath(p)
      const s = typeof data === 'string' ? data : JSON.stringify(data)
      const prev = files.get(k) || ''
      files.set(k, prev + s)
      writes.push({ path: k, bytes: Buffer.byteLength(s), append: true })
      return { path: scope.path(k), bytes: Buffer.byteLength(s) }
    },
    writeJson: (p, obj) => scope.write(p, JSON.stringify(obj, null, 2)),
    /** 列出目录下的直接子项，形态与宿主一致：p 非空时返回 "p/子项"。 */
    list: (p = '') => {
      const d = normPath(p)
      const prefix = d ? `${d}/` : ''
      const out = new Set()
      for (const k of files.keys()) {
        if (!k.startsWith(prefix)) continue
        const rest = k.slice(prefix.length)
        if (!rest) continue
        const seg = rest.split('/')[0]
        out.add(d ? `${d}/${seg}` : seg)
      }
      return [...out].sort()
    },
    // 测试用
    _files: files,
    _writes: writes,
    _dump: () => Object.fromEntries(files),
  }
  return scope
}

export function makeMemoryScopes() {
  return {
    notes: makeMemoryScope('notes'),
    pdf: makeMemoryScope('pdf'),
    index: makeMemoryScope('index'),
    exports: makeMemoryScope('exports'),
  }
}

// ---------------------------------------------------------------------------
// 源响应夹具
// ---------------------------------------------------------------------------

const GFM_TITLES = [
  'Grid-Forming Inverter Control for Inertia Support in Low-Inertia Power Systems',
  'Virtual Synchronous Generator Based Inertia Emulation with Grid-Forming Converters',
  'Transient Stability Enhancement of Grid-Forming Inverters under Weak Grid Conditions',
  'Coordinated Inertia Provision of Grid-Forming and Grid-Following Converters',
  'Small-Signal Stability Analysis of Grid-Forming Inverter Dominated Systems',
  'Fast Frequency Response of Grid-Forming Inverters with Virtual Inertia Control',
  'Droop Control Design for Grid-Forming Inverters in Islanded Microgrids',
  'Inertia Estimation and Inertia Support Allocation in Converter-Dominated Grids',
]

const VENUES = [
  'IEEE Transactions on Power Systems',
  'IEEE Transactions on Smart Grid',
  'IEEE Transactions on Power Delivery',
  'Electric Power Systems Research',
  'International Journal of Electrical Power & Energy Systems',
  'Applied Energy',
  'IEEE PES General Meeting',
  'arXiv preprint',
]

const GIVEN = ['Wei', 'Jane', 'Hao', 'Maria', 'Li', 'Andreas', 'Yuki', 'Pavel']
const FAMILY = ['Wang', 'Doe', 'Chen', 'Rossi', 'Zhang', 'Muller', 'Tanaka', 'Novak']

export function fixtureDoi(i) {
  return `10.1109/TPWRS.2024.${1000000 + i * 37}`
}

export function fixtureTitle(i) {
  return GFM_TITLES[i % GFM_TITLES.length]
}

export function fixtureAuthors(i) {
  return [`${GIVEN[i % 8]} ${FAMILY[i % 8]}`, `${GIVEN[(i + 3) % 8]} ${FAMILY[(i + 3) % 8]}`]
}

/** 造一份结构真实的 arXiv Atom feed。 */
export function arxivFeedXml(n = 8) {
  const entries = []
  for (let i = 0; i < n; i += 1) {
    // 第 4 条故意不给 DOI（arXiv 上很常见），用来测"无 DOI 时字段必须是 null 而不是空串"
    const doi = i === 4 ? '' : `      <arxiv:doi>${fixtureDoi(i)}</arxiv:doi>\n`
    const jref = i % 2 === 0 ? '' : `      <arxiv:journal_ref>IEEE Trans. Power Syst. 39 (2024) 1${i}</arxiv:journal_ref>\n`
    entries.push(
      [
        '  <entry>',
        `    <id>http://arxiv.org/abs/2401.0${100 + i}v2</id>`,
        '    <updated>2024-03-0' + ((i % 9) + 1) + 'T00:00:00Z</updated>',
        '    <published>2024-0' + ((i % 9) + 1) + '-1' + ((i % 9) + 1) + 'T00:00:00Z</published>',
        `    <title>${fixtureTitle(i).replace(/&/g, '&amp;')}</title>`,
        `    <summary>  This paper studies grid-forming inverter inertia support. It proposes a virtual
      inertia controller and validates it on a modified IEEE 9-bus test system.  </summary>`,
        ...fixtureAuthors(i).map((a) => `    <author>\n      <name>${a}</name>\n    </author>`),
        '    <link href="http://arxiv.org/abs/2401.0' + (100 + i) + 'v2" rel="alternate" type="text/html"/>',
        '    <link title="pdf" href="http://arxiv.org/pdf/2401.0' + (100 + i) + 'v2" rel="related" type="application/pdf"/>',
        '    <arxiv:primary_category xmlns:arxiv="http://arxiv.org/schemas/atom" term="eess.SY"/>',
        doi + jref + '  </entry>',
      ].join('\n'),
    )
  }
  return [
    '<?xml version="1.0" encoding="UTF-8"?>',
    '<feed xmlns="http://www.w3.org/2005/Atom" xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">',
    '  <title>arXiv Query: search_query=all:"grid-forming inverter"</title>',
    `  <opensearch:totalResults xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">${n * 13}</opensearch:totalResults>`,
    ...entries,
    '</feed>',
  ].join('\n')
}

/** 造一份 OpenAlex works 响应（含 inverted index 摘要）。 */
export function openAlexPayload(n = 8) {
  const results = []
  for (let i = 0; i < n; i += 1) {
    const title = fixtureTitle(i)
    const words = title.split(' ')
    const inverted = {}
    words.forEach((w, idx) => {
      inverted[w] = inverted[w] ? [...inverted[w], idx] : [idx]
    })
    results.push({
      id: `https://openalex.org/W${2000000 + i}`,
      doi: `https://doi.org/${fixtureDoi(i)}`,
      title,
      display_name: title,
      publication_year: 2020 + (i % 5),
      authorships: fixtureAuthors(i).map((name) => ({ author: { display_name: name } })),
      primary_location: { source: { display_name: VENUES[i % VENUES.length] }, landing_page_url: `https://doi.org/${fixtureDoi(i)}` },
      cited_by_count: 12 + i * 37,
      type: 'article',
      open_access: { is_oa: i % 2 === 0, oa_url: i % 2 === 0 ? `https://example.invalid/oa/${i}.pdf` : null },
      best_oa_location: { pdf_url: i % 2 === 0 ? `https://example.invalid/oa/${i}.pdf` : null },
      abstract_inverted_index: inverted,
    })
  }
  return { meta: { count: n * 999 }, results }
}

/** 造一份 Crossref works 响应。 */
export function crossrefPayload(n = 8) {
  const items = []
  for (let i = 0; i < n; i += 1) {
    items.push({
      DOI: fixtureDoi(i),
      title: [fixtureTitle(i)],
      author: fixtureAuthors(i).map((name) => {
        const parts = name.split(' ')
        return { given: parts[0], family: parts[1] }
      }),
      'container-title': [VENUES[(i + 2) % VENUES.length]],
      issued: { 'date-parts': [[2019 + (i % 6), 6, 1]] },
      'is-referenced-by-count': 5 + i * 11,
      URL: `https://doi.org/${fixtureDoi(i)}`,
      abstract: '<jats:p>Grid-forming inverter inertia support with virtual inertia control.</jats:p>',
      type: 'journal-article',
    })
  }
  return { message: { 'total-results': n * 777, items } }
}

/** 造一份 Semantic Scholar 响应（带 TLDR）。 */
export function s2Payload(n = 6) {
  const data = []
  for (let i = 0; i < n; i += 1) {
    data.push({
      paperId: `s2-${i}`,
      title: fixtureTitle(i),
      abstract: 'Grid-forming inverter inertia support with virtual inertia control.',
      year: 2021 + (i % 4),
      venue: VENUES[(i + 1) % VENUES.length],
      authors: fixtureAuthors(i).map((name) => ({ name })),
      externalIds: { DOI: fixtureDoi(i), CorpusId: 1000 + i },
      citationCount: 3 + i * 5,
      openAccessPdf: i % 3 === 0 ? { url: `https://example.invalid/s2/${i}.pdf` } : null,
      tldr: { text: 'Proposes a virtual inertia controller for grid-forming inverters.' },
      url: `https://www.semanticscholar.org/paper/s2-${i}`,
      publicationTypes: ['JournalArticle'],
    })
  }
  return { total: n * 555, data }
}

// ---------------------------------------------------------------------------
// 桩 net
// ---------------------------------------------------------------------------

/**
 * @param {{arxiv?: *, openalex?: *, crossref?: *, s2?: *, fail?: string[], status?: object}} [opts]
 */
export function makeStubNet(opts = {}) {
  const calls = []
  const routes = {
    'export.arxiv.org': () => ({ body: opts.arxiv || arxivFeedXml(), type: 'application/atom+xml' }),
    'api.openalex.org': () => ({ body: JSON.stringify(opts.openalex || openAlexPayload()), type: 'application/json' }),
    'api.crossref.org': () => ({ body: JSON.stringify(opts.crossref || crossrefPayload()), type: 'application/json' }),
    'api.semanticscholar.org': () => ({ body: JSON.stringify(opts.s2 || s2Payload()), type: 'application/json' }),
  }

  const net = {
    calls,
    logFile: '<stub>',
    ALLOWED_DOMAINS: [...ALLOWED],
    hostOf(url) {
      try {
        return new URL(String(url)).host
      } catch {
        return null
      }
    },
    isAllowedUrl(url) {
      const h = net.hostOf(url)
      return !!h && ALLOWED.includes(h)
    },
    async request(url, options = {}) {
      const host = net.hostOf(url)
      calls.push({ url: String(url), host, limitKey: options.limitKey || null, headers: options.headers || {} })
      if (!net.isAllowedUrl(url)) {
        const err = new Error(`E_DOMAIN_NOT_ALLOWED -> ${host}`)
        err.code = 'E_DOMAIN_NOT_ALLOWED'
        throw err
      }
      if (Array.isArray(opts.fail) && opts.fail.includes(host)) {
        return new Response('rate limited', { status: 429 })
      }
      const forced = opts.status && opts.status[host]
      if (forced) return new Response(String(forced.body ?? ''), { status: forced.status })
      const r = routes[host]()
      return new Response(r.body, { status: 200, headers: { 'content-type': r.type } })
    },
  }
  return net
}

/** 造一个最小可用的插件 ctx（fake scopes + stub net）。 */
export function makeFakeCtx({ scopes = makeMemoryScopes(), net = makeStubNet(), llm = null, id = 'research-literature' } = {}) {
  const logs = []
  return {
    id,
    version: '0.6.0',
    name: '文献检索与研究卡片',
    dir: '<memory>',
    capabilities: [],
    permissions: [],
    scopes: Object.keys(scopes),
    log: {
      info: (m) => logs.push(['info', String(m)]),
      warn: (m) => logs.push(['warn', String(m)]),
      error: (m) => logs.push(['error', String(m)]),
      debug: () => {},
    },
    fs: { scope: (name) => (scopes[name] ? scopes[name] : (() => { const e = new Error(`E_SCOPE_NOT_GRANTED -> ${name}`); e.code = 'E_SCOPE_NOT_GRANTED'; throw e })()) },
    net,
    llm,
    ui: { registerCard: () => {}, registerCommand: () => {} },
    state: { get: () => null, set: () => {}, all: () => ({}) },
    _logs: logs,
    _scopes: scopes,
  }
}

export { ALLOWED as STUB_ALLOWED_DOMAINS }
