// tests/helpers/fake-fs.mjs
//
// 内存文件系统（P-R7 工具层测试用）。
// 为什么不用真实磁盘：权限矩阵、快照回滚、读回校验这些用例要能**反复、确定地**跑，
// 落在真实磁盘上会受"文件被占用/杀软/路径长度"影响，还会往 data\ 里丢垃圾。
//
// 支持的 API 与 node:fs 同名子集一致（工具实现只用到这些）：
//   existsSync / statSync / readFileSync / writeFileSync / mkdirSync /
//   rmSync / copyFileSync / renameSync / readdirSync / openSync / readSync / closeSync

const encoder = new TextEncoder()

function normalize(p) {
  return String(p || '').replace(/\//g, '\\').replace(/\\+$/, '')
}

export function createFakeFs(initial = {}) {
  /** path -> { kind:'file'|'dir', data:Buffer, mtime:Date } */
  const nodes = new Map()
  let fds = 0
  const openFd = new Map()

  for (const [p, content] of Object.entries(initial || {})) {
    const key = normalize(p)
    nodes.set(key, { kind: 'file', data: Buffer.from(String(content), 'utf8'), mtime: new Date() })
  }

  const ensureParent = (p) => {
    const k = normalize(p)
    const idx = k.lastIndexOf('\\')
    if (idx > 0) {
      const parent = k.slice(0, idx)
      if (!nodes.has(parent)) nodes.set(parent, { kind: 'dir', data: null, mtime: new Date() })
    }
  }

  const api = {
    _nodes: nodes,
    existsSync: (p) => nodes.has(normalize(p)),
    statSync: (p) => {
      const n = nodes.get(normalize(p))
      if (!n) {
        const err = new Error(`ENOENT: ${p}`)
        err.code = 'ENOENT'
        throw err
      }
      return {
        size: n.kind === 'file' ? n.data.length : 0,
        isFile: () => n.kind === 'file',
        isDirectory: () => n.kind === 'dir',
        mtime: n.mtime,
      }
    },
    readFileSync: (p) => {
      const n = nodes.get(normalize(p))
      if (!n) {
        const err = new Error(`ENOENT: ${p}`)
        err.code = 'ENOENT'
        throw err
      }
      if (n.kind === 'dir') {
        const err = new Error(`EISDIR: ${p}`)
        err.code = 'EISDIR'
        throw err
      }
      return Buffer.from(n.data)
    },
    writeFileSync: (p, data) => {
      const k = normalize(p)
      ensureParent(k)
      nodes.set(k, {
        kind: 'file',
        data: Buffer.isBuffer(data) ? Buffer.from(data) : Buffer.from(String(data), 'utf8'),
        mtime: new Date(),
      })
    },
    mkdirSync: (p) => {
      const k = normalize(p)
      ensureParent(k)
      if (!nodes.has(k)) nodes.set(k, { kind: 'dir', data: null, mtime: new Date() })
    },
    rmSync: (p) => {
      nodes.delete(normalize(p))
    },
    copyFileSync: (from, to) => {
      const n = nodes.get(normalize(from))
      if (!n) {
        const err = new Error(`ENOENT: ${from}`)
        err.code = 'ENOENT'
        throw err
      }
      ensureParent(normalize(to))
      nodes.set(normalize(to), { kind: 'file', data: Buffer.from(n.data), mtime: new Date() })
    },
    renameSync: (from, to) => {
      const n = nodes.get(normalize(from))
      if (!n) {
        const err = new Error(`ENOENT: ${from}`)
        err.code = 'ENOENT'
        throw err
      }
      ensureParent(normalize(to))
      nodes.delete(normalize(from))
      nodes.set(normalize(to), n)
    },
    readdirSync: (p, opts) => {
      const dir = normalize(p)
      const out = []
      for (const [k, n] of nodes) {
        if (k === dir) continue
        const idx = k.lastIndexOf('\\')
        const parent = idx > 0 ? k.slice(0, idx) : ''
        if (parent !== dir) continue
        const name = k.slice(idx + 1)
        if (opts && opts.withFileTypes) {
          out.push({ name, isDirectory: () => n.kind === 'dir', isFile: () => n.kind === 'file' })
        } else {
          out.push(name)
        }
      }
      return out
    },
    openSync: (p) => {
      const n = nodes.get(normalize(p))
      if (!n) {
        const err = new Error(`ENOENT: ${p}`)
        err.code = 'ENOENT'
        throw err
      }
      fds += 1
      openFd.set(fds, n)
      return fds
    },
    readSync: (fd, buf, off, len) => {
      const n = openFd.get(fd)
      if (!n) throw new Error('EBADF')
      n.data.copy(buf, off, 0, Math.min(len, n.data.length))
      return Math.min(len, n.data.length)
    },
    closeSync: (fd) => {
      openFd.delete(fd)
    },
  }
  return api
}

export default { createFakeFs }
