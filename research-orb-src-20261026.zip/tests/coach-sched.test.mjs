// tests/coach-sched.test.mjs —— S25·2A 调度器：三触发源/单例/暂停/自恢复/持久化
import { test, beforeEach, afterEach } from 'node:test'
import assert from 'node:assert/strict'
import { mkdirSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, dataPath } from '../packages/core/src/safefs.mjs'
import { createScheduler } from '../packages/plugins/coach/scheduler.mjs'

const ROOT = dataPath('tmp', 's25-sched-test')
let DIR
let n = 0

beforeEach(() => {
  n += 1
  DIR = `${ROOT}-${n}`
  rmSync(DIR, { recursive: true, force: true })
  mkdirSync(DIR, { recursive: true })
})
afterEach(() => { rmSync(DIR, { recursive: true, force: true }) })

function vclock(start = 1000000) { const s = { t: start }; return { now: () => s.t, advance: (ms) => { s.t += ms } } }

test('sched: interval 到点触发一次；未到不触发', async () => {
  const c = vclock()
  const s = createScheduler({ dir: DIR, now: c.now, overrides: { intervalMs: 1000 } })
  s.start()
  assert.equal(await s.tickInterval(), false, '未到不触发')
  c.advance(1001)
  assert.equal(await s.tickInterval(), true, '到点触发')
  assert.equal(await s.tickInterval(), false, '触发后重新起算，未到不触发')
})

test('sched: pause 后不触发；resume 恢复', async () => {
  const c = vclock()
  const s = createScheduler({ dir: DIR, now: c.now, overrides: { intervalMs: 1000 } })
  s.start()
  s.pause()
  c.advance(2000)
  assert.equal(await s.tickInterval(), false, '暂停不触发')
  const r = await s.feed({ idleMs: 999999 })
  assert.equal(r.length, 0, '暂停时 idle 也不触发')
  s.resume()
  assert.equal(await s.tickInterval(), true, '恢复后到点即触发')
})

test('sched: idle-dwell 边沿触发一次；持续停留不重复', async () => {
  const c = vclock()
  const s = createScheduler({ dir: DIR, now: c.now, overrides: { idleDwellMs: 3000 } })
  s.start()
  assert.equal((await s.feed({ idleMs: 1000 })).length, 0)
  assert.equal((await s.feed({ idleMs: 3500 })).length, 1, '越线瞬间触发一次')
  assert.equal((await s.feed({ idleMs: 5000 })).length, 0, '持续停留不重复')
  assert.equal((await s.feed({ idleMs: 500 })).length, 0, '退回未越线')
  assert.equal((await s.feed({ idleMs: 4000 })).length, 1, '再次越线重新武装触发')
})

test('sched: threshold 娱乐超时触发；24h 冷却内不重复', async () => {
  const c = vclock()
  const s = createScheduler({ dir: DIR, now: c.now, overrides: { entertainmentCapMin: 45, thresholdCooldownMs: 24 * 3600 * 1000 } })
  s.start()
  assert.equal((await s.feed({ entertainmentMin: 10 })).length, 0, '未超阈不触发')
  assert.equal((await s.feed({ entertainmentMin: 50 })).length, 1, '超阈触发')
  c.advance(3600 * 1000) // 1 小时后仍在冷却
  assert.equal((await s.feed({ entertainmentMin: 60 })).length, 0, '冷却内不重复')
  c.advance(25 * 3600 * 1000) // 越过 24h 冷却
  assert.equal((await s.feed({ entertainmentMin: 60 })).length, 1, '冷却后可再触发')
})

test('sched: 单例——存活实例存在时第二实例 E_ALREADY_RUNNING', () => {
  const c = vclock()
  const a = createScheduler({ dir: DIR, now: c.now, isAlive: (pid) => pid === 4321 })
  a.start() // 写入 pid=process.pid… isAlive 探测 4321；先让 a 的 pid 判活成立
  // 直接以同 store 起第二实例：st.pid=process.pid，isAlive 对该 pid 返回 true 模拟存活
  assert.throws(() => createScheduler({ dir: DIR, now: c.now, isAlive: (pid) => pid === process.pid }), (e) => e.code === 'E_ALREADY_RUNNING')
})

test('sched: 崩溃自恢复——store 标记 running 但 pid 已死 → 接管且 lastInterval 保留', async () => {
  const c = vclock()
  const a = createScheduler({ dir: DIR, now: c.now, overrides: { intervalMs: 1000 }, isAlive: () => false })
  a.start()
  c.advance(500)
  await a.tickInterval() // 未到，无触发；lastInterval=启动时刻
  a.stop()               // 模拟退出
  c.advance(600)         // 累计 1100 ≥ 1000：若 lastInterval 丢失会立即误触发
  const b = createScheduler({ dir: DIR, now: c.now, overrides: { intervalMs: 1000 }, isAlive: () => false }) // 崩溃后接管
  b.start()
  assert.equal(await b.tickInterval(), true, '接管后按保留的 lastInterval 判定到点（恰一次）')
  assert.equal(b.state().counters.interval, 1)
})

test('sched: 状态持久化字段齐（running/paused/pid/lastInterval/counters）', () => {
  const c = vclock()
  const s = createScheduler({ dir: DIR, now: c.now })
  s.start(); s.pause()
  const st = s.state()
  for (const k of ['running', 'paused', 'pid', 'lastInterval', 'lastThreshold', 'idleArmed', 'counters']) assert.ok(k in st, `字段 ${k}`)
  assert.ok(existsSync(join(DIR, 'scheduler.json')))
})

import { existsSync } from 'node:fs'
