// tests/memory-inject.test.mjs —— 记忆注入（topK3 / ≤800字 / 词面交集 / 超时降级）
import test from 'node:test'
import assert from 'node:assert/strict'
import { MEMORY_INJECT_LIMITS, buildMemoryContext, buildMemoryContextWithTimeout } from '../packages/core/src/memory-inject.mjs'

const now = Date.parse('2026-10-26T00:00:00Z')
const e = (kind, text, ts = '2026-10-25T00:00:00Z', confidence = 0.9) => ({ id: 'm-' + text, kind, text, ts, confidence })

test('MI-1 空条目 → 空注入', () => {
  const r = buildMemoryContext('论文怎么写', [], { now })
  assert.equal(r.text, '')
  assert.equal(r.chars, 0)
})

test('MI-2 有交集才注入（宁缺勿滥）', () => {
  const r = buildMemoryContext('今天天气如何', [e('blocker', '下垂控制看不懂')], { now })
  assert.equal(r.text, '', '无词面交集不注入')
})

test('MI-3 命中并带类别标注', () => {
  const r = buildMemoryContext('下垂控制那块我还是不懂', [e('blocker', '下垂控制看不懂')], { now })
  assert.ok(r.text.includes('[卡点]'), '应带类别标注：' + r.text)
  assert.ok(r.text.includes('下垂控制'))
  assert.equal(r.used.length, 1)
})

test('MI-4 topK 上限 3（多命中只取 3）', () => {
  const entries = [
    e('goal', '要做微电网综述'), e('preference', '微电网综述别用中文源'),
    e('decision', '微电网综述按 MPC 线做'), e('blocker', '微电网综述卡在需求响应'),
  ]
  const r = buildMemoryContext('微电网综述下一步做什么', entries, { now })
  assert.ok(r.used.length <= 3, 'used=' + r.used.length)
  assert.equal(MEMORY_INJECT_LIMITS.topK, 3)
})

test('MI-5 maxChars 硬上限 800', () => {
  const long = '微电网综述'.repeat(400)
  const r = buildMemoryContext('微电网综述', [e('goal', long)], { now })
  assert.ok(r.chars <= 800, 'chars=' + r.chars)
  assert.equal(MEMORY_INJECT_LIMITS.maxChars, 800)
})

test('MI-6 排序：卡点/偏好优先于普通记录', () => {
  const entries = [e('other', '微电网 随便记一条'), e('blocker', '微电网 卡住了'), e('preference', '微电网 别用中文源')]
  const r = buildMemoryContext('微电网', entries, { now })
  assert.equal(r.used[0].kind === 'blocker' || r.used[0].kind === 'preference', true, '第一条应是 blocker/preference：' + JSON.stringify(r.used))
})

test('MI-7 时间衰减：更近的记忆排更前', () => {
  const old = e('other', '微电网 老记录', '2026-08-01T00:00:00Z')
  const fresh = e('other', '微电网 新记录', '2026-10-25T00:00:00Z')
  const r = buildMemoryContext('微电网', [old, fresh], { now })
  assert.ok(r.used[0].text.includes('新记录'), JSON.stringify(r.used))
})

test('MI-8 超时包装：正常返回不带 timedOut', () => {
  const r = buildMemoryContextWithTimeout('下垂控制', [e('blocker', '下垂控制看不懂')], { now, timeoutMs: 300 })
  assert.equal(r.timedOut, undefined)
  assert.ok(r.chars > 0)
})

test('MI-9 非法输入不抛异常', () => {
  assert.doesNotThrow(() => buildMemoryContext(null, null))
  assert.equal(buildMemoryContext(undefined, [{ text: '' }]).text, '')
})