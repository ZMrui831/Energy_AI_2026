// tests/geom.test.mjs
//
// P-R6.2 任务二：拖动数学回归（≥12 条）。
// 覆盖：dpi 1.0/1.25/1.5、光标左上/右下、多屏负坐标、拖出边界后 mouseup 钳制、
//       异常 bounds 触发复位、拖动期间禁止钳制、点击穿透圆形命中。

import test from 'node:test'
import assert from 'node:assert/strict'

import {
  toPhysical, toDip, displayAt, clampToWorkArea, anchoredBounds,
  dragTarget, createDragSession, assertSaneBounds, isOffscreen, insideCircle,
} from '../packages/core/src/geom.mjs'

const BALL = { width: 96, height: 96 }
const PANEL = { width: 420, height: 620 }
/** 主屏 1920×1080（100%）。 */
const MAIN = { workArea: { x: 0, y: 0, width: 1920, height: 1080 }, scaleFactor: 1 }
/** 副屏在主屏左侧（负坐标），150% 缩放 → workArea 用 DIP 表示。 */
const LEFT = { workArea: { x: -1280, y: 0, width: 1280, height: 720 }, scaleFactor: 1.5 }
const MAIN125 = { workArea: { x: 0, y: 0, width: 1536, height: 824 }, scaleFactor: 1.25 }
const MAIN150 = { workArea: { x: 0, y: 0, width: 1280, height: 720 }, scaleFactor: 1.5 }

test('geom: DIP↔物理像素换算（100%/125%/150%）', () => {
  assert.deepEqual(toPhysical({ x: 100, y: 50 }, 1), { x: 100, y: 50 })
  assert.deepEqual(toPhysical({ x: 100, y: 50 }, 1.25), { x: 125, y: 63 }) // 62.5 → round 63
  assert.deepEqual(toPhysical({ x: 100, y: 50 }, 1.5), { x: 150, y: 75 })
  // 往返误差 ≤ 1 物理像素（非整除时 round 会引入最多 1 物理像素的舍入，浮点比较需放宽）
  const rt = toDip(toPhysical({ x: 33, y: 77 }, 1.5), 1.5)
  assert.ok(Math.abs(rt.x - 33) <= 1 / 1.5 && Math.abs(rt.y - 77) <= 0.5 / 1.5)
})

test('geom: displayAt 命中含负坐标的副屏', () => {
  assert.equal(displayAt({ x: -100, y: 300 }, [LEFT, MAIN]), LEFT)
  assert.equal(displayAt({ x: 500, y: 300 }, [LEFT, MAIN]), MAIN)
  assert.equal(displayAt({ x: 99999, y: 99999 }, [LEFT, MAIN]), LEFT) // 越界回落第一个
})

test('geom: clampToWorkArea 在 100% 下钳回右下角', () => {
  const r = clampToWorkArea({ x: 5000, y: 5000, ...BALL }, MAIN, { x: 5000, y: 5000 })
  assert.equal(r.x, 1920 - 16 - 96)
  assert.equal(r.y, 1080 - 16 - 96)
})

test('geom: clampToWorkArea 在 125%/150% 缩放下不越界（DIP 全程）', () => {
  for (const [name, d] of [['125%', MAIN125], ['150%', MAIN150]]) {
    const r = clampToWorkArea({ x: 9999, y: 9999, ...BALL }, d, { x: 9999, y: 9999 })
    assert.ok(r.x + r.width <= d.workArea.width, `${name} 右缘越界`)
    assert.ok(r.y + r.height <= d.workArea.height, `${name} 下缘越界`)
    assert.ok(r.x >= d.workArea.x && r.y >= d.workArea.y, `${name} 左/上缘越界`)
  }
})

test('geom: anchoredBounds 落在右下角且含 EDGE_MARGIN', () => {
  const r = anchoredBounds(BALL, MAIN)
  assert.equal(r.x, 1920 - 16 - 96)
  assert.equal(r.y, 1080 - 16 - 96)
  const p = anchoredBounds(PANEL, MAIN)
  assert.equal(p.x, 1920 - 16 - 420)
  assert.equal(p.y, 1080 - 16 - 620)
})

test('geom: 拖动 1:1 跟手 —— 光标向右下移 200,100 → 窗口同样位移（不反向）', () => {
  const startCursor = { x: 1000, y: 900 }
  const startBounds = { x: 800, y: 700, ...BALL }
  const t = dragTarget(startCursor, startBounds, { x: 1200, y: 1000 })
  assert.deepEqual(t, { x: 1000, y: 800, width: 96, height: 96 })
})

test('geom: 拖动 1:1 跟手 —— 光标向左上移（不反向、不放大位移）', () => {
  const t = dragTarget({ x: 1000, y: 900 }, { x: 800, y: 700, ...BALL }, { x: 600, y: 500 })
  assert.deepEqual(t, { x: 400, y: 300, width: 96, height: 96 })
})

test('geom: 150% 缩放下位移仍 1:1（DIP 域内自洽）', () => {
  const startCursor = { x: 400, y: 300 }
  const t = dragTarget(startCursor, { x: 100, y: 100, ...BALL }, { x: 500, y: 350 })
  assert.deepEqual(t, { x: 200, y: 150, width: 96, height: 96 })
})

test('geom: 拖动会话 —— move 期间禁止钳制（可拖出屏幕），end 才钳回', () => {
  const s = createDragSession({ displays: [MAIN] })
  assert.equal(s.begin({ x: 1000, y: 900 }, { x: 800, y: 700, ...BALL }), null)
  // 拖到屏幕外：move 返回未钳制目标
  const mid = s.move({ x: 2400, y: 1600 })
  assert.deepEqual(mid, { x: 2200, y: 1400, width: 96, height: 96 })
  // end 钳回 workArea
  const fin = s.end({ x: 2400, y: 1600 })
  assert.equal(fin.x, 1920 - 16 - 96)
  assert.equal(fin.y, 1080 - 16 - 96)
  assert.equal(s.active, false)
})

test('geom: 拖动会话 —— 光标未动时 move 返回 null（省一次 setBounds）', () => {
  const s = createDragSession({ displays: [MAIN] })
  s.begin({ x: 100, y: 100 }, { x: 50, y: 50, ...BALL })
  assert.equal(s.move({ x: 100, y: 100 }), null)
  assert.equal(s.end({ x: 100, y: 100 }), null) // 未拖动 → 不落界
})

test('geom: 拖动会话 —— 多屏负坐标下 end 钳到副屏 workArea', () => {
  const s = createDragSession({ displays: [LEFT, MAIN] })
  s.begin({ x: -600, y: 300 }, { x: -700, y: 200, ...BALL })
  s.move({ x: -100, y: 700 })
  const fin = s.end({ x: -100, y: 700 })
  // 位移 = -100-(-600)=+500 → 目标 x = -700+500 = -200（仍在 LEFT -1280..0 内）
  assert.equal(fin.x, -200)
  assert.ok(fin.y <= LEFT.workArea.y + LEFT.workArea.height - 16)
  assert.ok(fin.y >= LEFT.workArea.y + 16)
})

test('geom: assertSaneBounds —— 展开态 420×620 合法，超大窗口判异常', () => {
  assert.equal(assertSaneBounds({ x: 0, y: 0, ...PANEL }, PANEL).ok, true)
  assert.equal(assertSaneBounds({ x: 0, y: 0, ...BALL }, PANEL).ok, true)
  const bad = assertSaneBounds({ x: 0, y: 0, width: 1920, height: 1080 }, PANEL)
  assert.equal(bad.ok, false)
  assert.match(bad.reason, /超过面板面积/)
})

test('geom: isOffscreen / 复位 —— 完全在屏幕外的 bounds 判定 + 默认角落复位', () => {
  assert.equal(isOffscreen({ x: -5000, y: -5000, ...BALL }, [MAIN]), true)
  assert.equal(isOffscreen({ x: 100, y: 100, ...BALL }, [MAIN]), false)
  // 复位落点 = anchoredBounds
  const reset = anchoredBounds(BALL, MAIN)
  assert.equal(isOffscreen(reset, [MAIN]), false)
})

test('geom: 点击穿透圆形命中 —— 球心/边缘命中，四角不命中', () => {
  assert.equal(insideCircle({ x: 48, y: 48 }, 96), true)
  assert.equal(insideCircle({ x: 10, y: 48 }, 96), true)
  assert.equal(insideCircle({ x: 2, y: 2 }, 96), false)
  assert.equal(insideCircle({ x: 94, y: 94 }, 96), false)
})

test('geom: 连续拖动多帧 —— 位移线性累积且始终以按下点为基准（防正反馈）', () => {
  const s = createDragSession({ displays: [MAIN] })
  s.begin({ x: 0, y: 0 }, { x: 500, y: 500, ...BALL })
  const a = s.move({ x: 10, y: 10 })
  const b = s.move({ x: 20, y: 20 })
  const c = s.move({ x: 30, y: 30 })
  // 三帧都以按下点为基准：509/510 → 520/520 → 530/530（不是 519→539→569 的累积漂移）
  assert.deepEqual([a.x, b.x, c.x], [510, 520, 530])
  assert.deepEqual([a.y, b.y, c.y], [510, 520, 530])
})
