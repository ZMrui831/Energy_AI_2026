// tests/process-discipline.test.mjs
//
// P-R5 必做 1：进程收尾纪律的**静态**钉死。
// 这些断言读的是源码文本——目的不是测行为，而是让「按进程名批量杀」这类写法
// 一旦被引入就立刻红掉（SAFETY.md §8）。

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync, readdirSync } from 'node:fs'
import { join, resolve } from 'node:path'

import { classifyBrowserProcess, killArgsForPid, assertKillablePid, selfCheckResidue } from '../packages/plugins/research-browser/lib/process-guard.mjs'

const PKG = join(process.cwd(), 'packages', 'plugins', 'research-browser')

/** 递归收集源码文件（.mjs/.json），跳过快照与临时目录。 */
function collectSources(dir, out = []) {
  for (const name of readdirSync(dir, { withFileTypes: true })) {
    if (name.name.startsWith('.')) continue
    const p = join(dir, name.name)
    if (name.isDirectory()) collectSources(p, out)
    else if (/\.(mjs|json)$/.test(name.name)) out.push(p)
  }
  return out
}

const SOURCES = collectSources(PKG).map((p) => ({ path: p, text: readFileSync(p, 'utf8') }))

/**
 * 去掉注释与字符串字面量后再扫描。
 * 必要性：纪律注释里会**故意引用**禁用写法（如"严禁 taskkill /IM msedge.exe"），
 * 若不剥离注释，规则文档本身就会把自己判红。扫描目标必须是**可执行代码**。
 */
function stripCommentsAndStrings(text) {
  let out = ''
  let i = 0
  const n = text.length
  while (i < n) {
    const c = text[i]
    const next = text[i + 1]
    if (c === '/' && next === '/') { // 行注释
      while (i < n && text[i] !== '\n') i += 1
      continue
    }
    if (c === '/' && next === '*') { // 块注释
      i += 2
      while (i < n && !(text[i] === '*' && text[i + 1] === '/')) i += 1
      i += 2
      continue
    }
    if (c === '"' || c === "'" || c === '`') { // 字符串/模板字面量
      const q = c
      i += 1
      while (i < n) {
        if (text[i] === '\\') { i += 2; continue }
        if (text[i] === q) { i += 1; break }
        i += 1
      }
      out += '""'
      continue
    }
    out += c
    i += 1
  }
  return out
}

/** 可执行代码视图（注释与字符串已剥离）。 */
const CODE = SOURCES.map((s) => ({ path: s.path, text: stripCommentsAndStrings(s.text) }))

test('纪律: research-browser 源码中不存在按进程名批量杀（/IM、Stop-Process -Name、Get-Process…|Stop）', () => {
  const banned = [
    { re: /taskkill[^\n]*\/IM/i, why: 'taskkill /IM（按名批量杀）' },
    { re: /Stop-Process[^\n]*-Name/i, why: 'PowerShell Stop-Process -Name' },
    { re: /Get-Process[^\n]*\|\s*Stop\b/i, why: 'Get-Process … | Stop' },
    { re: /\bStop-Process\b[^\n]*-Name/i, why: 'Stop-Process -Name' },
  ]
  for (const { path, text } of CODE) {
    for (const b of banned) {
      assert.equal(b.re.test(text), false, `${path} 命中禁用写法：${b.why}`)
    }
  }
})

test('纪律: 源码中不含 Start-Process / shutdown / logoff 等越界命令', () => {
  const banned = [
    { re: /Start-Process/i, why: 'Start-Process（脱离沙箱的 GUI 启动）' },
    { re: /\bshutdown\b/i, why: 'shutdown' },
    { re: /\blogoff\b/i, why: 'logoff' },
    { re: /\breboot\b/i, why: 'reboot' },
  ]
  for (const { path, text } of CODE) {
    for (const b of banned) {
      assert.equal(b.re.test(text), false, `${path} 命中禁用命令：${b.why}`)
    }
  }
})

test('纪律: killTree 只按 PID 树（/PID /T /F），参数来自 killArgsForPid', () => {
  const cdpRaw = SOURCES.find((s) => s.path.endsWith(join('lib', 'cdp.mjs')))
  const cdp = CODE.find((s) => s.path.endsWith(join('lib', 'cdp.mjs')))
  assert.ok(cdpRaw && cdp, '应存在 lib/cdp.mjs')
  // taskkill 是字符串字面量（在剥离后的代码视图里会变成 ""），故在原始文本上确认其存在；
  // 而参数构造与 /IM 禁令在剥离后的**可执行代码**视图上校验（排除注释里的反例引用）。
  assert.match(cdpRaw.text, /spawn\(\s*['"]taskkill['"]/) // 兜底强杀确实是 spawn 调用
  assert.match(cdp.text, /killArgsForPid\(/) // 参数一律由守卫构造
  assert.equal(/\/IM/.test(cdp.text), false, 'cdp.mjs 可执行代码不得出现 /IM')
})

test('纪律: killArgsForPid 只产出 /PID 树参数', () => {
  assert.deepEqual(killArgsForPid(12345), ['/pid', '12345', '/T', '/F'])
  const args = killArgsForPid(1).join(' ')
  assert.equal(/\/im\b/i.test(args), false, '不得含 /IM')
})

test('纪律: assertKillablePid 拒绝非法 PID', () => {
  assert.equal(assertKillablePid(4321), 4321)
  for (const bad of [0, -1, 1.5, 'abc', null, undefined, NaN]) {
    assert.throws(() => assertKillablePid(bad), /非法 PID/)
  }
})

test('判据: classifyBrowserProcess 只认本项目进程', () => {
  // 我方：命令行含 research-orb / 我们的端口 / 我们的 user-data-dir
  // S74c·P0-3：仓库根按模块位置推导，副本放到别处时这些用例仍针对**副本自身**
  const ROOT = resolve(import.meta.dirname, '..')
  const UDD = join(ROOT, 'data', 'browser-profile')
  assert.equal(classifyBrowserProcess(`"C:\\...\\msedge.exe" --headless=new --user-data-dir=${UDD}`).ours, true)
  assert.equal(classifyBrowserProcess(`msedge.exe --remote-debugging-port=54321 --user-data-dir=${join(ROOT, 'data', 'tmp', 'x')}`, { port: 54321 }).ours, true)
  const uddY = join(ROOT, 'data', 'tmp', 'y')
  assert.equal(classifyBrowserProcess(`msedge.exe --user-data-dir=${uddY}`, { userDataDir: uddY }).ours, true)

  // 用户自己的浏览器 / WebView2：不得判为 ours
  const userEdge = '"C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe" --profile-directory="Default"'
  const webview = `"C:\\...\\msedgewebview2.exe" --embedded-browser-webview=1 --user-data-dir=${process.env.USERPROFILE}\\AppData\\Local\\...`
  assert.equal(classifyBrowserProcess(userEdge).ours, false)
  assert.equal(classifyBrowserProcess(userEdge, { port: 54321 }).ours, false)
  assert.equal(classifyBrowserProcess(webview).ours, false)
  assert.equal(classifyBrowserProcess('').ours, false)
  assert.equal(classifyBrowserProcess(null).ours, false)
})

test('自检: selfCheckResidue 只读返回结构正确（不做任何删除）', async () => {
  const r = await selfCheckResidue()
  assert.equal(typeof r.total, 'number')
  assert.equal(typeof r.edgeTotal, 'number')
  assert.ok(Array.isArray(r.ours))
  for (const o of r.ours) {
    assert.equal(typeof o.pid, 'number')
    assert.equal(typeof o.name, 'string')
    assert.equal(typeof o.reason, 'string')
  }
})