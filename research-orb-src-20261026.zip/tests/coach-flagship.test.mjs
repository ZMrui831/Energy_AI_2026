// tests/coach-flagship.test.mjs —— S27·问题1 根因固化：旗舰鉴权对象解析 + URL 分流
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { resolveAuth, makeInvoke } from '../packages/plugins/coach/index.mjs'

test('flagship: resolveAuth 对对象引用取 apiKey（S27 401 根因：曾拼成 [object Object]）', () => {
  const k = resolveAuth('secrets:deepseek')
  assert.equal(typeof k, 'string')
  assert.ok(k && k.length >= 20 && !/object/.test(k), '应是 apiKey 字符串而非对象序列化')
})

test('flagship: resolveAuth 对字符串引用原样返回；未知引用返回 null', () => {
  const k = resolveAuth('claude-settings:ANTHROPIC_AUTH_TOKEN')
  assert.equal(typeof k, 'string')
  assert.equal(resolveAuth('nope:nothing'), null)
})

test('flagship: makeInvoke 旗舰档 → api.deepseek.com 官方 API 且 Bearer 是真实密钥', async () => {
  const captured = { url: '', auth: '' }
  const origFetch = globalThis.fetch
  globalThis.fetch = async (url, init) => {
    captured.url = String(url)
    captured.auth = String((init && init.headers && init.headers.Authorization) || '')
    return { ok: true, status: 200, json: async () => ({ choices: [{ message: { content: 'ok' } }], usage: { total_tokens: 7 } }) }
  }
  try {
    const invoke = makeInvoke({ net: null })
    const r = await invoke({ tier: 'flagship', provider: { providerId: 'deepseek-api', model: 'deepseek-chat', authRef: 'secrets:deepseek' }, payload: { prompt: 'x' } })
    assert.equal(r.text, 'ok')
    assert.equal(r.tokens, 7)
    assert.equal(captured.url, 'https://api.deepseek.com/chat/completions', '旗舰必须走官方 API（S27 修复：曾被误判到网关）')
    assert.ok(captured.auth.startsWith('Bearer ') && captured.auth.length > 10 && !/object/.test(captured.auth), 'Bearer 必须是真实密钥')
  } finally {
    globalThis.fetch = origFetch
  }
})

test('flagship: makeInvoke cheap 档 → 网关 /api/v1（不变）', async () => {
  const captured = { url: '' }
  const origFetch = globalThis.fetch
  globalThis.fetch = async (url) => {
    captured.url = String(url)
    return { ok: true, status: 200, json: async () => ({ choices: [{ message: { content: 'ok' } }] }) }
  }
  try {
    const invoke = makeInvoke({ net: null })
    await invoke({ tier: 'cheap', provider: { providerId: 'school-gateway', model: 'qwen', baseUrlRef: 'claude-settings:ANTHROPIC_BASE_URL', authRef: 'claude-settings:ANTHROPIC_AUTH_TOKEN' }, payload: { prompt: 'x' } })
    assert.match(captured.url, /^https:\/\/models\.sjtu\.edu\.cn\/api\/v1\/chat\/completions$/)
  } finally {
    globalThis.fetch = origFetch
  }
})
