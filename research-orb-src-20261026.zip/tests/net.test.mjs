// tests/net.test.mjs
//
// 受控出网回归测试（依据 SAFETY.md 第 5 节、docs/DOMAIN-smart-energy.md 文献源优先级）。
// 全部离线：fetchImpl / now / sleep 均为注入桩，虚拟时钟把 62 秒退避压到毫秒级。

import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { PROJECT_ROOT, logPath } from '../packages/core/src/safefs.mjs'

import {
  ALLOWED_DOMAINS,
  BACKOFF_MS,
  DEFAULT_NET_LOG,
  NetError,
  REASONER_MODEL,
  SlidingWindowLimiter,
  TokenBucket,
  createNet,
  hostOf,
  isAllowedUrl,
  maskSecret,
  redactUrl,
} from '../packages/core/src/net.mjs'

/**
 * 清理测试遗留文件：用"截断"而不是删除。
 * 原因：宿主环境有批量删除保护，删到一定次数会直接抛 SAFE_DELETE_BULK_CONFIRM_REQUIRED，
 * 把与被删文件毫无关系的测试一起带崩（实测：agent.test.mjs 整文件失败）。
 * 测试的本意只是"从这个文件重新开始"，截断即可，顺带少一份误删风险。
 * 多余的实参（如 { force: true }）会被忽略，调用点不必改写。
 */
const truncateFile = (p) => {
  try {
    writeFileSync(p, '')
  } catch {
    /* 文件不存在等情形直接忽略 */
  }
}

// S74c·P0-3：改用 safefs 导出的 PROJECT_ROOT（按模块位置推导），不再硬编码仓库绝对路径
const ROOT = PROJECT_ROOT
const TEST_LOG = logPath('net.test.jsonl')

const response = (status, body = '{}') => ({
  status,
  ok: status >= 200 && status < 300,
  json: async () => JSON.parse(body),
  text: async () => body,
})

function readLog(file = TEST_LOG) {
  if (!existsSync(file)) return []
  return readFileSync(file, 'utf8')
    .split('\n')
    .filter((l) => l.trim().length > 0)
    .map((l) => JSON.parse(l))
}

/** 虚拟时钟：sleep 只累加时间并记录等待，不真等。 */
function vclock(start = 1_700_000_000_000) {
  let t = start
  const waits = []
  return {
    now: () => t,
    sleep: async (ms) => {
      waits.push(ms)
      t += ms
    },
    advance: (ms) => {
      t += ms
    },
    waits,
  }
}

const freshLog = () => truncateFile(TEST_LOG, { force: true })

// ---------------------------------------------------------------------------
// 1. 白名单
// ---------------------------------------------------------------------------

test('域名白名单严格等于 SAFETY.md 第 5 节列出的域（S60 起 8 个：+open.bigmodel.cn 视觉档）', () => {
  assert.deepEqual(
    [...ALLOWED_DOMAINS].sort(),
    [
      'api.crossref.org',
      'api.deepseek.com',
      'api.openalex.org',
      'api.semanticscholar.org',
      'arxiv.org',
      'export.arxiv.org',
      'models.sjtu.edu.cn',
      'open.bigmodel.cn', // S60：视觉档 zhipu GLM-5.3-Flash（SAFETY.md 第 5 节已同步）
    ].sort(),
  )
  assert.ok(!ALLOWED_DOMAINS.includes('eutils.ncbi.nlm.nih.gov'), 'NCBI 仅医学时启用，默认不在集合内')
})

test('isAllowedUrl: https + 精确主机名才放行', () => {
  const allowed = [
    'https://api.deepseek.com/v1/chat/completions',
    'https://models.sjtu.edu.cn/api/v1/messages',
    'https://export.arxiv.org/api/query?search_query=all:grid',
    'https://arxiv.org/abs/2401.00001',
    'https://api.openalex.org/works?search=grid-forming',
    'https://api.crossref.org/works/10.1109/TPWRS.2024.1',
    'https://api.semanticscholar.org/graph/v1/paper/search',
    'https://API.DEEPSEEK.COM/v1/models',
  ]
  for (const url of allowed) assert.equal(isAllowedUrl(url), true, `应放行 ${url}`)

  const denied = [
    'http://api.deepseek.com/v1/chat/completions',
    'https://evil.example.com/x',
    'https://localhost/x',
    'https://127.0.0.1/x',
    'https://deepseek.com/x',
    'https://api.deepseek.com.evil.tld/v1/chat',
    'https://notapi.deepseek.com/x',
    'https://webvpn.sjtu.edu.cn/x',
    'https://sci-hub.se/10.1109/x',
    'ftp://arxiv.org/x',
    'not a url',
    '',
  ]
  for (const url of denied) assert.equal(isAllowedUrl(url), false, `应拒绝 ${url}`)
})

test('hostOf 归一化大小写、去尾点、去端口', () => {
  assert.equal(hostOf('https://API.DeepSeek.com:443/v1'), 'api.deepseek.com')
  assert.equal(hostOf('https://arxiv.org./x'), 'arxiv.org')
  assert.equal(hostOf('nonsense'), null)
})

// ---------------------------------------------------------------------------
// 2. 拒绝：白名单外直接拒绝，且不发起任何 fetch
// ---------------------------------------------------------------------------

test('白名单外直接拒绝（exit before fetch），并写 net.jsonl 的 deny 记录', async () => {
  freshLog()
  let fetched = 0
  const net = createNet({
    fetchImpl: async () => {
      fetched += 1
      return response(200)
    },
    logFile: TEST_LOG,
  })

  await assert.rejects(() => net.request('https://evil.example.com/steal'), (err) => {
    assert.ok(err instanceof NetError)
    assert.equal(err.code, 'E_DOMAIN_NOT_ALLOWED')
    return true
  })
  assert.equal(fetched, 0, '被拒绝的请求绝不允许触网')
  assert.equal(net.stats.denied, 1)

  const denies = readLog().filter((l) => l.decision === 'deny')
  assert.equal(denies.length, 1)
  assert.equal(denies[0].host, 'evil.example.com')
  assert.equal(denies[0].reason, 'not-in-allowlist')
  assert.equal(denies[0].denyKey, 'evil.example.com')
  assert.equal(denies[0].count, 1, '首次拒绝 count=1')
  assert.ok(Number.isFinite(Date.parse(denies[0].ts)))
})

test('http 明文与不可解析 URL 同样被拒', async () => {
  freshLog()
  const net = createNet({ fetchImpl: async () => response(200), logFile: TEST_LOG })
  await assert.rejects(() => net.request('http://api.crossref.org/works'), (e) => e.code === 'E_DOMAIN_NOT_ALLOWED')
  await assert.rejects(() => net.request('%%%not-a-url'), (e) => e.code === 'E_DOMAIN_NOT_ALLOWED')
  const logs = readLog()
  assert.equal(logs.length, 2)
  assert.equal(logs[1].reason, 'unparsable-url')
  assert.equal(logs[1].host, null)
  assert.equal(logs[1].denyKey, '<unparsable>')
})

// ---------------------------------------------------------------------------
// 2b. deny 去重（S67·3-D·D1 改追加式）：首行 deny 不变，重复拒绝追加
//     net-deny-repeat（count/firstTs/lastTs）；拒绝次数不削弱
// ---------------------------------------------------------------------------

test('deny 去重（S67·D1 追加式）：61 次拒绝 = 1 条历史 deny 行 + 60 条 repeat，count 对账', async () => {
  freshLog()
  const net = createNet({ fetchImpl: async () => response(200), logFile: TEST_LOG })
  for (let i = 0; i < 61; i += 1) {
    await assert.rejects(() => net.request(`https://sci-hub.se/10.1109/x?i=${i}`), (e) => e.code === 'E_DOMAIN_NOT_ALLOWED')
  }
  // 拒绝次数一次不少（逐次计数，不因去重削弱）
  assert.equal(net.stats.denied, 61)
  // 历史 deny 行只有一条，且 count 停在 1（历史行一概不改写）
  const denies = readLog().filter((l) => l.decision === 'deny' && !l.kind)
  assert.equal(denies.length, 1, '同一 host 的历史 deny 行只有一行')
  assert.equal(denies[0].host, 'sci-hub.se')
  assert.equal(denies[0].count, 1, '历史行 count 停在首次值（S67·D1：不改写历史）')
  // 其余 60 次各追加一条 net-deny-repeat，末条 count=61
  const repeats = readLog().filter((l) => l.kind === 'net-deny-repeat')
  assert.equal(repeats.length, 60)
  assert.equal(repeats[repeats.length - 1].count, 61)
  assert.ok(Number.isFinite(Date.parse(repeats[repeats.length - 1].firstTs)), 'firstTs 记录首次拒绝时间')
  assert.ok(Number.isFinite(Date.parse(repeats[repeats.length - 1].lastTs)), 'lastTs 记录最后一次拒绝时间')
  // queueState 也能按 host 对账
  const byHost = net.queueState().deniedByHost
  assert.deepEqual(byHost, [{ host: 'sci-hub.se', count: 61 }])
  // 行数 = 1 deny + 60 repeat（每条 repeat 都携带完整 host/count，无内容丢失）
  const raw = readFileSync(TEST_LOG, 'utf8').split('\n').filter(Boolean)
  assert.equal(raw.length, 61)
})

test('deny 去重（S67·D1 追加式）：不同 host 各自成行；unparsable 归入 <unparsable> 桶', async () => {
  freshLog()
  const net = createNet({ fetchImpl: async () => response(200), logFile: TEST_LOG })
  await assert.rejects(() => net.request('https://sci-hub.se/a'))
  await assert.rejects(() => net.request('https://sci-hub.se/b'))
  await assert.rejects(() => net.request('https://libgen.is/x'))
  await assert.rejects(() => net.request('http://api.deepseek.com/v1/chat/completions'))
  await assert.rejects(() => net.request('%%%not-a-url'))
  await assert.rejects(() => net.request('%%%still-not-a-url'))

  const rows = readLog()
  const firsts = rows.filter((r) => !r.kind)
  const repeats = rows.filter((r) => r.kind === 'net-deny-repeat')
  assert.equal(firsts.length, 4, '4 个不同 deny 键 = 4 条首行')
  assert.equal(repeats.length, 2, 'sci-hub.se 第 2 次 + unparsable 第 2 次 = 2 条 repeat')
  const firstCounts = Object.fromEntries(firsts.map((r) => [r.denyKey, r.count]))
  assert.deepEqual(firstCounts, {
    'sci-hub.se': 1,
    'libgen.is': 1,
    'api.deepseek.com': 1, // http 明文：主机在白名单但协议不符，仍按 host 去重
    '<unparsable>': 1,
  })
  const repeatCounts = Object.fromEntries(repeats.map((r) => [r.denyKey, r.count]))
  assert.deepEqual(repeatCounts, { 'sci-hub.se': 2, '<unparsable>': 2 })
  assert.equal(net.stats.denied, 6, 'stats.denied 逐次计数，与首行 count+repeat count 之和一致')
})

test('deny 去重：deny 行被外部清掉后仍会补审计（不丢拒绝记录）', async () => {
  freshLog()
  const net = createNet({ fetchImpl: async () => response(200), logFile: TEST_LOG })
  await assert.rejects(() => net.request('https://sci-hub.se/a'))
  // 模拟日志被轮转：首行消失，但进程内台账还记着这个 host
  truncateFile(TEST_LOG, { force: true })
  await assert.rejects(() => net.request('https://sci-hub.se/b'))
  const rows = readLog()
  assert.equal(rows.length, 1, '兜底补一条完整 deny 行')
  assert.equal(rows[0].host, 'sci-hub.se')
  assert.equal(rows[0].count, 2, '补的行也带累计 count')
  assert.equal(net.stats.denied, 2)
})

// ---------------------------------------------------------------------------
// 3. 放行：写入 net.jsonl
// ---------------------------------------------------------------------------

test('白名单内放行并记录 allow（status/method/attempts/ms）', async () => {
  freshLog()
  const calls = []
  const net = createNet({
    fetchImpl: async (url, opts) => {
      calls.push({ url, method: opts.method })
      return response(200, '{"ok":true}')
    },
    logFile: TEST_LOG,
  })

  const res = await net.request('https://api.crossref.org/works/10.1109/x', { method: 'GET' })
  assert.equal(res.status, 200)
  assert.equal(calls.length, 1)

  const allows = readLog().filter((l) => l.decision === 'allow')
  assert.equal(allows.length, 1)
  assert.equal(allows[0].host, 'api.crossref.org')
  assert.equal(allows[0].status, 200)
  assert.equal(allows[0].method, 'GET')
  assert.equal(allows[0].attempts, 1)
  assert.deepEqual(allows[0].delaysMs, [])
  assert.ok(allows[0].ms >= 0)
})

test('json() 正常解析；非 2xx 抛 E_HTTP_STATUS', async () => {
  freshLog()
  const ok = createNet({ fetchImpl: async () => response(200, '{"total":7}'), logFile: TEST_LOG })
  assert.deepEqual(await ok.json('https://api.openalex.org/works'), { total: 7 })

  const bad = createNet({ fetchImpl: async () => response(500, 'boom'), logFile: TEST_LOG })
  await assert.rejects(() => bad.json('https://api.openalex.org/works'), (e) => e.code === 'E_HTTP_STATUS' && e.status === 500)
})

// ---------------------------------------------------------------------------
// 4. 限速
// ---------------------------------------------------------------------------

test('令牌桶：默认 3 req/s，容量 3，第 4 次需等待', () => {
  const clock = vclock()
  const bucket = new TokenBucket({ ratePerSec: 3, now: clock.now })

  assert.deepEqual(bucket.take(), { ok: true, waitMs: 0 })
  assert.deepEqual(bucket.take(), { ok: true, waitMs: 0 })
  assert.deepEqual(bucket.take(), { ok: true, waitMs: 0 })

  const fourth = bucket.take()
  assert.equal(fourth.ok, false)
  assert.ok(fourth.waitMs >= 300 && fourth.waitMs <= 340, `waitMs 应约 333ms，实际 ${fourth.waitMs}`)

  clock.advance(fourth.waitMs)
  assert.equal(bucket.take().ok, true)
})

test('令牌桶按域隔离，且回填不超过容量', () => {
  const clock = vclock()
  const a = new TokenBucket({ ratePerSec: 3, now: clock.now })
  const b = new TokenBucket({ ratePerSec: 3, now: clock.now })
  for (let i = 0; i < 3; i += 1) assert.equal(a.take().ok, true)
  assert.equal(a.take().ok, false, 'a 域用尽')
  assert.equal(b.take().ok, true, 'b 域不受 a 域影响')

  clock.advance(60_000)
  // 回填是惰性的（只在 take 时结算），所以用"能连取满容量、第 4 次又不够"来断言封顶
  for (let i = 0; i < 3; i += 1) assert.equal(a.take().ok, true, '空闲 60s 后必须回填满容量')
  assert.equal(a.take().ok, false, '回填不得超过容量')
})

test('每域令牌桶生效于真实请求路径：4 次连续请求触发一次等待', async () => {
  freshLog()
  const clock = vclock()
  const net = createNet({
    fetchImpl: async () => response(200),
    now: clock.now,
    sleep: clock.sleep,
    logFile: TEST_LOG,
    ratePerSec: 3,
  })
  for (let i = 0; i < 4; i += 1) {
    await net.request('https://api.semanticscholar.org/graph/v1/paper/search?query=vsg')
  }
  assert.equal(clock.waits.length, 1, '第 4 次应被令牌桶拦下一次')
  assert.ok(clock.waits[0] >= 300, `等待应约 333ms，实际 ${clock.waits[0]}`)
  assert.equal(readLog().filter((l) => l.decision === 'allow').length, 4)
})

test('deepseek-reasoner 严格 10 次/分钟，第 11 次排队而非丢弃', async () => {
  freshLog()
  const clock = vclock()
  const net = createNet({
    fetchImpl: async () => response(200, '{"choices":[]}'),
    now: clock.now,
    sleep: clock.sleep,
    logFile: TEST_LOG,
    ratePerSec: 1000, // 让令牌桶不干扰，只考察 reasoner 窗口
    reasonerPerMinute: 10,
  })

  for (let i = 0; i < 10; i += 1) {
    await net.request('https://api.deepseek.com/v1/chat/completions', { model: REASONER_MODEL, method: 'POST' })
  }
  assert.equal(clock.waits.length, 0, '前 10 次必须秒过')

  await net.request('https://api.deepseek.com/v1/chat/completions', { model: REASONER_MODEL, method: 'POST' })
  assert.equal(clock.waits.length, 1, '第 11 次必须排队等待')
  assert.ok(clock.waits[0] >= 59_000, `应等到窗口滑出（~60s），实际 ${clock.waits[0]}`)

  const logs = readLog().filter((l) => l.model === REASONER_MODEL)
  assert.equal(logs.length, 11, '排队后仍必须实际发出（不丢请求）')
})

test('非 reasoner 模型不受每分钟窗口限制', async () => {
  freshLog()
  const clock = vclock()
  const net = createNet({
    fetchImpl: async () => response(200),
    now: clock.now,
    sleep: clock.sleep,
    logFile: TEST_LOG,
    ratePerSec: 1000,
  })
  for (let i = 0; i < 25; i += 1) {
    await net.request('https://api.deepseek.com/v1/chat/completions', { model: 'deepseek-chat', method: 'POST' })
  }
  assert.equal(clock.waits.length, 0)
})

test('SlidingWindowLimiter 直接单测：窗口滑出后恢复', () => {
  const clock = vclock()
  const lim = new SlidingWindowLimiter({ limit: 2, windowMs: 1000, now: clock.now })
  assert.equal(lim.take().ok, true)
  assert.equal(lim.take().ok, true)
  assert.equal(lim.take().ok, false)
  clock.advance(1001)
  assert.equal(lim.take().ok, true)
})

// ---------------------------------------------------------------------------
// 5. 429 指数退避
// ---------------------------------------------------------------------------

test('429 指数退避 2/4/8/16/32 秒，最多 5 次后放弃并保留 429 响应', async () => {
  freshLog()
  const clock = vclock()
  let calls = 0
  const net = createNet({
    fetchImpl: async () => {
      calls += 1
      return response(429, '{"error":"too many requests"}')
    },
    now: clock.now,
    sleep: clock.sleep,
    logFile: TEST_LOG,
    ratePerSec: 1000,
  })

  const res = await net.request('https://api.semanticscholar.org/graph/v1/paper/search?query=vpp')
  assert.equal(res.status, 429)
  assert.equal(calls, 6, '首次 + 5 次退避重试 = 6 次')
  assert.deepEqual(clock.waits, BACKOFF_MS, '退避序列必须是 2/4/8/16/32 秒')
  assert.deepEqual(clock.waits, [2000, 4000, 8000, 16000, 32000])

  const logs = readLog()
  assert.equal(logs.filter((l) => l.decision === 'retry').length, 5)
  assert.deepEqual(logs.filter((l) => l.decision === 'retry').map((l) => l.delayMs), BACKOFF_MS)
  const last = logs[logs.length - 1]
  assert.equal(last.decision, 'exhausted')
  assert.equal(last.attempts, 6)
  assert.equal(last.retries, 5)
  assert.equal(net.stats.exhausted, 1)
})

test('429 后恢复：退避两次拿到 200，退避序列中断', async () => {
  freshLog()
  const clock = vclock()
  const seq = [429, 429, 200]
  let calls = 0
  const net = createNet({
    fetchImpl: async () => {
      const status = seq[Math.min(calls, seq.length - 1)]
      calls += 1
      return response(status)
    },
    now: clock.now,
    sleep: clock.sleep,
    logFile: TEST_LOG,
    ratePerSec: 1000,
  })

  const res = await net.request('https://export.arxiv.org/api/query?search_query=all:gfm')
  assert.equal(res.status, 200)
  assert.deepEqual(clock.waits, [2000, 4000])

  const last = readLog().at(-1)
  assert.equal(last.decision, 'allow')
  assert.equal(last.attempts, 3)
  assert.equal(last.retries, 2)
  assert.deepEqual(last.delaysMs, [2000, 4000])
})

// ---------------------------------------------------------------------------
// 6. 密钥打码：日志里绝不出现明文密钥
// ---------------------------------------------------------------------------

test('maskSecret 前 4 位 + ***；redactUrl 打码密钥类 query 参数', () => {
  assert.equal(maskSecret('sk-1234567890abcdef'), 'sk-1***')
  assert.equal(maskSecret('abc'), '***')
  assert.equal(maskSecret(''), '***')
  assert.equal(maskSecret(undefined), '***')

  const url = 'https://api.openalex.org/works?search=grid-forming&api_key=sk-TOPSECRET123&mailto=me@school.edu'
  const masked = redactUrl(url)
  assert.ok(masked.includes('search=grid-forming'), '非敏感参数保留，便于审计')
  assert.ok(!masked.includes('sk-TOPSECRET123'))
  assert.ok(!masked.includes('me@school.edu'))
  assert.ok(masked.includes('api_key=sk-T***'))
})

test('出网日志与拒绝日志中绝不出现明文密钥（query + header 双通道）', async () => {
  freshLog()
  const KEY = 'sk-SUPERSECRET-abcdefghijklmnop'
  const net = createNet({ fetchImpl: async () => response(200), logFile: TEST_LOG })

  await net.request(`https://api.openalex.org/works?api_key=${KEY}&search=inertia`, {
    headers: { Authorization: `Bearer ${KEY}` },
  })
  await assert.rejects(() => net.request(`https://evil.example.com/x?token=${KEY}`))

  const raw = readFileSync(TEST_LOG, 'utf8')
  assert.ok(!raw.includes(KEY), 'net.jsonl 不得出现明文密钥')
  assert.ok(!raw.includes('Bearer'), 'net.jsonl 不得记录请求头')
  assert.ok(raw.includes('sk-S***'))
})

// ---------------------------------------------------------------------------
// 7. 默认日志落点
// ---------------------------------------------------------------------------

test('默认审计日志落在 data/logs/net.jsonl', async () => {
  assert.equal(DEFAULT_NET_LOG, logPath('net.jsonl'))
  const net = createNet({ fetchImpl: async () => response(200) })
  assert.equal(net.logFile, DEFAULT_NET_LOG)
  await assert.rejects(() => net.request('https://sci-hub.se/x'), (e) => e.code === 'E_DOMAIN_NOT_ALLOWED')

  assert.ok(existsSync(DEFAULT_NET_LOG), 'net.jsonl 必须被创建')
  const last = readLog(DEFAULT_NET_LOG).at(-1)
  assert.equal(last.decision, 'deny')
  assert.equal(last.host, 'sci-hub.se')
})

// ---------------------------------------------------------------------------
// 【阶段 2 补的洞】fetch 自己抛异常时也必须留审计
// ---------------------------------------------------------------------------

test('fetch 抛异常（DNS/连接重置）时写 decision:error 审计行并抛类型化 E_NET', async () => {
  const file = logPath('net.throw.test.jsonl')
  truncateFile(file, { force: true })
  const net = createNet({
    fetchImpl: async () => {
      const err = new Error('socket hang up')
      err.cause = { code: 'ECONNRESET' }
      throw err
    },
    logFile: file,
  })

  await assert.rejects(() => net.request('https://api.openalex.org/works?x=1'), (e) => {
    assert.ok(e instanceof NetError, '必须是 NetError')
    assert.equal(e.code, 'E_NET')
    assert.match(e.message, /api\.openalex\.org/)
    return true
  })

  const lines = readLog(file)
  assert.equal(lines.length, 1, '失败也必须留一行审计（过去这里是 0 行，等于静默逃逸）')
  assert.equal(lines[0].decision, 'error')
  assert.equal(lines[0].host, 'api.openalex.org')
  assert.equal(lines[0].error, 'ECONNRESET')
  assert.equal(lines[0].message, 'socket hang up')
  assert.equal(lines[0].bucketKey, 'api.openalex.org')
  assert.equal(net.stats.failed, 1)
  assert.equal(net.stats.allowed, 0)
  assert.equal(net.queueState().failed, 1, 'queueState 也要能读出失败计数')
  truncateFile(file, { force: true })
})

test('fetch 抛异常不重试（不是 429 退避场景），且不计入 allow/deny', async () => {
  const file = logPath('net.throw2.test.jsonl')
  truncateFile(file, { force: true })
  let calls = 0
  const net = createNet({
    fetchImpl: async () => {
      calls += 1
      const err = new Error('getaddrinfo ENOTFOUND')
      err.code = 'ENOTFOUND'
      throw err
    },
    logFile: file,
  })
  await assert.rejects(() => net.request('https://api.crossref.org/works'))
  assert.equal(calls, 1, '网络层错误不重试')
  const lines = readLog(file)
  assert.equal(lines.length, 1)
  assert.equal(lines[0].error, 'ENOTFOUND')
  assert.equal(net.stats.denied, 0)
  assert.equal(net.stats.retried, 0)
  truncateFile(file, { force: true })
})
