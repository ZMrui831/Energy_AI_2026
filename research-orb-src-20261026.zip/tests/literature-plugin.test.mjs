// tests/literature-plugin.test.mjs
//
// 插件层的离线端到端：/find → /card → /bib → /recall 全链路，
// 外加两条"纪律"断言：插件里没有第二条出网/落盘出口，且合规红线仍然生效。

import test from 'node:test'
import assert from 'node:assert/strict'
import { readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'

import {
  CARD_ID,
  DEFAULTS,
  PLUGIN_ID,
  activate,
  classifyCardTarget,
  createEngine,
  formatCandidates,
  formatSourceLine,
  parseSelection,
  splitFlags,
} from '../packages/plugins/research-literature/index.mjs'
import { createNet } from '../packages/core/src/net.mjs'
import { createRegistry, normalizeManifest } from '../packages/plugins/index.mjs'
import { PROJECT_ROOT, logPath, dataPath } from '../packages/core/src/safefs.mjs'
import { validateLlmDraft } from '../packages/plugins/research-literature/lib/cards.mjs'
import { expandQueryToEnglish, aliasHit, matchClusters, resolveQuery } from '../packages/plugins/research-literature/lib/keywords.mjs'
import { extractCitedNumbers, runRecall } from '../packages/plugins/research-literature/lib/recall.mjs'
import { STUB_ALLOWED_DOMAINS, makeFakeCtx, makeMemoryScopes, makeStubNet, arxivFeedXml } from './helpers/research-fixtures.mjs'

const PLUGIN_DIR = join(PROJECT_ROOT, 'packages', 'plugins', 'research-literature')

function engineWith({ llm = null, secrets = {} } = {}) {
  const scopes = makeMemoryScopes()
  const net = makeStubNet()
  const ctx = makeFakeCtx({ scopes, net, llm })
  const engine = createEngine(ctx, { scopes, secretsLoader: () => secrets })
  return { engine, scopes, net, ctx }
}

/** 一个只吐固定文本的假 llm（形状与 ctx.llm 一致）。 */
function fakeLlm(text) {
  return {
    available: true,
    chat: () => (async function* gen() {
      yield { type: 'delta', text, channel: 'content' }
      yield { type: 'done', text }
    })(),
  }
}

// ---------------------------------------------------------------------------
// 纯函数
// ---------------------------------------------------------------------------

test('plugin: splitFlags 剥掉 --k v 与 --flag，正文保持原样', () => {
  assert.deepEqual(splitFlags('grid-forming inverter --max 20'), { text: 'grid-forming inverter', flags: { max: '20' } })
  assert.deepEqual(splitFlags('10.1/x --heuristic --topic gfm'), { text: '10.1/x', flags: { heuristic: true, topic: 'gfm' } })
  assert.deepEqual(splitFlags('  '), { text: '', flags: {} })
  assert.deepEqual(splitFlags('--topic a --topic b'), { text: '', flags: { topic: 'b' } })
  // 命令名由宿主切掉，splitFlags 只处理参数部分；即使有人把命令名带进来也不该崩
  assert.equal(splitFlags('/find x').text, '/find x')
})

test('plugin: splitFlags 双引号内的多词值不被切碎（/verify --title 依赖此行为）', () => {
  const r = splitFlags('doi 10.1109/x --title "Grid-Forming Inverter Control for Inertia Support" --year 2021')
  assert.equal(r.text, 'doi 10.1109/x')
  assert.equal(r.flags.title, 'Grid-Forming Inverter Control for Inertia Support')
  assert.equal(r.flags.year, '2021')
  // 引号只影响切词，不进入 token；空引号仍算一个 token
  assert.deepEqual(splitFlags('quote "a b" --pdf x.pdf'), { text: 'quote a b', flags: { pdf: 'x.pdf' } })
  assert.deepEqual(splitFlags('--title ""'), { text: '', flags: { title: '' } })
})

test('plugin: classifyCardTarget 区分 DOI / PDF / 空', () => {
  assert.deepEqual(classifyCardTarget('10.1109/TPWRS.2024.1'), { kind: 'doi', value: '10.1109/TPWRS.2024.1' })
  assert.deepEqual(classifyCardTarget('https://doi.org/10.1109/X'), { kind: 'doi', value: '10.1109/X' })
  assert.deepEqual(classifyCardTarget('doi:10.1109/X'), { kind: 'doi', value: '10.1109/X' })
  assert.equal(classifyCardTarget('D:\\papers\\a.pdf').kind, 'pdf')
  assert.equal(classifyCardTarget('C:/papers/a.PDF').kind, 'pdf')
  assert.equal(classifyCardTarget('D:\\papers\\a.pdf').value, 'D:\\papers\\a.pdf')
  assert.equal(classifyCardTarget('/home/x/a.pdf').kind, 'pdf')
  assert.deepEqual(classifyCardTarget(''), { kind: 'empty', value: '' })
})

test('plugin: parseSelection 支持逗号与区间，去重排序', () => {
  assert.deepEqual(parseSelection('1,3,5'), [1, 3, 5])
  assert.deepEqual(parseSelection('3,1,3'), [1, 3])
  assert.deepEqual(parseSelection('2-4'), [2, 3, 4])
  assert.deepEqual(parseSelection('5-3,1'), [1, 3, 4, 5])
  assert.deepEqual(parseSelection('abc'), [])
  assert.deepEqual(parseSelection('0,-1'), [], '0 与负数不是合法编号')
})

test('plugin: 关键词别名匹配区分中英文（中文子串 / 英文词边界）', () => {
  assert.equal(aliasHit('构网', '构网型逆变器的惯量支撑'), true)
  assert.equal(aliasHit('ai', 'waiting for the domain'), false, '"ai" 不得命中 waiting/domain')
  assert.equal(aliasHit('ai', 'AI for grid dispatch'), true)
  assert.equal(aliasHit('gfm', 'a gfm survey'), true)
  assert.equal(aliasHit('rser', 'a rser paper'), true)
  assert.deepEqual(matchClusters('构网型逆变器').map((c) => c.id), ['stability'])
  assert.equal(resolveQuery('gfm').query, 'grid-forming inverter inertia support')
  assert.equal(resolveQuery('gfm').expanded, true)
  // 已经是预设检索式原文时不该谎称"展开过"（改写前后一字不差）
  assert.equal(resolveQuery('grid-forming inverter inertia support').expanded, false)
  assert.equal(resolveQuery('grid-forming inverter inertia support').query, 'grid-forming inverter inertia support')
  assert.equal(resolveQuery('grid-forming inverter inertia support').clusterId, 'stability', '簇归属仍应给出')
  const exp = expandQueryToEnglish('构网型逆变器的惯量支撑有哪些实现路径')
  assert.ok(exp)
  assert.deepEqual(exp.clusters, ['stability'])
  assert.ok(exp.query.includes('grid-forming inverter'))
  assert.equal(expandQueryToEnglish('zebra quantum banana'), null, '未命中任何别名时不扩展')
  assert.deepEqual(expandQueryToEnglish('microgrid islanding').clusters, ['distribution'], 'microgrid 也是别名，应当扩展')
})

test('plugin: recall 的 [n] 抽取与 LLM 草案校验', () => {
  assert.deepEqual(extractCitedNumbers('结论是 A [1]，另有 B [3]，重复 [1]。'), [1, 3])
  assert.deepEqual(extractCitedNumbers('没有引用'), [])
  assert.equal(validateLlmDraft({ 问题: 'x' }).ok, true)
  assert.equal(validateLlmDraft({ 问题: 'x', 方法: 'y' }).ok, true)
  assert.equal(validateLlmDraft({ summary: '只有非允许键' }).ok, false)
  assert.equal(validateLlmDraft(null).ok, false)
  assert.equal(validateLlmDraft([1, 2]).ok, false)
  assert.equal(validateLlmDraft({ 问题: { nested: 1 } }).ok, false)
  assert.ok(validateLlmDraft({ 问题: { nested: 1 } }).errors[0].includes('必须是字符串'))
})

test('plugin: 格式化输出稳定（源状态行 / 候选表）', () => {
  assert.equal(
    formatSourceLine([
      { source: 'arxiv', ok: true, entries: 8, usedFallback: false },
      { source: 'semanticscholar', ok: true, skipped: true, reason: 'E_NO_KEY' },
      { source: 'crossref', ok: false, error: { code: 'E_RATE_LIMITED' } },
    ]),
    'arxiv:8条  semanticscholar:跳过(E_NO_KEY)  crossref:失败(E_RATE_LIMITED)',
  )
  const table = formatCandidates([
    { title: 'T1', authors: ['A'], venue: 'IEEE Transactions on Smart Grid', year: 2024, citations: 3, sources: ['arxiv'], source: 'arxiv', score: 0.9, venueKey: 'TSG', venueTier: 'top' },
  ])
  assert.ok(table.startsWith('#   score'))
  assert.ok(table.includes('0.900'))
  assert.ok(table.includes('T1'))
})

// ---------------------------------------------------------------------------
// 端到端（离线）
// ---------------------------------------------------------------------------

test('plugin: /find → /card --find → /bib → /recall 全链路离线跑通', async () => {
  const { engine, scopes, net } = engineWith()
  assert.equal(engine.status().cards, 0)

  // 1) /find
  const found = await engine.find('grid-forming inverter inertia support', {})
  assert.equal(found.ok, true)
  assert.ok(found.ui.candidates.length >= 5, `候选 ${found.ui.candidates.length} 应 ≥5`)
  assert.equal(found.ui.kind, 'candidates')
  for (const c of found.ui.candidates) {
    for (const f of ['title', 'authors', 'venue', 'year', 'doi', 'url', 'abstract', 'citations', 'source']) {
      assert.ok(f in c, `候选缺少 ${f}`)
    }
    assert.ok(c.doi || c.url, '必须有 DOI 或 URL 以便回溯原文')
    assert.ok(c.score > 0)
  }
  assert.ok(found.ui.candidates.filter((c) => c.doi).length >= 5, '至少 5 条应带 DOI（夹具里只有第 5 条无 DOI）')
  assert.ok(scopes.index.exists('candidates/index.json'), '候选账本应落盘')
  const candFiles = scopes.index.list('candidates')
  assert.ok(candFiles.some((f) => f.endsWith('grid-forming-inverter-inertia-support.json')))
  // 只碰白名单域名
  for (const call of net.calls) assert.ok(STUB_ALLOWED_DOMAINS.includes(call.host), `越界域名 ${call.host}`)
  const hosts = [...new Set(net.calls.map((c) => c.host))].sort()
  assert.deepEqual(hosts, ['api.crossref.org', 'api.openalex.org', 'export.arxiv.org'], 'S2 无 key 时不应被请求')

  // 2) /card --find 1,2,3（确定性草案，不调模型）
  const made = await engine.cardFromFindSelection('1,2,3', { topic: 'gfm', useLlm: false, model: 'deepseek-chat' })
  assert.equal(made.ok, true)
  assert.equal(made.ui.kind, 'cards-batch')
  assert.equal(made.ui.results.filter((r) => r.ok).length, 3)
  assert.equal(made.ui.indexCount, 3)
  // notes 顶层 = 主题目录 + 链接索引（块 3 的派生文件，任务书点名路径 data/notes/.links.json）
  assert.deepEqual(scopes.notes.list('').sort(), ['.links.json', 'gfm'])
  const mdFiles = scopes.notes.list('gfm').filter((f) => f.endsWith('.md'))
  assert.equal(mdFiles.length, 3)
  assert.equal(scopes.notes.list('gfm').filter((f) => f.endsWith('.meta.json')).length, 3, '每张卡都应有 meta 侧车')
  // 卡片 front-matter 字段齐全
  const { parseCard, CARD_FIELDS } = await import('../packages/plugins/research-literature/lib/cards.mjs')
  for (const rel of mdFiles) {
    const data = parseCard(scopes.notes.read(rel)).data
    assert.deepEqual(Object.keys(data), [...CARD_FIELDS], `${rel} 字段不齐`)
  }
  assert.equal(engine.status().cards, 3)

  // 3) /bib
  const bib = await engine.bib('gfm', { date: '2026-10-15' })
  assert.equal(bib.ok, true, bib.text)
  assert.equal(bib.ui.count, 3)
  assert.equal(bib.ui.check.ok, true)
  assert.equal(bib.ui.check.parsed, 3)
  assert.ok(scopes.exports.exists('gfm-2026-10-15.bib'))
  assert.ok(bib.ui.sample.includes('@article{'))

  // 4) /recall（中文问题 → 检索式扩展 → 命中并带出处）
  const rec = await engine.recall('构网型逆变器的惯量支撑有哪些实现路径', {})
  assert.equal(rec.ok, true)
  assert.equal(rec.ui.kind, 'recall')
  assert.equal(rec.ui.mode, 'retrieval', '未注入 llm 时应走纯检索降级')
  assert.ok(rec.ui.hitCount >= 1)
  assert.ok(rec.ui.citations.length >= 1, '必须有出处表')
  assert.ok(rec.ui.expansion, '中文问题应触发英文检索式扩展')
  for (const c of rec.ui.citations) {
    assert.ok(c.title && c.rel, '每条出处都必须有标题与卡片路径')
  }
  assert.ok(rec.text.includes('出处（由检索层生成'))
  assert.ok(/\[\d+\]/.test(rec.text), '答案必须带 [n] 出处标记')
  assert.ok(rec.ui.rebuilt === false, '第二次访问应直接读盘而不是重建')
})

test('plugin: 同一篇论文归到两个主题 → 索引去重不炸，日志记下合并，卡片文本给出提醒', async () => {
  const { engine, scopes, ctx } = engineWith()
  await engine.find('grid-forming inverter inertia support', {})
  const first = await engine.cardFromFindSelection('1', { topic: 'gfm', useLlm: false })
  assert.equal(first.ok, true, first.text)
  assert.equal(first.ui.indexCount, 1)

  // 换主题再归档同一篇（面板里就是这么点出来的）
  const second = await engine.cardFromFindSelection('1', { topic: 'inbox', useLlm: false })
  assert.equal(second.ok, true, second.text)
  assert.equal(second.ui.indexCount, 1, '同一篇论文在索引里只应占一条')
  assert.ok(second.ui.duplicateCount >= 1, '应报告合并组数')
  // 两张卡片都还在磁盘上（去重是索引层的事，不删用户文件）
  assert.equal(scopes.notes.list('gfm').filter((f) => f.endsWith('.md')).length, 1)
  assert.equal(scopes.notes.list('inbox').filter((f) => f.endsWith('.md')).length, 1)
  // warn 必须落进插件日志（不静默丢弃）
  const warns = ctx._logs.filter(([lvl, msg]) => lvl === 'warn' && msg.includes('同论文卡片'))
  assert.equal(warns.length, 1)
  assert.ok(warns[0][1].includes('保留'), warns[0][1])
  assert.ok(warns[0][1].includes('丢弃'), warns[0][1])
})

test('plugin: 单张 /card 归档时，若同 DOI 已在别的主题会给出提醒', async () => {
  const { engine } = engineWith()
  await engine.find('grid-forming inverter inertia support', {})
  const doi = engine.latestCandidates().candidates[0].doi
  const a = await engine.cardFromTarget(doi, { topic: 'gfm', heuristic: true })
  assert.equal(a.ok, true, a.text)
  assert.equal(a.ui.duplicateDoiElsewhere, null, '第一次归档不该有重复提醒')
  const b = await engine.cardFromTarget(doi, { topic: 'inbox', heuristic: true })
  assert.equal(b.ok, true, b.text)
  assert.deepEqual(b.ui.duplicateDoiElsewhere, [a.ui.rel.replace(/^data\/notes\//, '')], '第二次应指出已有的卡片路径')
  assert.ok(b.text.includes('提醒：同一 DOI 还存在于'), b.text)
})

test('plugin: 同论文跨主题归档后 /recall 仍可用（索引没有被重复 id 打死）', async () => {
  const { engine } = engineWith()
  await engine.find('grid-forming inverter inertia support', {})
  await engine.cardFromFindSelection('1,2', { topic: 'gfm', useLlm: false })
  await engine.cardFromFindSelection('1,2', { topic: 'inbox', useLlm: false })
  const r = await engine.recall('构网型逆变器的惯量支撑', {})
  assert.equal(r.ok, true, r.text)
  assert.ok(r.ui.hitCount >= 1)
  // 每次 /card 都已经重建过索引，所以这里正常读到的是现成的索引（rebuilt=false 才对）
  assert.equal(r.ui.rebuilt, false)
  assert.equal(r.ui.indexCount, 2, '两篇论文、两张卡片 → 索引两条')
  const dois = r.ui.citations.map((c) => c.doi)
  assert.equal(new Set(dois).size, dois.length, '出处里不该出现同一篇论文两次')
})

test('plugin: /card 传单个 DOI 时优先用已存候选，零网络请求', async () => {
  const { engine, net } = engineWith()
  await engine.find('grid-forming inverter inertia support', {})
  const before = net.calls.length
  const first = engine.latestCandidates().candidates[0]
  const r = await engine.cardFromTarget(first.doi, { topic: 'gfm', heuristic: true })
  assert.equal(r.ok, true, r.text)
  assert.equal(net.calls.length, before, '候选命中时必须零网络请求')
  assert.match(r.ui.biblioVia, /^candidates:/)
})

test('plugin: /card 传未知 DOI 时给出类型化错误与已尝试的源', async () => {
  const { engine } = engineWith()
  const net = makeStubNet({
    status: { 'api.openalex.org': { status: 404, body: '' }, 'api.crossref.org': { status: 404, body: '' } },
  })
  const scopes = makeMemoryScopes()
  const eng = createEngine(makeFakeCtx({ scopes, net }), { scopes, secretsLoader: () => ({}) })
  const r = await eng.cardFromTarget('10.9999/definitely-not-real', { topic: 'gfm' })
  assert.equal(r.ok, false)
  assert.equal(r.code, 'E_DOI_NOT_FOUND')
  assert.match(r.text, /openalex/)
  assert.match(r.text, /crossref/)
  assert.equal(scopes.notes.list('').length, 0, '失败时不得写任何卡片')
  assert.equal(engine.status().cards, 0)
})

test('plugin: /card 无参数、/find 空词、/recall 空问题都给出用法提示而不是抛错', async () => {
  const { engine } = engineWith()
  const c = await engine.cardFromTarget('', {})
  assert.equal(c.code, 'E_EMPTY_TARGET')
  assert.match(c.text, /用法/)
  const f = await engine.find('', {})
  assert.equal(f.code, 'E_EMPTY_QUERY')
  const r = await engine.recall('', {})
  assert.equal(r.code, 'E_EMPTY_QUESTION')
  const bib = await engine.bib('', {})
  assert.equal(bib.code, 'E_NO_CARD')
})

test('plugin: /recall 在空卡片库上给出可操作提示', async () => {
  const { engine } = engineWith()
  const r = await engine.recall('构网型逆变器', {})
  assert.equal(r.ok, false)
  assert.equal(r.code, 'E_INDEX_EMPTY')
  assert.match(r.text, /先 \/find/)
})

// ---------------------------------------------------------------------------
// /verify 引用校验（P-R4 块 1，产品红线）—— 引擎级端到端（真连接器路径 + 真 PDF 抽取）
// ---------------------------------------------------------------------------

const VERIFY_FIXTURE_PDF = dataPath('fixtures', 'sample-paper.pdf')

/** 单篇载荷的桩 net：OpenAlex 404（覆盖不到），Crossref 返回该 DOI 的完整元数据。 */
function verifyDoiNet() {
  return makeStubNet({
    status: {
      'api.openalex.org': { status: 404, body: '' },
      'api.crossref.org': {
        status: 200,
        body: JSON.stringify({
          message: {
            DOI: '10.1109/TPWRS.2024.1000000',
            title: ['Grid-Forming Inverter Control for Inertia Support in Low-Inertia Power Systems'],
            author: [
              { given: 'Wei', family: 'Wang' },
              { given: 'Jane', family: 'Doe' },
            ],
            'container-title': ['IEEE Transactions on Power Systems'],
            issued: { 'date-parts': [[2019, 6, 1]] },
            'is-referenced-by-count': 5,
            URL: 'https://doi.org/10.1109/TPWRS.2024.1000000',
            type: 'journal-article',
          },
        }),
      },
    },
  })
}

test('plugin: /verify doi 题录全对 → 已证实并贴置信度', async () => {
  const scopes = makeMemoryScopes()
  const engine = createEngine(makeFakeCtx({ scopes, net: verifyDoiNet() }), { scopes, secretsLoader: () => ({}) })
  const r = await engine.verify(
    'doi 10.1109/TPWRS.2024.1000000 --title "Grid-Forming Inverter Control for Inertia Support in Low-Inertia Power Systems" --year 2019 --author "Wei Wang"',
  )
  assert.equal(r.ok, true, r.text)
  assert.equal(r.ui.status, 'verified')
  assert.match(r.text, /引用校验通过（已证实）/)
  assert.match(r.text, /校验置信度：1\.00/)
  assert.match(r.text, /IEEE Transactions on Power Systems/)
})

test('plugin: /verify doi 伪造 DOI（双源 404）→ 拒引并给出理由', async () => {
  const scopes = makeMemoryScopes()
  const net = makeStubNet({
    status: { 'api.openalex.org': { status: 404, body: '' }, 'api.crossref.org': { status: 404, body: '' } },
  })
  const engine = createEngine(makeFakeCtx({ scopes, net }), { scopes, secretsLoader: () => ({}) })
  const r = await engine.verify('doi 10.9999/definitely-not-real --title "某篇不存在的论文"')
  assert.equal(r.ok, false)
  assert.equal(r.ui.status, 'rejected')
  assert.match(r.text, /引用校验失败（DOI 无法解析：Crossref 与 OpenAlex 均未收录该 DOI/)
  assert.match(r.text, /不得出现在任何结论中/)
})

test('plugin: /verify quote 经真实 unpdf 抽取：命中放行、不命中拒引', async () => {
  const { engine } = engineWith()
  const hit = await engine.verify(
    'quote Simulations on a modified IEEE 9-bus system show improved frequency nadir by 32 percent. --pdf ' + VERIFY_FIXTURE_PDF,
  )
  assert.equal(hit.ok, true, hit.text)
  assert.equal(hit.ui.status, 'verified')
  assert.match(hit.text, /归一化后逐字命中/)
  assert.match(hit.text, /1 页 \/ 631 字符/)
  const miss = await engine.verify('quote Simulations show improved frequency nadir by 90 percent. --pdf ' + VERIFY_FIXTURE_PDF)
  assert.equal(miss.ok, false)
  assert.equal(miss.ui.status, 'rejected')
  assert.match(miss.text, /引用校验失败（引文未在 PDF 全文中逐字命中/)
})

test('plugin: /verify 参数缺失给用法提示而不是抛错', async () => {
  const { engine } = engineWith()
  const empty = await engine.verify('')
  assert.equal(empty.code, 'E_BAD_ARGS')
  assert.match(empty.text, /\/verify doi <DOI>/)
  const noPdf = await engine.verify('quote 某段引文')
  assert.equal(noPdf.code, 'E_BAD_ARGS')
  assert.match(noPdf.text, /--pdf <本地PDF路径>/)
  const unknownSub = await engine.verify('isbn 978-x')
  assert.equal(unknownSub.code, 'E_BAD_ARGS')
})

// ---------------------------------------------------------------------------
// /verify 严谨性子命令（P-R4 块 2）—— 引擎级端到端
// ---------------------------------------------------------------------------

test('plugin: /verify numbers 抽取量纲并回溯到本地 PDF 全文', async () => {
  const { engine } = engineWith()
  const hit = await engine.verify(
    'numbers Simulations show improved frequency nadir by 32 percent, and the system runs at 50 Hz. --pdf ' + VERIFY_FIXTURE_PDF,
  )
  // 夹具 PDF 只有 "32 percent"：32 % 命中，50 Hz 回溯失败 → ok=false（回溯失败 ≠ 量纲问题）
  assert.equal(hit.ok, false, hit.text)
  assert.match(hit.text, /回溯原文：已提供/)
  assert.match(hit.text, /32 %｜已回溯命中（32percent）/)
  assert.match(hit.text, /50 Hz｜回溯失败/)
  assert.match(hit.text, /→ 1 个数值未能在来源中回溯/)

  // 全部命中的用例 → ok=true
  const allHit = await engine.verify('numbers nadir improved by 32 percent. --pdf ' + VERIFY_FIXTURE_PDF)
  assert.equal(allHit.ok, true, allHit.text)
  assert.match(allHit.text, /→ 未发现未回溯数值。/)

  // 量纲警告：多功率基准（不影响 ok，只提示）
  const warn = await engine.verify('numbers values on a 100 MVA base, later converted to the 50 MVA base.')
  assert.equal(warn.ok, true, warn.text)
  assert.match(warn.text, /检测到多个功率基准（100 MVA \/ 50 MVA）/)

  // 无 --pdf：显式声明无法回溯，不假装校验过
  const noSrc = await engine.verify('numbers nadir improved by 32 percent')
  assert.equal(noSrc.ok, true)
  assert.match(noSrc.text, /未提供（未给 --pdf），数值无法回溯/)
  assert.match(noSrc.text, /32 %｜未回溯/)
})

test('plugin: /verify meta 完整期刊题录无缺项；PDF 来源显式列无 DOI 缺项', async () => {
  const scopes = makeMemoryScopes()
  const engine = createEngine(makeFakeCtx({ scopes, net: verifyDoiNet() }), { scopes, secretsLoader: () => ({}) })
  const ok = await engine.verify('meta 10.1109/TPWRS.2024.1000000')
  assert.equal(ok.ok, true, ok.text)
  assert.match(ok.text, /引用校验通过/)
  assert.match(ok.text, /预印本：否/)
  assert.match(ok.text, /DOI：有/)
  assert.match(ok.text, /检索时间：20\d\d-/)
  assert.match(ok.text, /缺项：无。/)

  const pdf = await engine.verify(
    'meta ' + VERIFY_FIXTURE_PDF + ' --quote "Simulations on a modified IEEE 9-bus system show improved frequency nadir by 32 percent."',
  )
  assert.equal(pdf.ok, true, pdf.text)
  assert.match(pdf.text, /DOI：无/)
  assert.match(pdf.text, /缺项｜无 DOI：无法经 Crossref\/OpenAlex 独立核验题录/)
  assert.match(pdf.text, /本地 PDF 仅核到引文逐字命中/)

  // PDF 不给 --quote → 用法提示
  const noQuote = await engine.verify('meta ' + VERIFY_FIXTURE_PDF)
  assert.equal(noQuote.code, 'E_BAD_ARGS')
  assert.match(noQuote.text, /--quote <引文>/)
})

test('plugin: /verify meta arXiv DOI → 预印本 + v2 版本识别', async () => {
  const scopes = makeMemoryScopes()
  const net = makeStubNet({
    status: {
      'api.openalex.org': { status: 404, body: '' },
      'api.crossref.org': {
        status: 200,
        body: JSON.stringify({
          message: {
            DOI: '10.48550/arXiv.2401.0100v2',
            title: ['A Preprint on Grid-Forming Inverter Control'],
            author: [{ given: 'Wei', family: 'Wang' }],
            'container-title': ['arXiv preprint'],
            issued: { 'date-parts': [[2024, 1, 1]] },
            'is-referenced-by-count': 0,
            URL: 'https://arxiv.org/abs/2401.0100v2',
            type: 'preprint',
          },
        }),
      },
    },
  })
  const engine = createEngine(makeFakeCtx({ scopes, net }), { scopes, secretsLoader: () => ({}) })
  const r = await engine.verify('meta 10.48550/arXiv.2401.0100v2')
  assert.equal(r.ok, true, r.text)
  assert.match(r.text, /预印本：是（arXiv DOI 10\.48550\/arxiv\.2401\.0100v2）/)
  assert.match(r.text, /版本：v2/)
  assert.match(r.text, /提示｜.*预印本（arXiv DOI 10\.48550\/arxiv\.2401\.0100v2）：未经同行评审/)
  // 有 DOI（kind=doi）→ 不应出现"无 DOI"缺项
  assert.ok(!r.text.includes('无 DOI'))
})

test('plugin: /verify answer --file 一段输出同屏三档 + 未验证断言区 + 严谨性两区', async () => {
  const scopes = makeMemoryScopes()
  const engine = createEngine(makeFakeCtx({ scopes, net: verifyDoiNet() }), { scopes, secretsLoader: () => ({}) })
  const file = join(tmpdir(), `rigor-answer-${process.pid}-${Date.now()}.json`)
  writeFileSync(
    file,
    JSON.stringify({
      lead: '关于构网型逆变器频率支撑的三条陈述：',
      assertions: [
        {
          text: '构网型控制可改善频率最低点（仿真显示 32 percent）。',
          strength: 'proven',
          sources: [
            { kind: 'pdf', ref: VERIFY_FIXTURE_PDF, locator: { quote: 'Simulations on a modified IEEE 9-bus system show improved frequency nadir by 32 percent.' } },
          ],
        },
        { text: '惯量常数量级或可与同步机相当。', strength: 'inferred' },
        {
          text: '该系统频率最低点改善 90 percent。',
          strength: 'proven',
          sources: [{ kind: 'pdf', ref: VERIFY_FIXTURE_PDF, locator: { quote: 'there is no such sentence in this fixture pdf at all' } }],
        },
      ],
    }),
  )
  try {
    const r = await engine.verify(`answer --file "${file}"`)
    assert.equal(r.ok, false) // 第三条降级 + 有拒引
    assert.match(r.text, /强度口径：已证实/)
    assert.match(r.text, /构网型控制可改善频率最低点（仿真显示 32 percent）。 \[1\] —— 已证实/)
    assert.match(r.text, /惯量常数量级或可与同步机相当。 —— 推断/)
    assert.match(r.text, /【未验证断言】/)
    assert.match(r.text, /该系统频率最低点改善 90 percent。 —— 待验证（全部 1 个来源校验失败）/)
    // unverified 不进结论区
    const conclusion = r.text.slice(r.text.indexOf('【结论】'), r.text.indexOf('【来源清单】'))
    assert.ok(!conclusion.includes('90 percent'))
    // 严谨性两区：第三条的 90 % 无可回溯原文；PDF 来源无 DOI 缺项
    assert.match(r.text, /【数值与单位】/)
    assert.match(r.text, /未提供原文，1 个数值无法回溯/)
    assert.match(r.text, /【元数据提示】/)
    assert.match(r.text, /缺项｜PDF /)
  } finally {
    rmSync(file, { force: true })
  }
})

test('plugin: /verify answer --file 缺参与坏 JSON 给可读错误', async () => {
  const { engine } = engineWith()
  const noFile = await engine.verify('answer')
  assert.equal(noFile.code, 'E_BAD_ARGS')
  assert.match(noFile.text, /--file <断言JSON路径>/)
  const bad = await engine.verify('answer --file definitely-missing-file.json')
  assert.equal(bad.code, 'E_BAD_JSON')
  assert.match(bad.text, /读取\/解析失败/)
})

test('plugin: 模型返回合法 JSON 时用模型字段，书目字段仍来自元数据', async () => {
  const payload = JSON.stringify({
    问题: '模型说的问题',
    方法: '模型说的方法',
    数据与算例: '模型说的算例',
    结论与局限: '模型说的结论',
    可复用点: '可复用',
    待验证点: '待验证',
    与我课题的关系: '与你课题有关',
    title: '模型编的标题',
    doi: '10.9999/fake',
  })
  const { engine } = engineWith({ llm: fakeLlm(payload) })
  await engine.find('grid-forming inverter', {})
  const c = await engine.cardFromFindSelection('1', { topic: 'gfm', useLlm: true, model: 'deepseek-chat' })
  assert.equal(c.ok, true, c.text)
  const card = c.ui.results[0].card
  assert.equal(card['问题'], '模型说的问题')
  assert.equal(card['与我课题的关系'], '与你课题有关')
  assert.notEqual(card.title, '模型编的标题', '标题必须来自元数据')
  assert.notEqual(card.doi, '10.9999/fake', 'DOI 必须来自元数据')
  assert.equal(c.ui.results[0].generatedBy, 'llm')
  assert.equal(card['读数（0-5）'], 0)
})

test('plugin: 模型输出不是合法 JSON 或不合 schema → 报错且不写盘', async () => {
  // 1) 根本不是 JSON
  const e1 = engineWith({ llm: fakeLlm('抱歉，我无法给出 JSON 格式。') })
  await e1.engine.find('grid-forming inverter', {})
  const r1 = await e1.engine.cardFromFindSelection('1', { topic: 'gfm', useLlm: true })
  assert.equal(r1.ok, false)
  assert.equal(r1.ui.results[0].code, 'E_CARD_SCHEMA')
  assert.equal(e1.scopes.notes.list('').length, 0, '不得写盘')

  // 2) 是 JSON 但没有一个允许的键
  const e2 = engineWith({ llm: fakeLlm('{"summary":"这是摘要","keywords":["a"]}') })
  await e2.engine.find('grid-forming inverter', {})
  const r2 = await e2.engine.cardFromFindSelection('1', { topic: 'gfm', useLlm: true })
  assert.equal(r2.ok, false)
  assert.equal(r2.ui.results[0].code, 'E_CARD_SCHEMA')
  assert.equal(e2.scopes.notes.list('').length, 0, 'schema 不符必须零落盘')

  // 3) 值是嵌套对象
  const e3 = engineWith({ llm: fakeLlm('{"问题":{"nested":"x"},"方法":"ok"}') })
  await e3.engine.find('grid-forming inverter', {})
  const r3 = await e3.engine.cardFromFindSelection('1', { topic: 'gfm', useLlm: true })
  assert.equal(r3.ok, false)
  assert.equal(e3.scopes.notes.list('').length, 0)

  // 4) 模型调用失败（非 JSON 问题）→ 退回确定性草案，仍然写盘
  const e4 = engineWith({ llm: { available: true, chat: () => (async function* gen() { yield { type: 'error', error: { code: 'E_RATE_LIMITED', message: 'limited' } } })() } })
  await e4.engine.find('grid-forming inverter', {})
  const r4 = await e4.engine.cardFromFindSelection('1', { topic: 'gfm', useLlm: true })
  assert.equal(r4.ok, true, r4.text)
  assert.equal(r4.ui.results[0].generatedBy, 'heuristic')
  assert.equal(e4.scopes.notes.list('gfm').filter((f) => f.endsWith('.md')).length, 1)
})

test('plugin: --heuristic 完全绕开模型（不发任何 LLM 调用）', async () => {
  let chatCalls = 0
  const llm = {
    available: true,
    chat: () => {
      chatCalls += 1
      return (async function* gen() {})()
    },
  }
  const { engine } = engineWith({ llm })
  await engine.find('grid-forming inverter', {})
  const r = await engine.cardFromFindSelection('1,2', { topic: 'gfm', useLlm: false })
  assert.equal(r.ok, true)
  assert.equal(chatCalls, 0, '--heuristic 时不得调用模型')
  assert.equal(r.ui.results[0].generatedBy, 'heuristic')
})

test('plugin: 配置了 S2 key 时才请求 S2，且密钥不进任何输出文本', async () => {
  const scopes = makeMemoryScopes()
  const net = makeStubNet()
  const ctx = makeFakeCtx({ scopes, net, llm: null })
  const engine = createEngine(ctx, {
    scopes,
    secretsLoader: () => ({ openalex: { mailto: 'orbo@example.org' }, semanticscholar: { apiKey: 'S2-SECRET-KEY-abcdef' } }),
  })
  const s = engine.status()
  assert.equal(s.s2Configured, true)
  assert.equal(s.openalexPolite, true)
  const r = await engine.find('grid-forming inverter inertia support', {})
  assert.equal(r.ok, true)
  const hosts = [...new Set(net.calls.map((c) => c.host))].sort()
  assert.deepEqual(hosts, ['api.crossref.org', 'api.openalex.org', 'api.semanticscholar.org', 'export.arxiv.org'])
  const s2call = net.calls.find((c) => c.host === 'api.semanticscholar.org')
  assert.equal(s2call.headers['x-api-key'], 'S2-SECRET-KEY-abcdef')
  assert.ok(s2call.url.includes('mailto=orbo%40example.org') === false, 'S2 不带 openalex 的 mailto')
  const oaCall = net.calls.find((c) => c.host === 'api.openalex.org')
  assert.ok(oaCall.url.includes('mailto='), '配置了 mailto 就该带上')
  // 密钥绝不能出现在任何面向用户的文本/UI payload 里
  const surfaces = JSON.stringify({ text: r.text, ui: r.ui, status: engine.status() })
  assert.ok(!surfaces.includes('S2-SECRET-KEY-abcdef'), '密钥不得泄漏到界面/文本')
  assert.ok(!surfaces.includes('orbo@example.org'), 'mailto 也不进文本')
})

test('plugin: 无 key 且无 mailto 时两个参数都不出现（不臆造）', async () => {
  const scopes = makeMemoryScopes()
  const net = makeStubNet()
  const engine = createEngine(makeFakeCtx({ scopes, net }), { scopes, secretsLoader: () => ({}) })
  await engine.find('grid-forming inverter', {})
  for (const call of net.calls) {
    assert.ok(!call.url.includes('mailto'), `不得出现 mailto：${call.url}`)
    assert.ok(!call.url.includes('@'), `不得臆造邮箱：${call.url}`)
  }
})

test('plugin: activate 注册 1 张卡片 + 6 条命令，且零网络/零数据写入', async () => {
  const scopes = makeMemoryScopes()
  const net = makeStubNet()
  const cards = []
  const commands = []
  const ctx = makeFakeCtx({ scopes, net, llm: null })
  ctx.ui = { registerCard: (c) => cards.push(c), registerCommand: (c) => commands.push(c) }
  const handle = await activate(ctx)
  assert.equal(cards.length, 1)
  assert.equal(cards[0].id, CARD_ID)
  assert.equal(cards[0].title, '文献')
  assert.deepEqual(cards[0].actions, ['find', 'card', 'bib', 'recall', 'verify', 'note'])
  assert.match(cards[0].body, /\/find/)
  assert.match(cards[0].body, /\/verify（引用校验·严谨性检查）/)
  assert.match(cards[0].body, /\/note（笔记操作/)
  assert.deepEqual(commands.map((c) => c.name).sort(), ['bib', 'card', 'card.update', 'find', 'note', 'recall', 'verify'])
  for (const c of commands) assert.equal(typeof c.run, 'function')
  assert.equal(net.calls.length, 0, 'activate 不得出网')
  assert.equal(scopes.notes._writes.length + scopes.index._writes.length + scopes.pdf._writes.length + scopes.exports._writes.length, 0, 'activate 不得写数据')
  assert.equal(typeof handle.deactivate, 'function')
  handle.deactivate()
})

test('plugin: 命令返回的 text 是纯文本，ui 是可结构化渲染的 payload', async () => {
  const scopes = makeMemoryScopes()
  const commands = []
  const ctx = makeFakeCtx({ scopes, net: makeStubNet(), llm: null })
  ctx.ui = { registerCard: () => {}, registerCommand: (c) => commands.push(c) }
  await activate(ctx)
  const find = commands.find((c) => c.name === 'find')
  const out = await find.run('gfm --max 6')
  assert.equal(typeof out.text, 'string')
  assert.equal(out.ok, true)
  assert.equal(out.ui.kind, 'candidates')
  assert.ok(out.text.includes('检索：'))
  assert.ok(!out.text.includes('[object Object]'))
  const bib = commands.find((c) => c.name === 'bib')
  const b = await bib.run('gfm')
  assert.equal(b.code, 'E_NO_CARD', '还没卡片时 /bib 应给出提示')
})

// ---------------------------------------------------------------------------
// 纪律 / 合规
// ---------------------------------------------------------------------------

function listPluginSources(dir) {
  const out = []
  for (const name of readdirSync(dir)) {
    const p = join(dir, name)
    if (statSync(p).isDirectory()) out.push(...listPluginSources(p))
    else if (/\.(mjs|js|json)$/.test(name)) out.push(p)
  }
  return out
}

test('discipline: 插件源码里没有第二条出网出口（不许直接 fetch / http.request）', () => {
  const files = listPluginSources(PLUGIN_DIR)
  assert.ok(files.length >= 12, `插件源文件数偏少：${files.length}`)
  for (const f of files) {
    if (f.endsWith('.json')) continue
    const src = readFileSync(f, 'utf8')
    assert.ok(!/\bfetch\s*\(/.test(src), `${f} 直接调用了 fetch —— 必须走 ctx.net`)
    assert.ok(!/require\(['"]node:https?['"]\)/.test(src), `${f} 直接引了 node:http(s)`)
    assert.ok(!/from\s+['"]node:https?['"]/.test(src), `${f} 直接引了 node:http(s)`)
    assert.ok(!/XMLHttpRequest/.test(src))
  }
})

test('discipline: 插件源码里没有第二条落盘出口（只经 ctx.fs.scope）', () => {
  for (const f of listPluginSources(PLUGIN_DIR)) {
    if (f.endsWith('.json')) continue
    const src = readFileSync(f, 'utf8')
    for (const banned of ['writeFileSync', 'appendFileSync', 'createWriteStream', 'mkdirSync', 'rmSync', 'unlinkSync']) {
      assert.ok(!new RegExp(`\\b${banned}\\b`).test(src), `${f} 出现 ${banned} —— 写操作必须经 scope + safeWrite`)
    }
  }
})

test('discipline: 插件源码不含 sci-hub / 绕过鉴权 / 付费全文抓取的痕迹', () => {
  for (const f of listPluginSources(PLUGIN_DIR)) {
    const src = readFileSync(f, 'utf8')
    assert.ok(!/sci-?hub/i.test(src), `${f} 出现 sci-hub`)
    assert.ok(!/libgen|z-?library|annas-archive/i.test(src), `${f} 出现盗版镜像站`)
    assert.ok(!/bypass|绕过校园网|proxy-pool/i.test(src))
    assert.ok(!/process\.env/.test(src), `${f} 不得读环境变量（凭据只从 secrets.json）`)
  }
})

test('discipline: 插件只用 manifest 声明的作用域，且声明的作用域都在宿主白名单内', () => {
  const manifest = normalizeManifest(JSON.parse(readFileSync(join(PLUGIN_DIR, 'plugin.json'), 'utf8')))
  assert.equal(manifest.id, PLUGIN_ID)
  assert.deepEqual(manifest.scopes, ['exports', 'index', 'notes', 'pdf'])
  assert.deepEqual(manifest.permissions.length > 0, true)
  // 源码里出现的 scope(...) 实参必须都在声明内
  const used = new Set()
  for (const f of listPluginSources(PLUGIN_DIR)) {
    if (f.endsWith('.json')) continue
    for (const m of readFileSync(f, 'utf8').matchAll(/ctx\.fs\.scope\(\s*'([a-z]+)'\s*\)/g)) used.add(m[1])
  }
  assert.deepEqual([...used].sort(), ['exports', 'index', 'notes', 'pdf'])
  for (const s of used) assert.ok(manifest.scopes.includes(s), `${s} 未在 plugin.json 声明`)
})

test('compliance: 未声明的作用域在真宿主上会被拒（fs.scope 抛 E_SCOPE_NOT_GRANTED）', async () => {
  const reg = createRegistry({ core: { net: createNet({ fetchImpl: async () => new Response('{}', { status: 200 }), logFile: logPath('test-literature-net.jsonl') }) } })
  await reg.enable(PLUGIN_ID)
  const rec = reg.list().find((p) => p.id === PLUGIN_ID)
  assert.equal(rec.enabled, true, `插件启用失败：${rec.error}`)
  assert.deepEqual(rec.scopes, ['exports', 'index', 'notes', 'pdf'])
  assert.deepEqual(rec.commands.sort(), ['bib', 'card', 'card.update', 'find', 'note', 'recall', 'verify'])
  assert.equal(rec.cards, 1)
  await reg.disable(PLUGIN_ID)
})

test('compliance: sci-hub 类站点在 core net 上仍然是 deny（阶段 1 行为不被阶段 2 破坏）', async () => {
  const { readFileSync: rf, writeFileSync: wf } = await import('node:fs')
  // 审计日志必须落在唯一可写根内 —— 这本身就是 safefs 在生效：
  // 把 logFile 指到系统临时目录时，net 的 record() 会静默失败（只往 stderr 抱怨一行），
  // 而不是违规写到根外。测试里就用项目内的 logs 目录。
  const logFile = logPath('test-literature-deny.jsonl')
  wf(logFile, '') // 从零开始，便于逐行断言（截断而非删除，见各测试文件头说明）
  const net = createNet({ fetchImpl: async () => new Response('should never be called', { status: 200 }), logFile })
  for (const url of ['https://sci-hub.se/10.1109/x', 'http://sci-hub.se/x', 'https://libgen.is/x', 'https://www.sciencedirect.com/x']) {
    await assert.rejects(() => net.request(url), (e) => e.code === 'E_DOMAIN_NOT_ALLOWED', `${url} 必须被拒`)
  }
  const lines = rf(logFile, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l))
  // S67·3-D·D1 方案 A（追加式）：4 次拒绝落在 3 个 host 上
  //   → 3 条首次 deny 行（count:1）+ 1 条 net-deny-repeat 行（sci-hub.se, count:2）= 4 行
  // 关键不变量两条：① 历史行不被改写；② stats.denied 仍逐次计数（去重不减次数）。
  const firsts = lines.filter((l) => l.kind !== 'net-deny-repeat')
  const repeats = lines.filter((l) => l.kind === 'net-deny-repeat')
  assert.equal(firsts.length, 3, '每个 host 首次拒绝恰好一行')
  assert.equal(repeats.length, 1, '重复拒绝追加一行 net-deny-repeat')
  assert.equal(repeats[0].host, 'sci-hub.se', '重复行指向被重复拒绝的 host')
  assert.equal(repeats[0].count, 2, '重复行 count 累计到 2')
  assert.deepEqual(firsts.map((l) => l.host).sort(), ['libgen.is', 'sci-hub.se', 'www.sciencedirect.com'])
  assert.ok(lines.every((l) => l.decision === 'deny'), '每次拒绝都要留 deny 审计（去重不减次数）')
  assert.equal(net.stats.denied, 4, 'stats.denied 逐次计数')
  assert.equal(net.stats.requests, 0, '被拒的请求绝不能真的发出去')
})

test('compliance: 连接器只使用四个白名单域，且 ENPOINT 全是 https', async () => {
  const urls = []
  for (const f of listPluginSources(join(PLUGIN_DIR, 'connectors'))) {
    for (const m of readFileSync(f, 'utf8').matchAll(/'https:\/\/([a-z0-9.-]+)[^']*'/g)) urls.push(m[1])
  }
  const hosts = [...new Set(urls)].filter((h) => h.includes('.'))
  assert.deepEqual(hosts.sort(), ['api.crossref.org', 'api.openalex.org', 'api.semanticscholar.org', 'export.arxiv.org'])
  for (const h of hosts) assert.ok(STUB_ALLOWED_DOMAINS.includes(h), `${h} 不在 core net 白名单`)
})

test('plugin: DEFAULTS 与文档口径一致', () => {
  assert.equal(DEFAULTS.max, 12)
  assert.equal(DEFAULTS.minCandidates, 5)
  assert.equal(DEFAULTS.topic, 'inbox')
  assert.equal(DEFAULTS.topK, 5)
})

test('plugin: runRecall 的 llm 模式在答案后强制附上代码生成的出处表', async () => {
  const hits = [
    { score: 1, document: { title: 'T1', venue: 'V1', year: 2024, doi: '10.1/a', rel: 'gfm/a.md', body: 'body1' } },
    { score: 0.5, document: { title: 'T2', venue: 'V2', year: 2020, doi: null, url: 'https://x', rel: 'gfm/b.md', body: 'body2' } },
  ]
  const r = await runRecall({
    hits,
    question: 'q',
    llm: { available: true },
    ask: async () => ({ ok: true, text: '结论是 A [1]。', model: 'deepseek-chat' }),
  })
  assert.equal(r.mode, 'llm')
  assert.equal(r.citedByModel, true)
  assert.deepEqual(r.citedNumbers, [1])
  assert.equal(r.citations.length, 2)
  assert.ok(r.answer.includes('出处（由检索层生成'))
  assert.ok(r.answer.includes('gfm/a.md'))
  assert.ok(r.answer.includes('gfm/b.md'), '没被模型引用的卡片也要出现在出处表里')

  // 模型一个引用都没给 → citedByModel=false，但出处表仍在（这就是"硬"的那一手）
  const r2 = await runRecall({ hits, question: 'q', llm: { available: true }, ask: async () => ({ ok: true, text: '没有引用', model: 'm' }) })
  assert.equal(r2.mode, 'llm')
  assert.equal(r2.citedByModel, false)
  assert.ok(r2.answer.includes('出处（由检索层生成'))

  // 模型编号越界 → 记进 invalidCitations，但出处表照出
  const r3 = await runRecall({ hits, question: 'q', llm: { available: true }, ask: async () => ({ ok: true, text: '看 [9]', model: 'm' }) })
  assert.deepEqual(r3.invalidCitations, [9])
  assert.equal(r3.citedByModel, false)
})

test('plugin: hits 为空时 runRecall 给出建议而不是空答案', async () => {
  const r = await runRecall({ hits: [], question: '什么问题', llm: null })
  assert.equal(r.mode, 'empty')
  assert.match(r.answer, /建议先用 \/find/)
  assert.deepEqual(r.citations, [])
})

test('plugin: find 用真实 core net（注入桩 fetch）也能跑通，证明走的是宿主网络层', async () => {
  const logFile = logPath('test-literature-find.jsonl')
  const net = createNet({
    fetchImpl: async (url) => {
      const host = new URL(url).host
      if (host === 'export.arxiv.org') return new Response(arxivFeedXml(8), { status: 200 })
      if (host === 'api.openalex.org') return new Response(JSON.stringify({ meta: { count: 1 }, results: [] }), { status: 200 })
      if (host === 'api.crossref.org') return new Response(JSON.stringify({ message: { 'total-results': 0, items: [] } }), { status: 200 })
      return new Response('{}', { status: 200 })
    },
    logFile,
  })
  const scopes = makeMemoryScopes()
  const engine = createEngine(makeFakeCtx({ scopes, net }), { scopes, secretsLoader: () => ({}) })
  const r = await engine.find('grid-forming inverter inertia support', {})
  assert.equal(r.ok, true)
  // S10 起 find 带行内 DOI 可信标记：候选的 Crossref/OpenAlex 双源校验也走同一 net
  //（同一判定源：connectors 抓取器）。故请求数 = 检索请求 + 每候选 2 次校验；
  // --no-trust 时精确回到 3 次（证明开关生效、检索路径未被改变）。
  assert.ok(net.stats.requests >= 3, `请求应 ≥3（实际 ${net.stats.requests}）`)
  assert.equal(net.stats.denied, 0, '不应有任何 deny')
  const lines = readFileSync(logFile, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l))
  assert.ok(lines.length >= 3)
  assert.ok(lines.every((l) => l.decision === 'allow'))
  assert.ok(lines.every((l) => ['export.arxiv.org', 'api.openalex.org', 'api.crossref.org'].includes(l.host)))
  assert.ok(lines.some((l) => l.bucketKey === 'research-literature:arxiv'), '限速桶键必须按源分桶')

  // --no-trust：请求数精确为 3（只检索，不校验），且 ui 不带 doiTrust
  const logFile2 = logPath('test-literature-find-notrust.jsonl')
  const net2 = createNet({
    fetchImpl: async (url) => {
      const host = new URL(url).host
      if (host === 'export.arxiv.org') return new Response(arxivFeedXml(8), { status: 200 })
      if (host === 'api.openalex.org') return new Response(JSON.stringify({ meta: { count: 1 }, results: [] }), { status: 200 })
      if (host === 'api.crossref.org') return new Response(JSON.stringify({ message: { 'total-results': 0, items: [] } }), { status: 200 })
      return new Response('{}', { status: 200 })
    },
    logFile: logFile2,
  })
  const engine2 = createEngine(makeFakeCtx({ scopes: makeMemoryScopes(), net: net2 }), { scopes: makeMemoryScopes(), secretsLoader: () => ({}) })
  const r2 = await engine2.find('grid-forming inverter inertia support', { 'no-trust': true })
  assert.equal(r2.ok, true)
  assert.equal(net2.stats.requests, 3, '--no-trust 时精确 3 次请求（只检索）')
  assert.equal(r2.ui.trustNote, '（已按 --no-trust 跳过 DOI 校验）')
  assert.ok(r2.ui.candidates.every((c) => c.doiTrust === null), '--no-trust 时不下发 doiTrust')
})
