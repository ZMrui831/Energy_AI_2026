// tests/rigor.test.mjs
//
// 严谨性修正（P-R4 块 2）的离线回归：数值与单位校验、元数据完整性、强度三档强制渲染。
// 本文件全部离线——数值/元数据都是纯函数；渲染用例的断言结果手搓（形状与
// verifyAssertion 的产出一致），真实世界用例由 tools/accept-stage4-block2.mjs 取证。
//
// 验收口径在本文件里的对应：
//   一段输出同时含三档 + 未验证断言区   → renderRigorAnswer 用例
//   数值回溯原文（命中/不命中/未提供）  → traceQuantity + checkQuantities 用例
//   量纲不一致警告                     → checkQuantityConsistency 用例
//   元数据缺项显式提示                 → assessMetaCompleteness 用例

import test from 'node:test'
import assert from 'node:assert/strict'

import {
  UNIT_RANGES,
  assessMetaCompleteness,
  canonicalUnit,
  checkQuantities,
  checkQuantityConsistency,
  extractQuantities,
  parseQuantityNumber,
  renderMetaCompleteness,
  renderQuantityReport,
  renderRigorAnswer,
  renderStrengthLegend,
  traceQuantity,
} from '../packages/plugins/research-literature/lib/rigor.mjs'
import { renderVerifiedAnswer } from '../packages/plugins/research-literature/lib/cite-verify.mjs'

const q1 = (text) => extractQuantities(text)[0]

// ---------------------------------------------------------------------------
// 数值抽取
// ---------------------------------------------------------------------------

test('extractQuantities: 基本形态（紧贴/空格/千分位/科学计数/负号/约等号）', () => {
  assert.deepEqual(
    extractQuantities('12.5MW').map((q) => [q.value, q.unit]),
    [[12.5, 'MW']],
  )
  assert.deepEqual(
    extractQuantities('rated 1,234.5 MVA').map((q) => [q.value, q.unit]),
    [[1234.5, 'MVA']],
  )
  assert.deepEqual(
    extractQuantities('voltage 0.98 p.u. and 0.98pu').map((q) => [q.value, q.unit]),
    [
      [0.98, 'p.u.'],
      [0.98, 'p.u.'],
    ],
  )
  assert.deepEqual(
    extractQuantities('50 Hz, 3.5 H, 3.5 h, 110 kV').map((q) => [q.value, q.unit]),
    [
      [50, 'Hz'],
      [3.5, 'H'],
      [3.5, 'h'],
      [110, 'kV'],
    ],
  )
  assert.deepEqual(
    extractQuantities('25 % / 25 percent / 25percent / 25 pct').map((q) => [q.value, q.unit]),
    [
      [25, '%'],
      [25, '%'],
      [25, '%'],
      [25, '%'],
    ],
  )
  assert.deepEqual(
    extractQuantities('≈3.5 MW and -5 MW and 1.5e3 kW').map((q) => [q.value, q.unit]),
    [
      [3.5, 'MW'],
      [-5, 'MW'],
      [1500, 'kW'],
    ],
  )
})

test('extractQuantities: H 与 h 大小写分流（惯量常数 vs 小时）', () => {
  assert.equal(q1('inertia constant H = 3.5 H').unit, 'H')
  assert.equal(q1('time constant 3.5 h').unit, 'h')
  // UNIT_RANGES 只给 H（惯量）定了范围，h（小时）没有——分流错了会把小时当惯量校验
  assert.ok(UNIT_RANGES.H)
  assert.equal(UNIT_RANGES.h, undefined)
})

test('extractQuantities: 认不出单位的数字被跳过（噪声控制）', () => {
  assert.deepEqual(extractQuantities('Section 2 and Section 3'), [])
  assert.deepEqual(extractQuantities('a modified IEEE 9-bus system'), [])
  assert.deepEqual(extractQuantities('5 And 6 And'), [])
  // 编号里的年份（前面是连字符）不是数量；区间 "5-10 MW" 整体不解析（漏掉比解析错安全）
  assert.deepEqual(extractQuantities('TPWRS-2024 paper'), [])
  assert.deepEqual(extractQuantities('range 5-10 MW'), [])
  // 裸年份后跟普通单词：单位认不出 → 跳过
  assert.deepEqual(extractQuantities('the 2021 paper studies'), [])
})

test('parseQuantityNumber: 四种数字形态', () => {
  assert.equal(parseQuantityNumber('1,234.5'), 1234.5)
  assert.equal(parseQuantityNumber('3,5'), 3.5) // 欧式小数逗号（1-2 位）
  assert.equal(parseQuantityNumber('3,500'), 3500) // 三位按千分位
  assert.equal(parseQuantityNumber('1.5e3'), 1500)
  assert.equal(parseQuantityNumber('-0.98'), -0.98)
  assert.equal(parseQuantityNumber('1.234'), 1.234) // 英式：这就是小数
  assert.equal(parseQuantityNumber('abc'), null)
  assert.equal(parseQuantityNumber(''), null)
})

test('canonicalUnit: 大小写归一与句末点容忍', () => {
  assert.equal(canonicalUnit('MW'), 'MW')
  assert.equal(canonicalUnit('mw'), 'MW')
  assert.equal(canonicalUnit('MVA'), 'MVA')
  assert.equal(canonicalUnit('p.u.'), 'p.u.')
  assert.equal(canonicalUnit('PU'), 'p.u.')
  assert.equal(canonicalUnit('p.u'), 'p.u.')
  assert.equal(canonicalUnit('Hz.'), 'Hz') // 句末标点粘在单位上
  assert.equal(canonicalUnit('percent'), '%')
  assert.equal(canonicalUnit('H'), 'H')
  assert.equal(canonicalUnit('h'), 'h')
  assert.equal(canonicalUnit('bus'), null)
  assert.equal(canonicalUnit(''), null)
  assert.equal(canonicalUnit(null), null)
})

// ---------------------------------------------------------------------------
// 回溯原文
// ---------------------------------------------------------------------------

test('traceQuantity: 命中容忍空白/大小写/千分位/小数逗号差异', () => {
  assert.deepEqual(traceQuantity({ value: 32, unit: '%' }, 'show improved frequency nadir by 32 percent.'), {
    traced: true,
    matchedForm: '32percent',
  })
  assert.equal(traceQuantity({ value: 32, unit: '%' }, 'BY 32 PERCENT').traced, true)
  assert.equal(traceQuantity({ value: 1234, unit: 'MW' }, 'rated at 1,234 MW').traced, true)
  assert.equal(traceQuantity({ value: 1234, unit: 'MW' }, 'rated at 1234 MW').traced, true) // 原文没写千分位
  assert.equal(traceQuantity({ value: 3.5, unit: 'MW' }, 'value of 3,5 MW').traced, true) // 原文用欧式逗号
  // 换行断字：归一去空白后照样命中
  assert.equal(traceQuantity({ value: 50, unit: 'Hz' }, 'system frequency is 50\nHz nominal').traced, true)
})

test('traceQuantity: 不命中与未提供原文是两回事', () => {
  assert.equal(traceQuantity({ value: 90, unit: '%' }, 'show improved frequency nadir by 32 percent.').traced, false)
  assert.equal(traceQuantity({ value: 32, unit: '%' }, null).traced, null) // 未提供原文
  assert.equal(traceQuantity({ value: 32, unit: '%' }, '   ').traced, null)
})

test('checkQuantities: 有原文逐条回溯；无原文 trace=null 且 untraced 为空', () => {
  const src = 'Simulations show improved frequency nadir by 32 percent.'
  const hit = checkQuantities({ text: 'nadir improved by 32 percent', sourceText: src })
  assert.equal(hit.tracedCount, 1)
  assert.equal(hit.untraced.length, 0)

  const miss = checkQuantities({ text: 'nadir improved by 90 percent', sourceText: src })
  assert.equal(miss.tracedCount, 0)
  assert.equal(miss.untraced.length, 1)
  assert.equal(miss.untraced[0].value, 90)

  // 没有原文：无法回溯 ≠ 回溯失败，untraced 必须为空（不能把环境缺失当成引用失败）
  const noSrc = checkQuantities({ text: 'nadir improved by 90 percent' })
  assert.equal(noSrc.trace, null)
  assert.equal(noSrc.untraced.length, 0)
})

// ---------------------------------------------------------------------------
// 量纲一致性
// ---------------------------------------------------------------------------

test('checkQuantityConsistency: p.u. 多功率基准 → 警告', () => {
  const one = checkQuantityConsistency([], 'All per-unit values are on a 100 MVA base.')
  assert.equal(one.warnings.length, 0)
  const two = checkQuantityConsistency([], 'Values are on a 100 MVA base, later converted to the 50 MVA base.')
  assert.equal(two.warnings.length, 1)
  assert.equal(two.warnings[0].code, 'PU_BASE_MISMATCH')
  assert.match(two.warnings[0].message, /100 MVA \/ 50 MVA/)
  // S_B / 基准容量 声明式也认
  const sb = checkQuantityConsistency([], 'S_B = 100 MVA；折算到 基准容量 50MVA 系统')
  assert.equal(sb.warnings.length, 1)
  assert.equal(sb.warnings[0].code, 'PU_BASE_MISMATCH')
})

test('checkQuantityConsistency: MW 与 MVA 混用 / 有功大于视在 → 警告', () => {
  const confused = checkQuantityConsistency(extractQuantities('rated 100 MW, apparent 100 MVA'), 'rated 100 MW, apparent 100 MVA')
  assert.equal(confused.warnings.length, 1)
  assert.equal(confused.warnings[0].code, 'MW_MVA_CONFUSED')

  const pgt = checkQuantityConsistency(extractQuantities('P = 200 MW while S = 100 MVA'), 'P = 200 MW while S = 100 MVA')
  assert.equal(pgt.warnings.length, 1)
  assert.equal(pgt.warnings[0].code, 'P_GT_S')

  const fine = checkQuantityConsistency(extractQuantities('P = 50 MW while S = 100 MVA'), 'P = 50 MW while S = 100 MVA')
  assert.equal(fine.warnings.length, 0)
})

test('checkQuantityConsistency: kV 与 p.u. 并存未声明电压基准 → 提示（有声明则不提示）', () => {
  const qs = extractQuantities('voltage 0.98 p.u. at 110 kV bus')
  const noBase = checkQuantityConsistency(qs, 'voltage 0.98 p.u. at 110 kV bus')
  assert.equal(noBase.notes.length, 1)
  assert.equal(noBase.notes[0].code, 'PU_V_BASE_MISSING')
  const withBase = checkQuantityConsistency(qs, 'voltage 0.98 p.u. at 110 kV bus, V_B = 110 kV')
  assert.equal(withBase.notes.length, 0)
})

test('checkQuantityConsistency: 数量级范围警告（Hz/H/p.u./%）', () => {
  const hz = checkQuantityConsistency(extractQuantities('frequency dropped to 80 Hz'), 'frequency dropped to 80 Hz')
  assert.equal(hz.warnings.length, 1)
  assert.match(hz.warnings[0].message, /超出工频常见范围 \[45, 66\]/)

  const inertia = checkQuantityConsistency(extractQuantities('H = 0.5 H'), 'H = 0.5 H')
  assert.equal(inertia.warnings.length, 1)
  assert.match(inertia.warnings[0].message, /超出惯性时间常数常见范围 \[1, 20\]/)

  const pu = checkQuantityConsistency(extractQuantities('impedance 35 p.u.'), 'impedance 35 p.u.')
  assert.equal(pu.warnings.length, 1)
  assert.match(pu.warnings[0].message, /超出标幺值常见范围 \[-30, 30\]/)

  const pct = checkQuantityConsistency(extractQuantities('efficiency 120 %'), 'efficiency 120 %')
  assert.equal(pct.warnings.length, 1)
  assert.match(pct.warnings[0].message, /超出百分比常见范围 \[0, 100\]/)

  // 常见值不误报
  const ok = checkQuantityConsistency(extractQuantities('50 Hz, H = 3.5 H, 0.98 p.u., 32 %'), '50 Hz, H = 3.5 H, 0.98 p.u., 32 %')
  assert.equal(ok.warnings.length, 0)
})

// ---------------------------------------------------------------------------
// 元数据完整性
// ---------------------------------------------------------------------------

test('assessMetaCompleteness: 完整 DOI 期刊题录无缺项', () => {
  const a = assessMetaCompleteness({
    kind: 'doi',
    ref: '10.1109/lcsys.2020.3044551',
    meta: { title: 'Grid-Forming Frequency Shaping Control', year: 2021, authors: ['Yan Jiang'], venue: 'IEEE Control Systems Letters', doi: '10.1109/lcsys.2020.3044551' },
    status: 'verified',
    checkedAt: '2026-10-15T12:00:00.000Z',
  })
  assert.equal(a.isPreprint, false)
  assert.equal(a.version, null)
  assert.equal(a.hasDoi, true)
  assert.equal(a.retrievalTime, '2026-10-15T12:00:00.000Z')
  assert.deepEqual(a.missing, [])
})

test('assessMetaCompleteness: arXiv URL → 预印本 + 版本 + 无 DOI 缺项', () => {
  const a = assessMetaCompleteness({
    kind: 'url',
    ref: 'https://arxiv.org/abs/1706.03762v2',
    meta: { title: '[1706.03762v2] Attention Is All You Need', url: 'https://arxiv.org/abs/1706.03762v2' },
    status: 'verified',
    checkedAt: '2026-10-15T12:00:00.000Z',
  })
  assert.equal(a.isPreprint, true)
  assert.equal(a.version, 'v2')
  assert.equal(a.hasDoi, false)
  assert.ok(a.missing.some((m) => /无 DOI/.test(m)))
  assert.ok(a.notes.some((n) => /未经同行评审/.test(n)))
})

test('assessMetaCompleteness: 预印本缺版本 → 显式提示', () => {
  const a = assessMetaCompleteness({
    kind: 'doi',
    ref: '10.48550/arxiv.2401.0100',
    meta: { title: 'Some preprint', year: 2024, authors: ['A B'], venue: 'arXiv preprint' },
    status: 'verified',
    checkedAt: '2026-10-15T12:00:00.000Z',
  })
  assert.equal(a.isPreprint, true)
  assert.equal(a.version, null)
  assert.ok(a.missing.some((m) => /预印本未标注 arXiv 版本/.test(m)))
})

test('assessMetaCompleteness: 非预印本不误报（venue/ref 都不含预印本特征）', () => {
  const a = assessMetaCompleteness({
    kind: 'doi',
    ref: '10.1109/tpwrs.2024.1',
    meta: { title: 'T', year: 2024, authors: ['A B'], venue: 'IEEE Transactions on Power Systems' },
    status: 'verified',
    checkedAt: '2026-10-15T12:00:00.000Z',
  })
  assert.equal(a.isPreprint, false)
  assert.equal(a.preprintEvidence, null)
})

test('assessMetaCompleteness: 被拒/无法校验的 DOI → 可解析性缺项显式提示', () => {
  const rejected = assessMetaCompleteness({
    kind: 'doi',
    ref: '10.9999/fake.doi.12345',
    meta: null,
    status: 'rejected',
    reason: 'Crossref 与 OpenAlex 均未收录该 DOI',
    checkedAt: '2026-10-15T12:00:00.000Z',
  })
  assert.ok(rejected.missing.some((m) => /DOI 可解析性校验未通过（拒引）/.test(m)))
  const unverifiable = assessMetaCompleteness({
    kind: 'doi',
    ref: '10.1109/tpwrs.2024.1',
    meta: null,
    status: 'unverifiable',
    reason: '网络错误',
    checkedAt: '2026-10-15T12:00:00.000Z',
  })
  assert.ok(unverifiable.missing.some((m) => /DOI 可解析性未校验完成（环境原因，可重试）/.test(m)))
  // URL/PDF 来源的被拒不是"DOI 可解析性"问题，不套用该缺项
  const urlRejected = assessMetaCompleteness({ kind: 'url', ref: 'https://example.org/x', meta: null, status: 'rejected', reason: '标题不匹配', checkedAt: 't' })
  assert.ok(!urlRejected.missing.some((m) => /DOI 可解析性/.test(m)))
})

test('assessMetaCompleteness: 检索时间缺失与题录缺项逐条提示', () => {
  const a = assessMetaCompleteness({
    kind: 'doi',
    ref: '10.1109/tpwrs.2024.1',
    meta: { title: 'T', year: null, authors: [], venue: '' },
    status: 'verified',
    checkedAt: null,
  })
  assert.ok(a.missing.some((m) => /未记录检索时间/.test(m)))
  assert.ok(a.missing.some((m) => /题录缺年份/.test(m)))
  assert.ok(a.missing.some((m) => /题录缺作者/.test(m)))
  assert.ok(a.missing.some((m) => /题录缺发表 venue/.test(m)))
})

// ---------------------------------------------------------------------------
// 渲染
// ---------------------------------------------------------------------------

test('renderStrengthLegend: 三档枚举同屏（与 STRENGTH_DESC 同源）', () => {
  const legend = renderStrengthLegend()
  assert.match(legend, /已证实（有原文出处且通过引用校验）/)
  assert.match(legend, /推断（模型推理，无原文出处）/)
  assert.match(legend, /待验证（无来源或校验未通过，不得作为结论）/)
})

test('renderVerifiedAnswer: strengthLegend 默认关（块 1 输出不变），开时图例前置', () => {
  const assertions = [
    { text: '一条已证实的结论', effective: 'proven', verified: [{ kind: 'doi', ref: '10.1109/x', status: 'verified', confidence: 1, strong: true, meta: { title: 'T' }, resolvedBy: 'crossref' }], rejected: [], unverifiable: [] },
  ]
  const off = renderVerifiedAnswer({ assertions })
  assert.ok(!off.includes('强度口径'))
  const on = renderVerifiedAnswer({ assertions, strengthLegend: true })
  assert.match(on, /强度口径：已证实/)
  // 图例在结论区之前
  assert.ok(on.indexOf('强度口径') < on.indexOf('【结论】'))
})

/** 手搓一份 verifyAssertion 形状的结果（proven + inferred + unverified 三档俱全）。 */
function mixedAssertions() {
  return [
    {
      id: 'a1',
      text: '构网型控制可改善频率最低点。',
      claimed: 'proven',
      effective: 'proven',
      downgraded: false,
      downgradeReason: null,
      confidence: 1,
      verified: [
        {
          kind: 'pdf',
          ref: 'data/fixtures/sample-paper.pdf',
          locator: { quote: 'Simulations on a modified IEEE 9-bus system show improved frequency nadir by 32 percent.', page: null, section: null },
          status: 'verified',
          confidence: 1,
          strong: true,
          metaChecked: true,
          meta: null,
          resolvedBy: null,
          reason: null,
          detail: { pdfPages: 1, pdfChars: 631, quoteChars: 88, hitPage: 1, claimedPage: null, pageVerified: null },
          checkedAt: '2026-10-15T12:00:00.000Z',
        },
      ],
      rejected: [],
      unverifiable: [],
      unverified: false,
    },
    {
      id: 'a2',
      text: '惯量常数量级可能与同步机相当。',
      claimed: 'inferred',
      effective: 'inferred',
      downgraded: false,
      downgradeReason: null,
      confidence: null,
      verified: [],
      rejected: [],
      unverifiable: [],
      unverified: false,
    },
    {
      id: 'a3',
      text: '该系统频率最低点改善 90 percent。',
      claimed: 'proven',
      effective: 'unverified',
      downgraded: true,
      downgradeReason: '全部 1 个来源校验失败',
      confidence: null,
      verified: [],
      rejected: [
        {
          kind: 'pdf',
          ref: 'data/fixtures/sample-paper.pdf',
          locator: { quote: 'improved frequency nadir by 90 percent', page: null, section: null },
          status: 'rejected',
          confidence: null,
          strong: false,
          metaChecked: false,
          meta: null,
          resolvedBy: null,
          reason: '引文未在 PDF 全文中逐字命中',
          detail: null,
          checkedAt: '2026-10-15T12:00:00.000Z',
        },
      ],
      unverifiable: [],
      unverified: true,
    },
  ]
}

test('renderRigorAnswer: 一段输出同屏三档 + 未验证断言区 + 严谨性两区', () => {
  const text = renderRigorAnswer({
    lead: '总装测试',
    assertions: mixedAssertions(),
    rigor: {
      quantities: [
        { label: '构网型控制可改善频率最低点。', quantities: [{ raw: '32 %', value: 32, unit: '%' }], trace: [{ quantity: { raw: '32 %', value: 32, unit: '%' }, traced: true, matchedForm: '32percent' }], untraced: [], consistency: { warnings: [], notes: [] } },
        { label: '该系统频率最低点改善 90 percent。', quantities: [{ raw: '90 %', value: 90, unit: '%' }], trace: null, untraced: [], consistency: { warnings: [], notes: [] } },
      ],
      meta: [
        { label: 'PDF data/fixtures/sample-paper.pdf', assessment: assessMetaCompleteness({ kind: 'pdf', ref: 'data/fixtures/sample-paper.pdf', meta: null, status: 'verified', checkedAt: '2026-10-15T12:00:00.000Z' }) },
      ],
    },
  })

  // 三档同屏（图例 + 每条结论的档位标注）
  assert.match(text, /强度口径：已证实/)
  assert.match(text, /构网型控制可改善频率最低点。 \[1\] —— 已证实/)
  assert.match(text, /惯量常数量级可能与同步机相当。 —— 推断/)
  assert.match(text, /【未验证断言】/)
  assert.match(text, /该系统频率最低点改善 90 percent。 —— 待验证（全部 1 个来源校验失败）/)

  // unverified 断言绝不进结论区
  const conclusion = text.slice(text.indexOf('【结论】'), text.indexOf('【来源清单】'))
  assert.ok(!conclusion.includes('90 percent'))

  // 严谨性两区
  assert.match(text, /【数值与单位】/)
  assert.match(text, /提示｜该系统频率最低点改善 90 percent。：未提供原文，1 个数值无法回溯/)
  assert.match(text, /【元数据提示】/)
  assert.match(text, /缺项｜PDF data\/fixtures\/sample-paper.pdf：无 DOI/)
})

test('renderQuantityReport: 逐条回溯状态 + 结尾结论（命中/失败/未提供）', () => {
  const withSrc = renderQuantityReport({
    text: 'nadir improved by 32 percent and 90 percent',
    sourceText: 'Simulations show improved frequency nadir by 32 percent.',
    sourceLabel: 'sample-paper.pdf',
  })
  assert.match(withSrc.text, /回溯原文：已提供（sample-paper.pdf，\d+ 字符）/)
  assert.match(withSrc.text, /32 %｜已回溯命中（32percent）/)
  assert.match(withSrc.text, /90 %｜回溯失败/)
  assert.match(withSrc.text, /→ 1 个数值未能在来源中回溯/)

  const noSrc = renderQuantityReport({ text: 'nadir improved by 32 percent' })
  assert.match(noSrc.text, /未提供（未给 --pdf），数值无法回溯/)
  assert.match(noSrc.text, /32 %｜未回溯/)
  assert.match(noSrc.text, /→ 未发现未回溯数值。/)

  const warn = renderQuantityReport({ text: 'values on a 100 MVA base then 50 MVA base' })
  assert.match(warn.text, /量纲一致性警告：/)
  assert.match(warn.text, /检测到多个功率基准/)
})

test('renderMetaCompleteness: 四行事实 + 缺项/提示分区', () => {
  const a = assessMetaCompleteness({
    kind: 'url',
    ref: 'https://arxiv.org/abs/1706.03762v2',
    meta: { title: 'T', url: 'https://arxiv.org/abs/1706.03762v2' },
    status: 'verified',
    checkedAt: '2026-10-15T12:00:00.000Z',
  })
  const text = renderMetaCompleteness(a)
  assert.match(text, /预印本：是（arXiv 1706\.03762v2）/)
  assert.match(text, /版本：v2/)
  assert.match(text, /DOI：无/)
  assert.match(text, /检索时间：2026-10-15T12:00:00\.000Z/)
  assert.match(text, /缺项（显式提示，需人工补全或降级使用）：/)
  assert.match(text, /缺项｜无 DOI：无法经 Crossref\/OpenAlex 独立核验题录/)
})
