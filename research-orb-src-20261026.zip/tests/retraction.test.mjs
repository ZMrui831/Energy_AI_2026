// tests/retraction.test.mjs
import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  parseRetraction, lookupRetraction, tagRetracted, assertRetractionGate, RetractionError,
} from '../packages/plugins/research-literature/connectors/retraction.mjs'

test('parseRetraction：Crossref 标题前缀 RETRACTED: 命中', () => {
  const r = parseRetraction({ crossrefMessage: { title: 'RETRACTED: Some paper', type: 'journal-article' } })
  assert.equal(r.retracted, true)
  assert.equal(r.source, 'crossref')
  assert.ok(r.signals.crossref_titlePrefix)
})

test('parseRetraction：OpenAlex is_retracted=true 命中', () => {
  const r = parseRetraction({ openalexWork: { is_retracted: true } })
  assert.equal(r.retracted, true)
  assert.equal(r.source, 'openalex')
})

test('parseRetraction：update[] update-type 含 retract 命中', () => {
  const r = parseRetraction({ crossrefMessage: { update: [{ 'update-type': 'retraction', DOI: 'x' }] } })
  assert.equal(r.retracted, true)
  assert.ok(r.signals.crossref_updateType)
})

test('parseRetraction：无任何信号不命中', () => {
  const r = parseRetraction({ crossrefMessage: { title: 'Normal paper' }, openalexWork: { is_retracted: false } })
  assert.equal(r.retracted, false)
  assert.equal(r.source, null)
})

test('tagRetracted：命中返回 [已撤稿]，否则空串', () => {
  assert.equal(tagRetracted({ retracted: true }), '[已撤稿]')
  assert.equal(tagRetracted({ retracted: false }), '')
})

test('assertRetractionGate：命中撤稿 + 已证实话术 → 抛 E_RETRACTED_VERIFIED', () => {
  assert.throws(
    () => assertRetractionGate({ doi: '10.1/x', retracted: true, text: '该撤稿论文已证实有效' }),
    (e) => e instanceof RetractionError && e.code === 'E_RETRACTED_VERIFIED' && /待核实|假设/.test(e.guidance),
  )
})

test('assertRetractionGate：命中撤稿 + 假设语气 → 放行', () => {
  const r = assertRetractionGate({ doi: '10.1/x', retracted: true, text: '假设该结论存疑，待核实原始撤稿声明' })
  assert.equal(r.ok, true)
})

test('assertRetractionGate：未撤稿不受限', () => {
  const r = assertRetractionGate({ doi: '10.1/y', retracted: false, text: '该论文已证实有效' })
  assert.equal(r.ok, true)
})

test('lookupRetraction：经可注入 getJson 离线复现（Wakefield）', async () => {
  const getJson = async (url) => {
    if (url.includes('crossref')) return { message: { title: 'RETRACTED: Wakefield MMR' } }
    if (url.includes('openalex')) return { is_retracted: true }
    return {}
  }
  const r = await lookupRetraction('10.1016/S0140-6736(97)11096-0', { getJson })
  assert.equal(r.retracted, true)
  assert.equal(tagRetracted(r), '[已撤稿]')
})
