// tests/coach.test.mjs —— S25·1A 目标与蓝图：读写/digest 预算/注入开关/模板回落
// 纪律：目录全部注入 data/tmp（隔离）；不动 data/config.json（无需复位）。
import { test, beforeEach, afterEach } from 'node:test'
import assert from 'node:assert/strict'
import { mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, dataPath } from '../packages/core/src/safefs.mjs'
import { readGoal, setGoal, readBlueprint, writeBlueprint, templateBlueprint, regenBlueprint, CoachError } from '../packages/plugins/coach/engine.mjs'
import { readCoachSystemContext, estimateTokens, COACH_DIGEST_MAX_TOKENS } from '../packages/core/src/coach-context.mjs'

const ROOT = dataPath('tmp', 's25-coach-test')
let DIR
let n = 0

beforeEach(() => {
  n += 1
  DIR = `${ROOT}-${n}`
  rmSync(DIR, { recursive: true, force: true })
  mkdirSync(DIR, { recursive: true })
})
afterEach(() => { rmSync(DIR, { recursive: true, force: true }) })

test('coach: goal set 写入并可读回；空/超长拒绝', () => {
  const rec = setGoal('两周内完成微电网综述初稿', { dir: DIR })
  assert.equal(rec.goal, '两周内完成微电网综述初稿')
  assert.equal(readGoal(DIR).goal, '两周内完成微电网综述初稿')
  assert.throws(() => setGoal('   ', { dir: DIR }), (e) => e.code === 'E_EMPTY_GOAL')
  assert.throws(() => setGoal('x'.repeat(501), { dir: DIR }), (e) => e.code === 'E_GOAL_TOO_LONG')
})

test('coach: blueprint edit 覆写；外部直接改文件后 readBlueprint 即时生效', () => {
  writeBlueprint('v1 蓝图', { dir: DIR })
  assert.match(readBlueprint(DIR), /v1 蓝图/)
  writeFileSync(join(DIR, 'blueprint.md'), '外部手改的 v2', 'utf8')
  assert.equal(readBlueprint(DIR).trim(), '外部手改的 v2')
  assert.throws(() => writeBlueprint('  ', { dir: DIR }), (e) => e.code === 'E_EMPTY_BLUEPRINT')
})

test('coach: regen LLM 成功 → source=llm 写盘；LLM 失败 → 回落模板 source=template', async () => {
  const okRouter = { run: async () => ({ ok: true, text: '1. 拆子问题\n2. 检索文献\n3. 立结论并挂证据\n4. 出图表', providerId: 'deepseek-api', model: 'deepseek-chat', fallback: false }) }
  const r1 = await regenBlueprint({ router: okRouter, dir: DIR })
  assert.equal(r1.source, 'llm')
  assert.match(readBlueprint(DIR), /检索文献/)
  const badRouter = { run: async () => ({ ok: false, tier: 'flagship', error: { code: 'E_HTTP_500', message: 'down' } }) }
  const r2 = await regenBlueprint({ router: badRouter, dir: DIR })
  assert.equal(r2.source, 'template')
  assert.equal(r2.fallback, true)
  assert.match(readBlueprint(DIR), /研究蓝图（模板/)
})

test('coach: digest 注入含画像+目标+蓝图三段', () => {
  const rootDir = DIR
  mkdirSync(join(rootDir, 'data', 'coach'), { recursive: true })
  writeFileSync(join(rootDir, 'data', 'profile.json'), JSON.stringify({ personalization: true }), 'utf8')
  writeFileSync(join(rootDir, 'data', 'profile-digest.txt'), '研究生二年级，方向智能电网', 'utf8')
  setGoal('两周内完成微电网综述初稿', { dir: join(rootDir, 'data', 'coach') })
  writeBlueprint('1. 定范围\n2. 找文献', { dir: join(rootDir, 'data', 'coach') })
  const sys = readCoachSystemContext({ root: rootDir })
  assert.match(sys, /【用户画像】/)
  assert.match(sys, /【用户目标】/)
  assert.match(sys, /【研究蓝图（摘要）】/)
})

test('coach: digest 总量 ≤700 token（长蓝图被压缩而非溢出）', () => {
  const rootDir = DIR
  mkdirSync(join(rootDir, 'data', 'coach'), { recursive: true })
  writeFileSync(join(rootDir, 'data', 'profile.json'), JSON.stringify({ personalization: true }), 'utf8')
  writeFileSync(join(rootDir, 'data', 'profile-digest.txt'), '画像摘要。'.repeat(120), 'utf8')
  setGoal('目标 X', { dir: join(rootDir, 'data', 'coach') })
  writeBlueprint('蓝图行。'.repeat(800), { dir: join(rootDir, 'data', 'coach') })
  const sys = readCoachSystemContext({ root: rootDir })
  assert.ok(estimateTokens(sys) <= COACH_DIGEST_MAX_TOKENS, `tokens=${estimateTokens(sys)}`)
})

test('coach: 未开个性化 → digest 不含画像段但仍注入目标/蓝图；空库 → 不注入（无记忆不注入前置）', () => {
  const rootDir = DIR
  mkdirSync(join(rootDir, 'data', 'coach'), { recursive: true })
  writeFileSync(join(rootDir, 'data', 'profile.json'), JSON.stringify({ personalization: false }), 'utf8')
  writeFileSync(join(rootDir, 'data', 'profile-digest.txt'), '不该出现的画像', 'utf8')
  setGoal('目标 Y', { dir: join(rootDir, 'data', 'coach') })
  writeBlueprint('蓝图 Z', { dir: join(rootDir, 'data', 'coach') })
  const sys = readCoachSystemContext({ root: rootDir })
  assert.doesNotMatch(sys, /不该出现的画像/)
  assert.match(sys, /【用户目标】/)

  // 空库：连 coach 目录都没有 → ''
  const empty = readCoachSystemContext({ root: join(DIR, 'no-coach') })
  assert.equal(empty, '')
})

test('coach: 模板蓝图含目标文本与可核验步骤', () => {
  const t = templateBlueprint('微电网综述')
  assert.match(t, /微电网综述/)
  assert.match(t, /定范围/)
  assert.match(t, /chart bars/)
})
