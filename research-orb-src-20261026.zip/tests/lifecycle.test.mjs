// tests/lifecycle.test.mjs —— S3 清理状态机（cleaner.mjs + lifecycle-worker.mjs）回归：≥15 例。
//
// 覆盖判据：1（失败不丢 file_path、重跑不重复删）、2（deleting 续跑）、
// 3（observation 墓碑 + evidence 仍可引用）、4（敏感永不落盘）、5（2000 帧字节回落，
// sqlite）、7（jsonl 降级路径全部用例都跑）、孤儿治理、stuck 熔断、worker CLI 冒烟。
//
// 夹具：data/db/ 下 mkdtemp 目录（根内，safefs 放行），try/finally 清理。
// 运行环境：node:sqlite 用 D:\node.exe（Node>=23.4）；不可用时 sqlite 用例真 skip。

import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, mkdirSync, writeFileSync, existsSync, readdirSync, rmSync, statSync } from 'node:fs'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'
import { tmpdir } from 'node:os'

import { createStore, detectSqlite, mergeLifecycleConfig, computeExpiry, DbError } from '../packages/core/src/db.mjs'
import { runCleanup, CLEANUP_STATS_KEYS } from '../packages/core/src/lifecycle/cleaner.mjs'
import { PROJECT_ROOT, dataPath } from '../packages/core/src/safefs.mjs'

const hasSqlite = await detectSqlite()
const SQLITE_SKIP = hasSqlite ? false : 'node:sqlite unavailable（需要 Node>=23.4，用 D:\\node.exe）'

const HOUR = 3_600_000
const DAY = 86_400_000

function makeFixture(label) {
  mkdirSync(dataPath('db'), { recursive: true })
  const dir = mkdtempSync(dataPath('db', `lctest-${label}-`))
  const fx = {
    dir,
    dbPath: join(dir, 'orb.sqlite'),
    dataDir: dir,
    shotsDir: join(dir, 'shots'),
    trashDir: join(dir, 'trash'),
    configPath: join(dir, 'lifecycle-config.json'),
  }
  mkdirSync(fx.shotsDir, { recursive: true })
  writeFileSync(fx.configPath, JSON.stringify(mergeLifecycleConfig({ cleanup: { batchSize: 2500 } })), 'utf8')
  return fx
}

function rmFixture(fx) {
  try {
    rmSync(fx.dir, { recursive: true, force: true })
  } catch {
    // 宿主环境的 safe-delete shim 可能把 rmSync 升级成回收站操作并偶发失败；
    // 派生一个不带 NODE_OPTIONS shim 的子进程做原生删除兜底。
    const r = spawnSync(
      process.execPath,
      ['-e', "const fs=require('node:fs');fs.rmSync(process.argv[1],{recursive:true,force:true})", fx.dir],
      { env: { ...process.env, NODE_OPTIONS: '' }, timeout: 30_000 },
    )
    if (r.status !== 0 && existsSync(fx.dir)) {
      // 仍失败则留下夹具（data/db/lctest-* 残留可手工清理），不让清理噪声污染测试结果
    }
  }
}

function sha() {
  return 'b'.repeat(64)
}

/** 造一个真实 png 夹具文件（纯测试数据，走 node:fs 直写，仅存在于根内夹具目录）。 */
function makePng(dir, name) {
  const p = join(dir, name)
  writeFileSync(p, 'PNGFIXTURE-' + name, 'utf8')
  return p
}

const PAST = new Date(Date.now() - HOUR).toISOString() // 已过期
const FUTURE = new Date(Date.now() + 2 * HOUR).toISOString() // 未过期

async function insertExpired(store, id, filePath) {
  return store.insertRawFrame({ id, file_path: filePath, sha256: sha(), sensitivity: 'normal', created_at: PAST, expires_at: PAST })
}

// ---------------------------------------------------------------------------
// 判据 1：失败置 error 且 file_path 保留；重跑不重复删除
// ---------------------------------------------------------------------------

test('判据1：10 条过期帧（1 条指向目录删不掉）→ 9 deleted / 1 error 且 file_path 保留', async () => {
  const fx = makeFixture('crit1')
  try {
    const store = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
    const blockedDir = join(fx.dir, 'blocked-dir')
    mkdirSync(blockedDir, { recursive: true }) // fs.rm 对目录抛 EISDIR → 稳定失败源
    const ids = []
    for (let i = 0; i < 9; i++) {
      const p = makePng(fx.shotsDir, `frame-${i}.png`)
      await insertExpired(store, `f-${i}`, p)
      ids.push(`f-${i}`)
    }
    await insertExpired(store, 'f-blocked', blockedDir)
    ids.push('f-blocked')

    const stats = await runCleanup({ store, shotsDir: fx.shotsDir, trashDir: fx.trashDir })
    assert.equal(stats.deleted, 9)
    assert.equal(stats.errored, 1)
    assert.equal(stats.marked, 10)

    const bad = store.getRawFrame('f-blocked')
    assert.equal(bad.status, 'error')
    assert.equal(bad.file_path, blockedDir, '失败记录必须保留 file_path（判据 1）')
    assert.ok(bad.error.includes('E_DELETE_RETRYABLE'))
    for (let i = 0; i < 9; i++) {
      assert.equal(existsSync(join(fx.shotsDir, `frame-${i}.png`)), false, '成功删除的文件必须真的没了')
      assert.equal(store.getRawFrame(`f-${i}`).status, 'deleted')
    }
    assert.deepEqual(store.counts().raw_frame, { ready: 0, deleting: 0, deleted: 9, error: 1 })
    store.close()
  } finally {
    rmFixture(fx)
  }
})

test('判据1：再跑一轮不重复删除（counts 不变，本轮不再产生删除）', async () => {
  const fx = makeFixture('crit1-rerun')
  try {
    const store = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
    const blockedDir = join(fx.dir, 'blocked-dir')
    mkdirSync(blockedDir, { recursive: true })
    for (let i = 0; i < 3; i++) await insertExpired(store, `g-${i}`, makePng(fx.shotsDir, `g-${i}.png`))
    await insertExpired(store, 'g-blocked', blockedDir)
    await runCleanup({ store, shotsDir: fx.shotsDir, trashDir: fx.trashDir })
    const before = store.counts()

    const stats2 = await runCleanup({ store, shotsDir: fx.shotsDir, trashDir: fx.trashDir })
    assert.equal(stats2.deleted, 0, '已删除的不得重复删除')
    assert.deepEqual(store.counts(), before, '重跑一轮 counts 必须完全不变')
    store.close()
  } finally {
    rmFixture(fx)
  }
})

// ---------------------------------------------------------------------------
// 判据 2：deleting 状态重启续跑
// ---------------------------------------------------------------------------

test('判据2：手造 deleting 记录 → runCleanup 拾起并完成删除', async () => {
  const fx = makeFixture('crit2')
  try {
    const store = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
    const p = makePng(fx.shotsDir, 'resume.png')
    await insertExpired(store, 'resume-1', p)
    store.markDeleting(['resume-1']) // 模拟上一轮 markDeleting 后进程崩溃
    assert.equal(store.getRawFrame('resume-1').status, 'deleting')

    const stats = await runCleanup({ store, shotsDir: fx.shotsDir, trashDir: fx.trashDir })
    const after = store.getRawFrame('resume-1')
    assert.equal(after.status, 'deleted', `状态迁移 deleting → deleted，实际 ${after.status}`)
    assert.equal(existsSync(p), false)
    assert.equal(stats.deleted, 1)
    store.close()
  } finally {
    rmFixture(fx)
  }
})

// ---------------------------------------------------------------------------
// 判据 3：observation 墓碑
// ---------------------------------------------------------------------------

test('判据3：过期 observation → 墓碑（ocr 清空/status=deleted/deleted_at），evidence 仍可引用', async () => {
  const fx = makeFixture('crit3')
  try {
    const store = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
    await insertExpired(store, 'src', makePng(fx.shotsDir, 'src.png'))
    store.upsertObservation({ id: 'ob-old', kind: 'window', source_frame_id: 'src', ocr_excerpt: '密码是 123', created_at: new Date(Date.now() - 8 * DAY).toISOString() })
    store.upsertObservation({ id: 'ob-new', kind: 'window', source_frame_id: 'src', ocr_excerpt: '无关紧要', created_at: new Date(Date.now() - 1 * DAY).toISOString() })

    const stats = await runCleanup({ store, shotsDir: fx.shotsDir, trashDir: fx.trashDir })
    assert.equal(stats.tombstoned, 1, '只有超过 observationDays(7d) 的才墓碑')
    const old = store.getObservation('ob-old')
    assert.equal(old.status, 'deleted')
    assert.equal(old.ocr_excerpt, null, '墓碑必须清空 ocr_excerpt')
    assert.ok(old.deleted_at)
    assert.equal(store.getObservation('ob-new').status, 'active')

    // 墓碑行保留 → evidence_item 仍可引用（判据 3 的引用语义）
    store.insertEvidenceItem({ id: 'ev-1', observation_id: 'ob-old' })
    assert.equal(store.counts().evidence_item, 1)
    store.close()
  } finally {
    rmFixture(fx)
  }
})

// ---------------------------------------------------------------------------
// 判据 4：敏感永不落盘
// ---------------------------------------------------------------------------

test('判据4：computeExpiry 三分支 + sensitive insert 拒绝并记 blocked-sensitive-persist', async () => {
  const T0 = Date.now()
  assert.equal(computeExpiry('normal', 'normal', undefined, T0), new Date(T0 + 6 * HOUR).toISOString())
  assert.equal(computeExpiry('normal', 'learning', undefined, T0), new Date(T0 + 20 * 60_000).toISOString())
  assert.throws(() => computeExpiry('sensitive', 'normal'), (e) => e.code === 'E_SENSITIVE_NO_PERSIST')

  const fx = makeFixture('crit4')
  try {
    const store = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
    assert.throws(
      () => store.insertRawFrame({ id: 'sens-1', file_path: 'x.png', sha256: sha(), sensitivity: 'sensitive', created_at: PAST, expires_at: PAST }),
      (e) => e.code === 'E_SENSITIVE_NO_PERSIST',
    )
    assert.equal(store.getRawFrame('sens-1'), null, '敏感帧不得入库')
    assert.equal(store.listAuditEvents({ kind: 'blocked-sensitive-persist' }).length, 1)
    store.close()
  } finally {
    rmFixture(fx)
  }
})

// ---------------------------------------------------------------------------
// 孤儿文件 → 回收站（不直接删）
// ---------------------------------------------------------------------------

test('孤儿 png：无 DB 记录 → 移入 trash 并记 orphan-moved 审计，被记录文件不动', async () => {
  const fx = makeFixture('orphan')
  try {
    const store = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
    const recorded = makePng(fx.shotsDir, 'recorded.png')
    store.insertRawFrame({ id: 'alive', file_path: recorded, sha256: sha(), sensitivity: 'normal', created_at: PAST, expires_at: FUTURE })
    makePng(fx.shotsDir, 'orphan.png') // DB 无记录

    const stats = await runCleanup({ store, shotsDir: fx.shotsDir, trashDir: fx.trashDir })
    assert.equal(stats.orphansMoved, 1)
    assert.equal(existsSync(recorded), true, '有记录的文件不得被搬走')
    assert.equal(existsSync(join(fx.shotsDir, 'orphan.png')), false)
    const moved = readdirSync(fx.trashDir)
    assert.equal(moved.length, 1, '孤儿进回收站而不是直接删')
    const ev = store.listAuditEvents({ kind: 'orphan-moved' })
    assert.equal(ev.length, 1)
    assert.ok(JSON.parse(ev[0].metadata_json).from.endsWith('orphan.png'))
    store.close()
  } finally {
    rmFixture(fx)
  }
})

test('孤儿治理：deleted/error 状态的 file_path 也算“有记录”，不搬', async () => {
  const fx = makeFixture('orphan-any-status')
  try {
    const store = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
    await insertExpired(store, 'dead-1', makePng(fx.shotsDir, 'already-gone.png'))
    store.markDeleting(['dead-1'])
    store.setRawFrameStatus('dead-1', 'deleted') // 文件已没了但 DB 有记录
    makePng(fx.shotsDir, 'stray.png') // 无记录 → 应被搬

    const stats = await runCleanup({ store, shotsDir: fx.shotsDir, trashDir: fx.trashDir })
    assert.equal(stats.orphansMoved, 1)
    assert.deepEqual(readdirSync(fx.trashDir), ['stray.png'])
    store.close()
  } finally {
    rmFixture(fx)
  }
})

test('空库护栏：库里一条记录都没有时跳过孤儿扫描（防首跑误搬全部历史截图）', async () => {
  const fx = makeFixture('orphan-empty-db')
  try {
    const store = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
    makePng(fx.shotsDir, 'legacy.png')
    const stats = await runCleanup({ store, shotsDir: fx.shotsDir, trashDir: fx.trashDir })
    assert.equal(stats.orphansMoved, 0)
    assert.equal(existsSync(join(fx.shotsDir, 'legacy.png')), true)
    assert.equal(existsSync(fx.trashDir), false, '回收站目录都不该被创建')
    assert.equal(store.listAuditEvents({ kind: 'orphan-scan-skipped' }).length, 1)
    store.close()
  } finally {
    rmFixture(fx)
  }
})

// ---------------------------------------------------------------------------
// stuck 熔断：连续 3 轮失败 → lifecycle-stuck，之后不再重试
// ---------------------------------------------------------------------------

test('stuck：同一记录连续 3 轮失败 → lifecycle-stuck 审计且第 4 轮不再动它', async () => {
  const fx = makeFixture('stuck')
  try {
    const store = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
    const blockedDir = join(fx.dir, 'blocked-dir')
    mkdirSync(blockedDir, { recursive: true })
    await insertExpired(store, 'stubborn', blockedDir)

    await runCleanup({ store, shotsDir: fx.shotsDir, trashDir: fx.trashDir }) // attempt 1
    await runCleanup({ store, shotsDir: fx.shotsDir, trashDir: fx.trashDir }) // attempt 2
    assert.equal(store.listAuditEvents({ kind: 'lifecycle-stuck' }).length, 0)
    const s3 = await runCleanup({ store, shotsDir: fx.shotsDir, trashDir: fx.trashDir }) // attempt 3 → stuck
    assert.equal(s3.stuck, 1)
    const stuckEv = store.listAuditEvents({ kind: 'lifecycle-stuck' })
    assert.equal(stuckEv.length, 1)
    assert.equal(JSON.parse(stuckEv[0].metadata_json).id, 'stubborn')
    const row = store.getRawFrame('stubborn')
    assert.equal(row.status, 'error')
    assert.ok(row.error.includes('E_DELETE_STUCK'))
    assert.equal(row.file_path, blockedDir, 'stuck 依旧保留 file_path')

    const s4 = await runCleanup({ store, shotsDir: fx.shotsDir, trashDir: fx.trashDir })
    assert.equal(s4.stuck, 0, '第 4 轮不再重试')
    assert.equal(s4.errored, 0)
    assert.equal(store.listAuditEvents({ kind: 'lifecycle-stuck' }).length, 1, 'stuck 审计不重复')
    assert.deepEqual(store.getRawFrame('stubborn'), row)
    store.close()
  } finally {
    rmFixture(fx)
  }
})

// ---------------------------------------------------------------------------
// 根外路径：直接置 error 不删、不重试
// ---------------------------------------------------------------------------

test('根外路径：置 error（E_OUTSIDE_ROOT）不删文件、后续轮次不再重试', async () => {
  const fx = makeFixture('outside-root')
  try {
    const outside = join(tmpdir(), `orb-lifecycle-outside-${Date.now()}.png`)
    writeFileSync(outside, 'OUTSIDE', 'utf8')
    try {
      const store = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
      store.insertRawFrame({ id: 'out-1', file_path: outside, sha256: sha(), sensitivity: 'normal', created_at: PAST, expires_at: PAST })
      const stats = await runCleanup({ store, shotsDir: fx.shotsDir, trashDir: fx.trashDir })
      assert.equal(stats.errored, 1)
      const row = store.getRawFrame('out-1')
      assert.equal(row.status, 'error')
      assert.ok(row.error.includes('E_OUTSIDE_ROOT'))
      assert.equal(row.file_path, outside)
      assert.equal(existsSync(outside), true, '根外文件绝不能被动')
      assert.ok(!row.error.includes('E_DELETE_RETRYABLE'), '根外失败是终局的，不重试')
      const stats2 = await runCleanup({ store, shotsDir: fx.shotsDir, trashDir: fx.trashDir })
      assert.equal(stats2.errored, 0, '终局失败不进入重试通道')
      store.close()
    } finally {
      rmSync(outside, { force: true })
    }
  } finally {
    rmFixture(fx)
  }
})

// ---------------------------------------------------------------------------
// frame-deleted 审计内容
// ---------------------------------------------------------------------------

test('frame-deleted 审计：metadata 含 id/file_path/sha256', async () => {
  const fx = makeFixture('audit-frame-deleted')
  try {
    const store = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
    const p = makePng(fx.shotsDir, 'audited.png')
    await insertExpired(store, 'aud-1', p)
    await runCleanup({ store, shotsDir: fx.shotsDir, trashDir: fx.trashDir })
    const ev = store.listAuditEvents({ kind: 'frame-deleted' })
    assert.equal(ev.length, 1)
    const meta = JSON.parse(ev[0].metadata_json)
    assert.equal(meta.id, 'aud-1')
    assert.equal(meta.file_path, p)
    assert.equal(meta.sha256, sha())
    store.close()
  } finally {
    rmFixture(fx)
  }
})

test('runCleanup 返回值键齐全且为数字（S8 起含 trashExpired）', async () => {
  const fx = makeFixture('stats-shape')
  try {
    const store = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
    const stats = await runCleanup({ store, shotsDir: fx.shotsDir, trashDir: fx.trashDir })
    // S8 起新增 trashExpired（回收区到期，D11-①）；以 CLEANUP_STATS_KEYS 为权威口径
    assert.deepEqual(Object.keys(stats).sort(), [...CLEANUP_STATS_KEYS].sort())
    for (const v of Object.values(stats)) assert.equal(typeof v, 'number')
    store.close()
  } finally {
    rmFixture(fx)
  }
})

// ---------------------------------------------------------------------------
// 判据 5（sqlite）：2000 条过期帧 → shots 字节回落
// ---------------------------------------------------------------------------

test('判据5：2000 条过期帧清理后夹具 shots 字节回落（after < before）', { skip: SQLITE_SKIP }, async () => {
  const fx = makeFixture('crit5-2000')
  try {
    // 场景整体放进无 NODE_OPTIONS shim 的子进程执行：本 CLI 宿主把 fs.rmSync 包装成
    // 回收站操作（2000 次外部进程调用既慢又偶发失败），而 Electron 生产环境走的是
    // 原生 rmSync——子进程环境与生产一致，删除语义才测得真。
    const child = [
      "import { mkdirSync, writeFileSync, readdirSync, statSync, existsSync } from 'node:fs'",
      "import { join } from 'node:path'",
      "import { pathToFileURL } from 'node:url'",
      `const ROOT = ${JSON.stringify(PROJECT_ROOT)}`,
      `const fx = ${JSON.stringify({ dir: fx.dir, dbPath: fx.dbPath, shotsDir: fx.shotsDir, trashDir: fx.trashDir })}`,
      "const { createStore, mergeLifecycleConfig } = await import(pathToFileURL(join(ROOT, 'packages/core/src/db.mjs')))",
      "const { runCleanup } = await import(pathToFileURL(join(ROOT, 'packages/core/src/lifecycle/cleaner.mjs')))",
      "const PAST = new Date(Date.now() - 3600_000).toISOString()",
      "const sha = () => 'b'.repeat(64)",
      "mkdirSync(fx.shotsDir, { recursive: true })",
      "const N = 2000",
      "for (let i = 0; i < N; i++) {",
      "  const p = join(fx.shotsDir, `bulk-${i}.png`)",
      "  writeFileSync(p, 'PNGFIXTURE-' + i)",
      "  const store2 = null",
      "}",
      "const store = await createStore({ driver: 'sqlite', dbPath: fx.dbPath, config: mergeLifecycleConfig({ cleanup: { batchSize: 2500 } }) })",
      "store.initMigrations()",
      "for (let i = 0; i < N; i++) {",
      "  store.insertRawFrame({ id: `bulk-${i}`, file_path: join(fx.shotsDir, `bulk-${i}.png`), sha256: sha(), sensitivity: 'normal', created_at: PAST, expires_at: PAST })",
      "}",
      "const bytes = (dir) => existsSync(dir) ? readdirSync(dir).reduce((n, name) => n + statSync(join(dir, name)).size, 0) : 0",
      "const before = bytes(fx.shotsDir)",
      "const cfg = mergeLifecycleConfig({ cleanup: { batchSize: 2500 } })",
      "const stats = await runCleanup({ store, config: cfg, shotsDir: fx.shotsDir, trashDir: fx.trashDir })",
      "const after = bytes(fx.shotsDir)",
      "console.log(JSON.stringify({ ok: true, deleted: stats.deleted, errored: stats.errored, before, after, counts: store.counts().raw_frame }))",
      "store.close()",
    ].join('\n')
    const childPath = join(fx.dir, 'crit5-child.mjs')
    writeFileSync(childPath, child, 'utf8')
    const r = spawnSync(process.execPath, [childPath], { encoding: 'utf8', timeout: 120_000, env: { ...process.env, NODE_OPTIONS: '' } })
    assert.equal(r.status, 0, `子进程必须成功：stderr=${r.stderr}\nstdout=${r.stdout}`)
    const out = JSON.parse(r.stdout.trim().split('\n').pop())
    assert.equal(out.deleted, 2000)
    assert.equal(out.errored, 0)
    assert.ok(out.before > 0)
    assert.ok(out.after < out.before, `清理后必须回落：before=${out.before} after=${out.after}`)
    assert.equal(out.after, 0)
    assert.deepEqual(out.counts, { ready: 0, deleting: 0, deleted: 2000, error: 0 })
  } finally {
    rmFixture(fx)
  }
})

// ---------------------------------------------------------------------------
// worker CLI 冒烟（spawn 子进程，全参数注入隔离夹具）
// ---------------------------------------------------------------------------

test('worker --once：输出一行可解析 JSON，deleted 计数正确，退出码 0', async () => {
  const fx = makeFixture('cli-once')
  try {
    // 用与 worker 相同的 auto driver 写入同一个库，保证 worker 读得到
    const store = await createStore({ driver: 'auto', dbPath: fx.dbPath, dataDir: fx.dataDir })
    store.initMigrations()
    const p = makePng(fx.shotsDir, 'cli-1.png')
    store.insertRawFrame({ id: 'cli-1', file_path: p, sha256: sha(), sensitivity: 'normal', created_at: PAST, expires_at: PAST })
    store.close()

    // 宿主（WorkBuddy CLI）的 safe-delete shim 会在同一 turn 累计删除超阈值后
    // 拦截子进程的 rmSync（全量测试跑到这里时极易触发），导致 worker 删文件
    // 失败 → deleted=0 的伪失败。与 tools/run-tests.mjs 同款：显式禁用该 shim。
    const childEnv = { ...process.env, CODEBUDDY_SAFE_DELETE_ENABLED: '0' }
    const r = spawnSync(process.execPath, [
      join(PROJECT_ROOT, 'tools', 'lifecycle-worker.mjs'), '--once',
      '--db', fx.dbPath, '--shots-dir', fx.shotsDir, '--trash-dir', fx.trashDir, '--config', fx.configPath,
    ], { encoding: 'utf8', timeout: 60_000, env: childEnv })
    assert.equal(r.status, 0, `退出码必须 0：stderr=${r.stderr}`)
    const out = JSON.parse(r.stdout.trim().split('\n').pop())
    assert.equal(out.deleted, 1)
    assert.equal(out.driver, hasSqlite ? 'sqlite' : 'jsonl')
    assert.equal(existsSync(p), false)
  } finally {
    rmFixture(fx)
  }
})

test('worker --stats：counts + disk(dbBytes/shotsBytes) JSON 可解析', () => {
  const fx = makeFixture('cli-stats')
  try {
    makePng(fx.shotsDir, 's.png')
    const r = spawnSync(process.execPath, [
      join(PROJECT_ROOT, 'tools', 'lifecycle-worker.mjs'), '--stats',
      '--db', fx.dbPath, '--shots-dir', fx.shotsDir, '--config', fx.configPath,
    ], { encoding: 'utf8', timeout: 60_000 })
    assert.equal(r.status, 0, `退出码必须 0：stderr=${r.stderr}`)
    const out = JSON.parse(r.stdout.trim().split('\n').pop())
    assert.ok(['sqlite', 'jsonl'].includes(out.driver))
    assert.deepEqual(Object.keys(out.counts).sort(), ['audit_event', 'evidence_item', 'observation', 'raw_frame', 'summary'])
    assert.equal(typeof out.disk.dbBytes, 'number')
    assert.ok(out.disk.shotsBytes > 0)
  } finally {
    rmFixture(fx)
  }
})

test('worker --audit-report：只读统计 relativeCount，不改写 writes.jsonl', () => {
  const fx = makeFixture('cli-audit')
  try {
    const r = spawnSync(process.execPath, [
      join(PROJECT_ROOT, 'tools', 'lifecycle-worker.mjs'), '--audit-report',
    ], { encoding: 'utf8', timeout: 60_000 })
    assert.equal(r.status, 0, `退出码必须 0：stderr=${r.stderr}`)
    const out = JSON.parse(r.stdout.trim().split('\n').pop())
    assert.equal(typeof out.totalLines, 'number')
    assert.equal(typeof out.relativeCount, 'number')
    assert.ok(Array.isArray(out.relative))
    for (const item of out.relative) {
      assert.ok(!/^[a-zA-Z]:[\\/]/.test(item.path), `相对路径判定失败：${item.path}`)
    }
  } finally {
    rmFixture(fx)
  }
})
