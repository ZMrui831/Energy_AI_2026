// tests/ratelimit.test.mjs
//
// 限速与出网边界回归（阶段 1 验收 ②③⑦ 的自动化部分）：
//   · reasoner 严格 10 次/分钟：第 11 次排队而不是直发，且 12 次连续调用不崩；
//   · 白名单外域名被拒，并写 data\logs\net.jsonl 的 deny 行；
//   · 令牌桶按 limitKey 分桶（provider+model 各自独立）。
//
// 全部用虚拟时钟：12 次真实 reasoner 调用要等一分钟，测试里压缩成毫秒级。

import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

import { createNet, REASONER_MODEL, BACKOFF_MS, NetError } from '../packages/core/src/net.mjs'
import { PROJECT_ROOT, safeWrite, logPath, LOG_DIR } from '../packages/core/src/safefs.mjs'

/** 清理测试遗留文件：用"截断"而不是删除。
 *  原因：宿主环境有批量删除保护，删到一定次数会直接抛 SAFE_DELETE_BULK_CONFIRM_REQUIRED，
 *  把与被删文件毫无关系的测试一起带崩（实测：agent.test.mjs 整文件失败）。
 *  测试的本意只是"从这个文件重新开始"，截断即可，顺带少一份误删风险。
 *  多余的实参（如 { force: true }）会被忽略，保持调用点不必改写。 */
const truncateFile = (p) => {
  try {
    writeFileSync(p, '')
  } catch {
    /* 文件不存在等情形直接忽略 */
  }
}

const LOG = logPath('test-ratelimit.jsonl')
const DEFAULT_LOG = logPath('net.jsonl')

const readLog = (p) =>
  existsSync(p)
    ? readFileSync(p, 'utf8')
        .split('\n')
        .filter((l) => l.trim())
        .map((l) => JSON.parse(l))
    : []

/** 虚拟时钟 + 假 fetch：让"等 60 秒"变成纯算术。 */
function harness({ ratePerSec = 3, burst = null } = {}) {
  const clock = { t: 0, sleeps: [] }
  const calls = []
  const net = createNet({
    fetchImpl: async (url, options) => {
      calls.push({ url: String(url), options })
      return new Response('{"ok":true}', { status: 200, headers: { 'content-type': 'application/json' } })
    },
    now: () => clock.t,
    sleep: async (ms) => {
      clock.sleeps.push(ms)
      clock.t += ms
    },
    logFile: LOG,
    ratePerSec,
    burst,
  })
  return { net, clock, calls }
}

test.before(() => truncateFile(LOG, { force: true }))

// ---------------------------------------------------------------------------
// ② reasoner 12 次：第 11 次排队，不崩
// ---------------------------------------------------------------------------

test('reasoner 12 次连续调用：第 11 次进入排队，全部成功，无异常', async () => {
  // burst 拉满，排除普通令牌桶的干扰 —— 本用例只考察 10 次/分钟这个窗口
  const { net, clock } = harness({ ratePerSec: 1e6, burst: 1e6 })
  const url = 'https://api.deepseek.com/v1/chat/completions'
  const responses = []
  for (let i = 0; i < 12; i += 1) {
    responses.push(
      await net.request(url, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ model: REASONER_MODEL, messages: [] }),
        model: REASONER_MODEL,
        limitKey: 'deepseek-api:' + REASONER_MODEL,
      }),
    )
  }

  assert.equal(responses.length, 12)
  assert.ok(responses.every((r) => r.status === 200), '12 次全部必须拿到响应')

  const rows = readLog(LOG).filter((r) => r.decision === 'allow')
  assert.equal(rows.length, 12)
  const queued = rows.map((r) => r.reasonerQueued === true)
  assert.deepEqual(
    queued,
    [false, false, false, false, false, false, false, false, false, false, true, false],
    '只有第 11 次被 10 次/分钟窗口拦下排队，第 12 次已在窗口内腾出空位',
  )

  // 第 11 次至少等了 60 秒窗口（虚拟时间）
  assert.ok(clock.sleeps.some((ms) => ms >= 60_000), `应出现 >=60000ms 的等待，实际 ${JSON.stringify(clock.sleeps)}`)
  assert.ok(clock.t >= 60_000, `虚拟总耗时 ${clock.t}ms 应 >= 60s`)

  const q = net.queueState()
  assert.equal(q.waiting, 0, '跑完必须把排队计数清零')
  assert.ok(q.limited >= 1, '限流计数应 >= 1')
  assert.equal(q.reasonerLimitPerMinute, 10)
  assert.ok(q.reasonerWindowUsed <= 10)
  assert.equal(q.exhausted, 0)
})

test('reasoner 未超限时完全不排队', async () => {
  const { net, clock } = harness({ ratePerSec: 1e6, burst: 1e6 })
  for (let i = 0; i < 10; i += 1) {
    await net.request('https://api.deepseek.com/v1/chat/completions', { model: REASONER_MODEL, method: 'POST', body: '{"model":"deepseek-reasoner"}' })
  }
  assert.equal(clock.sleeps.length, 0, '前 10 次不该有任何等待')
  assert.equal(net.queueState().limited, 0)
})

test('deepseek-chat 不受 reasoner 每分钟窗口约束', async () => {
  const { net, clock } = harness({ ratePerSec: 1e6, burst: 1e6 })
  for (let i = 0; i < 12; i += 1) {
    await net.request('https://api.deepseek.com/v1/chat/completions', { model: 'deepseek-chat', method: 'POST', body: '{"model":"deepseek-chat"}' })
  }
  assert.equal(clock.sleeps.length, 0)
  assert.equal(net.queueState().reasonerWindowUsed, 0)
})

// ---------------------------------------------------------------------------
// 令牌桶分桶
// ---------------------------------------------------------------------------

test('令牌桶按 limitKey 分桶：不同 provider+model 互不抢占', async () => {
  const { net } = harness({ ratePerSec: 1, burst: 1 })
  const url = 'https://api.deepseek.com/v1/chat/completions'
  await net.request(url, { model: 'deepseek-chat', limitKey: 'p1:deepseek-chat', method: 'POST', body: '{"model":"deepseek-chat"}' })
  const q = net.queueState()
  const keys = q.buckets.map((b) => b.key)
  assert.deepEqual(keys, ['p1:deepseek-chat'])
  assert.equal(q.buckets[0].capacity, 1)

  await net.request(url, { model: 'deepseek-chat', limitKey: 'p2:deepseek-chat', method: 'POST', body: '{"model":"deepseek-chat"}' })
  assert.equal(net.queueState().buckets.length, 2, '不同 limitKey 必须各自成桶')
})

test('未传 limitKey 时退回按域分桶', async () => {
  const { net } = harness()
  await net.request('https://api.openalex.org/works', { method: 'GET' })
  assert.deepEqual(net.queueState().buckets.map((b) => b.key), ['api.openalex.org'])
})

// ---------------------------------------------------------------------------
// ③ 白名单
// ---------------------------------------------------------------------------

test('白名单外域名被拒（不发请求），并在 net.jsonl 留下 deny 行', async () => {
  const before = readLog(DEFAULT_LOG).length
  const calls = []
  // 这个用例必须打【默认】日志，才能证明"默认就是 net.jsonl"
  const net = createNet({
    fetchImpl: async (url) => {
      calls.push(String(url))
      return new Response('{}', { status: 200 })
    },
    now: () => 0,
    sleep: async () => {},
  })
  await assert.rejects(
    () => net.request('https://sci-hub.se/paper/123'),
    (e) => e instanceof NetError && e.code === 'E_DOMAIN_NOT_ALLOWED',
  )
  await assert.rejects(() => net.request('http://api.deepseek.com/v1/chat/completions'), (e) => e.code === 'E_DOMAIN_NOT_ALLOWED')
  assert.equal(calls.length, 0, '被拒的请求绝不能真的发出去')

  const rows = readLog(DEFAULT_LOG).slice(before)
  assert.equal(rows.length, 2)
  assert.ok(rows.every((r) => r.decision === 'deny'))
  assert.equal(rows[0].host, 'sci-hub.se')
  assert.equal(rows[0].reason, 'not-in-allowlist')
  assert.equal(rows[1].reason, 'not-in-allowlist', 'http: 协议同样被判拒')
  assert.ok(!JSON.stringify(rows).includes('token='), 'deny 行不得带凭据')
})

test('429 退避序列与 BACKOFF_MS 一致，且退避次数有上限', async () => {
  const clock = { t: 0, sleeps: [] }
  let hits = 0
  const net = createNet({
    fetchImpl: async () => {
      hits += 1
      return new Response('slow down', { status: 429 })
    },
    now: () => clock.t,
    sleep: async (ms) => {
      clock.sleeps.push(ms)
      clock.t += ms
    },
    logFile: LOG,
  })
  const res = await net.request('https://api.deepseek.com/v1/chat/completions', { method: 'POST', body: '{"model":"deepseek-chat"}' })
  assert.equal(res.status, 429)
  assert.deepEqual(clock.sleeps, BACKOFF_MS, '退避必须是 2/4/8/16/32 秒')
  assert.equal(hits, BACKOFF_MS.length + 1)
  assert.equal(net.queueState().exhausted, 1)
})

test('审计行对 URL 里的密钥类查询参数打码', async () => {
  const path = logPath('test-ratelimit-redact.jsonl')
  truncateFile(path, { force: true })
  const n2 = createNet({
    fetchImpl: async () => new Response('{}', { status: 200 }),
    now: () => 0,
    sleep: async () => {},
    logFile: path,
  })
  await n2.request('https://api.crossref.org/works?api_key=SUPERSECRET123&filter=recent&mailto=a@b.c')
  const rows = readLog(path)
  assert.equal(rows.length, 1)
  assert.ok(!rows[0].url.includes('SUPERSECRET123'), rows[0].url)
  assert.match(rows[0].url, /api_key=SUPE\*\*\*/)
  assert.ok(rows[0].url.includes('filter=recent'), '非密钥参数应原样保留')
  assert.match(rows[0].url, /mailto=a%40b\.\*\*\*/, 'mailto 被视为密钥类参数一并打码')
  truncateFile(path, { force: true })
})

test('safeWrite 的审计日志与 net 日志都在 data/logs 下，不跨界', () => {
  assert.ok(DEFAULT_LOG.startsWith(LOG_DIR))
  assert.ok(LOG.startsWith(LOG_DIR))
  const probe = logPath('test-ratelimit-probe.jsonl')
  safeWrite(probe, 'x\n', { append: true })
  assert.ok(existsSync(probe))
  truncateFile(probe, { force: true })
})
