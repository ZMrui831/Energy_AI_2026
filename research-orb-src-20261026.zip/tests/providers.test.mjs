// tests/providers.test.mjs
//
// provider 层回归：SSE 双协议解析、事件三态、密钥打码、config 掩码、
// 错误分类透传、两个 provider 共用同一 net。全部用假 fetch，不碰真实网络与真实凭据。

import test from 'node:test'
import assert from 'node:assert/strict'
import { join } from 'node:path'

import { createNet, ENDPOINTS, classifyStatus, joinUrl, assertAllowedBaseUrl, NetError } from '../packages/core/src/net.mjs'
import { PROJECT_ROOT, logPath } from '../packages/core/src/safefs.mjs'
import {
  DeepSeekProvider,
  SchoolGatewayProvider,
  DEEPSEEK_PROVIDER_ID,
  GATEWAY_PROVIDER_ID,
  createProviders,
  collectStream,
  normalizeMessages,
  parseSse,
  shortMessage,
  stripSecrets,
  EVENT,
  ProviderError,
} from '../packages/core/src/providers/index.mjs'

const TEST_LOG = logPath('test-providers.jsonl')
const FAKE_KEY = 'sk-testonlyabcdefghijklmnop'
const FAKE_TOKEN = 'sk-testonlytoken1234567890'

const virtualNet = (fetchImpl) =>
  createNet({
    fetchImpl,
    logFile: TEST_LOG,
    now: () => 1_700_000_000_000,
    sleep: async () => {},
  })

const sse = (frames, { status = 200 } = {}) =>
  new Response(frames.map((f) => `data: ${JSON.stringify(f)}\n\n`).join('') + 'data: [DONE]\n\n', {
    status,
    headers: { 'content-type': 'text/event-stream' },
  })

const deepseekCfg = () => ({
  baseUrl: 'https://api.deepseek.com',
  apiKey: FAKE_KEY,
  models: ['deepseek-chat', 'deepseek-reasoner'],
  ready: true,
  source: 'test',
})

const gatewayCfg = () => ({
  baseUrl: 'https://models.sjtu.edu.cn/api',
  authToken: FAKE_TOKEN,
  settingsPath: 'C:\\nonexistent\\settings.json',
  pathExists: true,
  models: ['deepseek-chat', 'deepseek-reasoner'],
  ready: true,
  source: 'test',
})

// ---------------------------------------------------------------------------
// 纯函数
// ---------------------------------------------------------------------------

test('stripSecrets 把 sk- 前缀与 Bearer 打码，且不改变无密钥文本', () => {
  assert.equal(stripSecrets(`oops ${FAKE_KEY}`), 'oops sk-t***')
  assert.equal(stripSecrets('Authorization: Bearer abcdefghijkl'), 'Authorization: Bearer ***')
  assert.equal(stripSecrets('普通文本'), '普通文本')
  assert.ok(!stripSecrets(`x=${FAKE_KEY}`).includes('testonly'))
})

test('shortMessage 压平空白并截断到上限', () => {
  assert.equal(shortMessage('  a\n\n b  '), 'a b')
  assert.equal(shortMessage('x'.repeat(500), 10).length, 10)
  assert.ok(!shortMessage(`err ${FAKE_KEY}`).includes('testonly'))
})

test('normalizeMessages 只放行 system/user/assistant + 字符串 content', () => {
  assert.deepEqual(normalizeMessages([{ role: 'user', content: 'hi' }]), [{ role: 'user', content: 'hi' }])
  assert.throws(() => normalizeMessages([]), (e) => e.code === 'E_BAD_MESSAGES')
  assert.throws(() => normalizeMessages([{ role: 'tool', content: 'x' }]), (e) => e.code === 'E_BAD_MESSAGES')
  assert.throws(() => normalizeMessages([{ role: 'user', content: 42 }]), (e) => e.code === 'E_BAD_MESSAGES')
})

test('classifyStatus 覆盖鉴权/限流/超时/服务端/未知', () => {
  assert.deepEqual(classifyStatus(200), { code: 'OK', retryable: false })
  assert.equal(classifyStatus(401).code, 'E_AUTH')
  assert.equal(classifyStatus(403).code, 'E_AUTH')
  assert.equal(classifyStatus(404).code, 'E_NOT_FOUND')
  assert.equal(classifyStatus(408).retryable, true)
  assert.equal(classifyStatus(429).code, 'E_RATE_LIMITED')
  assert.equal(classifyStatus(400).code, 'E_BAD_REQUEST')
  assert.equal(classifyStatus(503).code, 'E_SERVER')
  assert.equal(classifyStatus(418).code, 'E_HTTP_418')
  assert.equal(classifyStatus('x').code, 'E_UNKNOWN')
})

test('ENDPOINTS/joinUrl 组装正确，且尾部斜杠不产生双斜杠', () => {
  assert.equal(joinUrl('https://api.deepseek.com/', '/v1/chat/completions'), 'https://api.deepseek.com/v1/chat/completions')
  assert.equal(ENDPOINTS.deepseekChatCompletions('https://api.deepseek.com'), 'https://api.deepseek.com/v1/chat/completions')
  assert.equal(ENDPOINTS.deepseekModels('https://api.deepseek.com'), 'https://api.deepseek.com/v1/models')
  assert.equal(ENDPOINTS.anthropicMessages('https://models.sjtu.edu.cn/api'), 'https://models.sjtu.edu.cn/api/v1/messages')
})

test('assertAllowedBaseUrl 提前拒绝白名单外主机', () => {
  assert.equal(assertAllowedBaseUrl('https://api.deepseek.com', 't'), 'api.deepseek.com')
  assert.throws(() => assertAllowedBaseUrl('https://evil.example.com', 't'), (e) => e instanceof NetError && e.code === 'E_DOMAIN_NOT_ALLOWED')
  assert.throws(() => assertAllowedBaseUrl('not a url', 't'), (e) => e.code === 'E_BAD_BASE_URL')
})

test('parseSse 同时吃 OpenAI 的 data: 与 Anthropic 的 event:', async () => {
  const openai = new Response('data: {"a":1}\n\ndata: [DONE]\n\n')
  const out1 = []
  for await (const f of parseSse(openai.body)) out1.push(f)
  assert.equal(out1.length, 2)
  assert.deepEqual(out1[0].json, { a: 1 })
  assert.equal(out1[1].data, '[DONE]')

  const anthropic = new Response('event: message_stop\ndata: {"type":"message_stop"}\n\n')
  const out2 = []
  for await (const f of parseSse(anthropic.body)) out2.push(f)
  assert.equal(out2[0].event, 'message_stop')
  assert.equal(out2[0].json.type, 'message_stop')

  // 心跳注释与坏 JSON 都不能炸
  const noisy = new Response(': ping\n\ndata: {oops\n\n')
  const out3 = []
  for await (const f of parseSse(noisy.body)) out3.push(f)
  assert.equal(out3.length, 1)
  assert.equal(out3[0].json, null)
})

// ---------------------------------------------------------------------------
// DeepSeek（OpenAI 兼容）
// ---------------------------------------------------------------------------

test('DeepSeekProvider 流式产出 delta/done，并把 reasoning_content 分到独立 channel', async () => {
  const seen = []
  const net = virtualNet(async (url, options) => {
    seen.push({ url, headers: options.headers, body: JSON.parse(options.body) })
    return sse([
      { choices: [{ delta: { reasoning_content: '想一下' } }] },
      { choices: [{ delta: { content: '答案' } }] },
      { choices: [{ delta: { content: '：42' }, finish_reason: 'stop' }], usage: { total_tokens: 7 } },
    ])
  })
  const provider = new DeepSeekProvider({ net, config: deepseekCfg() })
  const chunks = []
  for await (const ev of provider.chat({ messages: [{ role: 'user', content: 'q' }], model: 'deepseek-chat' })) chunks.push(ev)

  const deltas = chunks.filter((c) => c.type === EVENT.DELTA)
  const done = chunks.find((c) => c.type === EVENT.DONE)
  assert.deepEqual(deltas.map((d) => d.channel), ['reasoning', 'content', 'content'])
  assert.equal(done.text, '答案：42')
  assert.equal(done.reasoning, '想一下')
  assert.equal(done.usage.total_tokens, 7)
  assert.equal(done.finishReason, 'stop')

  assert.equal(seen.length, 1)
  assert.equal(seen[0].url, 'https://api.deepseek.com/v1/chat/completions')
  assert.equal(seen[0].body.stream, true)
  assert.equal(seen[0].headers.authorization, `Bearer ${FAKE_KEY}`, '密钥只应出现在请求头')
})

test('provider 错误事件不泄漏密钥（正文回显 sk- 也必须打码）', async () => {
  const net = virtualNet(async () => new Response(`bad key ${FAKE_KEY}`, { status: 401 }))
  const provider = new DeepSeekProvider({ net, config: deepseekCfg() })
  const { errors, text } = await collectStream(provider.chat({ messages: [{ role: 'user', content: 'q' }] }))
  assert.equal(text, '')
  assert.equal(errors.length, 1)
  assert.equal(errors[0].code, 'E_AUTH')
  assert.equal(errors[0].retryable, false)
  assert.ok(!errors[0].message.includes('testonly'), errors[0].message)
  assert.match(errors[0].message, /sk-t\*\*\*/)
})

test('429 被分类成可重试的 E_RATE_LIMITED（退避由 net 负责）', async () => {
  const net = virtualNet(async () => new Response('slow down', { status: 429 }))
  const provider = new DeepSeekProvider({ net, config: deepseekCfg() })
  const { errors } = await collectStream(provider.chat({ messages: [{ role: 'user', content: 'q' }] }))
  assert.equal(errors[0].code, 'E_RATE_LIMITED')
  assert.equal(errors[0].retryable, true)
})

test('DeepSeekProvider 拒绝未知模型与缺失密钥', async () => {
  const net = virtualNet(async () => sse([]))
  const p1 = new DeepSeekProvider({ net, config: deepseekCfg() })
  const r1 = await collectStream(p1.chat({ messages: [{ role: 'user', content: 'q' }], model: 'gpt-4' }))
  assert.equal(r1.errors[0].code, 'E_UNKNOWN_MODEL')

  const p2 = new DeepSeekProvider({ net, config: { ...deepseekCfg(), apiKey: '', ready: false } })
  const r2 = await collectStream(p2.chat({ messages: [{ role: 'user', content: 'q' }], model: 'deepseek-chat' }))
  assert.equal(r2.errors[0].code, 'E_NO_KEY')
  assert.ok(!r2.errors[0].message.includes(FAKE_KEY))
})

test('DeepSeekProvider.describeConfig 只输出掩码，describe 只输出元数据', () => {
  const net = virtualNet(async () => sse([]))
  const p = new DeepSeekProvider({ net, config: deepseekCfg() })
  const cfg = p.describeConfig()
  assert.equal(cfg.key, 'sk-t***')
  assert.equal(cfg.baseUrl, 'https://api.deepseek.com')
  assert.deepEqual(cfg.models, ['deepseek-chat', 'deepseek-reasoner'])
  assert.ok(!JSON.stringify(cfg).includes('testonly'))

  const d = p.describe()
  assert.equal(d.id, DEEPSEEK_PROVIDER_ID)
  assert.equal(d.kind, 'openai-compatible')
  assert.equal(d.defaultModel, 'deepseek-chat')
  assert.ok(!JSON.stringify(d).includes('sk-'))
})

// ---------------------------------------------------------------------------
// 学校网关（Anthropic 兼容）
// ---------------------------------------------------------------------------

test('SchoolGatewayProvider: system 提到顶层、messages 去掉 system、token 只进 x-api-key', async () => {
  const seen = []
  const net = virtualNet(async (url, options) => {
    seen.push({ url, headers: options.headers, body: JSON.parse(options.body) })
    const body =
      'event: message_start\ndata: {"type":"message_start","message":{"usage":{"input_tokens":3}}}\n\n' +
      'event: content_block_delta\ndata: {"type":"content_block_delta","delta":{"type":"thinking_delta","thinking":"考虑"}}\n\n' +
      'event: content_block_delta\ndata: {"type":"content_block_delta","delta":{"type":"text_delta","text":"网关可用"}}\n\n' +
      'event: message_delta\ndata: {"type":"message_delta","delta":{"stop_reason":"end_turn"},"usage":{"output_tokens":5}}\n\n' +
      'event: message_stop\ndata: {"type":"message_stop"}\n\n'
    return new Response(body, { status: 200, headers: { 'content-type': 'text/event-stream' } })
  })
  const provider = new SchoolGatewayProvider({ net, config: gatewayCfg() })
  const chunks = []
  for await (const ev of provider.chat({
    messages: [{ role: 'system', content: '你是助手' }, { role: 'user', content: 'q' }],
    model: 'deepseek-chat',
  })) chunks.push(ev)

  assert.equal(seen.length, 1)
  assert.equal(seen[0].url, 'https://models.sjtu.edu.cn/api/v1/messages')
  assert.equal(seen[0].headers['x-api-key'], FAKE_TOKEN)
  assert.equal(seen[0].headers['anthropic-version'], '2023-06-01')
  assert.equal(seen[0].body.system, '你是助手')
  assert.deepEqual(seen[0].body.messages, [{ role: 'user', content: 'q' }])

  const done = chunks.find((c) => c.type === EVENT.DONE)
  assert.equal(done.text, '网关可用')
  assert.equal(done.reasoning, '考虑')
  assert.equal(done.finishReason, 'end_turn')
  assert.equal(done.usage.output_tokens, 5)
})

test('SchoolGatewayProvider: 缺凭据时明确报 E_NO_CREDENTIALS 且口令打码', async () => {
  const net = virtualNet(async () => sse([]))
  const p = new SchoolGatewayProvider({ net, config: { ...gatewayCfg(), baseUrl: '', authToken: '', ready: false, pathExists: true } })
  const { errors } = await collectStream(p.chat({ messages: [{ role: 'user', content: 'q' }] }))
  assert.equal(errors[0].code, 'E_NO_CREDENTIALS')
  assert.match(errors[0].message, /settings\.json/)
})

test('anthropic 流里的 error 事件被转成统一 error 事件', async () => {
  const net = virtualNet(
    async () =>
      new Response('event: error\ndata: {"type":"error","error":{"message":"boom"}}\n\n', { status: 200 }),
  )
  const p = new SchoolGatewayProvider({ net, config: gatewayCfg() })
  const { errors } = await collectStream(p.chat({ messages: [{ role: 'user', content: 'q' }], model: 'deepseek-chat' }))
  assert.equal(errors[0].code, 'E_GATEWAY')
  assert.match(errors[0].message, /boom/)
})

// ---------------------------------------------------------------------------
// 注册表
// ---------------------------------------------------------------------------

test('createProviders 注册两个 provider 且共享同一个 net（限速口径一致）', () => {
  const net = virtualNet(async () => sse([]))
  const reg = createProviders({ net })
  assert.equal(reg.list().length, 2)
  assert.ok(reg.has(DEEPSEEK_PROVIDER_ID) && reg.has(GATEWAY_PROVIDER_ID))
  assert.equal(reg.byId(DEEPSEEK_PROVIDER_ID).net, net)
  assert.equal(reg.byId(GATEWAY_PROVIDER_ID).net, net)
  assert.equal(reg.errors.length, 0)

  const desc = reg.describe()
  assert.equal(desc.providers.length, 2)
  assert.ok(!JSON.stringify(desc).includes('testonly'))
})

test('ProviderError 携带 code 与细节字段', () => {
  const err = new ProviderError('E_X', 'msg', { status: 500 })
  assert.equal(err.name, 'ProviderError')
  assert.equal(err.code, 'E_X')
  assert.equal(err.status, 500)
})

// ---------------------------------------------------------------------------
// 协议外沿：非流式
// ---------------------------------------------------------------------------

test('deepseek 非流式请求返回单个 delta + done', async () => {
  const net = virtualNet(async () =>
    new Response(JSON.stringify({ model: 'deepseek-chat', choices: [{ message: { content: '一次到位' }, finish_reason: 'stop' }], usage: { total_tokens: 2 } }), {
      status: 200,
      headers: { 'content-type': 'application/json' },
    }),
  )
  const provider = new DeepSeekProvider({ net, config: deepseekCfg() })
  const { text, done } = await collectStream(
    provider.chat({ messages: [{ role: 'user', content: 'q' }], model: 'deepseek-chat', stream: false }),
  )
  assert.equal(text, '一次到位')
  assert.equal(done.finishReason, 'stop')
})
