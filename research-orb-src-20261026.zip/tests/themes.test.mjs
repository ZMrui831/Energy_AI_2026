// tests/themes.test.mjs
//
// P-R6 块 B：主题系统的验收测试。
//   1) schema 校验：缺字段 / 非法颜色 / 非法 sizeScale / 非法 ball.size → 拒绝且不写盘
//   2) 路径穿越：主题名含 ../ 或绝对路径 → 拒绝
//   3) 内置主题全部通过校验，且满足对比度约束（正文 ≥4.5:1、次要 ≥3:1）
//   4) themeToCss 只输出颜色/字体/圆角/阴影 token —— **不含任何几何 token**
//      （几何契约：换肤不得改变球 96×96 / 展开 420×620 / 右下锚点）
//   5) 字体回退链：默认宋体/楷体；用户字体优先；链尾必落到通用族（无豆腐块）
//   6) 导入导出往返一致

import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, readFileSync, mkdirSync, writeFileSync, rmSync, readdirSync } from 'node:fs'
import { join } from 'node:path'

import {
  listThemes, readTheme, importTheme, exportTheme, validateTheme, themeToCss, themePath,
  contrastRatio, fontStack, userFonts, THEMES_DIR, DEFAULT_THEME, BODY_FALLBACK, HEADING_FALLBACK, MONO_FALLBACK,
} from '../packages/core/src/themes.mjs'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

/** 一份完整合法的主题对象（测试基准）。 */
function validTheme(overrides = {}) {
  return {
    name: 'test-theme',
    description: '测试主题',
    colors: {
      bg: '#ffffff', bgAlt: '#f0f0f0', panel: '#ffffff', text: '#111111', textDim: '#555555',
      accent: '#1f6feb', border: '#cccccc', hover: '#eeeeee', ballFrom: '#a9cdf5', ballTo: '#1f6feb',
    },
    radius: '16px',
    spacing: '12px',
    shadow: '0 1px 2px rgba(0,0,0,0.06)',
    font: { body: 'SimSun, serif', heading: 'KaiTi, serif', mono: 'Consolas, monospace', sizeScale: 1 },
    ball: { size: 96, ring: '#7dd3fc' },
    ...overrides,
  }
}

// ---------------------------------------------------------------------------
// 1) schema 校验
// ---------------------------------------------------------------------------
test('themes: 完整合法主题通过校验', () => {
  const v = validateTheme(validTheme())
  assert.equal(v.ok, true, v.errors && v.errors.join('；'))
})

test('themes: 缺字段被拒（逐个删必需字段）', () => {
  for (const key of ['name', 'description', 'colors', 'radius', 'spacing', 'shadow', 'font', 'ball']) {
    const doc = validTheme()
    delete doc[key]
    const v = validateTheme(doc)
    assert.equal(v.ok, false, `缺 ${key} 应被拒`)
    assert.ok(v.errors.some((e) => e.includes(key)), `错误信息应提到 ${key}：${v.errors.join('；')}`)
  }
  for (const k of ['bg', 'bgAlt', 'panel', 'text', 'textDim', 'accent', 'border', 'hover', 'ballFrom', 'ballTo']) {
    const doc = validTheme()
    delete doc.colors[k]
    const v = validateTheme(doc)
    assert.equal(v.ok, false, `colors 缺 ${k} 应被拒`)
  }
  for (const k of ['body', 'heading', 'mono', 'sizeScale']) {
    const doc = validTheme()
    delete doc.font[k]
    const v = validateTheme(doc)
    assert.equal(v.ok, false, `font 缺 ${k} 应被拒`)
  }
  for (const k of ['size', 'ring']) {
    const doc = validTheme()
    delete doc.ball[k]
    const v = validateTheme(doc)
    assert.equal(v.ok, false, `ball 缺 ${k} 应被拒`)
  }
})

test('themes: 非法颜色 / sizeScale / ball.size 被拒', () => {
  for (const bad of ['red', '#gggggg', '#12345', 'rgb(999,0,0)', 'javascript:alert(1)', 42, null]) {
    const doc = validTheme()
    doc.colors.bg = bad
    const v = validateTheme(doc)
    assert.equal(v.ok, false, `colors.bg=${JSON.stringify(bad)} 应被拒`)
  }
  for (const bad of [0.2, 3, 'x', -1]) {
    const doc = validTheme()
    doc.font.sizeScale = bad
    assert.equal(validateTheme(doc).ok, false, `sizeScale=${bad} 应被拒`)
  }
  for (const bad of [10, 400, '96', null]) {
    const doc = validTheme()
    doc.ball.size = bad
    assert.equal(validateTheme(doc).ok, false, `ball.size=${bad} 应被拒`)
  }
})

test('themes: 合法颜色形态被接受（#rgb/#rrggbb/rgba）', () => {
  assert.equal(validateTheme(validTheme({ colors: { ...validTheme().colors, bg: '#fff', accent: 'rgba(31,111,235,0.5)' } })).ok, true)
})

test('themes: 非法主题名 / 路径穿越被拒', () => {
  for (const bad of ['../evil', '/etc/passwd', 'a/b', '', '.', 'x'.repeat(80), 'a b']) {
    assert.throws(() => themePath(bad), (e) => e.code === 'E_THEME_BAD_NAME', `主题名 ${JSON.stringify(bad)} 应被拒`)
  }
})

// ---------------------------------------------------------------------------
// 2) 导入：校验不过不写盘
// ---------------------------------------------------------------------------
test('themes: 导入缺字段主题 → 拒绝且磁盘上不出现该文件', () => {
  const name = 'pr6-should-not-exist'
  const p = themePath(name)
  if (existsSync(p)) rmSync(p)
  const doc = validTheme({ name })
  delete doc.colors.accent
  assert.throws(() => importTheme(name, doc), (e) => e.code === 'E_THEME_SCHEMA')
  assert.equal(existsSync(p), false, '校验不过不得写盘')
})

test('themes: 导入合法主题 → 写盘且可读回；导出往返一致', () => {
  const name = 'pr6-roundtrip'
  const p = themePath(name)
  try {
    const doc = validTheme({ name, description: '往返测试' })
    const saved = importTheme(name, doc)
    assert.equal(saved.name, name)
    const back = readTheme(name)
    assert.deepEqual(back, saved)
    assert.equal(exportTheme(name), JSON.stringify(saved, null, 2))
    assert.ok(listThemes().some((t) => t.name === name && t.ok))
  } finally {
    if (existsSync(p)) rmSync(p)
  }
})

// ---------------------------------------------------------------------------
// 3) 内置主题 + 对比度约束
// ---------------------------------------------------------------------------
test('themes: 内置主题全部通过校验', () => {
  const themes = listThemes()
  assert.ok(themes.length >= 3, `至少 3 套主题（实际 ${themes.length}）`)
  for (const t of themes) assert.equal(t.ok, true, `${t.name}: ${t.errors.join('；')}`)
})

test('themes: teal 是默认主题且存在', () => {
  assert.equal(DEFAULT_THEME, 'teal')
  assert.ok(existsSync(join(THEMES_DIR, 'teal.theme.json')))
})

test('themes: 对比度约束 —— 正文 ≥4.5:1、次要 ≥3:1、强调色 ≥4.5:1', () => {
  for (const t of listThemes()) {
    const th = readTheme(t.name)
    const body = contrastRatio(th.colors.text, th.colors.panel)
    const dim = contrastRatio(th.colors.textDim, th.colors.panel)
    const accent = contrastRatio(th.colors.accent, th.colors.panel)
    assert.ok(body >= 4.5, `${t.name} 正文对比度 ${body.toFixed(2)} < 4.5`)
    assert.ok(dim >= 3, `${t.name} 次要文字对比度 ${dim.toFixed(2)} < 3`)
    assert.ok(accent >= 4.5, `${t.name} 强调色对比度 ${accent.toFixed(2)} < 4.5`)
  }
})

// ---------------------------------------------------------------------------
// 4) 换肤不破坏几何契约
// ---------------------------------------------------------------------------
test('themes: themeToCss 只输出颜色/字体/圆角/阴影 token，不含任何几何 token', () => {
  for (const t of listThemes()) {
    const css = themeToCss(readTheme(t.name))
    // 几何 token（vendor floating.css 定义、由窗口尺寸逻辑读取）一个都不能出现
    for (const geo of ['--ball:', '--chrome:', '--composer-height:', '--prompt-line:', '--prompt-pad:', '--composer-max:', '--selection-chip:', '--origin-x:', '--origin-y:']) {
      assert.equal(css.includes(geo), false, `${t.name} 的 CSS 不得覆盖几何 token ${geo}`)
    }
    // 也不得出现 width/height/px 尺寸类的面板几何
    assert.equal(/\bwidth\s*:/.test(css), false, `${t.name} 的 CSS 不得设置 width`)
    assert.equal(/\bheight\s*:/.test(css), false, `${t.name} 的 CSS 不得设置 height`)
    // 但必须真的覆盖了颜色/字体/圆角/阴影
    assert.match(css, /--black:/)
    assert.match(css, /--panel-radius:/)
    assert.match(css, /font-family:/)
  }
})

test('themes: 几何契约常量（球 96×96 / 展开 420×620）与主题解耦', () => {
  // main.mjs 的几何常量不得来自主题文件
  const main = readFileSync(join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs'), 'utf8')
  assert.match(main, /COLLAPSED_SIZE = \{ width: 96, height: 96 \}/)
  assert.match(main, /EXPANDED_SIZE = \{ width: 420, height: 620 \}/)
  // 主题的 ball.size 只能用于球面视觉（渐变/圆环），不得驱动窗口尺寸
  assert.equal(/ball\.size/.test(main), false, 'main.mjs 不得用 theme.ball.size 决定窗口尺寸')
})

// ---------------------------------------------------------------------------
// 5) 字体回退链
// ---------------------------------------------------------------------------
test('themes: 默认正文字体链以宋体开头、标题以楷体开头', () => {
  assert.equal(BODY_FALLBACK[0], 'SimSun')
  assert.equal(HEADING_FALLBACK[0], 'KaiTi')
})

test('themes: fontStack 链尾必落到通用族（无豆腐块保障）', () => {
  for (const base of [BODY_FALLBACK, HEADING_FALLBACK, MONO_FALLBACK]) {
    const stack = fontStack(null, base)
    assert.ok(/serif|sans-serif|monospace|system-ui/.test(stack.split(',').pop().trim()), `链尾必须落到通用族：${stack}`)
  }
  // 用户自备字体优先
  const stack = fontStack(['MyFont'], BODY_FALLBACK)
  assert.ok(stack.startsWith('MyFont'), '用户字体应排在链首')
  assert.ok(stack.includes('SimSun'), '用户字体之后仍保留系统回退')
})

test('themes: data/fonts 目录可枚举且只收字体扩展名', () => {
  const fonts = userFonts()
  assert.ok(Array.isArray(fonts))
  for (const f of fonts) assert.match(f, /\.(ttf|otf|ttc|woff2?)$/i)
})

test('themes: P-R6.1 球体外圈描边 —— #ball 规则含 ball.ring 描边 + 外发光，且不碰几何', () => {
  for (const t of listThemes()) {
    const css = themeToCss(readTheme(t.name))
    const rule = css.split('}').find((x) => x.includes('#ball')) || ''
    const th = readTheme(t.name)
    assert.ok(rule.includes('0 0 0 1.5px'), `${t.name} 缺 1.5px 外圈描边`)
    assert.ok(rule.includes('0 0 7px'), `${t.name} 缺外发光`)
    assert.ok(rule.includes(th.ball.ring), `${t.name} 描边未用 ball.ring token`)
  }
})

test('themes: 内置主题的字体链以宋体/楷体开头', () => {
  for (const t of listThemes()) {
    const th = readTheme(t.name)
    assert.match(th.font.body, /^SimSun/, `${t.name} 正文应以宋体开头`)
    assert.match(th.font.heading, /^KaiTi/, `${t.name} 标题应以楷体开头`)
    assert.match(th.font.mono, /^Consolas/, `${t.name} 等宽应以 Consolas 开头`)
  }
})
