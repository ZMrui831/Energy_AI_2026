// tests/pdf.test.mjs
//
// PDF 抽取与分节（交付 2）。
// 用 data/fixtures/sample-paper.pdf 这个仓库内夹具跑一次真实 unpdf 抽取，
// 其余用例都是纯函数，不碰文件系统。

import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, readFileSync, statSync } from 'node:fs'
import { join } from 'node:path'

import {
  ABSTRACT_FALLBACK_CHARS,
  PDF_SCHEMA_VERSION,
  SECTION_KEYS,
  buildPdfDoc,
  cardExcerpt,
  extractPdfFile,
  matchSectionHeading,
  pdfHash,
  shortHash,
  splitSections,
} from '../packages/plugins/research-literature/lib/pdf.mjs'
import { DATA_DIR, dataPath } from '../packages/core/src/safefs.mjs'

const FIXTURE = dataPath('fixtures', 'sample-paper.pdf')

const SAMPLE = [
  'Grid-Forming Inverter Control for Inertia Support',
  'Wei Wang, Maria Rossi',
  '',
  'Abstract',
  'This paper addresses the low-inertia problem of converter-dominated power systems.',
  'A virtual inertia controller for grid-forming inverters is proposed in this work.',
  '',
  '1. Introduction',
  'The increasing penetration of renewable generation reduces system inertia significantly.',
  'Frequency stability therefore becomes a major challenge for grid operators.',
  '',
  '2. Method',
  'The proposed controller emulates synchronous inertia through a first-order frequency loop.',
  'A small-signal model is derived to analyse the damping contribution.',
  '',
  '3. Results',
  'Simulation results on a modified IEEE 9-bus test system validate the proposed scheme.',
  'The inertia support reduces the frequency nadir by 0.12 Hz.',
  '',
  '4. Conclusion',
  'Grid-forming inverter inertia support improves transient frequency response.',
  'Future work will consider communication delays and cyber-physical security.',
  '',
  'References',
  '[1] Some Author. A paper. IEEE Trans. Power Syst., 2023.',
].join('\n')

// ---------------------------------------------------------------------------

test('pdf: 哈希稳定且短哈希取前 16 位', () => {
  const buf = Buffer.from('hello pdf')
  const h1 = pdfHash(buf)
  const h2 = pdfHash(Buffer.from('hello pdf'))
  assert.equal(h1, h2, '同内容必须同哈希')
  assert.equal(h1.length, 64)
  assert.equal(shortHash(h1), h1.slice(0, 16))
  assert.notEqual(pdfHash(Buffer.from('other')), h1)
})

test('pdf: 章节标题识别容忍编号/全角冒号/常见别名', () => {
  for (const line of ['Abstract', 'ABSTRACT', 'Abstract:', 'Summary']) assert.equal(matchSectionHeading(line), 'abstract', line)
  for (const line of ['1. Introduction', '2 Introduction', 'III. Introduction', 'Background']) {
    assert.equal(matchSectionHeading(line), 'introduction', line)
  }
  for (const line of ['Method', 'Methods', 'Methodology:', '3. Proposed Controller', 'System Model']) {
    assert.equal(matchSectionHeading(line), 'method', line)
  }
  for (const line of ['Results', 'Simulation Results', 'Case Study', 'Numerical Validation', '4. Experimental Results']) {
    assert.equal(matchSectionHeading(line), 'results', line)
  }
  for (const line of ['Conclusion', 'Conclusions', 'Concluding Remarks', '5. Conclusion and Future Work']) {
    assert.equal(matchSectionHeading(line), 'conclusion', line)
  }
  assert.equal(matchSectionHeading('References'), 'references')
  assert.equal(matchSectionHeading('Bibliography:'), 'references')
  // 不该误判的
  assert.equal(matchSectionHeading('This paper proposes a new method for inertia support in low inertia grids, and it is quite long indeed'), null)
  assert.equal(matchSectionHeading(''), null)
  assert.equal(matchSectionHeading('Figure 3: results of the case study with 12 buses connected'), null)
})

test('pdf: 分节按标题顺序切，参考文献不吞进结论；同 key 只认首次出现', () => {
  const { sections, found, order } = splitSections(SAMPLE)
  assert.equal(found, true)
  assert.deepEqual(order, ['abstract', 'introduction', 'method', 'results', 'conclusion', 'references'])
  assert.match(sections.abstract.text, /low-inertia problem/)
  assert.match(sections.method.text, /first-order frequency loop/)
  assert.match(sections.results.text, /IEEE 9-bus/)
  assert.match(sections.conclusion.text, /transient frequency response/)
  assert.match(sections.references.text, /Some Author/)
  assert.ok(!sections.conclusion.text.includes('Some Author'), 'References 不该被并入 Conclusion')
  assert.equal(sections.abstract.chars, sections.abstract.text.length)
  assert.equal(sections.abstract.heading, 'Abstract')

  // 同一章节名第二次出现时不另起一节（防止交叉引用被当成标题），只保留首次切分
  const dup = splitSections(
    ['Abstract', 'aaa bbb ccc ddd eee fff ggg', 'Conclusion', 'x y z', 'Conclusion', 'tail'].join('\n'),
  )
  assert.equal(dup.order.filter((k) => k === 'conclusion').length, 1)
  assert.match(dup.sections.conclusion.text, /x y z/)
  assert.match(dup.sections.conclusion.text, /tail/, '第二次出现的同名标题不切分，留在本节正文里')
})

test('pdf: 无标题可分时退回全文，摘要取正文开头并标记 found=false', () => {
  const flat = 'A single blob of text without any recognisable section headings, repeated for length. '.repeat(60)
  const { sections, found, order } = splitSections(flat)
  assert.equal(found, false)
  assert.deepEqual(order, [])
  assert.equal(sections.abstract.chars, ABSTRACT_FALLBACK_CHARS)
  assert.match(sections.abstract.heading, /未识别到 Abstract/)
})

test('pdf: buildPdfDoc 结构完整、不复制原始字节', () => {
  const bytes = Buffer.from('%PDF-1.4 fake')
  const doc = buildPdfDoc(bytes, { sourcePath: 'D:\\tmp\\x.pdf', totalPages: 4, text: SAMPLE })
  assert.equal(doc.schemaVersion, PDF_SCHEMA_VERSION)
  assert.equal(doc.hash, pdfHash(bytes))
  assert.equal(doc.shortHash, doc.hash.slice(0, 16))
  assert.equal(doc.sourcePath, 'D:\\tmp\\x.pdf')
  assert.equal(doc.pages, 4)
  assert.equal(doc.chars, SAMPLE.length)
  assert.equal(doc.sectionsFound, true)
  assert.equal(doc.text, SAMPLE)
  // 文档里绝不能出现原始二进制/base64 —— 只存路径与文本
  const serialized = JSON.stringify(doc)
  assert.ok(!serialized.includes('%PDF-1.4 fake'), '不得把原始 PDF 字节写进抽取结果')
  assert.equal(doc.sourceBytes, bytes.length)
  for (const k of SECTION_KEYS) {
    if (doc.sections[k]) assert.equal(typeof doc.sections[k].text, 'string')
  }
})

test('pdf: 真实 unpdf 抽取仓库内夹具（1 页 / 分节齐全）', async () => {
  assert.ok(existsSync(FIXTURE), `夹具缺失：${FIXTURE}`)
  const doc = await extractPdfFile(FIXTURE)
  assert.equal(doc.pages, 1)
  assert.ok(doc.chars > 400, `抽取字符数过少：${doc.chars}`)
  assert.equal(doc.sectionsFound, true)
  assert.deepEqual(doc.sectionOrder, ['abstract', 'introduction', 'method', 'results', 'conclusion', 'references'])
  assert.match(doc.text, /Grid-Forming/)
  assert.equal(doc.sourcePath, FIXTURE)
  assert.ok(statSync(FIXTURE).size > 0)
})

test('pdf: extractPdfFile 对不存在/非法路径给类型化错误', async () => {
  await assert.rejects(() => extractPdfFile(dataPath('fixtures', 'nope.pdf')), (e) => e.code === 'E_PDF_NOT_FOUND')
  await assert.rejects(() => extractPdfFile(''), (e) => e.code === 'E_BAD_PDF_PATH')
  await assert.rejects(() => extractPdfFile(dataPath('fixtures')), (e) => e.code === 'E_PDF_NOT_FILE')
})

test('pdf: cardExcerpt 有界（不把整篇论文交给模型）', () => {
  const doc = buildPdfDoc(Buffer.from('x'), { text: SAMPLE })
  const excerpt = cardExcerpt(doc, { perSection: 60 })
  assert.ok(excerpt.includes('### abstract'))
  assert.ok(excerpt.includes('### method'))
  assert.ok(excerpt.length < SAMPLE.length * 3)
  assert.ok(!excerpt.includes('Some Author'), '参考文献不应进入卡片节选')
  assert.ok(cardExcerpt({ text: 'only text' }).includes('only text'), '无分节时退回全文节选')
})

test('pdf: 夹具文件本身在项目内（唯一可写根约束下的合法位置）', () => {
  const raw = readFileSync(FIXTURE)
  assert.ok(raw.length > 1000)
  assert.equal(raw.subarray(0, 5).toString('latin1'), '%PDF-')
  assert.ok(FIXTURE.startsWith(DATA_DIR))
})
