import { resolve } from 'node:path'
// tests/tools-permissions.test.mjs
//
// 权限矩阵的单测钉子（P-R7 硬要求：≥15 用例，覆盖根内/根外、红线、大小写不敏感、
// .. 穿越、UNC、符号链接）。**全部纯函数，不碰真实文件系统**——符号链接用注入的
// lstat 桩，于是"软链逃出授权根"能在纯 node 下稳定复现。

import test from 'node:test'
import assert from 'node:assert/strict'

import {
  DECISION,
  DEFAULT_DENY_ROOTS,
  DEFAULT_TOOL_TIERS,
  TIER,
  createGrantStore,
  createPolicy,
  describeRequest,
  evaluate,
  expandRoots,
  isUnder,
  matchRoot,
  normalizePath,
} from '../packages/core/src/tools/permissions.mjs'

const ROOT = resolve(import.meta.dirname, '..')
const DESKTOP = 'D:\\Desktop'
const OUT = 'D:\\AI_Workspace\\_out'

const fakePaths = {
  resolveInput(input) {
    if (input === 'project:') return { ok: true, path: ROOT }
    if (input === 'desktop:') return { ok: true, path: DESKTOP }
    return { ok: false, code: 'E_UNKNOWN_ALIAS', message: 'nope' }
  },
}

function policy(overrides = {}) {
  return createPolicy({ paths: fakePaths, ...overrides })
}

// ---------------------------------------------------------------- 路径工具

test('perm: normalizePath / isUnder 的大小写与分隔符不敏感', () => {
  assert.equal(normalizePath('d:/desktop/a'), 'd:\\desktop\\a')
  assert.equal(isUnder('D:\\Desktop\\a.docx', DESKTOP), true)
  assert.equal(isUnder('d:\\DESKTOP\\sub\\a.docx', DESKTOP), true)
  assert.equal(isUnder('D:\\DesktopX\\a.docx', DESKTOP), false, '前缀相同但不是子目录，必须判否')
  assert.equal(isUnder(DESKTOP, DESKTOP), true)
  assert.equal(matchRoot('D:\\Other\\x', [ROOT, DESKTOP]), null)
})

test('perm: expandRoots 展开别名，解析失败的根被丢弃而不是猜一个', () => {
  const roots = expandRoots(['project:', 'desktop:', OUT, 'bogus:'], fakePaths)
  assert.deepEqual(roots, [ROOT, DESKTOP, OUT])
})

// ---------------------------------------------------------------- 档位

test('perm: 未登记的工具一律 confirm（fail-closed，绝不默认 auto）', () => {
  const p = policy()
  assert.equal(p.tierOf('fs.read'), TIER.AUTO)
  assert.equal(p.tierOf('fs.write'), TIER.CONFIRM)
  assert.equal(p.tierOf('shell.run'), TIER.CONFIRM)
  assert.equal(p.tierOf('totally.unknown.tool'), TIER.CONFIRM)
  assert.equal(p.isKnown('fs.read'), true)
  assert.equal(p.isKnown('totally.unknown.tool'), false)
})

test('perm: 默认档位表里读类 auto、写类 confirm', () => {
  for (const id of ['fs.list', 'fs.stat', 'fs.search', 'fs.read', 'app.list', 'app.focus', 'clip.get', 'screen.capture']) {
    assert.equal(DEFAULT_TOOL_TIERS[id], TIER.AUTO, id)
  }
  for (const id of ['fs.write', 'fs.delete', 'fs.move', 'doc.docx', 'shell.run', 'app.launch', 'clip.set', 'net.fetch']) {
    assert.equal(DEFAULT_TOOL_TIERS[id], TIER.CONFIRM, id)
  }
})

// ---------------------------------------------------------------- 根内 / 根外

test('perm: 授权根内 + 只读工具 -> allow', () => {
  const p = policy()
  const d = evaluate({ toolId: 'fs.read', targets: [ROOT + '\\data\\config.json'], policy: p })
  assert.equal(d.decision, DECISION.ALLOW)
  assert.equal(d.code, null)
})

test('perm: 授权根内 + 写工具（桌面）-> confirm（未授权时不得自动执行）', () => {
  const p = policy()
  const d = evaluate({ toolId: 'doc.docx', targets: [DESKTOP + '\\自我介绍.docx'], write: true, policy: p })
  assert.equal(d.decision, DECISION.CONFIRM)
  assert.equal(d.tier, TIER.CONFIRM)
})

test('perm: 根外目标 -> deny（E_OUTSIDE_ROOTS）', () => {
  const p = policy()
  for (const t of [`${process.env.USERPROFILE}\\Documents\\a.docx`, 'E:\\随便\\a.txt', 'D:\\other\\x']) {
    const d = evaluate({ toolId: 'fs.read', targets: [t], policy: p })
    assert.equal(d.decision, DECISION.DENY, t)
    assert.equal(d.code, 'E_OUTSIDE_ROOTS', t)
  }
})

test('perm: 根外目标即使 tier=auto 也 deny（授权根优先于档位）', () => {
  const p = policy({ toolTiers: { 'fs.read': TIER.AUTO } })
  const d = evaluate({ toolId: 'fs.read', targets: ['C:\\secret\\x'], policy: p })
  assert.equal(d.decision, DECISION.DENY)
})

// ---------------------------------------------------------------- 拒绝根

test('perm: 拒绝根内连读都拒绝（cordis / orb 台账 / .dsh / .claude / island / 系统）', () => {
  const p = policy()
  const cases = [
    'D:\\AI_Workspace\\dsh-orb-cordis\\package.json',
    'D:\\dsh-orb-project\\台账.md',
    `${process.env.USERPROFILE}\\.dsh\\config.json`,
    `${process.env.USERPROFILE}\\.claude\\settings.json`,
    'D:\\AI_Workspace\\island-desktop\\src\\main.js',
    'C:\\Windows\\System32\\drivers\\etc\\hosts',
    'C:\\Program Files\\X\\y.exe',
  ]
  for (const t of cases) {
    const d = evaluate({ toolId: 'fs.read', targets: [t], policy: p })
    assert.equal(d.decision, DECISION.DENY, t)
    assert.equal(d.code, 'E_ROOT_DENIED', t)
  }
  assert.ok(DEFAULT_DENY_ROOTS.length >= 8)
})

test('perm: 拒绝根大小写不敏感（c:\\WINDOWS\\... 同样拒绝）', () => {
  const p = policy()
  const d = evaluate({ toolId: 'fs.read', targets: ['c:\\windows\\system32\\config\\SAM'], policy: p })
  assert.equal(d.decision, DECISION.DENY)
  assert.equal(d.code, 'E_ROOT_DENIED')
})

test('perm: 拒绝根优先于授权根（拒绝根不可被任何配置覆盖）', () => {
  const p = policy()
  const d = evaluate({ toolId: 'fs.write', targets: ['C:\\Windows\\Temp\\x'], write: true, policy: p })
  assert.equal(d.code, 'E_ROOT_DENIED')
})

// ---------------------------------------------------------------- 红线

test('perm: 红线文件即使在项目根内也拒绝（secrets.json / settings.json / desktop.ini）', () => {
  const p = policy()
  const cases = [
    [ROOT + '\\data\\secrets.json', 'fs.read'],
    [ROOT + '\\data\\secrets.json', 'fs.write'],
    [ROOT + '\\.claude\\settings.json', 'fs.read'],
    [DESKTOP + '\\desktop.ini', 'fs.write'],
  ]
  for (const [t, tool] of cases) {
    const d = evaluate({ toolId: tool, targets: [t], policy: p })
    assert.equal(d.decision, DECISION.DENY, t)
    assert.equal(d.code, 'E_REDLINE', t)
  }
})

test('perm: 非红线同名文件不误伤（my.settings.json.bak 不算）', () => {
  const p = policy()
  const d = evaluate({ toolId: 'fs.read', targets: [ROOT + '\\data\\secrets.json.bak'], policy: p })
  assert.equal(d.decision, DECISION.ALLOW)
})

// ---------------------------------------------------------------- 穿越 / UNC

test('perm: .. 穿越在权限层再拒一次（纵深防御）', () => {
  const p = policy()
  const d = evaluate({ toolId: 'fs.read', targets: [ROOT + '\\data\\..\\..\\outside\\x'], policy: p })
  assert.equal(d.decision, DECISION.DENY)
  assert.equal(d.code, 'E_TRAVERSAL')
})

test('perm: UNC 路径一律拒绝（网络位置不可审计）', () => {
  const p = policy()
  for (const t of ['\\\\srv\\share\\x', '\\\\?\\C:\\x']) {
    const d = evaluate({ toolId: 'fs.read', targets: [t], policy: p })
    assert.equal(d.decision, DECISION.DENY, t)
    assert.equal(d.code, 'E_UNC', t)
  }
})

// ---------------------------------------------------------------- 符号链接

test('perm: 符号链接指向授权根外 -> deny（E_SYMLINK_ESCAPE）', () => {
  const p = policy()
  const lstat = (t) =>
    t === ROOT + '\\link.docx'
      ? { isSymbolicLink: true, realpath: `${process.env.USERPROFILE}\\.dsh\\secret` }
      : null
  const d = evaluate({ toolId: 'fs.read', targets: [ROOT + '\\link.docx'], policy: p, lstat })
  assert.equal(d.decision, DECISION.DENY)
  assert.equal(d.code, 'E_SYMLINK_ESCAPE')
})

test('perm: 符号链接指向授权根内 -> 放行（不误伤合法软链）', () => {
  const p = policy()
  const lstat = () => ({ isSymbolicLink: true, realpath: DESKTOP + '\\real.docx' })
  const d = evaluate({ toolId: 'fs.read', targets: [ROOT + '\\link.docx'], policy: p, lstat })
  assert.equal(d.decision, DECISION.ALLOW)
})

test('perm: 符号链接指向拒绝根 -> deny（即使落在授权根内）', () => {
  const p = policy()
  const lstat = () => ({ isSymbolicLink: true, realpath: 'D:\\dsh-orb-project\\台账.md' })
  const d = evaluate({ toolId: 'fs.read', targets: [ROOT + '\\link.md'], policy: p, lstat })
  assert.equal(d.code, 'E_SYMLINK_ESCAPE')
})

test('perm: lstat 抛异常时按"探测不到"处理，不因探测失败而放行到根外', () => {
  const p = policy()
  const lstat = () => {
    throw new Error('ENOENT')
  }
  const d = evaluate({ toolId: 'fs.read', targets: [ROOT + '\\ghost'], policy: p, lstat })
  assert.equal(d.decision, DECISION.ALLOW, '探测失败不应把合法路径变拒绝；真正的边界由授权根保证')
})

// ---------------------------------------------------------------- 会话授权

test('perm: grant 只能抹掉 confirm，永远抹不掉 deny', () => {
  const p = policy()
  const g = createGrantStore()
  g.grant('fs.write')
  // confirm -> allow
  const a = evaluate({ toolId: 'fs.write', targets: [DESKTOP + '\\a.txt'], write: true, policy: p, grants: g })
  assert.equal(a.decision, DECISION.ALLOW)
  assert.equal(a.code, 'E_GRANTED')
  // deny 依然 deny
  const b = evaluate({ toolId: 'fs.write', targets: ['C:\\Windows\\x'], write: true, policy: p, grants: g })
  assert.equal(b.decision, DECISION.DENY)
  assert.equal(b.code, 'E_ROOT_DENIED')
})

test('perm: grant 作用域只对被授予的工具生效', () => {
  const p = policy()
  const g = createGrantStore()
  g.grant('fs.write')
  const d = evaluate({ toolId: 'fs.delete', targets: [DESKTOP + '\\a.txt'], policy: p, grants: g })
  assert.equal(d.decision, DECISION.CONFIRM)
  assert.equal(g.list().length, 1)
  g.clear()
  assert.equal(g.has('fs.write'), false)
})

// ---------------------------------------------------------------- 其它

test('perm: 工具名为空 / 非法 -> deny', () => {
  const p = policy()
  assert.equal(evaluate({ toolId: '', targets: [], policy: p }).code, 'E_TOOL_UNKNOWN')
  assert.equal(evaluate({ toolId: null, targets: [], policy: p }).code, 'E_TOOL_UNKNOWN')
})

test('perm: 无文件目标的工具（app.list / clip.get）走档位本身', () => {
  const p = policy()
  assert.equal(evaluate({ toolId: 'app.list', targets: [], policy: p }).decision, DECISION.ALLOW)
  assert.equal(evaluate({ toolId: 'clip.set', targets: [], policy: p }).decision, DECISION.CONFIRM)
})

test('perm: 多个目标里有一个越界 -> 整次调用 deny（不部分执行）', () => {
  const p = policy()
  const d = evaluate({ toolId: 'fs.copy', targets: [DESKTOP + '\\a.txt', 'C:\\nope\\b.txt'], policy: p })
  assert.equal(d.decision, DECISION.DENY)
  assert.equal(d.code, 'E_OUTSIDE_ROOTS')
})

test('perm: tier=deny 的工具即便在授权根内也拒绝', () => {
  const p = policy({ toolTiers: { 'fs.delete': TIER.DENY } })
  const d = evaluate({ toolId: 'fs.delete', targets: [ROOT + '\\tmp\\x'], policy: p })
  assert.equal(d.decision, DECISION.DENY)
  assert.equal(d.code, 'E_TOOL_DENIED')
})

test('perm: describeRequest 文案含工具中文名与目标绝对路径', () => {
  const p = policy()
  const d = evaluate({ toolId: 'doc.docx', targets: [DESKTOP + '\\自我介绍.docx'], write: true, policy: p })
  const r = describeRequest({ toolId: 'doc.docx', args: { title: '自我介绍' }, targets: [DESKTOP + '\\自我介绍.docx'], decision: d })
  assert.equal(r.what, '生成 Word 文档')
  assert.equal(r.where, DESKTOP + '\\自我介绍.docx')
  assert.match(r.title, /需要批准/)
})

test('perm: 策略可被 data\\config.json 的 tools 段覆盖（授权根与档位）', () => {
  const p = policy({ config: { tools: { allowRoots: ['project:'], tiers: { 'fs.read': 'confirm' } } } })
  assert.deepEqual(p.roots, [ROOT])
  assert.equal(p.tierOf('fs.read'), TIER.CONFIRM)
  assert.equal(evaluate({ toolId: 'fs.read', targets: [DESKTOP + '\\a'], policy: p }).code, 'E_OUTSIDE_ROOTS')
})
