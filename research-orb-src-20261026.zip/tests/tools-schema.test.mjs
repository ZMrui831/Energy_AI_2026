// tests/tools-schema.test.mjs
//
// 参数校验（P-R7）：**校验失败必须拒绝，绝不猜测补全**（COERCE 恒为 false）。
// 自己实现而非引 ajv：只用得到 type/properties/required/enum/范围/长度/items/
// additionalProperties 这一小片，自写可以精确控制"缺参数就是错"这条纪律。

import test from 'node:test'
import assert from 'node:assert/strict'

import { COERCE, SchemaError, assertValid, formatErrors, validate } from '../packages/core/src/tools/schema.mjs'

const SCHEMA = {
  type: 'object',
  properties: {
    path: { type: 'string', minLength: 1, maxLength: 200 },
    content: { type: 'string' },
    num: { type: 'integer', minimum: 1, maximum: 10 },
    ratio: { type: 'number', exclusiveMinimum: 0, exclusiveMaximum: 1 },
    mode: { type: 'string', enum: ['read', 'write'] },
    items: { type: 'array', items: { type: 'string' }, minItems: 1, maxItems: 3 },
    flag: { type: 'boolean' },
  },
  required: ['path'],
  additionalProperties: false,
}

test('schema: 合法参数通过', () => {
  const r = validate(SCHEMA, { path: 'a', num: 5, mode: 'read', items: ['x'], flag: true })
  assert.equal(r.ok, true)
  assert.deepEqual(r.errors, [])
})

test('schema: 缺必填 -> E_REQUIRED（不猜测补全）', () => {
  const r = validate(SCHEMA, {})
  assert.equal(r.ok, false)
  assert.equal(r.errors[0].code, 'E_REQUIRED')
  assert.equal(r.errors[0].path, '$.path')
  assert.equal(COERCE, false, 'COERCE 必须恒为 false：缺参数就是错')
})

test('schema: 类型不符 -> E_TYPE（不强制转换）', () => {
  assert.equal(validate(SCHEMA, { path: 123 }).errors[0].code, 'E_TYPE')
  assert.equal(validate(SCHEMA, { path: 'a', flag: 'yes' }).errors[0].code, 'E_TYPE')
  assert.equal(validate(SCHEMA, { path: 'a', items: 'x' }).errors[0].code, 'E_TYPE')
})

test('schema: integer 也接受 number（JSON Schema 语义），但小数不算 integer', () => {
  assert.equal(validate(SCHEMA, { path: 'a', num: 3 }).ok, true)
  assert.equal(validate(SCHEMA, { path: 'a', num: 3.5 }).errors[0].code, 'E_TYPE')
  assert.equal(validate(SCHEMA, { path: 'a', ratio: 0.5 }).ok, true)
})

test('schema: 范围与边界（minimum / maximum / exclusive*）', () => {
  assert.equal(validate(SCHEMA, { path: 'a', num: 0 }).errors[0].code, 'E_MINIMUM')
  assert.equal(validate(SCHEMA, { path: 'a', num: 11 }).errors[0].code, 'E_MAXIMUM')
  assert.equal(validate(SCHEMA, { path: 'a', num: 1 }).ok, true)
  assert.equal(validate(SCHEMA, { path: 'a', ratio: 0 }).errors[0].code, 'E_EXCLUSIVE_MINIMUM')
  assert.equal(validate(SCHEMA, { path: 'a', ratio: 1 }).errors[0].code, 'E_EXCLUSIVE_MAXIMUM')
})

test('schema: 长度（minLength / maxLength）与空串', () => {
  assert.equal(validate(SCHEMA, { path: '' }).errors[0].code, 'E_MIN_LENGTH')
  assert.equal(validate(SCHEMA, { path: 'x'.repeat(201) }).errors[0].code, 'E_MAX_LENGTH')
})

test('schema: enum 取值白名单', () => {
  assert.equal(validate(SCHEMA, { path: 'a', mode: 'read' }).ok, true)
  const r = validate(SCHEMA, { path: 'a', mode: 'delete' })
  assert.equal(r.errors[0].code, 'E_ENUM')
  assert.match(r.errors[0].message, /read/)
})

test('schema: 数组元素逐个校验 + 条数上下限', () => {
  assert.equal(validate(SCHEMA, { path: 'a', items: ['x', 2] }).errors[0].code, 'E_TYPE')
  assert.equal(validate(SCHEMA, { path: 'a', items: [] }).errors[0].code, 'E_MIN_ITEMS')
  assert.equal(validate(SCHEMA, { path: 'a', items: ['1', '2', '3', '4'] }).errors[0].code, 'E_MAX_ITEMS')
})

test('schema: additionalProperties=false 拒绝未声明参数', () => {
  const r = validate(SCHEMA, { path: 'a', sneaky: 1 })
  assert.equal(r.ok, false)
  assert.equal(r.errors[0].code, 'E_UNKNOWN_ARG')
})

test('schema: assertValid 抛出 SchemaError，错误含工具名与首个错误', () => {
  assert.throws(
    () => assertValid(SCHEMA, {}, 'doc.docx'),
    (e) => e instanceof SchemaError && e.code === 'E_BAD_ARGS' && /doc\.docx/.test(e.message),
  )
  assert.equal(assertValid(SCHEMA, { path: 'a' }, 'doc.docx'), true)
})

test('schema: formatErrors 压成一行人话（界面/日志直接用）', () => {
  const s = formatErrors(validate(SCHEMA, { mode: 'bad' }).errors)
  assert.match(s, /\$\.path/)
  assert.match(s, /\$\.mode/)
})

test('schema: pattern 正则（如 .docx 后缀约束）', () => {
  const s = { type: 'object', properties: { p: { type: 'string', pattern: '\\.docx$' } }, required: ['p'], additionalProperties: false }
  assert.equal(validate(s, { p: 'a.docx' }).ok, true)
  assert.equal(validate(s, { p: 'a.pdf' }).errors[0].code, 'E_PATTERN')
})

test('schema: 嵌套过深有上限（防恶意/失控的深层结构）', () => {
  let node = { type: 'string' }
  for (let i = 0; i < 20; i += 1) node = { type: 'object', properties: { a: node } }
  let value = 'deep'
  for (let i = 0; i < 20; i += 1) value = { a: value }
  const r = validate(node, value)
  assert.equal(r.ok, false)
  assert.ok(r.errors.some((e) => e.code === 'E_TOO_DEEP'))
})

test('schema: 空 schema（无 properties）不报错', () => {
  assert.equal(validate({ type: 'object', properties: {} }, { anything: 1 }).ok, true)
})
