// tests/vault-notes.test.mjs —— 笔记库插件：写入/读回/负向（草稿拒绝）
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, mkdirSync, rmSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, dataPath } from '../packages/core/src/safefs.mjs'
import { createStore } from '../packages/core/src/db.mjs'
import { createClaim, attachEvidence, publishClaim } from '../packages/core/src/lifecycle/publish.mjs'
import { writeClaimToVault, readVaultNote, VaultError } from '../packages/plugins/vault-notes/index.mjs'

const DIR = dataPath('tmp', 'test-vault-notes')

async function build() {
  if (existsSync(DIR)) rmSync(DIR, { recursive: true, force: true })
  mkdirSync(DIR, { recursive: true })
  const store = await createStore({ driver: 'sqlite', dbPath: join(DIR, 'orb.sqlite'), dataDir: DIR })
  store.initMigrations()
  store.insertRawFrame({ id: 'rf-t', file_path: join(DIR, 's.png'), sha256: 'b'.repeat(64), sensitivity: 'normal', created_at: new Date().toISOString(), expires_at: new Date(Date.now() + 3600000).toISOString(), status: 'ready', size_bytes: 1, format: 'png', mode: 'lowres', monitor_id: 'M1', consent_id: 'demo', trace_id: 'tr-t' })
  createClaim(store, { id: 'clm-pub', kind: 'observation', text: '测试结论正文。', evidenceMode: 'direct' })
  attachEvidence(store, { claimId: 'clm-pub', evidenceId: 'rf-t', layer: 'raw_frame', relation: 'direct', sha256: 'b'.repeat(64) })
  publishClaim(store, 'clm-pub')
  createClaim(store, { id: 'clm-draft', kind: 'observation', text: '未核验', evidenceMode: 'none' })
  return store
}

test('vault: 已发布结论可写入且含 evidence_id', async () => {
  const store = await build()
  const r = writeClaimToVault({ store, claimId: 'clm-pub', vaultRoot: 'data/tmp/test-vault-notes/v' })
  assert.ok(existsSync(r.path))
  const raw = readFileSync(r.path, 'utf8')
  assert.match(raw, /evidence_ids:\s*\[rf-t\]/)
  assert.match(raw, /status:\s*published/)
  store.close()
})

test('vault: 读回可解析 front-matter 且正文一致', async () => {
  const store = await build()
  writeClaimToVault({ store, claimId: 'clm-pub', vaultRoot: 'data/tmp/test-vault-notes/v' })
  const n = readVaultNote({ claimId: 'clm-pub', vaultRoot: 'data/tmp/test-vault-notes/v' })
  assert.equal(n.frontMatter.claim_id, 'clm-pub')
  assert.ok(String(n.text).includes('测试结论正文'))
  store.close()
})

test('vault: 草稿一律拒绝（E_NOT_PUBLISHED）且不落文件', async () => {
  const store = await build()
  assert.throws(() => writeClaimToVault({ store, claimId: 'clm-draft', vaultRoot: 'data/tmp/test-vault-notes/v' }), (e) => e instanceof VaultError && e.code === 'E_NOT_PUBLISHED')
  assert.equal(existsSync(join(PROJECT_ROOT, 'data/tmp/test-vault-notes/v/研究结论/clm-draft.md')), false)
  store.close()
})