// tests/db.test.mjs —— S3 存储层（db.mjs）回归：≥10 例。
//
// 运行环境：node:sqlite 需要 Node>=23.4（验收统一用 D:\node.exe v24.20.0）。
// sqlite 专属用例先探测能力，不可用则 skip（真 skip，单列）。
// jsonl 降级用例在任何 Node 下都必须全跑。
// 临时夹具放在 data/db/ 下的 mkdtemp 目录（safefs assertInsideRoot 只放行根内路径），
// try/finally 清理。

import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, mkdirSync, readdirSync, rmSync, writeFileSync, readFileSync, appendFileSync } from 'node:fs'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'

import {
  createStore, computeExpiry, detectSqlite, DEFAULT_LIFECYCLE_CONFIG,
  mergeLifecycleConfig, DbError,
} from '../packages/core/src/db.mjs'
import { PROJECT_ROOT, dataPath } from '../packages/core/src/safefs.mjs'

const MIGRATIONS_DIR = join(PROJECT_ROOT, 'packages', 'core', 'src', 'db', 'migrations')
const MIGRATION_0001 = readFileSync(join(MIGRATIONS_DIR, '0001_init.sql'), 'utf8')
const hasSqlite = await detectSqlite()

const HOUR = 3_600_000
const MIN = 60_000
const T0 = '2026-10-17T00:00:00.000Z'

function makeFixture(label) {
  mkdirSync(dataPath('db'), { recursive: true })
  const dir = mkdtempSync(dataPath('db', `dbtest-${label}-`))
  return {
    dir,
    dbPath: join(dir, 't.sqlite'),
    dataDir: dir,
    migDir: join(dir, 'migrations'),
  }
}

function frame(overrides = {}) {
  return {
    id: 'f-' + Math.random().toString(36).slice(2, 10),
    file_path: join(PROJECT_ROOT, 'data', 'shots', 'nonexistent-' + Math.random().toString(36).slice(2, 8) + '.png'),
    sha256: 'a'.repeat(64),
    sensitivity: 'normal',
    created_at: T0,
    expires_at: T0,
    ...overrides,
  }
}

// ---------------------------------------------------------------------------
// 迁移器
// ---------------------------------------------------------------------------

test('sqlite 迁移：空库全部应用，重复运行幂等全跳过', { skip: hasSqlite ? false : 'node:sqlite unavailable（需要 Node>=23.4，用 D:\\node.exe）' }, async () => {
  const fx = makeFixture('mig-empty')
  try {
    const store = await createStore({ driver: 'sqlite', dbPath: fx.dbPath })
    // 动态口径：迁移目录里有几个 .sql 就应应用几个（S6 起含 0002_claim_evidence.sql）
    const migCount = readdirSync(MIGRATIONS_DIR).filter((f) => f.endsWith('.sql')).length
    const r1 = store.initMigrations()
    assert.equal(r1.applied, migCount, `迁移目录 ${migCount} 个 .sql 应被全部应用`)
    assert.equal(r1.skipped, 0)
    const r2 = store.initMigrations()
    assert.deepEqual(r2, { applied: 0, skipped: migCount }, '重复运行必须全部跳过')
    // 表确实建出来了
    const counts = store.counts()
    assert.equal(counts.raw_frame.ready, 0)
    store.close()
  } finally {
    rmFixture(fx)
  }
})

test('sqlite 迁移：已有库只补新迁移，再次重跑幂等', { skip: hasSqlite ? false : 'node:sqlite unavailable' }, async () => {
  const fx = makeFixture('mig-incremental')
  try {
    mkdirSync(fx.migDir)
    writeFileSync(join(fx.migDir, '0001_init.sql'), MIGRATION_0001, 'utf8')
    const s1 = await createStore({ driver: 'sqlite', dbPath: fx.dbPath })
    assert.deepEqual(s1.initMigrations(fx.migDir), { applied: 1, skipped: 0 })
    s1.close()

    // 之后再补一个 0002 迁移
    writeFileSync(join(fx.migDir, '0002_add_meta_note.sql'), 'ALTER TABLE app_meta ADD COLUMN note TEXT;', 'utf8')
    const s2 = await createStore({ driver: 'sqlite', dbPath: fx.dbPath })
    const r = s2.initMigrations(fx.migDir)
    assert.equal(r.applied, 1, '只应用新迁移')
    assert.equal(r.skipped, 1, '已应用的旧迁移跳过')
    s2.close()

    const s3 = await createStore({ driver: 'sqlite', dbPath: fx.dbPath })
    assert.deepEqual(s3.initMigrations(fx.migDir), { applied: 0, skipped: 2 }, '第三次运行幂等')
    s3.close()
  } finally {
    rmFixture(fx)
  }
})

test('sqlite 迁移：checksum 篡改 → fail-closed 抛 E_MIGRATION_CHECKSUM 且库内容未被修改', { skip: hasSqlite ? false : 'node:sqlite unavailable' }, async () => {
  const fx = makeFixture('mig-tamper')
  try {
    mkdirSync(fx.migDir)
    writeFileSync(join(fx.migDir, '0001_init.sql'), MIGRATION_0001, 'utf8')
    const s1 = await createStore({ driver: 'sqlite', dbPath: fx.dbPath })
    s1.initMigrations(fx.migDir)
    s1.insertRawFrame(frame({ id: 'keep-me' }))
    s1.close()

    // 篡改已应用迁移的文件内容
    appendFileSync(join(fx.migDir, '0001_init.sql'), '\n-- tampered\n', 'utf8')

    const s2 = await createStore({ driver: 'sqlite', dbPath: fx.dbPath })
    const before = s2.counts()
    assert.throws(() => s2.initMigrations(fx.migDir), (e) => e.code === 'E_MIGRATION_CHECKSUM', '必须抛 E_MIGRATION_CHECKSUM')
    const after = s2.counts()
    assert.deepEqual(after, before, 'fail-closed：库内容一个字节都不能动')
    assert.equal(after.raw_frame.ready, 1, '原有数据仍在')
    s2.close()
  } finally {
    rmFixture(fx)
  }
})

test('jsonl driver：initMigrations 为 no-op（降级路径不依赖 sqlite schema）', async () => {
  const fx = makeFixture('mig-jsonl')
  try {
    const store = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
    assert.equal(store.driver, 'jsonl')
    assert.deepEqual(store.initMigrations(), { applied: 0, skipped: 0 })
    store.close()
  } finally {
    rmFixture(fx)
  }
})

// ---------------------------------------------------------------------------
// raw_frame
// ---------------------------------------------------------------------------

test('sqlite raw_frame：insert/get 往返，默认 status=ready，expires 默认 +6h', { skip: hasSqlite ? false : 'node:sqlite unavailable' }, async () => {
  const fx = makeFixture('rf-sqlite')
  try {
    const store = await createStore({ driver: 'sqlite', dbPath: fx.dbPath })
    store.initMigrations()
    const f = frame({ id: 'rf-1', created_at: T0 })
    delete f.expires_at
    const row = store.insertRawFrame(f)
    assert.equal(row.status, 'ready')
    assert.equal(row.error, null)
    assert.equal(row.expires_at, new Date(Date.parse(T0) + 6 * HOUR).toISOString())
    const got = store.getRawFrame('rf-1')
    assert.equal(got.file_path, f.file_path)
    assert.equal(got.sha256, 'a'.repeat(64))
    assert.equal(store.getRawFrame('nope'), null)
    store.close()
  } finally {
    rmFixture(fx)
  }
})

test('jsonl raw_frame：同接口行为等价（insert/get/listExpiredReady/markDeleting）', async () => {
  const fx = makeFixture('rf-jsonl')
  try {
    const store = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
    const f1 = frame({ id: 'rf-a', created_at: T0, expires_at: '2026-10-17T01:00:00.000Z' })
    const f2 = frame({ id: 'rf-b', created_at: T0, expires_at: '2026-10-17T00:30:00.000Z' })
    const f3 = frame({ id: 'rf-c', created_at: T0, expires_at: '2099-01-01T00:00:00.000Z' })
    store.insertRawFrame(f1)
    store.insertRawFrame(f2)
    store.insertRawFrame(f3)
    assert.equal(store.getRawFrame('rf-a').status, 'ready')
    // listExpiredReady 按 expires_at 升序
    const expired = store.listExpiredReady('2026-10-18T00:00:00.000Z')
    assert.deepEqual(expired.map((r) => r.id), ['rf-b', 'rf-a'])
    // markDeleting 批量置 deleting，且只动 ready
    store.markDeleting(['rf-a', 'rf-b', 'ghost'])
    assert.equal(store.getRawFrame('rf-a').status, 'deleting')
    assert.equal(store.getRawFrame('rf-b').status, 'deleting')
    assert.deepEqual(store.listByStatus('deleting').map((r) => r.id).sort(), ['rf-a', 'rf-b'])
    // tombstone observation 也走一遍（同接口断言）
    store.upsertObservation({ id: 'ob-1', kind: 'window', source_frame_id: 'rf-c', ocr_excerpt: 'hello' })
    store.tombstoneObservation('ob-1')
    const ob = store.getObservation('ob-1')
    assert.equal(ob.status, 'deleted')
    assert.equal(ob.ocr_excerpt, null)
    assert.ok(ob.deleted_at)
    store.close()
  } finally {
    rmFixture(fx)
  }
})

test('敏感帧永不落盘：两 driver 都抛 E_SENSITIVE_NO_PERSIST 且记 blocked-sensitive-persist 审计', async () => {
  const fx = makeFixture('rf-sensitive')
  try {
    const sSql = await createStore({ driver: 'sqlite', dbPath: fx.dbPath })
    sSql.initMigrations()
    assert.throws(() => sSql.insertRawFrame(frame({ id: 's-1', sensitivity: 'sensitive' })), (e) => e.code === 'E_SENSITIVE_NO_PERSIST')
    assert.equal(sSql.getRawFrame('s-1'), null, '敏感帧不得出现在 raw_frame')
    const ev = sSql.listAuditEvents({ kind: 'blocked-sensitive-persist' })
    assert.equal(ev.length, 1, 'sqlite：blocked-sensitive-persist 审计必须落账')
    sSql.close()

    const sJson = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
    assert.throws(() => sJson.insertRawFrame(frame({ id: 's-2', sensitivity: 'sensitive' })), (e) => e.code === 'E_SENSITIVE_NO_PERSIST')
    assert.equal(sJson.getRawFrame('s-2'), null)
    assert.equal(sJson.listAuditEvents({ kind: 'blocked-sensitive-persist' }).length, 1, 'jsonl：blocked-sensitive-persist 审计必须落账')
    sJson.close()
  } finally {
    rmFixture(fx)
  }
})

test('sha256 约束：非 64 位十六进制被两 driver 拒绝（sqlite 还有 CHECK 兜底）', { skip: hasSqlite ? false : 'node:sqlite unavailable' }, async () => {
  const fx = makeFixture('rf-sha')
  try {
    const sSql = await createStore({ driver: 'sqlite', dbPath: fx.dbPath })
    sSql.initMigrations()
    assert.throws(() => sSql.insertRawFrame(frame({ id: 'x1', sha256: 'deadbeef' })), (e) => e.code === 'E_BAD_SHA256')
    sSql.close()
    const sJson = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
    assert.throws(() => sJson.insertRawFrame(frame({ id: 'x2', sha256: 'zz'.repeat(32) })), (e) => e.code === 'E_BAD_SHA256')
    sJson.close()
  } finally {
    rmFixture(fx)
  }
})

// ---------------------------------------------------------------------------
// observation / evidence_item（判据 3 的外键语义）
// ---------------------------------------------------------------------------

test('observation 墓碑后 evidence_item 仍可引用；observation 引用不存在的帧被拒', { skip: hasSqlite ? false : 'node:sqlite unavailable' }, async () => {
  const fx = makeFixture('ob-fk')
  try {
    const store = await createStore({ driver: 'sqlite', dbPath: fx.dbPath })
    store.initMigrations()
    store.insertRawFrame(frame({ id: 'rf-src' }))
    store.upsertObservation({ id: 'ob-1', kind: 'window', source_frame_id: 'rf-src', ocr_excerpt: 'secret text' })
    store.tombstoneObservation('ob-1')
    const ob = store.getObservation('ob-1')
    assert.equal(ob.status, 'deleted')
    assert.equal(ob.ocr_excerpt, null, '墓碑必须清空 ocr_excerpt')
    assert.ok(ob.deleted_at)
    // 行保留 → evidence_item 依旧可引用（FK 是 ON DELETE SET NULL，tombstone 不删行）
    const ev = store.insertEvidenceItem({ id: 'ev-1', observation_id: 'ob-1' })
    assert.equal(ev.availability, 'available')
    // 引用不存在的 raw_frame → FK 拒绝
    assert.throws(() => store.upsertObservation({ id: 'ob-2', kind: 'window', source_frame_id: 'ghost-frame' }))
    store.close()
  } finally {
    rmFixture(fx)
  }
})

test('jsonl 同语义：墓碑 + evidence 引用 + FK 校验（observed 拒绝幽灵引用）', async () => {
  const fx = makeFixture('ob-fk-jsonl')
  try {
    const store = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
    store.insertRawFrame(frame({ id: 'rf-src' }))
    store.upsertObservation({ id: 'ob-1', kind: 'window', source_frame_id: 'rf-src', ocr_excerpt: 'text' })
    store.tombstoneObservation('ob-1')
    store.insertEvidenceItem({ id: 'ev-1', observation_id: 'ob-1' })
    const counts = store.counts()
    assert.equal(counts.observation.deleted, 1)
    assert.equal(counts.evidence_item, 1)
    assert.throws(() => store.insertEvidenceItem({ id: 'ev-2', observation_id: 'ghost' }), (e) => e.code === 'E_FK_VIOLATION')
    store.close()
  } finally {
    rmFixture(fx)
  }
})

// ---------------------------------------------------------------------------
// audit_event
// ---------------------------------------------------------------------------

test('audit_event 非法 JSON 拒绝：非法字符串与不可序列化对象两 driver 都抛', { skip: hasSqlite ? false : 'node:sqlite unavailable' }, async () => {
  const fx = makeFixture('audit-json')
  try {
    const sSql = await createStore({ driver: 'sqlite', dbPath: fx.dbPath })
    sSql.initMigrations()
    assert.throws(() => sSql.insertAuditEvent({ ts: T0, kind: 'k', metadata: '{not-json' }), (e) => e.code === 'E_BAD_AUDIT_JSON')
    const circular = {}
    circular.self = circular
    assert.throws(() => sSql.insertAuditEvent({ ts: T0, kind: 'k', metadata: circular }), (e) => e.code === 'E_BAD_AUDIT_JSON')
    // 合法对象 → metadata_json 存储且可读回
    sSql.insertAuditEvent({ ts: T0, kind: 'ok-kind', metadata: { a: 1 } })
    const ev = sSql.listAuditEvents({ kind: 'ok-kind' })
    assert.deepEqual(JSON.parse(ev[0].metadata_json), { a: 1 })
    sSql.close()

    const sJson = await createStore({ driver: 'jsonl', dataDir: fx.dataDir })
    assert.throws(() => sJson.insertAuditEvent({ ts: T0, kind: 'k', metadata: '{bad' }), (e) => e.code === 'E_BAD_AUDIT_JSON')
    sJson.close()
  } finally {
    rmFixture(fx)
  }
})

// ---------------------------------------------------------------------------
// counts 形状
// ---------------------------------------------------------------------------

test('counts() 形状：raw_frame 四状态 / observation 两状态 / 汇总计数字段', { skip: hasSqlite ? false : 'node:sqlite unavailable' }, async () => {
  const fx = makeFixture('counts')
  try {
    const store = await createStore({ driver: 'sqlite', dbPath: fx.dbPath })
    store.initMigrations()
    store.insertRawFrame(frame({ id: 'c1' }))
    store.insertRawFrame(frame({ id: 'c2' }))
    store.markDeleting(['c2'])
    const c = store.counts()
    assert.deepEqual(Object.keys(c).sort(), ['audit_event', 'evidence_item', 'observation', 'raw_frame', 'summary'])
    assert.deepEqual(c.raw_frame, { ready: 1, deleting: 1, deleted: 0, error: 0 })
    assert.deepEqual(c.observation, { active: 0, deleted: 0 })
    assert.equal(typeof c.summary, 'number')
    assert.equal(typeof c.evidence_item, 'number')
    assert.equal(typeof c.audit_event, 'number')
    store.close()
  } finally {
    rmFixture(fx)
  }
})

// ---------------------------------------------------------------------------
// computeExpiry（纯函数，两 Node 都跑）
// ---------------------------------------------------------------------------

test('computeExpiry：normal=+6h、learning=+20min、sensitive 抛 E_SENSITIVE_NO_PERSIST、坏 mode 抛错', () => {
  assert.equal(computeExpiry('normal', 'normal', DEFAULT_LIFECYCLE_CONFIG, Date.parse(T0)), new Date(Date.parse(T0) + 6 * HOUR).toISOString())
  assert.equal(computeExpiry('normal', 'learning', DEFAULT_LIFECYCLE_CONFIG, Date.parse(T0)), new Date(Date.parse(T0) + 20 * MIN).toISOString())
  assert.equal(computeExpiry('blocked', 'normal', DEFAULT_LIFECYCLE_CONFIG, Date.parse(T0)), new Date(Date.parse(T0) + 6 * HOUR).toISOString())
  assert.throws(() => computeExpiry('sensitive', 'normal'), (e) => e.code === 'E_SENSITIVE_NO_PERSIST')
  assert.throws(() => computeExpiry('sensitive', 'learning'), (e) => e.code === 'E_SENSITIVE_NO_PERSIST', '敏感帧不管什么 mode 都拒绝')
  assert.throws(() => computeExpiry('normal', 'forever'), (e) => e.code === 'E_BAD_MODE')
})

test('mergeLifecycleConfig：注入覆盖按节合并，非法输入回落默认', () => {
  const m = mergeLifecycleConfig({ retention: { rawFrameNormalHours: 1 }, cleanup: { batchSize: 7 } })
  assert.equal(m.retention.rawFrameNormalHours, 1)
  assert.equal(m.retention.rawFrameLearningMinutes, 20, '未覆盖字段保留默认')
  assert.equal(m.cleanup.batchSize, 7)
  assert.equal(m.cleanup.maxConsecutiveFailures, 3)
  assert.equal(mergeLifecycleConfig(null).version, 1)
  assert.equal(mergeLifecycleConfig('garbage').retention.observationDays, 7)
})

test('createStore 参数纪律：坏 driver 抛 E_BAD_DRIVER；driver=auto 缺 dbPath/dataDir 抛 E_BAD_PATH', async () => {
  await assert.rejects(() => createStore({ driver: 'mongo' }), (e) => e.code === 'E_BAD_DRIVER')
  await assert.rejects(() => createStore({ driver: 'jsonl' }), (e) => e.code === 'E_BAD_PATH')
})

function rmFixture(dir) {
  try {
    rmSync(dir, { recursive: true, force: true })
  } catch {
    // 宿主 safe-delete shim 偶发失败时，派生无 shim 子进程原生删除兜底
    spawnSync(
      process.execPath,
      ['-e', "const fs=require('node:fs');fs.rmSync(process.argv[1],{recursive:true,force:true})", dir],
      { env: { ...process.env, NODE_OPTIONS: '' }, timeout: 30_000 },
    )
  }
}
