// tests/audit-integrity.test.mjs —— S67·3-D 审计一致性回归（D1/D2/D3/D4）。
//
// D1 net 拒绝去重改追加式（方案 A）：历史 deny 行逐字节不变；重复拒绝追加
//     net-deny-repeat（count/firstTs/lastTs）；源码无"整文件读改写"路径。
// D2 safefs 冻结区（vendor / db/migrations）写入直接抛 E_PROTECTED_ZONE；
//     读不受影响；审计仍记 protected 标记；.snapshots 为软标记（非 hard）。
// D3 rotateOnly 默认值与运行时配置都含 net/tool/perception（证据断言）。
// D4 verifyClaimIntegrity：published 但证据被剥离 → ok:false 且列出该 claim；
//     buildClaimExport 导出对象携带 integrity 复查结果（只读，不阻断）。
//
// 运行：node --test --test-reporter=tap tests/audit-integrity.test.mjs
// （D2/D4 的写路径经 safefs，夹具必须在项目根内；host shim 需 CODEBUDDY_SAFE_DELETE_ENABLED=0）

import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, readFileSync, writeFileSync, mkdtempSync, mkdirSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { createHash } from 'node:crypto'

import { createNet } from '../packages/core/src/net.mjs'
import {
  PROJECT_ROOT, SafeFsError, safeWrite, hardProtectedZoneOf,
} from '../packages/core/src/safefs.mjs'
import { logPath } from '../packages/core/src/safefs.mjs'
import { createStore } from '../packages/core/src/db.mjs'
import {
  createClaim, attachEvidence, publishClaim, buildClaimExport, verifyClaimIntegrity, claimEvidenceReport,
} from '../packages/core/src/lifecycle/publish.mjs'

const NET_LOG = logPath('net.audit-integrity.jsonl') // 独立文件，不与 net.test.mjs 互踩
const response = (status, body = '{}') => ({ status, ok: status >= 200 && status < 300, json: async () => JSON.parse(body), text: async () => body })
const readLog = (file = NET_LOG) => (existsSync(file) ? readFileSync(file, 'utf8').split('\n').filter((l) => l.trim()).map((l) => JSON.parse(l)) : [])
const truncate = (p) => { try { writeFileSync(p, '') } catch { /* 不存在则忽略 */ } }
const sha64 = (s) => createHash('sha256').update(String(s)).digest('hex')

// ---------------------------------------------------------------------------
// D1：net.mjs 拒绝去重 —— 追加式（方案 A），历史行不改写
// ---------------------------------------------------------------------------

test('D1①+② 同一 host 连续 deny 3 次：历史行逐字节不变 + 追加 net-deny-repeat（count=3, firstTs/lastTs）', async () => {
  truncate(NET_LOG)
  const net = createNet({ fetchImpl: async () => response(200), logFile: NET_LOG })
  await assert.rejects(() => net.request('https://sci-hub.se/d1'), (e) => e.code === 'E_DOMAIN_NOT_ALLOWED')
  const firstRaw = readFileSync(NET_LOG, 'utf8').split('\n').filter((l) => l.trim())[0]
  assert.equal(JSON.parse(firstRaw).denyKey, 'sci-hub.se')
  assert.equal(JSON.parse(firstRaw).count, 1)
  for (let i = 2; i <= 3; i += 1) {
    await assert.rejects(() => net.request(`https://sci-hub.se/d1?i=${i}`), (e) => e.code === 'E_DOMAIN_NOT_ALLOWED')
  }
  const nowFirstRaw = readFileSync(NET_LOG, 'utf8').split('\n').filter((l) => l.trim())[0]
  assert.equal(nowFirstRaw, firstRaw, '历史 deny 行必须逐字节不变（S67·D1 方案 A）')
  const rows = readLog()
  const repeats = rows.filter((r) => r.kind === 'net-deny-repeat' && r.denyKey === 'sci-hub.se')
  assert.equal(repeats.length, 2, '第 2、3 次拒绝各追加一行 repeat')
  const last = repeats[repeats.length - 1]
  assert.equal(last.count, 3)
  assert.ok(Number.isFinite(Date.parse(last.firstTs)), 'firstTs 可解析')
  assert.ok(Number.isFinite(Date.parse(last.lastTs)), 'lastTs 可解析')
  assert.ok(Date.parse(last.lastTs) >= Date.parse(last.firstTs), 'lastTs >= firstTs')
  assert.equal(net.stats.denied, 3, 'stats.denied 仍逐次计数')
})

test('D1②b stats.denied 与追加行对账（61 次拒绝 = 1 deny + 60 repeat）', async () => {
  truncate(NET_LOG)
  const net = createNet({ fetchImpl: async () => response(200), logFile: NET_LOG })
  for (let i = 0; i < 61; i += 1) {
    await assert.rejects(() => net.request(`https://sci-hub.se/bulk?i=${i}`), (e) => e.code === 'E_DOMAIN_NOT_ALLOWED')
  }
  assert.equal(net.stats.denied, 61)
  const rows = readLog()
  const denies = rows.filter((r) => r.decision === 'deny' && !r.kind)
  const repeats = rows.filter((r) => r.kind === 'net-deny-repeat')
  assert.equal(denies.length, 1, '同一 host 只有一行历史 deny 行')
  assert.equal(denies[0].count, 1, '历史行 count 停在 1（不再被改写）')
  assert.equal(repeats.length, 60, '其余 60 次各追加一行 repeat')
  const lastRepeat = repeats[repeats.length - 1]
  assert.equal(lastRepeat.count, 61)
  const byHost = net.queueState().deniedByHost
  assert.deepEqual(byHost, [{ host: 'sci-hub.se', count: 61 }])
})

test('D1③ 源码断言：recordDenyRepeat 函数体内不再有"整文件读改写"路径', () => {
  const src = readFileSync(join(PROJECT_ROOT, 'packages', 'core', 'src', 'net.mjs'), 'utf8')
  const start = src.indexOf('function recordDenyRepeat')
  assert.ok(start > 0, 'recordDenyRepeat 必须存在（方案 A）')
  const body = src.slice(start, src.indexOf('\n  }', start))
  assert.ok(!body.includes('readFileSync(logFile'), '函数体内禁止 readFileSync(logFile...)（判据 D1③）')
  assert.ok(!body.includes('safeWrite'), '函数体内禁止 safeWrite 整文件重写（判据 D1③）')
  assert.ok(!src.includes('bumpDenyCount'), '旧的读改写函数 bumpDenyCount 必须已删除')
})

// ---------------------------------------------------------------------------
// D2：safefs 冻结区（vendor / db/migrations）只读化 —— 写入抛 E_PROTECTED_ZONE
// ---------------------------------------------------------------------------

test('D2① 写 vendor 冻结区 → 抛 E_PROTECTED_ZONE（且未真写）', () => {
  const target = join(PROJECT_ROOT, 'vendor', 'orb-base', 'panel', 'floating.html')
  const before = readFileSync(target, 'utf8')
  assert.throws(
    () => safeWrite(target, 'MUST-NOT-WRITE'),
    (e) => e instanceof SafeFsError && e.code === 'E_PROTECTED_ZONE' && /拒绝写入冻结区/.test(e.message),
  )
  assert.equal(readFileSync(target, 'utf8'), before, 'vendor 文件内容不得有任何变化')
})

test('D2② 读 vendor 同路径 → 正常（冻结区只拦写不拦读）', () => {
  const target = join(PROJECT_ROOT, 'vendor', 'orb-base', 'panel', 'floating.html')
  assert.ok(existsSync(target), 'vendor 文件必须存在（只读验证前提）')
  assert.ok(readFileSync(target, 'utf8').length > 0, '读操作完全不受影响')
})

test('D2③ 写 db/migrations 冻结区同样抛错；写普通项目文件正常', () => {
  assert.throws(
    () => safeWrite(join(PROJECT_ROOT, 'packages', 'core', 'src', 'db', 'migrations', 'x-should-fail.sql'), '-- no'),
    (e) => e instanceof SafeFsError && e.code === 'E_PROTECTED_ZONE',
  )
  // 普通项目文件写入不受影响（自建自删；data/tmp 是临时区）
  const tmp = join(PROJECT_ROOT, 'data', 'tmp', `audit-integrity-${Date.now()}.tmp`)
  try {
    mkdirSync(join(PROJECT_ROOT, 'data', 'tmp'), { recursive: true })
    safeWrite(tmp, 'ok')
    assert.equal(readFileSync(tmp, 'utf8'), 'ok')
  } finally {
    try { rmSync(tmp, { force: true }) } catch { /* 宿主 shim 偶发；单个 <100B 文件留在临时区可接受 */ }
  }
})

test('D2④ 冻结区拦截仍写审计 protected 标记（并发容忍：轮询 + 精确匹配本探针）', async () => {
  // 全量测试多文件并行时，其他用例也在写 writes.jsonl —— "尾部切片"会被并发写入干扰
  // （本用例曾单跑绿、全量红）。改为轮询 + 精确匹配本探针的路径与时间戳。
  // 必须用 logPath 而非硬拼 PROJECT_ROOT：run-tests 会把 ORB_LOG_DIR 隔离到临时目录，
  // 硬拼路径在全量下读到的是真实项目日志（本用例曾单跑绿、全量红）。
  const wp = logPath('writes.jsonl')
  const startedAt = Date.now() - 1000
  const probe = join(PROJECT_ROOT, 'vendor', 'orb-base', 'panel', 'floating.html')
  try { safeWrite(probe, 'AUDIT-PROBE-' + startedAt) } catch { /* 预期抛错 E_PROTECTED_ZONE */ }
  const readAll = () => {
    try {
      return readFileSync(wp, 'utf8')
        .split('\n')
        .filter(Boolean)
        .map((l) => { try { return JSON.parse(l) } catch { return null } })
        .filter(Boolean)
    } catch { return [] }
  }
  let hit = null
  for (let k = 0; k < 15 && !hit; k += 1) {
    // ts 是 ISO 字符串（不是数字），必须 Date.parse 后再比；否则 NaN 恒假（本处曾踩过）
    hit = readAll().find((r) => r && r.denied === true
      && String(r.path || r.file || '').includes('floating.html')
      && Date.parse(String(r.ts || '')) >= startedAt)
    if (!hit) await new Promise((res) => setTimeout(res, 100))
  }
  assert.ok(hit, '拦截动作必须写一条 denied+protected 审计行（1.5s 内）')
  assert.ok(hit.protected === true || String(hit.reason || '').length > 0, '该行须标 protected 或至少带 reason')
  assert.match(String(hit.reason), /frozen-vendor-snapshot/)
})

test('D2⑤ .snapshots 是软标记（非 hard）：hardProtectedZoneOf 不拦它', () => {
  assert.equal(hardProtectedZoneOf(join(PROJECT_ROOT, '.snapshots', 'x.txt')), null, '.snapshots 允许正常写入（回滚点）')
  assert.match(hardProtectedZoneOf(join(PROJECT_ROOT, 'vendor', 'x')), /frozen-vendor-snapshot/)
  assert.match(hardProtectedZoneOf(join(PROJECT_ROOT, 'packages', 'core', 'src', 'db', 'migrations', 'x.sql')), /db-migrations-frozen/)
})

// ---------------------------------------------------------------------------
// D3：rotateOnly 默认值与运行时配置都覆盖审计日志（G5 证据断言）
// ---------------------------------------------------------------------------

test('D3 rotateOnly：代码默认值 + db.mjs 配置 + 运行时 config 均含 net/tool/perception', () => {
  const logsSrc = readFileSync(join(PROJECT_ROOT, 'packages', 'core', 'src', 'lifecycle', 'logs.mjs'), 'utf8')
  assert.match(logsSrc, /rotateOnly \?\? \['writes\.jsonl', 'net\.jsonl', 'tool\.jsonl', 'perception\.jsonl'\]/, 'logs.mjs 默认名单')
  const dbSrc = readFileSync(join(PROJECT_ROOT, 'packages', 'core', 'src', 'db.mjs'), 'utf8')
  assert.match(dbSrc, /rotateOnly: \['writes\.jsonl', 'net\.jsonl', 'tool\.jsonl', 'perception\.jsonl'\]/, 'db.mjs 默认配置')
  const cfg = JSON.parse(readFileSync(join(PROJECT_ROOT, 'data', 'lifecycle-config.json'), 'utf8'))
  for (const f of ['writes.jsonl', 'net.jsonl', 'tool.jsonl', 'perception.jsonl']) {
    assert.ok(cfg.logs.rotateOnly.includes(f), `运行时 config 缺 ${f}（worker loadConfig 优先读它）`)
  }
})

// ---------------------------------------------------------------------------
// D4：verifyClaimIntegrity —— published 但证据被剥离 → ok:false 且列出
// ---------------------------------------------------------------------------

test('D4 published 且证据为空 → verifyClaimIntegrity ok:false 并列出该 claim；导出对象携带 integrity', async () => {
  mkdirSync(join(PROJECT_ROOT, 'data', 'db'), { recursive: true })
  const { mkdtempSync: mk } = await import('node:fs')
  const { tmpdir } = await import('node:os')
  // 夹具必须在项目根内（safefs 根断言）
  const dir = mk(join(PROJECT_ROOT, 'data', 'db', 'audit-integrity-'))
  try {
    const store = await createStore({ driver: 'sqlite', dbPath: join(dir, 'orb.sqlite'), dataDir: dir })
    store.initMigrations()
    // 对照组：有证据的 published claim
    createClaim(store, { id: 'clm-ok', kind: 'observation', text: '有证据的结论', evidenceMode: 'direct' })
    attachEvidence(store, { claimId: 'clm-ok', evidenceId: 'ev-src-1', layer: 'observation', relation: 'direct', sha256: sha64('e1') })
    assert.equal(publishClaim(store, 'clm-ok').ok, true)
    // 破损组：published 但证据随后被剥离（模拟删证据未联动 / 历史脏数据）
    createClaim(store, { id: 'clm-broken', kind: 'observation', text: '证据将被剥离的结论', evidenceMode: 'direct' })
    attachEvidence(store, { claimId: 'clm-broken', evidenceId: 'ev-src-2', layer: 'observation', relation: 'direct', sha256: sha64('e2') })
    assert.equal(publishClaim(store, 'clm-broken').ok, true)
    const db = store._db // sqlite driver 类实例持有 DatabaseSync（jsonl → undefined）
    assert.ok(db, '需要 sqlite driver 的 _db 访问（D4 场景）')
    db.prepare('DELETE FROM claim_evidence WHERE claim_id = ?').run('clm-broken')

    const rep = verifyClaimIntegrity(store)
    assert.equal(rep.ok, false)
    assert.ok(Array.isArray(rep.broken) && rep.broken.some((b) => b.id === 'clm-broken'), '必须列出破损 claim')
    assert.ok(!rep.broken.some((b) => b.id === 'clm-ok'), '对照组不得误报')

    // 接线证据：buildClaimExport（导出路径）携带 integrity 复查结果（只读，不阻断导出本身）
    const built = buildClaimExport(store, 'clm-broken', { version: 's67/test', now: Date.now() })
    assert.equal(built.ok, true, '导出不阻断（告警交给人决策）')
    assert.equal(built.integrity.ok, false)
    assert.ok(built.integrity.broken.some((b) => b.id === 'clm-broken'))

    // 详情展示路径：claimEvidenceReport 出「证据缺失」告警
    const detail = claimEvidenceReport(store, 'clm-broken', Date.now())
    assert.equal(detail.integrityWarning, '证据缺失')
    const okDetail = claimEvidenceReport(store, 'clm-ok', Date.now())
    assert.equal(okDetail.integrityWarning, undefined)

    store.close()
  } finally {
    try { rmSync(dir, { recursive: true, force: true }) } catch { /* shim 偶发；夹具在 data/db 内后清 */ }
  }
})
