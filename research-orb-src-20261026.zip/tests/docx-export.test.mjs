// tests/docx-export.test.mjs
//
// 块 4 首批 skill 的导出回归：docx 真跑（两条独立验证）/ LaTeX 成对 / 图片占位卡。
//
// docx 独立验证（任务书要求"两条都做更佳"，这里全做）：
//   (a) zip 解包：docx 是 zip——用 jszip（docx 的既有传递依赖，零新增）读
//       word/document.xml 存在且非空且含标题文本；
//   (b) python-docx 读回标题：用受管 venv（.workbuddy\binaries\python\envs\b4-verify，
//       非全局；python-docx MIT）真实解析文档结构。venv 不可用时此条跳过并显式记录，
//       绝不静默算过。
//
// node_modules 纪律钉：全树 install/preinstall/postinstall 脚本必须为 0
// （--ignore-scripts 是安装时的保险，这条钉保证它在仓库里长期成立）。

import test from 'node:test'
import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, readFileSync, readdirSync, statSync, unlinkSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

import { buildDocx } from '../packages/plugins/research-literature/lib/docx-export.mjs'
import { buildLatexDraft, buildLatexPair, texEscape } from '../packages/plugins/research-literature/lib/latex-export.mjs'
import { buildBibtex, selfCheckBibtex } from '../packages/plugins/research-literature/lib/bib.mjs'
import { createEngine } from '../packages/plugins/research-literature/index.mjs'
import { PROJECT_ROOT, dataPath } from '../packages/core/src/safefs.mjs'
import { makeFakeCtx, makeMemoryScopes } from './helpers/research-fixtures.mjs'
import { runPython } from '../tools/lib/run-python.mjs'

const CARD = {
  title: 'Grid-Forming Control 读书卡',
  authors: ['王伟', 'Jane Doe'],
  venue: 'IEEE Transactions on Power Systems',
  year: 2024,
  doi: '10.1109/test.1',
  url: '',
  pdf: null,
  tags: ['template/方法', 'project/gfm'],
  问题: '构网型逆变器如何支撑低惯量电网？',
  方法: '虚拟同步机 + 频率整形控制。',
  数据与算例: 'IEEE 9-bus 改进算例。',
  结论与局限: '频率最低点改善 32 percent；只测了小系统。',
  可复用点: '控制参数整定流程。',
  待验证点: '大扰动下的表现。',
  与我课题的关系: '直接相关。',
  '读数（0-5）': 4,
}
const CONTENT = [
  '# Grid-Forming Control 读书卡',
  '',
  '> 王伟, Jane Doe · IEEE Transactions on Power Systems · 2024',
  '',
  '## 我的批注',
  '',
  '批注：这篇的方法节值得精读，参数表在第 4 节。',
  '',
].join('\n')
const ENTRY = { rel: 'gfm/demo-card.md', slug: 'demo-card', title: CARD.title, card: CARD, content: CONTENT }
// 受管 venv 必须在项目内（硬边界）：指向 research-orb/.venv，而非用户目录。
const PYTHON_VENV = join(PROJECT_ROOT, '.venv')

test('docx: buildDocx 产出合法 zip；word/document.xml 存在且非空且含标题（独立验证 a：解包）', async () => {
  const { buffer, paragraphCount } = await buildDocx('gfm', [ENTRY])
  assert.ok(buffer.length > 1000, `docx 应有实质内容（${buffer.length} 字节）`)
  // zip 解包（jszip 是 docx 的既有传递依赖，不新增依赖）
  const JSZip = (await import('jszip')).default
  const zip = await JSZip.loadAsync(buffer)
  const names = Object.keys(zip.files)
  assert.ok(names.includes('word/document.xml'), `docx 必须含 word/document.xml（实际：${names.slice(0, 6).join(', ')}…）`)
  const xml = await zip.file('word/document.xml').async('string')
  assert.ok(xml.length > 500, `document.xml 非空（${xml.length} 字符）`)
  assert.ok(xml.includes('Grid-Forming Control 读书卡'), 'document.xml 必须含卡标题')
  assert.ok(xml.includes('构网型逆变器如何支撑低惯量电网？'), 'document.xml 必须含正文/元信息')
  assert.ok(paragraphCount > 5)
})

test('docx: python-docx 读回标题与段落（独立验证 b：受管 venv，非全局；不可用则显式跳过）', async (t) => {
  const python = join(PYTHON_VENV, 'Scripts', 'python.exe')
  if (!existsSync(python)) {
    // 冷跑复现：先 `node tools/setup-venv.mjs` 再跑测试。绝不静默算过。
    t.skip('项目内 .venv 缺失——运行 `node tools/setup-venv.mjs` 重建后再跑（解包验证 a 已独立覆盖）')
    return
  }
  const { buffer } = await buildDocx('gfm', [ENTRY])
  // 写到临时文件给 python 读（tmp 是我们的工作台，验证完即删）
  const tmpDoc = dataPath('exports', '.verify-docx.tmp')
  mkdirSync(dataPath('exports'), { recursive: true })
  writeFileSync(tmpDoc, buffer)
  try {
    const script = [
      'import docx, json, sys',
      "d = docx.Document(sys.argv[1])",
      'heads = [p.text for p in d.paragraphs if p.style.name.startswith("Heading")]',
      'tables = len(d.tables)',
      'print(json.dumps({"heads": heads, "tables": tables}, ensure_ascii=False))',
    ].join('\n')
    const r = runPython(python, script, [tmpDoc])
    assert.equal(r.status, 0, `python-docx 读取失败：${r.stderr}`)
    const parsed = JSON.parse(r.stdout)
    assert.ok(parsed.heads.includes(CARD.title), `读回的标题应含卡标题（实际：${parsed.heads.slice(0, 5).join(' | ')}）`)
    assert.ok(parsed.heads.some((h) => h.includes('我的批注')), '批注节标题应存在')
    assert.equal(parsed.tables, 1, 'front-matter 元信息表应存在')
  } finally {
    try { unlinkSync(tmpDoc) } catch { /* 已删 */ }
  }
})

test('docx: node_modules 全树 install 脚本 0（依赖评审结论的长期钉）', () => {
  const nm = join(PROJECT_ROOT, 'node_modules')
  const bad = []
  const walk = (dir) => {
    for (const name of readdirSync(dir)) {
      if (name === '.bin' || name === '.package-lock.json') continue
      const p = join(dir, name)
      let st = null
      try { st = statSync(p) } catch { continue }
      if (!st.isDirectory()) continue
      const pj = join(p, 'package.json')
      if (existsSync(pj)) {
        try {
          const m = JSON.parse(readFileSync(pj, 'utf8'))
          for (const k of ['install', 'preinstall', 'postinstall']) {
            if (m.scripts && m.scripts[k]) bad.push(`${m.name} -> ${k}`)
          }
        } catch { /* 坏 json 跳过 */ }
      }
      walk(p)
    }
  }
  walk(nm)
  assert.deepEqual(bad, [], `node_modules 不得含任何 install 脚本（--ignore-scripts 纪律）：${bad.join(', ')}`)
  // package.json 版本精确锁定（无 ^ 前缀）
  const pkg = JSON.parse(readFileSync(join(PROJECT_ROOT, 'package.json'), 'utf8'))
  assert.equal(pkg.dependencies.docx, '9.11.0', 'docx 必须精确锁定 9.11.0')
})

test('latex: .tex/.bib 成对导出，.bib 过 citation-js 自检；texEscape 转义最小集', async () => {
  const { tex, bib, bibEntries } = buildLatexPair('gfm', [ENTRY])
  assert.match(tex, /\\section\{Grid-Forming Control 读书卡\}/)
  assert.match(tex, /\\subsection\{我的批注\}/)
  assert.match(tex, /\\begin\{document\}/)
  assert.match(tex, /DOI: \\href/, '元信息行含 DOI 链接')
  // 转义：& % _ 等特殊字符
  assert.equal(texEscape('a_b&c%d'), 'a\\_b\\&c\\%d')
  // bib 走同一 buildBibtex 路径 + citation-js 自检（期望 DOI 一致）
  const check = await selfCheckBibtex(bib, { expectDois: ['10.1109/test.1'] })
  assert.equal(check.ok, true, `自检失败：${check.error}`)
  assert.equal(bibEntries, 1)
})

test('note image: 占位卡（source/image + ocr-pending 标签，图片留原路径）', async () => {
  const { scopes, engine } = engineWith()
  const imgPath = dataPath('fixtures', 'sample-paper.pdf') // 存在的任意文件路径即可（占位卡不读内容）
  const r = await engine.note(`image ${imgPath} --topic gfm --note 频率响应曲线截图`)
  assert.equal(r.ok, true, r.text)
  const rel = r.ui.rel
  const md = scopes.notes.read(rel)
  assert.match(md, /source\/image/)
  assert.match(md, /ocr-pending/)
  assert.match(md, /## 图片/)
  assert.match(md, /待 OCR/)
  assert.match(md, /频率响应曲线截图/)
  // 不存在的图片路径
  const miss = await engine.note('image 一定不存在的图.png')
  assert.equal(miss.ok, false)
  assert.equal(miss.code, 'E_NOT_FOUND')
  // 缺参数
  assert.equal((await engine.note('image ')).code, 'E_BAD_ARGS')
})

function engineWith() {
  const scopes = makeMemoryScopes()
  const ctx = makeFakeCtx({ scopes, llm: null })
  const engine = createEngine(ctx, { scopes, secretsLoader: () => ({}) })
  return { scopes, ctx, engine }
}

