// tests/wake.test.mjs —— 唤醒词匹配回归（S74·3-B）
// 判据来自两份实盘经验：变体多拼写 + 包含匹配 + 核心词兜底 + 复读过滤 + 人声闸门 + 禁模糊匹配
import test from 'node:test'
import assert from 'node:assert/strict'
import {
  WAKE_PARAMS, WAKE_VARIANTS, normalizeText, expandVariants, coreOf,
  isRepetitionHallucination, passEnergyGate, matchWake, stripWakeWord,
} from '../packages/core/src/wake.mjs'

test('W-1 标准唤醒词命中（含语气尾）', () => {
  for (const s of ['问源', '问源啊', '问源在吗', '问源，在不在']) {
    const r = matchWake(s)
    assert.equal(r.hit, true, `${s} 应命中`)
    assert.ok(['variant', 'core'].includes(r.source))
  }
})

test('W-2 近音误识别也能命中（同音字/繁简）', () => {
  for (const s of ['问元', '文源', '问缘', '問源', '问远', '小源', '小球']) {
    assert.equal(matchWake(s).hit, true, `${s} 应命中（近音/繁简）`)
  }
})

test('W-3 变体长优先（长变体不被短词抢先）', () => {
  const r = matchWake('问源在吗今天看什么')
  assert.equal(r.hit, true)
  assert.equal(r.source, 'variant')
  assert.ok(r.word.length >= 2)
  // 长变体命中后 rest 不应残留"在吗"
  assert.ok(!String(r.rest).startsWith('在吗'), 'rest 不应以"在吗"开头')
})

test('W-4 否定例：不含唤醒词不命中', () => {
  for (const s of ['今天天气不错', '帮我看看这篇论文', '现在几点了', '']) {
    assert.equal(matchWake(s).hit, false, `${JSON.stringify(s)} 不应命中`)
  }
})

test('W-5 复读幻觉被过滤（tiny 常见）', () => {
  assert.equal(isRepetitionHallucination('千千千千'), true)
  assert.equal(isRepetitionHallucination('哈哈哈哈哈'), true)
  assert.equal(isRepetitionHallucination('问源在吗'), false)
  assert.equal(matchWake('千千千千').hit, false)
})

test('W-6 人声量闸门：说话过短不出结果', () => {
  assert.equal(passEnergyGate({ spokenMs: 200, rms: 0.05 }).ok, false)
  assert.equal(passEnergyGate({ spokenMs: 800, rms: 0.05 }).ok, true)
  assert.equal(passEnergyGate({ spokenMs: 800, rms: 0.001 }).ok, false)
})

test('W-7 归一化：去标点/空白/语气尾/小写', () => {
  assert.equal(normalizeText(' 问源，在吗！ '), '问源在吗'.replace(/在吗$/, ''))
  assert.equal(normalizeText('問源'), '问源')
})

test('W-8 近音展开：含变体且去重、限额', () => {
  const v = expandVariants(['问源'])
  assert.ok(v.length >= 5, '至少展开出 5 个变体')
  assert.equal(new Set(v).size, v.length, '去重')
  assert.ok(v.length <= 40, '限额 40')
  assert.ok(v.includes('问源'))
  assert.ok(v.includes('问元') || v.includes('文源'), '含近音变体')
})

test('W-9 核心词：剥掉疑问尾', () => {
  assert.equal(coreOf('问源在吗'), '问源')
  assert.equal(coreOf('小球出来'), '小球')
})

test('W-10 stripWakeWord：剪掉唤醒词剩指令（为后续预留）', () => {
  const m = matchWake('问源帮我找综述')
  assert.equal(m.hit, true)
  const rest = stripWakeWord('问源帮我找综述', m)
  assert.ok(rest.includes('帮我找综述'), 'rest 应保留指令：' + rest)
  assert.ok(!rest.startsWith('问源'))
})

test('W-11 参数符合实盘值（防被随手改坏）', () => {
  assert.equal(WAKE_PARAMS.tickMs, 120)
  assert.equal(WAKE_PARAMS.preRollMs, 1500)
  assert.equal(WAKE_PARAMS.cooldownMs, 700)
  assert.equal(WAKE_PARAMS.minSpokenMs, 400)
  assert.ok(WAKE_PARAMS.rmsCap <= 0.06, '门限必须有上限')
  assert.ok(WAKE_PARAMS.probeBudgetPerMin <= 12)
})

test('W-12 禁止模糊匹配（形近字不应命中）', () => {
  // 编辑距离 1 但非近音的字：不该命中（否则误触爆炸）
  assert.equal(matchWake('问题').hit, false)
  assert.equal(matchWake('原因').hit, false)
})

test('W-13 变体表非空且含专名', () => {
  assert.ok(WAKE_VARIANTS.length >= 8)
  assert.ok(WAKE_VARIANTS.some((v) => v.includes('问源')))
})