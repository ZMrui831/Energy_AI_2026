// tests/s10-features.test.mjs —— S10 单元层：DOI 档位判定（同一 connectors 源）+ 结论导出组装。
import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { createHash } from 'node:crypto'

import { PROJECT_ROOT, dataPath } from '../packages/core/src/safefs.mjs'
import { createStore } from '../packages/core/src/db.mjs'
import { doiTrustFor, doiTrustForCandidates, normalizeDoi, DOI_TRUST_LABELS } from '../packages/plugins/research-literature/lib/doi-trust.mjs'
import { buildClaimExport, evidenceModeLabel, createClaim, attachEvidence, publishClaim } from '../packages/core/src/lifecycle/publish.mjs'

/** 桩 net：按 host 决定两个 DOI 抓取器的成败（openalex 先问、crossref 后问）。
 *  口径与 lib/http.mjs 一致：net.request(url, {limitKey, headers}) → {ok,status,text()}。 */
function stubNet({ openalexOk = true, crossrefOk = true, log = [] } = {}) {
  return {
    async request(url) {
      const host = new URL(url).host
      log.push(url)
      if (host === 'api.openalex.org') {
        if (!openalexOk) return { ok: false, status: 404, text: async () => 'not found' }
        return { ok: true, status: 200, text: async () => JSON.stringify({ id: 'https://openalex.org/W1', doi: '10.1/x', title: 'T', display_name: 'T', publication_year: 2024, authorships: [], cited_by_count: 1, primary_location: null }) }
      }
      if (host === 'api.crossref.org') {
        if (!crossrefOk) return { ok: false, status: 404, text: async () => 'not found' }
        return { ok: true, status: 200, text: async () => JSON.stringify({ message: { DOI: '10.1/x', title: ['T'], issued: { 'date-parts': [[2024]] }, author: [], 'is-referenced-by-count': 1 } }) }
      }
      return { ok: true, status: 200, text: async () => '{}' }
    },
  }
}

test('S10 DOI 档位：双源 / 仅单源 / 未收录 / 无 DOI（判定源=connectors 抓取器）', async () => {
  const dual = await doiTrustFor('10.1/x', { net: stubNet({ openalexOk: true, crossrefOk: true }) })
  assert.equal(dual.status, 'dual')
  assert.equal(dual.label, DOI_TRUST_LABELS.dual)
  assert.equal(dual.sources.filter((s) => s.ok).length, 2)

  const single = await doiTrustFor('10.1/x', { net: stubNet({ openalexOk: true, crossrefOk: false }) })
  assert.equal(single.status, 'single')
  assert.equal(single.label, DOI_TRUST_LABELS.single)

  const none = await doiTrustFor('10.1/x', { net: stubNet({ openalexOk: false, crossrefOk: false }) })
  assert.equal(none.status, 'none')
  assert.equal(none.label, DOI_TRUST_LABELS.none)

  const noDoi = await doiTrustFor('', { net: stubNet({}) })
  assert.equal(noDoi.status, 'no-doi')
  assert.equal(noDoi.label, DOI_TRUST_LABELS['no-doi'])

  assert.equal(normalizeDoi('https://doi.org/10.1/X'), '10.1/x')
  assert.equal(normalizeDoi('  '), null)
})

test('S10 DOI 档位：批量带缓存（同 DOI 不问两遍网络）+ limit 上限如实标 unverifiable', async () => {
  const log = []
  const recs = [{ doi: '10.1/x' }, { doi: '10.1/x' }, { doi: '10.2/y' }, { doi: '10.3/z' }]
  const map = await doiTrustForCandidates(recs, { net: stubNet({ log }), limit: 2 })
  assert.equal(map.get(recs[0]).status, 'dual')
  assert.equal(map.get(recs[1]).status, 'dual')
  assert.equal(log.filter((u) => u.includes('10.1/x')).length, 2, '同 DOI 只问一遍（缓存生效）')
  assert.equal(map.get(recs[2]).status, 'dual')
  assert.equal(map.get(recs[3]).status, 'unverifiable', '超 limit 的条目不伪装已校验')
})

test('S10 导出组装：已发布结论 → md 含 evidence_id/可用性/档位/时间/版本', async () => {
  mkdirSync(dataPath('db'), { recursive: true })
  const dir = mkdtempSync(dataPath('db', 's10-export-'))
  try {
    const store = await createStore({ driver: 'sqlite', dbPath: join(dir, 'orb.sqlite'), dataDir: dir })
    store.initMigrations()
    const shotA = join(dir, 'a.png')
    writeFileSync(shotA, 'PNG-A')
    const shaA = createHash('sha256').update('PNG-A').digest('hex')
    store.insertRawFrame({ id: 'rf-a', file_path: shotA, sha256: shaA, sensitivity: 'normal', created_at: new Date().toISOString(), expires_at: new Date(Date.now() + 3600_000).toISOString() })
    store.insertRawFrame({ id: 'rf-b', file_path: join(dir, 'gone.png'), sha256: 'f'.repeat(64), sensitivity: 'normal', created_at: new Date().toISOString(), expires_at: new Date().toISOString() })
    store.setRawFrameStatus('rf-b', 'deleted')

    createClaim(store, { id: 'clm-x', kind: 'observation', text: 'S10 导出验收结论', evidenceMode: 'direct' })
    attachEvidence(store, { claimId: 'clm-x', evidenceId: 'rf-a', layer: 'raw_frame', relation: 'direct', sha256: shaA })
    attachEvidence(store, { claimId: 'clm-x', evidenceId: 'rf-b', layer: 'raw_frame', relation: 'direct', sha256: 'f'.repeat(64) })
    const pub = publishClaim(store, 'clm-x')
    assert.equal(pub.ok, true)

    const built = buildClaimExport(store, 'clm-x', { version: 's10/test', now: Date.now() })
    assert.equal(built.ok, true)
    assert.equal(built.label, evidenceModeLabel('direct'))
    assert.match(built.markdown, /rf-a/)
    assert.match(built.markdown, /rf-b/)
    assert.match(built.markdown, /\| 可用 \|/)
    assert.match(built.markdown, /\| 已删 \|/)
    assert.match(built.markdown, /原图已按保留策略删除；保留时间、窗口、摘要与内容哈希，无法恢复画面。/)
    assert.match(built.markdown, /导出时间：/)
    assert.match(built.markdown, /产品版本：research-orb s10\/test/)
    assert.equal(built.evidence.length, 2)
    assert.equal(built.degraded, 1)

    // 未发布结论不得导出
    createClaim(store, { id: 'clm-draft', kind: 'manual', text: '草稿', evidenceMode: 'none' })
    const bad = buildClaimExport(store, 'clm-draft', { version: 's10/test' })
    assert.equal(bad.ok, false)
    assert.equal(bad.code, 'E_NOT_PUBLISHED')
    store.close()
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})
