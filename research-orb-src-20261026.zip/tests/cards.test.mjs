// tests/cards.test.mjs
//
// 卡片笔记（交付 3）：字段表严格性、schema 校验后不写盘、渲染/解析往返、slug 幂等。

import test from 'node:test'
import assert from 'node:assert/strict'

import {
  BIBLIO_FIELDS,
  CARD_FIELDS,
  INTERPRETIVE_FIELDS,
  PLACEHOLDER,
  READING_FIELD,
  READING_MAX,
  buildBody,
  cardFromRecord,
  decideSlug,
  emptyCard,
  getReading,
  listAllCards,
  listCards,
  mergeDraft,
  normalizeStoredCard,
  parseCard,
  readCard,
  renderCard,
  validateCard,
  writeCard,
} from '../packages/plugins/research-literature/lib/cards.mjs'
import { makeMemoryScope } from './helpers/research-fixtures.mjs'

const GOOD = {
  title: 'Grid-Forming Inverter Control for Inertia Support',
  authors: ['Wei Wang', 'Maria Rossi'],
  venue: 'IEEE Transactions on Power Systems',
  year: 2024,
  doi: '10.1109/TPWRS.2024.1000000',
  url: 'https://doi.org/10.1109/TPWRS.2024.1000000',
  pdf: 'data/pdf/abcdef0123456789.json',
  tags: ['grid-forming inverter', 'TPWRS'],
  问题: '低惯量系统中频率稳定性变差。',
  方法: '提出虚拟惯量控制器并做小信号分析。',
  数据与算例: '改进 IEEE 9 节点系统仿真。',
  结论与局限: '惯量支撑改善暂态频率响应；未考虑通信时延。',
  可复用点: '一阶频率环结构可直接迁移。',
  待验证点: '弱电网下的稳定性边界待验证。',
  与我课题的关系: '可作为本课题的基线对照组。',
  [READING_FIELD]: 3,
}

const RECORD = {
  title: 'Virtual Synchronous Generator Based Inertia Emulation',
  authors: ['Hao Chen', 'Li Zhang'],
  venue: 'IEEE Transactions on Smart Grid',
  year: 2023,
  doi: '10.1109/TSG.2023.9999999',
  url: 'https://doi.org/10.1109/TSG.2023.9999999',
  abstract: 'The low-inertia problem is a major challenge for converter-dominated grids. This paper proposes a virtual synchronous generator controller with adaptive inertia. Simulation on a modified IEEE 9-bus test system validates the proposed scheme.',
  citations: 42,
  source: 'openalex',
  sources: ['openalex', 'crossref'],
  venueTier: 'top',
  venueKey: 'TSG',
}

// ---------------------------------------------------------------------------
// 字段表
// ---------------------------------------------------------------------------

test('cards: front-matter 字段表与 DOMAIN 第 4 节逐字一致（含全角括号读数）', () => {
  assert.deepEqual(
    [...CARD_FIELDS],
    [
      'title', 'authors', 'venue', 'year', 'doi', 'url', 'pdf', 'tags',
      '问题', '方法', '数据与算例', '结论与局限', '可复用点', '待验证点', '与我课题的关系', '读数（0-5）',
    ],
  )
  assert.equal(CARD_FIELDS.length, 16)
  assert.equal(READING_FIELD, '读数（0-5）')
  assert.equal(new Set(CARD_FIELDS).size, 16, '字段不得重复')
  assert.deepEqual([...BIBLIO_FIELDS], ['title', 'authors', 'venue', 'year', 'doi', 'url'])
  assert.equal(INTERPRETIVE_FIELDS.length, 7)
  for (const f of INTERPRETIVE_FIELDS) assert.ok(CARD_FIELDS.includes(f))
})

// ---------------------------------------------------------------------------
// 校验
// ---------------------------------------------------------------------------

test('cards: validateCard 接受合法卡片，键顺序固定为字段表顺序', () => {
  const r = validateCard(GOOD)
  assert.equal(r.ok, true, r.errors.join('; '))
  assert.deepEqual(Object.keys(r.card), [...CARD_FIELDS], '键顺序必须与字段表一致')
  assert.equal(r.card.doi, '10.1109/tpwrs.2024.1000000', 'DOI 归一为小写')
  assert.equal(r.card[READING_FIELD], 3)
})

test('cards: 读数越界/缺失/非整数一律判错且不给卡片', () => {
  for (const bad of [6, -1, 2.5, 'many', undefined, null, '']) {
    const r = validateCard({ ...GOOD, [READING_FIELD]: bad })
    assert.equal(r.ok, false, `读数=${JSON.stringify(bad)} 应判错`)
    assert.equal(r.card, null)
    assert.ok(r.errors.some((e) => e.includes(READING_FIELD)), r.errors.join('; '))
  }
  // 字符串数字可以接受（gray-matter 读回来是 number，但手写 front-matter 常写成字符串）
  assert.equal(validateCard({ ...GOOD, [READING_FIELD]: '4' }).ok, true)
  // 简写键名也认
  const alias = validateCard({ ...GOOD, [READING_FIELD]: undefined, 读数: 5 })
  assert.equal(alias.ok, true)
  assert.equal(alias.card[READING_FIELD], 5)
})

test('cards: 缺 title / year 非法判错；多余键被丢弃而不是报错', () => {
  assert.equal(validateCard({ ...GOOD, title: '  ' }).ok, false)
  assert.equal(validateCard({ ...GOOD, year: 'abc' }).ok, false)
  assert.equal(validateCard({ ...GOOD, year: 1200 }).ok, false)
  assert.equal(validateCard({ ...GOOD, year: '' }).ok, true)
  assert.equal(validateCard({ ...GOOD, year: '' }).card.year, null)
  const extra = validateCard({ ...GOOD, summary: 'LLM 多写了一个键', extraField: 1 })
  assert.equal(extra.ok, true)
  assert.ok(!('summary' in extra.card))
  assert.equal(Object.keys(extra.card).length, 16)
  assert.equal(validateCard(null).ok, false)
  assert.equal(validateCard([]).ok, false)
  assert.equal(validateCard('x').ok, false)
})

test('cards: emptyCard 与 normalizeStoredCard 行为', () => {
  const e = emptyCard()
  assert.deepEqual(Object.keys(e), [...CARD_FIELDS])
  assert.equal(e.year, null)
  assert.deepEqual(e.tags, [])
  assert.equal(getReading(e), 0)
  const stored = normalizeStoredCard({ ...GOOD, [READING_FIELD]: 2 })
  assert.equal(stored.ok, true)
  assert.equal(getReading(stored.card), 2)
})

test('cards: 空的可选字段归一为 null 而不是空串', () => {
  const r = validateCard({ ...GOOD, doi: '', url: '', pdf: '', year: '' })
  assert.equal(r.card.doi, null)
  assert.equal(r.card.url, '')
  assert.equal(r.card.pdf, null)
  assert.equal(r.card.year, null)
})

// ---------------------------------------------------------------------------
// 启发式草案
// ---------------------------------------------------------------------------

test('cards: cardFromRecord 生成确定性草案，字段齐全且可复现', () => {
  const a = cardFromRecord(RECORD, { topic: 'gfm' })
  const b = cardFromRecord(RECORD, { topic: 'gfm' })
  assert.equal(a.ok, true, a.errors.join('; '))
  assert.deepEqual(a.card, b.card, '同一输入必须产出同一张卡（无时间戳/随机）')
  assert.equal(a.card.title, RECORD.title)
  assert.deepEqual(a.card.authors, RECORD.authors)
  assert.equal(a.card.year, 2023)
  assert.equal(a.card[READING_FIELD], 0, '读数默认 0（未读），不能由启发式编出来')
  assert.ok(a.card['问题'].length > 10)
  assert.ok(a.card['方法'].length > 10)
  assert.ok(a.card['数据与算例'].includes('IEEE 9-bus'))
  assert.ok(a.card['结论与局限'].length > 10)
  assert.ok(a.card.tags.includes('virtual synchronous generator'), `tags=${JSON.stringify(a.card.tags)}`)
  assert.ok(a.card.tags.includes('TSG'), '优选期刊应打上 venueKey 标签')
  assert.ok(a.card.tags.some((t) => t.startsWith('source:')), '应标注来源')
  assert.ok(!a.card.tags.some((t) => /^\d{4}$/.test(t)), '年份不该混进 tags')
})

test('cards: 空记录时解释性字段退化为显式占位符（不编内容）', () => {
  const r = cardFromRecord({ title: 'Untitled', authors: [], venue: '', year: null, doi: null, url: '', abstract: '' }, { topic: 'inbox' })
  assert.equal(r.ok, true)
  assert.equal(r.card['问题'], PLACEHOLDER)
  assert.equal(r.card['方法'], PLACEHOLDER)
  assert.equal(r.card['数据与算例'], PLACEHOLDER)
  assert.ok(r.card['待验证点'].includes('未抽到'))
  assert.match(r.card['与我课题的关系'], /需人工判断/)
})

test('cards: PDF 抽取结果参与草案（方法/结果取对应章节）', () => {
  const extraction = {
    sections: {
      abstract: { text: 'The low-inertia problem is addressed by a virtual inertia controller in this work.' },
      method: { text: 'The proposed controller emulates synchronous inertia via a first-order frequency loop.' },
      results: { text: 'Simulation on a modified IEEE 9-bus test system validates the scheme.' },
      conclusion: { text: 'Inertia support improves transient frequency response. Future work considers delays.' },
    },
    text: 'x'.repeat(100),
  }
  const r = cardFromRecord({ title: 'T', authors: [], venue: '', year: 2024, doi: null, url: '', abstract: '' }, { topic: 'gfm', pdfRel: 'data/pdf/aaa.json', extraction })
  assert.equal(r.ok, true)
  assert.match(r.card['方法'], /first-order frequency loop/)
  assert.match(r.card['数据与算例'], /IEEE 9-bus/)
  assert.match(r.card['结论与局限'], /transient frequency response/)
  assert.equal(r.card.pdf, 'data/pdf/aaa.json')
})

test('cards: mergeDraft 只采纳 LLM 的解释性字段，书目字段永不采纳 LLM 版本', () => {
  const llm = {
    问题: 'LLM 说的问题',
    方法: 'LLM 说的方法',
    title: 'LLM 编的标题',
    doi: '10.9999/fake',
    year: 1999,
  }
  const m = mergeDraft(RECORD, llm, { topic: 'gfm' })
  assert.equal(m.ok, true)
  assert.equal(m.card['问题'], 'LLM 说的问题')
  assert.equal(m.card['方法'], 'LLM 说的方法')
  assert.equal(m.card.title, RECORD.title, '标题必须来自元数据')
  assert.equal(m.card.doi, RECORD.doi.toLowerCase().toLowerCase(), 'DOI 必须来自元数据')
  assert.equal(m.card.year, 2023, '年份必须来自元数据')
  assert.deepEqual(m.fieldsFromLlm, ['问题', '方法'])
  // LLM 给的读数同样不被采纳
  const m2 = mergeDraft(RECORD, { ...llm, [READING_FIELD]: 5 }, { topic: 'gfm' })
  assert.equal(m2.card[READING_FIELD], 0)
})

// ---------------------------------------------------------------------------
// 渲染 / 解析
// ---------------------------------------------------------------------------

test('cards: 渲染-解析往返无损（含中文键名、数组、null）', () => {
  const r = validateCard(GOOD)
  const md = renderCard(r.card)
  assert.ok(md.startsWith('---\n'))
  assert.ok(md.includes('读数（0-5）: 3'), '中文键名的 front-matter 必须能正确写出')
  const back = parseCard(md)
  assert.equal(back.data.title, GOOD.title)
  assert.deepEqual(back.data.authors, GOOD.authors)
  assert.deepEqual(back.data.tags, GOOD.tags)
  assert.equal(back.data.doi, GOOD.doi.toLowerCase())
  assert.equal(back.data.pdf, GOOD.pdf)
  assert.equal(back.data[READING_FIELD], 3)
  for (const f of INTERPRETIVE_FIELDS) assert.equal(back.data[f], GOOD[f], f)
  assert.equal(Object.keys(back.data).length, 16)
  // 正文里 7 个解释性小节 + 批注区都在
  for (const f of INTERPRETIVE_FIELDS) assert.ok(back.content.includes(`## ${f}`), f)
  assert.ok(back.content.includes('## 我的批注'))
  assert.ok(back.content.includes('## 标签'))
})

test('cards: body 里保留 DOI 与抽取文本路径，便于人工回溯', () => {
  const md = renderCard(validateCard(GOOD).card)
  assert.ok(md.includes('https://doi.org/10.1109/TPWRS.2024.1000000'))
  assert.ok(md.includes('data/pdf/abcdef0123456789.json'))
  const body = buildBody(validateCard({ ...GOOD, doi: null }).card)
  assert.ok(body.includes('未关联本地 PDF') === false)
})

// ---------------------------------------------------------------------------
// slug / 落盘
// ---------------------------------------------------------------------------

test('cards: decideSlug 同 DOI 幂等、异 DOI 不覆盖、无标识时视为同一篇', () => {
  assert.equal(decideSlug([], 'grid-forming', { doi: '10.1/a' }), 'grid-forming')
  const existing = [{ name: 'grid-forming', doi: '10.1/a', identity: 'doi:10.1/a' }]
  assert.equal(decideSlug(existing, 'grid-forming', { doi: '10.1/a' }), 'grid-forming', '同一篇必须落同一文件')
  assert.equal(decideSlug(existing, 'grid-forming', { doi: '10.1/b' }), 'grid-forming-2', '不同文献不得覆盖')
  const withSecond = [...existing, { name: 'grid-forming-2', doi: '10.1/b', identity: 'doi:10.1/b' }]
  assert.equal(decideSlug(withSecond, 'grid-forming', { doi: '10.1/c' }), 'grid-forming-3')
  assert.equal(decideSlug([], 'x', { title: 'Y', url: '' }), 'x')
})

test('cards: writeCard 写 .md + meta 侧车，重复写同一篇只覆盖不新增', () => {
  const notes = makeMemoryScope('notes')
  const card = validateCard(GOOD).card
  const w1 = writeCard({ notes, topic: 'gfm', card, meta: { generatedBy: 'heuristic' } })
  assert.equal(w1.rel.startsWith('gfm/'), true)
  assert.ok(notes.exists(w1.rel))
  assert.ok(notes.exists(w1.metaRel), '必须有 meta 侧车')
  assert.equal(w1.overwritten, false)
  const meta = notes.readJson(w1.metaRel)
  assert.equal(meta.generatedBy, 'heuristic')
  assert.ok(meta.writtenAt)

  const w2 = writeCard({ notes, topic: 'gfm', card, meta: { generatedBy: 'llm' } })
  assert.equal(w2.rel, w1.rel, '同 DOI 必须覆盖同一文件')
  assert.equal(w2.overwritten, true)
  assert.equal(notes.list('gfm').filter((n) => n.endsWith('.md')).length, 1)
  assert.equal(notes.readJson(w2.metaRel).generatedBy, 'llm')
})

test('cards: schema 不符时 writeCard 抛错且**一个字节都不写**', () => {
  const notes = makeMemoryScope('notes')
  const before = notes._files.size
  assert.throws(
    () => writeCard({ notes, topic: 'gfm', card: { ...GOOD, [READING_FIELD]: 99 } }),
    (e) => e.code === 'E_CARD_SCHEMA' && Array.isArray(e.errors),
  )
  assert.throws(() => writeCard({ notes, topic: 'gfm', card: { ...GOOD, title: '' } }), (e) => e.code === 'E_CARD_SCHEMA')
  assert.throws(() => writeCard({ notes, topic: 'gfm', card: null }), (e) => e.code === 'E_CARD_SCHEMA')
  assert.equal(notes._files.size, before, '校验失败绝不能落盘')
  assert.equal(notes._writes.length, 0)
  assert.deepEqual(notes.list('gfm'), [])
})

test('cards: listCards / listAllCards / readCard 能读回并识别损坏卡片', () => {
  const notes = makeMemoryScope('notes')
  const card = validateCard(GOOD).card
  writeCard({ notes, topic: 'gfm', card, meta: { generatedBy: 'heuristic' } })
  const lc = listCards(notes, 'gfm')
  assert.equal(lc.length, 1)
  assert.equal(lc[0].doi, GOOD.doi.toLowerCase())
  assert.equal(lc[0].identity, `doi:${GOOD.doi.toLowerCase()}`)

  const all = listAllCards(notes)
  assert.equal(all.length, 1)
  assert.equal(all[0].ok, true)
  assert.equal(all[0].card.title, GOOD.title)
  assert.equal(all[0].meta.generatedBy, 'heuristic')

  // 放一张手写的坏卡片进另一个主题：listAllCards 必须把它标成 ok=false 而不是整体抛错
  notes.write('broken/nope.md', '---\ntitle: \n---\nbody')
  const all2 = listAllCards(notes)
  assert.equal(all2.length, 2)
  assert.equal(all2.filter((c) => !c.ok).length, 1)
  assert.ok(all2.find((c) => !c.ok).errors.length > 0)

  // 排除本插件私有目录
  const scoped = listAllCards(notes, { excludeTopics: ['gfm'] })
  assert.equal(scoped.length, 1)

  const rd = readCard(notes, lc[0].rel)
  assert.equal(rd.ok, true)
  assert.equal(rd.card[READING_FIELD], 3)
})

test('cards: listCards 对不存在的主题返回空数组而不是抛错', () => {
  const notes = makeMemoryScope('notes')
  assert.deepEqual(listCards(notes, 'not-there'), [])
  assert.deepEqual(listAllCards(notes), [])
})
