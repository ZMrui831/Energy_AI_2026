// tests/browser.test.mjs
//
// Phase 5 L1（非影响性浏览器）+ L4（让路策略）+ 合规层 的单元测试。
// 覆盖：yield-guard 让路逻辑、compliance 网关/限速/robots、extract 归一化、
// engine 端到端接线（黑名单硬拒 / 白名单放行+落盘 / 临时授权放行），
// 其中页面抽取通过注入 mock 的 openAndExtractFn 做确定性验证，
// 真·无头浏览器跑通见 tools/accept-stage5-browser.mjs（验收脚本）。

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdirSync, mkdtempSync, rmSync, existsSync, readFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'

import { createYieldGuard } from '../packages/plugins/research-browser/lib/yield-guard.mjs'
import {
  gateDomain, grantTempAuth, isDeniedDomain, HostThrottle, checkRobots, DENY_DOMAINS, NORMAL_UA,
} from '../packages/plugins/research-browser/lib/compliance.mjs'
import { parseStructured, slugFromUrl } from '../packages/plugins/research-browser/lib/extract.mjs'
import { createBrowserEngine } from '../packages/plugins/research-browser/lib/engine.mjs'
import { PROJECT_ROOT, dataPath } from '../packages/core/src/safefs.mjs'

// 浏览器证据必须落在项目根之内（safeWrite 根断言）。测试临时根放在 data/tmp/ 下。
function makeTestRoot() {
  mkdirSync(dataPath('tmp'), { recursive: true })
  return mkdtempSync(dataPath('tmp', 'browser-test-'))
}

// ---------------------------------------------------------------------------
// L4 让路策略
// ---------------------------------------------------------------------------
test('yield-guard: 用户空闲且前台属于我们 → 不抢占、可继续', async () => {
  const g = createYieldGuard({ getIdleSec: () => 999, isForegroundOurs: () => true, idleThresholdSec: 30 })
  assert.equal(g.shouldYield(), false)
  const r = await g.beforeGraphicalAction({ maxWaitMs: 200 })
  assert.equal(r.yielded, false)
  assert.equal(r.abandoned ?? false, false)
  assert.equal(r.reason, 'idle-and-ours')
})

test('yield-guard: 用户活动中（空闲秒数 < 阈值）→ 让路、超时放弃', async () => {
  const g = createYieldGuard({ getIdleSec: () => 1, idleThresholdSec: 30 }) // 仅 1 秒空闲 → 视为操作中
  assert.equal(g.shouldYield(), true)
  const r = await g.beforeGraphicalAction({ maxWaitMs: 120, pollMs: 40 })
  assert.equal(r.yielded, true)
  assert.equal(r.abandoned, true) // 持续活动 → 放弃，绝不抢占前台
})

test('yield-guard: 前台窗口不属于本应用 → 让路', () => {
  const g = createYieldGuard({ getIdleSec: () => 999, isForegroundOurs: () => false })
  assert.equal(g.shouldYield(), true)
})

test('yield-guard: 禁用后永不让路', async () => {
  const g = createYieldGuard({ getIdleSec: () => 0, isForegroundOurs: () => false, enabled: false })
  assert.equal(g.shouldYield(), false)
  const r = await g.beforeGraphicalAction({ maxWaitMs: 80 })
  assert.equal(r.yielded, false)
  assert.equal(r.reason, 'disabled')
})

// ---------------------------------------------------------------------------
// 合规层
// ---------------------------------------------------------------------------
test('compliance: 白名单域放行', () => {
  const r = gateDomain('https://arxiv.org/abs/2301.00001')
  assert.equal(r.allowed, true)
  assert.equal(r.kind, 'allow-whitelist')
})

test('compliance: 黑名单（sci-hub/libgen 类）无论是否授权都拒', () => {
  const auth = grantTempAuth(new Set(), 'sci-hub.se')
  const r = gateDomain('https://sci-hub.se/foo', { tempAuth: auth })
  assert.equal(r.allowed, false)
  assert.equal(r.kind, 'deny-blacklist')
  assert.equal(isDeniedDomain('sci-hub.se'), true)
  assert.equal(isDeniedDomain('arxiv.org'), false)
  assert.ok(DENY_DOMAINS.some((d) => d.includes('libgen')))
})

test('compliance: 非白名单且无临时授权 → 拒', () => {
  const r = gateDomain('https://example.com/page')
  assert.equal(r.allowed, false)
  assert.equal(r.kind, 'deny-not-allowed')
})

test('compliance: 按任务临时授权 → 放行（审计留痕由 engine 负责）', () => {
  const auth = grantTempAuth(new Set(), 'Example.com')
  const r = gateDomain('https://example.com/page', { tempAuth: auth })
  assert.equal(r.allowed, true)
  assert.equal(r.kind, 'allow-tempauth')
})

test('compliance: HostThrottle 单域限速 + 单飞', async () => {
  const th = new HostThrottle({ minMs: 60 })
  const t0 = Date.now()
  await th.acquire('a.com')
  await th.release('a.com')
  // 第二次立即 acquire，应被限到 ≥60ms
  await th.acquire('a.com')
  const waited = Date.now() - t0
  assert.ok(waited >= 55, `期望限流≥55ms，实际 ${waited}ms`)
  await th.release('a.com')
})

test('compliance: robots 白名单域按路径禁止', async () => {
  const robots = 'User-agent: *\nDisallow: /secret\n'
  const netGet = async () => ({ ok: true, text: robots })
  const deny = await checkRobots('https://arxiv.org/secret/x', netGet)
  assert.equal(deny.allowed, false)
  const allow = await checkRobots('https://arxiv.org/public/x', netGet)
  assert.equal(allow.allowed, true)
})

test('compliance: robots 非白名单域不做预检（skipped）', async () => {
  const netGet = async () => ({ ok: true, text: 'Disallow: /\n' })
  const r = await checkRobots('https://example.com/x', netGet)
  assert.equal(r.skipped, true)
})

// ---------------------------------------------------------------------------
// 合规静态断言（验收项 6）：黑名单/UA/不伪装 由代码常量强约束
// ---------------------------------------------------------------------------
test('compliance static: 黑名单含 sci-hub/libgen 且不可被临时授权绕过', () => {
  assert.ok(DENY_DOMAINS.some((d) => d.includes('sci-hub')), '黑名单含 sci-hub')
  assert.ok(DENY_DOMAINS.some((d) => d.includes('libgen')), '黑名单含 libgen')
  const auth = grantTempAuth(new Set(), 'sci-hub.se')
  const r = gateDomain('https://sci-hub.se/foo', { tempAuth: auth })
  assert.equal(r.allowed, false, '黑名单即使被临时授权也拒绝')
  assert.equal(r.kind, 'deny-blacklist')
})

test('compliance static: 正常 UA，绝不伪装成爬虫/机器人', () => {
  assert.match(NORMAL_UA, /Mozilla\/5\.0/)
  assert.match(NORMAL_UA, /Windows/)
  assert.doesNotMatch(NORMAL_UA, /bot|crawler|spider|curl|python-requests/i, '不得伪装为爬虫/脚本 UA')
})

// ---------------------------------------------------------------------------
// extract 归一化
// ---------------------------------------------------------------------------
test('extract: parseStructured 去重/清洗/补 host', () => {
  const raw = {
    title: '  Grid-Forming  控制 ', authors: ['王伟', '王伟', '', '  Li '], doi: ' 10.1/x ', year: '2021-05-03',
    abstract: '摘要…', snippet: '正文片段…', url: 'https://arxiv.org/abs/2301.00001',
  }
  const p = parseStructured(raw, raw.url)
  assert.equal(p.title, 'Grid-Forming 控制')
  assert.deepEqual(p.authors, ['王伟', 'Li'])
  assert.equal(p.doi, '10.1/x')
  assert.equal(p.year, '2021')
  assert.equal(p.host, 'arxiv.org')
  assert.equal(p.retrievedBy, 'research-browser (headless, non-intrusive)')
})

test('extract: slugFromUrl 确定性小写', () => {
  const s1 = slugFromUrl('https://arxiv.org/abs/2301.00001', 'Grid Forming 控制')
  const s2 = slugFromUrl('https://arxiv.org/abs/2301.00001', 'Grid Forming 控制')
  assert.equal(s1, s2)
  assert.ok(/^[a-z0-9\u4e00-\u9fa5-]+$/.test(s1))
})

// ---------------------------------------------------------------------------
// engine 端到端接线（mock 抽取器，确定性）
// ---------------------------------------------------------------------------
function fakeExtract(raw) {
  return async () => raw
}

test('engine: 黑名单域 → 直接拒绝，绝不启动浏览器', async () => {
  let launched = false
  const engine = createBrowserEngine({
    browserExe: 'C:/dummy/msedge.exe', // 注入真值绕过"无浏览器"早期返回（本机确有 Edge，但测试不依赖）
    openAndExtractFn: async () => { launched = true; return {} },
    browserRoot: makeTestRoot(),
  })
  const r = await engine.browse({ url: 'https://sci-hub.se/foo' })
  assert.equal(r.ok, false)
  assert.equal(r.code, 'E_DOMAIN_NOT_ALLOWED')
  assert.equal(launched, false, '黑名单不应触发任何浏览器启动')
})

test('engine: 白名单域 → 抽取并落盘 data/browser/<host>/<slug>.json', async () => {
  const root = makeTestRoot()
  const raw = {
    title: 'Grid-Forming Control', authors: ['Wang Wei'], doi: '10.1109/tpe.2023.1', year: '2023',
    abstract: 'An abstract.', snippet: 'body snippet', url: 'https://arxiv.org/abs/2301.00001',
  }
  const engine = createBrowserEngine({
    browserExe: 'C:/dummy/msedge.exe',
    openAndExtractFn: fakeExtract(raw),
    browserRoot: root,
  })
  const r = await engine.browse({ url: 'https://arxiv.org/abs/2301.00001' })
  assert.equal(r.ok, true, `期望成功，实际 ${r.code}:${r.reason}`)
  assert.ok(existsSync(r.path), `证据文件应存在: ${r.path}`)
  const saved = JSON.parse(readFileSync(r.path, 'utf8'))
  assert.equal(saved.title, 'Grid-Forming Control')
  assert.equal(saved.host, 'arxiv.org')
  assert.equal(saved.fetchedAt, saved.fetchedAt) // 存在
  // listEvidence 能找到
  const list = engine.listEvidence()
  assert.ok(list.length >= 1)
  rmSync(root, { recursive: true, force: true })
})

test('engine: 临时授权域 → 放行并落盘', async () => {
  const root = makeTestRoot()
  const engine = createBrowserEngine({
    browserExe: 'C:/dummy/msedge.exe',
    openAndExtractFn: fakeExtract({ title: 'Example Page', url: 'https://example.com/article' }),
    browserRoot: root,
  })
  const deniedBefore = await engine.browse({ url: 'https://example.com/article' })
  assert.equal(deniedBefore.ok, false, '授权前应被拒')

  engine.authorizeTemp('example.com')
  const okAfter = await engine.browse({ url: 'https://example.com/article' })
  assert.equal(okAfter.ok, true, `授权后应成功，实际 ${okAfter.code}:${okAfter.reason}`)
  assert.ok(existsSync(okAfter.path))
  rmSync(root, { recursive: true, force: true })
})
