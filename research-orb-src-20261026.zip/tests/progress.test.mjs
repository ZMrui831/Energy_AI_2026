// tests/progress.test.mjs
//
// 进度汇总离线回归：mtime 产出计数（内存 store 注入）、segment 计账口径、
// 分项目汇总、写盘/节流、周聚合。全部不落盘。

import test from 'node:test'
import assert from 'node:assert/strict'

import { createProgress } from '../packages/core/src/progress.mjs'
import { createMemoryStore } from '../packages/core/src/timer-store.mjs'

const DAY = '2026-01-15'
const MON = '2026-01-12' // 2026-01-15 是周四，所在周周一

function setup() {
  const store = createMemoryStore()
  const progress = createProgress({ store, now: () => new Date(2026, 0, 15, 12, 0, 0).getTime() })
  return { store, progress }
}

/** 直接往账本里塞一条 segment 行（等价于引擎落账的结果）。 */
function seg(store, dayKey, sec, extra = {}) {
  store.appendDay(dayKey, {
    type: 'segment',
    ts: new Date(2026, 0, 15, 10, 0, 0).toISOString(),
    dayKey,
    from: 'x',
    to: 'y',
    sec,
    kind: extra.kind || 'focus',
    sessionId: extra.sessionId || 't-1',
    projectId: extra.projectId || null,
    stageId: extra.stageId || null,
  })
}

test('progress: 必须注入 store', () => {
  assert.throws(() => createProgress({}), (e) => e.code === undefined && /store/.test(e.message))
})

test('progress: 空账本 -> 全零汇总（模板可生成的地基）', () => {
  const { progress } = setup()
  const d = progress.summarizeDay(DAY)
  assert.equal(d.dayKey, DAY)
  assert.equal(d.focusSec, 0)
  assert.equal(d.segmentCount, 0)
  assert.equal(d.sessionCount, 0)
  assert.equal(d.completedCount, 0)
  assert.equal(d.interruptedCount, 0)
  assert.deepEqual(d.byProject, [])
  assert.equal(d.outputs.cards.count, 0)
  assert.equal(d.outputs.bib.count, 0)
})

test('progress: 专注秒数 = Σsegment.sec（非 segment 行不掺和）', () => {
  const { store, progress } = setup()
  seg(store, DAY, 600)
  seg(store, DAY, 300, { kind: 'pause' })
  store.appendDay(DAY, { type: 'start', ts: 'x', sessionId: 't-1' })
  store.appendDay(DAY, { type: 'pause', ts: 'x', sessionId: 't-1', segmentSec: 300 })
  store.appendDay(DAY, { type: 'idle.prompt', ts: 'x', sessionId: 't-1', idleSec: 400 })
  const d = progress.summarizeDay(DAY)
  assert.equal(d.focusSec, 900)
  assert.equal(d.segmentCount, 2)
  assert.equal(d.sessionCount, 1)
})

test('progress: 会话/完成/中断计数各走各的类型', () => {
  const { store, progress } = setup()
  store.appendDay(DAY, { type: 'start', sessionId: 'a' })
  store.appendDay(DAY, { type: 'start', sessionId: 'b' })
  store.appendDay(DAY, { type: 'stop', sessionId: 'a', completed: true, totalSec: 900 })
  store.appendDay(DAY, { type: 'stop', sessionId: 'b', completed: false, totalSec: 100 })
  store.appendDay(DAY, { type: 'interrupted', sessionId: 'c', recordedSec: 300, gapSec: 120 })
  const d = progress.summarizeDay(DAY)
  assert.equal(d.sessionCount, 2)
  assert.equal(d.completedCount, 1)
  assert.equal(d.interruptedCount, 1)
})

test('progress: 分项目汇总补项目名，项目已删标注清楚', () => {
  const { store, progress } = setup()
  const p1 = progress.projects.create({ name: '构网型逆变器惯量支撑' })
  const p2 = progress.projects.create({ name: '配电网承载力评估' })
  seg(store, DAY, 900, { projectId: p2.id })
  seg(store, DAY, 1500, { projectId: p1.id })
  seg(store, DAY, 300, { projectId: 'ghost-project' })
  seg(store, DAY, 200) // 未归类
  const d = progress.summarizeDay(DAY)
  const byName = Object.fromEntries(d.byProject.map((r) => [r.name, r.focusSec]))
  assert.equal(byName['构网型逆变器惯量支撑'], 1500)
  assert.equal(byName['配电网承载力评估'], 900)
  assert.equal(byName['ghost-project（项目已删除）'], 300)
  assert.equal(byName['未归类'], 200)
  // 按时长降序
  assert.equal(d.byProject[0].focusSec, 1500)
})

test('progress: 分项目带阶段细分（项目 / 阶段两级，阶段已删有标注）', () => {
  const { store, progress } = setup()
  const p1 = progress.projects.create({ name: '构网型逆变器惯量支撑' })
  progress.projects.addStage(p1.id, { name: '文献综述' })
  progress.projects.addStage(p1.id, { name: '算例复现' })
  seg(store, DAY, 900, { projectId: p1.id, stageId: 's1' })
  seg(store, DAY, 600, { projectId: p1.id, stageId: 's2' })
  seg(store, DAY, 300, { projectId: p1.id, stageId: 's2', kind: 'final' })
  seg(store, DAY, 200, { projectId: p1.id }) // 项目内无阶段的部分
  seg(store, DAY, 120, { projectId: p1.id, stageId: 'ghost-stage' })
  const d = progress.summarizeDay(DAY)
  assert.equal(d.byProject.length, 1)
  const row = d.byProject[0]
  assert.equal(row.focusSec, 2120)
  const stages = Object.fromEntries(row.stages.map((s) => [s.stageName, s.focusSec]))
  assert.equal(stages['文献综述'], 900)
  assert.equal(stages['算例复现'], 900)
  assert.equal(stages['ghost-stage（阶段已删除）'], 120)
  // 按阶段时长降序
  assert.equal(row.stages[0].focusSec, 900)
})

test('progress: 产出计数走内存 store 注入（cards/bib 分开数）', () => {
  const { store, progress } = setup()
  store._setOutputs(DAY, {
    cards: [{ rel: 'data/notes/gfm/a.md' }, { rel: 'data/notes/gfm/b.md' }],
    bib: [{ rel: 'data/exports/refs-2026-01-15.bib' }],
  })
  const d = progress.summarizeDay(DAY)
  assert.equal(d.outputs.cards.count, 2)
  assert.deepEqual(d.outputs.cards.files, ['data/notes/gfm/a.md', 'data/notes/gfm/b.md'])
  assert.equal(d.outputs.bib.count, 1)
  assert.deepEqual(d.outputs.bib.files, ['data/exports/refs-2026-01-15.bib'])
})

test('progress: 别的日期没有产出数据时是零（不会串天）', () => {
  const { store, progress } = setup()
  store._setOutputs(DAY, { cards: [{ rel: 'data/notes/x/a.md' }], bib: [] })
  assert.equal(progress.summarizeDay(DAY).outputs.cards.count, 1)
  assert.equal(progress.summarizeDay('2026-01-16').outputs.cards.count, 0)
})

test('progress: writeDay 落盘、readDay 读回、maybeRefresh 节流', () => {
  const { store, progress } = setup()
  seg(store, DAY, 600)
  const written = progress.writeDay(DAY)
  assert.equal(written.dayKey, DAY)
  assert.ok(written.path.includes(DAY))
  const back = progress.readDay(DAY)
  assert.equal(back.focusSec, 600)
  // readDay 没有落盘文件时返回 null
  assert.equal(progress.readDay('2026-01-16'), null)
})

test('progress: maybeRefresh 60 秒内不重复写，force 立即写', () => {
  const { store, progress } = setup()
  seg(store, DAY, 600)
  let nowMs = new Date(2026, 0, 15, 12, 0, 0).getTime()
  const prog = createProgress({ store, now: () => nowMs })
  assert.ok(prog.maybeRefresh(), '首次必写')
  nowMs += 30_000
  assert.equal(prog.maybeRefresh(), null, '30 秒内被节流挡下')
  nowMs += 31_000
  assert.ok(prog.maybeRefresh(), '超过 60 秒放行')
  assert.ok(prog.maybeRefresh({ force: true }), 'force 无视节流')
  // 节流状态按实例隔离：另一个引擎（插件侧自建的那种）有自己的一份
  const other = createProgress({ store, now: () => nowMs })
  assert.ok(other.maybeRefresh(), '新实例首次不受旧实例节流影响')
})

test('progress: 周聚合 —— 逐日重算、activeDays、分项目合并、产出去重', () => {
  const { store, progress } = setup()
  const p1 = progress.projects.create({ name: '项目甲' })
  // 周四（DAY）：两个会话 900s
  store.appendDay(DAY, { type: 'start', sessionId: 'a' })
  seg(store, DAY, 900, { projectId: p1.id })
  store._setOutputs(DAY, { cards: [{ rel: 'data/notes/gfm/a.md' }], bib: [{ rel: 'data/exports/x.bib' }] })
  // 周五：300s 未归类 + 同一张卡片（mtime 若落在两天只应算一次 —— 去重按文件路径）
  const FRI = '2026-01-16'
  seg(store, FRI, 300)
  store._setOutputs(FRI, { cards: [{ rel: 'data/notes/gfm/a.md' }, { rel: 'data/notes/gfm/b.md' }], bib: [] })
  // 周日：一个完成会话
  const SUN = '2026-01-18'
  store.appendDay(SUN, { type: 'start', sessionId: 'z' })
  store.appendDay(SUN, { type: 'stop', sessionId: 'z', completed: true, totalSec: 600 })
  seg(store, SUN, 600)

  const week = progress.summarizeWeek(MON)
  assert.equal(week.weekKey, MON)
  assert.equal(week.from, MON)
  assert.equal(week.to, '2026-01-18')
  assert.equal(week.focusSec, 1800)
  assert.equal(week.sessionCount, 2)
  assert.equal(week.completedCount, 1)
  assert.equal(week.activeDays, 3)
  assert.equal(week.days.length, 7)
  const byName = Object.fromEntries(week.byProject.map((r) => [r.name, r.focusSec]))
  assert.equal(byName['项目甲'], 900)
  assert.equal(byName['未归类'], 900)
  // 产出按文件路径去重
  assert.equal(week.outputs.cards.count, 2)
  assert.deepEqual(week.outputs.cards.files, ['data/notes/gfm/a.md', 'data/notes/gfm/b.md'])
  assert.equal(week.outputs.bib.count, 1)
  // 每日明细按周一到周日排布，周四那天是 900
  assert.equal(week.days[3].dayKey, DAY)
  assert.equal(week.days[3].focusSec, 900)
})

test('progress: 周汇总对空周也返回完整 7 天结构', () => {
  const { progress } = setup()
  const week = progress.summarizeWeek(MON)
  assert.equal(week.focusSec, 0)
  assert.equal(week.activeDays, 0)
  assert.equal(week.days.length, 7)
  assert.deepEqual(week.byProject, [])
})

test('progress: projects 引擎经 progress 暴露（get/list/find/create/addStage/markDone）', () => {
  const { progress } = setup()
  const p = progress.projects.create({ name: '智慧能源系统' })
  assert.ok(/^[a-z0-9][a-z0-9._-]{1,63}$/i.test(p.id))
  assert.equal(progress.projects.get(p.id).name, '智慧能源系统')
  assert.equal(progress.projects.find('智慧能源系统').id, p.id)
  assert.equal(progress.projects.find(p.id).id, p.id)
  const withStage = progress.projects.addStage(p.id, { name: '文献调研' })
  assert.equal(withStage.stages.length, 1)
  assert.equal(withStage.stages[0].name, '文献调研')
  const done = progress.projects.markDone(p.id)
  assert.equal(done.done, true)
  assert.equal(progress.projects.list().length, 1)
})

test('progress: markDone 记录里程碑（阶段级/项目级，可省略）', () => {
  const { progress } = setup()
  const p = progress.projects.create({ name: '构网型逆变器' })
  progress.projects.addStage(p.id, { name: '文献综述' })
  // 阶段完成 + 里程碑
  const d1 = progress.projects.markDone(p.id, '文献综述', '完成 12 篇文献精读与综述初稿')
  assert.equal(d1.stages[0].done, true)
  assert.equal(d1.stages[0].milestone, '完成 12 篇文献精读与综述初稿')
  assert.ok(d1.stages[0].doneAt)
  // 项目完成 + 里程碑
  const d2 = progress.projects.markDone(p.id, null, '全部完成 提交校赛')
  assert.equal(d2.done, true)
  assert.equal(d2.milestone, '全部完成 提交校赛')
  // 不带给 milestone 时字段不出现（旧账本形状不变）
  const p2 = progress.projects.create({ name: '无里程碑' })
  progress.projects.addStage(p2.id, { name: '算例' })
  const d3 = progress.projects.markDone(p2.id, '算例')
  assert.equal(d3.stages[0].milestone, undefined)
  // 里程碑走名称校验：空串/换行被拒
  assert.throws(() => progress.projects.markDone(p.id, null, '  '), (e) => e.code === 'E_BAD_NAME')
})

// ---------------------------------------------------------------------------
// 加速/测试数据排除（阶段 3.1）：timeScale≠1 的会话不进真实进度，scaled 单列
// ---------------------------------------------------------------------------

test('progress: 加速会话（start 行 timeScale≠1）的 segment 不计入专注与分项目', () => {
  const { store, progress } = setup()
  const p1 = progress.projects.create({ name: '构网型逆变器惯量支撑' })
  // 真实会话：scale=1，2 段共 900s
  store.appendDay(DAY, { type: 'start', ts: 'x', sessionId: 'real-1', projectId: p1.id, timeScale: 1 })
  seg(store, DAY, 600, { sessionId: 'real-1', projectId: p1.id })
  seg(store, DAY, 300, { sessionId: 'real-1', projectId: p1.id, kind: 'final' })
  store.appendDay(DAY, { type: 'stop', ts: 'x', sessionId: 'real-1', projectId: p1.id, completed: true, totalSec: 900 })
  // 加速会话：scale=60，1 分钟番茄 1.1 秒真实走完 -> 计时秒 66，但【不计入】
  store.appendDay(DAY, { type: 'start', ts: 'x', sessionId: 'fast-1', projectId: p1.id, timeScale: 60 })
  seg(store, DAY, 66, { sessionId: 'fast-1', projectId: p1.id, kind: 'final' })
  store.appendDay(DAY, { type: 'stop', ts: 'x', sessionId: 'fast-1', projectId: p1.id, completed: true, totalSec: 66 })

  const d = progress.summarizeDay(DAY)
  // 真实进度只认 scale=1 的会话
  assert.equal(d.focusSec, 900)
  assert.equal(d.segmentCount, 2)
  assert.equal(d.sessionCount, 1)
  assert.equal(d.completedCount, 1)
  assert.equal(d.byProject.length, 1)
  assert.equal(d.byProject[0].focusSec, 900)
  // 加速数据单列，一个数字都不混进上方
  assert.equal(d.scaled.sessionCount, 1)
  assert.equal(d.scaled.segmentCount, 1)
  assert.equal(d.scaled.focusSec, 66)
})

test('progress: 旧账本（start 行无 timeScale 字段）不算加速', () => {
  const { store, progress } = setup()
  // 阶段 3 之前/测试里手写的行没有 timeScale：Number(undefined) 是 NaN，
  // 判定必须显式排除，否则全天真实数据会被误判成"加速"全部清零
  store.appendDay(DAY, { type: 'start', ts: 'x', sessionId: 'legacy-1' })
  seg(store, DAY, 600, { sessionId: 'legacy-1' })
  const d = progress.summarizeDay(DAY)
  assert.equal(d.focusSec, 600)
  assert.equal(d.sessionCount, 1)
  assert.equal(d.scaled.sessionCount, 0)
  assert.equal(d.scaled.focusSec, 0)
})

test('progress: 加速会话的 interrupted 行也不计入中断计数', () => {
  const { store, progress } = setup()
  store.appendDay(DAY, { type: 'interrupted', sessionId: 'fast-1', recordedSec: 30, gapSec: 10 })
  store.appendDay(DAY, { type: 'interrupted', sessionId: 'real-1', recordedSec: 30, gapSec: 10 })
  store.appendDay(DAY, { type: 'start', sessionId: 'fast-1', timeScale: 60 })
  const d = progress.summarizeDay(DAY)
  assert.equal(d.interruptedCount, 1, '加速会话的中断记录不污染真实中断计数')
})

test('progress: 周汇总继承逐日加速排除并单列 scaled', () => {
  const { store, progress } = setup()
  const p1 = progress.projects.create({ name: '项目甲' })
  // 周四：真实 900 + 加速 3600
  store.appendDay(DAY, { type: 'start', sessionId: 'real-a', projectId: p1.id, timeScale: 1 })
  seg(store, DAY, 900, { sessionId: 'real-a', projectId: p1.id })
  store.appendDay(DAY, { type: 'start', sessionId: 'fast-a', timeScale: 60 })
  seg(store, DAY, 3600, { sessionId: 'fast-a' })
  // 周五：只有加速
  const FRI = '2026-01-16'
  store.appendDay(FRI, { type: 'start', sessionId: 'fast-b', timeScale: 60 })
  seg(store, FRI, 1800, { sessionId: 'fast-b' })
  const week = progress.summarizeWeek(MON)
  assert.equal(week.focusSec, 900, '周专注只含真实会话')
  assert.equal(week.sessionCount, 1)
  assert.equal(week.activeDays, 1)
  assert.equal(week.scaled.sessionCount, 2)
  assert.equal(week.scaled.focusSec, 5400)
  const byName = Object.fromEntries(week.byProject.map((r) => [r.name, r.focusSec]))
  assert.equal(byName['项目甲'], 900)
  assert.equal(byName['未归类'], undefined, '加速会话的未归类时长不出现在分项目里')
})
