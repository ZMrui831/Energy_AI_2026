// tests/perception.test.mjs
//
// 感知层 S2 数据子代理（事件化 + 差分）回归测试（≥10 例）。
// 风格：import test from 'node:test' + node:assert/strict，顶层 test(...)，无 describe/it。
//
// 零真实盘污染：
//   · events 测试全部用【注入的假 writer（内存数组）】验证批次规则与事件立即写；
//   · diff 测试全部用构造的假灰度数组验证指标与阈值边界。

import test from 'node:test'
import assert from 'node:assert/strict'

import {
  EVENT_TYPES,
  detectEvents,
  createEventRecorder,
} from '../packages/plugins/perception/events.mjs'
import {
  downscaleGray,
  phashBits,
  phashInt,
  hamming,
  computeDiff,
} from '../packages/plugins/perception/diff.mjs'

const N = 256 * 144

// —— helpers ——
function frame(over = {}) {
  return {
    pid: 1,
    hwnd: 1,
    process: 'app',
    title: 't',
    idleMs: 0,
    isFullscreen: false,
    state: 'run',
    consent: 'granted',
    ...over,
  }
}
function grayFill(v) {
  return new Uint8Array(N).fill(v)
}
function memRecorders() {
  const events = []
  const summaries = []
  const rec = createEventRecorder({
    now: () => 0,
    writeEvent: (l) => events.push(l),
    writeSummary: (l) => summaries.push(l),
  })
  return { rec, events, summaries }
}

// ============================================================
// ① detectEvents —— 各事件类型触发
// ============================================================
test('events: window-switch（pid 变化）', () => {
  const ev = detectEvents(frame(), frame({ pid: 2, hwnd: 2, title: 't' }))
  assert.equal(ev.length, 1)
  assert.equal(ev[0].type, 'window-switch')
  assert.equal(ev[0].pid, 2)
  assert.ok(EVENT_TYPES.includes('window-switch'))
})

test('events: window-switch（hwnd 变化，pid 同）', () => {
  const ev = detectEvents(frame({ pid: 1 }), frame({ pid: 1, hwnd: 99 }))
  assert.equal(ev.length, 1)
  assert.equal(ev[0].type, 'window-switch')
  assert.equal(ev[0].hwnd, 99)
})

test('events: title-change（同进程 title 变，不派生 window-switch）', () => {
  const ev = detectEvents(
    frame({ pid: 1, hwnd: 1, title: 'A' }),
    frame({ pid: 1, hwnd: 1, title: 'B' }),
  )
  assert.equal(ev.length, 1)
  assert.equal(ev[0].type, 'title-change')
  assert.equal(ev[0].from, 'A')
  assert.equal(ev[0].to, 'B')
})

test('events: idle-start（idleMs 跨过 5000 阈值）', () => {
  const ev = detectEvents(frame({ idleMs: 1000 }), frame({ idleMs: 6000 }))
  assert.equal(ev.length, 1)
  assert.equal(ev[0].type, 'idle-start')
  assert.equal(ev[0].idleMs, 6000)
})

test('events: idle-end（idleMs 回落后阈值）', () => {
  const ev = detectEvents(frame({ idleMs: 9000 }), frame({ idleMs: 2000 }))
  assert.equal(ev.length, 1)
  assert.equal(ev[0].type, 'idle-end')
})

test('events: fullscreen-enter（isFullscreen 翻转）', () => {
  const ev = detectEvents(frame({ isFullscreen: false }), frame({ isFullscreen: true }))
  assert.equal(ev.length, 1)
  assert.equal(ev[0].type, 'fullscreen-enter')
  assert.equal(ev[0].isFullscreen, true)
})

test('events: fullscreen-leave（isFullscreen 翻转）', () => {
  const ev = detectEvents(frame({ isFullscreen: true }), frame({ isFullscreen: false }))
  assert.equal(ev.length, 1)
  assert.equal(ev[0].type, 'fullscreen-leave')
})

test('events: state-change + consent-change 同时', () => {
  const ev = detectEvents(
    frame({ state: 'run', consent: 'granted' }),
    frame({ state: 'paused', consent: 'revoked' }),
  )
  const types = ev.map((e) => e.type)
  assert.ok(types.includes('state-change'))
  assert.ok(types.includes('consent-change'))
  assert.equal(ev.find((e) => e.type === 'state-change').to, 'paused')
})

// ============================================================
// ② 无变化时不产生事件
// ============================================================
test('events: 完全相同的帧不产生事件', () => {
  const a = frame()
  const ev = detectEvents(a, { ...a })
  assert.deepEqual(ev, [])
  // prev 为 null 也不应产生事件
  assert.deepEqual(detectEvents(null, frame()), [])
})

// ============================================================
// ③ 汇总批次规则：<5秒且<50条 不写；≥5秒写；≥50条写
// ============================================================
test('batch: <5秒且<50条 不写 summary，flush 才写', () => {
  const { rec, summaries } = memRecorders()
  rec.tick(frame()) // 基线（不计数）
  for (let i = 0; i < 10; i++) rec.tick(frame()) // 10 条 tick，时间恒为 0
  assert.equal(summaries.length, 0, '未达批次阈值不应写 summary')
  rec.flush()
  assert.equal(summaries.length, 1, 'flush 应强制写出一次')
  assert.equal(summaries[0].type, 'tick-batch')
  assert.equal(summaries[0].count, 10)
})

test('batch: 达到 50 条 触发写出（≥50 条规则）', () => {
  const { rec, summaries } = memRecorders()
  rec.tick(frame()) // 基线
  for (let i = 0; i < 50; i++) rec.tick(frame()) // 共 51 次调用 → 计数到 50
  assert.equal(summaries.length, 1, '第 50 条应触发批次写出')
  assert.equal(summaries[0].count, 50)
  // 再多喂不应重复（已重置批次）
  rec.tick(frame())
  assert.equal(summaries.length, 1, '新批次未达阈值不应再写')
})

test('batch: 跨过 5 秒（注入假 now）触发写出（≥5秒规则）', () => {
  let clock = 0
  const events = []
  const summaries = []
  const rec = createEventRecorder({
    now: () => clock,
    writeEvent: (l) => events.push(l),
    writeSummary: (l) => summaries.push(l),
  })
  rec.tick(frame()) // 基线 + batchStart=0
  rec.tick(frame())
  rec.tick(frame())
  assert.equal(summaries.length, 0, '时间未跨 5 秒不应写')
  clock = 6000 // 注入假时钟：前进 6 秒
  rec.tick(frame()) // t - batchStart = 6000 >= 5000 → 写出
  assert.equal(summaries.length, 1, '跨过 5 秒应写出')
  assert.ok(summaries[0].durationMs >= 6000)
})

// ============================================================
// ④ 事件类立即写（不进批次）
// ============================================================
test('events: window-switch 立即落盘，但不写 summary（验证事件与批次隔离）', () => {
  const { rec, events, summaries } = memRecorders()
  rec.tick(frame()) // 基线
  rec.tick(frame({ pid: 2, hwnd: 2, process: 'b', title: 't2' })) // 触发 window-switch
  assert.equal(events.length, 1, '事件应被立即写')
  assert.equal(events[0].type, 'window-switch')
  assert.equal(summaries.length, 0, '事件不进批次，未达阈值不写 summary')
})

// ============================================================
// ⑤ computeDiff：同帧 changeScore ≈ 0
// ============================================================
test('diff: 完全相同帧 changeScore ≈ 0', () => {
  const a = grayFill(123)
  const r = computeDiff(a, a)
  assert.equal(r.meanDiff, 0)
  assert.equal(r.histogramDistance, 0)
  assert.equal(r.changeScore, 0)
  assert.ok(r.changeScore >= 0 && r.changeScore <= 1)
})

// ============================================================
// ⑥ computeDiff：异帧 changeScore > 0 且 ≤ 1
// ============================================================
test('diff: 部分不同帧 changeScore ∈ (0,1]', () => {
  const a = grayFill(100)
  const b = grayFill(100)
  for (let i = 0; i < N / 2; i++) b[i] = 200 // 一半像素变亮
  const r = computeDiff(a, b)
  assert.ok(r.meanDiff > 0, 'meanDiff 应 > 0')
  assert.ok(r.changeScore > 0, 'changeScore 应 > 0')
  assert.ok(r.changeScore <= 1, 'changeScore 应 ≤ 1')
  assert.ok(r.meanDiff < 1, '部分变化 meanDiff 应 < 1')
})

// ============================================================
// ⑦ computeDiff：完全不同帧 changeScore ≈ 1
// ============================================================
test('diff: 全黑 vs 全白 changeScore ≈ 1', () => {
  const a = grayFill(0)
  const b = grayFill(255)
  const r = computeDiff(a, b)
  assert.equal(r.meanDiff, 1)
  assert.equal(r.histogramDistance, 1)
  assert.ok(r.changeScore > 0.999, `changeScore 应≈1，实得 ${r.changeScore}`)
})

// ============================================================
// ⑧ histogramDistance 边界
// ============================================================
test('diff: histogramDistance 边界（相同=0，完全分离=1）', () => {
  const a = grayFill(0)
  const same = grayFill(0)
  assert.equal(computeDiff(a, same).histogramDistance, 0)
  const b = grayFill(255) // 全在 bin255，与全 bin0 完全分离
  assert.equal(computeDiff(a, b).histogramDistance, 1)
})

// ============================================================
// ⑨ phash / hamming 距离正确（同帧 0、翻转帧大）
// ============================================================
test('phash: phashBits 长度 64；同帧 hamming=0', () => {
  const a = new Uint8Array(N)
  for (let i = 0; i < N; i++) a[i] = i % 256 // 渐变，避免中值平局
  const bits = phashBits(a)
  assert.equal(bits.length, 64)
  assert.equal(hamming(bits, bits), 0, '同帧 hamming 应为 0')
  // BigInt 形式与其 0/1 数组一致
  assert.equal(hamming(phashInt(bits), phashInt(bits)), 0)
})

test('phash: 翻转帧（255-x）hamming 很大', () => {
  const a = new Uint8Array(N)
  for (let i = 0; i < N; i++) a[i] = i % 256
  const b = new Uint8Array(N)
  for (let i = 0; i < N; i++) b[i] = 255 - a[i]
  const da = phashBits(a)
  const db = phashBits(b)
  const h = hamming(da, db)
  assert.ok(h > 40, `翻转帧 hamming 应很大，实得 ${h}`)
})

// ============================================================
// ⑩ downscaleGray 尺寸正确（最近邻）
// ============================================================
test('diff: downscaleGray 最近邻尺寸与取值正确', () => {
  // 4×2 → 2×1：dx0 取 sx0=0 => 0，dx1 取 sx=floor(1*4/2)=2 => 2
  const src = Uint8Array.from([0, 1, 2, 3, 4, 5, 6, 7])
  const out = downscaleGray(src, 4, 2, 2, 1)
  assert.equal(out.length, 2)
  assert.deepEqual(Array.from(out), [0, 2])
  // 纯色 4×4 → 2×2 应全为该色
  const flat = new Uint8Array(16).fill(7)
  const out2 = downscaleGray(flat, 4, 4, 2, 2)
  assert.equal(out2.length, 4)
  assert.ok(out2.every((v) => v === 7))
})

test('diff: computeDiff 返回结构完整（含 phash 数组）', () => {
  const a = grayFill(0)
  const b = grayFill(255)
  const r = computeDiff(a, b)
  assert.ok(Array.isArray(r.phash))
  assert.equal(r.phash.length, 64)
  assert.equal(typeof r.changeScore, 'number')
})
