// tests/skip-audit.test.mjs —— S74c·P0-4 拒授权跳过聚合审计单元测试
//
// 验证：同一 60s 窗口内多条 skipped-no-consent 合并为单条聚合行
//   { kind:'skipped-no-consent', window:'60s', attempts:N, reason, reasons, firstTs, lastTs }
// 且不再写出多条独立行（避免审计刷屏），落 perception.jsonl。
import { test, beforeEach } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, readFileSync, rmSync, existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

// 必须在 import safefs/skip-audit 之前把日志目录指向临时目录（避免污染真实 data/logs）
const LOG_DIR = mkdtempSync(join(tmpdir(), 'orb-skip-audit-'))
process.env.ORB_LOG_DIR = LOG_DIR
process.env.ORB_DATA_DIR = join(LOG_DIR, 'data')

const { recordSkippedNoConsent, flushSkipAudit, __resetSkipAuditForTest, computeSkippedStats } = await import('../packages/plugins/perception/skip-audit.mjs')

const perceptLog = join(LOG_DIR, 'perception.jsonl')
const rows = () => (existsSync(perceptLog) ? readFileSync(perceptLog, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)) : [])

beforeEach(() => {
  __resetSkipAuditForTest()
  try { if (existsSync(perceptLog)) rmSync(perceptLog) } catch { /* noop */ }
})

test('同一 60s 窗口内多条跳过 → 合并为单条聚合行', () => {
  recordSkippedNoConsent({ reason: 'consent-inactive' })
  recordSkippedNoConsent({ reason: 'consent-inactive' })
  recordSkippedNoConsent({ reason: 'cold-start' })
  flushSkipAudit()
  const r = rows().filter((x) => x.kind === 'skipped-no-consent')
  assert.equal(r.length, 1, '窗口内应只落 1 条聚合行')
  assert.equal(r[0].window, '60s', 'window 字段为 60s')
  assert.equal(r[0].attempts, 3, 'attempts 累计 3 次')
  assert.equal(r[0].reason, 'consent-inactive', 'reason 保留首个来源（兼容旧断言）')
  assert.deepEqual([...r[0].reasons].sort(), ['cold-start', 'consent-inactive'], 'reasons 收录全部来源')
  assert.ok(Number.isFinite(Date.parse(r[0].firstTs)) && Number.isFinite(Date.parse(r[0].lastTs)), 'firstTs/lastTs 为合法时间')
})

test('聚合后不再写独立行（审计不刷屏）', () => {
  for (let i = 0; i < 8; i++) recordSkippedNoConsent({ reason: 'consent-inactive' })
  flushSkipAudit()
  const r = rows().filter((x) => x.kind === 'skipped-no-consent')
  assert.equal(r.length, 1, '8 次跳过只落 1 行')
  assert.equal(r[0].attempts, 8)
  assert.equal(r.filter((x) => x.window !== '60s').length, 0, '不存在无 window 的独立行')
})

test('聚合行具备 perception 状态卡消费所需字段（lastTs/attempts）', () => {
  recordSkippedNoConsent({ reason: 'consent-inactive' })
  recordSkippedNoConsent({ reason: 'consent-inactive' })
  flushSkipAudit()
  const r = rows().filter((x) => x.kind === 'skipped-no-consent')
  assert.equal(r.length, 1)
  assert.equal(r[0].attempts, 2)
  assert.ok(Number.isFinite(Date.parse(r[0].lastTs)), 'lastTs 可解析为时间戳（供 lastSkippedAt）')
})

test('computeSkippedStats：聚合行按 attempts 累加 + lastTs 取最近（/perception status 字段来源）', () => {
  const now = Date.now()
  const input = [
    { kind: 'skipped-no-consent', window: '60s', attempts: 4, firstTs: new Date(now - 5000).toISOString(), lastTs: new Date(now - 1000).toISOString() },
    { kind: 'skipped-no-consent', window: '60s', attempts: 2, firstTs: new Date(now - 70000).toISOString(), lastTs: new Date(now - 65000).toISOString() },
    { kind: 'frame-registered' }, // 非跳过行忽略
    { kind: 'skipped-no-consent', ts: new Date(now - 90000).toISOString() }, // 老单条行按 1 计
  ]
  const s = computeSkippedStats(input)
  assert.equal(s.skippedTotal, 4 + 2 + 1, 'attempts 累加 + 单条计 1')
  assert.equal(s.lastSkippedAt, now - 1000, 'lastSkippedAt 取最近一条的 lastTs')
})
