// tests/timer-driver.test.mjs
//
// 主进程计时驱动器离线回归（阶段 3 交付 5 的主进程半边）：
//   · 节拍 onTick：完成 -> 通知 + 强制刷新进度；跨午夜 -> 强制刷新；
//   · 空闲探测 onIdleCheck：>5 分钟 + 运行中 + 无未决询问才发起，不重复；
//   · 通知开关门控：setNotifications(false) 后一切通知只落日志；
//   · 崩溃恢复 recoverBoot：按心跳收尾 + 如实报告 gap；损坏态只 log 不 notify；
//   · 下行去重 pushTimer：显示态签名不变不推；
//   · settle：退出前停表收尾 + 清定时器。
//
// 全部虚拟时钟 + 内存 store + 注入的 send/notify/getIdleSec/log，不碰 electron。
// 注意：env.idleSec 必须通过 env 对象本体改（driver 闭包里引用的是同一个 env）。

import test from 'node:test'
import assert from 'node:assert/strict'

import { createTimerDriver } from '../apps/desktop/timer-driver.mjs'
import { createTimer, IDLE_ASK_SEC } from '../packages/core/src/timer.mjs'
import { createProgress } from '../packages/core/src/progress.mjs'
import { createMemoryStore } from '../packages/core/src/timer-store.mjs'

const T0 = new Date(2026, 0, 14, 10, 0, 0).getTime()

function makeClock(startMs = T0) {
  const c = { t: startMs }
  c.now = () => c.t
  c.advance = (ms) => {
    c.t += ms
    return c.t
  }
  c.set = (ms) => {
    c.t = ms
    return c.t
  }
  return c
}

/** 收集下行 / 通知 / 日志的假环境 + 记 maybeRefresh 调用的 progress 包装。 */
function makeEnv({ timer, clock, withProgress = true }) {
  const sent = []
  const notified = []
  const logs = []
  const refreshes = []
  const inner = createProgress({ store: timer._store, now: clock.now })
  const progress = {
    ...inner,
    maybeRefresh(args) {
      refreshes.push({ force: !!(args && args.force) })
      return inner.maybeRefresh(args)
    },
  }
  const driver = createTimerDriver({
    timer,
    progress: withProgress ? progress : null,
    send: (m) => sent.push(m),
    notify: (title, body) => notified.push({ title, body }),
    getIdleSec: () => env.idleSec,
    log: (type, detail) => logs.push({ type, detail }),
    tickMs: 10,
    idleCheckMs: 10,
  })
  // env 本体被 driver 闭包引用（idleSec 是可调字段），测试直接改 env.idleSec
  const env = { sent, notified, logs, refreshes, idleSec: 0, driver, timer, clock }
  return env
}

function setup({ timeScale = 1, startMs = T0 } = {}) {
  const clock = makeClock(startMs)
  const store = createMemoryStore()
  const timer = createTimer({ store, now: clock.now, timeScale })
  timer._store = store // 供 makeEnv 复用同一 store 建 progress
  return makeEnv({ timer, clock })
}

// ---------------------------------------------------------------------------
// 构造与下行去重
// ---------------------------------------------------------------------------

test('driver: 不注入 timer 引擎直接抛错', () => {
  assert.throws(() => createTimerDriver({}), /必须注入 timer 引擎/)
  assert.throws(() => createTimerDriver({ timer: {} }), /必须注入 timer 引擎/)
})

test('driver: pushTimer(force) 发送完整快照，签名不变则去重', () => {
  const env = setup()
  const snap = env.driver.pushTimer(true)
  assert.equal(snap.status, 'idle')
  assert.equal(env.sent.length, 1)
  assert.equal(env.sent[0].type, 'timer')
  assert.equal(env.sent[0].snapshot.status, 'idle')

  env.driver.pushTimer(true) // force 必发
  assert.equal(env.sent.length, 2)

  env.driver.pushTimer() // 非 force + 签名未变 -> 不发
  assert.equal(env.sent.length, 2)

  env.timer.start({ minutes: 25 }) // 状态真的变了
  env.driver.pushTimer()
  assert.equal(env.sent.length, 3)
  assert.equal(env.sent[2].snapshot.status, 'running')
})

test('driver: pushTimer 在 status() 抛错时只落日志不崩', () => {
  const broken = {
    tick() {},
    status() {
      throw new Error('boom')
    },
    getSettings: () => ({ notifications: true }),
  }
  const logs = []
  const driver = createTimerDriver({ timer: broken, log: (t) => logs.push(t) })
  const snap = driver.pushTimer(true)
  assert.equal(snap, null)
  assert.ok(logs.includes('timer-status-failed'))
})

test('driver: 没有 progress 引擎时 refreshProgress 静默跳过', () => {
  const clock = makeClock()
  const store = createMemoryStore()
  const timer = createTimer({ store, now: clock.now })
  timer._store = store
  const env = makeEnv({ timer, clock, withProgress: false })
  assert.deepEqual(env.refreshes, [])
  env.driver.refreshProgress(true)
  assert.deepEqual(env.refreshes, []) // 不调不存在的方法，也不抛
})

// ---------------------------------------------------------------------------
// 节拍：完成 / 跨午夜 / 普通
// ---------------------------------------------------------------------------

test('driver: onTick 到点完成 -> 通知 + 强制刷新进度 + 下行', () => {
  const env = setup({ timeScale: 60 })
  env.timer.start({ minutes: 1 }) // 1 分钟番茄，加速 60 倍 = 1 真实秒
  const n0 = env.sent.length
  env.clock.advance(1000)
  env.driver.onTick() // 这一次 tick 到点 -> justCompleted
  const last = env.notified[env.notified.length - 1]
  assert.equal(env.notified.length, 1)
  assert.equal(last.title, '番茄钟完成')
  assert.ok(last.body.includes('1 分钟'))
  assert.ok(env.refreshes.some((r) => r.force === true))
  assert.ok(env.sent.length > n0)
  assert.equal(env.timer.status().status, 'idle') // 引擎已自动收尾
})

test('driver: onTick 跨午夜 -> 强制刷新进度（不通知完成）', () => {
  // 从 23:59:50 起一个 45 分钟番茄，让 driver 的 onTick 自己跨过午夜
  const env = setup({ startMs: new Date(2026, 0, 14, 23, 59, 50).getTime() })
  env.timer.start({ minutes: 45 })
  const before = env.notified.length
  const n0 = env.refreshes.length
  env.clock.set(new Date(2026, 0, 15, 0, 0, 5).getTime())
  env.driver.onTick() // 内部 tick 观察到 justMidnight -> force 刷新
  assert.equal(env.notified.length, before) // 跨午夜不弹"完成"
  // onTick 末尾固定还有一次节流刷新，所以是 force + 非 force 两条
  assert.equal(env.refreshes.length, n0 + 2)
  assert.equal(env.refreshes[n0].force, true)
  assert.equal(env.refreshes[n0 + 1].force, false)
  // 跨午夜的部分真的落账了（23:59:50 -> 00:00:00 = 10 秒在前一天）
  assert.equal(env.timer._store.readDay('2026-01-14').filter((r) => r.type === 'segment' && r.kind === 'midnight').length, 1)
})

test('driver: onTick 普通节拍 -> 不通知、走节流刷新', () => {
  const env = setup()
  env.timer.start({ minutes: 25 })
  env.clock.advance(60_000)
  const n0 = env.refreshes.length
  env.driver.onTick()
  assert.equal(env.notified.length, 0)
  assert.equal(env.refreshes.length, n0 + 1)
  assert.equal(env.refreshes[n0].force, false)
})

test('driver: onTick 在 tick() 抛错时只落日志不崩', () => {
  const broken = {
    tick() {
      throw new Error('tick boom')
    },
    status: () => ({ status: 'idle' }),
    getSettings: () => ({ notifications: true }),
  }
  const logs = []
  const driver = createTimerDriver({ timer: broken, log: (t) => logs.push(t) })
  driver.onTick()
  assert.ok(logs.includes('timer-tick-failed'))
})

test('driver: 通知关闭后，完成事件只落 timer-notify-skipped 日志', () => {
  const env = setup({ timeScale: 60 })
  env.timer.setNotifications(false)
  env.timer.start({ minutes: 1 })
  env.clock.advance(1000)
  env.driver.onTick() // 这一次 tick 到点 -> justCompleted
  assert.equal(env.notified.length, 0)
  assert.ok(env.logs.some((l) => l.type === 'timer-notify-skipped' && l.detail && l.detail.title === '番茄钟完成'))
  // 通知开着时（默认）则正常弹
  env.timer.setNotifications(true)
  env.timer.start({ minutes: 1 })
  env.clock.advance(1000)
  env.driver.onTick()
  assert.equal(env.notified.length, 1)
})

// ---------------------------------------------------------------------------
// 空闲探测
// ---------------------------------------------------------------------------

test('driver: onIdleCheck 空闲超阈值 + 运行中 + 无未决 -> 发起询问', () => {
  const env = setup()
  env.timer.start({ minutes: 25 })
  env.idleSec = IDLE_ASK_SEC + 60
  env.driver.onIdleCheck()
  assert.equal(env.sent.filter((m) => m.type === 'timer:idle').length, 1)
  assert.equal(env.notified.length, 1)
  assert.ok(env.notified[0].title.includes('专注仍在进行'))
  assert.ok(env.logs.some((l) => l.type === 'timer-idle-prompt'))
  // 引擎里也真的记下了
  assert.ok(env.timer.status().idlePrompt)
})

test('driver: onIdleCheck 已有未决询问 -> 不重复发起', () => {
  const env = setup()
  env.timer.start({ minutes: 25 })
  env.idleSec = 400
  env.driver.onIdleCheck()
  env.driver.onIdleCheck()
  env.driver.onIdleCheck()
  assert.equal(env.sent.filter((m) => m.type === 'timer:idle').length, 1)
  assert.equal(env.timer.status().idlePrompt.idleSec, 400)
})

test('driver: onIdleCheck 非运行态 / 未达阈值 -> 不发起', () => {
  const env = setup()
  // 空闲态
  env.idleSec = 9999
  env.driver.onIdleCheck()
  assert.equal(env.sent.filter((m) => m.type === 'timer:idle').length, 0)
  // 运行中但阈值差 1 秒
  env.timer.start({ minutes: 25 })
  env.idleSec = IDLE_ASK_SEC - 1
  env.driver.onIdleCheck()
  assert.equal(env.sent.filter((m) => m.type === 'timer:idle').length, 0)
})

test('driver: onIdleCheck 在 getIdleSec 抛错时安全返回', () => {
  const clock = makeClock()
  const store = createMemoryStore()
  const timer = createTimer({ store, now: clock.now })
  timer._store = store
  const logs = []
  const driver = createTimerDriver({
    timer,
    getIdleSec: () => {
      throw new Error('powerMonitor gone')
    },
    log: (t) => logs.push(t),
  })
  driver.onIdleCheck() // 不抛即通过
  assert.equal(logs.length, 0) // 异常路径直接 return，不额外 log
})

// ---------------------------------------------------------------------------
// 面板上行：通知开关 / 空闲回答
// ---------------------------------------------------------------------------

test('driver: setNotifications 落盘 + 下行设置 + 强制推送', () => {
  const env = setup()
  const off = env.driver.setNotifications(false)
  assert.deepEqual(off, { notifications: false })
  assert.equal(env.timer.getSettings().notifications, false)
  const notifyMsgs = env.sent.filter((m) => m.type === 'timer:notify')
  assert.equal(notifyMsgs.length, 1)
  assert.deepEqual(notifyMsgs[0].settings, { notifications: false })
  // setNotifications 末尾还有一次 force pushTimer
  assert.equal(env.sent[env.sent.length - 1].type, 'timer')
  const on = env.driver.setNotifications(true)
  assert.deepEqual(on, { notifications: true })
  assert.equal(env.sent.filter((m) => m.type === 'timer:notify').length, 2)
  assert.ok(env.logs.some((l) => l.type === 'timer-notifications'))
})

test('driver: resolveIdle 两种回答都下行快照 + 强制刷新', () => {
  const env = setup()
  env.timer.start({ minutes: 25 })
  env.clock.advance(400_000) // 系统空闲 400s
  env.timer.noteIdle(400)
  // 扣除
  const snap1 = env.driver.resolveIdle(false)
  assert.equal(snap1.idlePrompt, null)
  const resolveMsgs = env.sent.filter((m) => m.type === 'timer:idle-resolve')
  assert.equal(resolveMsgs.length, 1)
  assert.ok(env.refreshes.some((r) => r.force === true))
  // 落账：扣除把 [段起点, 询问起点] 落成 idle-trim 段
  const segs = env.timer._store.readDay('2026-01-14').filter((r) => r.type === 'segment')
  assert.equal(segs.length, 1)
  assert.equal(segs[0].kind, 'idle-trim')

  // 再问一次，保留
  env.timer.noteIdle(500)
  const snap2 = env.driver.resolveIdle(true)
  assert.equal(snap2.idlePrompt, null)
  assert.equal(env.sent.filter((m) => m.type === 'timer:idle-resolve').length, 2)
  const resolves = env.timer._store.readDay('2026-01-14').filter((r) => r.type === 'idle.resolve')
  assert.equal(resolves.length, 2)
  assert.equal(resolves[0].keep, false)
  assert.equal(resolves[1].keep, true)
})

// ---------------------------------------------------------------------------
// 崩溃恢复
// ---------------------------------------------------------------------------

test('driver: recoverBoot 有中断会话 -> 通知"不猜不补" + 强制刷新 + 推送', () => {
  // 第一个"进程"：起一个会话后不收尾就"崩掉"
  const store = createMemoryStore()
  const clock1 = makeClock(T0)
  const timer1 = createTimer({ store, now: clock1.now })
  timer1.start({ minutes: 25 })
  clock1.advance(30_000)
  timer1.tick() // 留一次心跳（heartbeatAt = T0+30s）

  // 第二个"进程"：同一 store 重新装配，崩了 5 分钟后才重启
  const clock2 = makeClock(T0 + 5 * 60_000)
  const timer2 = createTimer({ store, now: clock2.now })
  timer2._store = store
  const env = makeEnv({ timer: timer2, clock: clock2 })
  const out = env.driver.recoverBoot()
  assert.equal(out.recovered, true)
  assert.equal(out.record.recordedSec, 30) // 只记到最后一次心跳（T0 -> T0+30s）
  assert.equal(out.record.gapSec, 270) // 心跳之后未知的 4 分 30 秒如实报告（不猜不补）
  assert.equal(env.notified.length, 1)
  assert.ok(env.notified[0].title.includes('上次专注已收尾'))
  assert.ok(env.notified[0].body.includes('不猜不补'))
  assert.ok(env.refreshes.some((r) => r.force === true))
  assert.equal(env.sent[env.sent.length - 1].type, 'timer') // 强制推送
  assert.equal(env.driver.bootRecovered().recovered, true)
})

test('driver: recoverBoot 无活动会话 -> 不通知，仍推送当前态', () => {
  const env = setup()
  const out = env.driver.recoverBoot()
  assert.equal(out.recovered, false)
  assert.equal(out.reason, 'no-active-session')
  assert.equal(env.notified.length, 0)
  assert.equal(env.sent[env.sent.length - 1].type, 'timer')
})

test('driver: recoverBoot 检出损坏 -> 只 log 不 notify，磁盘零写入', () => {
  const store = createMemoryStore()
  // 手写一个坏状态（startedAt 非法）
  store.writeState({ status: 'running', sessionId: 't-x', startedAt: 'not-a-ts', segmentStartedAt: T0, heartbeatAt: T0, plannedSec: 1500, accumulatedSec: 0 })
  const before = JSON.stringify(store.readState())
  const clock = makeClock()
  const timer = createTimer({ store, now: clock.now })
  timer._store = store
  const env = makeEnv({ timer, clock })
  const out = env.driver.recoverBoot()
  assert.equal(out.corrupt, true)
  assert.ok(out.problems.includes('startedAt'))
  assert.equal(env.notified.length, 0) // 损坏不弹窗（用户会被 /status 的提示告知）
  assert.ok(env.logs.some((l) => l.type === 'timer-corrupt'))
  assert.equal(JSON.stringify(store.readState()), before) // 一个字节都没改
})

test('driver: recoverBoot 在 recover() 抛错时兜底不崩', () => {
  const broken = {
    tick() {},
    status: () => ({ status: 'idle' }),
    getSettings: () => ({ notifications: true }),
    recover() {
      throw new Error('recover boom')
    },
  }
  const logs = []
  const driver = createTimerDriver({ timer: broken, log: (t) => logs.push(t) })
  const out = driver.recoverBoot()
  assert.equal(out.recovered, false)
  assert.ok(out.error.includes('recover boom'))
  assert.ok(logs.includes('timer-recover-failed'))
})

// ---------------------------------------------------------------------------
// 退出收尾与定时器生命周期
// ---------------------------------------------------------------------------

test('driver: settle 停表收尾 + 清定时器；空闲态调用不抛', () => {
  const env = setup()
  env.driver.start()
  env.timer.start({ minutes: 25 })
  env.clock.advance(120_000)
  env.driver.settle('app-quit')
  assert.equal(env.timer.status().status, 'idle')
  // 账本里有 reason=app-quit 的 stop 行
  const stops = env.timer._store.readDay('2026-01-14').filter((r) => r.type === 'stop')
  assert.equal(stops.length, 1)
  assert.equal(stops[0].reason, 'app-quit')
  assert.ok(env.logs.some((l) => l.type === 'timer-settle-stopped'))
  // 空闲态再 settle 一次：E_TIMER_NOT_RUNNING 被吞掉
  env.driver.settle('app-quit')
  assert.equal(env.timer.status().status, 'idle')
})

test('driver: start 后 stopTimers 清掉所有定时器（测试不挂起）', async () => {
  const env = setup()
  env.timer.start({ minutes: 25 })
  env.driver.start()
  await new Promise((r) => setTimeout(r, 60)) // 跨过几个 tickMs=10ms 的节拍
  env.driver.stopTimers()
  const rev = env.timer.status().revision
  await new Promise((r) => setTimeout(r, 60))
  assert.equal(env.timer.status().revision, rev) // 节拍停了，心跳不再写
  // 幂等：重复停不抛
  env.driver.stopTimers()
  env.driver.stopTimers()
  // 重复 start 只建一套（tickTimer 已存在时直接返回）
  env.driver.start()
  env.driver.stopTimers()
})
