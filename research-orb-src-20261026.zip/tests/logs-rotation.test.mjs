// tests/logs-rotation.test.mjs
//
// S3 日志轮转测试。全部在 os.tmpdir() 临时夹具中运行，绝不触碰真实 data/logs。

import { test } from 'node:test'
import assert from 'node:assert/strict'
import os from 'node:os'
import {
  existsSync,
  mkdtempSync,
  readdirSync,
  readFileSync,
  rmSync,
  statSync,
  writeFileSync,
} from 'node:fs'
import { join } from 'node:path'
import { planRotation, rotateLogs } from '../packages/core/src/lifecycle/logs.mjs'

// ---------------------------------------------------------------- 夹具工具

function makeTmp() {
  return mkdtempSync(join(os.tmpdir(), 'orb-logs-'))
}

/** 某本地日期正午的时间戳（避免午夜边界），daysAgo 天前。 */
function noonTs(now, daysAgo) {
  const d = new Date(now.getTime())
  d.setDate(d.getDate() - daysAgo)
  d.setHours(12, 0, 0, 0)
  return d.getTime()
}

function localDayOf(d) {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}${m}${day}`
}

function evLine(ts, extra = {}) {
  return JSON.stringify({ ts, kind: 'net-call', ...extra })
}

function writeFileLines(path, lines) {
  writeFileSync(path, lines.length ? lines.join('\n') + '\n' : '', 'utf8')
}

function readLines(path) {
  const text = readFileSync(path, 'utf8')
  if (text === '') return []
  const lines = text.split('\n')
  if (lines[lines.length - 1] === '') lines.pop()
  return lines
}

function countLinesInDir(dir, filter = () => true) {
  let n = 0
  for (const f of readdirSync(dir)) {
    if (!f.endsWith('.jsonl') || !filter(f)) continue
    n += readLines(join(dir, f)).length
  }
  return n
}

// ---------------------------------------------------------------- planRotation

test('planRotation: 按天分组且行序保持、总行数不变', () => {
  const now = new Date()
  const lines = [
    evLine(noonTs(now, 2)),
    evLine(noonTs(now, 0)),
    evLine(noonTs(now, 2)),
    evLine(noonTs(now, 1)),
  ]
  const plan = planRotation(lines, { maxBytes: 1_000_000 })
  assert.equal(plan.totalLines, 4)
  assert.equal(plan.parts.length, 3)
  const days = plan.parts.map((p) => p.suffix)
  const d0 = localDayOf(new Date(noonTs(now, 0)))
  const d1 = localDayOf(new Date(noonTs(now, 1)))
  const d2 = localDayOf(new Date(noonTs(now, 2)))
  assert.deepEqual(days, [`-${d2}`, `-${d1}`, `-${d0}`])
  // 每个分片行数：2 / 1 / 1
  assert.deepEqual(
    plan.parts.map((p) => p.lines.length),
    [2, 1, 1],
  )
})

test('planRotation: 单日超限按 -1/-2 拆分且各分片不超上限', () => {
  const big = 'x'.repeat(100)
  const lines = Array.from({ length: 50 }, (_, i) => evLine(1700000000000 + i, { big }))
  const plan = planRotation(lines, { maxBytes: 1024 })
  assert.equal(plan.totalLines, 50)
  assert.ok(plan.parts.length >= 2)
  assert.equal(plan.parts[0].suffix.endsWith('-1'), true)
  assert.equal(plan.parts[1].suffix.endsWith('-2'), true)
  for (const p of plan.parts) {
    const bytes = p.lines.reduce((s, l) => s + Buffer.byteLength(l, 'utf8') + 1, 0)
    assert.ok(bytes <= 1024, `分片字节 ${bytes} 超过上限 1024`)
  }
  // 行不重不漏
  assert.deepEqual(plan.parts.flatMap((p) => p.lines), lines)
})

// ---------------------------------------------------------------- rotateLogs

test('rotateLogs: 3 天混合行 → 总行数精确不变、按天文件名正确、主文件清空', () => {
  const dir = makeTmp()
  try {
    const now = new Date('2026-10-17T15:00:00')
    const lines = []
    for (let k = 0; k < 3; k++) {
      const ts = noonTs(now, k)
      for (let i = 0; i < 5; i++) lines.push(evLine(ts + i * 1000))
    }
    writeFileLines(join(dir, 'net.jsonl'), lines)
    const res = rotateLogs({ logsDir: dir, now })
    // 总行数 before == after 精确断言
    assert.equal(res.totalBeforeLines, 15)
    assert.equal(res.totalAfterLines, 15)
    assert.equal(countLinesInDir(dir, (f) => f !== 'lifecycle.jsonl'), 15)
    // 按天文件名正确（分片按日期升序）
    const expectDays = [2, 1, 0].map((k) => localDayOf(new Date(noonTs(now, k))))
    const gotParts = res.files[0].parts
    assert.deepEqual(gotParts, expectDays.map((d) => `net-${d}.jsonl`))
    for (const p of gotParts) {
      assert.ok(existsSync(join(dir, p)), `缺少分片 ${p}`)
      assert.equal(readLines(join(dir, p)).length, 5)
    }
    // 主文件清空（内容全归档）
    assert.equal(readLines(join(dir, 'net.jsonl')).length, 0)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('rotateLogs: 单日超限 → -1/-2 分片，每个分片文件不超过上限', () => {
  const dir = makeTmp()
  try {
    const now = new Date()
    const big = 'y'.repeat(200)
    // maxFileMB:1 → 上限 1048576；每行 ~220 字节 → 6000 行 ~1.3MB
    const lines = Array.from({ length: 6000 }, (_, i) => evLine(noonTs(now, 0) + i, { big }))
    writeFileLines(join(dir, 'app.jsonl'), lines)
    const res = rotateLogs({ logsDir: dir, now, maxFileMB: 1 })
    assert.equal(res.totalBeforeLines, 6000)
    assert.equal(res.totalAfterLines, 6000)
    const parts = res.files[0].parts
    assert.ok(parts.length >= 2, '应拆成多个分片')
    assert.match(parts[0], /app-\d{8}-1\.jsonl$/)
    assert.match(parts[1], /app-\d{8}-2\.jsonl$/)
    const maxBytes = 1024 * 1024
    for (const p of parts) {
      assert.ok(statSync(join(dir, p)).size <= maxBytes, `${p} 超过 1MB 上限`)
    }
    assert.equal(countLinesInDir(dir, (f) => f !== 'lifecycle.jsonl'), 6000)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('rotateLogs: rotateOnly（writes.jsonl）过期分片只归档不删除', () => {
  const dir = makeTmp()
  try {
    const now = new Date('2026-10-17T12:00:00')
    // 预置过期切割分片（30 天前）
    const oldLines = [evLine(noonTs(now, 30)), evLine(noonTs(now, 30) + 1)]
    writeFileLines(join(dir, 'writes-20260917.jsonl'), oldLines)
    const res = rotateLogs({ logsDir: dir, now, rotateOnly: ['writes.jsonl'] })
    // 原分片不在了，但内容以 -archived-<ts> 形式保留，审计永不丢
    assert.ok(!existsSync(join(dir, 'writes-20260917.jsonl')))
    const archived = readdirSync(dir).filter((f) => /writes-20260917-archived-\d+\.jsonl$/.test(f))
    assert.equal(archived.length, 1)
    assert.deepEqual(readLines(join(dir, archived[0])), oldLines)
    const act = res.retention.find((r) => r.action === 'archived')
    assert.ok(act, '返回值应体现 retention 归档动作')
    assert.equal(act.base, 'writes')
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('rotateLogs: 非 rotateOnly 过期分片被删除，新鲜分片保留', () => {
  const dir = makeTmp()
  try {
    const now = new Date('2026-10-17T12:00:00')
    writeFileLines(join(dir, 'net-20260917.jsonl'), [evLine(1)]) // 30 天前 → 删
    writeFileLines(join(dir, 'net-20261016.jsonl'), [evLine(2)]) // 昨日 → 留
    rotateLogs({ logsDir: dir, now, rotateOnly: ['writes.jsonl'] })
    assert.ok(!existsSync(join(dir, 'net-20260917.jsonl')), '过期分片应被删除')
    assert.ok(existsSync(join(dir, 'net-20261016.jsonl')), '新鲜分片应保留')
    assert.equal(readLines(join(dir, 'net-20261016.jsonl')).length, 1)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('rotateLogs: 边界——空目录/空文件/单行文件不抛不丢；已切割文件不再轮转', () => {
  const dir = makeTmp()
  try {
    const now = new Date('2026-10-17T12:00:00')
    // 空目录
    let res = rotateLogs({ logsDir: dir, now })
    assert.deepEqual(res, { files: [], retention: [], totalBeforeLines: 0, totalAfterLines: 0 })
    // 空文件
    writeFileLines(join(dir, 'empty.jsonl'), [])
    // 单行文件
    writeFileLines(join(dir, 'one.jsonl'), [evLine(noonTs(now, 0))])
    // 已切割文件（-YYYYMMDD / -N / -archived-）不应被当主文件再轮转
    // （用 5 天前的日期命名，避开 14 天保留期清扫）
    const recent = localDayOf(new Date(noonTs(now, 5)))
    writeFileLines(join(dir, `net-${recent}.jsonl`), [evLine(noonTs(now, 5))])
    writeFileLines(join(dir, 'seq-1.jsonl'), [evLine(noonTs(now, 5))])
    writeFileLines(join(dir, 'old-archived-123.jsonl'), [evLine(noonTs(now, 5))])
    res = rotateLogs({ logsDir: dir, now })
    assert.equal(res.totalBeforeLines, 1) // 只有 one.jsonl 是主文件
    assert.equal(res.totalAfterLines, 1)
    assert.ok(existsSync(join(dir, `net-${recent}.jsonl`)), '已切割文件不应被动')
    assert.deepEqual(readLines(join(dir, `net-${recent}.jsonl`)), [evLine(noonTs(now, 5))])
    assert.equal(readLines(join(dir, 'seq-1.jsonl')).length, 1)
    assert.equal(readLines(join(dir, 'old-archived-123.jsonl')).length, 1)
    // 单行内容进了当天分片
    const today = localDayOf(new Date(noonTs(now, 0)))
    assert.equal(readLines(join(dir, `one-${today}.jsonl`)).length, 1)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('rotateLogs: lifecycle.jsonl 收到 log-rotated 记录（append 单行）', () => {
  const dir = makeTmp()
  try {
    const now = new Date('2026-10-17T12:00:00')
    writeFileLines(join(dir, 'net.jsonl'), [evLine(noonTs(now, 0)), evLine(noonTs(now, 1))])
    rotateLogs({ logsDir: dir, now })
    const lc = join(dir, 'lifecycle.jsonl')
    assert.ok(existsSync(lc))
    const lines = readLines(lc)
    assert.equal(lines.length, 1)
    const rec = JSON.parse(lines[0])
    assert.equal(rec.kind, 'log-rotated')
    assert.equal(rec.file, 'net.jsonl')
    assert.equal(rec.beforeLines, 2)
    assert.equal(rec.afterLines, 2)
    assert.ok(Array.isArray(rec.parts) && rec.parts.length === 2)
    assert.equal(typeof rec.beforeBytes, 'number')
    assert.equal(typeof rec.afterBytes, 'number')
    // 再跑一次：append 而非重写 → 记录变 2 行
    rotateLogs({ logsDir: dir, now })
    assert.equal(readLines(lc).length, 2)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('rotateLogs: 解析失败行归入当天且不丢；幂等重跑同一天内容并入不重复', () => {
  const dir = makeTmp()
  try {
    const now = new Date('2026-10-17T12:00:00')
    const good = evLine(noonTs(now, 0))
    writeFileLines(join(dir, 'mix.jsonl'), ['这不是JSON{{{', good])
    const res = rotateLogs({ logsDir: dir, now })
    assert.equal(res.totalBeforeLines, 2)
    assert.equal(res.totalAfterLines, 2)
    const today = localDayOf(new Date(noonTs(now, 0)))
    const partLines = readLines(join(dir, `mix-${today}.jsonl`))
    assert.deepEqual(partLines, ['这不是JSON{{{', good]) // 坏行归当天、内容原样
    // 主文件追加新行后再轮转：与既有当天分片合并不覆盖丢失
    const good2 = evLine(noonTs(now, 0) + 999)
    writeFileLines(join(dir, 'mix.jsonl'), [good2])
    const res2 = rotateLogs({ logsDir: dir, now })
    assert.equal(res2.totalBeforeLines, 1)
    assert.equal(res2.totalAfterLines, 3) // 旧分片 2 行 + 新 1 行
    assert.equal(readLines(join(dir, `mix-${today}.jsonl`)).length, 3)
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('rotateLogs: 缺 logsDir 必须抛错（绝不默认轮转真实 data/logs）', () => {
  assert.throws(() => rotateLogs({}), /E_NO_LOGSDIR/)
  assert.throws(() => rotateLogs(), /E_NO_LOGSDIR/)
})
