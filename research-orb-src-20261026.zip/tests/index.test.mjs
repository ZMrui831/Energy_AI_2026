// tests/index.test.mjs
//
// 混合检索索引（交付 4）：确定性哈希向量、卡片→文档映射、落盘/读回、混合检索、
// 以及"索引坏了必须能重建而不是报错"这条可恢复性。

import test from 'node:test'
import assert from 'node:assert/strict'

import {
  INDEX_FILENAME,
  INDEX_MANIFEST_FILENAME,
  INDEX_SCHEMA_VERSION,
  VECTOR_DIM,
  buildIndex,
  buildIndexBody,
  cardDocId,
  documentFromCard,
  embedText,
  fnv1a,
  loadOrRebuild,
  persistIndex,
  readIndex,
  rebuildIndex,
  searchIndex,
  tokenizeForVector,
} from '../packages/plugins/research-literature/lib/index-store.mjs'
import { validateCard } from '../packages/plugins/research-literature/lib/cards.mjs'
import { makeMemoryScope } from './helpers/research-fixtures.mjs'

const CARD_A = validateCard({
  title: 'Grid-Forming Inverter Control for Inertia Support',
  authors: ['Wei Wang'],
  venue: 'IEEE Transactions on Power Systems',
  year: 2024,
  doi: '10.1109/TPWRS.2024.0001',
  url: 'https://doi.org/10.1109/TPWRS.2024.0001',
  pdf: null,
  tags: ['grid-forming inverter'],
  问题: '低惯量系统的频率稳定性问题。',
  方法: '虚拟惯量控制器与 droop 控制协同。',
  数据与算例: '改进 IEEE 9 节点系统。',
  结论与局限: '频率最低点改善 0.12 Hz。',
  可复用点: '一阶频率环。',
  待验证点: '弱电网边界。',
  与我课题的关系: '基线对照。',
  '读数（0-5）': 2,
}).card

const CARD_B = validateCard({
  title: 'Microgrid Islanding Detection Using Wavelet Transform',
  authors: ['Hao Chen'],
  venue: 'Electric Power Systems Research',
  year: 2019,
  doi: '10.1016/j.epsr.2019.0002',
  url: 'https://doi.org/10.1016/j.epsr.2019.0002',
  pdf: null,
  tags: ['islanding detection'],
  问题: '孤岛检测速度与可靠性。',
  方法: '小波变换特征提取加阈值判别。',
  数据与算例: '含分布式电源的配电馈线。',
  结论与局限: '检测时间小于 20 ms。',
  可复用点: '小波特征。',
  待验证点: '多逆变器并联场景。',
  与我课题的关系: '弱相关，仅作方法参考。',
  '读数（0-5）': 1,
}).card

const ENTRY_A = { ok: true, rel: 'gfm/grid-forming-inverter.md', topic: 'gfm', slug: 'grid-forming-inverter', card: CARD_A, content: '\n## 我的批注\n\n这篇的算例可以借用。\n' }
const ENTRY_B = { ok: true, rel: 'microgrid/islanding.md', topic: 'microgrid', slug: 'islanding', card: CARD_B, content: '' }

// ---------------------------------------------------------------------------
// 向量
// ---------------------------------------------------------------------------

test('index: 哈希向量确定性、定长、已 L2 归一', () => {
  const v1 = embedText('grid-forming inverter inertia support')
  const v2 = embedText('grid-forming inverter inertia support')
  assert.deepEqual(v1, v2, '同文本必须同向量（这是"可复现检索"的前提）')
  assert.equal(v1.length, VECTOR_DIM)
  const norm = Math.sqrt(v1.reduce((s, x) => s + x * x, 0))
  assert.ok(Math.abs(norm - 1) < 0.01, `应归一，实际 ${norm}`)
  assert.notDeepEqual(embedText('microgrid islanding'), v1)
  assert.deepEqual(embedText(''), new Array(VECTOR_DIM).fill(0))
  assert.equal(fnv1a('abc'), fnv1a('abc'))
  assert.notEqual(fnv1a('abc'), fnv1a('abd'))
  assert.ok(Number.isInteger(fnv1a('x')) && fnv1a('x') >= 0)
})

test('index: 分词丢停用词、中文按单字+双字切', () => {
  const t = tokenizeForVector('The grid inverter and the microgrid 惯量支撑')
  assert.ok(!t.includes('the'))
  assert.ok(!t.includes('and'))
  assert.ok(t.includes('grid'))
  assert.ok(t.includes('惯'))
  assert.ok(t.includes('惯量'))
  assert.ok(t.includes('支撑'))
})

test('index: 卡片文档 id 优先 DOI，其次 URL，再退 rel', () => {
  assert.equal(cardDocId(CARD_A, 'x.md'), 'doi:10.1109/tpwrs.2024.0001')
  assert.equal(cardDocId({ doi: null, url: 'https://a/b' }, 'x.md'), 'url:https://a/b')
  assert.equal(cardDocId({ doi: null, url: '', title: 't' }, 'gfm/a.md'), 'rel:gfm/a.md')
})

// ---------------------------------------------------------------------------
// 文档映射
// ---------------------------------------------------------------------------

test('index: documentFromCard 把解释性字段与批注一起进 body', () => {
  const doc = documentFromCard(CARD_A, ENTRY_A)
  assert.equal(doc.id, 'doi:10.1109/tpwrs.2024.0001')
  assert.equal(doc.title, CARD_A.title)
  assert.equal(doc.authors, 'Wei Wang')
  assert.equal(doc.year, 2024)
  assert.equal(doc.reading, 2)
  assert.equal(doc.topic, 'gfm')
  assert.equal(doc.slug, 'grid-forming-inverter')
  assert.equal(doc.rel, 'gfm/grid-forming-inverter.md')
  assert.equal(doc.vector.length, VECTOR_DIM)
  for (const f of ['虚拟惯量控制器', 'IEEE 9 节点', '0.12 Hz', '基线对照']) assert.ok(doc.body.includes(f), `body 缺少 ${f}`)
  assert.ok(doc.body.includes('这篇的算例可以借用'), '用户批注必须可被检索')

  const body = buildIndexBody(CARD_B, '')
  assert.ok(body.includes('孤岛检测'))
  // year 缺失时用 0 占位（Orama number 字段不接受 null）
  assert.equal(documentFromCard({ ...CARD_A, year: null }, {}).year, 0)
})

// ---------------------------------------------------------------------------
// 建库 / 落盘 / 读回
// ---------------------------------------------------------------------------

test('index: 建库 → 落盘 → 读回，检索命中同一张卡片', async () => {
  const index = makeMemoryScope('index')
  const built = await buildIndex([ENTRY_A, ENTRY_B])
  assert.equal(built.docs.length, 2)
  assert.equal(built.manifest.count, 2)
  assert.equal(built.manifest.schemaVersion, INDEX_SCHEMA_VERSION)
  assert.equal(built.manifest.vectorDim, VECTOR_DIM)
  assert.ok(built.manifest.oramaVersion !== 'unknown', 'manifest 应记录 Orama 版本便于归因')
  assert.equal(built.manifest.cards[0].doi, '10.1109/tpwrs.2024.0001')

  await persistIndex(index, built)
  assert.ok(index.exists(INDEX_FILENAME))
  assert.ok(index.exists(INDEX_MANIFEST_FILENAME))

  const read = await readIndex(index)
  assert.equal(read.reason, null, `读回失败：${read.reason}`)
  assert.ok(read.db)
  assert.equal(read.manifest.count, 2)

  const hit = await searchIndex(read.db, { term: 'grid-forming inverter inertia', limit: 5 })
  assert.equal(hit.mode, 'hybrid')
  assert.ok(hit.hits.length >= 1)
  assert.equal(hit.hits[0].document.doi, '10.1109/tpwrs.2024.0001')
  assert.ok(typeof hit.hits[0].score === 'number')
})

test('index: 忽略 ok=false 的条目（坏卡片不进索引）', async () => {
  const built = await buildIndex([ENTRY_A, { ok: false, rel: 'x/y.md', card: null }, null, ENTRY_B])
  assert.equal(built.docs.length, 2)
  assert.equal(built.manifest.count, 2)
})

test('index: 同一篇论文归档到两个主题时按论文身份去重（否则 insertMultiple 会整体抛错）', async () => {
  // 回归：面板里把归档主题从 gfm 换成 inbox 再点一次生成，就会产生这种"同一 DOI、两张卡片"的局面。
  // 不去重的话 Orama 抛 "A document with id ... already exists"，整个索引重建失败、/recall 永久不可用。
  const CARD_A_INBOX = { ...CARD_A, '读数（0-5）': 5 }
  const entryInbox = { ok: true, rel: 'inbox/grid-forming.md', topic: 'inbox', slug: 'grid-forming', card: CARD_A_INBOX, content: '' }
  const built = await buildIndex([ENTRY_A, entryInbox, ENTRY_B])
  assert.equal(built.docs.length, 2, '去重后应只剩 2 条文档')
  assert.equal(built.manifest.count, 2)
  assert.equal(built.manifest.duplicateCount, 1)
  assert.equal(built.duplicates[0].kept, 'inbox/grid-forming.md', '应保留读数更高的那张')
  assert.deepEqual(built.duplicates[0].dropped, ['gfm/grid-forming-inverter.md'])
  const r = await searchIndex(built.db, { term: 'grid-forming inverter', limit: 5 })
  assert.equal(r.hits.filter((h) => h.document.doi === '10.1109/tpwrs.2024.0001').length, 1, '同一条论文不得重复返回')
})

test('index: 三条同 id 卡片只留一张，丢弃关系全部记录在案', async () => {
  const base = { ok: true, topic: 't', slug: 'x', card: CARD_A, content: '' }
  const built = await buildIndex([
    { ...base, rel: 'a/x.md' },
    { ...base, rel: 'b/x.md', card: { ...CARD_A, '读数（0-5）': 3 } },
    { ...base, rel: 'c/x.md', card: { ...CARD_A, '读数（0-5）': 4 } },
  ])
  assert.equal(built.docs.length, 1)
  assert.equal(built.docs[0].rel, 'c/x.md', '读数最高的胜出')
  assert.equal(built.manifest.duplicateCount, 1)
  assert.deepEqual(built.duplicates[0].dropped.sort(), ['a/x.md', 'b/x.md'])
})

test('index: loadOrRebuild 第一次重建、第二次直接读盘', async () => {
  const index = makeMemoryScope('index')
  const first = await loadOrRebuild(index, [ENTRY_A, ENTRY_B])
  assert.equal(first.rebuilt, true)
  assert.match(first.reason, /E_INDEX_ABSENT/)
  const second = await loadOrRebuild(index, [ENTRY_A, ENTRY_B])
  assert.equal(second.rebuilt, false)
  assert.equal(second.reason, null)
  assert.equal(second.manifest.count, 2)
})

test('index: schema 版本不符或文件损坏时返回 null 并给出原因（不抛）', async () => {
  const index = makeMemoryScope('index')
  await persistIndex(index, await buildIndex([ENTRY_A]))
  // 篡改 schema 版本
  const manifest = index.readJson(INDEX_MANIFEST_FILENAME)
  index.writeJson(INDEX_MANIFEST_FILENAME, { ...manifest, schemaVersion: 999 })
  const r1 = await readIndex(index)
  assert.equal(r1.db, null)
  assert.match(r1.reason, /E_INDEX_SCHEMA_MISMATCH/)
  // 损坏的 JSON
  index.write(INDEX_FILENAME, 'this is not json {{{')
  const r2 = await readIndex(index)
  assert.equal(r2.db, null)
  assert.match(r2.reason, /E_INDEX_UNREADABLE/)
  // 缺文件
  const fresh = makeMemoryScope('index')
  const r3 = await readIndex(fresh)
  assert.equal(r3.reason, 'E_INDEX_ABSENT')

  // 而且 loadOrRebuild 必须能自愈
  index.writeJson(INDEX_MANIFEST_FILENAME, { ...manifest, schemaVersion: 999 })
  const healed = await loadOrRebuild(index, [ENTRY_A, ENTRY_B])
  assert.equal(healed.rebuilt, true)
  assert.equal(healed.manifest.count, 2)
})

test('index: rebuildIndex 落盘并返回 manifest', async () => {
  const index = makeMemoryScope('index')
  const r = await rebuildIndex(index, [ENTRY_A])
  assert.equal(r.rebuilt, true)
  assert.equal(r.manifest.count, 1)
  assert.ok(index.exists(INDEX_FILENAME))
})

// ---------------------------------------------------------------------------
// 检索
// ---------------------------------------------------------------------------

test('index: fulltext 与 hybrid 都能召回；空查询不炸', async () => {
  const index = makeMemoryScope('index')
  const { db } = await buildIndex([ENTRY_A, ENTRY_B])
  const ft = await searchIndex(db, { term: 'islanding', mode: 'fulltext', limit: 5 })
  assert.equal(ft.mode, 'fulltext')
  assert.equal(ft.hits[0].document.doi, '10.1016/j.epsr.2019.0002')
  const hy = await searchIndex(db, { term: 'inertia support', mode: 'hybrid', limit: 5 })
  assert.equal(hy.mode, 'hybrid')
  assert.ok(hy.hits.length >= 1)
  const empty = await searchIndex(db, { term: '   ', limit: 5 })
  assert.equal(empty.mode, 'empty')
  assert.deepEqual(empty.hits, [])
  const none = await searchIndex(db, { term: 'zzzzznotpresentzzzzz', limit: 5 })
  assert.deepEqual(none.hits, [])
})

test('index: 向量一路失效时自动降级为 fulltext（检索整体不报废）', async () => {
  const index = makeMemoryScope('index')
  const { db } = await buildIndex([ENTRY_A, ENTRY_B])
  // 把向量查询打坏：注入一个 search 会抛的假 orama
  const brokenLoader = async () => ({
    search: async (_db, params) => {
      if (params.mode === 'hybrid') throw new Error('vector dimension mismatch')
      return { hits: [{ id: 'x', score: 1, document: { doi: 'fallback' } }] }
    },
  })
  const r = await searchIndex(db, { term: 'inertia', mode: 'hybrid', limit: 3, loader: brokenLoader })
  assert.equal(r.mode, 'fulltext')
  assert.equal(r.degradedFrom, 'hybrid')
  assert.match(r.reason, /vector dimension/)
  assert.equal(r.hits[0].document.doi, 'fallback')
})

test('index: 中文查询在英文卡片上零命中（这就是 /recall 需要检索式扩展的原因）', async () => {
  const index = makeMemoryScope('index')
  const { db } = await buildIndex([ENTRY_A, ENTRY_B])
  const zh = await searchIndex(db, { term: '构网型逆变器的惯量支撑', limit: 5 })
  assert.equal(zh.hits.length, 0, '纯中文查询与英文词根不相交 —— 这是已知且被测钉住的行为')
  const en = await searchIndex(db, { term: 'grid-forming inverter inertia support', limit: 5 })
  assert.ok(en.hits.length >= 1, '英文检索式必须能命中')
})
