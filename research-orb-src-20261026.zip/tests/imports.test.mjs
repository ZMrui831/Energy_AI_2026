// tests/imports.test.mjs —— 长期钉：任何相对 import 写错都必须让测试失败
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { checkImports } from '../tools/check-imports.mjs'

test('全部相对 import 路径可解析（防止 ERR_MODULE_NOT_FOUND 进交付）', () => {
  const { scanned, failures } = checkImports()
  assert.ok(scanned > 40, '扫描文件数异常（' + scanned + '）')
  assert.deepEqual(failures, [], '存在无法解析的相对 import：' + JSON.stringify(failures, null, 2))
})