// tests/plugins.test.mjs
//
// 插件宿主回归：manifest 校验、扫描/启用/禁用/列出、命令执行、
// 私有 fs 夹逼（data\notes\<id>\ 之外一律拒绝）、审计落盘。
// 用仓库里真实存在的 hello 插件当被测对象 —— 这正是它存在的意义。

import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

import { createRegistry, normalizeManifest, pluginDataPath, PLUGIN_LOG, NOTES_DIR, PluginError } from '../packages/plugins/index.mjs'
import { createProviders } from '../packages/core/src/providers/index.mjs'
import { createNet } from '../packages/core/src/net.mjs'
import { PROJECT_ROOT, logPath, dataPath } from '../packages/core/src/safefs.mjs'

const TEST_NET_LOG = logPath('test-plugins-net.jsonl')

function makeRegistry({ withNet = true } = {}) {
  const net = withNet
    ? createNet({ fetchImpl: async () => new Response('{}', { status: 200 }), logFile: TEST_NET_LOG })
    : null
  const providers = withNet ? createProviders({ net }) : null
  return createRegistry({ core: { net, providers } })
}

const readAudit = () =>
  existsSync(PLUGIN_LOG)
    ? readFileSync(PLUGIN_LOG, 'utf8')
        .split('\n')
        .filter((l) => l.trim())
        .map((l) => JSON.parse(l))
    : []

// ---------------------------------------------------------------------------
// manifest
// ---------------------------------------------------------------------------

test('normalizeManifest 补齐缺省字段并校验 id / entry', () => {
  const m = normalizeManifest({ id: 'x.y', name: 'X' })
  assert.equal(m.version, '0.0.0')
  assert.equal(m.entry, 'index.mjs')
  assert.deepEqual(m.capabilities, [])
  assert.deepEqual(m.permissions, [])

  assert.throws(() => normalizeManifest({ id: '../evil' }), (e) => e.code === 'E_BAD_PLUGIN_ID')
  assert.throws(() => normalizeManifest({ id: 'ok', entry: '../../x.mjs' }), (e) => e.code === 'E_BAD_ENTRY')
  assert.throws(() => normalizeManifest({ id: 'ok', entry: 'C:\\x.mjs' }), (e) => e.code === 'E_BAD_ENTRY')
  assert.throws(() => normalizeManifest(null), (e) => e.code === 'E_BAD_MANIFEST')
})

test('pluginDataPath 夹在 data/notes/<id>/ 之内，穿越一律拒绝', () => {
  const ok = pluginDataPath('hello', 'sub/a.md')
  assert.ok(ok.toLowerCase().startsWith(join(NOTES_DIR, 'hello').toLowerCase()))
  // S34·P0 几何：DATA_DIR 隔离后 '../../../' 已越出整个数据根 → 宿主门（E_OUTSIDE_ROOT）；
  // 越出私目录但仍在数据根内 → 插件门（E_PLUGIN_FS_OUTSIDE）。两道门都算拒。
  assert.throws(() => pluginDataPath('hello', '../../../escape.md'), (e) => e instanceof PluginError || (e && (e.code === 'E_OUTSIDE_ROOT' || e.code === 'E_PLUGIN_FS_OUTSIDE')))
  assert.throws(() => pluginDataPath('hello', '../../escape.md'), (e) => e.code === 'E_PLUGIN_FS_OUTSIDE')
  assert.throws(() => pluginDataPath('bad id', 'x'), (e) => e.code === 'E_BAD_PLUGIN_ID')
})

// ---------------------------------------------------------------------------
// 扫描 / 启用 / 列出
// ---------------------------------------------------------------------------

test('registry: 扫到 hello，且未启用时不加载代码', () => {
  const reg = makeRegistry()
  const found = reg.scan()
  assert.ok(found.includes('hello'), JSON.stringify(found))
  const row = reg.get('hello')
  assert.equal(row.enabled, false)
  // P-R6.1 版本收敛：hello 也派生自 package.json（不再硬编码 0.1.0）
  assert.match(row.version, /^(\d+)(\.\d+){2}/)
  assert.equal(row.version, JSON.parse(readFileSync(join(PROJECT_ROOT, "package.json"), "utf8")).version)
  assert.ok(row.capabilities.includes('ui.card'))
  assert.ok(row.permissions.includes('fs:notes'))
  assert.ok(row.entry.endsWith('.mjs'))
})

test('registry: enable 调 activate(ctx)，卡片与命令被登记', async () => {
  const reg = makeRegistry()
  const r = await reg.enable('hello')
  assert.equal(r.enabled, true)
  assert.equal(r.cards, 1)
  assert.equal(r.commands, 2)

  const cards = reg.cards()
  assert.equal(cards.length, 1)
  assert.equal(cards[0].id, 'hello.status')
  assert.equal(cards[0].pluginId, 'hello')

  const cmds = reg.commands()
  assert.deepEqual(cmds.map((c) => c.name).sort(), ['hello', 'hello.selfcheck'])
  assert.ok(!('run' in cmds[0]), '命令表不得把 run 函数泄漏给界面')

  const row = reg.list().find((p) => p.id === 'hello')
  assert.equal(row.enabled, true)
  assert.equal(row.error, null)
})

test('registry: 命令可执行；未知命令返回 E_NO_COMMAND', async () => {
  const reg = makeRegistry()
  await reg.enable('hello')
  const r = await reg.runCommand('/hello', '世界')
  assert.equal(r.ok, true)
  assert.match(r.value.text, /Hello, 世界!/)

  const bad = await reg.runCommand('does-not-exist')
  assert.equal(bad.ok, false)
  assert.equal(bad.error, 'E_NO_COMMAND')
})

test('registry: 插件自证沙箱有效 —— 越界写入被宿主拦下', async () => {
  const reg = makeRegistry()
  await reg.enable('hello')
  const r = await reg.runCommand('hello.selfcheck')
  assert.equal(r.ok, true)
  assert.match(r.value.text, /沙箱拦截越界写入：OK/)
  assert.ok(r.value.notesRoot.toLowerCase().startsWith(join(NOTES_DIR, 'hello').toLowerCase()))
  assert.equal(r.value.netAvailable, true)
  assert.ok(r.value.allowedDomains >= 7)
})

test('registry: 私有笔记与 state 落在 data/notes/hello 内', async () => {
  const reg = makeRegistry()
  await reg.enable('hello')
  assert.ok(existsSync(join(NOTES_DIR, 'hello', 'hello.md')))
  assert.ok(existsSync(join(NOTES_DIR, 'hello', 'state.json')))
  const state = JSON.parse(readFileSync(join(NOTES_DIR, 'hello', 'state.json'), 'utf8'))
  assert.ok(Number(state.activations) >= 1)
})

test('registry: disable 收回注册项，重复 enable 不叠加', async () => {
  const reg = makeRegistry()
  await reg.enable('hello')
  await reg.disable('hello')
  assert.equal(reg.get('hello').enabled, false)
  assert.equal(reg.cards().length, 0)
  assert.equal(reg.commands().length, 0)
  assert.equal((await reg.runCommand('hello')).error, 'E_NO_COMMAND')

  await reg.enable('hello')
  await reg.enable('hello')
  assert.equal(reg.cards().length, 1, '重复启用不得叠加卡片')
  assert.equal(reg.commands().length, 2)
})

test('registry: 未启用时 cards/commands 为空，enableAll/disposeAll 成对工作', async () => {
  const reg = makeRegistry()
  reg.scan()
  assert.equal(reg.cards().length, 0)
  const enabled = await reg.enableAll()
  assert.ok(enabled.some((e) => e.id === 'hello' && e.enabled))
  // 阶段 2 起仓库里不止 hello 一个插件，所以"卡片总数"这类全仓库聚合断言
  // 收敛成按 pluginId 断言 —— 强度没降（还是钉死 hello 恰好注册 1 张卡），
  // 只是不再假设"全仓库只有 hello"。
  assert.equal(reg.cards().filter((c) => c.pluginId === 'hello').length, 1)
  assert.equal(reg.commands().filter((c) => c.pluginId === 'hello').length, 2)
  await reg.disposeAll()
  assert.equal(reg.cards().filter((c) => c.pluginId === 'hello').length, 0)
  assert.equal(reg.get('hello').enabled, false)
})

test('registry: enable 未知插件抛 E_NO_PLUGIN', async () => {
  const reg = makeRegistry()
  await assert.rejects(() => reg.enable('nope'), (e) => e.code === 'E_NO_PLUGIN')
})

test('registry: 无 net 时插件拿到的是"不可用"占位，而不是全局 fetch', () => {
  const reg = makeRegistry({ withNet: false })
  reg.scan()
  // 通过 hello 的自检命令间接验证：netAvailable 必须是 false
  return reg.enable('hello').then(async () => {
    const r = await reg.runCommand('hello.selfcheck')
    assert.equal(r.value.netAvailable, false)
    assert.deepEqual(r.value.allowedDomains, 0)
  })
})

// ---------------------------------------------------------------------------
// 审计
// ---------------------------------------------------------------------------

test('registry: 插件动作写 data/logs/plugins.jsonl 审计（带 pluginId）', async () => {
  const before = readAudit().length
  const reg = makeRegistry()
  // 只启用 hello：审计断言要钉在"哪个插件写了哪一行"上，
  // 用 enableAll 会把 research-literature / research-timer 的行也混进来（阶段 2 起仓库有多个插件）。
  await reg.enable('hello')
  await reg.runCommand('hello', 'audit')
  await reg.disable('hello')
  const after = readAudit()
  assert.ok(after.length > before, '必须有新审计行')
  const sliced = after.slice(before)
  assert.ok(sliced.length > 0)
  // 红线不变且更强：审计日志是跨测试文件共享的全局状态（npm test 已串行化，
  // 但万一有外部写入混入），每一行都必须带非空 pluginId —— 这条纪律本身不被并行性稀释。
  assert.ok(
    sliced.every((e) => typeof e.pluginId === 'string' && e.pluginId.length > 0),
    '每条审计都必须带 pluginId',
  )
  const mine = sliced.filter((e) => e.pluginId === 'hello')
  assert.ok(mine.some((e) => e.event === 'enable'))
  assert.ok(mine.some((e) => e.event === 'ui.card'))
  assert.ok(mine.some((e) => e.event === 'ui.command'))
  assert.ok(mine.some((e) => e.event === 'command.run'))
  assert.ok(mine.some((e) => e.event === 'disable'))
  assert.ok(mine.some((e) => e.event === 'fs.write'))
})

test('registry: 阶段 2 新增的 research-literature 插件声明的作用域与命令齐备', async () => {
  const reg = makeRegistry()
  reg.scan()
  const row = reg.get('research-literature')
  assert.ok(row, '应扫到 research-literature 插件')
  assert.deepEqual(row.scopes, ['exports', 'index', 'notes', 'pdf'])
  assert.deepEqual(row.commands, [], '未启用前不该登记任何命令')
  assert.equal(row.cards, 0, '未启用时不得有卡片')

  const r = await reg.enable('research-literature')
  assert.equal(r.enabled, true, `启用失败：${r.error}`)
  assert.equal(r.cards, 1)
  // 6 条对外命令 + card.update（面板卡片编辑弹层的写回通道，不经文件系统直改）
  assert.equal(r.commands, 7)
  assert.deepEqual(reg.get('research-literature').commands.sort(), ['bib', 'card', 'card.update', 'find', 'note', 'recall', 'verify'])
  assert.equal(reg.cards().find((c) => c.pluginId === 'research-literature').title, '文献')
  // 命令名不得撞车，且 run 不得泄漏给界面
  for (const c of reg.commands()) assert.ok(!('run' in c))
  await reg.disable('research-literature')
  assert.equal(reg.get('research-literature').enabled, false)
})

test('registry: 作用域门禁在真宿主上生效（未声明拒、外插件私有目录拒、越界拒）', async () => {
  const { scopeDataPath, scopeRoot, PluginError: PE, DATA_SCOPE_NAMES } = await import('../packages/plugins/index.mjs')
  // 路径数学：作用域内可通过；跨作用域但仍落在项目根内 → E_PLUGIN_FS_OUTSIDE；
  // 直接跳出项目根 → 先被 safefs 拦成 E_OUTSIDE_ROOT。两道门都要在。
  assert.ok(scopeDataPath('research-literature', 'pdf', 'a/b.json').toLowerCase().startsWith(dataPath('pdf').toLowerCase()))
  assert.throws(() => scopeDataPath('research-literature', 'pdf', '../notes/hijack.md'), (e) => e.code === 'E_PLUGIN_FS_OUTSIDE')
  assert.throws(() => scopeDataPath('research-literature', 'pdf', '../../../evil.json'), (e) => e.code === 'E_OUTSIDE_ROOT')
  assert.throws(() => scopeDataPath('research-literature', 'nope', 'a.json'), (e) => e.code === 'E_SCOPE_UNKNOWN')
  assert.throws(() => scopeRoot('nope'), (e) => e instanceof PE)
  assert.deepEqual([...DATA_SCOPE_NAMES], ['notes', 'pdf', 'index', 'exports', 'fixtures', 'packs'])

  const reg = makeRegistry()
  const r = await reg.enable('research-literature')
  assert.equal(r.enabled, true, `启用失败：${r.error}`)
  const handle = reg._records.get('research-literature').instance
  assert.ok(handle && handle.ctx, 'activate 应把 ctx 交回宿主以便核对能力面')

  // 1) 声明过的四个作用域可用
  for (const s of ['notes', 'pdf', 'index', 'exports']) assert.equal(handle.ctx.fs.scope(s).name, s)
  // 2) 未声明的作用域被拒（fixtures 在宿主白名单里，但本插件没声明）
  assert.throws(() => handle.ctx.fs.scope('fixtures'), (e) => e.code === 'E_SCOPE_NOT_GRANTED')
  // 3) 不认识的作用域名被拒
  assert.throws(() => handle.ctx.fs.scope('whatever'), (e) => e.code === 'E_SCOPE_UNKNOWN')
  // 4) notes 作用域不许写进别的插件的私有抽屉
  assert.throws(() => handle.ctx.fs.scope('notes').write('hello/hijack.md', 'x'), (e) => e.code === 'E_SCOPE_FOREIGN_NOTES')
  // 5) 私有抽屉的越界仍然被拦（阶段 1 行为不变）
  assert.throws(() => handle.ctx.fs.write('../../../escape.md', 'x'), (e) => e.code === 'E_PLUGIN_FS_OUTSIDE' || e.code === 'E_OUTSIDE_ROOT')
  assert.equal(reg._records.get('hello').manifest.scopes.length, 0, 'hello 不该凭空获得作用域')
  await reg.disable('research-literature')
})
