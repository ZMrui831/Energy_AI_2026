// tests/connectors.test.mjs
//
// 四个连接器 + 聚合层的离线测试。
// 全部用注入的桩 net，**不发任何真实请求** —— 网络层的域名白名单/令牌桶/退避
// 由 tests/net.test.mjs 与 tests/ratelimit.test.mjs 单独钉，这里只验连接器自己的逻辑。

import test from 'node:test'
import assert from 'node:assert/strict'

import {
  ARXIV_CATEGORIES,
  ARXIV_ENDPOINT,
  ARXIV_LIMIT_KEY,
  buildArxivQuery,
  buildArxivUrl,
  mapArxivEntry,
  parseArxivFeed,
  searchArxiv,
  searchArxivWithFallback,
} from '../packages/plugins/research-literature/connectors/arxiv.mjs'
import {
  OPENALEX_LIMIT_KEY,
  buildOpenAlexUrl,
  fetchOpenAlexByDoi,
  invertAbstract,
  mapOpenAlexWork,
  searchOpenAlex,
} from '../packages/plugins/research-literature/connectors/openalex.mjs'
import {
  CROSSREF_LIMIT_KEY,
  buildCrossrefUrl,
  fetchCrossrefByDoi,
  mapCrossrefItem,
  searchCrossref,
  stripJats,
} from '../packages/plugins/research-literature/connectors/crossref.mjs'
import {
  S2_LIMIT_KEY,
  buildS2Url,
  hasApiKey,
  mapS2Paper,
  searchSemanticScholar,
} from '../packages/plugins/research-literature/connectors/semanticscholar.mjs'
import { SEARCH_SOURCES, lookupRecordByDoi, searchAll } from '../packages/plugins/research-literature/connectors/index.mjs'
import { REQUIRED_FIELDS, dedupeRecords, rankRecords, scoreRecord, venueTier } from '../packages/plugins/research-literature/lib/record.mjs'
import { ConnectorError, NET_RETRY_ATTEMPTS, NET_RETRY_DELAY_MS, requestText } from '../packages/plugins/research-literature/lib/http.mjs'
import { decodeXmlEntities, firstTagText, splitBlocks, tagAttr } from '../packages/plugins/research-literature/lib/xml.mjs'
import {
  STUB_ALLOWED_DOMAINS,
  arxivFeedXml,
  crossrefPayload,
  fixtureDoi,
  makeStubNet,
  openAlexPayload,
  s2Payload,
} from './helpers/research-fixtures.mjs'

// ---------------------------------------------------------------------------
// XML 小工具
// ---------------------------------------------------------------------------

test('xml: 实体解码 / 标签文本 / 属性 / 分块', () => {
  assert.equal(decodeXmlEntities('A &amp; B &lt;x&gt; &#65; &#x42;'), 'A & B <x> A B')
  assert.equal(firstTagText('<a><b>  hello   world </b></a>', 'b'), 'hello world')
  assert.equal(firstTagText('<a><ns:b>x</ns:b></a>', 'b'), 'x')
  assert.equal(firstTagText('<a></a>', 'missing'), null)
  assert.equal(tagAttr('<link title="pdf" href="http://x/y.pdf"/>', 'link', 'href'), 'http://x/y.pdf')
  assert.equal(tagAttr('<link rel="alternate" href="a"/><link title="pdf" href="b"/>', 'link', 'href', { where: /title\s*=\s*"pdf"/i }), 'b')
  assert.equal(splitBlocks('<r><e>1</e><e>2</e></r>', 'e').length, 2)
})

// ---------------------------------------------------------------------------
// arXiv
// ---------------------------------------------------------------------------

test('arxiv: 检索式含整句短语 + 二元短语 + 全词 AND + 分类过滤', () => {
  const q = buildArxivQuery({ text: 'grid-forming inverter inertia support', categories: ARXIV_CATEGORIES })
  assert.match(q, /all:"grid-forming inverter inertia support"/)
  assert.match(q, /all:"grid-forming inverter"/)
  assert.match(q, /all:grid-forming AND all:inverter AND all:inertia AND all:support/)
  for (const c of ARXIV_CATEGORIES) assert.ok(q.includes(`cat:${c}`), `缺少分类 ${c}`)
  assert.ok(!/cat:/.test(buildArxivQuery({ text: 'gfm', categories: [] })), '不给分类时不应出现 cat: 过滤')
  assert.throws(() => buildArxivQuery({ text: '   ' }), (e) => e.code === 'E_EMPTY_QUERY')
})

test('arxiv: URL 指向 export.arxiv.org 且参数被正确编码', () => {
  const url = buildArxivUrl({ text: 'grid-forming inverter', categories: ['eess.SY'], max: 20 })
  assert.ok(url.startsWith(`${ARXIV_ENDPOINT}?`))
  assert.ok(url.includes('search_query='))
  assert.ok(url.includes('max_results=20'))
  assert.ok(url.includes('sortBy=relevance'))
  assert.ok(!url.includes(' '), 'URL 里不应出现未编码空格')
  assert.ok(url.includes('%22'), '双引号应被编码')
})

test('arxiv: Atom 解析与统一记录映射', () => {
  const feed = parseArxivFeed(arxivFeedXml(8))
  assert.equal(feed.entries.length, 8)
  assert.equal(feed.total, 104)
  assert.equal(feed.entries[0].authors.length, 2)
  assert.equal(feed.entries[0].primaryCategory, 'eess.SY')
  assert.ok(feed.entries[0].pdfHref.endsWith('v2'))
  assert.ok(feed.entries[0].absHref.includes('arxiv.org/abs/'))

  const rec = mapArxivEntry(feed.entries[1])
  for (const f of REQUIRED_FIELDS) assert.ok(f in rec, `统一记录缺少 ${f}`)
  assert.equal(rec.source, 'arxiv')
  assert.equal(rec.citations, null, 'arXiv 不提供引用数，必须是 null 而不是 0')
  assert.equal(rec.openAccess, true)
  assert.equal(rec.year, 2024)
  assert.match(rec.title, /Virtual Synchronous Generator/)
  assert.ok(Array.isArray(rec.authors) && rec.authors.length === 2)
  assert.match(rec.venue, /IEEE Trans\. Power Syst\./, 'journal_ref 应成为 venue')
  // 夹具里第 5 条（索引 4）没有 <arxiv:doi> → DOI 必须是 null 而不是空串
  assert.equal(mapArxivEntry(feed.entries[4]).doi, null)
  assert.equal(mapArxivEntry(feed.entries[0]).doi, fixtureDoi(0).toLowerCase())
  assert.equal(mapArxivEntry(feed.entries[0]).venue, 'arXiv:eess.SY', '无 journal_ref 时 venue 退回分类')
})

test('arxiv: 出网只经 net，且 limitKey 固定为 research-literature:arxiv', async () => {
  const net = makeStubNet()
  const r = await searchArxiv({ net, query: 'grid-forming inverter inertia support' })
  assert.equal(net.calls.length, 1)
  assert.equal(net.calls[0].host, 'export.arxiv.org')
  assert.equal(net.calls[0].limitKey, ARXIV_LIMIT_KEY)
  assert.equal(r.records.length, 8)
  assert.equal(r.entries, 8)
})

test('arxiv: 分类过滤命中不足时回退到全站，并标记 usedFallback', async () => {
  // 第一次（带分类）返回空 feed，第二次（无分类）返回 8 条
  const emptyFeed = '<?xml version="1.0"?><feed xmlns="http://www.w3.org/2005/Atom"><opensearch:totalResults xmlns:opensearch="http://a9.com/-/spec/opensearch/1.1/">0</opensearch:totalResults></feed>'
  let n = 0
  const net = {
    calls: [],
    hostOf: () => 'export.arxiv.org',
    isAllowedUrl: () => true,
    async request(url, options) {
      net.calls.push({ url, limitKey: options.limitKey })
      n += 1
      return new Response(n === 1 ? emptyFeed : arxivFeedXml(6), { status: 200 })
    },
  }
  const r = await searchArxivWithFallback({ net, query: 'grid-forming inverter', minResults: 5 })
  assert.equal(net.calls.length, 2, '应发两次请求')
  assert.equal(r.usedFallback, true)
  assert.equal(r.records.length, 6)
  assert.ok(!net.calls[1].url.includes('cat%3A'), '第二次请求不应带分类')
})

// ---------------------------------------------------------------------------
// OpenAlex
// ---------------------------------------------------------------------------

test('openalex: mailto 为空则 URL 里不出现该参数，非空才带上', () => {
  const without = buildOpenAlexUrl({ text: 'gfm', mailto: '', perPage: 10 })
  assert.ok(!without.includes('mailto'), '空 mailto 绝不能出现在 URL 里')
  assert.ok(!without.includes('@'), '不得臆造邮箱')
  const withMail = buildOpenAlexUrl({ text: 'gfm', mailto: 'someone@example.org' })
  assert.ok(withMail.includes('mailto=someone%40example.org'))
  const bad = buildOpenAlexUrl({ text: 'gfm', mailto: 'not-an-email' })
  assert.ok(!bad.includes('mailto'), '非法邮箱同样不加')
})

test('openalex: abstract_inverted_index 还原（词序必须对）', () => {
  const inverted = { Grid: [0], forming: [1], inverter: [2], inertia: [3], support: [4] }
  assert.equal(invertAbstract(inverted), 'Grid forming inverter inertia support')
  assert.equal(invertAbstract({ b: [1], a: [0], c: [2] }), 'a b c', '必须按词位排序而不是按键序')
  assert.equal(invertAbstract(null), '')
  assert.equal(invertAbstract({ broken: 'nope' }), '')
  assert.equal(invertAbstract({}), '')
})

test('openalex: 映射与检索（摘要来自 inverted index，OA 链接被保留）', async () => {
  const payload = openAlexPayload(4)
  const rec = mapOpenAlexWork(payload.results[0])
  for (const f of REQUIRED_FIELDS) assert.ok(f in rec, `缺少 ${f}`)
  assert.equal(rec.source, 'openalex')
  assert.equal(rec.doi, fixtureDoi(0).toLowerCase(), 'DOI 必须去掉 https://doi.org/ 前缀并小写')
  assert.equal(rec.abstract, payload.results[0].title)
  assert.equal(rec.citations, 12)
  assert.equal(rec.openAccess, true)
  assert.ok(rec.pdfUrl.includes('example.invalid'))

  const net = makeStubNet({ openalex: payload })
  const r = await searchOpenAlex({ net, query: 'gfm', mailto: null, max: 4 })
  assert.equal(r.entries, 4)
  assert.equal(r.mailtoUsed, false)
  assert.equal(net.calls[0].limitKey, OPENALEX_LIMIT_KEY)
  assert.equal(net.calls[0].host, 'api.openalex.org')
})

test('openalex: 按 DOI 单篇查询，DOI 里的斜杠不被编码', async () => {
  const net = makeStubNet({ openalex: openAlexPayload(1).results[0] })
  const r = await fetchOpenAlexByDoi({ net, doi: '10.1109/TPWRS.2024.1234567' })
  assert.ok(net.calls[0].url.includes('/works/https://doi.org/10.1109/TPWRS.2024.1234567'))
  assert.equal(r.record.source, 'openalex')
})

// ---------------------------------------------------------------------------
// Crossref
// ---------------------------------------------------------------------------

test('crossref: JATS 摘要剥标签，select 字段收敛', () => {
  assert.equal(stripJats('<jats:p>Hello <b>world</b>&amp;more</jats:p>'), 'Hello world &more')
  const url = buildCrossrefUrl({ text: 'gfm', rows: 5 })
  assert.ok(url.includes('select=DOI%2Ctitle'))
  assert.ok(url.includes('rows=5'))
  assert.ok(!url.includes('mailto'))
})

test('crossref: 映射与检索', async () => {
  const payload = crossrefPayload(5)
  const rec = mapCrossrefItem(payload.message.items[0])
  for (const f of REQUIRED_FIELDS) assert.ok(f in rec, `缺少 ${f}`)
  assert.equal(rec.source, 'crossref')
  assert.equal(rec.year, 2019)
  assert.deepEqual(rec.authors, ['Wei Wang', 'Maria Rossi'])
  assert.equal(rec.abstract, 'Grid-forming inverter inertia support with virtual inertia control.')
  const net = makeStubNet({ crossref: payload })
  const r = await searchCrossref({ net, query: 'gfm', max: 5 })
  assert.equal(r.entries, 5)
  assert.equal(net.calls[0].limitKey, CROSSREF_LIMIT_KEY)
})

test('crossref: 按 DOI 单篇查询', async () => {
  const net = makeStubNet({ crossref: { message: crossrefPayload(1).message.items[0] } })
  const r = await fetchCrossrefByDoi({ net, doi: 'https://doi.org/10.1109/TPWRS.2024.1' })
  assert.ok(net.calls[0].url.includes('/works/10.1109/TPWRS.2024.1'))
  assert.equal(r.record.source, 'crossref')
})

// ---------------------------------------------------------------------------
// Semantic Scholar（有 key 才用）
// ---------------------------------------------------------------------------

test('s2: 无 key 时一个请求都不发（不是发了被拒）', async () => {
  const net = makeStubNet()
  const r = await searchSemanticScholar({ net, query: 'gfm', apiKey: '' })
  assert.equal(net.calls.length, 0, '无 key 必须零请求')
  assert.equal(r.skipped, true)
  assert.equal(r.reason, 'E_NO_KEY')
  assert.deepEqual(r.records, [])
  assert.equal(hasApiKey('   '), false)
  assert.equal(hasApiKey('abc'), true)
})

test('s2: 有 key 时挂 x-api-key 头并取 TLDR', async () => {
  const net = makeStubNet()
  const r = await searchSemanticScholar({ net, query: 'gfm', apiKey: 'SECRET-123456', max: 6 })
  assert.equal(net.calls.length, 1)
  assert.equal(net.calls[0].host, 'api.semanticscholar.org')
  assert.equal(net.calls[0].limitKey, S2_LIMIT_KEY)
  assert.equal(net.calls[0].headers['x-api-key'], 'SECRET-123456')
  assert.equal(r.skipped, false)
  assert.equal(r.entries, 6)
  assert.match(r.records[0].tldr, /virtual inertia/)
  // 密钥绝不能出现在 URL 里
  assert.ok(!net.calls[0].url.includes('SECRET-123456'))
})

test('s2: 映射统一记录（tldr 兜底为摘要，externalIds.DOI 归一）', () => {
  const rec = mapS2Paper(s2Payload(1).data[0])
  for (const f of REQUIRED_FIELDS) assert.ok(f in rec, `缺少 ${f}`)
  assert.equal(rec.source, 'semanticscholar')
  assert.equal(rec.doi, fixtureDoi(0).toLowerCase())
  assert.ok(rec.tldr)
  const noAbstract = mapS2Paper({ title: 'T', tldr: { text: 'TLDR only' } })
  assert.equal(noAbstract.abstract, 'TLDR only', '无摘要时用 TLDR 兜底')
  assert.equal(mapS2Paper({ title: 'T' }).abstract, '')
})

// ---------------------------------------------------------------------------
// 去重 / 打分
// ---------------------------------------------------------------------------

test('record: 去重按 DOI 优先、标题兜底，合并时保留更权威的 venue 与更长的摘要', () => {
  const a = mapOpenAlexWork(openAlexPayload(1).results[0])
  const b = mapCrossrefItem(crossrefPayload(1).message.items[0])
  const c = mapArxivEntry(parseArxivFeed(arxivFeedXml(1)).entries[0])
  const { records, duplicates } = dedupeRecords([a, b, c])
  assert.equal(records.length, 1)
  assert.equal(duplicates, 2)
  assert.deepEqual(records[0].sources.sort(), ['arxiv', 'crossref', 'openalex'])
  assert.ok(records[0].abstract.length > 0)

  const t1 = { title: 'A Study of X', doi: null, source: 'x', authors: [], sources: ['x'] }
  const t2 = { title: 'a  study of  x!', doi: null, source: 'y', authors: [], sources: ['y'] }
  assert.equal(dedupeRecords([t1, t2]).records.length, 1, '无 DOI 时按归一标题合并')
})

test('record: 优选期刊识别含 arXiv journal_ref 尾巴的形态', () => {
  assert.equal(venueTier('IEEE Transactions on Power Systems').tier, 'top')
  assert.equal(venueTier('IEEE Trans. Power Syst. 39 (2024) 1234-1245').tier, 'top')
  assert.equal(venueTier('IEEE Trans. Power Syst.').tier, 'top')
  assert.equal(venueTier('Applied Energy').venueKey, 'APPLIED-ENERGY')
  assert.equal(venueTier('Energy').venueKey, 'ENERGY')
  assert.equal(venueTier('Energy Conversion and Management').tier, 'other')
  assert.equal(venueTier('arXiv:2401.0101').tier, 'preprint')
  assert.equal(venueTier('').tier, 'none')
  assert.equal(venueTier('Some Random Workshop').tier, 'other')
})

test('record: 打分 = 0.5*venue + 0.3*时效 + 0.2*引用，且排序稳定', () => {
  const now = new Date('2026-01-01T00:00:00Z')
  const top = scoreRecord({ venue: 'IEEE Transactions on Power Systems', year: 2025, citations: 1000, venueTier: 'top' }, { now })
  const weak = scoreRecord({ venue: 'Nope', year: 2005, citations: 0, venueTier: 'other' }, { now })
  assert.ok(top.score > weak.score)
  assert.ok(top.score <= 1.0001 && top.score > 0.9)
  assert.ok(weak.score < 0.4)
  const parts = top.parts
  assert.ok(Math.abs(parts.venue + parts.recency + parts.citation - top.score) < 1e-3, '三项权重之和应近似等于总分')

  const ranked = rankRecords(
    [
      { title: 'B', venue: 'IEEE Transactions on Smart Grid', year: 2020, citations: 10, venueTier: 'top' },
      { title: 'A', venue: 'IEEE Transactions on Smart Grid', year: 2020, citations: 10, venueTier: 'top' },
    ],
    { now },
  )
  assert.deepEqual(ranked.map((r) => r.title), ['A', 'B'], '同分时必须按标题稳定排序')
})

// ---------------------------------------------------------------------------
// 聚合
// ---------------------------------------------------------------------------

test('searchAll: 四源并联、跨源去重、S2 无 key 跳过、候选数达标', async () => {
  const net = makeStubNet()
  const r = await searchAll({ net, query: 'grid-forming inverter inertia support', max: 8 })
  assert.equal(r.ok, true)
  assert.ok(r.candidates.length >= 5, `候选应 ≥5，实际 ${r.candidates.length}`)
  assert.equal(r.stats.sourcesAsked, 4)
  assert.equal(r.stats.sourcesOk, 3, 'arxiv/openalex/crossref 成功，S2 跳过')
  assert.ok(r.stats.duplicates > 0, '跨源同 DOI 应被合并')
  assert.ok(r.stats.enough)
  const s2 = r.sources.find((s) => s.source === 'semanticscholar')
  assert.equal(s2.skipped, true)
  // 只碰白名单域名
  for (const c of net.calls) assert.ok(STUB_ALLOWED_DOMAINS.includes(c.host), `越界域名 ${c.host}`)
  // 每个候选都满足统一记录契约
  for (const c of r.candidates) {
    for (const f of REQUIRED_FIELDS) assert.ok(f in c, `候选缺少 ${f}`)
    assert.ok(typeof c.score === 'number')
  }
  // 排序必须单调不增
  for (let i = 1; i < r.candidates.length; i += 1) {
    assert.ok(r.candidates[i - 1].score >= r.candidates[i].score, '候选必须按分数降序')
  }
})

test('searchAll: 单源失败不影响整体（部分成功即返回）', async () => {
  const net = makeStubNet({ status: { 'api.crossref.org': { status: 429, body: 'slow down' } } })
  const r = await searchAll({ net, query: 'grid-forming inverter', max: 6 })
  const crossref = r.sources.find((s) => s.source === 'crossref')
  assert.equal(crossref.ok, false)
  assert.equal(crossref.error.code, 'E_RATE_LIMITED')
  assert.ok(r.candidates.length > 0, '其余源的结果必须照常返回')
  assert.equal(r.ok, true)
})

test('searchAll: 非白名单域名会被 net 拒绝而非静默跳过', async () => {
  const net = makeStubNet()
  await assert.rejects(
    () => net.request('https://sci-hub.se/10.1109/x'),
    (e) => e.code === 'E_DOMAIN_NOT_ALLOWED',
  )
})

test('searchAll: 空检索词抛 E_EMPTY_QUERY；未知源被过滤掉', async () => {
  const net = makeStubNet()
  await assert.rejects(() => searchAll({ net, query: '   ' }), (e) => e.code === 'E_EMPTY_QUERY')
  const r = await searchAll({ net, query: 'gfm', sources: ['arxiv', 'not-a-source'], max: 4 })
  assert.equal(r.stats.sourcesAsked, 1)
  assert.ok(r.candidates.length > 0)
})

test('lookupRecordByDoi: OpenAlex 成功即返回；失败则退 Crossref', async () => {
  const ok = makeStubNet({ openalex: openAlexPayload(1).results[0] })
  const r1 = await lookupRecordByDoi({ net: ok, doi: fixtureDoi(1) })
  assert.equal(r1.ok, true)
  assert.equal(r1.via, 'openalex')
  assert.equal(r1.attempts.length, 1, '第一源成功就不该再打第二源')

  const net = makeStubNet({
    status: { 'api.openalex.org': { status: 404, body: '' } },
    crossref: { message: crossrefPayload(1).message.items[0] },
  })
  const r2 = await lookupRecordByDoi({ net, doi: fixtureDoi(1) })
  assert.equal(r2.ok, true)
  assert.equal(r2.via, 'crossref')
  assert.equal(r2.attempts.length, 2)
  assert.equal(r2.attempts[0].ok, false)
})

test('lookupRecordByDoi: 两源都失败时 ok=false 并带出两次失败原因', async () => {
  const net = makeStubNet({ status: { 'api.openalex.org': { status: 404, body: '' }, 'api.crossref.org': { status: 404, body: '' } } })
  const r = await lookupRecordByDoi({ net, doi: '10.9999/nope.1' })
  assert.equal(r.ok, false)
  assert.equal(r.record, null)
  assert.deepEqual(r.attempts.map((a) => a.ok), [false, false])
})

test('http: 非 2xx 抛类型化 ConnectorError，429 归类为 E_RATE_LIMITED', async () => {
  const net = makeStubNet({ status: { 'api.openalex.org': { status: 429, body: '' } } })
  await assert.rejects(
    () => searchOpenAlex({ net, query: 'gfm' }),
    (e) => e instanceof ConnectorError && e.code === 'E_RATE_LIMITED' && e.status === 429,
  )
  const net2 = makeStubNet({ status: { 'api.openalex.org': { status: 500, body: '' } } })
  await assert.rejects(() => searchOpenAlex({ net: net2, query: 'gfm' }), (e) => e.code === 'E_HTTP_500')
})

test('http: 网络层错误（E_NET）重试一次；策略拒绝与 HTTP 错误都不重试', async () => {
  // 1) E_NET → 重试一次，第二次成功
  const sleeps = []
  let calls = 0
  const flaky = {
    request: async () => {
      calls += 1
      if (calls === 1) {
        const e = new Error('boom')
        e.code = 'E_NET'
        throw e
      }
      return new Response(arxivFeedXml(3), { status: 200 })
    },
  }
  const ok = await requestText(flaky, 'https://export.arxiv.org/api/query', { sleep: async (ms) => sleeps.push(ms) })
  assert.equal(ok.attempts, 2)
  assert.equal(calls, 2)
  assert.deepEqual(sleeps, [NET_RETRY_DELAY_MS])

  // 2) 重试用完还是 E_NET → 如实抛出，且不会无限重试
  let hardCalls = 0
  const dead = {
    request: async () => {
      hardCalls += 1
      const e = new Error('still down')
      e.code = 'E_NET'
      throw e
    },
  }
  await assert.rejects(() => requestText(dead, 'https://api.openalex.org/works', { sleep: async () => {} }), (e) => e.code === 'E_NET')
  assert.equal(hardCalls, NET_RETRY_ATTEMPTS + 1)

  // 3) 域名不在白名单 → 绝不重试（策略拒绝不是网络抖动）
  let deniedCalls = 0
  const deny = {
    request: async () => {
      deniedCalls += 1
      const e = new Error('denied')
      e.code = 'E_DOMAIN_NOT_ALLOWED'
      throw e
    },
  }
  await assert.rejects(() => requestText(deny, 'https://sci-hub.se/x', { sleep: async () => {} }), (e) => e.code === 'E_DOMAIN_NOT_ALLOWED')
  assert.equal(deniedCalls, 1)

  // 4) HTTP 429 → 不重试（429 的退避已经在 core net 里做过了，连接器不该再叠一层）
  let rateCalls = 0
  const limited = {
    request: async () => {
      rateCalls += 1
      return new Response('slow down', { status: 429 })
    },
  }
  await assert.rejects(() => requestText(limited, 'https://api.crossref.org/works', { sleep: async () => {} }), (e) => e.code === 'E_RATE_LIMITED')
  assert.equal(rateCalls, 1)
})

test('http: 一次连接重置不会让 /find 变成 0 候选（桩 net 的首次调用全抛 E_NET）', async () => {
  const base = makeStubNet()
  let first = true
  const wrap = {
    ...base,
    request: async (url, options) => {
      if (first) {
        first = false
        const e = new Error('fetch failed')
        e.code = 'E_NET'
        throw e
      }
      return base.request(url, options)
    },
  }
  const r = await searchAll({ net: wrap, query: 'grid-forming inverter inertia support', max: 4 })
  assert.equal(r.ok, true, JSON.stringify(r.sources.map((s) => [s.source, s.ok])))
  assert.ok(r.candidates.length >= 5, `重试后应仍有候选，实际 ${r.candidates.length}`)
})

test('connectors: 无 net 时拒绝出网（不允许退回全局 fetch）', async () => {
  await assert.rejects(() => searchArxiv({ net: null, query: 'gfm' }), (e) => e.code === 'E_NO_NET')
  await assert.rejects(() => searchOpenAlex({ net: {}, query: 'gfm' }), (e) => e.code === 'E_NO_NET')
})

test('connectors: SEARCH_SOURCES 覆盖四个源，顺序即展示顺序', () => {
  assert.deepEqual([...SEARCH_SOURCES], ['arxiv', 'openalex', 'crossref', 'semanticscholar'])
})

test('sources: URL 构造函数对空检索给出一致结果（S2 有 query 字段）', () => {
  assert.ok(buildS2Url({ text: 'gfm', limit: 5 }).includes('fields=title%2Cabstract'))
})
