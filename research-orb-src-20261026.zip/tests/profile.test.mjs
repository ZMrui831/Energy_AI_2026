// tests/profile.test.mjs
import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  demoFields, buildDigest, estimateTokens, writeProfile, readProfile,
  resetProfile, ProfileError,
} from '../packages/plugins/profile/index.mjs'
import { readProfileSystemContext, composeSystemPrompt } from '../packages/core/src/profile-context.mjs'

test('demoFields 覆盖全部问卷维度', () => {
  const f = demoFields()
  for (const k of ['major', 'direction', 'stage', 'literatureTypes', 'goal', 'weeklyHours', 'language', 'reminderIntensity']) {
    assert.ok(k in f, '缺失字段 ' + k)
    assert.ok(f[k].length > 0, '字段 ' + k + ' 无默认值')
  }
  // 默认占位不含真实身份
  assert.equal(f.major, '计算机科学')
  assert.equal(f.direction, '信息检索')
})

test('buildDigest ≤300 token 且含专业维度', () => {
  const prof = writeProfile({ fields: demoFields(), personalization: true })
  const d = buildDigest(prof)
  assert.ok(estimateTokens(d) <= 300, 'digest 超 300 token: ' + estimateTokens(d))
  assert.match(d, /计算机科学/)
  resetProfile()
})

test('写画像时拒绝身份字段（E_IDENTITY_FIELD）', () => {
  assert.throws(() => writeProfile({ fields: { name: '张三', school: 'XX大学' } }), (e) => e instanceof ProfileError && e.code === 'E_IDENTITY_FIELD')
})

test('个性化开关控制 system 注入', () => {
  resetProfile()
  // 未填：不注入
  assert.equal(readProfileSystemContext(), '')
  assert.equal(composeSystemPrompt('DEF', readProfileSystemContext()), 'DEF')
  // 关：不注入
  writeProfile({ fields: demoFields(), personalization: false })
  assert.equal(readProfileSystemContext(), '')
  // 开：注入且含演示值
  writeProfile({ fields: demoFields(), personalization: true })
  const inj = readProfileSystemContext()
  assert.ok(inj.length > 0)
  assert.match(inj, /计算机科学/)
  resetProfile()
})

test('reset 后 profile.json 与 digest 均清空', () => {
  writeProfile({ fields: demoFields(), personalization: true })
  assert.ok(readProfile())
  resetProfile()
  assert.equal(readProfile(), null)
  assert.equal(readProfileSystemContext(), '')
})
