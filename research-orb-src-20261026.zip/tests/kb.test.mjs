// tests/kb.test.mjs —— S23·A 本地知识库：分词/分块/索引/检索/引用/移除/上限
// 纪律：临时库放 data/tmp 下（根内）；凡动 data/config.json（setMode）必须在 finally 复位。
import { test, beforeEach, afterEach } from 'node:test'
import assert from 'node:assert/strict'
import { mkdirSync, rmSync, writeFileSync, existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, logPath, dataPath } from '../packages/core/src/safefs.mjs'
import * as modes from '../packages/core/src/modes.mjs'
import { createKb, tokenize, chunkPageText, KB_BLOCK_CHARS, KB_OVERLAP_CHARS } from '../packages/plugins/kb/engine.mjs'

const ROOT = dataPath('tmp', 's23-kb-test')
let DIR
let n = 0

beforeEach(() => {
  n += 1
  DIR = `${ROOT}-${n}`
  rmSync(DIR, { recursive: true, force: true })
  mkdirSync(DIR, { recursive: true })
})

afterEach(() => {
  rmSync(DIR, { recursive: true, force: true })
})

test('kb: 分词 latin 词 + CJK 双字组', () => {
  const t = tokenize('HVDC 微电网控制')
  assert.ok(t.includes('hvdc'))
  assert.ok(t.includes('微电'), 'CJK bigram 微电')
  assert.ok(t.includes('电网'), 'CJK bigram 电网')
})

test('kb: 分块 800 字/块、重叠 80（长段落滑窗），短段落整块保留', () => {
  const longPara = 'x'.repeat(2000)
  const blocks = chunkPageText(longPara, 1, 0)
  assert.ok(blocks.length >= 3, `2000 字应切 ≥3 块，实际 ${blocks.length}`)
  for (const b of blocks) assert.ok(b.text.length <= KB_BLOCK_CHARS)
  // 相邻块重叠 80：前一块的尾巴 80 字应出现在后一块开头
  for (let i = 1; i < blocks.length; i++) {
    const tail = blocks[i - 1].text.slice(-KB_OVERLAP_CHARS)
    assert.ok(blocks[i].text.startsWith(tail), `块 ${i} 应与前块重叠 80 字`)
  }
  // 短段落：一个 100 字段落 → 1 块
  const one = chunkPageText('y'.repeat(100), 1, 0)
  assert.equal(one.length, 1)
  assert.equal(one[0].page, 1)
  // blockIndex 续号
  const cont = chunkPageText('z'.repeat(100), 2, 5)
  assert.equal(cont[0].blockIndex, 5)
})

async function seed(kb) {
  mkdirSync(join(DIR, 'notes'), { recursive: true })
  mkdirSync(join(DIR, 'papers'), { recursive: true })
  writeFileSync(join(DIR, 'notes', '微电网.md'), '# 微电网\n\n微电网的逆变器控制策略采用下垂控制，可以实现无互联通信的功率分配。\n\n离网模式下微电网需要二次调频与电压恢复。', 'utf8')
  writeFileSync(join(DIR, 'papers', 'hvdc.txt'), 'HVDC high voltage direct current transmission reduces losses over long distance lines.', 'utf8')
  const r = await kb.addPath(DIR)
  return r
}

test('kb: add 目录登记 MD/TXT → list/find 命中正确 doc', async () => {
  const kb = createKb({ dir: join(DIR, 'kb') })
  const r = await seed(kb)
  assert.equal(r.added.length, 2, `应新增 2 份，实际 ${r.added.length}：${JSON.stringify(r)}`)
  assert.equal(r.errors.length, 0)
  const all = kb.list()
  assert.equal(all.length, 2)
  const md = all.find((d) => d.fileName === '微电网.md')
  assert.ok(md && md.kind === 'text' && md.blocks >= 2, 'md 至少 2 块（两个段落）')

  const hit = kb.find('逆变器 控制')
  assert.ok(hit.hits.length > 0)
  assert.equal(hit.hits[0].docId, md.docId, '命中应为微电网.md')
  assert.equal(hit.hits[0].page, 1)
  assert.ok(hit.hits[0].score > 0)
  assert.ok(hit.hits[0].snippet.includes('逆变器') || hit.hits[0].snippet.includes('控制'))

  const hit2 = kb.find('HVDC transmission')
  assert.ok(hit2.hits.length > 0)
  assert.equal(hit2.hits[0].fileName, 'hvdc.txt')
})

test('kb: cite 生成 kb:docId#page=N 证据引用；kb.jsonl 留痕', async () => {
  const kb = createKb({ dir: join(DIR, 'kb') })
  await seed(kb)
  const md = kb.list().find((d) => d.fileName === '微电网.md')
  const c = kb.cite(md.docId, 1)
  assert.equal(c.ref, `kb:${md.docId}#page=1`)
  assert.equal(c.evidenceId, `kb_${md.docId}_p1`)
  assert.equal(c.sha256, md.sha256)
  const kbLog = logPath('kb.jsonl')
  const lines = readFileSync(kbLog, 'utf8').split('\n').filter((l) => l.trim())
  const last = JSON.parse(lines[lines.length - 1])
  assert.equal(last.kind, 'kb-cite')
  assert.equal(last.ref, c.ref)
})

test('kb: 同内容去重；rm 移除后不再命中', async () => {
  const kb = createKb({ dir: join(DIR, 'kb') })
  await seed(kb)
  const r2 = await kb.addPath(DIR)
  assert.equal(r2.added.length, 0, '同内容不应重复入库')
  assert.ok(r2.skipped.every((s) => s.reason === 'E_KB_DUPLICATE'))

  const txt = kb.list().find((d) => d.fileName === 'hvdc.txt')
  const before = kb.find('HVDC')
  assert.ok(before.hits.some((h) => h.docId === txt.docId))
  const rm = kb.rm(txt.docId)
  assert.equal(rm.removed, txt.docId)
  assert.equal(kb.list().length, 1)
  const after = kb.find('HVDC')
  assert.ok(!after.hits.some((h) => h.docId === txt.docId))
  assert.throws(() => kb.rm(txt.docId), /没有该文档/)
})

test('kb: 伪 PDF 抽取失败如实报错（E_KB_EXTRACT 路径）', async () => {
  const kb = createKb({ dir: join(DIR, 'kb') })
  mkdirSync(join(DIR, 'fake'), { recursive: true })
  writeFileSync(join(DIR, 'fake', 'not-a-pdf.pdf'), 'this is definitely not a pdf file body', 'utf8')
  const r = await kb.addPath(join(DIR, 'fake'))
  assert.equal(r.added.length, 0)
  assert.equal(r.errors.length, 1, '伪 PDF 应进入 errors')
  assert.ok(['E_KB_EXTRACT', 'E_PDF_EXTRACT'].includes(r.errors[0].code) || String(r.errors[0].message).length > 0)
})

test('kb: 单库上限受 mode caps 约束（lean 档先填满，再入库 → E_KB_CAP）；finally 复位 standard', async () => {
  modes.setMode('lean')
  try {
    const kb = createKb({ dir: join(DIR, 'kb') })
    const bigDir = join(DIR, 'big')
    mkdirSync(bigDir, { recursive: true })
    // 一份 ≈70KB 文本：lean 档 per-file cap = 64KB → 截断入库并恰好填满全库上限
    writeFileSync(join(bigDir, 'big.txt'), 'a'.repeat(70 * 1024), 'utf8')
    const r1 = await kb.addPath(bigDir)
    assert.equal(r1.added.length, 1)
    assert.equal(r1.added[0].truncated, true, 'lean 档 70KB 应被截断到 64KB')
    // 再入第二份（哪怕很小）→ 全库总量超上限 → E_KB_CAP
    writeFileSync(join(bigDir, 'small.txt'), 'b'.repeat(100), 'utf8')
    const r2 = await kb.addPath(bigDir)
    const capSkips = r2.skipped.filter((s) => s.reason === 'E_KB_CAP')
    assert.ok(capSkips.length >= 1, `第二份应被 E_KB_CAP 跳过：${JSON.stringify(r2)}`)
    assert.equal(r2.added.length, 0)
  } finally {
    modes.setMode('standard') // 纪律：动过 config.json（setMode）必须在 finally 复位
  }
  assert.equal(modes.currentModeId(), 'standard')
})

test('kb: 持久化三件套落盘，重建引擎后可继续检索', async () => {
  const dir = join(DIR, 'kb')
  const kb = createKb({ dir })
  await seed(kb)
  assert.ok(existsSync(join(dir, 'docs.json')))
  assert.ok(existsSync(join(dir, 'chunks.jsonl')))
  assert.ok(existsSync(join(dir, 'index.json')))
  const docId = kb.list()[0].docId
  const kb2 = createKb({ dir }) // 重新加载
  assert.equal(kb2.list().length, 2)
  const hit = kb2.find('下垂控制')
  assert.ok(hit.hits.some((h) => h.docId === docId))
})
