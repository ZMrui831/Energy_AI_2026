// tests/shell-encoding.test.mjs —— S74c·P1-6 shell.run 中文不乱码回归
//
// 背景：cmd.exe 在中文 Windows 默认按 OEM 码页（936/GBK）输出，Node 只有 utf8 解码器且在
// 无新依赖前提下无法把 GBK 转回 UTF-8。修复：执行前 `chcp 65001>nul &` 切到 UTF-8 码页。
// 本测试真跑 cmd（白名单内 echo/dir/type），断言中文原样返回、无替换符/经典乱码。
import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { createPathResolver } from '../packages/core/src/tools/paths.mjs'
import { createToolRegistry } from '../packages/core/src/tools/registry.mjs'
import { registerShellTools } from '../packages/core/src/tools/impl/shell.mjs'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const paths = createPathResolver({
  root: PROJECT_ROOT,
  home: process.env.USERPROFILE,
  env: { USERPROFILE: process.env.USERPROFILE },
  desktopReader: () => 'D:\\Desktop',
})
const ctx = { paths, signal: null, emit: () => {}, toolId: 'shell.run' }
function reg() {
  const r = createToolRegistry()
  registerShellTools(r, { roots: [PROJECT_ROOT], extraAllow: [] })
  return r
}
const mojibake = (s) => /\ufffd|锟斤拷|烫烫|屯屯/.test(s)

test('encoding: echo 中文 → stdout 中文原样，无乱码', async () => {
  const r = await reg().get('shell.run').run({ command: 'echo 中文测试ABC一二次' }, ctx)
  assert.equal(r.ok, true, 'exit=' + r.exitCode + ' stderr=' + JSON.stringify(r.stderr))
  assert.ok(r.stdout.includes('中文测试ABC一二次'), 'stdout 应含中文原样：' + JSON.stringify(r.stdout))
  assert.ok(!mojibake(r.stdout), '不应出现替换符/乱码：' + JSON.stringify(r.stdout))
})

test('encoding: dir /b 列出中文文件名不乱码', async () => {
  const dir = join(PROJECT_ROOT, 'data', 'tmp', 'enc-test-' + Date.now())
  mkdirSync(dir, { recursive: true })
  writeFileSync(join(dir, '中文文件名-综合能源.txt'), 'x', 'utf8')
  try {
    const r = await reg().get('shell.run').run({ command: 'dir /b', cwd: dir }, ctx)
    assert.equal(r.ok, true, 'exit=' + r.exitCode + ' stderr=' + JSON.stringify(r.stderr))
    assert.ok(r.stdout.includes('中文文件名-综合能源.txt'), 'dir 应列出中文文件名：' + JSON.stringify(r.stdout))
    assert.ok(!mojibake(r.stdout), '不应出现乱码：' + JSON.stringify(r.stdout))
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('encoding: type 读取 UTF-8 中文文件内容不乱码', async () => {
  const dir = join(PROJECT_ROOT, 'data', 'tmp', 'enc-type-' + Date.now())
  mkdirSync(dir, { recursive: true })
  const f = join(dir, 'note.txt')
  writeFileSync(f, '微电网模型预测控制两阶段调度', 'utf8')
  try {
    const r = await reg().get('shell.run').run({ command: 'type ' + f, cwd: PROJECT_ROOT }, ctx)
    assert.equal(r.ok, true, 'exit=' + r.exitCode)
    assert.ok(r.stdout.includes('微电网模型预测控制两阶段调度'), 'type 应原样返回中文内容：' + JSON.stringify(r.stdout))
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})
