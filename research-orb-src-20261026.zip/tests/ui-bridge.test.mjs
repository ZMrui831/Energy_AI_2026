// tests/ui-bridge.test.mjs
//
// 面板注入体回归（阶段 3.2，主管核验 P-R3.1 时发现的必现缺陷催生）：
//
// ui-bridge.mjs 不是模块，而是主进程读成字符串后用 webContents.executeJavaScript
// 注入 renderer 的一段自包含脚本。阶段 3 曾因「state 的前向引用」（TDZ：
// `state.notifyCbTimer = notifyCb` 写在 `const state = {...}` 之前）让整个注入体
// 在 renderer 里 abort → bridge-inject-failed → UI 全废。当时的「UI 契约」只是
// 静态字符串断言，抓不到运行期错误——本测试补上运行期保险：
//
//   1) 语法可编译（new Function 整段过一遍）；
//   2) 在 vm 里用「万能桩」浏览器环境整段执行，断言不抛 ReferenceError
//      —— TDZ 与未声明标识符都属这一类（strict 模式下赋值给未声明变量同样是
//      ReferenceError，一并覆盖）。桩环境自身不完整导致的 TypeError 不判失败
//      （真实渲染行为由 accept-stage3-2 的 electron 冒烟覆盖）；
//   3) 版本单一来源：main.mjs 里 APP_VERSION 的赋值表达式求值必须等于
//      package.json.version——谁再硬编码字面量，这里立即红。
//
// 万能桩设计要点（v1 踩坑记录）：
//   · `then` 返回 undefined —— 桩不可 thenable，否则 `await 桩` 会永久挂死；
//   · Symbol.iterator 返回空生成器 —— for..of / 展开不抛异常也不挂死；
//   · toString/valueOf/Symbol.toPrimitive 给确定值 —— 字符串拼接不炸。

import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import vm from 'node:vm'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { TIMER_VERSION } from '../packages/plugins/research-timer/index.mjs'
import { RESEARCH_LITERATURE_VERSION } from '../packages/plugins/research-literature/index.mjs'

const BRIDGE_PATH = join(PROJECT_ROOT, 'apps', 'desktop', 'ui-bridge.mjs')
const MAIN_PATH = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const bridgeSource = readFileSync(BRIDGE_PATH, 'utf8')
const mainSource = readFileSync(MAIN_PATH, 'utf8')

test('注入体语法可编译（整段过 JS 引擎）', () => {
  assert.doesNotThrow(() => new Function(bridgeSource), '注入体必须能被编译——语法错误会让 executeJavaScript 静默失败')
})

/** 万能桩：任何属性访问/调用/构造都返回桩自身；对会挂死的语义点显式规避。 */
function makeUniversalStub() {
  const target = function stub() {}
  const stub = new Proxy(target, {
    get(t, prop) {
      if (prop === 'then') return undefined // 不可 thenable：await 桩立即 resolve，不会挂死
      if (prop === Symbol.iterator) return function* () {} // 可 for..of，零元素
      if (prop === Symbol.toPrimitive) return () => '[stub]'
      if (prop === 'toString') return () => '[stub]'
      if (prop === 'valueOf') return () => '[stub]'
      return stub
    },
    apply() { return stub },
    construct() { return stub },
    has() { return true },
    set() { return true },
    defineProperty() { return true },
  })
  return stub
}

test('注入体在桩浏览器环境里整段执行，不抛 ReferenceError（TDZ/未声明标识符回归）', () => {
  const stub = makeUniversalStub()
  const noop = () => {}
  const sandbox = {
    console,
    setTimeout: noop,
    clearTimeout: noop,
    setInterval: noop,
    clearInterval: noop,
    requestAnimationFrame: noop,
    cancelAnimationFrame: noop,
    queueMicrotask: noop,
    getComputedStyle: () => stub,
    matchMedia: () => stub,
    fetch: () => Promise.resolve(stub),
    MutationObserver: function () { return { observe: noop, disconnect: noop, takeRecords: () => [] } },
    IntersectionObserver: function () { return { observe: noop, disconnect: noop, unobserve: noop } },
    ResizeObserver: function () { return { observe: noop, disconnect: noop, unobserve: noop } },
    CustomEvent: function () {},
    Event: function () {},
    document: stub,
    window: stub,
    navigator: stub,
    location: stub,
    history: stub,
    localStorage: stub,
    sessionStorage: stub,
    screen: stub,
    researchOrb: stub,
  }
  sandbox.globalThis = sandbox
  sandbox.self = sandbox
  vm.createContext(sandbox)

  let referenceError = null
  let otherError = null
  try {
    vm.runInContext(bridgeSource, sandbox, { filename: 'ui-bridge.injected.js' })
  } catch (err) {
    // 注意：vm 上下文里的错误对象是「另一个 realm」的实例，外层 instanceof ReferenceError
    // 会跨域失败（变异测试实测：TDZ 回归会被误归类成 otherError 而漏过）——必须按 name 判。
    if (err && err.name === 'ReferenceError') referenceError = err
    else otherError = err
  }
  assert.equal(referenceError, null,
    `注入体顶层执行抛 ReferenceError（TDZ/未声明标识符）：${referenceError && referenceError.stack}`)
  // 桩环境不完整导致的 TypeError 等不判失败，但打出来供人工判断（真实渲染由 electron 冒烟覆盖）
  if (otherError) console.log(`  （桩环境非 ReferenceError，记录不判失败：${otherError.message}）`)
})

test('版本单一来源：main.mjs 的 APP_VERSION 表达式求值 == package.json.version', () => {
  const m = mainSource.match(/^const APP_VERSION = (.+)$/m)
  assert.ok(m, 'main.mjs 必须有一行 const APP_VERSION = ...（版本唯一入口）')
  const pkg = JSON.parse(readFileSync(join(PROJECT_ROOT, 'package.json'), 'utf8'))
  const evaluate = new Function('readFileSync', 'join', 'ROOT', `return (${m[1]})`)
  const value = evaluate(readFileSync, join, PROJECT_ROOT)
  assert.equal(value, pkg.version,
    `APP_VERSION（${value}）必须等于 package.json.version（${pkg.version}）——禁止硬编码字面量`)
  assert.equal(TIMER_VERSION, pkg.version, '插件 TIMER_VERSION 也必须与 package.json 一致')
})

test('版本四处一致（主管必修）：托盘/设置页 == package.json == plugin.json == 插件常量', () => {
  // P-R4 块 3 必修：package.json 曾停在 0.3.0-phase3.1 而文献插件已是 0.4.0-phase4.2，
  // 托盘与设置页（都显示 APP_VERSION）与插件卡片版本自相矛盾。现在全部派生自 package.json
  // （packages/core/src/version.mjs），plugin.json 由本钉看住。
  const pkg = JSON.parse(readFileSync(join(PROJECT_ROOT, 'package.json'), 'utf8'))
  const litManifest = JSON.parse(readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'research-literature', 'plugin.json'), 'utf8'))
  const timerManifest = JSON.parse(readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'research-timer', 'plugin.json'), 'utf8'))
  assert.equal(litManifest.version, pkg.version, 'research-literature/plugin.json 必须与 package.json 一致')
  assert.equal(timerManifest.version, pkg.version, 'research-timer/plugin.json 必须与 package.json 一致')
  // 两个插件常量都必须经 core/src/version.mjs 派生（不得再是字面量）
  const litSource = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'research-literature', 'index.mjs'), 'utf8')
  const timerSource = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'research-timer', 'index.mjs'), 'utf8')
  assert.match(litSource, /RESEARCH_LITERATURE_VERSION = APP_VERSION/, '文献插件版本必须派生自 version.mjs')
  assert.match(timerSource, /TIMER_VERSION = APP_VERSION/, '计时插件版本必须派生自 version.mjs')
  // 派生值真的等于 package.json（运行期验证）
  assert.equal(RESEARCH_LITERATURE_VERSION, pkg.version)
  assert.equal(TIMER_VERSION, pkg.version)
})

test('main.mjs 不得再出现第二处阶段版本字面量', () => {
  // 排除 APP_VERSION 那一行后，源码里不得再有 'x.y.z-*' 形态的版本字符串
  const withoutVersionLine = mainSource.replace(/^const APP_VERSION = .+$/m, '')
  const literals = withoutVersionLine.match(/['"]\d+\.\d+\.\d+[^'"]*['"]/g) || []
  assert.deepEqual(literals, [], `发现第二处版本字面量：${literals.join(', ')}`)
})

test('toggleTimer 的 status/project 拉取必须被关→开跳变守卫（GUI 取证暴露的死循环回归）', () => {
  // 2026-10-15 stage32 GUI 截图取证实测：renderTimer 收到下行 payload 会调 toggleTimer(true)，
  // 若 toggleTimer 在已开状态下仍无条件重发 status/project，就形成
  // 「payload → 重发命令 → 新 payload → 再重发」的死循环（每秒 ~60 次命令刷屏）。
  // 本钉保证：send('plugin:command') 必须位于 open && !wasOpen 守卫之内。
  //
  // P-R6：toggleTimer 已从 shell 抽到 packages\packs\research\ui\timer.js（领域渲染层），
  // 因此本钉改盯 pack 里的那一份 —— 抽走不等于纪律失效。
  const PACK_TIMER = join(PROJECT_ROOT, 'packages', 'packs', 'research', 'ui', 'timer.js')
  const packSource = readFileSync(PACK_TIMER, 'utf8')
  const fnStart = packSource.indexOf('function toggleTimer(')
  assert.ok(fnStart > 0, `toggleTimer 必须存在于 pack 领域渲染层（${PACK_TIMER}）`)
  const fnEnd = packSource.indexOf('function syncNotifyCheckboxes', fnStart)
  assert.ok(fnEnd > fnStart, 'toggleTimer 函数体边界异常')
  const body = packSource.slice(fnStart, fnEnd)
  assert.ok(body.includes('wasOpen'), 'toggleTimer 必须记录跳变前状态（wasOpen）')
  const sendIdx = body.indexOf("send('plugin:command'")
  assert.ok(sendIdx > 0, 'toggleTimer 内必须有 status/project 拉取')
  const guard = body.slice(0, sendIdx)
  assert.match(guard, /open && !wasOpen/, 'status/project 拉取必须被 open && !wasOpen 守卫（只在关→开跳变时发生）')
})

test('领域 UI 脚本同样是自包含注入体：语法可编译 + vm 执行不抛 ReferenceError', () => {
  // pack 的 ui/*.js 与 ui-bridge.mjs 同一注入机制（主进程 executeJavaScript），
  // 因此同样的两条保险必须覆盖到它们。
  const uiDir = join(PROJECT_ROOT, 'packages', 'packs', 'research', 'ui')
  const files = readdirSyncSafe(uiDir).filter((f) => f.endsWith('.js'))
  assert.ok(files.length >= 2, `research pack 至少要有 literature.js / timer.js（实际 ${files.join(',')}）`)
  for (const f of files) {
    const src = readFileSync(join(uiDir, f), 'utf8')
    assert.doesNotThrow(() => new Function(src), `${f} 必须能被编译`)
    // 桩环境执行：__ro 用万能桩顶上，领域钩子调用都落在桩上
    const stub = makeUniversalStub()
    const sandbox = {
      console, setTimeout: () => {}, clearTimeout: () => {}, setInterval: () => {}, clearInterval: () => {},
      requestAnimationFrame: () => {}, cancelAnimationFrame: () => {}, queueMicrotask: () => {},
      getComputedStyle: () => stub, matchMedia: () => stub, fetch: () => Promise.resolve(stub),
      MutationObserver: function () { return { observe() {}, disconnect() {}, takeRecords: () => [] } },
      document: stub, window: stub, navigator: stub, location: stub, localStorage: stub,
    }
    sandbox.globalThis = sandbox
    sandbox.__ro = stub
    vm.createContext(sandbox)
    let refErr = null
    try {
      vm.runInContext(src, sandbox, { filename: f })
    } catch (err) {
      if (err && err.name === 'ReferenceError') refErr = err
      else console.log(`  （${f} 桩环境非 ReferenceError，记录不判失败：${err.message}）`)
    }
    assert.equal(refErr, null, `${f} 顶层执行抛 ReferenceError：${refErr && refErr.stack}`)
  }
})

function readdirSyncSafe(dir) {
  try { return readdirSync(dir) } catch { return [] }
}
