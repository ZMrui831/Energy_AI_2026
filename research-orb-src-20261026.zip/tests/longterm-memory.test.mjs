// tests/longterm-memory.test.mjs —— S29·阶段2 长期记忆移植验收（≥8 项）。
import { test, beforeEach, afterEach } from 'node:test'
import assert from 'node:assert/strict'
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, dataPath } from '../packages/core/src/safefs.mjs'
import { readLongTermConfig, writeLongTermConfig, LT_DEFAULTS } from '../packages/plugins/longterm-memory/config.mjs'
import { readLongTermMemoryContext } from '../packages/plugins/longterm-memory/context.mjs'
import { observeTurn, isWritableFact, MAX_PER_TURN, MAX_CHARS } from '../packages/plugins/longterm-memory/write.mjs'

const ROOT = dataPath('tmp', 's29-ltm-test')
const SRC = 'D:/AI_Workspace/记忆插件/packages/core'

function sha(p) { return createHash('sha256').update(readFileSync(p)).digest('hex') }

let n = 0
beforeEach(() => { n += 1; rmSync(`${ROOT}-${n}`, { recursive: true, force: true }); mkdirSync(`${ROOT}-${n}`, { recursive: true }) })
afterEach(() => { rmSync(ROOT, { recursive: true, force: true }); for (let i = 1; i <= 40; i++) rmSync(`${ROOT}-${i}`, { recursive: true, force: true }) })

// 固化基线（S29 复制自上游；S30 同步上游 1.1.0-rc7：compile/markdown/recall 三文件随上游演进更新）。
// 为什么与"活源目录"脱钩：上游会继续演进，与活源逐字节比对会 flaky——版本+哈希固化的本意就是钉住基线，
// 上游更新时由人显式同步并改这张表（docs/LONGTERM-MEMORY.md 同表）。
const CORE_BASELINE = {
  'api.js': '1113d516ad022feec299195700a109a46af60bf1757ea8cddb716b6d37b7e651',
  'compile.js': '0cebcd14b6b55329cb6d8008f16bffaaabe8e41df3cd2870db91d52119408a99',
  'evict.js': 'd90b4c791e71a930b6f3ea118d9ddebfa80d7ba71e6f844fbaeae2bca8036b80',
  'index-cache.js': 'f664821f1d1e8638dbdd840a33749d3a471400019174ca7b859a7d0a73e0db09',
  'index-fts.js': '24e37369eb2a98d54ca52683fadc873de3a4b53a32b241683f9e1561048b0d4a',
  'lifecycle.js': '8ef0df50fc69aa4a0bf146a74ef7587611e30332ae0b5edf359c8b90652d09e3',
  'markdown.js': 'de283938c17049e66b5911ded8d7e299d16b45ea347ea573453d7568abd640df',
  'recall.js': 'ba58aae707ce2ad05b2c9bf3144ac2d88d3ae35ea65b529f583f4383276ee862',
  'schema.js': '1703856d2cbc7b7fc4002097d4c0440f995895372618c67fb9494b9396445e6e',
  'store-jsonl.js': '359ee507d2b0acde66bb7930ea4cf9de8ace523e6f781f50bdc6243be3ca0a12',
  'temporal.js': '977c1a93cf05b16a8afde1ea06439ad3d5eecbc98bd21705fbbb0a872b48d9f7',
}

test('ltm: 11 个内核文件 sha256 与固化基线一致（原样移植，上游 1.0.1）', () => {
  const rows = []
  for (const [f, want] of Object.entries(CORE_BASELINE)) {
    const got = sha(join(PROJECT_ROOT, 'packages', 'plugins', 'longterm-memory', 'core', f))
    rows.push({ f, same: got === want })
    assert.equal(got, want, `内核 ${f} 与固化基线不一致`)
  }
  assert.equal(Object.keys(CORE_BASELINE).length, 11)
})

test('ltm: 读侧——空库（文件不存在）返回空串且不创建文件', () => {
  const dir = `${ROOT}-${n}`
  const out = readLongTermMemoryContext({ root: dir, query: 'anything' })
  assert.equal(out, '')
  assert.equal(existsSync(join(dir, 'data', 'memory', 'longterm.md')), false, '不创建文件')
})

test('ltm: 读侧——文件损坏/配置损坏一律返回空串（不抛）', () => {
  const dir = `${ROOT}-${n}`
  mkdirSync(join(dir, 'data', 'memory'), { recursive: true })
  writeFileSync(join(dir, 'data', 'memory', 'longterm.md'), '这不是合法记忆格式 {{{', 'utf8')
  assert.doesNotThrow(() => { const o = readLongTermMemoryContext({ root: dir, query: 'x' }); assert.equal(typeof o, 'string') })
  writeFileSync(join(dir, 'data', 'memory', 'config.json'), '{ 坏 JSON', 'utf8')
  const cfg = readLongTermConfig({ root: dir })
  assert.equal(cfg.source, 'parse-error')
  assert.equal(cfg.enabled, LT_DEFAULTS.enabled)
})

test('ltm: 写侧——提问/寒暄/纯回执不入库；事实入长库', () => {
  const dir = `${ROOT}-${n}`
  assert.equal(isWritableFact('请问微电网的下垂控制是什么'), false, '提问不写')
  assert.equal(isWritableFact('你好'), false, '寒暄不写')
  assert.equal(isWritableFact('好的'), false, '纯回执不写')
  assert.equal(isWritableFact('嗯'), false, '单字不写')
  assert.equal(isWritableFact('用户正在撰写微电网综述第二章，已定三节结构'), true, '事实可写')
  const r1 = observeTurn({ root: dir, userText: '今天天气怎么样？' })
  assert.equal(r1.written, 0, '提问轮不写')
  const r2 = observeTurn({ root: dir, userText: '用户正在撰写微电网综述第二章，已完成现状与关键技术两节初稿' })
  assert.equal(r2.written, 1, '事实轮写入 1 条')
  const r3 = observeTurn({ root: dir, userText: '微电网' })
  assert.equal(r3.written, 0, '过短不写')
})

test('ltm: 写侧——单轮 ≤2 条、单条 ≤400 字', () => {
  const dir = `${ROOT}-${n}`
  const long = '用户长期偏好先列提纲再写作，今天再次确认了这一点。'.repeat(20)
  assert.ok(long.length > MAX_CHARS)
  const r = observeTurn({ root: dir, userText: long })
  assert.ok(r.written <= MAX_PER_TURN)
  // 单条截断到 400 字内
  const { createMemory } = require_shim()
  void createMemory
  const file = join(dir, 'data', 'memory', 'longterm.md')
  if (existsSync(file)) {
    const txt = readFileSync(file, 'utf8')
    assert.ok(!txt.includes(long), '超长文本应被截断到 400 字')
  }
})

test('ltm: 读侧——写入后可 recall 且预算内', () => {
  const dir = `${ROOT}-${n}`
  observeTurn({ root: dir, userText: '用户的研究方向是智能电网综合能源系统的 AI 应用' })
  observeTurn({ root: dir, userText: '用户的研究方向是微电网逆变器下垂控制策略综述' })
  const ctx = readLongTermMemoryContext({ root: dir, query: '微电网', budgetTokens: 300 })
  assert.ok(typeof ctx === 'string')
  const est = Math.ceil(ctx.length / 2)
  assert.ok(est <= 300, `预算内（实测 ${est}）`)
})

test('ltm: enabled=false → 注入为空且写侧跳过（实测）', () => {
  const dir = `${ROOT}-${n}`
  mkdirSync(join(dir, 'data', 'memory'), { recursive: true })
  writeFileSync(join(dir, 'data', 'memory', 'config.json'), JSON.stringify({ enabled: false, budgetTokens: 300, writeGovernance: true }), 'utf8')
  observeTurn({ root: dir, userText: '用户正在撰写微电网综述第二章' })
  assert.equal(existsSync(join(dir, 'data', 'memory', 'longterm.md')), false, '关闭时不写')
  const ctx = readLongTermMemoryContext({ root: dir, query: '微电网' })
  assert.equal(ctx, '', '关闭时注入为空')
})

test('ltm: 写侧治理总闸 writeGovernance=false → 跳过', () => {
  const dir = `${ROOT}-${n}`
  mkdirSync(join(dir, 'data', 'memory'), { recursive: true })
  writeFileSync(join(dir, 'data', 'memory', 'config.json'), JSON.stringify({ enabled: true, budgetTokens: 300, writeGovernance: false }), 'utf8')
  const r = observeTurn({ root: dir, userText: '用户正在撰写微电网综述第二章' })
  assert.equal(r.written, 0)
  assert.equal(r.skipped, 'no-governance')
})

test('ltm: 路径在项目根内（禁止越狱写）', () => {
  const dir = `${ROOT}-${n}`
  observeTurn({ root: dir, userText: '用户正在撰写微电网综述第二章' })
  const file = join(dir, 'data', 'memory', 'project', 'longterm.md')
  assert.ok(existsSync(file), '写在 root/data/memory/<scope> 内')
  assert.ok(file.startsWith(dir), '路径在 root 内')
})

test('ltm: 配置缺省值与预算上限', () => {
  const dir = `${ROOT}-${n}`
  const cfg = readLongTermConfig({ root: dir })
  assert.deepEqual({ ...cfg, source: 'default' }, { ...LT_DEFAULTS, source: 'default' })
  const big = '事实'.repeat(1000)
  const ctx0 = readLongTermMemoryContext({ root: dir, query: 'x', budgetTokens: 10 })
  assert.ok(Math.ceil(ctx0.length / 2) <= 10 || ctx0 === '')
  void big
})

test('ltm: diag 只记计数（longterm.md.diag.log 有 written/live，无内容）', () => {
  const dir = `${ROOT}-${n}`
  observeTurn({ root: dir, userText: '用户正在撰写微电网综述第二章，已完成两节初稿' })
  const diag = join(dir, 'data', 'memory', 'project', 'longterm.md.diag.log')
  assert.ok(existsSync(diag), 'diag 文件生成')
  const row = JSON.parse(readFileSync(diag, 'utf8').trim().split('\n').pop())
  assert.ok(Number.isFinite(row.written) && Number.isFinite(row.live), '计数字段')
  assert.ok(!JSON.stringify(row).includes('微电网'), 'diag 不记内容')
})

test('ltm: scope 分域——project 写的记忆 global 读不到（反之亦然）', () => {
  const dir = `${ROOT}-${n}`
  mkdirSync(join(dir, 'data', 'memory'), { recursive: true })
  writeFileSync(join(dir, 'data', 'memory', 'config.json'), JSON.stringify({ enabled: true, budgetTokens: 300, writeGovernance: true, scope: 'project' }), 'utf8')
  const r = observeTurn({ root: dir, userText: '用户在 project 域写下弦控制对比实验的记录' })
  assert.equal(r.written, 1)
  // 切 global 再写一条
  writeFileSync(join(dir, 'data', 'memory', 'config.json'), JSON.stringify({ enabled: true, budgetTokens: 300, writeGovernance: true, scope: 'global' }), 'utf8')
  observeTurn({ root: dir, userText: '用户在 global 域记下跨项目通用的作息偏好' })
  const projCtx = readLongTermMemoryContext({ root: dir, query: '下弦控制', scope: 'project' })
  const globCtx = readLongTermMemoryContext({ root: dir, query: '下弦控制', scope: 'global' })
  const globCtx2 = readLongTermMemoryContext({ root: dir, query: '作息偏好', scope: 'global' })
  const projCtx2 = readLongTermMemoryContext({ root: dir, query: '作息偏好', scope: 'project' })
  assert.ok(projCtx.includes('下弦控制'), 'project 域能读到自己')
  assert.ok(!globCtx.includes('下弦控制'), 'global 域读不到 project 的记忆')
  assert.ok(globCtx2.includes('作息偏好'), 'global 域能读到自己')
  assert.ok(!projCtx2.includes('作息偏好'), 'project 域读不到 global 的记忆')
  // 分域文件确实分开
  assert.ok(existsSync(join(dir, 'data', 'memory', 'project', 'longterm.md')))
  assert.ok(existsSync(join(dir, 'data', 'memory', 'global', 'longterm.md')))
})

test('ltm: forget——按关键词遗忘后 recall 不再命中且审计有行', async () => {
  const dir = `${ROOT}-${n}`
  observeTurn({ root: dir, userText: '用户临时记下明天下午三点要交电网报告' })
  const before = readLongTermMemoryContext({ root: dir, query: '电网报告' })
  assert.ok(before.includes('电网报告'), '遗忘前可读')
  const { createMemory } = await import('../packages/plugins/longterm-memory/core/api.js')
  const mem = createMemory({ file: join(dir, 'data', 'memory', 'project', 'longterm.md'), now: () => Date.now() })
  const r = mem.forget('电网报告', { mode: 'tombstone' })
  assert.ok(r.forgotten && (Array.isArray(r.forgotten) ? r.forgotten.length > 0 : r.forgotten), 'forget 有结果')
  const after = readLongTermMemoryContext({ root: dir, query: '电网报告' })
  assert.ok(!after.includes('电网报告'), '遗忘后读不到')
})

test('ltm: export——产出含全部存活事实且不泄漏路径', () => {
  const dir = `${ROOT}-${n}`
  observeTurn({ root: dir, userText: '用户导出测试甲：正在做微电网综述第二章写作' })
  observeTurn({ root: dir, userText: '用户导出测试乙：下午要补下垂控制对比实验数据' })
  // 经 index.mjs 的 export 逻辑等价路径：直接读 store 渲染
  return import('../packages/plugins/longterm-memory/core/api.js').then(({ createMemory }) => {
    const mem = createMemory({ file: join(dir, 'data', 'memory', 'project', 'longterm.md'), now: () => Date.now() })
    const rows = mem.store.live()
    assert.ok(rows.length >= 1, '有存活事实')
    const body = rows.map((r) => `- [L${r.layer}] ${String(r.text || '')}`).join('\n')
    assert.ok(!body.includes('data/') && !body.includes('\\') && !body.includes('memory'), '导出不含路径信息')
    assert.ok(!body.includes(dir), '导出不含绝对路径')
  })
})

test('ltm: 助手侧白名单——"已更新：X 现在是 Y"写入；纯回执"好的"丢弃', () => {
  const dir = `${ROOT}-${n}`
  const r1 = observeTurn({ root: dir, userText: '提纲有变化吗', assistantText: '已更新：第二章第三节现在是 挑战与展望' })
  assert.equal(r1.written, 1, '助手侧语义更新句应写入')
  const before = countFacts(dir)
  const r2 = observeTurn({ root: dir, userText: '谢谢', assistantText: '好的，随时问我。' })
  assert.equal(r2.written, 0, '纯回执不写')
  const r3 = observeTurn({ root: dir, userText: '嗯', assistantText: '好的。' })
  assert.equal(r3.written, 0, '纯回执+短用户消息不写')
  assert.equal(countFacts(dir), before, '事实数不增')
})

function countFacts(dir) {
  try {
    const { createMemory } = require_shim()
    void createMemory
    return readFileSync(join(dir, 'data', 'memory', 'project', 'longterm.md'), 'utf8').split('\n').filter((l) => l.trim() && !l.startsWith('#') && !l.startsWith('---')).length
  } catch { return 0 }
}

function require_shim() { return { createMemory: null } }
