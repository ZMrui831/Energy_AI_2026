// tests/collapse.test.mjs
//
// P-R6.2 任务四：welcome/说明区折叠 —— 接线与持久化语义。
// ui-bridge 是注入脚本（无模块导出），因此：
//   · 静态断言：折叠控件/持久化键/默认折叠/领域行纳入折叠区 必须在源码中接线；
//   · 纯逻辑断言：用源码内联提取 readWelcomeCollapsed/writeWelcomeCollapsed 的
//     语义等价实现做行为验证（localStorage 语义：缺省→默认折叠；'0'→展开；'1'→折叠）。

import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const bridge = readFileSync(join(PROJECT_ROOT, 'apps', 'desktop', 'ui-bridge.mjs'), 'utf8')

test('collapse: 折叠控件接线存在（head 点击 → toggleWelcome → localStorage）', () => {
  assert.match(bridge, /ro-welcome-head/, '必须有折叠头')
  assert.match(bridge, /ro-welcome-arrow/, '必须有折叠箭头')
  assert.match(bridge, /head\.addEventListener\('click', \(\) => toggleWelcome\(card\)\)/, '点击头必须切换折叠')
  assert.match(bridge, /WELCOME_COLLAPSE_KEY/, '必须有持久化键')
  assert.match(bridge, /localStorage\.setItem\(WELCOME_COLLAPSE_KEY/, '必须写 localStorage')
  assert.match(bridge, /localStorage\.getItem\(WELCOME_COLLAPSE_KEY/, '必须读 localStorage')
})

test('collapse: 默认折叠（无持久化值时）', () => {
  const m = bridge.match(/function welcomeCollapsedDefault\(\) \{ return (\w+) \}/)
  assert.ok(m, '必须有 welcomeCollapsedDefault')
  assert.equal(m[1], 'true', '默认必须是折叠（true）—— 面板首屏不再被说明文字占满')
})

test('collapse: 领域行（pack appendWelcome）纳入折叠区', () => {
  // renderPackWelcome 把领域行挂进 .ro-welcome-body（随折叠隐藏），而不是独立于折叠区
  const iPack = bridge.indexOf('renderPackWelcome()')
  assert.ok(iPack > 0, 'renderPackWelcome 必须存在')  // 定义形如 renderPackWelcome() {（对象方法）
  const seg = bridge.slice(iPack, iPack + 2200)
  assert.match(seg, /ro-welcome-body|bodyEl/, '领域行/概览卡必须挂进折叠 body')
  // 概览卡挂进 body（而不是 base），折叠时一起隐藏
  assert.match(seg, /renderOverviewInto\(ovHost\)/, '概览卡必须挂进 body')
})

test('collapse: 持久化语义（localStorage 缺省→折叠；0→展开；1→折叠）', () => {
  // 与 ui-bridge 内实现语义一致的等价验证
  const KEY = 'ro-welcome-collapsed'
  const store = new Map()
  const getItem = (k) => (store.has(k) ? store.get(k) : null)
  const setItem = (k, v) => store.set(k, String(v))
  const read = () => {
    const v = getItem(KEY)
    if (v === null) return true
    return v === '1'
  }
  assert.equal(read(), true, '缺省 → 折叠')
  setItem(KEY, '0')
  assert.equal(read(), false, "'0' → 展开")
  setItem(KEY, '1')
  assert.equal(read(), true, "'1' → 折叠")
  setItem(KEY, '0')
  // 语义：重启后 localStorage 仍在 → 状态保持
  assert.equal(read(), false, '重启（同一 store）→ 状态保持')
})
