// tests/timer-plugin.test.mjs
//
// 计时插件离线回归：8 条命令的解析与 payload、activate 的注册与零写盘、
// 宿主引擎注入（ctx.timer / ctx.progress）与自建兜底、源码纪律扫描。
//
// 全部内存 store + 注入引擎，一个字节不落盘；唯一碰真盘的是 activate 的
// "零写盘"证明 —— 用前后磁盘快照对比作证（activate 路径不允许写任何数据文件）。
//
// 注意：引擎的 start/pause/resume/stop/status/today/weekly 都是 async
// （与文献插件一致，命令层要能 await LLM），测试里必须 await；project/cardBody 是同步的。

import test from 'node:test'
import assert from 'node:assert/strict'
import { readdirSync, readFileSync, statSync } from 'node:fs'
import { join } from 'node:path'

import {
  CARD_ID,
  DEFAULTS,
  PLUGIN_ID,
  TIMER_VERSION,
  activate,
  createEngine,
  fmtClock,
  splitFlags,
} from '../packages/plugins/research-timer/index.mjs'
import { createTimer } from '../packages/core/src/timer.mjs'
import { createProgress } from '../packages/core/src/progress.mjs'
import { createMemoryStore, dayKeyOf } from '../packages/core/src/timer-store.mjs'
import { PROGRESS_DIR, PROJECTS_DIR, REPORTS_DIR, TIMER_DIR } from '../packages/core/src/timer-store.mjs'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const PLUGIN_DIR = join(PROJECT_ROOT, 'packages', 'plugins', 'research-timer')
const T0 = new Date(2026, 0, 14, 10, 0, 0).getTime()
const DAY = '2026-01-14'

function makeClock(startMs = T0) {
  const c = { t: startMs }
  c.now = () => c.t
  c.advance = (ms) => {
    c.t += ms
    return c.t
  }
  c.set = (ms) => {
    c.t = ms
    return c.t
  }
  return c
}

/** 只吐固定文本的假 llm（形状与 ctx.llm 一致，与文献插件测试同一套）。 */
function fakeLlm(text) {
  return {
    available: true,
    chat: () => (async function* gen() {
      yield { type: 'delta', text, channel: 'content' }
      yield { type: 'done', text }
    })(),
  }
}

function brokenLlm() {
  return {
    available: true,
    chat: () => (async function* gen() {
      throw new Error('provider down')
    })(),
  }
}

/** 最小 ctx：log/state 可观测，timer/progress/llm 可注入（null = 宿主没给）。 */
function makeCtx({ timer = null, progress = null, llm = null } = {}) {
  const logs = []
  const stateMap = new Map()
  const sets = []
  return {
    id: PLUGIN_ID,
    version: TIMER_VERSION,
    log: {
      info: (m) => logs.push(['info', String(m)]),
      warn: (m) => logs.push(['warn', String(m)]),
      error: (m) => logs.push(['error', String(m)]),
      debug: () => {},
    },
    llm,
    state: {
      get: (k, d = null) => (stateMap.has(k) ? stateMap.get(k) : d),
      set: (k, v) => {
        stateMap.set(k, v)
        sets.push([k, v])
      },
      all: () => Object.fromEntries(stateMap),
    },
    timer,
    progress,
    _logs: logs,
    _sets: sets,
  }
}

/** 全套注入的引擎（内存 store + 虚拟时钟 + 真 timer/progress 引擎）。 */
function setup({ timeScale = 1, llm = null } = {}) {
  const clock = makeClock()
  const store = createMemoryStore()
  const timer = createTimer({ store, now: clock.now, timeScale })
  const progress = createProgress({ store, now: clock.now })
  const ctx = makeCtx({ timer, progress, llm })
  const engine = createEngine(ctx, { store, timer, progress, now: clock.now })
  return { clock, store, timer, progress, ctx, engine }
}

// ---------------------------------------------------------------------------
// 纯函数与常量
// ---------------------------------------------------------------------------

test('plugin: splitFlags 与文献插件同口径', () => {
  assert.deepEqual(splitFlags('25 --project p1 --stage s1'), { text: '25', flags: { project: 'p1', stage: 's1' } })
  assert.deepEqual(splitFlags('--project 构网型逆变器'), { text: '', flags: { project: '构网型逆变器' } })
  assert.deepEqual(splitFlags('  '), { text: '', flags: {} })
  assert.deepEqual(splitFlags('--flag'), { text: '', flags: { flag: true } })
})

test('plugin: fmtClock 覆盖 mm:ss / h:mm:ss / 异常值', () => {
  assert.equal(fmtClock(0), '00:00')
  assert.equal(fmtClock(9), '00:09')
  assert.equal(fmtClock(65), '01:05')
  assert.equal(fmtClock(25 * 60), '25:00')
  assert.equal(fmtClock(3600), '1:00:00')
  assert.equal(fmtClock(3725), '1:02:05')
  assert.equal(fmtClock(-10), '00:00')
  assert.equal(fmtClock('abc'), '00:00')
})

test('plugin: DEFAULTS 冻结且口径一致', () => {
  assert.equal(DEFAULTS.minutes, 25)
  assert.equal(DEFAULTS.model, 'deepseek-chat')
  assert.equal(Object.isFrozen(DEFAULTS), true)
  assert.equal(CARD_ID, 'research.timer')
  assert.equal(PLUGIN_ID, 'research-timer')
  // 版本号三方一致：代码常量 / package.json / 插件 manifest。
  // 不硬编码字面量——升版本时只改一处也不会断，但任何一处漏改这里立即红。
  const pkgVersion = JSON.parse(readFileSync(join(PROJECT_ROOT, 'package.json'), 'utf8')).version
  const manifest = JSON.parse(readFileSync(join(PLUGIN_DIR, 'plugin.json'), 'utf8'))
  assert.equal(TIMER_VERSION, pkgVersion)
  assert.equal(manifest.version, pkgVersion)
})

// ---------------------------------------------------------------------------
// 引擎装配：宿主注入优先，缺失自建兜底
// ---------------------------------------------------------------------------

test('plugin: ctx 带宿主引擎时，createEngine 直接用同一实例（一本账）', () => {
  const clock = makeClock()
  const store = createMemoryStore()
  const timer = createTimer({ store, now: clock.now })
  const progress = createProgress({ store, now: clock.now })
  const ctx = makeCtx({ timer, progress })
  const engine = createEngine(ctx)
  assert.equal(engine._internals.timer, timer, '必须用宿主装配的 timer，不能自建')
  assert.equal(engine._internals.progress, progress, '必须用宿主装配的 progress')
})

test('plugin: ctx 没有宿主引擎时自建兜底（裸注册表测试场景）', () => {
  const ctx = makeCtx({}) // timer/progress 都是 null
  const engine = createEngine(ctx)
  assert.ok(engine._internals.timer && typeof engine._internals.timer.tick === 'function')
  assert.ok(engine._internals.progress && typeof engine._internals.progress.summarizeDay === 'function')
  // 自建的引擎构造期不碰磁盘（读都是惰性的）
  assert.equal(typeof engine._internals.store.readState, 'function')
})

// ---------------------------------------------------------------------------
// 8 条命令
// ---------------------------------------------------------------------------

test('plugin: /start 25 开始计时，payload kind=status', async () => {
  const { engine } = setup()
  const r = await engine.start('25')
  assert.equal(r.ok, true)
  assert.equal(r.ui.kind, 'status')
  assert.equal(r.ui.snapshot.status, 'running')
  assert.equal(r.ui.snapshot.plannedSec, 1500)
  assert.equal(r.ui.snapshot.mode, 'pomodoro-25')
  assert.ok(r.text.includes('运行中'))
  assert.ok(r.text.includes('25:00'))
})

test('plugin: /start 无参数默认 25 分钟；/start 15 走预设', async () => {
  const { engine, timer } = setup()
  const r = await engine.start('')
  assert.equal(timer.status().plannedSec, 1500)
  assert.equal(r.ui.snapshot.mode, 'pomodoro-25')
  await engine.stop()
  await engine.start('15')
  assert.equal(timer.status().mode, 'pomodoro-15')
  assert.equal(timer.status().plannedSec, 900)
})

test('plugin: /start 非法时长给出 E_BAD_MINUTES（0 / 181 / 小数 / 负数）', async () => {
  // 口径说明（阶段 3.1）：/start 支持位置参数项目名后，首个 token 以数字开头才当
  // 分钟解析；'abc' 这类非数字 token 现在按项目名解析（见下一条 E_NO_PROJECT 用例）。
  const { engine } = setup()
  for (const bad of ['0', '181', '25.5', '-5']) {
    const r = await engine.start(bad)
    assert.equal(r.ok, false, `${bad} 应被拒`)
    assert.equal(r.code, 'E_BAD_MINUTES')
    assert.ok(r.text.includes('1~180'))
  }
  const st = await engine.status()
  assert.equal(st.ui.snapshot.status, 'idle', '被拒后不能留下任何会话')
})

test('plugin: /start --project 归类（id 或名称），并记忆上次项目', async () => {
  const { engine, ctx } = setup()
  const made = engine.project('new 构网型逆变器')
  assert.equal(made.ok, true)
  const pid = made.ui.projects[0].id
  const r = await engine.start(`25 --project ${pid}`)
  assert.equal(r.ok, true)
  assert.equal(r.ui.snapshot.projectId, pid)
  assert.equal(r.ui.projectName, '构网型逆变器')
  assert.ok(ctx._sets.some(([k, v]) => k === 'lastProjectId' && v === pid), '归类选择要记忆，下次可省略')

  await engine.stop()
  // 按名称也能解析
  const r2 = await engine.start('25 --project 构网型逆变器')
  assert.equal(r2.ui.snapshot.projectId, pid)
})

test('plugin: /start --stage 与 --project 联动，阶段不存在报 E_NO_STAGE', async () => {
  const { engine } = setup()
  const made = engine.project('new 课题甲')
  const pid = made.ui.projects[0].id
  engine.project(`add-stage ${pid} 文献调研`)
  const stages = engine.project('list').ui.projects[0].stages
  assert.equal(stages.length, 1)
  assert.equal(stages[0].name, '文献调研')
  const r = await engine.start(`25 --project ${pid} --stage ${stages[0].id}`)
  assert.equal(r.ok, true)
  assert.equal(r.ui.stageName, '文献调研')
  await engine.stop()
  const bad = await engine.start(`25 --project ${pid} --stage 不存在`)
  assert.equal(bad.code, 'E_NO_STAGE')
})

test('plugin: /start 位置参数形式（/start [分钟] <项目> [<阶段>]，任务书字面）', async () => {
  const { engine, ctx } = setup()
  const made = engine.project('new gfm 电网构网型逆变器惯量支撑')
  assert.equal(made.ok, true)
  const pid = made.ui.projects[0].id
  assert.equal(pid, 'gfm', '显式 id 必须生效')
  engine.project('add-stage gfm 文献综述')

  // /start gfm 文献综述：默认 25 分钟 + 项目 + 阶段（中文名直接打，不用旗标）
  const r1 = await engine.start('gfm 文献综述')
  assert.equal(r1.ok, true, r1.text)
  assert.equal(r1.ui.snapshot.projectId, 'gfm')
  assert.equal(r1.ui.snapshot.stageId, 's1')
  assert.equal(r1.ui.projectName, '电网构网型逆变器惯量支撑')
  assert.equal(r1.ui.stageName, '文献综述')
  assert.equal(r1.ui.snapshot.plannedSec, 1500)
  await engine.stop()

  // /start 25 gfm 文献综述：分钟 + 位置参数
  const r2 = await engine.start('25 gfm 文献综述')
  assert.equal(r2.ui.snapshot.plannedSec, 1500)
  assert.equal(r2.ui.snapshot.stageId, 's1')
  await engine.stop()

  // /start gfm：只给项目（无阶段）
  const r3 = await engine.start('gfm')
  assert.equal(r3.ui.snapshot.projectId, 'gfm')
  assert.equal(r3.ui.snapshot.stageId, null)
  await engine.stop()

  // 位置参数记进"上次选择"：之后 /start 25 沿用
  await engine.start('gfm 文献综述')
  await engine.stop()
  assert.ok(ctx._sets.some(([k, v]) => k === 'lastProjectId' && v === 'gfm'))
  const r4 = await engine.start('25')
  assert.equal(r4.ui.snapshot.projectId, 'gfm', '省略归类时沿用上次')
  await engine.stop()

  // 多余位置参数 -> E_BAD_ARGS（不猜用户想干什么）
  const bad = await engine.start('25 gfm 文献综述 多余')
  assert.equal(bad.code, 'E_BAD_ARGS')

  // 非数字首个 token 不再当时长解析，而是项目名 -> 项目不存在 E_NO_PROJECT
  const ghost = await engine.start('abc')
  assert.equal(ghost.code, 'E_NO_PROJECT')
})

test('plugin: /project new 显式 id（<id> <名称>）与自动推导并存', () => {
  const { engine } = setup()
  // 显式 id（任务书字面：/project new gfm "电网构网型逆变器惯量支撑"）
  const r = engine.project('new gfm 电网构网型逆变器惯量支撑')
  assert.equal(r.ok, true)
  assert.equal(r.ui.projects[0].id, 'gfm')
  assert.equal(r.ui.projects[0].name, '电网构网型逆变器惯量支撑')
  // 单参数（含中文名）仍走自动推导，不被当 id
  const r2 = engine.project('new 配电网承载力评估')
  assert.equal(r2.ui.projects[1].id !== 'gfm', true)
  assert.equal(r2.ui.projects[1].name, '配电网承载力评估')
  // 重复 id -> E_PROJECT_EXISTS
  const dup = engine.project('new gfm 另一个项目')
  assert.equal(dup.ok, false)
  assert.equal(dup.code, 'E_PROJECT_EXISTS')
})

test('plugin: /project done 记录里程碑（阶段级；两参数语义不变）', () => {
  const { engine } = setup()
  engine.project('new gfm 电网构网型逆变器惯量支撑')
  engine.project('add-stage gfm 文献综述')
  // 阶段完成 + 里程碑（任务书字面：/project done gfm 文献综述 <milestone>）
  const done = engine.project('done gfm 文献综述 完成 12 篇文献精读与综述初稿')
  assert.equal(done.ok, true)
  assert.ok(done.text.includes('已标记阶段完成'))
  assert.ok(done.text.includes('里程碑：完成 12 篇文献精读与综述初稿'))
  const stage = done.ui.projects[0].stages[0]
  assert.equal(stage.done, true)
  assert.equal(stage.milestone, '完成 12 篇文献精读与综述初稿')
  // 阶段完成不带里程碑：字段为 null（旧形状不变）
  engine.project('add-stage gfm 算例复现')
  const plain = engine.project('done gfm 算例复现')
  assert.equal(plain.ui.projects[0].stages[1].milestone, null)
  // 两参数语义保持阶段 3 口径：done <项目> = 项目完成，done <项目> <阶段> = 阶段完成
  const doneAll = engine.project('done gfm')
  assert.equal(doneAll.ui.projects[0].done, true)
  assert.equal(doneAll.ui.projects[0].milestone, null)
  // 新项目 payload 的 milestone 默认 null
  const fresh = engine.project('new 无里程碑项目')
  assert.equal(fresh.ui.projects[1].milestone, null)
})

test('plugin: /project add-stage 支持项目名称引用（与命令描述 <项目id|名称> 一致）', () => {
  const { engine } = setup()
  engine.project('new 备赛')
  // GUI 取证实测（stage32 截图补拍）的回归：名称引用曾被直传 store 的严格 id 断言 → E_BAD_ID，
  // 而命令描述承诺 <项目id|名称>。现在与 /start 位置参数、/project done 同一解析口径。
  const byName = engine.project('add-stage 备赛 写作')
  assert.equal(byName.ok, true, byName.text || byName.error)
  const st = byName.ui.projects.find((p) => p.name === '备赛')
  assert.deepEqual(st.stages.map((s) => s.name), ['写作'])
  // 不存在的项目 → 可读的 E_NO_PROJECT，而不是 store 层的 E_BAD_ID
  const missing = engine.project('add-stage 不存在的项目 写作')
  assert.equal(missing.ok, false)
  assert.equal(missing.code, 'E_NO_PROJECT')
  assert.match(missing.text, /项目不存在/)
})

test('plugin: 加速测试模式显式提示（timeScale≠1，start/status/cardBody 三处）', async () => {
  const scaled = setup({ timeScale: 60 })
  const r = await scaled.engine.start('1')
  assert.equal(r.ok, true)
  assert.ok(r.text.includes('加速测试模式'), 'start 必须显式提示')
  assert.ok(r.text.includes('RESEARCH_ORB_TIME_SCALE=60'))
  assert.ok(r.text.includes('不计入进度汇总与日报统计'))
  const s = await scaled.engine.status()
  assert.ok(s.text.includes('加速测试模式'), 'status 也要提示')
  assert.equal(s.ui.timeScale, 60, 'payload 带 timeScale 供面板显示')
  const body = scaled.engine.cardBody()
  assert.ok(body.includes('加速测试模式'), '卡片正文也要提示')
  await scaled.engine.stop()

  // scale=1（真实路径）不出现提示，文案与阶段 3 逐字一致
  const real = setup({ timeScale: 1 })
  const r2 = await real.engine.start('1')
  assert.ok(!r2.text.includes('加速测试模式'))
  const s2 = await real.engine.status()
  assert.ok(!s2.text.includes('加速测试模式'))
  assert.ok(!real.engine.cardBody().includes('加速测试模式'))
  await real.engine.stop()
})

test('plugin: data/projects 缺失时 /status /today /cardBody /project list 空态友好', async () => {
  // 内存 store 不建任何项目 —— 等价于 data\projects 目录不存在
  // （默认 store 的 listProjects 在目录缺失时返回 []，readProject 返回 null）
  const { engine, store } = setup()
  store.appendDay(DAY, { type: 'segment', ts: new Date(T0).toISOString(), dayKey: DAY, sec: 300, kind: 'focus', sessionId: 't-x', projectId: 'ghost' })
  store.appendDay(DAY, { type: 'start', ts: new Date(T0).toISOString(), sessionId: 't-x', projectId: 'ghost', timeScale: 1 })

  const s = await engine.status()
  assert.equal(s.ok, true, 'projects 缺失不得让 /status 报错')
  assert.ok(s.text.includes('今日'), s.text)

  const t = await engine.today()
  assert.equal(t.ok, true, 'projects 缺失不得让 /today 报错')
  assert.ok(t.ui.markdown.includes('ghost（项目已删除）'), '账本里的项目标注"已删除"，不得抛异常')

  assert.doesNotThrow(() => engine.cardBody())

  const list = engine.project('list')
  assert.equal(list.ok, true)
  assert.ok(list.text.includes('还没有项目'))
})

test('plugin: /start 项目不存在报 E_NO_PROJECT；运行中再 /start 报 E_TIMER_RUNNING', async () => {
  const { engine } = setup()
  const noProj = await engine.start('25 --project ghost')
  assert.equal(noProj.code, 'E_NO_PROJECT')
  assert.ok(noProj.text.includes('/project new'))
  await engine.start('25')
  const dup = await engine.start('15')
  assert.equal(dup.ok, false)
  assert.equal(dup.code, 'E_TIMER_RUNNING')
  assert.ok(dup.text.includes('/stop'))
})

test('plugin: /pause → /resume → /stop 全流程，stop 汇总已专注', async () => {
  // 默认 timeScale=1：虚拟时钟推进多少真实毫秒就是多少计时秒
  const { clock, engine, timer } = setup()
  await engine.start('1') // 1 分钟 = 60 秒
  clock.advance(30_000) // 专注 30 秒
  const p = await engine.pause()
  assert.equal(p.ui.snapshot.status, 'paused')
  assert.equal(p.ui.snapshot.accumulatedSec, 30)
  const r = await engine.resume()
  assert.equal(r.ui.snapshot.status, 'running')
  clock.advance(30_000) // 再 30 秒
  const s = await engine.stop()
  assert.equal(s.ok, true)
  assert.equal(s.ui.kind, 'status')
  assert.equal(s.ui.snapshot.status, 'idle')
  assert.ok(s.text.includes('已收尾'))
  assert.ok(s.text.includes('1 分钟'))
  assert.equal(timer.status().lastStop.totalSec, 60)
  assert.equal(timer.status().lastStop.completed, true)
})

test('plugin: /pause /resume /stop 在错误态下给中文错误码', async () => {
  const { engine } = setup()
  const p = await engine.pause()
  assert.equal(p.code, 'E_TIMER_NOT_RUNNING')
  const r = await engine.resume()
  assert.equal(r.code, 'E_TIMER_NOT_PAUSED')
  const s = await engine.stop()
  assert.equal(s.code, 'E_TIMER_NOT_RUNNING')
  assert.ok(s.text.includes('没有'))
})

test('plugin: /status 带今日摘要（专注 / 会话 / 卡片 / bib 计数）', async () => {
  const { engine, store, clock } = setup()
  await engine.start('25')
  clock.advance(60_000)
  await engine.stop()
  store._setOutputs(DAY, { cards: [{ rel: 'data/notes/a.md', mtimeMs: T0 }], bib: [{ rel: 'data/exports/r.bib', mtimeMs: T0 }] })
  const s = await engine.status()
  assert.equal(s.ok, true)
  assert.equal(s.ui.kind, 'status')
  assert.equal(s.ui.today.dayKey, DAY)
  assert.equal(s.ui.today.focusSec, 60)
  assert.equal(s.ui.today.sessionCount, 1)
  assert.equal(s.ui.today.cards, 1)
  assert.equal(s.ui.today.bib, 1)
  assert.ok(s.text.includes('新增卡片 1'))
  assert.ok(s.text.includes('新增 bib 1'))
  assert.ok(s.text.includes('通知提醒：开'))
})

test('plugin: /today 生成日报，payload kind=report/scope=daily', async () => {
  const { engine, store } = setup()
  await engine.start('25')
  store._setOutputs(DAY, { cards: [{ rel: 'data/notes/gfm/a.md', mtimeMs: T0 }], bib: [] })
  const r = await engine.today()
  assert.equal(r.ok, true)
  assert.equal(r.ui.kind, 'report')
  assert.equal(r.ui.scope, 'daily')
  assert.equal(r.ui.dayKey, DAY)
  assert.ok(r.ui.markdown.includes(`# 科研日报 · ${DAY}`))
  assert.ok(r.ui.markdown.includes('`data/notes/gfm/a.md`'))
  assert.equal(r.ui.polished, false) // 没注入 llm -> 纯模板
  assert.ok(r.text.includes('日报已生成'))
  assert.ok(r.text.includes('纯模板'))
  assert.ok(r.text.includes('新增卡片 1'))
  // 真的写进了 store（内存）
  assert.ok(store.readReport('daily', DAY))
  assert.ok(r.ui.reportPath.endsWith(`daily-${DAY}.md`))
  assert.ok(!r.ui.reportPath.includes('\\'), '面板只出现相对路径')
})

test('plugin: /today 有可用 llm 时带 AI 复盘；llm 炸了回落纯模板', async () => {
  const good = setup({ llm: fakeLlm('今日投入 25 分钟，集中在构网型逆变器，建议下周补一次稳定性算例。') })
  const r1 = await good.engine.today()
  assert.equal(r1.ok, true)
  assert.equal(r1.ui.polished, true)
  assert.ok(r1.ui.markdown.includes('建议下周补一次稳定性算例'))
  assert.ok(r1.text.includes('含 AI 复盘'))

  const bad = setup({ llm: brokenLlm() })
  const r2 = await bad.engine.today()
  assert.equal(r2.ok, true, 'LLM 失败不该让 /today 失败')
  assert.equal(r2.ui.polished, false)
  assert.ok(r2.ui.markdown.includes('AI 复盘未启用或生成失败'))
  assert.ok(r2.text.includes('纯模板'))
})

test('plugin: /weekly 生成本周周报，payload kind=report/scope=weekly', async () => {
  const { engine, store } = setup()
  // 周一（2026-01-12）记一段
  store.appendDay('2026-01-12', { type: 'segment', ts: new Date(T0).toISOString(), sec: 900 })
  const r = await engine.weekly()
  assert.equal(r.ok, true)
  assert.equal(r.ui.kind, 'report')
  assert.equal(r.ui.scope, 'weekly')
  assert.equal(r.ui.weekKey, '2026-01-12')
  assert.ok(r.ui.markdown.includes('# 科研周报 · 2026-01-12 ~ 2026-01-18'))
  assert.ok(r.ui.markdown.includes('## 二、每日明细'))
  assert.ok(r.text.includes('周报已生成'))
  assert.ok(store.readReport('weekly', '2026-01-12'))
})

test('plugin: /project new / add-stage / done / list 全链路', () => {
  const { engine } = setup()
  const empty = engine.project('list')
  assert.equal(empty.ok, true)
  assert.equal(empty.ui.kind, 'projects')
  assert.ok(empty.text.includes('/project new'))

  const made = engine.project('new 惯量支撑课题')
  assert.equal(made.ok, true)
  assert.equal(made.ui.projects.length, 1)
  assert.equal(made.ui.projects[0].name, '惯量支撑课题')
  assert.ok(made.text.includes('/start 25 --project'))

  const staged = engine.project(`add-stage ${made.ui.projects[0].id} 数据清洗`)
  assert.equal(staged.ok, true)
  assert.equal(staged.ui.projects[0].stages.length, 1)

  const badStage = engine.project(`add-stage ${made.ui.projects[0].id}`)
  assert.equal(badStage.code, 'E_BAD_ARGS')

  const done = engine.project(`done ${made.ui.projects[0].id} 数据清洗`)
  assert.equal(done.ok, true)
  assert.equal(done.ui.projects[0].stages[0].done, true)
  assert.ok(done.text.includes('已标记阶段完成'))

  const doneAll = engine.project(`done ${made.ui.projects[0].id}`)
  assert.equal(doneAll.ui.projects[0].done, true)

  const noName = engine.project('new')
  assert.equal(noName.code, 'E_BAD_NAME')
  const noRef = engine.project('done')
  assert.equal(noRef.code, 'E_BAD_ARGS')
  const unknown = engine.project('done 不存在项目')
  assert.equal(unknown.ok, false)
})

test('plugin: 命令错误都走 {ok:false, code, text}，不抛异常', async () => {
  const { engine } = setup()
  const cases = [await engine.start('999'), await engine.pause(), await engine.resume(), await engine.stop()]
  for (const c of cases) {
    assert.equal(c.ok, false)
    assert.equal(typeof c.code, 'string')
    assert.equal(typeof c.text, 'string')
  }
})

test('plugin: cardBody 含当前态与命令清单', () => {
  const { engine, store } = setup()
  store._setOutputs(DAY, { cards: [{ rel: 'data/notes/a.md', mtimeMs: T0 }], bib: [] })
  engine.start // 同步方法也要能取到（cardBody 不落盘）
  const body = engine.cardBody()
  assert.ok(body.includes('番茄钟 15/25/45'))
  assert.ok(body.includes('空闲'))
  assert.ok(body.includes('/start /pause /resume /stop /status /today /weekly /project'))
})

// ---------------------------------------------------------------------------
// activate：注册契约 + 零写盘
// ---------------------------------------------------------------------------

test('plugin: activate 注册 1 张卡片 + 8 条命令', async () => {
  const cards = []
  const commands = []
  const ctx = makeCtx({})
  ctx.ui = { registerCard: (c) => cards.push(c), registerCommand: (c) => commands.push(c) }
  const handle = await activate(ctx)
  assert.equal(cards.length, 1)
  assert.equal(cards[0].id, CARD_ID)
  assert.equal(cards[0].title, '计时')
  assert.deepEqual(cards[0].actions, ['status', 'today', 'weekly', 'project'])
  assert.ok(cards[0].body.includes('/start'))
  assert.deepEqual(
    commands.map((c) => c.name).sort(),
    ['pause', 'project', 'resume', 'start', 'status', 'stop', 'today', 'weekly'],
  )
  for (const c of commands) {
    assert.equal(typeof c.run, 'function')
    assert.ok(c.description && c.description.length > 0, `${c.name} 缺少用法说明`)
  }
  assert.equal(typeof handle.deactivate, 'function')
  // 引擎用宿主注入的实例（这里 ctx 没给 -> 自建兜底）
  assert.ok(handle.engine._internals.timer)
  handle.deactivate() // 不抛即通过
})

test('plugin: activate 用宿主注入的引擎，停用不影响进行中的计时', async () => {
  const clock = makeClock()
  const store = createMemoryStore()
  const timer = createTimer({ store, now: clock.now })
  const progress = createProgress({ store, now: clock.now })
  const ctx = makeCtx({ timer, progress })
  ctx.ui = { registerCard: () => {}, registerCommand: () => {} }
  await timer.start({ minutes: 25 }) // 宿主侧先开一个计时
  const handle = await activate(ctx)
  assert.equal(handle.engine._internals.timer, timer, 'activate 必须复用宿主引擎')
  handle.deactivate()
  // 插件停用后账本还在 core：tick / stop 照常
  clock.advance(60_000)
  timer.tick()
  const out = timer.stop({ reason: 'after-deactivate' })
  assert.equal(out.summary.totalSec, 60)
  assert.equal(store.readDay(DAY).filter((r) => r.type === 'segment').length, 1)
})

/** data/ 下阶段 3 四个目录的快照（文件名 + mtime），用于零写盘作证。 */
function diskSnapshot() {
  const out = {}
  for (const [name, dir] of [['timer', TIMER_DIR], ['progress', PROGRESS_DIR], ['reports', REPORTS_DIR], ['projects', PROJECTS_DIR]]) {
    try {
      out[name] = readdirSync(dir)
        .map((n) => `${n}:${statSync(join(dir, n)).mtimeMs}`)
        .sort()
    } catch {
      out[name] = null
    }
  }
  return out
}

test('plugin: activate 零写盘（data 四目录前后快照一致）', async () => {
  const before = diskSnapshot()
  const cmds = []
  const ctx = makeCtx({})
  ctx.ui = { registerCard: () => {}, registerCommand: (c) => cmds.push(c) }
  const handle = await activate(ctx)
  // 只读命令也验证一下：/status 与 /project list 不允许写任何字节
  const statusCmd = cmds.find((c) => c.name === 'status')
  const projectCmd = cmds.find((c) => c.name === 'project')
  const s = await statusCmd.run('')
  assert.equal(s.ok, true)
  const p = await projectCmd.run('list')
  assert.equal(p.ok, true)
  handle.deactivate()
  const after = diskSnapshot()
  assert.deepEqual(after, before, 'activate 与只读命令不得改动 data/ 任何文件')
})

test('plugin: 注册的 run 包装返回 {text, ui, ok, code} 四件套', async () => {
  const clock = makeClock()
  const store = createMemoryStore()
  const timer = createTimer({ store, now: clock.now })
  const progress = createProgress({ store, now: clock.now })
  const ctx = makeCtx({ timer, progress })
  const cmds = []
  ctx.ui = { registerCard: () => {}, registerCommand: (c) => cmds.push(c) }
  await activate(ctx)
  const startCmd = cmds.find((c) => c.name === 'start')
  const stopCmd = cmds.find((c) => c.name === 'stop')
  const out = await startCmd.run('25')
  assert.equal(out.ok, true)
  assert.equal(typeof out.text, 'string')
  assert.equal(out.ui.kind, 'status')
  assert.equal(out.code, null)
  // 运行中再 start -> 错误透传（此时还没 stop）
  const dup = await startCmd.run('15')
  assert.equal(dup.ok, false)
  assert.equal(dup.code, 'E_TIMER_RUNNING')
  // stop 之后正常收尾
  const out2 = await stopCmd.run('')
  assert.equal(out2.ok, true)
})

// ---------------------------------------------------------------------------
// 源码纪律
// ---------------------------------------------------------------------------

function listPluginSources(dir) {
  const out = []
  for (const name of readdirSync(dir)) {
    const p = join(dir, name)
    if (statSync(p).isDirectory()) out.push(...listPluginSources(p))
    else if (/\.(mjs|js|json)$/.test(name)) out.push(p)
  }
  return out
}

/** 剥掉块注释与行注释再扫描 —— 否则"本插件不 import node:fs"的说明文字会被误伤。 */
function stripComments(src) {
  return src
    .replace(/\/\*[\s\S]*?\*\//g, '')
    .replace(/(^|[^:'"`])\/\/[^\n]*/g, '$1')
}

test('discipline: 插件源码没有第二条落盘/出网/定时器出口', () => {
  const files = listPluginSources(PLUGIN_DIR)
  assert.ok(files.length >= 2, `插件源文件数偏少：${files.length}`)
  for (const f of files) {
    if (f.endsWith('.json')) continue
    const src = stripComments(readFileSync(f, 'utf8'))
    for (const banned of ["from 'node:fs'", 'from "node:fs"', "require('node:fs')", "require('fs')", 'fetch\\s*\\(', 'XMLHttpRequest']) {
      assert.ok(!new RegExp(banned).test(src), `${f} 出现 ${banned}`)
    }
    for (const banned of ['writeFileSync', 'appendFileSync', 'createWriteStream', 'mkdirSync', 'rmSync', 'unlinkSync']) {
      assert.ok(!new RegExp(`\\b${banned}\\b`).test(src), `${f} 出现 ${banned} —— 写必须经 core 引擎的 store`)
    }
    assert.ok(!/process\.env/.test(src), `${f} 不得读环境变量（timeScale 只在 core-host 读）`)
    assert.ok(!/\bsetInterval\b|\bsetTimeout\b/.test(src), `${f} 不得自设定时器（节拍在主进程）`)
  }
})

test('discipline: 插件所有落盘都经 core 引擎的 store（import 面干净）', () => {
  const src = readFileSync(join(PLUGIN_DIR, 'index.mjs'), 'utf8')
  // 只允许从 core 引擎与自身 lib 导入
  const imports = [...src.matchAll(/from\s+'([^']+)'/g)].map((m) => m[1])
  for (const i of imports) {
    assert.ok(
      /^\.\.\/\.\.\/core\/src\//.test(i) || /^\.\/lib\//.test(i),
      `index.mjs 出现预期之外的 import：${i}`,
    )
  }
  // timer/progress/report 三个引擎都要用到
  assert.ok(imports.some((i) => i.endsWith('timer.mjs')))
  assert.ok(imports.some((i) => i.endsWith('progress.mjs')))
  assert.ok(imports.some((i) => i.endsWith('report.mjs')))
  assert.ok(imports.some((i) => i.endsWith('timer-store.mjs')))
})

test('plugin: dayKeyOf 本地时区口径与日报日期键一致', async () => {
  const { engine, store } = setup()
  assert.equal(dayKeyOf(T0), DAY)
  store._setOutputs(DAY, { cards: [], bib: [] })
  await engine.start('25')
  const r = await engine.today()
  assert.equal(r.ui.dayKey, DAY)
})
