// tests/perception-collector.test.mjs
//
// Pure-node contract tests for the perception collection layer.
// ZERO real PowerShell, ZERO real process spawning: every scenario injects a
// fake spawn / fake isAlive so `node --test tests/perception-collector.test.mjs`
// is deterministic and Electron-free.

import test from 'node:test'
import assert from 'node:assert/strict'
import { EventEmitter } from 'node:events'
import { PassThrough } from 'node:stream'

import {
  startCollector,
  parseLine,
  listOwnPowershell,
} from '../packages/plugins/perception/collector.mjs'

// ---------------------------------------------------------------------------
// Fake child process (stands in for the real powershell.exe child).
// - is an EventEmitter (has .on / .emit like ChildProcess)
// - has .stdout (PassThrough, supports setEncoding + write)
// - has .kill() that flips a flag and (optionally) notifies a liveness map
// ---------------------------------------------------------------------------
function makeFakeChild({ pid = 1234, autoExit = false, exitCode = 1, aliveMap = null } = {}) {
  const child = new EventEmitter()
  const stdout = new PassThrough()
  const stderr = new PassThrough()
  child.stdout = stdout
  child.stderr = stderr
  child.pid = pid
  child.killed = false
  child.kill = function () {
    this.killed = true
    if (aliveMap) aliveMap[pid] = false
    setImmediate(() => this.emit('exit', null, 'SIGTERM'))
  }
  if (autoExit) {
    setImmediate(() => child.emit('exit', exitCode, null))
  }
  return child
}

function sampleLine(over = {}) {
  const obj = {
    ts: 1730000000000,
    hwnd: 123456,
    pid: 4321,
    process: 'msedge',
    title: 'hello',
    idleMs: 1500,
    isFullscreen: false,
    monitorId: '\\.\\DISPLAY1',
    ...over,
  }
  return JSON.stringify(obj)
}

// ---------------------------------------------------------------------------
// T1: parseLine happy path
// ---------------------------------------------------------------------------
test('parseLine: valid JSONL line -> ok:true with sample', () => {
  const r = parseLine(sampleLine())
  assert.equal(r.ok, true)
  assert.equal(r.sample.process, 'msedge')
  assert.equal(r.sample.pid, 4321)
  assert.equal(r.sample.idleMs, 1500)
  assert.equal(r.sample.isFullscreen, false)
  assert.equal(r.sample.monitorId, '\\.\\DISPLAY1')
})

// ---------------------------------------------------------------------------
// T2: parseLine fault tolerance (never throws)
// ---------------------------------------------------------------------------
test('parseLine: malformed input -> ok:false, never throws', () => {
  assert.equal(parseLine('').ok, false) // empty
  assert.equal(parseLine('   ').ok, false) // whitespace only
  assert.equal(parseLine('not json at all').ok, false) // invalid json
  assert.equal(parseLine('{"foo":1}').ok, false) // missing fields
  assert.equal(parseLine('[1,2,3]').ok, false) // array, not object
  assert.equal(parseLine('null').ok, false) // null
  // BOM-only line (a stray artifact) -> empty after strip -> ok:false
  assert.equal(parseLine('﻿').ok, false)
  // BOM + invalid json -> ok:false
  assert.equal(parseLine('﻿garbage').ok, false)
  // missing a required field
  const missing = parseLine(JSON.stringify({ ts: 1, hwnd: 2, pid: 3, process: 'x', title: 't', idleMs: 0, isFullscreen: false }))
  assert.equal(missing.ok, false)
  assert.match(missing.reason, /missing-fields/)
  // wrong type
  const badType = parseLine(JSON.stringify({ ts: 1, hwnd: 2, pid: 3, process: 'x', title: 't', idleMs: 0, isFullscreen: 'no', monitorId: 'm' }))
  assert.equal(badType.ok, false)
  assert.match(badType.reason, /bad-type/)
  // robust: BOM + VALID json still parses (real-world stdout guard)
  const bomOk = parseLine('﻿' + sampleLine())
  assert.equal(bomOk.ok, true)
})

// ---------------------------------------------------------------------------
// T3: line buffering across chunk boundaries (multi-line + split line + CRLF)
// ---------------------------------------------------------------------------
test('collector: cross-chunk / multi-line / CRLF buffering', () => {
  const received = []
  const child = makeFakeChild({ pid: 8001 })
  const controller = startCollector({
    spawnImpl: () => child,
    onSample: (s) => received.push(s),
    baseDelay: 500,
  })

  // 1) two complete lines in one chunk (second uses CRLF)
  child.stdout.write(sampleLine({ pid: 11 }) + '\n' + sampleLine({ pid: 22 }) + '\r\n')
  // 2) a line split across two writes
  const big = sampleLine({ pid: 33 })
  child.stdout.write(big.slice(0, 20))
  child.stdout.write(big.slice(20) + '\n')
  // 3) stray empty lines / leading blank should be ignored
  child.stdout.write('\n   \n' + sampleLine({ pid: 44 }) + '\n')

  // allow microtask chunks to flush
  return new Promise((resolve) => {
    setImmediate(() =>
      setImmediate(() => {
        const pids = received.map((s) => s.pid).sort((a, b) => a - b)
        assert.deepEqual(pids, [11, 22, 33, 44])
        controller.stop()
        resolve()
      }),
    )
  })
})

// ---------------------------------------------------------------------------
// T4: unexpected exit -> exponential-backoff restart within 30s
// ---------------------------------------------------------------------------
test('collector: unexpected child exit triggers auto-restart (<=30s)', () => {
  let spawnCount = 0
  const pids = []
  const fakeSpawn = () => {
    spawnCount += 1
    const pid = 9000 + spawnCount
    pids.push(pid)
    return makeFakeChild({ pid, autoExit: true }) // dies immediately
  }

  const controller = startCollector({
    spawnImpl: fakeSpawn,
    baseDelay: 100, // fast first restart for the test
    onRestart: () => {},
  })

  return new Promise((resolve, reject) => {
    const guard = setTimeout(() => reject(new Error('no restart within 5s')), 5000)
    controller.on('restart', (info) => {
      clearTimeout(guard)
      assert.ok(info.restarts >= 1)
      assert.ok(spawnCount >= 2, 'a fresh child must have been spawned')
      assert.ok(info.delay >= 100 && info.delay <= 30000, 'backoff delay within bounds')
      assert.equal(controller.restartCount(), info.restarts)
      controller.stop()
      resolve()
    })
  })
})

// ---------------------------------------------------------------------------
// T5: stop() kills only our subtree, no residue, no restart
// ---------------------------------------------------------------------------
test('collector: stop() kills own pid tree, no residue, no restart', () => {
  const aliveMap = { 7001: true }
  const child = makeFakeChild({ pid: 7001, aliveMap })
  const killTreeCalls = []
  const controller = startCollector({
    spawnImpl: () => child,
    killTreeImpl: (pid) => killTreeCalls.push(pid),
    isAlive: (p) => !!aliveMap[p],
    baseDelay: 500,
  })

  assert.equal(controller.isRunning(), true)
  assert.equal(controller.pid(), 7001)

  const res = controller.stop()
  assert.equal(res.pid, 7001)
  assert.equal(child.killed, true, 'child.kill() was invoked')
  assert.deepEqual(killTreeCalls, [7001], 'tree kill used our own PID only')
  assert.equal(aliveMap[7001], false, 'liveness probe reports pid dead (no residue)')
  assert.equal(controller.isRunning(), false)
  assert.equal(controller.restartCount(), 0, 'stop must not schedule a restart')

  // residue self-check pure function agrees
  const check = listOwnPowershell([7001], (p) => !!aliveMap[p])
  assert.equal(check.allExited, true)
})

// ---------------------------------------------------------------------------
// T6: listOwnPowershell pure residue self-check
// ---------------------------------------------------------------------------
test('listOwnPowershell: reports alive vs exited across injected pids', () => {
  const state = { 1: true, 2: false, 3: true }
  const isAlive = (p) => !!state[p]
  const r1 = listOwnPowershell([1, 2, 3], isAlive)
  assert.equal(r1.allExited, false)
  assert.deepEqual(r1.alive.sort((a, b) => a - b), [1, 3])

  state[1] = false
  state[3] = false
  const r2 = listOwnPowershell([1, 2, 3], isAlive)
  assert.equal(r2.allExited, true)
  assert.deepEqual(r2.alive, [])

  // single pid (non-array) accepted
  const r3 = listOwnPowershell(1, () => false)
  assert.equal(r3.allExited, true)
})

// ---------------------------------------------------------------------------
// T7: onSample integration with a healthy fake child
// ---------------------------------------------------------------------------
test('collector: onSample receives parsed samples from healthy child', () => {
  const received = []
  const child = makeFakeChild({ pid: 8100 })
  const controller = startCollector({
    spawnImpl: () => child,
    onSample: (s) => received.push(s),
    baseDelay: 500,
  })
  child.stdout.write(sampleLine({ process: 'code', pid: 99 }) + '\n')
  return new Promise((resolve) => {
    setImmediate(() =>
      setImmediate(() => {
        assert.equal(received.length, 1)
        assert.equal(received[0].process, 'code')
        assert.equal(received[0].pid, 99)
        controller.stop()
        resolve()
      }),
    )
  })
})
