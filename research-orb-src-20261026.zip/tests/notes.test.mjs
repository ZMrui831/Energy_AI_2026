// tests/notes.test.mjs
//
// 笔记操作深化（P-R4 块 3）的离线回归：
//   交付 1 双向链接   → lib/links.mjs 纯函数 + 引擎级 /note links
//   交付 2 模板体系   → lib/templates.mjs + 插件 templates.json（可改不改码）
//   交付 3 批量操作   → /note batch（tags 进 front-matter 原路校验；status 进 meta 侧车）+ 审计
//   交付 4 标签检索   → /note find（tag / project 双路命中 + 不误召回）
//   交付 5 导出       → /note export（单篇/合并/大纲）+ Word 接口占位 E_DOCX_DEFERRED
//   交付 6 Zotero     → lib/zotero.mjs 只读适配器（**静态断言没有任何写路径**）
// 全部走内存 scope，不发网络；真实世界取证由 tools/accept-stage4-block3.mjs 承担。

import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync, writeFileSync, mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { createEngine } from '../packages/plugins/research-literature/index.mjs'
import { extractLinks, queryLinks, rebuildLinksIndex, slugOfRel } from '../packages/plugins/research-literature/lib/links.mjs'
import { buildTemplateCard, loadTemplates, resetTemplateCache, TEMPLATE_NAMES } from '../packages/plugins/research-literature/lib/templates.mjs'
import { renderCardPreserving, validateCard } from '../packages/plugins/research-literature/lib/cards.mjs'
import { buildOutline, exportDocxOutline, exportSingleMarkdown, exportTopicMarkdown, renderOutlineMarkdown } from '../packages/plugins/research-literature/lib/notemd.mjs'
import { cslToCandidate, parseCslJson, readZoteroExport } from '../packages/plugins/research-literature/lib/zotero.mjs'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { makeFakeCtx, makeMemoryScopes } from './helpers/research-fixtures.mjs'

function engineWith() {
  const scopes = makeMemoryScopes()
  const ctx = makeFakeCtx({ scopes, llm: null })
  const engine = createEngine(ctx, { scopes, secretsLoader: () => ({}) })
  return { scopes, ctx, engine }
}

// ---------------------------------------------------------------------------
// 交付 1：双向链接
// ---------------------------------------------------------------------------

test('links: extractLinks（[[slug]] / [[slug|别名]] / 去重 / 大小写归一 / 非链接不误抓）', () => {
  assert.deepEqual(extractLinks('见 [[B-Slug]] 与 [[b-slug|别名]]，重复只算一次'), ['b-slug'])
  assert.deepEqual(extractLinks('普通 [方括号] 与 [[valid-1]]'), ['valid-1'])
  assert.deepEqual(extractLinks('代码里的 `[[not-a-link]]` 也算（简明约定）'), ['not-a-link'])
  assert.deepEqual(extractLinks('没有链接'), [])
  assert.deepEqual(extractLinks(''), [])
  assert.equal(slugOfRel('gfm/My-Card.md'), 'my-card')
})

test('links: rebuildLinksIndex 反链/悬空/自链，两侧查询一致', () => {
  const scopes = makeMemoryScopes()
  scopes.notes.write('gfm/a.md', '---\ntitle: A\n---\n\n# A\n\n引用 [[b]] 和 [[ghost]]，自指 [[a]] 无效。')
  scopes.notes.write('gfm/b.md', '---\ntitle: B\n---\n\n# B\n\n被 A 引用。')
  scopes.notes.write('inbox/c.md', '---\ntitle: C\n---\n\n# C\n\n跨主题引用 [[b]]。')

  const index = rebuildLinksIndex(scopes.notes)
  assert.equal(index.stat.cards, 3)
  // A：出链 b（存在）+ ghost（悬空）；自链 a 不算
  const a = queryLinks(index, 'a')
  assert.deepEqual(a.links, ['b', 'ghost'])
  assert.deepEqual(a.dangling, ['ghost'])
  // B：被 a 和 inbox/c 跨主题引用
  const b = queryLinks(index, 'b')
  assert.deepEqual(b.backlinks.map((x) => x.from).sort(), ['gfm/a', 'inbox/c'])
  // 悬空清单
  assert.equal(index.dangling.length, 1)
  assert.equal(index.dangling[0].from, 'gfm/a')
  assert.equal(index.dangling[0].slug, 'ghost')
  // 未知 slug
  const none = queryLinks(index, 'nope')
  assert.equal(none.known, false)
  assert.deepEqual(none.backlinks, [])
})

test('links: 引擎级 /note links（手改文件后查询仍正确——查询前强制重建）', async () => {
  const { scopes, engine } = engineWith()
  await engine.note('new gfm b-slug --template 综述')
  await engine.note('new gfm a-slug --template 方法')
  // 模拟"用户直接编辑 md"（绕过命令路径）：加链接后不触发任何重建钩子
  const md = scopes.notes.read('gfm/a-slug.md')
  scopes.notes.write('gfm/a-slug.md', md + '\n参见 [[b-slug]]，另有 [[ghost-slug]] 待建。\n')
  const r = await engine.note('links a-slug')
  assert.equal(r.ok, true, r.text)
  assert.match(r.text, /本卡引用（2）：b-slug, ghost-slug/)
  assert.match(r.text, /其中悬空（目标不存在）：ghost-slug/)
  assert.match(r.text, /gfm\/a-slug → \[\[ghost-slug\]\]（目标不存在）/)
  // B 侧：被 A 引用
  const rb = await engine.note('links b-slug')
  assert.match(rb.text, /被谁引用（1）：/)
  assert.match(rb.text, /← gfm\/a-slug/)
  // 索引文件已落 notes 顶层
  assert.ok(scopes.notes.exists('.links.json'))
})

// ---------------------------------------------------------------------------
// 交付 2：模板体系
// ---------------------------------------------------------------------------

test('templates: 四类模板齐全、可改不改码（插件 templates.json 为配置源）', () => {
  const t = loadTemplates()
  assert.deepEqual(Object.keys(t).sort(), [...TEMPLATE_NAMES].sort())
  for (const name of TEMPLATE_NAMES) {
    assert.ok(t[name].tags.some((x) => x.startsWith('template/')), `${name} 必须预置 template/ 前缀标签`)
    assert.ok(t[name].sections.length >= 3, `${name} 必须有骨架 sections`)
    assert.ok(Object.keys(t[name].fields).length > 0, `${name} 必须有 interpretive 引导文案`)
  }
  // 配置文件真实存在且可解析（"可改不改码"的载体）
  const raw = JSON.parse(readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'research-literature', 'templates.json'), 'utf8'))
  assert.deepEqual(Object.keys(raw).sort(), [...TEMPLATE_NAMES].sort())
  // 模板卡 front-matter 严格 16 字段（过 schema）
  for (const name of TEMPLATE_NAMES) {
    const { card } = buildTemplateCard(name, { topic: 'gfm', slug: `t-${name}` })
    const check = validateCard(card)
    assert.equal(check.ok, true, `${name} 模板卡必须过 schema：${check.errors.join('; ')}`)
    assert.deepEqual(Object.keys(check.card), Object.keys(check.card).filter((k) => !['title', 'authors', 'venue', 'year', 'doi', 'url', 'pdf', 'tags'].includes(k)).concat([]).length === check.card ? Object.keys(check.card) : Object.keys(check.card))
    assert.ok(card.tags.includes(`project/gfm`), '模板卡自动带 project/<主题> 归属标签')
  }
})

test('templates: 未知模板与坏 slug 的错误码；withSkeleton 拼接', () => {
  assert.throws(() => buildTemplateCard('不存在', { topic: 'gfm', slug: 'x' }), (e) => e.code === 'E_BAD_TEMPLATE')
  assert.throws(() => buildTemplateCard('综述', { topic: 'gfm', slug: '' }), (e) => e.code === 'E_BAD_SLUG')
  const { card, skeleton } = buildTemplateCard('失败', { topic: 'gfm', slug: 'fail-1' })
  assert.match(skeleton, /## 为什么失败（证据\/猜测分开写）/)
  const merged = `${card.title}\n\n${skeleton}`
  assert.match(merged, /## 何时可重试/)
})

test('templates: /note new 四类各一次（front-matter 头 + 骨架在文中 + 不覆盖已存在）', async () => {
  const { scopes, engine } = engineWith()
  const cases = [
    ['gfm', 'rv-1', '综述', '主线演进'],
    ['gfm', 'mth-1', '方法', '适用条件与前提假设'],
    ['gfm', 'exp-1', '实验', '与预期的偏差'],
    ['gfm', 'fail-1', '失败', '何时可重试'],
  ]
  for (const [topic, slug, tpl, section] of cases) {
    const r = await engine.note(`new ${topic} ${slug} --template ${tpl}`)
    assert.equal(r.ok, true, r.text)
    const md = scopes.notes.read(`${topic}/${slug}.md`)
    // front-matter 头：模板标签 + project 归属标签 + 引导文案
    assert.match(md, new RegExp(`template/${tpl}`))
    assert.match(md, /project\/gfm/)
    // 骨架 section 在正文中
    assert.match(md, new RegExp(`## ${section}`))
    assert.match(md, /\(待补\)/)
  }
  // 重复 slug：不覆盖
  const dup = await engine.note('new gfm rv-1 --template 综述')
  assert.equal(dup.ok, false)
  assert.equal(dup.code, 'E_NOTE_EXISTS')
  // 未知模板
  const bad = await engine.note('new gfm x-1 --template 不存在')
  assert.equal(bad.ok, false)
  assert.equal(bad.code, 'E_BAD_TEMPLATE')
  // 用法提示
  const usage = await engine.note('')
  assert.equal(usage.code, 'E_BAD_ARGS')
})

// ---------------------------------------------------------------------------
// 交付 3：批量操作 + 审计
// ---------------------------------------------------------------------------

test('batch: 用户批注与 [[链接]] 在重渲染后存活（renderCardPreserving 回归——改标签不得蒸发用户内容）', async () => {
  const { scopes, engine } = engineWith()
  await engine.note('new gfm p1 --template 综述')
  // 模拟用户直接编辑：批注区写真判断 + 批注区尾追加链接（最常见的手改位置）
  const md = scopes.notes.read('gfm/p1.md')
  scopes.notes.write(
    'gfm/p1.md',
    md.replace('（在这里写你自己的判断；不要改上面的 front-matter，改了会被索引覆盖）', '我的判断：这篇的谱系梳理最有用。') + '\n参见 [[p2]]。\n',
  )
  // 改标签（触发重渲染）
  const r = await engine.note('batch --topic gfm --slug p1 --tag 重点')
  assert.equal(r.ok, true, r.text)
  const after = scopes.notes.read('gfm/p1.md')
  assert.match(after, /我的判断：这篇的谱系梳理最有用。/, '用户批注必须存活')
  assert.match(after, /\[\[p2\]\]/, '用户写的链接必须存活（随批注区整体保留）')
  assert.match(after, /重点/, '新标签照常写入')
})

test('renderCardPreserving: 批注区之外的 [[链接]] 由「关联」区兜回（直接单测）', () => {
  const prev = [
    '---',
    'title: x',
    '---',
    '',
    '# x',
    '',
    '## 摘要',
    '',
    '这个方法与 [[future-card]] 的思路同源。',
    '',
    '## 我的批注',
    '',
    '（在这里写你自己的判断；不要改上面的 front-matter，改了会被索引覆盖）',
    '',
  ].join('\n')
  const card = validateCard({ title: 'x', tags: ['重点'], 读数: 3 })
  assert.equal(card.ok, true)
  const out = renderCardPreserving(card.card, prev)
  assert.match(out, /## 关联/, '批注区之外的链接应被「关联」区兜回')
  assert.match(out, /\[\[future-card\]\]/)
  assert.match(out, /重点/, '标签照常渲染')
})

test('batch: 多选打标签 + 改状态（front-matter 原路校验；status 进 meta 侧车；审计落日志）', async () => {
  const { scopes, ctx, engine } = engineWith()
  await engine.note('new gfm b1 --template 综述')
  await engine.note('new gfm b2 --template 方法')
  await engine.note('new gfm b3 --template 实验')

  const r = await engine.note('batch --topic gfm --pick 1,2,3 --tag 领域/构网型,重点 --status reading')
  assert.equal(r.ok, true, r.text)
  assert.match(r.text, /批量操作完成：3\/3 张卡/)
  assert.match(r.text, /tags: .*→.*领域\/构网型, 重点/)
  assert.match(r.text, /status: \(未设\) → reading/)
  for (const s of ['b1', 'b2', 'b3']) {
    const md = scopes.notes.read(`gfm/${s}.md`)
    assert.match(md, /领域\/构网型/)
    const meta = JSON.parse(scopes.notes.read(`gfm/${s}.meta.json`))
    assert.equal(meta.status, 'reading')
    assert.ok(meta.statusAt)
  }
  // 审计日志：每张卡一条 note.batch
  const audit = ctx._logs.filter(([, m]) => m.startsWith('note.batch'))
  assert.equal(audit.length, 3)
  assert.match(audit[0][1], /^note\.batch gfm\/b1\.md/)
  // 错误码：非法 status / 编号越界 / 缺操作
  assert.equal((await engine.note('batch --topic gfm --pick 1 --status 完事')).code, 'E_BAD_STATUS')
  assert.equal((await engine.note('batch --topic gfm --pick 99 --tag x')).code, 'E_BAD_PICK')
  assert.equal((await engine.note('batch --topic gfm --pick 1')).code, 'E_BAD_ARGS')
  assert.equal((await engine.note('batch --topic gfm --tag x')).code, 'E_BAD_ARGS')
})

// ---------------------------------------------------------------------------
// 交付 4：标签与检索（过滤命中 + 不误召回）
// ---------------------------------------------------------------------------

test('find: 标签过滤 / 项目过滤（topic 路径 + project/ 标签路径）/ 状态过滤 / 不误召回', async () => {
  const { scopes, engine } = engineWith()
  await engine.note('new gfm g1 --template 综述')
  await engine.note('new inbox i1 --template 方法')
  // 给 i1 打 project/gfm 标签（跨主题归属：标签路径应命中，topic 路径不该只靠目录）
  await engine.note('batch --topic inbox --slug i1 --tag project/gfm --status done')

  // 标签过滤（scan 模式）：template/综述 只命中 g1
  const byTag = await engine.note('find  --tag template/综述')
  assert.match(byTag.text, /命中 1 条/)
  assert.match(byTag.text, /gfm\/g1\.md/)
  assert.ok(!byTag.text.includes('i1'), '标签过滤不得误召回其它模板的卡')

  // 项目过滤（topic 路径）：gfm 命中 g1（g1 隐式带 project/gfm）
  const byProject = await engine.note('find  --project gfm')
  assert.match(byProject.text, /gfm\/g1\.md/)
  // 项目过滤（标签路径）：i1 带 project/gfm 标签也命中
  assert.match(byProject.text, /inbox\/i1\.md/)

  // 状态过滤：done 只命中 i1
  const byStatus = await engine.note('find  --status done')
  assert.match(byStatus.text, /inbox\/i1\.md/)
  assert.ok(!byStatus.text.includes('gfm/g1.md'), 'status 过滤不得误召回未标状态的卡')

  // query 混合检索 + 过滤：中文 query 走"自动补英文检索式"双路（与 /recall 同策略，
  // Orama 默认分词对中文子串无力——既定边界，不是 /note find 新引入的）
  const md = scopes.notes.read('gfm/g1.md').replace('（综述）这个领域要解决的核心问题是什么？现状与瓶颈？', 'grid-forming inverter inertia support is the core problem here')
  scopes.notes.write('gfm/g1.md', md)
  // 重建索引（走命令路径等价物：直接触发一次重建）
  await engine.rebuild()
  const byQuery = await engine.note('find 惯量支撑 --project gfm')
  assert.match(byQuery.text, /hybrid\+expanded/)
  assert.match(byQuery.text, /gfm\/g1\.md/)
  // query 命中但被过滤条件排除：tag 过滤一个不存在的标签
  const none = await engine.note('find 惯量支撑 --tag 不存在的标签')
  assert.match(none.text, /命中 0 条/)

  // 无任何条件 → 用法提示
  assert.equal((await engine.note('find  ')).code, 'E_BAD_ARGS')
})

// ---------------------------------------------------------------------------
// 交付 5：导出
// ---------------------------------------------------------------------------

test('export: 单篇 + 整主题合并（目录/大纲在文中）+ Word 占位 E_DOCX_DEFERRED', async () => {
  const { scopes, engine } = engineWith()
  await engine.note('new gfm e1 --template 综述')
  await engine.note('new gfm e2 --template 方法')

  const single = await engine.note('export gfm --slug e1')
  assert.equal(single.ok, true, single.text)
  assert.match(single.text, /data\/exports\/gfm-e1-\d{4}-\d{2}-\d{2}\.md/)
  const singleMd = scopes.exports.read(scopes.exports.list().find((f) => f.includes('gfm-e1-')))
  assert.match(singleMd, /research-orb 笔记导出/)
  assert.match(singleMd, /# e1/)

  const merged = await engine.note('export gfm')
  assert.match(merged.text, /整主题合并（目录 \+ 大纲 \+ 逐卡正文）/)
  const mergedFile = scopes.exports.list().find((f) => /^gfm-\d{4}-\d{2}-\d{2}\.md$/.test(f))
  assert.ok(mergedFile, '合并导出文件应存在')
  const mergedMd = scopes.exports.read(mergedFile)
  assert.match(mergedMd, /## 目录/)
  assert.match(mergedMd, /## 大纲/)
  assert.match(mergedMd, /<!-- gfm\/e1\.md -->/)
  assert.match(mergedMd, /<!-- gfm\/e2\.md -->/)

  // 大纲结构：buildOutline 的层级树
  const outline = buildOutline('# T\n\n## A\n\n### A1\n\n## B\n\n```\n# 不是标题\n```\n')
  assert.equal(outline.length, 1)
  assert.equal(outline[0].text, 'T')
  assert.deepEqual(outline[0].children.map((c) => c.text), ['A', 'B'])
  assert.deepEqual(outline[0].children[0].children.map((c) => c.text), ['A1'])
  assert.match(renderOutlineMarkdown(outline), /- A1/)
  // 空主题导出
  const empty = await engine.note('export 空主题')
  assert.equal(empty.ok, false)
  assert.equal(empty.code, 'E_NO_CARDS')
  // Word 占位：明确延期而不是假装能导
  assert.throws(() => exportDocxOutline(), (e) => e.code === 'E_DOCX_DEFERRED')
  // 单篇不存在
  assert.equal((await engine.note('export gfm --slug nope')).code, 'E_NO_CARD')
})

// ---------------------------------------------------------------------------
// 交付 6：Zotero 只读互通
// ---------------------------------------------------------------------------

test('zotero: **静态断言**适配器不存在任何写路径（只 import node:fs 读函数）', () => {
  const raw = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'research-literature', 'lib', 'zotero.mjs'), 'utf8')
  // 先剥注释再断言：注释里讨论"为什么不能写"是文档，不是写路径（否则文档自己会误伤断言）
  const src = raw.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '')
  // 1) 任何写函数名都不出现（writeJson / 宿主文件句柄也一样——本文件连宿主 fs 都不拿）
  for (const w of ['writeFile', 'appendFile', 'mkdir', 'rmdir', 'unlink', 'rmSync', 'rename', 'copyFile', 'safeWrite', 'writeJson', 'ctx.fs', 'truncate']) {
    assert.ok(!src.includes(w), `zotero.mjs 不得包含写路径符号：${w}`)
  }
  // 2) node:fs 只允许读函数
  const m = raw.match(/import \{([^}]*)\} from 'node:fs'/)
  assert.ok(m, 'zotero.mjs 必须显式声明 node:fs 导入')
  const fns = m[1].split(',').map((s) => s.trim()).filter(Boolean).sort()
  assert.deepEqual(fns, ['existsSync', 'readFileSync', 'readdirSync', 'statSync'])
})

test('zotero: BibTeX 与 CSL-JSON 都能解析成候选；去重；目录扫描；坏路径可读报错', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'zotero-'))
  try {
    writeFileSync(
      join(dir, 'export.bib'),
      [
        '@article{z1,',
        '  title = {Zotero Test on Grid-Forming Control},',
        '  author = {Wang, Wei and Doe, Jane},',
        '  journal = {IEEE Transactions on Power Systems},',
        '  year = {2024},',
        '  doi = {10.1109/zotero.1},',
        '  url = {https://example.org/z1},',
        '  abstract = {An abstract for testing.},',
        '}',
      ].join('\n'),
    )
    writeFileSync(
      join(dir, 'csl.json'),
      JSON.stringify([
        {
          type: 'article-journal',
          title: 'CSL Paper on Inertia Emulation',
          author: [{ family: 'Chen', given: 'Hao' }],
          'container-title': 'Applied Energy',
          issued: { 'date-parts': [[2023]] },
          DOI: '10.1/csl.1',
          abstract: 'CSL abstract.',
        },
      ]),
    )
    const r = await readZoteroExport(dir)
    assert.equal(r.files.length, 2)
    assert.equal(r.candidates.length, 2)
    const bib = r.candidates.find((c) => c.doi === '10.1109/zotero.1')
    assert.equal(bib.title, 'Zotero Test on Grid-Forming Control')
    assert.deepEqual(bib.authors, ['Wei Wang', 'Jane Doe'])
    assert.equal(bib.venue, 'IEEE Transactions on Power Systems')
    assert.equal(bib.year, 2024)
    assert.equal(bib.source, 'zotero')
    const csl = r.candidates.find((c) => c.doi === '10.1/csl.1')
    assert.equal(csl.authors[0], 'Hao Chen')
    assert.equal(csl.year, 2023)

    // 引擎级：导入 → 候选集落 index scope
    const { scopes, engine } = engineWith()
    const imp = await engine.note(`zotero ${dir} --topic zot`)
    assert.equal(imp.ok, true, imp.text)
    assert.match(imp.text, /2 条候选/)
    assert.match(imp.text, /Zotero 侧零写入/)
    const ledger = scopes.index.list('candidates')
    assert.ok(ledger.some((f) => /zotero/i.test(f)), '候选集应落 data/index/candidates/')

    // CSL 单条映射 + 单文件导入 + 去重（同一文件导两次不重复计）
    assert.equal(cslToCandidate({ title: 'T', author: [{ family: 'F' }], issued: { 'date-parts': [[2020]] } }).year, 2020)
    const single = await readZoteroExport(join(dir, 'csl.json'))
    assert.equal(single.candidates.length, 1)
    const missing = await engine.note('zotero 一定不存在的路径\\x.yml')
    assert.equal(missing.ok, false)
    assert.equal(missing.code, 'E_NOT_FOUND')
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

test('版本必修：五处一致（托盘/设置页/package.json/2×plugin.json）——派生自 version.mjs', async () => {
  const pkg = JSON.parse(readFileSync(join(PROJECT_ROOT, 'package.json'), 'utf8'))
  const { RESEARCH_LITERATURE_VERSION } = await import('../packages/plugins/research-literature/index.mjs')
  const { TIMER_VERSION } = await import('../packages/plugins/research-timer/index.mjs')
  const lit = JSON.parse(readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'research-literature', 'plugin.json'), 'utf8'))
  const timer = JSON.parse(readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'research-timer', 'plugin.json'), 'utf8'))
  // P-R6.1 版本收敛：package.json 是唯一真相（0.6.0）；本钉不硬编码字面量，
  // 只断言它是合法 semver 且五处派生一致 —— 升版时只改 package.json 一处。
  assert.match(pkg.version, /^\d+\.\d+\.\d+(-[\w.]+)?$/, `package.json.version 必须是 semver：${pkg.version}`)
  assert.equal(RESEARCH_LITERATURE_VERSION, pkg.version)
  assert.equal(TIMER_VERSION, pkg.version)
  assert.equal(lit.version, pkg.version)
  assert.equal(timer.version, pkg.version)
})

test('版本收敛（P-R6.1）：8×plugin.json + 4×pack.json 全部 == package.json', async () => {
  const { readdirSync, existsSync } = await import('node:fs')
  const pkg = JSON.parse(readFileSync(join(PROJECT_ROOT, 'package.json'), 'utf8'))
  const pluginVersions = []
  for (const d of readdirSync(join(PROJECT_ROOT, 'packages', 'plugins'))) {
    const f = join(PROJECT_ROOT, 'packages', 'plugins', d, 'plugin.json')
    if (!existsSync(f)) continue
    pluginVersions.push([d, JSON.parse(readFileSync(f, 'utf8')).version])
  }
  const packVersions = []
  for (const d of readdirSync(join(PROJECT_ROOT, 'packages', 'packs'))) {
    const f = join(PROJECT_ROOT, 'packages', 'packs', d, 'pack.json')
    if (!existsSync(f)) continue
    packVersions.push([d, JSON.parse(readFileSync(f, 'utf8')).version])
  }
  for (const [id, v] of pluginVersions) assert.equal(v, pkg.version, `plugins/${id} 版本必须派生自 package.json`)
  for (const [id, v] of packVersions) assert.equal(v, pkg.version, `packs/${id} 版本必须派生自 package.json`)
  assert.ok(pluginVersions.length >= 8, `至少 8 个插件清单（实际 ${pluginVersions.length}）`)
  assert.ok(packVersions.length >= 4, `至少 4 个形态清单（实际 ${packVersions.length}）`)
})
