// tests/music-plugin.test.mjs
//
// S13「音乐律动光环」· B 路插件离线回归。
//
// 覆盖（对应任务书验收清单）：
//   1) activate 注册恰好 1 卡 1 命令，且把 ctx 交回宿主（handle.ctx）；
//   2) status / on / off / toggle / ambient / stations / play 在 stub 下行为正确且不抛；
//   3) ctx.core.music 为 null（裸 registry/宿主未接线）→ E_MUSIC_NO_DRIVER，不抛；
//   4) driver 方法抛异常 → E_MUSIC_COMMAND_FAILED，不抛到上层；
//   5) 每条审计带非空 pluginId（走真实 registry，读 data/logs/plugins.jsonl）；
//   6) 卡片正文与 status 文本是纯文本（电台名带 <b> 也不得出现 HTML 痕迹；源码禁 innerHTML）；
//   7) pack.json / plugin.json 声明契约 + pack UI 源码纪律（自包含/禁 focus/主题 token/静止纪律）。
//
// 全部内存桩，不碰真 Electron / 真 PowerShell / 真音频；唯一落盘是 registry 的
// plugins.jsonl 审计（与 plugins.test.mjs 同一模式，append-only）。

import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

import { activate, musicCommand, PLUGIN_ID, MUSIC_VERSION, MUSIC_CARD_ID } from '../packages/plugins/music/index.mjs'
import { makeFakeCtx } from './helpers/research-fixtures.mjs'
import { createRegistry, PLUGIN_LOG } from '../packages/plugins/index.mjs'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const PLUGIN_DIR = join(PROJECT_ROOT, 'packages', 'plugins', 'music')
const PACK_JSON = join(PROJECT_ROOT, 'packages', 'packs', 'research', 'pack.json')
const PACK_MUSIC_UI = join(PROJECT_ROOT, 'packages', 'packs', 'research', 'ui', 'music.js')

// ---------------------------------------------------------------------------
// 桩：A 路 driver（契约 §3 的形状），可注入失败点
// ---------------------------------------------------------------------------

function makeMusicStub(overrides = {}) {
  const calls = []
  const state = Object.assign(
    {
      enabled: false,
      networkEnabled: false,
      source: 'ambient',
      station: null,
      playing: false,
      level: 0,
      degraded: false,
      reason: null,
      stationCount: 0,
    },
    overrides.state || {},
  )
  const api = {
    calls,
    state: () => ({ ...state }),
    setEnabled(v) {
      calls.push(['setEnabled', v])
      state.enabled = v === true
      if (!state.enabled) state.playing = false
    },
    setNetworkEnabled(v) {
      calls.push(['setNetworkEnabled', v])
      state.networkEnabled = v === true
    },
    setVolume(v) { calls.push(['setVolume', v]) },
    playAmbient() {
      calls.push(['playAmbient'])
      state.playing = true
      state.source = 'ambient'
      state.station = null
    },
    stopMusic() {
      calls.push(['stopMusic'])
      state.playing = false
    },
    async listStations() {
      calls.push(['listStations'])
      return (
        overrides.stations || [
          { uuid: 'uuid-rain', name: 'Night Rain', codec: 'MP3' },
          // 电台名是不可信元数据：带 HTML 痕迹，必须只以纯文本呈现
          { uuid: 'uuid-focus', name: 'Deep Focus <b onclick="x()">', codec: 'AAC' },
        ]
      )
    },
    async playStation(uuid) {
      calls.push(['playStation', uuid])
      if (overrides.playFail) throw new Error('host rejected')
      state.playing = true
      state.source = 'radio'
      state.station = uuid
    },
    onState() { return () => {} },
    pushLevel() {},
  }
  return api
}

/** 假 ctx：makeFakeCtx + core.music 注入 + 捕获卡片/命令注册。 */
function makeCtx({ music = null } = {}) {
  const ctx = makeFakeCtx({ id: PLUGIN_ID })
  ctx.core = { music }
  const cards = []
  const commands = []
  ctx.ui = {
    registerCard: (spec) => { cards.push(spec); return spec },
    registerCommand: (spec) => { commands.push(spec); return spec },
  }
  return { ctx, cards, commands }
}

async function boot(music) {
  const made = makeCtx({ music })
  const handle = await activate(made.ctx)
  return { ...made, handle }
}

function readAuditLines() {
  if (!existsSync(PLUGIN_LOG)) return []
  return readFileSync(PLUGIN_LOG, 'utf8')
    .split('\n')
    .filter((l) => l.trim())
    .map((l) => JSON.parse(l))
}

// ---------------------------------------------------------------------------
// 1) activate 注册面
// ---------------------------------------------------------------------------

test('music: activate 注册恰好 1 卡 1 命令，并把 ctx 交回宿主', async () => {
  const { cards, commands, handle, ctx } = await boot(makeMusicStub())
  assert.equal(cards.length, 1, '恰好 1 张卡片')
  assert.equal(cards[0].id, MUSIC_CARD_ID)
  assert.equal(commands.length, 1, '恰好 1 条命令')
  assert.equal(commands[0].name, 'music')
  assert.equal(typeof commands[0].run, 'function')
  // plugins.test.mjs 的 handle.ctx 纪律：activate 返回值必须带 ctx
  assert.ok(handle && handle.ctx === ctx, 'activate 必须把 ctx 交回宿主以便核对能力面')
  assert.equal(typeof handle.deactivate, 'function')
  assert.doesNotThrow(() => handle.deactivate())
})

test('music: activate 对裸 ctx（无 ui / 无 core）不抛', async () => {
  const logs = []
  const handle = await activate({ log: { info: (m) => logs.push(String(m)) } })
  assert.ok(handle && typeof handle.deactivate === 'function')
  assert.doesNotThrow(() => handle.deactivate())
  assert.ok(logs.some((l) => l.includes('E_MUSIC_NO_DRIVER') || l.includes('未装配')), '无 driver 应有日志说明')
})

test('music: 卡片正文是纯文本快照（源/播放/联网/电台数/降级）', async () => {
  const { cards } = await boot(
    makeMusicStub({ state: { enabled: true, playing: true, networkEnabled: true, stationCount: 3, degraded: true, reason: '无音频端点' } }),
  )
  const body = cards[0].body
  assert.equal(typeof body, 'string')
  assert.ok(body.length > 0)
  for (const key of ['当前源', '播放中', '联网', '电台数', '降级']) {
    assert.ok(body.includes(key), `卡片正文应含「${key}」`)
  }
  assert.ok(body.includes('无音频端点'), '降级原因要如实呈现')
  assert.ok(!body.includes('<'), '卡片正文不得含 HTML 痕迹（textContent 语义）')
  // 源码纪律：不拼 HTML
  const src = readFileSync(join(PLUGIN_DIR, 'index.mjs'), 'utf8')
  assert.ok(!src.includes('innerHTML'), '插件源码不得使用 innerHTML')
})

// ---------------------------------------------------------------------------
// 2) 各子命令在 stub 下行为正确、不抛
// ---------------------------------------------------------------------------

test('music: status 呈现纯文本状态', async () => {
  const { commands } = await boot(makeMusicStub({ state: { enabled: true, playing: true, stationCount: 2 } }))
  const r = await commands[0].run('status')
  assert.equal(r.ok, true)
  assert.match(r.text, /当前源：程序生成环境音/)
  assert.match(r.text, /播放中：是/)
  assert.match(r.text, /联网电台：关闭（默认不联网）/)
  assert.match(r.text, /精选电台数：2/)
  assert.ok(!r.text.includes('<'))
})

test('music: on = setEnabled(true) + 默认源 T0（零网络），off = 停播 + 停用', async () => {
  const stub = makeMusicStub()
  const { commands } = await boot(stub)

  const on = await commands[0].run('on')
  assert.equal(on.ok, true)
  assert.match(on.text, /音乐已开启/)
  assert.deepEqual(stub.calls.find((c) => c[0] === 'setEnabled'), ['setEnabled', true])
  assert.ok(stub.calls.some((c) => c[0] === 'playAmbient'), 'on 后应落到默认源 T0')

  const off = await commands[0].run('off')
  assert.equal(off.ok, true)
  assert.match(off.text, /音乐已关闭/)
  assert.ok(stub.calls.some((c) => c[0] === 'stopMusic'))
  assert.deepEqual(stub.calls.filter((c) => c[0] === 'setEnabled').pop(), ['setEnabled', false])
})

test('music: toggle 按当前开关态翻转', async () => {
  const stub = makeMusicStub({ state: { enabled: true, playing: true } })
  const { commands } = await boot(stub)
  const r = await commands[0].run('toggle')
  assert.equal(r.ok, true)
  assert.match(r.text, /音乐已关闭/)
  assert.deepEqual(stub.calls.filter((c) => c[0] === 'setEnabled').pop(), ['setEnabled', false])

  const stub2 = makeMusicStub({ state: { enabled: false, playing: false } })
  const boot2 = await boot(stub2)
  const r2 = await boot2.commands[0].run('toggle')
  assert.equal(r2.ok, true)
  assert.match(r2.text, /音乐已开启/)
  assert.deepEqual(stub2.calls.filter((c) => c[0] === 'setEnabled').pop(), ['setEnabled', true])
})

test('music: ambient 走 T0 程序生成环境音', async () => {
  const stub = makeMusicStub()
  const { commands } = await boot(stub)
  const r = await commands[0].run('ambient')
  assert.equal(r.ok, true)
  assert.match(r.text, /程序生成环境音/)
  assert.ok(stub.calls.some((c) => c[0] === 'playAmbient'))
})

test('music: stations 列表与 play <uuid>；电台名按纯文本呈现', async () => {
  const stub = makeMusicStub()
  const { commands } = await boot(stub)

  const list = await commands[0].run('stations')
  assert.equal(list.ok, true)
  assert.match(list.text, /Night Rain/)
  assert.match(list.text, /uuid-rain/)
  // 电台名是不可信元数据：原样进入纯文本（渲染走 textContent，不被当 markup 解释），
  // 因此这里断言"逐字出现"而不是"被转义/被剥离"。
  assert.ok(list.text.includes('Deep Focus <b onclick="x()">'), '电台名应按纯文本原样呈现')
  // 插件侧不拼 HTML 的纪律由源码断言看住（见下方源码纪律用例）

  const play = await commands[0].run('play uuid-focus')
  assert.equal(play.ok, true)
  assert.match(play.text, /已开始播放电台 \[uuid-focus\]/)
  assert.deepEqual(stub.calls.find((c) => c[0] === 'playStation'), ['playStation', 'uuid-focus'])

  const bad = await commands[0].run('play')
  assert.equal(bad.ok, false)
  assert.equal(bad.code, 'E_MUSIC_BAD_ARGS')
})

test('music: 空参数回落 status；未知子命令返回用法；均不抛', async () => {
  const { commands } = await boot(makeMusicStub({ state: { enabled: true, playing: true } }))
  const empty = await commands[0].run('')
  assert.equal(empty.ok, true)
  assert.match(empty.text, /当前源/, '空参数默认看状态')
  const bogus = await commands[0].run('bogus')
  assert.equal(bogus.ok, true)
  assert.match(bogus.text, /用法/)
})

// ---------------------------------------------------------------------------
// 3) driver 缺失 / driver 抛错：优雅降级，绝不抛
// ---------------------------------------------------------------------------

test('music: ctx.core.music 为 null → 所有子命令返回 E_MUSIC_NO_DRIVER 且不抛', async () => {
  const { commands } = await boot(null)
  const subs = ['status', 'on', 'off', 'toggle', 'ambient', 'stations', 'play uuid-x', '']
  for (const sub of subs) {
    // 不抛即过：run 内部任何 throw 都会让这行 await 失败
    await assert.doesNotReject(async () => {
      const r = await commands[0].run(sub)
      assert.equal(r.ok, false, `/${sub} 在无 driver 时应失败`)
      assert.equal(r.code, 'E_MUSIC_NO_DRIVER', `/${sub} 应带 E_MUSIC_NO_DRIVER`)
      assert.equal(typeof r.text, 'string')
      assert.ok(r.text.length > 0)
    })
  }
  // 直接调导出的命令主体同样不抛
  await assert.doesNotReject(async () => {
    const r = await musicCommand(null, 'status')
    assert.equal(r.ok, false)
    assert.equal(r.code, 'E_MUSIC_NO_DRIVER')
  })
})

test('music: driver 方法抛异常 → E_MUSIC_COMMAND_FAILED，不抛到上层', async () => {
  const stub = makeMusicStub({ playFail: true })
  const { commands } = await boot(stub)
  const r = await commands[0].run('play uuid-rain')
  assert.equal(r.ok, false)
  assert.equal(r.code, 'E_MUSIC_COMMAND_FAILED')
  assert.ok(!r.text.includes('<'))
})

// ---------------------------------------------------------------------------
// 4) 真宿主：审计 pluginId + handle.ctx + 降级路径
// ---------------------------------------------------------------------------

test('music: 真 registry enable/命令/disable 全链路，审计每条带非空 pluginId', async () => {
  const before = readAuditLines().length
  const reg = createRegistry({ core: {} })
  try {
    await reg.enable('music')
    const row = reg.get('music')
    assert.ok(row, 'music 插件应被扫到')
    assert.equal(row.enabled, true, `启用失败：${row.error}`)
    assert.equal(row.cards, 1)
    assert.deepEqual(row.commands, ['music'])

    const rec = reg._records.get('music')
    assert.ok(rec.instance && rec.instance.ctx, 'activate 应把 ctx 交回宿主以便核对能力面')

    // 宿主未装配 driver（core 白名单里暂无 music）→ 命令层优雅降级
    const r = await reg.runCommand('music', 'status')
    assert.equal(r.ok, true, 'registry 层不因插件返回 ok:false 而报错')
    assert.equal(r.pluginId, 'music')
    assert.equal(r.value.ok, false)
    assert.equal(r.value.code, 'E_MUSIC_NO_DRIVER')

    await reg.disable('music')
    assert.equal(reg.get('music').enabled, false)
    assert.deepEqual(reg.get('music').commands, [])

    const sliced = readAuditLines().slice(before)
    assert.ok(sliced.length > 0, '必须有新审计行')
    assert.ok(
      sliced.every((e) => typeof e.pluginId === 'string' && e.pluginId.length > 0),
      '每条审计都必须带 pluginId',
    )
    assert.ok(sliced.some((e) => e.event === 'enable' && e.pluginId === 'music'))
    assert.ok(sliced.some((e) => e.event === 'command.run' && e.pluginId === 'music'))
  } finally {
    await reg.disposeAll()
  }
})

// ---------------------------------------------------------------------------
// 5) 声明契约与源码纪律
// ---------------------------------------------------------------------------

test('music: plugin.json 契约（id/entry/version 派生自 package.json）', () => {
  const manifest = JSON.parse(readFileSync(join(PLUGIN_DIR, 'plugin.json'), 'utf8'))
  assert.equal(manifest.id, 'music')
  assert.equal(manifest.entry, 'index.mjs')
  const pkg = JSON.parse(readFileSync(join(PROJECT_ROOT, 'package.json'), 'utf8'))
  assert.equal(manifest.version, pkg.version, 'plugin.json 版本必须派生自 package.json')
  assert.equal(MUSIC_VERSION, pkg.version, '插件常量 MUSIC_VERSION 同样派生')
  assert.ok(manifest.capabilities.includes('ui.card'))
  assert.ok(manifest.capabilities.includes('ui.command'))
})

test('music: research pack.json 声明 music 插件/命令/ui（无重复项）', () => {
  const pack = JSON.parse(readFileSync(PACK_JSON, 'utf8'))
  assert.ok(pack.plugins.includes('music'), 'pack.plugins 应含 music')
  assert.ok(pack.commands.includes('music'), 'pack.commands 应含 music')
  assert.ok(pack.ui.includes('ui/music.js'), 'pack.ui 应含 ui/music.js')
  assert.equal(new Set(pack.commands).size, pack.commands.length, '命令名不得重复')
  assert.equal(new Set(pack.plugins).size, pack.plugins.length, '插件 id 不得重复')
  assert.equal(pack.version, JSON.parse(readFileSync(join(PROJECT_ROOT, 'package.json'), 'utf8')).version)
})

test('music: pack UI 源码纪律（自包含/禁 innerHTML/禁 focus/零硬编码色值/主题 token）', () => {
  const src = readFileSync(PACK_MUSIC_UI, 'utf8')
  // 注入体纪律：与 ui-bridge 同一机制，禁 import/export
  assert.ok(!/^\s*import[\s({]/.test(src), '注入体不得写 import')
  assert.ok(!/^\s*export[\s{default]/.test(src), '注入体不得写 export')
  // 安全：音频元数据只走 textContent 语义
  assert.ok(!src.includes('innerHTML'), '禁 innerHTML')
  // 不抢前台
  assert.ok(!src.includes('.focus('), '严禁 focus()（§5 不抢前台）')
  // 零硬编码色值（3/6/8 位十六进制色）
  assert.ok(!/#[0-9a-fA-F]{8}\b|#[0-9a-fA-F]{6}\b|#[0-9a-fA-F]{3}\b/.test(src), '颜色必须全部走主题 token')
  for (const token of ['--ro-ball-from', '--ro-accent', '--ro-face']) {
    assert.ok(src.includes(token), `光环三停必须走 ${token}`)
  }
  // 光环挂点与层级
  assert.ok(src.includes('doc.body.appendChild'), '光环必须 append 到 body（不是 #ball 内）')
  assert.ok(src.includes('insertBefore(b, host)'), '顶栏按钮必须在 #new-conversation 前 insertBefore')
  assert.ok(src.includes('ro-music-halo'), '必须有 .ro-music-halo 光环根类')
  assert.ok(src.includes("'0 0 96 96'"), '光环 viewBox 0 0 96 96')
  // 上行 payload 形状（main.mjs 的 plugin:command 只认字符串 args）
  assert.ok(
    src.includes("R.send('plugin:command', { name: 'music', args: 'toggle' })"),
    '点击上行必须是 {type 由 send 补, name, args 字符串}',
  )
  // 电平订阅与包络/双阈值/脉冲
  assert.ok(src.includes("R.onMsg('music:level'"), '必须订阅 music:level')
  assert.ok(src.includes('START_THRESHOLD = 0.02'))
  assert.ok(src.includes('STOP_THRESHOLD = 0.008'))
  assert.ok(src.includes('PEAK_THRESHOLD = 0.85'))
  // 静止纪律写全
  assert.ok(src.includes('prefers-reduced-motion'))
  assert.ok(src.includes('body.ro-frozen'))
  assert.ok(src.includes('animation: none !important'))
  assert.ok(src.includes('transform: none !important'))
})
