// tests/coach-extract.test.mjs —— S25·2B + S27：抽取（降采样/去重/兜底/删图审计）
import { test, beforeEach, afterEach } from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'
import { PROJECT_ROOT, logPath, dataPath } from '../packages/core/src/safefs.mjs'
import { createRouter } from '../packages/core/src/router.mjs'
import { createExtractor, visionMessages, hitRate, shrinkForModel } from '../packages/plugins/coach/extract.mjs'

const ROOT = dataPath('tmp', 's27-extract-test')
let DIR, FRAMES, TRASH
let n = 0

beforeEach(() => {
  n += 1
  DIR = `${ROOT}-${n}`
  FRAMES = join(DIR, 'frames')
  TRASH = join(DIR, 'trash')
  rmSync(DIR, { recursive: true, force: true })
  mkdirSync(FRAMES, { recursive: true })
  mkdirSync(TRASH, { recursive: true })
})
afterEach(() => { rmSync(DIR, { recursive: true, force: true }) })

function makePng(path, w = 1400, h = 360, text = '微电网逆变器下垂控制策略研究综述初稿计划') {
  const script = [
    'Add-Type -AssemblyName System.Drawing;',
    `$b=New-Object System.Drawing.Bitmap ${w},${h};`,
    '$g=[System.Drawing.Graphics]::FromImage($b);',
    '$g.Clear([System.Drawing.Color]::White);',
    "$f=New-Object System.Drawing.Font('Microsoft YaHei',56);",
    `$g.DrawString('${text.slice(0, 10)}',$f,[System.Drawing.Brushes]::Black,40,40);`,
    `$g.DrawString('${text.slice(10)}',$f,[System.Drawing.Brushes]::Black,40,160);`,
    `$b.Save('${path.replace(/\\/g, '\\\\')}',[System.Drawing.Imaging.ImageFormat]::Png);`,
    '$g.Dispose();$b.Dispose();',
  ].join(' ')
  spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { timeout: 30000, encoding: 'utf8' })
  return existsSync(path)
}

function stubRouter(handler) {
  return createRouter({ providers: { cheap: { providerId: 'school-gateway', model: 'qwen' }, flagship: { providerId: 'deepseek-api', model: 'deepseek-chat' } }, invoke: handler, audit: () => {}, usagePath: join(DIR, 'usage.jsonl') })
}

test('extract: shrinkForModel 缩到 ≤640 宽 JPEG q70 且字节小于原图', () => {
  const src = join(FRAMES, 'big.png')
  assert.ok(makePng(src), '预制图')
  const before = statSync(src).size
  const out = shrinkForModel(src)
  assert.ok(out && existsSync(out), '缩略图应存在')
  const dims = spawnSync('powershell.exe', ['-NoProfile', '-Command', `Add-Type -AssemblyName System.Drawing; $i=[System.Drawing.Image]::FromFile('${out}'); "$($i.Width)x$($i.Height)"; $i.Dispose()`], { encoding: 'utf8' }).stdout.trim()
  assert.match(dims, /^640x/, `宽应 ≤640：${dims}`)
  assert.ok(statSync(out).size < before, `缩略应更小：${statSync(out).size} < ${before}`)
  rmSync(out, { force: true })
})

test('extract: visionMessages 支持 jpeg mime', () => {
  const m = visionMessages('QUJD', 'image/jpeg')
  assert.match(m[0].content[0].image_url.url, /^data:image\/jpeg;base64,QUJD$/)
})

test('extract: 去重——同哈希图只调一次 router（不扣配额），副本也进 trash', async () => {
  const src = join(FRAMES, 'dup.png')
  makePng(src, 900, 200)
  let calls = 0
  const ex = createExtractor({ dir: DIR, router: stubRouter(async () => { calls += 1; return { text: '转录文本内容' } }), trashDir: TRASH, ocr: () => ({ ok: true, text: '兜底' }) })
  const r1 = await ex.extract({ imagePath: src })
  const src2 = join(FRAMES, 'dup2.png')
  writeFileSync(src2, readFileSync(join(TRASH, readdirSafe(TRASH)[0])))
  const r2 = await ex.extract({ imagePath: src2 })
  assert.equal(r1.cached, false)
  assert.equal(r2.cached, true)
  assert.equal(calls, 1, '去重命中不重复调用')
  assert.ok(!existsSync(src2), '同内容副本也删除')
})

test('extract: qwen 失败 → OCR 兜底 + extract-fallback 审计', async () => {
  const src = join(FRAMES, 'fb.png')
  makePng(src, 900, 200)
  const audits = []
  const ex = createExtractor({
    dir: DIR,
    router: stubRouter(async () => { throw Object.assign(new Error('gw down'), { code: 'E_HTTP_500' }) }),
    trashDir: TRASH,
    ocr: () => ({ ok: true, engine: 'stub', text: '兜底转录' }),
  })
  const r = await ex.extract({ imagePath: src })
  assert.equal(r.source, 'ocr')
  assert.equal(r.text, '兜底转录')
  const auditText = readFileSync(logPath('coach.jsonl'), 'utf8')
  assert.ok(auditText.includes('extract-fallback'), '兜底审计')
  void audits
})

test('extract: 缺图 → E_FRAME_NOT_FOUND；处理后原图删除 + trash 副本', async () => {
  const ex = createExtractor({ dir: DIR, router: stubRouter(async () => ({ text: 't' })), trashDir: TRASH, ocr: () => ({ ok: true, text: 'x' }) })
  await assert.rejects(() => ex.extract({ imagePath: join(FRAMES, 'nope.png') }), (e) => e.code === 'E_FRAME_NOT_FOUND')
  const src = join(FRAMES, 'del.png')
  makePng(src, 900, 200)
  const r = await ex.extract({ imagePath: src })
  assert.equal(r.deleted, true)
  assert.ok(!existsSync(src), '原图已删')
  assert.ok(readdirSafe(TRASH).length >= 1, 'trash 有副本')
})

test('extract: hitRate 20 字样本口径', () => {
  assert.equal(hitRate('微电网逆变器', '微电网逆变器下垂控制'), 1)
  assert.ok(hitRate('微电网逆变器下垂控制', '微 电 网 逆 变 器 下 垂 控 制') >= 0.8)
  assert.equal(hitRate('', 'x'), 0)
})

function readdirSafe(dir) { try { return readdirSync(dir) } catch { return [] } }
