// tests/python-encoding.test.mjs
//
// 长期测试钉（主管冷跑 432/433 必修根因）：
// 跨进程（Node → Python）输出必须显式 UTF-8，否则在 cp936 等控制台代码页下
// 中文会 mojibake（如 `Grid-Forming Control ���鿨`）。
// 本测试直接验证集中式 helper `tools/lib/run-python.mjs` 的中文回环，
// 并对比"裸 spawnSync（无编码约定）"在 cp936 下的失败，防止回归。

import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync } from 'node:fs'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { runPython } from '../tools/lib/run-python.mjs'

const PYTHON_VENV = join(PROJECT_ROOT, '.venv')
const python = join(PYTHON_VENV, 'Scripts', 'python.exe')
const haveVenv = existsSync(python)

const SUBJECT = '构网型逆变器 王伟 Grid-Forming 读书卡'
const CODE = [
  'import sys, json',
  's = ' + JSON.stringify(SUBJECT),
  'sys.stdout.write(json.dumps({"s": s}, ensure_ascii=False))',
].join('\n')

test('跨进程输出约定：runPython 中文回环无 mojibake（受管 venv，缺失则跳过）', { skip: haveVenv ? false : '项目内 .venv 缺失——先 `node tools/setup-venv.mjs`' }, () => {
  const r = runPython(python, CODE)
  assert.equal(r.status, 0, `runPython 失败：${r.stderr}`)
  const out = JSON.parse(r.stdout)
  assert.equal(out.s, SUBJECT, `回环应原样返回中文，实际：${out.s}`)
})

test('回归护栏：裸 spawnSync（不带编码约定）在 cp936 下会 mojibake（仅文档化，不要求通过）', { skip: haveVenv ? false : '项目内 .venv 缺失——先 `node tools/setup-venv.mjs`' }, () => {
  // 仅在确实处于非 UTF-8 控制台时才断言失败；UTF-8 控制台下裸 spawnSync 也可能恰好正确，
  // 故本测试只记录差异，不阻塞验收。核心保证由上一个 test（runPython）提供。
  const naive = spawnSync(python, ['-c', CODE], { encoding: 'utf8' })
  const safe = runPython(python, CODE)
  const naiveOk = naive.status === 0 && JSON.parse(naive.stdout).s === SUBJECT
  const safeOk = safe.status === 0 && JSON.parse(safe.stdout).s === SUBJECT
  assert.equal(safeOk, true, 'runPython 必须始终正确（无论控制台代码页）')
  // 若裸 spawnSync 也正确，说明当前控制台本就是 UTF-8；若为 false，则证明编码约定是必要的。
  if (!naiveOk) {
    console.log('[guard] 裸 spawnSync 在此环境中文回环失败 —— 编码约定避免冷跑 432/433 复现')
  }
})
