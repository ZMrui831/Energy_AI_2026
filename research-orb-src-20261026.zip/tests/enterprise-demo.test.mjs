// tests/enterprise-demo.test.mjs
//
// P-R6 块 C：企业版雏形 + 演示模式的验收测试。
//   1) edition 开关双向验证（personal ↔ enterprise），配置落盘且可读回
//   2) 企业版下无头浏览器【临时 profile】被拒（运行证据 + 审计行）
//   3) 企业版下 L2/L3/L4 图形层一律不存在（静态断言：源码无 CreateDesktop/合成输入/截屏 API）
//   4) 审计只增不删（appendJsonl 语义 + 无删除代码路径）
//   5) 演示数据隔离 data\demo\，reset 可清空重建
//   6) 数据不外发（无上传/外发代码路径；出网仍走白名单）

import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, readFileSync, readdirSync, rmSync, writeFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT, dataPath } from '../packages/core/src/safefs.mjs'
import { loadSettings, saveSettings, isEnterprise } from '../packages/core/src/settings.mjs'
import { createBrowserEngine } from '../packages/plugins/research-browser/lib/engine.mjs'
import { appendJsonl, logPath } from '../packages/core/src/safefs.mjs'

const CONFIG = dataPath('config.json')
const DEMO_DIR = dataPath('demo')

/** S33：Windows 文件监视会短暂锁住 data/demo，reset 用重试（5 次 / 300ms）收敛。 */
function rmRetrySync(p, tries = 5) {
  for (let i = 0; i < tries; i++) {
    try { rmSync(p, { recursive: true, force: true }); return true } catch { if (i < tries - 1) { const t = Date.now() + 300; while (Date.now() < t) { /* busy */ } } }
  }
  return false
}

/** 保存并恢复 edition，避免测试之间互相污染。 */
function withEdition(edition, fn) {
  const before = loadSettings()
  saveSettings({ edition })
  return Promise.resolve()
    .then(fn)
    .finally(() => { saveSettings({ edition: before.edition }) })
}

test('enterprise: edition 双向切换且配置落盘', async () => {
  await withEdition('enterprise', () => {
    const s = loadSettings()
    assert.equal(s.edition, 'enterprise')
    assert.equal(isEnterprise(s), true)
    const onDisk = JSON.parse(readFileSync(CONFIG, 'utf8'))
    assert.equal(onDisk.edition, 'enterprise')
  })
  const after = loadSettings()
  assert.equal(after.edition, 'personal')
  assert.equal(isEnterprise(after), false)
})

test('enterprise: 临时 profile 被拒且留审计行（运行证据）', async () => {
  const engine = createBrowserEngine({
    browserExe: 'C:/dummy/msedge.exe',
    browserRoot: dataPath('tmp', 'pr6-ent-test'),
    openAndExtractFn: async () => ({ title: 'x' }),
    isEnterpriseFn: () => true,
  })
  const before = existsSync(logPath('browser.jsonl')) ? readFileSync(logPath('browser.jsonl'), 'utf8').split('\n').filter(Boolean).length : 0

  const r = await engine.browse({ url: 'https://arxiv.org/abs/2301.00001', opts: { temp: true } })
  assert.equal(r.ok, false)
  assert.equal(r.code, 'E_ENTERPRISE_TEMP_PROFILE_DENIED')

  const after = existsSync(logPath('browser.jsonl')) ? readFileSync(logPath('browser.jsonl'), 'utf8').split('\n').filter(Boolean).length : 0
  assert.ok(after > before, '拒绝必须写审计行')
  const lines = readFileSync(logPath('browser.jsonl'), 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l))
  const last = lines[lines.length - 1]
  assert.equal(last.decision, 'deny')
  assert.equal(last.kind, 'deny-enterprise-temp-profile')
  assert.ok(typeof last.reason === 'string' && last.reason.length > 0)
})

test('enterprise: 个人版下临时 profile 不被版本文本拦截（走既有合规网关）', async () => {
  const engine = createBrowserEngine({
    browserExe: 'C:/dummy/msedge.exe',
    browserRoot: dataPath('tmp', 'pr6-per-test'),
    openAndExtractFn: async () => ({ title: 'x' }),
    isEnterpriseFn: () => false,
  })
  const r = await engine.browse({ url: 'https://arxiv.org/abs/2301.00001', opts: { temp: true } })
  assert.equal(r.ok, true, `个人版临时 profile 应放行：${r.code}:${r.reason}`)
})

test('enterprise: L2/L3/L4 图形层在源码中不存在（静态断言）', () => {
  // L2 = CreateDesktop 独立桌面；L3 = VM；L4 = 合成输入 + 截屏。
  // 当前产品只实现 L1（无头浏览器）。企业版要求"一键关闭 L2/L3/L4"——
  // 最彻底的关闭就是【根本没有这些代码路径】。本钉保证这一点不被悄悄改掉。
  const roots = [join(PROJECT_ROOT, 'apps', 'desktop'), join(PROJECT_ROOT, 'packages')]
  // P-R6.2 修订：desktopCapturer 从禁用清单移除 —— 它是【读】屏幕像素（任务三
  // 屏幕感知的合法实现），不属于 L2/L3/L4 的【写/注入】类图形层；且其使用有审计
  // （writes.jsonl）与用户显式命令触发（/screen）。L2/L3/L4 的本质是"注入输入/
  // 接管桌面"，禁用清单据此保留输入注入与桌面接管类 API。
  const banned = [
    /CreateDesktop\s*\(/i,
    /SetThreadDesktop/i,
    /SwitchDesktop/i,
    /SendInput\s*\(/i,
    /keybd_event\s*\(/i,
    /mouse_event\s*\(/i,
    /SetForegroundWindow\s*\(/i,
    /capturePage\s*\(/i,
  ]
  const files = []
  const walk = (dir) => {
    let names = []
    try { names = readdirSync(dir, { withFileTypes: true }) } catch { return }
    for (const n of names) {
      if (n.name.startsWith('.')) continue
      const p = join(dir, n.name)
      if (n.isDirectory()) { if (n.name !== 'node_modules') walk(p) }
      else if (/\.(mjs|cjs|js)$/.test(n.name)) files.push(p)
    }
  }
  for (const r of roots) walk(r)
  for (const f of files) {
    const text = readFileSync(f, 'utf8')
    for (const re of banned) {
      assert.equal(re.test(text), false, `${f.replace(PROJECT_ROOT, '.')} 命中图形层 API ${re}（L2/L3/L4 不得进入产品路径）`)
    }
  }
})

test('enterprise: 审计只增不删 —— 无删除/清空审计日志的代码路径', () => {
  const files = []
  const walk = (dir) => {
    let names = []
    try { names = readdirSync(dir, { withFileTypes: true }) } catch { return }
    for (const n of names) {
      if (n.name.startsWith('.')) continue
      const p = join(dir, n.name)
      if (n.isDirectory()) { if (n.name !== 'node_modules') walk(p) }
      else if (/\.(mjs|cjs)$/.test(n.name)) files.push(p)
    }
  }
  for (const r of [join(PROJECT_ROOT, 'apps', 'desktop'), join(PROJECT_ROOT, 'packages', 'core'), join(PROJECT_ROOT, 'packages', 'plugins')]) walk(r)
  // 审计日志文件名集合（这些文件只允许 append）
  const auditLogs = ['writes.jsonl', 'net.jsonl', 'plugins.jsonl', 'app.jsonl', 'ui.jsonl', 'renderer.jsonl', 'browser.jsonl']
  for (const f of files) {
    const text = readFileSync(f, 'utf8')
    for (const log of auditLogs) {
      // 不得出现对这些日志的 truncate/unlink/rm 调用
      assert.equal(new RegExp(`truncate[^\\n]*${log}`).test(text), false, `${f} 不得 truncate ${log}`)
      assert.equal(new RegExp(`unlink[^\\n]*${log}`).test(text), false, `${f} 不得 unlink ${log}`)
    }
  }
})

test('enterprise: 数据不外发 —— 无上传/外发代码路径（出网仍走白名单）', () => {
  // core 的 net.mjs 是唯一出网口；它只接受白名单域名（ALLOWED_DOMAINS 来自 domains.json）。
  const net = readFileSync(join(PROJECT_ROOT, 'packages', 'core', 'src', 'net.mjs'), 'utf8')
  assert.match(net, /E_DOMAIN_NOT_ALLOWED/)
  assert.match(net, /ALLOWED_DOMAINS\.includes/)
  // shell/plugins 不得自己发请求（fetch/undici/https 直连）
  const files = []
  const walk = (dir) => {
    let names = []
    try { names = readdirSync(dir, { withFileTypes: true }) } catch { return }
    for (const n of names) {
      if (n.name.startsWith('.')) continue
      const p = join(dir, n.name)
      if (n.isDirectory()) { if (n.name !== 'node_modules') walk(p) }
      else if (/\.(mjs|cjs)$/.test(n.name)) files.push(p)
    }
  }
  for (const r of [join(PROJECT_ROOT, 'apps', 'desktop'), join(PROJECT_ROOT, 'packages', 'plugins')]) walk(r)
  for (const f of files) {
    if (f.endsWith(join('research-browser', 'lib', 'cdp.mjs'))) continue // CDP 走 127.0.0.1 本地回环，非外发
    const text = readFileSync(f, 'utf8')
    assert.equal(/\brequire\(['"]https?['"]\)/.test(text), false, `${f} 不得直连 https 模块`)
    assert.equal(/from ['"]node:https['"]/.test(text), false, `${f} 不得 import node:https`)
  }
})

// ---------------------------------------------------------------------------
// 演示模式
// ---------------------------------------------------------------------------
test('demo: 数据隔离在 data/demo/，reset 清空后可重建', () => {
  // 直接演示 reset 的语义：写入 → 清空 → 重建
  if (!existsSync(DEMO_DIR)) mkdirSync(DEMO_DIR, { recursive: true })
  writeFileSync(join(DEMO_DIR, 'probe.json'), '{"k":1}', 'utf8')
  assert.ok(existsSync(join(DEMO_DIR, 'probe.json')))

  // reset = rmSync + mkdirSync + 一行审计（与 main.mjs 的 resetDemoData 同语义）
  rmRetrySync(DEMO_DIR)
  assert.equal(existsSync(DEMO_DIR), false, 'reset 后 data/demo 必须不存在（已清空）')
  mkdirSync(DEMO_DIR, { recursive: true })
  appendJsonl(join(DEMO_DIR, 'demo.jsonl'), { ts: new Date().toISOString(), type: 'demo-reset' })
  assert.ok(existsSync(join(DEMO_DIR, 'demo.jsonl')), 'reset 后必须可重建')

  // 清理测试残留
  rmRetrySync(DEMO_DIR)
})

test('demo: 配置里的 demo 开关可读写', () => {
  const before = loadSettings()
  saveSettings({ demo: true })
  assert.equal(loadSettings().demo, true)
  saveSettings({ demo: false })
  assert.equal(loadSettings().demo, false)
  saveSettings({ demo: before.demo })
})
