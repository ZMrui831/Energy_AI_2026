// tests/audit-preflight.test.mjs —— S33·B2 审计基线语义单测（≥5 项）。
// 口径：比对 total（live + archived）；升/不变放行；低于基线拒（E_AUDIT_LOSS）；
//      无 approvedLowering 的下降拒；有报批字段且达标才允许；报批值仍高于当前也拒。
import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { auditPreflight } from '../packages/plugins/coach/audit-preflight.mjs'

/** 造临时 root：data/logs/writes.jsonl（live 行数）+ 基线 json。 */
function setup({ baseline, live = 0, approvedLowering }) {
  const root = mkdtempSync(join(tmpdir(), 'orb-ap-'))
  mkdirSync(join(root, 'data', 'logs'), { recursive: true })
  const baseDoc = { at: '2000-01-01T00:00:00.000Z', D23: 'test', ...baseline }
  if (approvedLowering) baseDoc.approvedLowering = approvedLowering
  writeFileSync(join(root, 'data', 'logs', 's25-audit-preflight.json'), JSON.stringify(baseDoc, null, 2))
  if (live > 0) writeFileSync(join(root, 'data', 'logs', 'writes.jsonl'), Array.from({ length: live }, (_, i) => JSON.stringify({ i })).join('\n') + '\n')
  else writeFileSync(join(root, 'data', 'logs', 'writes.jsonl'), '')
  return root
}
function cleanup(root) { try { rmSync(root, { recursive: true, force: true }) } catch { /* 尽力 */ } }

test('B2-1 升级（当前 > 基线）→ 放行，total 如实', () => {
  const root = setup({ baseline: { 'writes.jsonl': 10 }, live: 12 })
  try {
    const r = auditPreflight({ root })
    assert.equal(r.ok, true)
    assert.equal(r.results[0].total, 12)
    assert.equal(r.results[0].baseline, 10)
  } finally { cleanup(root) }
})

test('B2-2 不变（当前 == 基线）→ 放行', () => {
  const root = setup({ baseline: { 'writes.jsonl': 10 }, live: 10 })
  try {
    const r = auditPreflight({ root })
    assert.equal(r.ok, true)
    assert.equal(r.results[0].total, 10)
  } finally { cleanup(root) }
})

test('B2-3 低于基线（无报批）→ 抛 E_AUDIT_LOSS', () => {
  const root = setup({ baseline: { 'writes.jsonl': 10 }, live: 8 })
  try {
    assert.throws(() => auditPreflight({ root }), (e) => e && e.code === 'E_AUDIT_LOSS' && e.total === 8 && e.baseline === 10)
  } finally { cleanup(root) }
})

test('B2-4 无 approvedLowering 的下降一律拒（报批别的文件也不行）', () => {
  // 基线里为 coach.jsonl 报了批，但 writes.jsonl 没报批 → 降仍拒
  const root = setup({ baseline: { 'writes.jsonl': 10, 'coach.jsonl': 5 }, live: 9, approvedLowering: { 'coach.jsonl': { to: 0, at: 'x', reason: 'r', approvedBy: 'b' } } })
  try {
    assert.throws(() => auditPreflight({ root }), (e) => e && e.code === 'E_AUDIT_LOSS' && e.file === 'writes.jsonl')
  } finally { cleanup(root) }
})

test('B2-5 有报批字段且当前 >= 报批值 → 允许（approved=true）', () => {
  const root = setup({ baseline: { 'writes.jsonl': 10 }, live: 8, approvedLowering: { 'writes.jsonl': { to: 5, at: '2026-10-23T00:00:00Z', reason: '轮转归档', approvedBy: '主管' } } })
  try {
    const r = auditPreflight({ root })
    assert.equal(r.ok, true)
    assert.equal(r.results[0].approved, true)
    assert.equal(r.results[0].total, 8)
  } finally { cleanup(root) }
})

test('B2-6 有报批字段但当前 < 报批值 → 仍拒', () => {
  const root = setup({ baseline: { 'writes.jsonl': 10 }, live: 8, approvedLowering: { 'writes.jsonl': { to: 9, at: 'x', reason: 'r', approvedBy: 'b' } } })
  try {
    assert.throws(() => auditPreflight({ root }), (e) => e && e.code === 'E_AUDIT_LOSS')
  } finally { cleanup(root) }
})
