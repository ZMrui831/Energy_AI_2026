// tests/bib.test.mjs
//
// 引用导出（交付 5）：LaTeX 转义、作者名反转、条目类型、键唯一性、
// 以及最关键的 —— 用真实的 citation-js 把导出的 .bib **读回来**。

import test from 'node:test'
import assert from 'node:assert/strict'

import {
  bibAuthor,
  bibKeyBase,
  bibType,
  buildBibtex,
  cardToBibtex,
  exportBib,
  exportFileName,
  latexEscape,
  selfCheckBibtex,
  uniquify,
} from '../packages/plugins/research-literature/lib/bib.mjs'
import { validateCard } from '../packages/plugins/research-literature/lib/cards.mjs'
import { makeMemoryScope } from './helpers/research-fixtures.mjs'

function card(over = {}) {
  return validateCard({
    title: 'Grid-Forming Inverter Control for Inertia Support',
    authors: ['Wei Wang', 'Maria Rossi'],
    venue: 'IEEE Transactions on Power Systems',
    year: 2024,
    doi: '10.1109/TPWRS.2024.1000000',
    url: 'https://doi.org/10.1109/TPWRS.2024.1000000',
    pdf: null,
    tags: ['grid-forming inverter'],
    问题: 'q',
    方法: 'm',
    数据与算例: 'd',
    结论与局限: 'c',
    可复用点: 'r',
    待验证点: 'v',
    与我课题的关系: 'x',
    '读数（0-5）': 1,
    ...over,
  }).card
}

// ---------------------------------------------------------------------------
// 转义与字段构造
// ---------------------------------------------------------------------------

test('bib: LaTeX 转义只动危险字符，去掉花括号', () => {
  assert.equal(latexEscape('A & B'), 'A \\& B')
  assert.equal(latexEscape('100% of $x_1$'), '100\\% of \\$x\\_1\\$')
  assert.equal(latexEscape('#tag'), '\\#tag')
  assert.equal(latexEscape('{braced}'), 'braced')
  assert.equal(latexEscape('a\\b'), 'a b')
  assert.equal(latexEscape('  multi   space '), 'multi space')
  assert.equal(latexEscape('普通中文'), '普通中文')
})

test('bib: 作者名 "Given Family" 反转为 "Family, Given"', () => {
  assert.equal(bibAuthor('Wei Wang'), 'Wang, Wei')
  assert.equal(bibAuthor('Maria de la Cruz'), 'Cruz, Maria de la')
  assert.equal(bibAuthor('Wang, Wei'), 'Wang, Wei', '已有逗号的原样保留')
  assert.equal(bibAuthor('Aristotle'), 'Aristotle')
  assert.equal(bibAuthor(''), '')
  assert.equal(bibAuthor('J. R. R. Tolkien'), 'Tolkien, J. R. R.')
})

test('bib: 条目类型按 venue 判定（期刊/会议/预印本）', () => {
  assert.equal(bibType(card({ venue: 'IEEE Transactions on Power Systems' })), 'article')
  assert.equal(bibType(card({ venue: 'IEEE PES General Meeting' })), 'inproceedings')
  assert.equal(bibType(card({ venue: 'PSCC 2024' })), 'inproceedings')
  assert.equal(bibType(card({ venue: 'CIGRE Session' })), 'inproceedings')
  assert.equal(bibType(card({ venue: 'arXiv preprint' })), 'misc')
  assert.equal(bibType(card({ venue: 'arXiv:2401.0001' })), 'misc')
})

test('bib: 引用键为 ASCII 且去重加字母后缀', () => {
  const base = bibKeyBase(card())
  assert.equal(base, 'Wang2024Grid')
  // 中文姓氏不做拼音转写（那需要一张拼音表，且转错比不转更糟）→ 退化为 anon，靠 uniquify 消重
  assert.equal(bibKeyBase(card({ authors: ['李雷'] })), 'anon2024Grid')
  assert.equal(bibKeyBase(card({ authors: [] })), 'anon2024Grid')
  assert.equal(bibKeyBase(card({ year: null })), 'WangnYearGrid')
  const used = new Set()
  assert.equal(uniquify('K', used), 'K')
  assert.equal(uniquify('K', used), 'Ka')
  assert.equal(uniquify('K', used), 'Kb')
  // 字母后缀用完后退化为数字后缀，且绝不重复
  for (let i = 0; i < 40; i += 1) uniquify('K', used)
  const before = used.size
  const next = uniquify('K', used)
  assert.match(next, /^K-\d+$/, `字母用完后应退化为数字后缀，实际 ${next}`)
  assert.equal(used.size, before + 1, '新键不得与已有键重复')
  assert.equal(new Set([...used]).size, [...used].length)
})

test('bib: 单条条目所有字段都加花括号（回归：作者名里的逗号会破坏 BibTeX）', () => {
  const text = cardToBibtex(card(), 'Wang2024Grid')
  assert.ok(text.startsWith('@article{Wang2024Grid,'))
  assert.ok(text.includes('title     = {Grid-Forming Inverter Control for Inertia Support}'))
  assert.ok(text.includes('author    = {Wang, Wei and Rossi, Maria}'), 'author 必须被括号包住')
  assert.ok(text.includes('journal   = {IEEE Transactions on Power Systems}'))
  assert.ok(text.includes('year      = {2024}'))
  assert.ok(text.includes('doi       = {10.1109/tpwrs.2024.1000000}'))
  assert.ok(text.includes('url       = {https://doi.org/10.1109/TPWRS.2024.1000000}'))
  // 会议条目的期刊字段应变成 booktitle
  assert.ok(cardToBibtex(card({ venue: 'IEEE PES General Meeting' }), 'K').includes('booktitle'))
  // 缺 DOI/URL 时不写空字段
  const noDoi = cardToBibtex(card({ doi: null, url: '' }), 'K')
  assert.ok(!noDoi.includes('doi'))
  assert.ok(!noDoi.includes('url'))
})

test('bib: buildBibtex 头部 + 每条一段 + 键全局唯一', () => {
  const cards = [card(), card({ doi: '10.1/x', title: 'Another Grid Paper' }), card({ doi: '10.1/y', title: 'Third Grid Paper', authors: ['Li Lei'] })]
  const built = buildBibtex(cards, { topic: 'gfm', date: '2026-10-15' })
  assert.equal(built.entries.length, 3)
  assert.equal(new Set(built.keys).size, 3, '键必须唯一')
  assert.match(built.bib, /主题：gfm/)
  assert.match(built.bib, /导出时间：2026-10-15/)
  assert.match(built.bib, /条目数：3/)
  assert.equal(built.date, '2026-10-15')
  assert.equal(built.bib.split('@').length - 1, 3)
  assert.equal(exportFileName('gfm', '2026-10-15'), 'gfm-2026-10-15.bib')
  assert.equal(exportFileName('My Topic!', '2026-01-02'), 'my-topic-2026-01-02.bib')
})

// ---------------------------------------------------------------------------
// citation-js 自检（真依赖，不桩）
// ---------------------------------------------------------------------------

test('bib: citation-js 能解析导出的 .bib，条数与 DOI 全部保留', async () => {
  const cards = [card(), card({ doi: '10.1016/j.epsr.2019.0002', title: 'Islanding Detection & Protection', venue: 'Electric Power Systems Research', year: 2019, authors: ['Hao Chen'] }), card({ doi: null, url: 'https://arxiv.org/abs/2401.0001', venue: 'arXiv preprint', title: 'A Preprint on Inertia' })]
  const built = buildBibtex(cards, { topic: 'gfm', date: '2026-10-15' })
  const check = await selfCheckBibtex(built.bib, {
    expectKeys: built.keys,
    expectDois: cards.map((c) => c.doi).filter(Boolean),
  })
  assert.equal(check.ok, true, check.error || '')
  assert.equal(check.parsed, 3)
  assert.equal(check.expected, 3)
  assert.equal(check.dois.parsed.length, 2)
  assert.deepEqual(check.missingDoi, [])
  assert.equal(check.error, null)
  // 标题里的 & 必须被正确还原（说明转义与反解析都对）
  assert.ok(check.titles.some((t) => /Islanding Detection & Protection/.test(String(t))), JSON.stringify(check.titles))
})

test('bib: 自检对垃圾输入返回 ok=false 并带原因（不抛）', async () => {
  const bad = await selfCheckBibtex('not bibtex at all %%%', { expectKeys: ['X'] })
  assert.equal(bad.ok, false)
  assert.ok(bad.error, '必须给出原因')
  // citation-js 会把无法识别的文本忽略掉 → 解析 0 条，与期望 1 条不符
  assert.equal(bad.expected, 1)
})

test('bib: 自检发现条数不符时报 ok=false', async () => {
  const built = buildBibtex([card()], { topic: 'x', date: '2026-10-15' })
  const check = await selfCheckBibtex(built.bib, { expectKeys: ['A', 'B'], expectDois: [] })
  assert.equal(check.ok, false)
  assert.match(String(check.error), /期望 2 条/)
})

// ---------------------------------------------------------------------------
// 导出落盘
// ---------------------------------------------------------------------------

test('bib: 自检过程完全不碰网络（把 globalThis.fetch 换成会抛的桩仍应通过）', async () => {
  const cards = [card(), card({ doi: '10.1016/j.epsr.2019.0002', title: 'Islanding Detection', venue: 'Electric Power Systems Research' })]
  const built = buildBibtex(cards, { topic: 'gfm', date: '2026-10-15' })
  const original = globalThis.fetch
  let fetchCalls = 0
  globalThis.fetch = async () => {
    fetchCalls += 1
    throw new Error('网络被测试禁用：citation-js 不得出网')
  }
  try {
    const check = await selfCheckBibtex(built.bib, { expectKeys: built.keys, expectDois: cards.map((c) => c.doi) })
    assert.equal(check.ok, true, check.error || '')
    assert.equal(fetchCalls, 0, '自检过程不得发生任何 fetch 调用')
  } finally {
    globalThis.fetch = original
  }
})

test('bib: exportBib 写盘 + 自检通过，文件落在 exports 作用域', async () => {
  const exportsScope = makeMemoryScope('exports')
  const out = await exportBib({ exportsScope, topic: 'gfm', cards: [card()], date: '2026-10-15' })
  assert.equal(out.file, 'gfm-2026-10-15.bib')
  assert.equal(out.rel, 'exports/gfm-2026-10-15.bib')
  assert.equal(out.check.ok, true, out.check.error || '')
  assert.ok(exportsScope.exists('gfm-2026-10-15.bib'))
  assert.equal(exportsScope.read('gfm-2026-10-15.bib'), out.bib)
  assert.ok(out.bytes > 200)
  assert.deepEqual(exportsScope.list(''), ['gfm-2026-10-15.bib'])
})

test('bib: 空卡片集合导出空文件且自检条数一致', async () => {
  const exportsScope = makeMemoryScope('exports')
  const out = await exportBib({ exportsScope, topic: 'empty', cards: [], date: '2026-10-15' })
  assert.equal(out.entries.length, 0)
  assert.equal(out.check.ok, true, out.check.error || '')
  assert.equal(out.check.parsed, 0)
})
