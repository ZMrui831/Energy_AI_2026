// tests/chart-skill.test.mjs
//
// S17/S18「图与表」单测：真实 sqlite store（node:sqlite）+ 真实文件产物，不 mock 数据。
// S18 起 bars 指标 = 「证据引用 × 当前状态」分布（指标 A，替代 S17 无信息量的
// 「每条结论 × 证据条数」）；fixture 特意造出三类非零且 max≠min 的真实分布。
// 覆盖：出图尺寸合规 / 图内来源标注（drawn meta + 像素级差异）/ 无证据明确拒绝 /
//       sidecar 的 evidenceIds·sha256 与 DB 一致 / 表格含全部列 + docx /
//       S18：分布与 DB 独立复算一致且方差达标（≥3 类非零、max≠min）+ 标题论点句 /
//       S18：claimId 模式按该结论的证据出柱。

import test from 'node:test'
import assert from 'node:assert/strict'
import { spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT, dataPath } from '../packages/core/src/safefs.mjs'
import { createStore } from '../packages/core/src/db.mjs'
import { createClaim, attachEvidence, publishClaim } from '../packages/core/src/lifecycle/publish.mjs'
import { buildBarsArtifact, buildTableArtifact, pngSize, sha256Buf, resolvePython, RENDERER_PY } from '../packages/plugins/chart-skill/lib/chart.mjs'
import { ChartError, statusLabelOf } from '../packages/plugins/chart-skill/lib/data.mjs'

const TMP = dataPath('.tmp-chart-test')
const ART = join(TMP, 'artifacts')

async function seedStore() {
  if (existsSync(TMP)) rmSync(TMP, { recursive: true, force: true })
  mkdirSync(TMP, { recursive: true })
  const store = await createStore({ driver: 'sqlite', dbPath: join(TMP, 'orb.sqlite'), dataDir: TMP })
  store.initMigrations()
  const frame = (id, sha) => ({
    id, file_path: join(TMP, id + '.png'), sha256: sha, sensitivity: 'normal',
    created_at: new Date().toISOString(), expires_at: new Date(Date.now() + 3600000).toISOString(),
    status: 'ready', size_bytes: 1, format: 'png', mode: 'lowres', monitor_id: 'M1', consent_id: 'demo', trace_id: 'tr-chart',
  })
  store.insertRawFrame(frame('rf-chart-a', 'a'.repeat(64)))
  store.insertRawFrame(frame('rf-chart-b', 'b'.repeat(64)))
  store.insertRawFrame(frame('rf-chart-c', 'c'.repeat(64)))
  store.insertRawFrame(frame('rf-chart-gone', 'd'.repeat(64))) // 先登记后抹除 → 引用断链
  // ready 帧落真实文件（resolveEvidence 对 ready 会查盘）；insertRawFrame 恒写 ready，
  // 「已按策略删除」用公开 API setRawFrameStatus 置位（与 cleaner 同一通道）
  for (const id of ['rf-chart-a', 'rf-chart-b', 'rf-chart-c']) writeFileSync(join(TMP, id + '.png'), 'png-bytes')
  store.setRawFrameStatus('rf-chart-c', 'deleted')
  createClaim(store, { id: 'clm-chart-1', kind: 'observation', text: '双源校验显示该 DOI 真实存在，且引文逐字命中。', evidenceMode: 'direct' })
  attachEvidence(store, { claimId: 'clm-chart-1', evidenceId: 'rf-chart-a', layer: 'raw_frame', relation: 'direct', sha256: 'a'.repeat(64) })
  attachEvidence(store, { claimId: 'clm-chart-1', evidenceId: 'rf-chart-b', layer: 'raw_frame', relation: 'direct', sha256: 'b'.repeat(64) })
  attachEvidence(store, { claimId: 'clm-chart-1', evidenceId: 'rf-chart-c', layer: 'raw_frame', relation: 'direct', sha256: 'c'.repeat(64) })
  assert.equal(publishClaim(store, 'clm-chart-1').ok, true)
  createClaim(store, { id: 'clm-chart-2', kind: 'observation', text: '第二条已发布结论（单证据）。', evidenceMode: 'direct' })
  attachEvidence(store, { claimId: 'clm-chart-2', evidenceId: 'rf-chart-a', layer: 'raw_frame', relation: 'direct', sha256: 'a'.repeat(64) })
  attachEvidence(store, { claimId: 'clm-chart-2', evidenceId: 'rf-chart-gone', layer: 'raw_frame', relation: 'direct', sha256: 'd'.repeat(64) })
  assert.equal(publishClaim(store, 'clm-chart-2').ok, true)
  // 发布后抹除 raw_frame 行（复现生产库的断链引用：行没了，claim_evidence 仍在）
  store._db.prepare("DELETE FROM raw_frame WHERE id = 'rf-chart-gone'").run()
  createClaim(store, { id: 'clm-chart-draft', kind: 'observation', text: '未核验的猜测不进图。', evidenceMode: 'none' })
  return store
}

/** 独立复算：不经过 chart-skill 的聚合代码，直接从 DB 推期望分布。 */
function expectDistributionFromDb(store) {
  const rows = store._db.prepare('SELECT ce.evidence_id, ce.layer, rf.status AS rfStatus, rf.file_path AS filePath FROM claim_evidence ce LEFT JOIN raw_frame rf ON rf.id = ce.evidence_id').all()
  const counts = new Map()
  for (const r of rows) {
    let status
    if (!r.rfStatus) status = 'unregistered'
    else if (r.rfStatus === 'deleted' || r.rfStatus === 'error') status = r.rfStatus
    else status = existsSync(r.filePath) ? 'available' : 'missing'
    counts.set(statusLabelOf(status), (counts.get(statusLabelOf(status)) || 0) + 1)
  }
  return counts
}

test('chart: bars 出图尺寸合规（PNG ≥1600×1000，真实 Pillow 渲染）', async () => {
  const store = await seedStore()
  try {
    const r = await buildBarsArtifact({ store, outDir: ART })
    assert.ok(existsSync(r.pngPath), 'PNG 必须落盘：' + r.pngPath)
    const buf = readFileSync(r.pngPath)
    const size = pngSize(buf)
    assert.ok(size.width >= 1600 && size.height >= 1000, `尺寸 ${size.width}×${size.height} 必须 ≥1600×1000`)
    assert.ok(buf.length > 20_000, 'PNG 过小疑似空图：' + buf.length + 'B')
    assert.ok(existsSync(r.pngPath + '.drawn.json'), '渲染器必须回写 drawn meta')
  } finally { try { store.close() } catch { /* noop */ } }
})

test('chart: 来源标注在图内（drawn meta 含 evidence_id + 有/无标注像素级差异）', async () => {
  const store = await seedStore()
  try {
    // ① 生产产物：drawn meta 必须记录标注行，且含真实 evidence_id 与数据源
    const r = await buildBarsArtifact({ store, outDir: ART })
    const drawn = JSON.parse(readFileSync(r.pngPath + '.drawn.json', 'utf8'))
    const annText = drawn.annotationLines.join(' ')
    assert.ok(annText.includes('evidence_id='), 'drawn 必须记录标注行')
    assert.ok(annText.includes('rf-chart-a'), '标注必须含真实 evidence_id')
    assert.ok(annText.includes('claim_evidence'), '标注必须指明数据源')
    // ② 渲染器像素级证明：同一画面，去掉标注后 PNG 必然不同（标注真的画进图）
    const py = await resolvePython()
    const base = {
      out: join(TMP, 'with-annotation.png'),
      title: '证据链实况', subtitle: '', xLabel: '证据当前状态', yLabel: '证据引用条数',
      annotation: '来源：claim_evidence · evidence_id=rf-chart-a, rf-chart-b · research-orb 0.7.0',
      bars: [{ label: '原图仍在', value: 2, tier: '原图仍在' }, { label: '引用断链', value: 1, tier: '引用断链' }],
      tiers: { 原图仍在: '#0f766e', 引用断链: '#d97706' },
    }
    const render = async (payload) => {
      const p = join(TMP, 'payload.json')
      writeFileSync(p, JSON.stringify(payload), 'utf8')
      const res = spawnSync(py.path, [RENDERER_PY, p], { encoding: 'utf8', timeout: 60000, windowsHide: true })
      assert.equal(res.status, 0, '渲染必须成功：' + String(res.stderr).slice(0, 120))
      return readFileSync(payload.out)
    }
    const withAnn = await render(base)
    const withoutAnn = await render({ ...base, annotation: '', out: join(TMP, 'no-annotation.png') })
    assert.notEqual(withAnn.toString('hex'), withoutAnn.toString('hex'), '有/无标注的图像必须不同（标注在图内）')
  } finally { try { store.close() } catch { /* noop */ } }
})

test('chart: 无证据输入给明确错误码（E_NO_EVIDENCE）', async () => {
  const store = await seedStore()
  try {
    const empty = await createStore({ driver: 'sqlite', dbPath: join(TMP, 'empty.sqlite'), dataDir: join(TMP, 'empty') })
    empty.initMigrations()
    createClaim(empty, { id: 'clm-chart-only-draft', kind: 'observation', text: '只有草稿。', evidenceMode: 'none' })
    let err = null
    try { await buildBarsArtifact({ store: empty, outDir: ART }) } catch (e) { err = e }
    assert.ok(err instanceof ChartError && err.code === 'E_NO_EVIDENCE', '聚合无证据 code=' + (err && err.code))
    let err2 = null
    try { await buildBarsArtifact({ store, claimId: 'clm-chart-draft', outDir: ART }) } catch (e) { err2 = e }
    assert.ok(err2 instanceof ChartError && err2.code === 'E_NO_EVIDENCE', '指定无证据 claim code=' + (err2 && err2.code))
    try { empty.close() } catch { /* noop */ }
  } finally { try { store.close() } catch { /* noop */ } }
})

test('chart: sidecar 的 evidenceIds 与 DB 一致，sha256 可校验', async () => {
  const store = await seedStore()
  try {
    const r = await buildBarsArtifact({ store, outDir: ART })
    const sidecar = JSON.parse(readFileSync(r.sidecarPath, 'utf8'))
    const dbIds = store._db.prepare('SELECT DISTINCT evidence_id FROM claim_evidence').all().map((x) => x.evidence_id)
    assert.ok(sidecar.evidenceIds.length > 0, 'evidenceIds 非空')
    for (const id of sidecar.evidenceIds) {
      assert.ok(dbIds.includes(id), 'sidecar evidenceId 必须能在 DB 查到：' + id)
    }
    assert.equal(sidecar.sha256.png, sha256Buf(readFileSync(r.pngPath)), 'sha256(png) 必须可校验')
    assert.equal(sidecar.claimIds.length, store._db.prepare('SELECT COUNT(*) c FROM claim').get().c, 'claimIds = 全部结论（含草稿，口径见副标题）')
    assert.equal(sidecar.publishedClaimIds.length, store._db.prepare("SELECT COUNT(*) c FROM claim WHERE status='published'").get().c, 'publishedClaimIds = 已发布结论')
  } finally { try { store.close() } catch { /* noop */ } }
})

test('chart: 指标 A 分布与 DB 独立复算一致，且方差达标（≥3 类非零、max≠min），标题为论点句', async () => {
  const store = await seedStore()
  try {
    const r = await buildBarsArtifact({ store, outDir: ART })
    const sidecar = JSON.parse(readFileSync(r.sidecarPath, 'utf8'))
    const drawn = JSON.parse(readFileSync(r.pngPath + '.drawn.json', 'utf8'))
    // ① 与独立复算一致（不过 chart-skill 聚合代码）
    const expect = expectDistributionFromDb(store)
    assert.deepEqual(sidecar.distribution, Object.fromEntries(expect), 'sidecar.distribution 必须与 DB 独立复算一致')
    assert.equal(sidecar.metric, 'evidence-status')
    assert.equal(drawn.metric, 'evidence-status')
    // ② 方差硬标准：≥3 类非零且 max≠min
    const values = Object.values(sidecar.distribution)
    assert.ok(values.length >= 3, '非零类必须 ≥3：' + JSON.stringify(sidecar.distribution))
    assert.ok(Math.max(...values) !== Math.min(...values), 'max≠min：' + JSON.stringify(sidecar.distribution))
    assert.equal(sidecar.varianceOk, true)
    assert.equal(drawn.varianceOk, true)
    assert.deepEqual(drawn.barValues, values, 'drawn.barValues 必须与 sidecar 分布一致')
    // ③ 标题论点句：含总数与每一类的真实计数
    const total = values.reduce((a, b) => a + b, 0)
    assert.ok(drawn.title.includes(String(total) + ' 条证据引用'), '标题必须含总数：' + drawn.title)
    for (const [label, v] of Object.entries(sidecar.distribution)) {
      assert.ok(drawn.title.includes(v + ' 条' + label), '标题必须含该类计数：' + label + ' → ' + drawn.title)
    }
  } finally { try { store.close() } catch { /* noop */ } }
})

test('chart: claimId 模式只画该结论的证据（按状态聚合）', async () => {
  const store = await seedStore()
  try {
    const r = await buildBarsArtifact({ store, claimId: 'clm-chart-1', outDir: ART })
    const drawn = JSON.parse(readFileSync(r.pngPath + '.drawn.json', 'utf8'))
    const sidecar = JSON.parse(readFileSync(r.sidecarPath, 'utf8'))
    // clm-chart-1：a/b 原图仍在 + c 已删除 → 两类，值 2/1
    assert.deepEqual(sidecar.distribution, { 原图仍在: 2, 已按策略删除: 1 })
    assert.deepEqual(drawn.barValues, [2, 1])
    assert.deepEqual(sidecar.claimIds, ['clm-chart-1'])
    assert.ok(drawn.title.includes('结论'), '标题应点明是单结论视图：' + drawn.title)
    assert.ok(drawn.title.includes('2 条原图仍在') && drawn.title.includes('1 条已按策略删除'), '标题含真实计数：' + drawn.title)
  } finally { try { store.close() } catch { /* noop */ } }
})

test('chart: 表格含全部列（claim_id/状态/证据档位/证据数/证据编号）+ docx 落盘', async () => {
  const store = await seedStore()
  try {
    const r = await buildTableArtifact({ store, outDir: ART })
    for (const col of ['claim_id', '状态', '证据档位', '证据数', '证据编号']) {
      assert.ok(r.md.includes('| ' + col + ' '), '表头必须含列：' + col)
    }
    assert.ok(r.md.includes('clm-chart-1') && r.md.includes('rf-chart-a, rf-chart-b, rf-chart-c'), '表体含真实 claim 与证据编号')
    const docx = readFileSync(r.docxPath)
    assert.ok(docx.length > 1000, 'docx 非空')
    assert.equal(docx.toString('ascii', 0, 2), 'PK', 'docx 是 zip 容器')
    const sidecar = JSON.parse(readFileSync(r.sidecarPath, 'utf8'))
    assert.equal(sidecar.sha256.md, sha256Buf(readFileSync(r.mdPath)), 'sha256(md) 可校验')
    assert.equal(sidecar.sha256.docx, sha256Buf(docx), 'sha256(docx) 可校验')
  } finally { try { store.close() } catch { /* noop */ } }
})

test.after(() => {
  if (existsSync(TMP)) rmSync(TMP, { recursive: true, force: true })
})
