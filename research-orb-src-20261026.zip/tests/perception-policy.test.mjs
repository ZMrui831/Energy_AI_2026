// tests/perception-policy.test.mjs
//
// §5.4 五状态采样决策表 + §5.6 同意流 + §5.7 敏感黑名单 回归（纯函数，零真实盘污染）。
// 覆盖：五状态决策表 × 关键信号；learning 硬上限 minIntervalMs≥20000（即使 config 更小）；
//       consent 三模式 isActive / allowsScreenCapture / remainingMs / 重启不恢复；黑名单命中/不中/大小写/可配覆盖。

import test from 'node:test'
import assert from 'node:assert/strict'

import { decide, isSensitive, LEARNING_MIN_INTERVAL_MS } from '../packages/plugins/perception/sampler.mjs'
import {
  grant, isActive, allowsScreenCapture, revoke, remainingMs,
  FOUR_HOURS,
} from '../packages/plugins/perception/consent.mjs'

// ───────────────────────── 五状态决策表 ─────────────────────────

test('policy: idle → 30s轮询/60s聚合/60s差分/不截图/不可打扰', () => {
  const d = decide('idle')
  assert.equal(d.pollMs, 30000)
  assert.equal(d.aggregateMs, 60000)
  assert.equal(d.diffMs, 60000)
  assert.equal(d.capture.enabled, false)
  assert.equal(d.uploadModel, false)
  assert.equal(d.interruptible, false)
})

test('policy: normal → 5s轮询/10s聚合/5s差分/截图阈值0.12/每60s≤1张', () => {
  const d = decide('normal')
  assert.equal(d.pollMs, 5000)
  assert.equal(d.aggregateMs, 10000)
  assert.equal(d.diffMs, 5000)
  assert.equal(d.capture.enabled, true)
  assert.equal(d.capture.threshold, 0.12)
  assert.equal(d.capture.maxPerMinute, 1)
  assert.equal(d.capture.minIntervalMs, 60000)
})

test('policy: candidate → 1s轮询/1s聚合/5s差分/截图阈值0.08/每20s≤1张', () => {
  const d = decide('candidate')
  assert.equal(d.pollMs, 1000)
  assert.equal(d.aggregateMs, 1000)
  assert.equal(d.diffMs, 5000)
  assert.equal(d.capture.enabled, true)
  assert.equal(d.capture.threshold, 0.08)
  assert.equal(d.capture.maxPerMinute, 3)
  assert.equal(d.capture.minIntervalMs, 20000)
})

test('policy: learning → 1s廉价轮询/1s聚合/1s差分(仅直方图)/每20s≤1张/不上模型', () => {
  const d = decide('learning')
  assert.equal(d.pollMs, 1000)
  assert.equal(d.aggregateMs, 1000)
  assert.equal(d.diffMs, 1000)
  assert.equal(d.capture.enabled, true)
  assert.equal(d.capture.maxPerMinute, 3)
  assert.equal(d.capture.minIntervalMs, LEARNING_MIN_INTERVAL_MS)
  assert.equal(d.uploadModel, false)
})

test('policy: dnd → 30s元数据/不持久化/差分关闭/不截图/不可打扰', () => {
  const d = decide('dnd')
  assert.equal(d.pollMs, 30000)
  assert.equal(d.aggregateMs, 0)
  assert.equal(d.diffMs, 0)
  assert.equal(d.capture.enabled, false)
  assert.equal(d.interruptible, false)
})

test('policy: 非法 state 抛错', () => {
  assert.throws(() => decide('sleeping'), /非法 state/)
})

// ───────────────────────── learning 硬上限（§1-4）─────────────────────────

test('policy: learning 硬上限 — config 给 minIntervalMs=5000 仍被钳制到 20000', () => {
  const d = decide('learning', {}, { overrides: { learning: { capture: { minIntervalMs: 5000 } } } })
  assert.equal(d.capture.minIntervalMs, LEARNING_MIN_INTERVAL_MS)
  assert.ok(d.capture.minIntervalMs >= 20000)
})

test('policy: learning 硬上限 — config 给 maxPerMinute=10 仍被钳制到 3', () => {
  const d = decide('learning', {}, { overrides: { learning: { capture: { maxPerMinute: 10 } } } })
  assert.equal(d.capture.maxPerMinute, 3)
})

test('policy: learning 硬上限 — 即便 enabled 为 false 的 config 也保持≥20000', () => {
  const d = decide('learning', {}, { overrides: { learning: { capture: { minIntervalMs: 1000, maxPerMinute: 99 } } } })
  assert.equal(d.capture.minIntervalMs, 20000)
  assert.equal(d.capture.maxPerMinute, 3)
})

// ───────────────────────── 冷启动保护 ─────────────────────────

test('policy: 冷启动 — normal 态且启动 <5min 时关闭截图', () => {
  const now = 1_000_000
  const d = decide('normal', {}, { coldStart: true, now, processStartedAt: now - 60_000 })
  assert.equal(d.capture.enabled, false)
})

test('policy: 冷启动 — normal 态且启动 >5min 后恢复截图', () => {
  const now = 1_000_000
  const d = decide('normal', {}, { coldStart: true, now, processStartedAt: now - 600_000 })
  assert.equal(d.capture.enabled, true)
})

// ───────────────────────── §5.6 同意流 ─────────────────────────

test('consent: session 未过期且本进程授权 → isActive true / allowsScreenCapture true', () => {
  const c = grant('session', { now: 1000, ttl: FOUR_HOURS })
  const ctx = { now: 1000 + 1000, processStartedAt: 500 } // 启动早于授权
  assert.equal(isActive(c, ctx), true)
  assert.equal(allowsScreenCapture(c, ctx), true)
})

test('consent: session 过期 → isActive false', () => {
  const c = grant('session', { now: 1000, ttl: 1000 })
  const ctx = { now: 1000 + 2000, processStartedAt: 500 } // now > expiresAt
  assert.equal(isActive(c, ctx), false)
  assert.equal(allowsScreenCapture(c, ctx), false)
})

test('consent: session 重启后不恢复（processStartedAt > grantedAt）→ false', () => {
  const c = grant('session', { now: 1000, ttl: FOUR_HOURS })
  const ctx = { now: 2000, processStartedAt: 5000 } // 启动晚于授权 = 重启过
  assert.equal(isActive(c, ctx), false)
})

test('consent: session 未重启（processStartedAt ≤ grantedAt）→ true', () => {
  const c = grant('session', { now: 5000, ttl: FOUR_HOURS })
  const ctx = { now: 6000, processStartedAt: 1000 } // 启动早于授权 = 同进程
  assert.equal(isActive(c, ctx), true)
})

test('consent: metadata-only → isActive true 但 allowsScreenCapture false（仅元数据）', () => {
  const c = grant('metadata-only', { now: 1000 })
  assert.equal(isActive(c, {}), true)
  assert.equal(allowsScreenCapture(c, {}), false)
  assert.equal(c.expiresAt, undefined) // 无强过期
})

test('consent: denied → isActive false / allowsScreenCapture false', () => {
  const c = grant('denied')
  assert.equal(isActive(c, {}), false)
  assert.equal(allowsScreenCapture(c, {}), false)
})

test('consent: session expiresAt 不超过 4h（ttl 默认封顶）', () => {
  const c = grant('session', { now: 0 })
  assert.equal(c.expiresAt, FOUR_HOURS)
  const c2 = grant('session', { now: 0, ttl: FOUR_HOURS * 2 })
  assert.equal(c2.expiresAt, FOUR_HOURS) // 被封顶
})

test('consent: remainingMs — 会话剩余 >0 / 过期为 0', () => {
  const c = grant('session', { now: 0, ttl: 1000 })
  assert.equal(remainingMs(c, { now: 500 }), 500)
  assert.equal(remainingMs(c, { now: 2000 }), 0)
  assert.equal(remainingMs(grant('metadata-only', { now: 0 })), 0) // 非 session 为 0
})

test('consent: revoke → 返回 denied 且清敏感字段', () => {
  const c = grant('session', { now: 1000, ttl: FOUR_HOURS })
  const r = revoke(c)
  assert.equal(r.mode, 'denied')
  assert.equal(r.expiresAt, undefined)
  assert.equal(isActive(r, { now: 2000, processStartedAt: 500 }), false)
})

test('consent: 非法 mode 抛错', () => {
  assert.throws(() => grant('always'), /非法 mode/)
})

// ───────────────────────── §5.7 敏感黑名单 ─────────────────────────

test('blacklist: 命中默认正则 — 1Password 标题', () => {
  assert.equal(isSensitive('1Password - vault', '1password'), true)
})

test('blacklist: 命中默认正则 — 中文「银行」', () => {
  assert.equal(isSensitive('网上银行登录', 'chrome'), true)
})

test('blacklist: 大小写不敏感 — BANK', () => {
  assert.equal(isSensitive('My Bank App', 'bank.exe'), true)
})

test('blacklist: 不命中普通窗口', () => {
  assert.equal(isSensitive('VS Code', 'code'), false)
})

test('blacklist: 可配覆盖（字符串）', () => {
  assert.equal(isSensitive('Secret Notes', 'notepad', 'Secret'), true)
  assert.equal(isSensitive('Bank Login', 'chrome', 'Secret'), false)
})

test('blacklist: 可配覆盖（RegExp）', () => {
  const re = /topsecret|confidential/i
  assert.equal(isSensitive('TopSecret file', 'x', re), true)
  assert.equal(isSensitive('Bank', 'x', re), false)
})

test('blacklist: 敏感信号传入 decide → 强制关闭截图', () => {
  const d = decide('normal', { sensitive: true })
  assert.equal(d.capture.enabled, false)
})
