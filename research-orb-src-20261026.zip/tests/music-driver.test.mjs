// tests/music-driver.test.mjs
//
// S13 音乐驱动器纯 node 单测（独立进程，不碰真 Electron / 真 PowerShell）。
// 与 tools/accept-s13-music.mjs 的真实应用链路互为独立证据源（CONTRACT §7 独立性）。

import test from 'node:test'
import assert from 'node:assert/strict'
import { EventEmitter } from 'node:events'
import { PassThrough } from 'node:stream'
import { existsSync, mkdirSync, rmSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT, dataPath } from '../packages/core/src/safefs.mjs'
import {
  createMusicDriver,
  DEFAULT_MUSIC_CONFIG,
  readMusicConfig,
  writeMusicConfig,
} from '../apps/desktop/music-driver.mjs'

const TMP = dataPath('.tmp-music-test')
const CFG = join(TMP, 'config.json')
const ALLOW = join(TMP, 'music-allowlist.json')

function reset() {
  if (existsSync(TMP)) rmSync(TMP, { recursive: true, force: true })
  mkdirSync(TMP, { recursive: true })
  writeFileSync(CFG, JSON.stringify({ activePack: 'research', theme: 'teal', edition: 'personal' }, null, 2))
}

/** 收集审计行（不落生产 data/logs）。 */
function auditSink() {
  const rows = []
  return { rows, audit: (kind, detail) => rows.push(Object.assign({ kind }, detail || {})) }
}

/** 假 BrowserWindow：executeJavaScript 按脚本内容返回预设结果。 */
function fakeElectron({ fetchImpl, execResults = {} } = {}) {
  const execLog = []
  const win = {
    _destroyed: false,
    isDestroyed: () => win._destroyed,
    destroy() { win._destroyed = true },
    setIgnoreMouseEvents() { /* noop */ },
    loadFile() { return Promise.resolve() },
    on() { /* noop */ },
    webContents: {
      on() { /* noop */ },
      executeJavaScript(code) {
        execLog.push(String(code))
        if (/__musicAmbient\.start/.test(code)) return Promise.resolve(execResults.ambient || { ok: true, muted: false })
        if (/__musicAmbient\.stop/.test(code)) return Promise.resolve({ ok: true })
        if (/__musicAudio\.stop/.test(code)) return Promise.resolve({ ok: true })
        if (/__musicAudio\.play/.test(code)) return Promise.resolve(execResults.play || { ok: true, muted: false })
        return Promise.resolve(null)
      },
    },
  }
  return {
    electron: {
      app: {},
      BrowserWindow: class { constructor() { return win } },
      net: { fetch: fetchImpl || (() => Promise.reject(new Error('no-net'))) },
      protocol: {},
    },
    win,
    execLog,
  }
}

/** 假 level collector 注入点：spawn 一个 EventEmitter，stdout 推样本行。 */
function fakeLevel() {
  const children = []
  const killed = []
  const spawnImpl = (cmd, args) => {
    const c = new EventEmitter()
    c.stdout = new PassThrough()
    c.pid = 1000 + children.length
    c.kill = () => { killed.push(c.pid); return true }
    children.push({ c, cmd, args })
    return c
  }
  const killTreeImpl = (pid) => killed.push(['tree', pid])
  return { spawnImpl, killTreeImpl, children, killed }
}

function pushLine(entry, line) {
  entry.c.stdout.write(line + '\n')
}

// ---------------------------------------------------------------------------
test('music: 默认配置 networkEnabled 必须为 false（红线 1）', () => {
  reset()
  const cfg = readMusicConfig(CFG)
  assert.equal(cfg.networkEnabled, false)
  assert.equal(cfg.enabled, true)
  assert.equal(DEFAULT_MUSIC_CONFIG.networkEnabled, false)
  assert.ok(cfg.allowlistHosts.includes('de1.api.radio-browser.info'))
})

test('music: writeMusicConfig 保留其余顶层键，且 networkEnabled 只在显式 true 时为真', () => {
  reset()
  const a = writeMusicConfig({ volume: 0.3 }, CFG)
  assert.equal(a.volume, 0.3)
  assert.equal(a.networkEnabled, false)
  const doc = JSON.parse(readFileSync(CFG, 'utf8'))
  assert.equal(doc.theme, 'teal')          // 其余顶层键保留
  assert.equal(doc.music.volume, 0.3)

  writeMusicConfig({ networkEnabled: true }, CFG)
  assert.equal(readMusicConfig(CFG).networkEnabled, true)
  writeMusicConfig({ networkEnabled: 'yes' }, CFG)   // 非严格 true → false
  assert.equal(readMusicConfig(CFG).networkEnabled, false)
})

test('music: readMusicConfig 对损坏配置回落默认', () => {
  reset()
  writeFileSync(CFG, '{ not json')
  const cfg = readMusicConfig(CFG)
  assert.equal(cfg.networkEnabled, false)
  assert.equal(cfg.levelHz, 30)
})

test('music: hostAllowed —— 白名单主机 true，任意主机 false', () => {
  reset()
  const sink = auditSink()
  const fe = fakeElectron()
  const d = createMusicDriver({
    electron: fe.electron, send: () => {}, audit: sink.audit, configPath: CFG, allowlistPath: ALLOW,
  })
  assert.equal(d.hostAllowed('de1.api.radio-browser.info'), true)
  assert.equal(d.hostAllowed('DE1.api.radio-browser.info'), true)   // 大小写归一
  assert.equal(d.hostAllowed('evil.tld'), false)
  assert.equal(d.hostAllowed(''), false)
  assert.equal(d.hostAllowed('api.deepseek.com.evil.tld'), false)   // 后缀伪装必须拒
})

test('music: allowHost 逐条加入运行时白名单并审计', () => {
  reset()
  const sink = auditSink()
  const fe = fakeElectron()
  const d = createMusicDriver({
    electron: fe.electron, send: () => {}, audit: sink.audit, configPath: CFG, allowlistPath: ALLOW,
  })
  assert.equal(d.hostAllowed('stream.example.net'), false)
  d.allowHost('stream.example.net', 'test')
  assert.equal(d.hostAllowed('stream.example.net'), true)
  const doc = JSON.parse(readFileSync(ALLOW, 'utf8'))
  assert.deepEqual(doc.hosts, ['stream.example.net'])
  assert.ok(sink.rows.some((r) => r.kind === 'allow-host' && r.host === 'stream.example.net'))
})

test('music: streamHandler 拒绝非白名单主机 → 403 + 审计', async () => {
  reset()
  const sink = auditSink()
  const fe = fakeElectron()
  writeMusicConfig({ networkEnabled: true }, CFG)
  const d = createMusicDriver({
    electron: fe.electron, send: () => {}, audit: sink.audit, configPath: CFG, allowlistPath: ALLOW,
  })
  const res = await d.streamHandler({ url: 'music-stream://evil.tld/live.mp3' })
  assert.equal(res.status, 403)
  const row = sink.rows.find((r) => r.kind === 'reject-host')
  assert.ok(row, '必须有 reject-host 审计行')
  assert.equal(row.host, 'evil.tld')
  assert.equal(row.stage, 'stream')
})

test('music: streamHandler 在联网开关关闭时拒绝 → 403 + 审计', async () => {
  reset()
  const sink = auditSink()
  const fe = fakeElectron()
  const d = createMusicDriver({
    electron: fe.electron, send: () => {}, audit: sink.audit, configPath: CFG, allowlistPath: ALLOW,
  })
  // 主机先加入白名单，证明拒绝来自"开关"而非白名单
  d.allowHost('stream.example.net', 'test')
  const res = await d.streamHandler({ url: 'music-stream://stream.example.net/live.mp3' })
  assert.equal(res.status, 403)
  assert.ok(sink.rows.some((r) => r.kind === 'reject-network-disabled'))
})

test('music: streamHandler 流式转发不落盘（无 fs 写调用即通过——本测试不注入任何写路径）', async () => {
  reset()
  const sink = auditSink()
  let bodySeen = null
  const fetchImpl = async () => new Response('audio-bytes', { status: 200, headers: { 'content-type': 'audio/mpeg' } })
  const fe = fakeElectron({ fetchImpl })
  writeMusicConfig({ networkEnabled: true }, CFG)
  const d = createMusicDriver({
    electron: fe.electron, send: () => {}, audit: sink.audit, configPath: CFG, allowlistPath: ALLOW,
  })
  d.allowHost('stream.example.net', 'test')
  const res = await d.streamHandler({ url: 'music-stream://stream.example.net/live.mp3' })
  assert.equal(res.status, 200)
  assert.equal(res.headers.get('content-type'), 'audio/mpeg')
  assert.equal(res.headers.get('cache-control'), 'no-store')
  bodySeen = await res.text()
  assert.equal(bodySeen, 'audio-bytes')
  assert.ok(sink.rows.some((r) => r.kind === 'stream-open' && r.host === 'stream.example.net'))
})

test('music: 电台清单过滤 http 流与 hls 流，并把可用主机逐条加白', async () => {
  reset()
  const sink = auditSink()
  const rows = [
    { stationuuid: 'u-https', name: 'Good HTTPS', url_resolved: 'https://a.example.net/live.mp3', codec: 'MP3', hls: 0, lastcheckok: 1 },
    { stationuuid: 'u-http', name: 'Bad HTTP', url_resolved: 'http://b.example.net/live.mp3', codec: 'MP3', hls: 0, lastcheckok: 1 },
    { stationuuid: 'u-hls', name: 'Bad HLS', url_resolved: 'https://c.example.net/live.m3u8', codec: 'HLS', hls: 1, lastcheckok: 1 },
    { stationuuid: 'u-ok2', name: 'Good 2', url_resolved: 'https://d.example.net/live.aac', codec: 'AAC', lastcheckok: 1 },
  ]
  const fetchImpl = async (url) => {
    if (String(url).includes('/json/stations/topclick')) {
      return new Response(JSON.stringify(rows), { status: 200, headers: { 'content-type': 'application/json' } })
    }
    return new Response('{}', { status: 200 })
  }
  const fe = fakeElectron({ fetchImpl })
  writeMusicConfig({ networkEnabled: true }, CFG)
  const d = createMusicDriver({
    electron: fe.electron, send: () => {}, audit: sink.audit, configPath: CFG, allowlistPath: ALLOW,
  })
  const r = await d.listStations()
  assert.equal(r.ok, true)
  assert.equal(r.stations.length, 2)
  assert.deepEqual(r.stations.map((s) => s.uuid), ['u-https', 'u-ok2'])
  assert.equal(d.hostAllowed('a.example.net'), true)
  assert.equal(d.hostAllowed('d.example.net'), true)
  assert.equal(d.hostAllowed('b.example.net'), false)
  assert.equal(d.hostAllowed('c.example.net'), false)
})

test('music: 联网开关关闭时 listStations 与 playStation 一律拒绝', async () => {
  reset()
  const sink = auditSink()
  const fe = fakeElectron()
  const d = createMusicDriver({
    electron: fe.electron, send: () => {}, audit: sink.audit, configPath: CFG, allowlistPath: ALLOW,
  })
  const r = await d.listStations()
  assert.equal(r.ok, false)
  assert.equal(r.code, 'E_MUSIC_NETWORK_DISABLED')
  const p = await d.playStation('u-https')
  assert.equal(p.ok, false)
  assert.equal(p.code, 'E_MUSIC_NETWORK_DISABLED')
  assert.ok(sink.rows.some((x) => x.kind === 'stations-rejected'))
})

test('music: playStation 走 music-stream:// 且主机已加白；播放/点击各记审计', async () => {
  reset()
  const sink = auditSink()
  const rows = [
    { stationuuid: 'u-https', name: 'Good HTTPS', url_resolved: 'https://a.example.net/live.mp3?x=1', codec: 'MP3', hls: 0, lastcheckok: 1 },
  ]
  const fetchImpl = async (url) => {
    const u = String(url)
    if (u.includes('/json/stations/topclick')) return new Response(JSON.stringify(rows), { status: 200 })
    return new Response('{}', { status: 200 })
  }
  const fe = fakeElectron({ fetchImpl })
  writeMusicConfig({ networkEnabled: true }, CFG)
  const d = createMusicDriver({
    electron: fe.electron, send: () => {}, audit: sink.audit, configPath: CFG, allowlistPath: ALLOW,
  })
  const r = await d.playStation('u-https')
  assert.equal(r.ok, true)
  const playCall = fe.execLog.find((c) => c.includes('__musicAudio.play'))
  assert.ok(playCall, '必须驱动音频窗口播放')
  assert.ok(playCall.includes('music-stream://a.example.net/live.mp3?x=1'), '必须走协议代理：' + playCall)
  assert.ok(!playCall.includes('https://a.example.net'), '不得把远端 https 直给 renderer（CSP 会拦）')
  const st = d.state()
  assert.equal(st.source, 'radio')
  assert.equal(st.station, 'Good HTTPS')
  assert.equal(st.playing, true)
  assert.ok(sink.rows.some((x) => x.kind === 'play' && x.host === 'a.example.net' && x.source === 'radio'))
})

test('music: T0 环境音播放零网络（不调 net.fetch）+ 审计', async () => {
  reset()
  const sink = auditSink()
  let fetchCalls = 0
  const fe = fakeElectron({ fetchImpl: () => { fetchCalls += 1; return Promise.reject(new Error('should-not-fetch')) } })
  const d = createMusicDriver({
    electron: fe.electron, send: () => {}, audit: sink.audit, configPath: CFG, allowlistPath: ALLOW,
  })
  const r = await d.playAmbient()
  assert.equal(r.ok, true)
  assert.equal(fetchCalls, 0)
  assert.equal(d.state().playing, true)
  assert.equal(d.state().source, 'ambient')
  const row = sink.rows.find((x) => x.kind === 'play')
  assert.equal(row.host, '(local)')
  assert.equal(row.degraded, false)
})

test('music: stopMusic 记 stop 审计含时长与 host', async () => {
  reset()
  const sink = auditSink()
  const fe = fakeElectron()
  let t = 1_000_000
  const d = createMusicDriver({
    electron: fe.electron, send: () => {}, audit: sink.audit, configPath: CFG, allowlistPath: ALLOW,
    now: () => t,
  })
  await d.playAmbient()
  t += 4200
  await d.stopMusic()
  const row = sink.rows.find((x) => x.kind === 'stop')
  assert.ok(row)
  assert.equal(row.durationMs, 4200)
  assert.equal(row.source, 'ambient')
  assert.equal(row.host, '(local)')
})

test('music: 30Hz 电平样本 → music:level 下行，bands 16 段且取值合法', async () => {
  reset()
  const sink = auditSink()
  const sent = []
  const lv = fakeLevel()
  let t = 0
  const d = createMusicDriver({
    electron: null, send: (m) => sent.push(m), audit: sink.audit, configPath: CFG, allowlistPath: ALLOW,
    spawnImpl: lv.spawnImpl, killTreeImpl: lv.killTreeImpl, now: () => (t += 100),
  })
  d.start()
  assert.equal(lv.children.length, 1, '必须起一个采集器')
  assert.equal(lv.children[0].args[0], '-NoProfile')
  assert.ok(lv.children[0].args.some((a) => String(a).includes('level-collector.ps1')), '必须指向 ps1 采集器')

  pushLine(lv.children[0], JSON.stringify({ ts: 1, peak: 0.5 }))
  pushLine(lv.children[0], 'not json')            // 脏行不抛
  pushLine(lv.children[0], '')                     // 空行
  pushLine(lv.children[0], JSON.stringify({ ts: 2, peak: 0.9 }))
  pushLine(lv.children[0], JSON.stringify({ ts: 3, error: 'no-endpoint' }))   // 错误行

  const levels = sent.filter((m) => m.type === 'music:level')
  assert.ok(levels.length >= 2, '两个有效样本至少推两帧：' + levels.length)
  for (const m of levels) {
    assert.equal(m.bands.length, 16)
    assert.ok(m.level >= 0 && m.level <= 1)
    assert.ok(m.peak >= 0 && m.peak <= 1)
    for (const b of m.bands) assert.ok(b >= 0 && b <= 1)
  }
  // 0.9 的峰值必须让 level 明显大于 0（包络在工作）
  const last = levels[levels.length - 1]
  assert.ok(last.peak > 0.8, 'peak 必须透传瞬时峰值')
})

test('music: setEnabled(false) 停采集并同步杀 PID 子树（/T /F）', () => {
  reset()
  const sink = auditSink()
  const lv = fakeLevel()
  const d = createMusicDriver({
    electron: null, send: () => {}, audit: sink.audit, configPath: CFG, allowlistPath: ALLOW,
    spawnImpl: lv.spawnImpl, killTreeImpl: lv.killTreeImpl,
  })
  d.start()
  assert.equal(d.isRunning(), true)
  d.setEnabled(false)
  assert.equal(d.isRunning(), false)
  assert.ok(lv.killed.some((k) => Array.isArray(k) && k[0] === 'tree'), '必须同步 taskkill 子树')
  assert.equal(readMusicConfig(CFG).enabled, false)

  // 再开：必须能重新起采集（stop→start 循环）
  d.setEnabled(true)
  assert.equal(d.isRunning(), true)
  assert.equal(lv.children.length, 2)
})

test('music: stop() 之后不再推电平、不再 spawn', () => {
  reset()
  const sink = auditSink()
  const sent = []
  const lv = fakeLevel()
  let t = 0
  const d = createMusicDriver({
    electron: null, send: (m) => sent.push(m), audit: sink.audit, configPath: CFG, allowlistPath: ALLOW,
    spawnImpl: lv.spawnImpl, killTreeImpl: lv.killTreeImpl, now: () => (t += 100),
  })
  d.start()
  const before = lv.children.length
  d.stop()
  pushLine(lv.children[0], JSON.stringify({ ts: 9, peak: 0.7 }))
  assert.equal(lv.children.length, before, 'stop 后不得再 spawn')
  const after = sent.filter((m) => m.type === 'music:level').length
  d.pushLevel(true)
  assert.equal(sent.filter((m) => m.type === 'music:level').length, after, 'stop 后不得再推电平')
})

test('music: 纯 node 模式（无 Electron）降级不崩', async () => {
  reset()
  const sink = auditSink()
  const d = createMusicDriver({
    electron: null, send: () => {}, audit: sink.audit, configPath: CFG, allowlistPath: ALLOW,
  })
  const r = await d.playAmbient()
  assert.equal(r.ok, false)
  assert.equal(d.state().degraded, true)
  assert.equal(typeof d.state().reason, 'string')
  assert.ok(sink.rows.some((x) => x.kind === 'play-failed' && x.degraded === true))
})

test.after(() => {
  if (existsSync(TMP)) rmSync(TMP, { recursive: true, force: true })
})
