import { resolve } from 'node:path'
// tests/tools-paths.test.mjs
//
// 路径解析层的钉子（P-R7）。
// 最重要的一条：**注册表登记的桌面 ≠ %USERPROFILE%\Desktop** 的真实用例
// （本机：登记值 D:\Desktop，USERPROFILE ${process.env.USERPROFILE}）。主管曾因猜测
// %USERPROFILE%\Desktop 把入口放到用户看不见的目录，被当场指出，所以这里
// 用注入式读取器把"两者不同"钉死，并要求 desktop: 一律走登记值。

import test from 'node:test'
import assert from 'node:assert/strict'

import {
  ALIASES,
  PathError,
  createPathResolver,
  readShellFolderDesktop,
  splitAlias,
} from '../packages/core/src/tools/paths.mjs'

const ROOT = resolve(import.meta.dirname, '..')
const HOME = process.env.USERPROFILE
// 系统登记的真实桌面（与 %USERPROFILE%\Desktop 不同 —— 本机事实）
const REAL_DESKTOP = 'D:\\Desktop'
const GUESSED_DESKTOP = `${process.env.USERPROFILE}\\Desktop`

/** 构造一个"注册表值与 %USERPROFILE%\Desktop 不同"的解析器。 */
function makeResolver(overrides = {}) {
  return createPathResolver({
    root: ROOT,
    home: HOME,
    env: { USERPROFILE: HOME },
    desktopReader: () => REAL_DESKTOP,
    ...overrides,
  })
}

test('paths: 别名切分 —— 单字符前缀是盘符不是别名，多字符走别名', () => {
  assert.deepEqual(splitAlias('D:\\a'), { alias: null, rest: 'D:\\a' })
  assert.deepEqual(splitAlias('desktop:a.docx'), { alias: 'desktop', rest: 'a.docx' })
  assert.deepEqual(splitAlias('DESKTOP:a.docx'), { alias: 'desktop', rest: 'a.docx' })
  assert.deepEqual(splitAlias('project:data/x'), { alias: 'project', rest: 'data/x' })
  assert.deepEqual(splitAlias('home:.x'), { alias: 'home', rest: '.x' })
  assert.deepEqual(splitAlias('/abs/path'), { alias: null, rest: '/abs/path' })
})

test('paths: desktop: 走系统登记值，绝不用 %USERPROFILE%\\Desktop 猜', () => {
  const r = makeResolver()
  assert.equal(r.desktop(), REAL_DESKTOP)
  const got = r.resolveInput('desktop:自我介绍.docx')
  assert.equal(got.ok, true)
  assert.equal(got.path, 'D:\\Desktop\\自我介绍.docx')
  assert.notEqual(got.path.indexOf(GUESSED_DESKTOP), 0)
  // 关键断言：解析结果与"猜出来的路径"必须不同，否则说明又回退了
  assert.notEqual(got.path, GUESSED_DESKTOP + '\\自我介绍.docx')
  assert.equal(got.source, 'desktop')
})

test('paths: 注册表值与 %USERPROFILE%\\Desktop 不同这一事实被显式记录在案', () => {
  const r = makeResolver()
  const d = r.describe()
  assert.equal(d.desktop, REAL_DESKTOP)
  assert.equal(d.home, HOME)
  assert.notEqual(d.desktop, d.home + '\\Desktop')
  assert.match(d.desktopSource, /Shell Folders/)
})

test('paths: 注册表读不到 -> fail-closed（E_DESKTOP_UNRESOLVED），不回退猜测', () => {
  const r = makeResolver({ desktopReader: () => null })
  const got = r.resolveInput('desktop:a.docx')
  assert.equal(got.ok, false)
  assert.equal(got.code, 'E_DESKTOP_UNRESOLVED')
  assert.match(got.message, /拒绝回退/)
})

test('paths: 注册表读取器抛异常也算读不到（不静默吞成 USERPROFILE）', () => {
  const r = makeResolver({
    desktopReader: () => {
      throw new Error('powershell 被拦')
    },
  })
  assert.equal(r.resolveInput('desktop:a.docx').code, 'E_DESKTOP_UNRESOLVED')
})

test('paths: project: / home: / 相对路径 / 绝对路径 各自落点正确', () => {
  const r = makeResolver()
  assert.equal(r.resolveInput('project:data/logs/x.jsonl').path, ROOT + '\\data\\logs\\x.jsonl')
  assert.equal(r.resolveInput('home:.claude/settings.json').path, HOME + '\\.claude\\settings.json')
  assert.equal(r.resolveInput('data/x.txt').path, ROOT + '\\data\\x.txt')
  assert.equal(r.resolveInput('D:\\Desktop\\a b.docx').path, 'D:\\Desktop\\a b.docx')
  assert.equal(r.resolveInput('D:\\Desktop\\sub\\x').path, 'D:\\Desktop\\sub\\x')
})

test('paths: 大小写不敏感别名（DESKTOP: / Desktop:）', () => {
  const r = makeResolver()
  assert.equal(r.resolveInput('DESKTOP:X.DOCX').path, REAL_DESKTOP + '\\X.DOCX')
  assert.equal(r.resolveInput('Desktop:y.txt').path, REAL_DESKTOP + '\\y.txt')
})

test('paths: 引号包裹与首尾空白被剥离', () => {
  const r = makeResolver()
  assert.equal(r.resolveInput('  "desktop:a.docx"  ').path, REAL_DESKTOP + '\\a.docx')
  assert.equal(r.resolveInput(" 'project:x' ").path, ROOT + '\\x')
})

test('paths: 拒绝 .. 上行段（不做规范化洗白）', () => {
  const r = makeResolver()
  for (const p of ['..\\evil', 'project:../outside', 'desktop:../out/x', 'a/../../b']) {
    const got = r.resolveInput(p)
    assert.equal(got.ok, false, p)
    assert.equal(got.code, 'E_TRAVERSAL', p)
  }
})

test('paths: 拒绝 UNC / 空字节 / 非法字符 / 保留设备名', () => {
  const r = makeResolver()
  assert.equal(r.resolveInput('\\\\srv\\share\\x').code, 'E_UNC')
  assert.equal(r.resolveInput('//srv/share/x').code, 'E_UNC')
  assert.equal(r.resolveInput('desktop:a\0b').code, 'E_BAD_PATH')
  assert.equal(r.resolveInput('desktop:a|b').code, 'E_BAD_PATH')
  assert.equal(r.resolveInput('desktop:a?b').code, 'E_BAD_PATH')
  assert.equal(r.resolveInput('desktop:a*b').code, 'E_BAD_PATH')
  assert.equal(r.resolveInput('CON').code, 'E_BAD_PATH')
  assert.equal(r.resolveInput('desktop:NUL.txt').code, 'E_BAD_PATH')
})

test('paths: 未知别名 / 空串 / 非字符串', () => {
  const r = makeResolver()
  assert.equal(r.resolveInput('foo:bar').code, 'E_UNKNOWN_ALIAS')
  assert.equal(r.resolveInput('').code, 'E_EMPTY')
  assert.equal(r.resolveInput('   ').code, 'E_EMPTY')
  assert.equal(r.resolveInput(null).code, 'E_EMPTY')
  assert.equal(r.resolveInput(123).code, 'E_EMPTY')
})

test('paths: requirePath 严格版抛 PathError（executor 用）', () => {
  const r = makeResolver()
  assert.equal(r.requirePath('desktop:ok.docx'), REAL_DESKTOP + '\\ok.docx')
  assert.throws(() => r.requirePath('desktop:../x'), (e) => e instanceof PathError && e.code === 'E_TRAVERSAL')
})

test('paths: 别名清单固定为 project/home/desktop', () => {
  assert.deepEqual([...ALIASES], ['project', 'home', 'desktop'])
  const r = makeResolver()
  assert.deepEqual(r.aliases, ['project', 'home', 'desktop'])
})

test('paths: 真实注册表读取器可读到本机登记桌面（集成探针，失败则跳过断言）', () => {
  const got = readShellFolderDesktop()
  if (!got) return // 环境无 PowerShell / 被安全策略拦截时跳过，不制造 flaky
  assert.equal(typeof got, 'string')
  assert.ok(got.length > 0, '桌面路径不应为空')
})

test('paths: 桌面解析结果缓存 —— 只调一次读取器', () => {
  let calls = 0
  const r = makeResolver({
    desktopReader: () => {
      calls += 1
      return REAL_DESKTOP
    },
  })
  r.resolveInput('desktop:a')
  r.resolveInput('desktop:b')
  r.desktop()
  assert.equal(calls, 1)
})
