// tests/skill-installer.test.mjs
//
// skill 适配性安装器（P-R4 块 4）回归：
//   · 核心纯函数：verifySource（哈希白名单三态拒绝）/ scanCandidates / summarizePermissions
//   · registry 全流程：prepare（零写入+权限清单+token）→ confirm（复制+审计+重扫）→ retire（只移不删）
//   · 红线：被篡改 hash 必须拒绝；目标已存在拒绝（禁自动更新）；cancel 零落盘；越界 id 拒绝
//   · 权限沙箱：恶意 skill 经 ctx 越界写 → 抛错且零写入；未声明 skill.admin 的插件拿不到 admin
// 全部在临时目录建 skill 夹具；安装目标在项目 packages/plugins/ 内（用假 registry dir 指到 tmp）。

import test, { after } from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, renameSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { buildFileManifest, scanCandidates, summarizePermissions, verifySource } from '../packages/core/src/skill-installer.mjs'
import { createRegistry, PLUGINS_DIR } from '../packages/plugins/index.mjs'
import { PROJECT_ROOT, dataPath } from '../packages/core/src/safefs.mjs'

const SKILL_BODY = `export async function activate(ctx) {
  const cards = []
  ctx.ui.registerCard({ id: 'demo.skill', title: 'Demo', body: 'demo', actions: [] })
  ctx.ui.registerCommand({ name: 'demo.skill.ping', title: 'ping', description: 'ping', run: async () => ({ text: 'pong', ok: true }) })
  return { deactivate() {} }
}
export default { activate }
`

/** 在 tmp 里造一个合法 skill 目录（含正确 hash 白名单的 plugin.json）。 */
function makeSkillDir(root, id, { body = SKILL_BODY, extra = {}, hashOverride = null } = {}) {
  const dir = join(root, id)
  mkdirSync(dir, { recursive: true })
  writeFileSync(join(dir, 'index.mjs'), body)
  const manifest = {
    id,
    name: `Skill ${id}`,
    version: '1.0.0',
    description: 'acceptance fixture',
    capabilities: ['ui.card', 'ui.command', ...(extra.capabilities || [])],
    permissions: extra.permissions || [],
    scopes: extra.scopes || [],
    entry: 'index.mjs',
    source: dir,
  }
  const files = buildFileManifest(dir)
  manifest.hash = hashOverride || files
  writeFileSync(join(dir, 'plugin.json'), `${JSON.stringify(manifest, null, 2)}\n`)
  return { dir, manifest }
}

/** S33·D：删除重试（Windows 文件锁，3 次 / 300ms）。 */
async function rmRetry(p, tries = 3) {
  for (let i = 0; i < tries; i++) {
    try { rmSync(p, { recursive: true, force: true }); return true } catch { if (i < tries - 1) await new Promise((r) => setTimeout(r, 300)) }
  }
  return false
}
/** S33·D：同步版删除重试（用于 finally/after 的收尾）。 */
function rmRetrySync(p, tries = 3) {
  for (let i = 0; i < tries; i++) {
    try { rmSync(p, { recursive: true, force: true }); return true } catch { if (i < tries - 1) { const t = Date.now() + 300; while (Date.now() < t) { /* busy */ } } }
  }
  return false
}

// S33·D：安装测试不再往真实 packages/plugins/ 里丢目录——改到项目内 data/tmp 的临时注册目录，
// 这样清理必定成功（不污染源码树），版本收敛测试也不会被测试插件干扰。
const REG_DIRS = []
function mkRegDir() {
  const d = join(PROJECT_ROOT, 'data', 'tmp', `skill-reg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`)
  mkdirSync(d, { recursive: true })
  REG_DIRS.push(d)
  return d
}

// S33·D：文件级 after() 统一清残留并断言——安装目标落在真实 packages/plugins/，
// 必须把 test-b4-* 与 .retired/test-b4-* 收干净，否则会污染后续运行（历史遗留 1.0.0 目录就是这么来的）。
after(async () => {
  cleanupTestPlugins()
  const retired = join(PLUGINS_DIR, '.retired')
  const left = []
  if (existsSync(PLUGINS_DIR)) for (const n of readdirSync(PLUGINS_DIR)) if (n.startsWith('test-b4-')) left.push(n)
  if (existsSync(retired)) for (const n of readdirSync(retired)) if (n.startsWith('test-b4-')) left.push('.retired/' + n)
  assert.deepEqual(left, [], '测试残留必须清空（packages/plugins/test-b4-* 与 .retired/test-b4-*）：' + left.join(','))
})

test('verifySource: 三态拒绝与通过（篡改/缺白名单/白名单外文件/正常）', async () => {
  const root = mkTmp()
  try {
    // 正常
    const good = makeSkillDir(root, 'good-skill')
    const ok = verifySource(good.dir, good.manifest)
    assert.equal(ok.ok, true)
    assert.equal(ok.files, 1) // index.mjs（plugin.json 自身不在白名单）

    // 篡改：声明 hash 不动，改掉实际文件内容
    const tampered = makeSkillDir(root, 'tampered-skill')
    writeFileSync(join(tampered.dir, 'index.mjs'), SKILL_BODY + '\n// injected')
    const bad = verifySource(tampered.dir, tampered.manifest)
    assert.equal(bad.ok, false)
    assert.equal(bad.code, 'E_HASH_MISMATCH')
    assert.match(bad.details[0], /哈希不一致（疑似被篡改）/)

    // 缺白名单
    const noHash = makeSkillDir(root, 'nohash-skill')
    delete noHash.manifest.hash
    assert.equal(verifySource(noHash.dir, noHash.manifest).code, 'E_HASH_MISSING')

    // 白名单外文件（多出来的未声明文件）
    const extra = makeSkillDir(root, 'extra-skill')
    writeFileSync(join(extra.dir, 'sneaky.js'), 'export {}')
    const bad2 = verifySource(extra.dir, extra.manifest)
    assert.equal(bad2.ok, false)
    assert.equal(bad2.code, 'E_UNEXPECTED_FILE')
    assert.match(bad2.details[0], /白名单之外的文件/)
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('scanCandidates 与 summarizePermissions（四类细项给用户确认）', () => {
  const root = mkTmp()
  try {
    makeSkillDir(root, 'sk-a', { extra: { capabilities: ['llm'], permissions: ['net:api.crossref.org'], scopes: ['notes'] } })
    mkdirSync(join(root, '.hidden'), { recursive: true })
    writeFileSync(join(root, 'loose.txt'), 'not a skill')
    const cands = scanCandidates(root)
    assert.equal(cands.length, 1)
    assert.equal(cands[0].id, 'sk-a')
    const p = summarizePermissions({ scopes: ['notes'], permissions: ['net:api.crossref.org'], capabilities: ['llm', 'ui.card'] })
    assert.match(p.lines[0], /fs:data\/notes\//)
    assert.match(p.lines[1], /net:api\.crossref\.org（仅白名单）/)
    assert.match(p.lines[3], /llm:受控 provider/)
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('registry 全流程：prepare（零写入）→ confirm（安装+审计+重扫）→ enable → retire（只移不删）', async () => {
  const root = mkTmp()
  // registry 目录被 safefs 夹逼在项目根内——安装测试用真实 packages/plugins/，以唯一测试 id 隔离，finally 清理
  const regDir = PLUGINS_DIR
  const reg = createRegistry({ core: { net: null, providers: null }, logger: () => {} })
  try {
    const skill = makeSkillDir(root, 'test-b4-flow', { extra: { capabilities: ['skill.admin'] } })
    // prepare：零写入 + token + 权限清单
    const before = existsSync(join(regDir, 'test-b4-flow')) ? 1 : 0
    const p = reg.prepareSkillInstall(skill.dir)
    assert.equal(p.ok, true, p.error)
    assert.ok(p.token)
    assert.match(p.permissions.lines[2], /ui:card/)
    assert.equal(existsSync(join(regDir, 'test-b4-flow')) ? 1 : 0, before, 'prepare 不得写盘')
    // commit：复制 + 重扫
    const c = reg.commitSkillInstall(p.token)
    assert.equal(c.ok, true, c.error)
    const installed = readFileSync(join(regDir, 'test-b4-flow', 'index.mjs'), 'utf8')
    assert.equal(installed, SKILL_BODY, '安装内容必须逐字一致')
    assert.ok(existsSync(join(regDir, 'test-b4-flow', 'plugin.json')))
    // 重扫可见 + 可启用
    const rows = reg.listInstalledSkills()
    assert.ok(rows.some((r) => r.id === 'test-b4-flow' && (r.source || '').includes('test-b4-flow')))
    const en = await reg.enable('test-b4-flow')
    assert.equal(en.enabled, true, en.error)
    // 命令可用
    const cmd = await reg.runCommand('demo.skill.ping', '')
    assert.equal(cmd.ok, true)
    assert.equal(cmd.value.text, 'pong')
    // retire：只移不删
    const r = await reg.retireSkill('test-b4-flow')
    assert.equal(r.ok, true, r.error)
    assert.match(r.retiredTo, /\.retired[\\/]test-b4-flow-\d/)
    assert.ok(!existsSync(join(regDir, 'test-b4-flow')), '原目录应已移走')
    // 精确锁定本次退休目录（用 API 返回的 retiredTo，不依赖 readdir 顺序）
    const retiredBase = join(regDir, '.retired')
    const retiredName = readdirSync(retiredBase).find((d) => d.startsWith('test-b4-flow-') && existsSync(join(retiredBase, d, 'index.mjs')))
    const retiredDir = retiredName ? join(retiredBase, retiredName) : null
    assert.ok(retiredDir && existsSync(join(retiredDir, 'index.mjs')), '退休目录必须保留全部文件（只移不删）')
    // 重复 commit 同 token → 已消费
    assert.equal((await reg.commitSkillInstall(p.token)).code, 'E_NO_PENDING')
  } finally {
    rmSync(root, { recursive: true, force: true })
    // 清理测试安装残留（rename 出源码树，避免污染 .retired，也绕开 Windows 文件锁）
    cleanupTestPlugins()
  }
})

test('红线：篡改 hash 拒绝 / 目标已存在拒绝（禁自动更新）/ cancel 零落盘 / 越界 id 拒绝', async () => {
  const root = mkTmp()
  // registry 目录被 safefs 夹逼在项目根内——安装测试用真实 packages/plugins/，以唯一测试 id 隔离，finally 清理
  const regDir = PLUGINS_DIR
  const reg = createRegistry({ core: { net: null, providers: null }, logger: () => {} })
  try {
    // 篡改 hash → prepare 直接拒绝
    const bad = makeSkillDir(root, 'evil-1', { hashOverride: { 'index.mjs': '0'.repeat(64) } })
    const r1 = reg.prepareSkillInstall(bad.dir)
    assert.equal(r1.ok, false)
    assert.equal(r1.code, 'E_HASH_MISMATCH')
    assert.ok(!existsSync(join(regDir, 'evil-1')), '拒绝安装必须零落盘')

    // 已存在同 id → commit 拒绝（禁自动更新：更新必须显式先 retire）
    const s1 = makeSkillDir(root, 'test-b4-dup')
    const p1 = reg.prepareSkillInstall(s1.dir)
    await reg.commitSkillInstall(p1.token)
    const s2 = makeSkillDir(root, 'dup-skill-2') // 内容不同目录，但 id 相同 → 改 id 相同
    const manifest2 = JSON.parse(readFileSync(join(s2.dir, 'plugin.json'), 'utf8'))
    manifest2.id = 'test-b4-dup'
    manifest2.hash = buildFileManifest(s2.dir)
    writeFileSync(join(s2.dir, 'plugin.json'), JSON.stringify(manifest2, null, 2))
    const p2 = reg.prepareSkillInstall(s2.dir)
    const c2 = reg.commitSkillInstall(p2.token)
    assert.equal(c2.ok, false)
    assert.equal(c2.code, 'E_ALREADY_INSTALLED')

    // cancel：零落盘
    const s3 = makeSkillDir(root, 'test-b4-cancel')
    const p3 = reg.prepareSkillInstall(s3.dir)
    const cc = reg.cancelSkillInstall(p3.token)
    assert.equal(cc.ok, true)
    assert.ok(!existsSync(join(regDir, 'test-b4-cancel')))

    // 越界 id（路径穿越）→ prepare 拒绝
    const evil = makeSkillDir(root, 'evil-id')
    const evilManifest = JSON.parse(readFileSync(join(evil.dir, 'plugin.json'), 'utf8'))
    evilManifest.id = '../evil'
    evilManifest.hash = buildFileManifest(evil.dir)
    writeFileSync(join(evil.dir, 'plugin.json'), JSON.stringify(evilManifest, null, 2))
    const r4 = reg.prepareSkillInstall(evil.dir)
    assert.equal(r4.ok, false)
    assert.equal(r4.code, 'E_BAD_PLUGIN_ID')
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
})

test('权限沙箱：恶意 skill 经 ctx 越界写 → 抛错且零写入；未声明 skill.admin 拿不到 admin', async () => {
  const root = mkTmp()
  // registry 目录被 safefs 夹逼在项目根内——安装测试用真实 packages/plugins/，以唯一测试 id 隔离，finally 清理
  const regDir = PLUGINS_DIR
  const reg = createRegistry({ core: { net: null, providers: null }, logger: () => {} })
  try {
    // 恶意 skill：声明 notes 作用域但试图穿越出去；另试一个未声明的作用域
    const malicious = makeSkillDir(root, 'test-b4-mal', {
      extra: { scopes: ['notes'] },
      body: `export async function activate(ctx) {
        const out = []
        try { ctx.fs.scope('not-a-scope'); out.push('scope-granted') } catch (e) { out.push('E_SCOPE:' + e.code) }
        try { const s = ctx.fs.scope('notes'); s.write('../../pdf/evil-inside-root.txt', 'x'); out.push('write-ok') } catch (e) { out.push('E_OUT:' + e.code) }
        ctx.ui.registerCommand({ name: 'malicious.probe', title: 'p', description: 'p', run: async () => ({ text: out.join('|'), ok: true }) })
        return {}
      }
      export default { activate }
      `,
    })
    const p = reg.prepareSkillInstall(malicious.dir)
    assert.equal(p.ok, true, p.error)
    const c = reg.commitSkillInstall(p.token)
    assert.equal(c.ok, true, c.error)
    await reg.enable('test-b4-mal')
    const probe = await reg.runCommand('malicious.probe', '')
    const report = String(probe.value.text)
    assert.match(report, /E_SCOPE:E_SCOPE_UNKNOWN/, '未声明的作用域必须拒（E_SCOPE_UNKNOWN）')
    // S34·P0 几何：'../../pdf' 在隔离数据树下已越出 DATA_DIR → 宿主门 E_OUTSIDE_ROOT；
    // 两道门都算拒，红线是"绝不落盘"。
    assert.match(report, /E_OUT:E_PLUGIN_FS_OUTSIDE|E_OUT:E_OUTSIDE_ROOT/, '穿越出已声明作用域必须拒（绝不落盘）')
    assert.ok(!existsSync(dataPath('pdf', 'evil-inside-root.txt')), '越界写入绝不能落盘')
    // 零写入：项目根没有 evil.txt（tmp plugins 目录也没有）
    assert.ok(!existsSync(join(root, 'evil.txt')))
    // 未声明 skill.admin 的插件拿不到 admin
    const adminProbe = makeSkillDir(root, 'test-b4-admin', {
      body: `export async function activate(ctx) {
        ctx.ui.registerCommand({ name: 'admin.probe', title: 'p', description: 'p', run: async () => ({ text: ctx.skillAdmin ? 'GRANTED' : 'null', ok: true }) })
        return {}
      }
      export default { activate }
      `,
    })
    const p2 = reg.prepareSkillInstall(adminProbe.dir)
    await reg.commitSkillInstall(p2.token)
    await reg.enable('test-b4-admin')
    const r3 = await reg.runCommand('admin.probe', '')
    assert.equal(r3.value.text, 'null', '未声明 skill.admin 的插件 ctx.skillAdmin 必须为 null')
  } finally {
    cleanupTestPlugins()
    rmSync(root, { recursive: true, force: true })
  }
})

test('内置 skill-installer 插件：声明 skill.admin，能拿到 admin API', async () => {
  const reg = createRegistry({ core: { net: null, providers: null }, logger: () => {} })
  reg.scan()
  const rec = reg._records.get('skill-installer')
  assert.ok(rec, '内置 skill-installer 应被扫到')
  assert.ok(rec.manifest.capabilities.includes('skill.admin'))
  const en = await reg.enable('skill-installer')
  assert.equal(en.enabled, true, en.error)
  const r = await reg.runCommand('skill', 'list')
  assert.equal(r.ok, true, r.value ? r.value.text : r.error)
  assert.match(r.value.text, /已装插件/)
})

function cleanupTestPlugins() {
  // 测试残骸清理：Windows 下文件监视会锁住 packages/plugins 里的 test-b4-*（unlink 被拒），
  // 但 rename 仍可用——优先 rename 出源码树到 data/tmp（下次 run-tests 的 cleanResidue 会清掉）。
  for (const d of REG_DIRS.splice(0)) rmRetrySync(d)
  // 同盘回收站：rename 跨盘（D:→C: TEMP）会 EXDEV，必须落在 D: 上；cleanResidue 每轮清空它
  const archiveDir = join(PLUGINS_DIR, '..', '.skill-test-trash')
  for (const base of [PLUGINS_DIR, join(PLUGINS_DIR, '.retired')]) {
    if (!existsSync(base)) continue
    for (const name of readdirSync(base)) {
      if (!name.startsWith('test-b4-')) continue
      const src = join(base, name)
      let moved = false
      try {
        mkdirSync(archiveDir, { recursive: true })
        renameSync(src, join(archiveDir, `test-b4-out-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`))
        moved = true
      } catch { /* rename 失败再尝试删除 */ }
      if (!moved) rmRetrySync(src)
    }
  }
}

function mkTmp() {
  return mkdtempSync(join(tmpdir(), 'skill-b4-'))
}
