# SAFETY.md —— research-orb 安全边界（任何 AI/脚本都必须遵守）

## 1. 可写范围（唯一）
- **唯一可写根**：`D:\explorer!\research-orb\`（含 `data\`、`.snapshots\`）
- 其余任何路径**一律只读**。

## 2. 禁写/禁改（硬红线）
- `D:\AI_Workspace\dsh-orb-cordis\**`（orb 源码，一字不改）
- `D:\AI_Workspace\island*\**`、`island-desktop\**`（萌源）
- `C:\Users\54958\.dsh\**`（DSH 配置/插件/数据）
- `D:\dsh-orb-project\**`（orb 台账，只读）
> 注意：`C:\Users\54958\.claude\settings.json` **只允许读**（学校网关凭据来源）。

## 3. 禁止行为
- 执行 `dsh plugin add/update`；修改任何 profile 的 `package.json`；下载/安装 dsh-orb 官方 tgz
- 任何 `shutdown / logoff / 重启 / 注销`；创建或修改计划任务；改注册表/环境变量/电源与网络策略
- 杀 dsh-orb 的 helper（`electron.exe` 且命令行含 `dsh-orb\dist\helper\lib\main.js`）
- 安装全局 npm 包；**本应用不得内置任何自动更新/远程下载执行逻辑**

## 4. 密钥策略
- 只从 `data\secrets.json` 或环境变量读取；学校网关从 `~/.claude/settings.json` **运行时直读**
- **密钥绝不出现**在源码、日志、汇报、提示词、截图里；日志一律打码（前 4 位 + `***`）
- `data\secrets.json` 不得提交/外发/复制到其它目录

## 5. 网络出口（白名单）
`api.deepseek.com` · `models.sjtu.edu.cn` · `export.arxiv.org` · `arxiv.org` · `api.openalex.org` · `api.crossref.org` · `api.semanticscholar.org` · `eutils.ncbi.nlm.nih.gov`（仅医学时） · `open.bigmodel.cn`（S60 视觉档 zhipu）
- 白名单外一律拒绝；每域令牌桶限速；全部出网写 `data\logs\net.jsonl`
- **deepseek-reasoner 严格 10 次/分钟**，超限排队；429 指数退避（2/4/8/16/32s，最多 5 次）
- 换/加 provider 必须同步本节与 `packages\core\src\domains.json`（护栏：`tools\check-provider-domains.mjs`，已接 run-tests 前置）

## 6. 守卫与快照（用法）
- 任何批量写入前：`node tools\guard-path.mjs <路径...>`（越界 exit 1）
- 任何阶段开工前：`node tools\snapshot.mjs`（生成 `.snapshots\<时间戳>\`，保留最近 10 份）
- 回滚：把 `.snapshots\<时间戳>\` 内容整目录覆盖回项目根

## 7. 事故教训（来自 dsh-orb，直接适用）
1. **不许把插件/程序目录改名再复制**（曾致 DSH 无法运行、球消失）→ 只能就地覆盖 + 每步校验
2. **不许把系统命令当探针**（曾 `shutdown /s /t` 当探测，5 小时后真弹关机）
3. **不许自动更新覆盖**（曾把 0.3.x 降级成官方 0.1.1，功能全丢）

## 8. 插件进程收尾纪律（P-R5 固化，适用于 research-browser / L1）
> 来源：L1 无头浏览器会拉起 `msedge.exe --headless=new`。用户的**正常浏览器**与
> WorkBuddy 的 **WebView2**（`msedgewebview2.exe`）**同名**，按名字批量杀会打断用户工作。

1. **只允许终止本项目自己拉起的浏览器进程**，判据（满足其一即可）：命令行含
   `--user-data-dir=D:\explorer!\research-orb\...`，或命令行含字面量 `research-orb`。
   判据实现见 `packages\plugins\research-browser\lib\process-guard.mjs`
   （`classifyBrowserProcess`）。
2. **严禁 `taskkill /IM msedge.exe` 之类按进程名批量杀**（含 `/IM`、PowerShell `Stop-Process -Name`、
   `Get-Process msedge* | Stop`）。只允许按 **PID 树**：`taskkill /PID <pid> /T /F`
   （实现见 `killArgsForPid`，断言见 `assertKillablePid`）。
3. **进程收尾后必须自检并留证**：我方残留 = 0，且**用户浏览器的进程数不得减少**。
   自检入口 `selfCheckResidue()`（只读，**不做任何删除**），汇报须贴出清理前后的
   Edge 进程总数对比。若发现残留：**先打印"判据 + 命中清单"再清理**，并保留前后对比。
4. 例外仅限 SAFETY.md §3 已列明的既有禁令对象（orb helper 本就禁杀），不因本节放宽。