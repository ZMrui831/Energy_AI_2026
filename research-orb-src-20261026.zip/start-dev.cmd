@echo off
rem ===========================================================================
rem  research-orb DEV launcher -- DEBUG ONLY, DO NOT SHIP.
rem
rem  Why this file exists:
rem    Inside an agent shell the inherited process environment makes Chromium's
rem    sandboxed child processes fail to initialise (GPU crashes with
rem    0xC0000005, the renderer dies with STATUS_BREAKPOINT 0x80000003), so the
rem    floating ball never paints. --no-sandbox is the only reliable workaround.
rem
rem  This launcher is for local debugging and screenshot/automation runs ONLY.
rem    - start.cmd  = normal user entry point, sandbox ON, no extra flags.
rem    - start-dev.cmd = this file, sandbox OFF, used by the dev/agent shell.
rem  Double-clicking start.cmd on the desktop is unaffected and stays sandboxed.
rem
rem  ASCII only on purpose: cmd.exe mangles non-ASCII paths.
rem  Offline by design: no package manager, no fetch, no remote update path.
rem ===========================================================================
setlocal

set "ELECTRON_EXE=D:\AI_Workspace\dsh-orb-electron\electron.exe"
set "APP_MAIN=D:\explorer!\research-orb\apps\desktop\main.mjs"

rem Clear the inherited ELECTRON_RUN_AS_NODE. If it is set, electron.exe runs as
rem a plain Node process and the floating ball never appears.
set "ELECTRON_RUN_AS_NODE="

if not exist "%ELECTRON_EXE%" (
  echo [research-orb/dev] ERROR: electron.exe not found:
  echo   %ELECTRON_EXE%
  exit /b 1
)

if not exist "%APP_MAIN%" (
  echo [research-orb/dev] ERROR: main entry not found:
  echo   %APP_MAIN%
  exit /b 1
)

echo [research-orb/dev] starting floating ball (DEBUG: sandbox disabled)...
"%ELECTRON_EXE%" --no-sandbox "%APP_MAIN%" %*
set "EXIT_CODE=%ERRORLEVEL%"
echo [research-orb/dev] exited with code %EXIT_CODE%.

endlocal & exit /b %EXIT_CODE%
