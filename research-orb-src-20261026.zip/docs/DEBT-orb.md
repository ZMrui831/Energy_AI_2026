# DEBT-orb.md —— research-orb 债务台账（accept-with-debt 登记处）

>  canonical `D:\dsh-orb-project\DEBT.md` 属契约红线**只读**目录（CONTRACT §3），
> 本文件为仓库内副本，供主管合并。格式与 canonical 一致。

| # | 债务 | 来源切片 | 影响 | 还债条件 | 状态 |
|---|---|---|---|---|---|
| D1 | summary/audit 的 90 天**批量清理未实现**（只软删标记） | S3 | 长期磁盘缓慢增长（可忽略量级） | 有 >1 万条 summary 时 | open |
| D2 | `raw_frame.deleted` 行保留 `file_path`（不清空） | S3/S3.1 | 审计可读性（路径已失效） | 若引入外部审计对账 | open |
| D3 | ~~12 态 SSIM 基线受状态条滚动影响~~ **已还**：__s5.freeze() 打桩 + freeze-ui-baseline.mjs 哈希台账（LEDGER.json）；冻结两次 SSIM=1.00000 | S5→S8 | — | — | closed |
| D4 | ~~「开始学习」无等待态~~ **已还**：四态 idle/busy/success/failure（busy 禁用+禁重复点击；failure 粘滞原因+下一步） | S5→S8 | — | — | closed |
| D5 | `data/` 无 run-scoped 隔离（验收与生产共用目录） | 全局 | 状态泄漏根因 | 已部分还债：run-isolated 落地；仍欠产品层 ORB_DATA_ROOT 真正换根 | partial |
| D6 | 30 分钟感知长测 + 人工抽查 30 条未做 | S2 | 长稳/准确率未闭环 | 挂机一次 | open |
| D7 | claim/summary 发布闸仅 sqlite（jsonl driver 下降级不可发布） | S6 | 降级环境下无法发布结论（诚实失败，非静默） | jsonl store 增加关系表支持 | open |
| D8 | ~~claim 的 UI 入口未接~~ **已还（S10）**：对话页"转为结论"入口 + 发布面板（renderClaimDetail：措辞编辑/补证据/导出/发布闸）；全程走 S6 createClaim/publishClaim，不绕过证据闸 | S6→S10 | — | — | closed |
| D9 | `none` 证据的"不得用事实语气"：DB/流程闸已挡发布（S6）；**渲染层已落地（S10）**：徽标"⚠ 无直接证据（不得作为事实）"+ 发布拦截写明缺什么；**LLM 侧自然语言措辞约束未做** | S6→S10 | none 结论若被 LLM 直接引用仍可能带事实语气 | LLM 侧措辞约束（生成/引用时降级提示） | partial |

| D11-① | ~~data\trash 无到期机制~~ **已还**：sweepTrash + retention.trashDays（默认7天可配）+ trash-expired 审计 + /ui trash 统计 | S6→S8 | — | — | closed |
| D11-② | ~~非应用抓屏产生无主 PNG~~ **已还**：capture-registry 显式例外通道（审计+可解释），孤儿扫描已知路径=DB行+例外台账 | S6→S8 | — | — | closed |
| D26 | `tests/isolation.test.mjs` **第 264 号**靠注释兼容：断言源码字面量 `const DATA_DIR = join(ROOT,'data')`，而 main.mjs 早已改从 safefs 取（`DATA_DIR as SAFE_DATA_DIR`）。因该测试文件历史上被上层文件过滤锁死（S47），当时用"main.mjs 里默认等价注释"兼容，真实行为由 `accept-s47-app-isolation`（真启动两次 + 真实 data 零写入）承担 | S47 | 静态断言与真实来源不一致，读测试的人会被注释误导 | 拿到 isolation.test.mjs 写权限后，把断言改成"DATA_DIR 必须来自 safefs 导出" | open |
| D27 | `packages/packs/research/ui/home.js`（旧首页）**不可写**（S47 起 Edit/Python/PowerShell/File.Open 全被文件过滤拒绝），因此改造版另存 `home-v1.js` 并在 pack.json 的 ui 数组里替换引用；旧 `home.js` 归档在 `ui/.deprecated/`。属权宜，不是设计选择 | S47 | 同一份首页存在两个名字（历史残留易误读）；未来若恢复写权限应合并或明确删除 | 文件过滤解除后删除 .deprecated/home.js 或在文档里固化"home-v1 是唯一首页" | open |
