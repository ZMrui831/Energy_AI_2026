# DATA-LIFECYCLE.md —— S3 数据生命周期（保留矩阵 / 删除语义 / 降级 / 故障排查 / 接线补丁）

> 交付切片：S3。技术选型：Node 内置 `node:sqlite`（DatabaseSync，动态 import + 能力探测），探测失败自动降级 JSONL 存储（`createStore({driver:'jsonl'})`）。**不 npm 安装、不引原生模块。**
> 本机事实：`node`（PATH）= v22.22.2 与 `D:\node.exe` = v24.20.0 实测均可裸 import `node:sqlite`；`D:\node.exe` 是 WorkBuddy 宿主包装版，跑测试/验收需 `CODEBUDDY_SAFE_DELETE_ENABLED=0` 禁用其 safe-delete shim（与 `tools/run-tests.mjs` 同款），否则批量 `rmSync` 被拦造成伪失败。

## 1. 存储布局

```
data\db\orb.sqlite                      主库（WAL 模式）
data\db\jsonl-store\*.jsonl             JSONL 降级存储（同接口）
packages\core\src\db\migrations\NNNN_name.sql   迁移（按序号，checksum 入库）
packages\core\src\lifecycle\cleaner.mjs 清理状态机
packages\core\src\lifecycle\logs.mjs    日志轮转清扫器
packages\core\src\lifecycle\import.mjs  S2 感知事件导入
data\lifecycle-config.json              保留矩阵配置（可改；缺省回落内置默认）
data\trash\                             孤儿文件暂存（记账，不直接删）
data\logs\lifecycle.jsonl               生命周期审计（追加）
data\logs\stage-s3-summary.json         S3 验收汇总
tools\lifecycle-worker.mjs              清理 worker（--once/--loop/--stats/--audit-report）
tools\lifecycle-audit-report.mjs        审计统一只读报告
tools\accept-s3-lifecycle.mjs           S3 验收脚本（12 判据）
```

## 2. 保留矩阵（用户已拍板，字段级表见 RETENTION-MATRIX.md）

| 数据 | 普通 | 学习中 | 敏感窗口 |
|---|---|---|---|
| 原图 `raw_frame` | **6 小时** | **20 分钟** | **永不落盘**（store 层直接拒绝 `insertRawFrame({sensitivity:'sensitive'})`，抛 `E_SENSITIVE_NO_PERSIST` 并写审计 `blocked-sensitive-persist`） |
| 观察 `observation` | 7 天（到期 tombstone：`status='deleted'` + `ocr_excerpt=NULL` + `deleted_at`，行保留供 `evidence_item` 引用） | 7 天 | 不产生 |
| 摘要 `summary` | 90 天 | 90 天 | 不产生 |
| 审计 `audit_event` / `writes.jsonl` | 只增不删（日志轮转只归档不删内容） | 同左 | 同左 |

配置落 `data\lifecycle-config.json`；`DEFAULT_LIFECYCLE_CONFIG`（db.mjs）与文件内容一致，单测断言默认值。

## 3. 删除语义（清理 worker）

- **批处理**：每轮取 ≤500 条 `status='ready' AND expires_at<=now` → **单事务批量置 `deleting`**（先改状态，崩溃后可续跑）→ 逐条删文件 → `deleted` / `error`。
- **error 记录**：`file_path` 保留；每轮重试；连续 3 轮失败 → 审计 `lifecycle-stuck` 并停该条。
- **重启续跑**：`deleting` 记录下一轮必被拾起（kill worker / 断电场景安全）。
- **孤儿文件**（磁盘有、DB 无记录）：移入 `data\trash\` 并审计 `orphan-moved`，**不直接删**。空库护栏：库中无任何 raw_frame 记录时跳过孤儿扫描（防止首跑误搬历史截图，记 `orphan-scan-skipped`）。
- **tombstone**：observation 过期 → `status='deleted'` + `ocr_excerpt=NULL`；`id` 不消失，`evidence_item`（FK `ON DELETE SET NULL`）仍可引用。
- **固定降级文案**（写入 UI/回复时必须逐字使用）：
  1. 「原图已按保留策略删除；保留时间、窗口、摘要与内容哈希，无法恢复画面。」
  2. 「证据已过期：此结论仅保留摘要，不能再打开原图。」
  3. 「数据正在安全删除，期间不再被模型使用。」

## 4. 日志轮转（清扫器，不介入写入路径、不改 safefs.mjs）

- 按天切 `data\logs\<name>-YYYYMMDD.jsonl`；单文件 >8MB 再切 `-1/-2`；保留 14 天；`rotateOnly` 名单（`writes.jsonl`）**只轮转归档不删**（audit 永不丢）。
- **切割后总行数校验**：before == after，不一致抛 `E_ROTATION_LINE_LOSS` 且未删除任何文件（fail-closed）。校验记录落 `data\logs\lifecycle.jsonl`（含 before/after 行数与字节）。
- **已知修复**（S3 收口）：20MB 级文件（~30 万行）的 `merged.push(...readLines(...))` spread 展开超 V8 参数上限（~65k）炸 `RangeError`——已改为迭代 push。
- 审计统一：**新记录一律绝对路径**（safefs 从 S2 起保证）；历史 6 条相对路径不改写，`tools\lifecycle-audit-report.mjs` 只读报告。

## 5. 降级与 S2 导入

- `createStore({driver:'auto'})`：探测 `node:sqlite` → sqlite；失败 → jsonl（并写审计 `sqlite-unavailable`）。`driver:'jsonl'` 强制降级（判据 7）；`driver:'sqlite'` 强制且探测失败 → 抛 `E_SQLITE_UNAVAILABLE`（诚实失败，不静默）。
- jsonl driver 与 sqlite 同接口（insert/list/markDeleting/tombstone/audit/counts/flush），落 `<dataDir>/jsonl-store/*.jsonl`。
- **S2 导入**（`tools\lifecycle-worker.mjs` 扩展或 `packages\core\src\lifecycle\import.mjs`）：
  - 读 `data\perception\events-*.jsonl`（宽松解析：未知字段忽略；`tick-batch` 批次行跳过——内存聚合产物不进 DB）；
  - 幂等键 `(ts, kind, sha256(rawLine))`；失败行跳过计数，不中断；
  - 目录不存在 → 打印「未发现 S2 数据，跳过」并正常退出（不报错）。

## 6. worker 用法

```bat
D:\node.exe tools\lifecycle-worker.mjs --once     REM 跑一轮（验收/测试）
D:\node.exe tools\lifecycle-worker.mjs --loop     REM 60s 间隔常驻（Ctrl-C 退出）
D:\node.exe tools\lifecycle-worker.mjs --stats    REM 各表计数 + data\shots、data\db 磁盘字节
D:\node.exe tools\lifecycle-worker.mjs --audit-report   REM 只读：writes.jsonl 相对路径记录统计
REM 隔离夹具参数：--db <path> --shots-dir <path> --trash-dir <path> --config <path>
```

## 7. 故障排查

| 症状 | 处置 |
|---|---|
| `E_MIGRATION_CHECKSUM` | 迁移文件被改 → **库保持不动（fail-closed）**；确认为误改则还原迁移文件；确需演进 → 新增 `NNNN_*.sql`，绝不改旧文件 |
| `E_ROTATION_LINE_LOSS` | 轮转行数校验失败 → 未删任何文件；查磁盘空间/杀软锁文件后重跑 |
| `E_SENSITIVE_NO_PERSIST` | 敏感帧请求落盘 → 这是**正确拦截**；核查调用方 sensitivity 标记来源 |
| `lifecycle-stuck` 审计 | 同一记录连续 3 轮删除失败 → 人工检查 file_path（占用/权限/根外） |
| `sqlite-unavailable` 审计 | node:sqlite 探测失败 → 已自动走 jsonl；确认 Node ≥22.5 或升级 Node |
| worker 跑完 deleted=0 | 看 `--stats`：若 ready=0 且磁盘有 png → 是孤儿扫描场景（空库护栏跳过）；库中有记录但未到期 → 正常 |

## 8. 主进程接线（**S3.1 已接线，2026-10-17**）

生产链路已打通：raw_frame 有真实生产者（感知层抓屏），runCleanup 有真实调度者（主进程定时器）。

### 8.1 接线点（三处）

| 接线点 | 文件 | 行为 |
| --- | --- | --- |
| store 单例 + 清理调度 | `apps/desktop/main.mjs`（`app.whenReady()` 内） | `createStore({driver, dbPath: data\db\orb.sqlite, dataDir: data\db, config})` → `initMigrations()` → `setInterval(runCleanup, 60_000)`。失败只记 `lifecycle-store-unavailable` 到 `data\logs\app.jsonl`，**不阻塞启动、不影响感知**。`before-quit` 里 `clearInterval` + `store.close()`。 |
| 原图登记 | `packages/plugins/perception/index.mjs`（`_doCapture` 内，抓屏成功后） | `store.insertRawFrame({...})`：sha256 去重（同 sha 且 `status='ready'` → 复用）；`expires_at = computeExpiry(sensitivity, mode)`（普通 6h / 学习中 20min）；sensitive → 抛 `E_SENSITIVE_NO_PERSIST`，捕获后记审计并继续。登记失败 fail-soft：记 `perception-register-failed` 到 `data\logs\perception.jsonl`，**绝不影响抓屏与采样**。 |
| 启用通道 | `packages/packs/research/pack.json` | 按 PERCEPTION.md §6.1 把 `perception` 加入 plugins/commands（感知插件原先不在任何 pack 清单，不启用则本接线在生产空转）。 |

### 8.2 定时器周期与降级行为

- **周期**：60 秒一轮 `runCleanup({ store, config, shotsDir: data\shots, trashDir: data\trash })`。
  防重复注册：已有定时器则跳过并记 `lifecycle-timer-already`；注册成功记 `lifecycle-timer-registered`（每次进程启动恰好 1 次）。
- **每轮失败**：try/catch → `data\logs\lifecycle.jsonl` 记 `lifecycle-round-failed`，下一轮继续，**调度不中断**。
- **DB 不可用**：`createStore` 失败 → 无 store、无定时器，感知照常工作（登记侧 fail-soft）；
  `RESEARCH_ORB_LIFECYCLE_DRIVER=jsonl` 可强制 jsonl driver（审计记 `sqlite-unavailable`）。
- **store 交接**：`ctx.core` 是冻结白名单（registry 本任务禁改），主进程经
  `globalThis.researchOrbLifecycle` 把**同一个** store 单例交给感知插件；桥不存在（纯 node/测试）→ 插件跳过登记。
- **扩展字段**：`raw_frame` 表 schema（`0001_init.sql`，checksum 锁定）只存核心 8 列；
  `consent_id / monitor_id / window_id / process_name / window_title / width / height / format / size_bytes / mode / trace_id` 全量记入 `audit_event(kind='frame-registered').metadata_json`。
- **孤儿治理提示**：清理轮扫描 `data\shots`（登记路径所在目录）；DB 有记录后，目录内无登记的
  历史 PNG 会被**移入 `data\trash`（只搬不删）**——这是保留矩阵对真实数据生效的正常表现。

### 8.3 S2 事件入库（可选，S4+）

感知层事件目前只落 `data/perception/events-*.jsonl`；如需入 DB，用 `packages/core/src/lifecycle/import.mjs` 的 `importPerceptionEvents({ store })` 周期导入（幂等，可重复跑）。

## 9. claim / claim_evidence（S6 已实现：数据层证据闸）

「无证据的结论不得发布」由**数据层**保证（CONTRACT §6）：迁移 `0002_claim_evidence.sql` 建
`claim`/`claim_evidence`/`summary_evidence` 三张表 + 四只触发器——

| 触发器 | 时机 | 行为 |
| --- | --- | --- |
| `CLAIM_EVIDENCE_REQUIRED` | claim `draft→published` 更新 | 非 none 证据 0 条 → `RAISE(ABORT)`，整体拒绝 |
| `SUMMARY_EVIDENCE_REQUIRED` | summary `draft→published` 更新 | 同上（summary_evidence 口径） |
| `trg_claim_no_direct_published_insert` | claim INSERT | 直插 published → 拒绝（必须走草稿→闸→发布） |
| `trg_summary_no_direct_published_insert` | summary INSERT | 同上 |

- **发布流程**（`packages/core/src/lifecycle/publish.mjs`）：`createClaim(draft)` → `attachEvidence` →
  `publishClaim`：缺证据**停在草稿**并落 `audit_event(kind='publish-blocked')`（可解释）；
  `evidence_mode='none'` → `E_NONE_EVIDENCE` 明确拒绝；成功后落 `claim-published`。
  触发器是最终强制：任何路径（含裸 SQL）都绕不过。
- **删除后的诚实性**：`resolveEvidence()` 对已清理原图返回固定文案
  「原图已按保留策略删除；保留时间、窗口、摘要与内容哈希，无法恢复画面。」；
  `claim_evidence.sha256` 与 `raw_frame.id` 不随文件删除消失（§2：行保留、不清空历史路径）。
- **迁移安全**（§7）：0002 全语句 IF [NOT] EXISTS 幂等；迁移器每文件 BEGIN/COMMIT+ROLLBACK；
  checksum 不符整体拒绝（`E_MIGRATION_CHECKSUM`，fail-closed 不半途改库）。
  回滚：`node tools/s6-rollback.mjs --db <path> --yes`（事务内 drop 触发器/表/账本登记；重跑迁移即再升级）。
- **验收**（单行复跑）：
  `node tools/run-isolated.mjs --label s6 --cmd "node tools/accept-s6-evidence.mjs"`
  探针 `tools/s6-probe.mjs` 为**独立子进程 + 独立夹具库**；数据层闸场景用**裸 SQL**验证（不经过 publish.mjs）。
  产物：`RUN-REPORT.json`（evidence 清单 + sha256）+ `data/logs/s6-accept-evidence.json`。
- **jsonl driver 降级**：claim/summary 发布闸仅 sqlite（数据层强制的前提）；jsonl 下 `publishClaim/publishSummary`
  返回 `E_DRIVER_UNSUPPORTED`（诚实降级，不伪装能发布）。
