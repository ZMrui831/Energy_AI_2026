# BUGFIX-drag.md —— 拖动反向/逃逸/屏幕被占用的根因与修法（P-R6.2 任务二）

## 1. 症状（用户实测）

1. 拖动不跟鼠标，甚至**反向移动**；
2. 随后球**遁入屏幕下方**；
3. 屏幕被占用、点击无效、无法操作桌面（只剩任务栏可用）。

## 2. 根因（三个叠加）

### 根因 A：位移基准 + 每帧钳制 → 正反馈
旧实现（main.mjs 的 drag IPC）每帧这样算：

```
target = 当前窗口位置 + (cursor - dragOrigin.cursor)   ← 基准是"当前"窗口位置
target = clampToWorkArea(target)                        ← 每帧钳制
```

问题在"当前窗口位置"：钳制一旦把窗口拉回，窗口真实位置与"期望位置"出现偏差；
下一帧又以这个**被钳过的位置**为基准继续叠加位移 → 位移被放大或反向 →
表现就是"反向移动"与"逃出屏幕"（遁入下方 = 每帧都被钳到底边，看起来像持续下滑）。

### 根因 B：坐标语义在 DPI≠100% 时不一致
渲染层发的是 `event.screenX/screenY`（Chromium 的 DIP），主进程 `setBounds/getPosition`
在 Windows 上是另一套语义；125%/150% 缩放下两者差 1.25/1.5 倍 →
位移计算天然错位，缩放越高错得越离谱（官方 orb 的 "Windows 120%/150% 吸边" 修复同理）。

### 根因 C：无尺寸护栏 + 无点击穿透
窗口是 `transparent + alwaysOnTop('screen-saver')` 的 96×96 层：
- 没有"窗口尺寸只能 96×96 或 420×620"的断言 → 一旦 bounds 被异常放大，透明层覆盖全屏；
- 没有 `setIgnoreMouseEvents` → 透明区域全部吃点击 → "屏幕被占用、点击无效"。

## 3. 修法（三层）

### 3.1 数学层（纯函数，可单测）—— `packages\core\src\geom.mjs`
- `dragTarget(startCursor, startBounds, cursor)`：**以按下瞬间的光标/窗口为固定偏移**，
  之后任意帧 `target = startWin + (cursor - startCursor)` —— 无论中间发生过什么，
  位移恒等于光标位移，**结构上排除正反馈**（连续多帧断言 510/520/530，而非 519→539→569）。
- `createDragSession()`：**move 期间禁止钳制**（可拖出屏幕），只在 `end` 钳制 ——
  钳制与位移计算从此不再同一帧内互相打架。
- `assertSaneBounds` / `isOffscreen` / `insideCircle` / `displayAt` / `toPhysical / toDip`。

### 3.2 坐标权威 —— 主进程
渲染层只上报 `phase`；坐标一律由主进程 **16ms 轮询 `screen.getCursorScreenPoint()`**。
收益：① 与 `setBounds` 同一坐标系（DIP，DPI 换算只在物理像素交界处发生）；
② 光标飞出 96×96 窗口也丢不了事件（比 pointer capture 更稳）。

### 3.3 护栏与逃生
| 护栏 | 实现 |
| --- | --- |
| 尺寸护栏 | `applyBoundsGuarded`：面积 > 面板(420×620)×1.2 → 立即复位右下角 + `bounds-guard-reset` 审计 |
| 点击穿透 | 收起态球圆内可点、四角 ignore；展开态只放行面板矩形（`click-through` 日志记录翻转） |
| 启动自愈 | `healBoundsAtBoot`：越界/超大 → 复位 |
| 逃生通道 | 托盘「重置球的位置」+ **Ctrl+Alt+Shift+R** |
| 显示变化 | `display-metrics-changed` → 立即重钳制 |

## 4. 技术选型对比（为什么不用其它方案）

| 方案 | 结论 | 理由 |
| --- | --- | --- |
| **CSS `-webkit-app-region: drag`**（现状） | ❌ 弃用 | 位移由 OS 合成，应用拿不到过程、无法钳制、无法做尺寸护栏；与 clamp 天然打架（即根因 A）。且点击穿透（ignoreMouseEvents）与 app-region 组合在 Windows 上行为不一致 |
| **手动 setBounds（本次采用）** | ✅ | 全过程可控：钳制时机、护栏、审计、复位都在自己手里；配合纯函数层完全可测 |
| Chromium `moveWindow`/外部窗口消息 | ❌ | 需要原生模块（禁下载二进制），且同样绕过自家的护栏与审计 |
| 渲染层上报坐标 | ❌ | DPI 语义错位（根因 B）；主进程轮询 `getCursorScreenPoint` 是唯一权威 |

## 5. 验证

- `tests\geom.test.mjs` 15 例：dpi 1.0/1.25/1.5、光标左上/右下、多屏负坐标、
  **move 禁钳制 / end 钳制**、异常 bounds 复位、圆命中、连续多帧无累积漂移（防正反馈）。
- `tools\accept-stage62-drag.mjs` 21 项：源码断言（旧 dragOrigin 已删）、hit-test 双值、
  **真实物理光标拖动**（.NET 移动光标 600×400 → drag-end final bounds 落在 workArea 内）。
- 手测项（需真人）：跟手手感、拖到底部钳制视觉确认、球旁点击桌面图标。
