# DEMO.md —— S4 学习主线 · 3 分钟演示讲稿

> **演示加速声明（必须向评委口头 + 本文档双处声明）**：`--fast`（默认）把「learning 态停留
> 10 分钟」的阈值压缩为 `--dwell` 秒（默认 45，可配 30–60）。**除停留时长外，其余各步
> （1Hz 采集、主动询问、真实截屏、S3 登记、草稿/晋升/丢弃、轨迹对账）全部真实执行。**
> `node tools/demo-script.mjs --real` 为真实 10 分钟时长。

## 1. 一条命令跑主线

```bat
node tools\demo-script.mjs --fast --dwell 35
node tools\demo-script.mjs --fast --dwell 35 --answer reject   REM 演示婉拒 → 24h 冷却
node tools\demo-script.mjs --real                              REM 真实时长（10 分钟）
```

- 前提：`data\perception-config.json` 的 consent 为有效 **session**（抓屏的同意前提；被拒/过期时脚本诚实失败并分类原因）。
- **一键复跑（推荐）**：`node tools\demo-script.mjs --fast --dwell 35 --grant-consent`
  —— `--grant-consent` 等价于"用户在面板点允许"（走 consent.grant() 官方 API，输出标注 [模拟用户]），演示结束自动撤销；`--keep-consent` 可保留。
- 输出：逐步 `[step] 动作 → 证据(id/文件)` 时间线 + 总用时 + 每步 PASS/FAIL；每步结果由**真实校验**算出（文件存在/哈希一致/样本数达标），skipped 不算 PASS。
- 运行记录追加 `data\logs\demo-runs.jsonl`（连演 10 次的判据 B 汇总来源）。

## 2. 三分钟讲稿（对着输出讲）

| 时刻 | 屏幕上 | 该说什么 |
| --- | --- | --- |
| 0:00 | step1-2 | 「应用有一个统一的证据库（SQLite）和一个同意开关——抓屏必须先有 session 同意，这两步是前提自检。」 |
| 0:10 | step3 | 「点开始学习后进入 learning 态：每秒只采**廉价信号**（前台窗口/进程/标题/空闲时长），1Hz、绝不截图。」 |
| 0:45 | step4 | 「停留超过阈值，系统**只主动问一次**：为什么现在提示、用了哪条证据（evidence_id）、怎么关掉，三件事都说清楚。」 |
| 0:55 | step5-6 | 「用户确认后抓一帧真实截图，立刻登记进生命周期库——learning 态的原图只保留 20 分钟，倒计时从登记那刻开始。」 |
| 1:15 | step7-9 | 「自动生成的只是**草稿**，物理隔离在 data\drafts；晋升时原文进正式笔记区（sha256 逐字节一致），草稿区清空且进回收站可撤销。全程绝不直接改正式笔记。」 |
| 1:40 | step10 | 「轨迹页出现这条片段：时间/时长/置信度/证据数/保留倒计时；点开能回指 evidence_id。原图到期被清理后，页面如实显示『原图已按保留策略删除』——证据可过期，事实不撒谎。」 |
| 2:10 | （可选）`--answer reject` | 「用户婉拒时写入 24h 同意图冷却，当场复验：第二次询问被抑制——主动绝不纠缠。」 |
| 2:40 | 收尾 | 「全程没有一条数据是编的：每步的 PASS 都来自真实校验，加速参数在输出和文档双处声明。」 |

失败兜底：
- `consent 非 session/过期` → 演示在 step2 诚实失败并说明；重新授予 session 同意即可。
- `冷却中（intent=learning-help）` → 上一次演示婉拒了询问；删除 `data\timeline\proactive-state.json` 或等 24h（设计行为，不是 bug）。
- `样本不足` → collector（PowerShell 助手）启动慢或被安全软件拦截；重跑一次。
- 截屏失败 → 会话非交互桌面（如远程会话断开）；在本机桌面重跑。

## 3. 加速参数

| 参数 | 默认 | 说明 |
| --- | --- | --- |
| `--fast`（默认） | 停留阈值 45s | 30–60 可配（`--dwell`）。**输出与本文档双处声明加速**；仅压缩停留时长。 |
| `--real` | 600s（10 分钟） | 真实时长口径，无任何压缩。 |
| `--answer accept\|reject` | accept | 显式模拟「用户确认 / 婉拒」（输出标注「模拟用户」）；reject 写 24h 同意图冷却。 |

## 4. 与竞品对比的 5 条要点

1. **证据先于结论**：每个自动草稿都挂 evidence_id，可回指原图与 1Hz 信号；竞品的"AI 记录"通常给不出可复核的证据链。
2. **保留策略对真实数据生效**：learning 原图 20 分钟、普通 6 小时，过期真删且 UI 如实标注"原图已按保留策略删除"——不假装"还能看"；多数竞品只写隐私声明，不落实到行级状态机。
3. **主动一次 + 冷却退让**：超阈值只问一次，拒绝即 24h 同意图冷却；提示自带"为什么/证据/如何关"。竞品常见反复打扰或永不主动两个极端。
4. **草稿/正式物理隔离**：自动内容只进 data\drafts，晋升需显式确认且 sha256 可比对；竞品让 AI 直接写用户笔记库，出错无法区分人机笔迹。
5. **单机零外发 + 全程审计**：1Hz 只采元数据、原图不出本机、每一步落 JSONL 审计（writes/lifecycle/perception/demo-runs），行为可回放可追责。

## 5. 与既有模块的边界（本片只调用，不改内部）

- S1：`createToolRuntime`（fs.write / fs.delete / screen.capture，抓屏 host 注入 PowerShell 真实截屏）。
- S2：`startCollector` / `createEventRecorder` / `isSensitive`（真实 1Hz collector，事件落 data\perception）。
- S3：`createStore` / `insertRawFrame` / `computeExpiry`（evidence_id 的来源；与 S3.1 的 60s 清理定时器对账）。
- 轨迹页：`/timeline` 命令（`packages\plugins\timeline`）+ `packages\packs\research\ui\timeline.js`；原图保留状态经 S3.1 的 store 单例对账，deleted → "原图已按保留策略删除"。

---

## 主管补充（2026-10-17）：可重复演示的完整命令
```
node tools\demo-script.mjs --fast --dwell 35 --grant-consent --reset-cooldown
```
- `--grant-consent`：等价于"用户在面板点本次允许屏幕感知"（走 consent.grant() 官方 API，输出标注 [模拟用户]），**演示结束自动撤销**（`--keep-consent` 可保留）。
- `--reset-cooldown`：清空 data\timeline\proactive-state.json 里"主动询问"的 **24h 冷却**，等价于"等到 24 小时之后再演示"；**产品本身不会自动清冷却**（这是防纠缠设计），仅演示/验收使用。
- 实测（主管）：连跑 3 次，**10/10 步 PASS、exit=0、约 37s**；跑完 consent 回到 denied、冷却回到中性态。
- 不传这两个参数时，若 consent 非 session 或处于冷却，脚本会**诚实失败并分类原因**（exit 3/4），不会假装成功。