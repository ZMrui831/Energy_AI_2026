# AUDIT-INTEGRITY.md —— S67·批 3-D 审计一致性（一页说明）

## D1 net.mjs 拒绝去重 → **方案 A·追加式**
- 旧实现 `bumpDenyCount`：`readFileSync` 整个 net.jsonl → 改历史 deny 行 → `safeWrite` 整文件重写。毛病：与"历史审计行一律不改写"矛盾；高频拒绝退化为 O(n²) 同步阻塞。
- 新实现 `recordDenyRepeat`：首次拒绝写一条 deny 行（count=1，**此后永不改写**）；重复拒绝【追加】一行 `{ts, kind:'net-deny-repeat', decision:'deny', host, url(打码), denyKey, dedup:'append-per-repeat', count, firstTs, lastTs}`。聚合计数由进程内存 `denyLedger Map<key,{count,firstTs}>` 维护；`stats.denied` 仍逐次计数；`queueState().deniedByHost` 对账不变。
- 选择理由：审计日志的历史行是证据；读-改-写既违反不可变原则又在 20MB 级日志上每次拒绝做全文件 IO。方案 B（保留原地计数）只是把矛盾写进注释，没有消除 O(n²)，故不取。
- 证据：`tests/audit-integrity.test.mjs` D1①+②（首行逐字节不变 + repeat 行 count=3/firstTs/lastTs）、D1②b（61 次 = 1 deny + 60 repeat 对账）、D1③（源码断言函数体内无 `readFileSync(logFile`、无 `safeWrite`，旧 `bumpDenyCount` 已删除）。

## D2 safefs.mjs 冻结区只标记不拦截 → **已拦截（实现核实于本切片，补测试钉死）**
- `PROTECTED_ZONES`：`vendor/`（hard，`frozen-vendor-snapshot`）、`packages/core/src/db/migrations/`（hard，`db-migrations-frozen`）、`.snapshots/`（soft，回滚点正常写入）。
- `safeWrite` 对 hard 区：先写一条 `denied:true, protected:true, reason` 审计（二次追责），再抛 `SafeFsError('E_PROTECTED_ZONE', 'safeFs: 拒绝写入冻结区（…）')`——**写之前拦截，文件零变化**。读操作不受影响。
- 证据：`tests/audit-integrity.test.mjs` D2①（写 vendor 抛错且内容逐字节不变）、②（读正常）、③（migrations 同拦 + 普通文件正常）、④（审计 protected 标记切片断言）、⑤（`.snapshots` 非 hard 纯函数断言）。

## D3 G5（安全审计保留 14 天被删）→ **已修，运行时配置漏洞已补**
- 代码层：`lifecycle/logs.mjs:183` 默认 `['writes.jsonl','net.jsonl','tool.jsonl','perception.jsonl']` ✓；`db.mjs:45` 同 ✓。
- **运行时漏洞（本切片补齐）**：`tools/lifecycle-worker.mjs` 的 `loadConfig()` 优先读 `data/lifecycle-config.json`，而该文件的 `rotateOnly` 只剩 `["writes.jsonl"]` → 真实运行时 net/tool/perception 审计 14 天后仍会被删。已补齐为四项（node 写入，**无 BOM UTF-8** 校验通过）。
- 证据：`tests/audit-integrity.test.mjs` D3（三处逐一断言）。

## D4 G4（published claim 证据被剥离）→ **已接线（原为死代码）**
- `verifyClaimIntegrity`（`lifecycle/publish.mjs:220`）此前**零调用**（仅定义+导出）。已接到两条只读展示路径：
  1. `buildClaimExport`：导出对象附 `integrity = verifyClaimIntegrity(store)`——不阻断导出（告警交人决策）；
  2. `claimEvidenceReport`：published 且非 none 证据为 0 → 附 `integrityWarning: '证据缺失'`。
- **不自动改状态**：撤销/补证据属业务决策。
- 证据：`tests/audit-integrity.test.mjs` D4（破损 claim → `ok:false` 且列出；对照组不误报；导出对象与详情路径均有告警）。

## 验证（只跑定向三件套，未跑全量/未启动 Electron）

```
node --test --test-reporter=tap tests/audit-integrity.test.mjs   → 10/10 全绿
node --test --test-reporter=tap tests/net.test.mjs               → 23/23 全绿（2 个旧去重断言按 D1 新语义更新，口径不放宽）
node --test --test-reporter=tap tests/db.test.mjs                → 15/15 全绿
node tools/check-imports.mjs                                     → 479 文件 0 失败
```
