# ARCH.md —— 三层架构与插件契约（草案 v1）

## 架构事实（P-R6.1 主管核验更正）
**计时/进度/审计/受管网络属 core（通用生产力），不属领域词。**「底座零学科假设」
（`tests\packs.test.mjs`）的判定词表**不含** `计时/进度`——此前任务书曾把 `计时`
误列为禁词，现按本实现口径更正：这些是任何形态（科研/通用/健康/养老）都需要的
底座能力，写在 core 是分层正确，不是学科耦合。词表只禁**学科/业务词**
（arxiv/doi/文献/论文/citation/bibtex/zotero/overleaf/latex/笔记/健康/养老/医院/用药/血压）。

## 分层原则
**科研能力与底座解耦**：底座只提供「悬浮球 + 音频 + 系统集成」，一切"智能能力"以插件形式挂载 → 换插件即换形态（科研 / 健康 / 养老 / 通用）。

## base（底座，来自 vendor/orb-base）
- 窗口：透明、无边框、置顶、可拖动；球 ↔ 面板展开收起（`panel/floating.html` + `floating.css`）
- 单实例锁、托盘、退出清理；独立 userData：`data\.chromium\`（阶段 3.1 卫生：Chromium 缓存与领域数据分层，`data\` 顶层只放领域目录）
- 音频：ASR（whisper，后续接入）、TTS（edge-tts / 本机 SAPI 兜底）
- 原生选择（native-selection）：取选中文本 → 供"品论文/翻译/追问"入口

## core（内核，自研）
- `providers/`：`ModelProvider { id, name, kind, listModels(), describe(), describeConfig(), chat({messages, tools?, stream, model, signal}) }`
  - `provider.mjs`：抽象层 + SSE 双协议解析 + 事件三态（delta / done / error）+ 密钥打码
  - `deepseek-api`（OpenAI 兼容；key 取自 `data/secrets.json`）
  - `school-gateway`（Anthropic 兼容；baseUrl/token 运行时读 `~/.claude/settings.json`）
  - `index.mjs`：`createProviders()`，两个 provider **共享同一个 net 实例**
- `config.mjs`：凭据与配置的**唯一**读取入口，对外只给 `describeConfig()`（掩码）
- `ratelimit`：按 provider+model 令牌桶；reasoner 10 次/分钟；429 指数退避 + 排队（在 `net.mjs` 内）
- `session`：`data/sessions/<id>.jsonl` 追加写（经 `safefs.appendJsonl`）
- `agent`：一轮编排（消息 → provider 流式 → 回显 → 落盘），支持中断与降级
- `net`：白名单出口 + 每域限速 + `data/logs/net.jsonl`
- `safefs`：唯一写文件出口（断言在项目根内）+ `data/logs/writes.jsonl`
- `plugins`（宿主在 `packages/plugins/registry.mjs`）：PluginRegistry（扫描/加载/启用/禁用/列出/执行命令）

## plugins 契约（**已在阶段 1 实现**）
```json
{
  "id": "research.literature",
  "name": "文献检索",
  "version": "0.1.0",
  "capabilities": ["search.literature", "note.card", "cite.bibtex"],
  "permissions": ["net:arxiv", "fs:notes"],
  "entry": "index.mjs"
}
```
`index.mjs` 导出 `activate(ctx)`（可返回 `{ deactivate }`），`ctx` 提供：
`log`（写 `data/logs/plugins.jsonl`）、`net`（复用 core 的 net，白名单/限速/审计照旧）、
`fs`（**夹逼在 `data/notes/<pluginId>/` 之内**，越界抛 `E_PLUGIN_FS_OUTSIDE`）、
`ui`（`registerCard` / `registerCommand`，面板读取）、`llm`（复用 provider/agent）、
`state`（插件私有小 KV，落 `data/notes/<pluginId>/state.json`）。
**权限只是元数据**，实际能力由宿主白名单强制：路径夹逼 + 域名白名单 + 令牌桶限速。
参考实现：`packages/plugins/hello/`。

### 宿主装配的引擎注入（阶段 3 追加）

计时与进度引擎由**组合根** `apps/desktop/core-host.mjs` 创建（`createDefaultStore()`
+ 注入的 `now` + `RESEARCH_ORB_TIME_SCALE`），经 `createRegistry({ core })` 注入：

| ctx 字段 | 引擎 | 说明 |
| --- | --- | --- |
| `ctx.timer` | `packages/core/src/timer.mjs` | 番茄钟状态机 + 计账 + 崩溃恢复 + 空闲询问 |
| `ctx.progress` | `packages/core/src/progress.mjs` | 当日/本周汇总（60s 节流刷新） |

插件 `createEngine` 优先用宿主实例（`options.timer || ctx.timer || 自建兜底`）——
主进程的秒级节拍与插件的命令操作的是**同一个**引擎，一本账；宿主没给时
（如裸注册表测试）才用默认 store 自建。**插件禁用不影响已开始的计时收尾**
（账本在 core，不在插件里）。

主进程侧与 electron 解耦的节拍/空闲探测/通知/下行推送在
`apps/desktop/timer-driver.mjs`（`send/notify/getIdleSec/log` 全部注入，纯 node 可测）：
每秒 `tick()`（跨午夜切分 / 完成收尾 / 心跳）、空闲 >5 分钟询问、退出前 `settle()`。
下行全部复用 main-event，消息 type 带 `timer` 前缀（`timer` / `timer:idle` /
`timer:notify` / `timer:idle-resolve`），不新增 IPC 通道。

### 声明式数据作用域（阶段 2 追加）

私有抽屉（`data/notes/<pluginId>/`）不够用：科研插件按 DOMAIN 的数据布局必须写
`data/notes/<topic>/`、`data/pdf/`、`data/index/`、`data/exports/`。与其让插件自己
`import safefs` 绕开宿主（那等于没有边界），不如把口子做成**可声明的**：

```json
{ "scopes": ["notes", "pdf", "index", "exports"] }
```

| 行为 | 结果 |
| --- | --- |
| `ctx.fs.scope('pdf')` 且 manifest 已声明 | 返回一个与私有 fs 同接口、但根为 `data/pdf/` 的受限句柄 |
| 未声明就调用 | `E_SCOPE_NOT_GRANTED`（错误里带 granted 列表） |
| 作用域名不在宿主的 `DATA_SCOPES` 常量里 | `E_SCOPE_UNKNOWN` |
| 路径穿越出作用域（但仍落在项目根内） | `E_PLUGIN_FS_OUTSIDE` |
| 路径穿越出项目根 | `E_OUTSIDE_ROOT`（safefs 先拦） |
| 在 `notes` 作用域里写别的插件的私有目录 | `E_SCOPE_FOREIGN_NOTES` |
| 任何一次写入 | 都走 `safeWrite` → `writes.jsonl` 留痕 |

于是"插件能写到哪儿"从源码里看不见的 import，变成 manifest 里可审的一行。
`activate(ctx)` 返回体里会带回 `ctx` 本身，宿主/测试可据此核对插件实际拿到的能力面。

## 数据布局（全部在项目内，不与 dsh-orb 共用）
```
data\sessions\<id>.jsonl     会话
data\notes\<topic>\<slug>.md 研究卡片（front-matter 16 字段，严格取自 DOMAIN 第 4 节）
data\notes\<topic>\<slug>.meta.json  卡片溯源侧车（LLM/启发式、书目来源、抽取哈希；块 3 起含 status: draft/reading/done）
data\notes\.links.json       双向链接派生索引（块 3；正文 [[slug]] → 反链/悬空，查询前强制重建，随时可删可重建）
packages\plugins\research-literature\templates.json  笔记模板配置（块 3；四类模板可改不改码，损坏回落内置默认）
packages\plugins\.retired\       skill 卸载退休区（块 4；只移不删，目录名带时间戳）
data\pdf\<hash>.json         PDF 抽取结果（仅存源路径与文本，不复制原始 PDF）
data\index\literature.json   Orama 索引快照（派生品，坏了自动重建）
data\index\literature.manifest.json  索引清单（条数/Orama 版本/同论文去重关系）
data\index\candidates\<slug>.json    最近一次 /find 的候选集（同一查询覆盖写）
data\exports\<topic>-<日期>.bib      BibTeX 导出
data\.chromium\              Electron userData（Cache/GPUCache/Local Storage/Preferences…，
                             阶段 3.1 起 Chromium 产物全部落这里，不再混在 data\ 顶层）
data\timer\state.json            计时运行态（崩溃恢复依据；心跳 30s，audit:false）
data\timer\settings.json         { notifications } 通知开关
data\timer\<YYYY-MM-DD>.jsonl    当日事件流（append-only，schema 见下）
data\projects\<id>.json          项目与阶段（/project 命令的操作对象，schema 见下）
data\progress\<YYYY-MM-DD>.json  当日进度汇总（每 60s 与计时结束时刷新，schema 见下）
data\reports\daily-<date>.md     日报（纯模板必生成，LLM 失败回落）
data\reports\weekly-<monday>.md  周报（逐日重算，不读中间文件）
data\logs\{net,writes,plugins,app,ui,renderer}.jsonl 出网 / 写入 / 插件动作 / 应用 / 面板 / 渲染审计
data\secrets.json            密钥（唯一来源）
.snapshots\<ts>\             阶段快照
```

### 计时账本 schema（`data\timer\<YYYY-MM-DD>.jsonl`，以代码实际为准）

`type` 八型，全部 append-only；**segment 是专注时长的唯一计账单位**
（pause/stop/跨午夜/空闲扣除/崩溃恢复都先落 segment 行，"当天专注 = 当天 segment.sec 求和"可重算）：

| type | 关键字段 | 落点时机 |
| --- | --- | --- |
| `start` | `sessionId, projectId, stageId, mode, plannedSec, minutes, timeScale` | 开会话（timeScale=加速倍速，验收用；≠1 的会话不进真实进度） |
| `pause` | `sessionId, segmentSec, accumulatedSec` | 暂停（先落 segment 再记 pause） |
| `resume` | `sessionId` | 恢复 |
| `segment` | `ts, dayKey, from, to, sec, kind, sessionId, projectId, stageId` | 计账行；`kind` ∈ `focus / pause / final / midnight / interrupted / idle-trim`；跨午夜按本地午夜切分逐日落行 |
| `stop` | `sessionId, projectId, stageId, mode, plannedSec, totalSec, completed, overrunSec, reason` | 收尾（reason: `user / completed / app-dispose`） |
| `idle.prompt` | `sessionId, idleSec` | 空闲 >5 分钟询问（只问不改） |
| `idle.resolve` | `sessionId, keep, keptSec?, discardSec?` | 用户回答（扣除时先落 `idle-trim` 段） |
| `interrupted` | `sessionId, projectId, stageId, status, plannedSec, recordedSec, totalSec, remainingSec, gapSec, recoveredAt` | 崩溃恢复：`recordedSec` 只到最后一次心跳，`gapSec` 是心跳后的未知间隔（不猜不补） |

注意两个常见误读：恢复行的 `type` 是 **`interrupted`**（不是 `recovered`）；
segment 行**不带** timeScale——排除加速数据要经 start 行的 timeScale 建 sessionId 黑名单
（`progress.mjs` 的 `scaled` 区，报告里单列「测试 / 加速数据」）。

`data\projects\<id>.json`：`{ id, name, createdAt, updatedAt, done, doneAt?, milestone?, stages: [{ id, name, done, createdAt, doneAt?, milestone? }] }`
（`milestone` 为 `/project done <项目> <阶段> <里程碑>` 记的完成备注，可省略）。

`data\progress\<YYYY-MM-DD>.json`：`{ dayKey, generatedAt, focusSec, segmentCount, sessionCount, completedCount, interruptedCount, byProject: [{ projectId, name, focusSec, segments, stages: [{ stageId, stageName, focusSec }] }], outputs: { cards, bib }, scaled: { sessionCount, segmentCount, focusSec } }`
（`byProject` 到「项目 / 阶段」两级；`scaled` 是加速会话单列，不进上方任何汇总）。

## 路线（与研究阶段对应）
P-R0 骨架与安全设施 → P-R1 内核与插件宿主 → P-R2 科研核心（检索/抽取/笔记/引用）→ P-R3 计时与进度 → P-R4 跟踪指导 → P-R5 插件化多形态与打包