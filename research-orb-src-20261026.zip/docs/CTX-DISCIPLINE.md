# 上下文纪律（CTX-DISCIPLINE）——S39·G2

> 口径：四层注入的契约、裁剪顺序、Found X of Y 样例、分页契约与遥测口径，一条页说清。数据来源：packages/core/src/agent.mjs（注入编排）+ coach 摘要/记忆 + longterm-memory/context.mjs + settings budgetTokens。

## 一、六条契约落了哪几条

| # | 契约 | 落地情况 | 证据 |
| --- | --- | --- | --- |
| 1 | 顺序固定：coach 摘要 → coach 记忆 → 长期记忆 | ✅ main.mjs 三段按序拼接，超限按此序裁剪 | agent.mjs 注入段；`/memory status` 显示注入顺序 |
| 2 | 总预算硬上限 1400 token，一级默认 300 | ✅ budgetTokens（config.json）+ 逐段裁剪到硬上限 | settings.mjs WEIGHTS/budget；longterm context budgetTokens |
| 3 | 空段不注入（不注入"记忆："空壳） | ✅ readLongTermMemoryContext 空库返回 ''；memoryHints 空 → 不附 hintsBlock | confusion.mjs；context.mjs |
| 4 | 字节稳定：同输入同输出（读侧不用墙钟） | ✅ 内核 recall 读侧不取 now（文档化不变量） | longterm core/api.js 头注 |
| 5 | 失败不注入不抛（fail-open 到空） | ✅ 全 try/catch，异常一律 '' | context.mjs / coach-context.mjs |
| 6 | 检索词来自当前轮（query 随对话走） | ✅ observeTurn 后 recall(query) 用当轮关键词 | main.mjs runTurn 接线 |

## 二、Found X of Y 样例

检索命中计数遵循 `Found {present} of {candidates}` 形态：

```
[coach] 上下文注入：Found 3 of 7（memory 2 + trajectory 1；budget 300 tokens，总预算剩 812）
```

- **X（present）**：实际注入的条目数（过预算裁剪后）。
- **Y（candidates）**：召回阶段命中的候选数（裁剪前）。
- 展示位置：注入调试行（telemetry）+ `/memory facts` 头部；不进对话正文。

## 三、分页契约

- **`/memory facts [n]`**：`n` 为返回条数，默认 10、上限 100；超出提示截断（`…另有 N 条，用 /memory facts <n> 查看`）。
- **`/coach qa list [--limit N]`**：N 默认 5、上限 50；超出提示截断。
- **`/coach qa search <词>`**：最多返回 10 条；未命中显示「未命中」。
- **`/chain`**：不分页（单条结论的链路一次全出）；多结论场景用 `claimId` 定位。
- 分页一律**按时间倒序**（最新在前），与 trajectory.jsonl 的追加序一致。

## 四、遥测口径

| 事件 | 落点 | 字段 |
| --- | --- | --- |
| LLM 调用 | data/logs/usage.jsonl（每次 run 一行，只增） | ts/taskClass/tier/providerId/model/fallback/ok/ms/tokens/error |
| 注入诊断 | 调试行（不落盘） | Found X of Y / 各段 token 占用 |
| 语音开关 | coach.jsonl | voice-toggle / voice-refused |
| 导图映射 | mindmap-*.json sidecar | nodes[{nodePath,text,source,noteFile}] |

- 遥测**只记计数与元数据**，不记对话内容与路径明文（脱敏同 privacy 口径）。
- **失败也是数据**：usage 行 `ok:false` 原样保留（含 error.code），/usage 卡如实分列"成功/失败/回落"。
