#!/usr/bin/env pwsh
# tools/neutral-terminal.ps1 —— 中性终端启动器（供录屏 S2/S4 切终端跑命令时使用）
# 作用：把终端窗口标题设为中性词"演示"，cd 到项目根，清掉 ELECTRON_RUN_AS_NODE，
#       避免录屏里暴露 C:\Users\<name>\... 路径标题或用户名。
# 用法：powershell -NoProfile -ExecutionPolicy Bypass -File tools\neutral-terminal.ps1
$host.UI.RawUI.WindowTitle = '演示'
$root = Split-Path -Parent $PSScriptRoot
Set-Location -LiteralPath $root
Remove-Item Env:\ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue
Write-Host '[neutral-terminal] 已就绪：窗口标题="演示"，目录=' $root -ForegroundColor DarkGray
Write-Host '[neutral-terminal] 现在可在此运行：node tools\accept-s10-doi.mjs  /  node tools\verify-demo.mjs' -ForegroundColor DarkGray
