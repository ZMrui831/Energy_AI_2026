import { spawn } from 'node:child_process'
import { existsSync, readFileSync, mkdirSync, cpSync, mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import {mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('_tmp_keeper')

const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const tmpRoot = mkdtempSync(join(tmpdir(), 's73keep-'))
const dataDir = join(tmpRoot, 'data')
mkdirSync(dataDir, { recursive: true })
try { cpSync(join(PROJECT_ROOT, 'data', 'themes'), join(dataDir, 'themes'), { recursive: true }) } catch {}
try { cpSync(join(PROJECT_ROOT, 'data', 'providers.json'), join(dataDir, 'providers.json')) } catch {}
try { cpSync(join(PROJECT_ROOT, 'data', 'vision-context.json'), join(dataDir, 'vision-context.json')) } catch {}
const env = { ...process.env, ORB_DATA_DIR: dataDir }
delete env.ELECTRON_RUN_AS_NODE
delete env.ORB_LOG_DIR
const child = spawn(ORB_ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', '--remote-debugging-port=9341', join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')], { cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] })
const errLines = []
child.stdout.resume()
child.stderr.on('data', (b) => { errLines.push(String(b)); if (errLines.length > 40) errLines.shift() })
child.on('exit', (code) => { console.log('KEEPER_CHILD_EXIT code=' + code + ' stderr=' + errLines.join('').slice(-800)); process.exit(0) })
console.log('KEEPER_DATA=' + dataDir)
const t0 = Date.now()
const tick = setInterval(() => {
  const ap = join(dataDir, 'logs', 'app.jsonl')
  if (existsSync(ap) && readFileSync(ap, 'utf8').includes('bridge-injected')) {
    console.log('KEEPER_READY')
    clearInterval(tick)
  } else if (Date.now() - t0 > 60000) { console.log('KEEPER_TIMEOUT'); clearInterval(tick) }
}, 1000)
process.on('SIGTERM', () => { try { child.kill() } catch {} ; process.exit(0) })
setInterval(() => {}, 10000)
