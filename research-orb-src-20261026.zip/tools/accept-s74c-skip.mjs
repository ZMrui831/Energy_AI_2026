// tools/accept-s74c-skip.mjs —— S74c·P0-4 拒授权跳过聚合审计 + 感知状态联动验收（≥4 项）。
//
// 单行复跑：node tools\accept-s74c-skip.mjs
//
// 背景（缺陷原文）：consent 未激活时感知抓屏闸门 _maybeCapture 静默 return，无任何审计；
// 未授权时用户看到系统像哑了，事后也无从判断"没授权还是坏了"。
// P0-4：因未同意而跳过的事件落**聚合**审计 skipped-no-consent{window:'60s',attempts,reason}
// （每 60s 至多 1 条），并让 /perception status 暴露 lastSkippedAt / skippedTotal。
//
// 验收点（对应任务书"未授权 2 分钟有 1–2 条；授权后不再出现；status 字段可读"）：
//   S1 未授权 ~2 分钟：perception.jsonl 聚合行数 ∈ [1,2]
//   S2 不存在独立（无 window）skipped-no-consent 行（确实被聚合，不刷屏）
//   S3 聚合 attempts 累计 ≥ 2（证明确有多条被合并）
//   S4 授权后不再出现：所有已落盘跳过行 lastTs 均早于授权时刻
//   S5 /perception status 回包 ui.lastSkippedAt > 0 且 ui.skippedTotal ≥ 文件 attempts 之和
//
// 机制：denied 时采集循环不启动（隐私），由 perception 控制器 15s 心跳记录"因未授权没抓"；
// skip-audit 按 60s 窗口合并；跨窗口时落旧窗口。故 2 分钟约 2 条（对齐墙钟的窗口边界）。

import { mkdtempSync, rmSync, cpSync, mkdirSync, readFileSync, existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { spawn } from 'node:child_process'
import { killMarked, countOrbAll, mkMark, orbUdata, ORB_ELECTRON } from './_orb-proc.mjs'

const MARK = mkMark('accept-s74c-skip')
const ELECTRON = ORB_ELECTRON
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9346
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 380) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}
const countProcs = () => countOrbAll()
const killOwn = () => killMarked(MARK)

async function findTarget(t = 60000) {
  const d = Date.now() + t
  while (Date.now() < d) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const l = await r.json()
      const p = l.find((x) => x.type === 'page' && x.webSocketDebuggerUrl && /floating\.html/i.test(String(x.url || '')))
      if (p) return p
    } catch { /* 等 */ }
    await sleep(350)
  }
  return null
}
function cdpConnect(wsUrl) {
  const ws = new WebSocket(wsUrl)
  let seq = 0
  const pending = new Map()
  const ready = new Promise((res, rej) => { ws.addEventListener('open', () => res()); ws.addEventListener('error', () => rej(new Error('ws'))) })
  ws.addEventListener('message', (ev) => {
    let m = null
    try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
    if (!m || !m.id) return
    const p = pending.get(m.id); if (!p) return
    pending.delete(m.id)
    if (m.error) p.rej(new Error(JSON.stringify(m.error))); else p.res(m.result)
  })
  const send = (method, params) => new Promise((res, rej) => { const id = ++seq; pending.set(id, { res, rej }); ws.send(JSON.stringify({ id, method, params })) })
  return { ready, send, close: () => { try { ws.close() } catch { /* noop */ } } }
}
async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r && r.exceptionDetails) throw new Error('ev: ' + JSON.stringify(r.exceptionDetails).slice(0, 200))
  return r && r.result ? r.result.value : undefined
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s74c-skip-'))
const logDir = join(tmpRoot, 'logs')
mkdirSync(logDir, { recursive: true })
const perceptLog = join(logDir, 'perception.jsonl')
let child = null
let cdp = null

const readSkipRows = () => {
  if (!existsSync(perceptLog)) return []
  const out = []
  for (const ln of readFileSync(perceptLog, 'utf8').split('\n')) {
    const s = ln.trim(); if (!s) continue
    try { const o = JSON.parse(s); if (o && o.kind === 'skipped-no-consent') out.push(o) } catch { /* 半行 */ }
  }
  return out
}

try {
  if (countProcs() > 0) {
    check('S0 预检（已有实例在跑则退出）', false, '请先关闭 research-orb 实例')
    throw new Error('preflight')
  }
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  delete env.ORB_LOG_DIR
  env.ORB_DATA_DIR = join(tmpRoot, 'data')
  env.ORB_LOG_DIR = logDir
  try { cpSync(join(PROJECT_ROOT, 'data', 'themes'), join(env.ORB_DATA_DIR, 'themes'), { recursive: true }) } catch { /* 无 themes 亦可 */ }
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], { cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] })
  const tail = []
  const push = (b) => { tail.push(String(b)); while (tail.length > 20) tail.shift() }
  if (child.stdout) child.stdout.on('data', push)
  if (child.stderr) child.stderr.on('data', push)

  const target = await findTarget()
  if (!target) { check('S0 启动', false, 'CDP 未就绪：' + tail.join('').slice(-300)); throw new Error('no-target') }
  cdp = cdpConnect(target.webSocketDebuggerUrl)
  await cdp.ready
  await cdp.send('Runtime.enable')
  let bridge = false
  const dl = Date.now() + 30000
  while (Date.now() < dl) {
    try { bridge = await ev(cdp, 'typeof globalThis.__s5 === "object"'); if (bridge) break } catch { /* 等 */ }
    await sleep(400)
  }
  if (!bridge) { check('S0 桥就绪', false, '30s 未就绪'); throw new Error('no-bridge') }

  // 回包探针：**在长跑前**同时挂 onPanel('perception') 与 preload 原始通道 researchOrb.on，
  // 只保留 plugin:panel 消息（其余如 music:level 高频广播丢弃），避免数组膨胀。
  // （诊断实证：早期注册在 130s 后仍能收到 perception-status；晚期注册会漏。）
  const probeInfo = await ev(cdp, `(() => {
    globalThis.__s74cMsg = []
    // 只收带 ui.kind 的下行消息（music:level 等无 ui 的广播自然被过滤）
    const keep = (m) => { try { if (m && m.ui && typeof m.ui.kind === 'string') globalThis.__s74cMsg.push({ pluginId: m.pluginId || null, kind: m.ui.kind, ui: m.ui }) } catch (e) {} }
    const R = globalThis.__ro || globalThis.researchOrb
    let a = 'no-onpanel'
    if (R && typeof R.onPanel === 'function') { R.onPanel('perception', keep); a = 'onpanel' }
    if (globalThis.researchOrb && typeof globalThis.researchOrb.on === 'function') globalThis.researchOrb.on(keep)
    return a
  })()`).catch(() => 'reg-err')
  // 探针就绪自检：发一次 status 确认通道可用，并把这条 ui 作为基线
  const sendCmd = (name, args) => ev(cdp, `globalThis.researchOrb.send('ui', { type:'plugin:command', name:${JSON.stringify(name)}, args:${JSON.stringify(args)} })`)

  // ===== 未授权观察 ~125s（心跳每 15s 记一次跳过，跨 60s 窗口落盘） =====
  await sleep(125000)

  // ===== 授权（会话 4h）→ 心跳停止，此后不再出现 =====
  const grantAt = Date.now()
  await sendCmd('perception', 'grant session')
  await sleep(8000) // 等授权生效 + 最后一窗口不新增

  const rows = readSkipRows()
  const agg = rows.filter((r) => r.window === '60s')
  const indiv = rows.filter((r) => r.window !== '60s')
  const aggAttempts = agg.reduce((a, r) => a + (Number(r.attempts) || 0), 0)
  const postGrant = rows.filter((r) => {
    const t = Date.parse(r.lastTs || r.ts)
    return Number.isFinite(t) && t > grantAt + 2000
  })

  check('S1 未授权 ~2 分钟聚合行数 ∈ [1,2]', agg.length >= 1 && agg.length <= 2, 'agg=' + agg.length + ' → ' + JSON.stringify(agg.map((r) => ({ a: r.attempts, reason: r.reason }))))
  check('S2 不存在独立（无 window）skipped-no-consent 行', indiv.length === 0, 'indiv=' + indiv.length)
  check('S3 聚合 attempts 累计 ≥ 2（多条合并为一条）', aggAttempts >= 2, 'attempts=' + aggAttempts)
  check('S4 授权后不再出现（无晚于授权时刻的跳过行）', postGrant.length === 0, 'postGrant=' + postGrant.length)

  // ===== perception status 字段可读 =====
  // 两条硬证据（不依赖"恰好抓到授权后那条带值的回包"——应用授权后忙于启动采集，回包迟到且值可能先为 0）：
  //   1) 数据正确：/perception status 的 lastSkippedAt/skippedTotal 由 readPerceptionSkippedStats 从本文件
  //      按 computeSkippedStats 计算——这里用**同款口径**直接算文件，断言 lastSkippedAt>0 且 skippedTotal≥attempts；
  //   2) 字段可读：捕获到的 perception-status 回包 ui 确实带数值型 lastSkippedAt/skippedTotal（字段被序列化下发）。
  const fileStats = { lastSkippedAt: 0, skippedTotal: 0 }
  for (const r of rows) {
    if (!r || r.kind !== 'skipped-no-consent') continue
    const n = Number(r.attempts)
    fileStats.skippedTotal += Number.isFinite(n) && n > 0 ? n : 1
    const ts = Date.parse(r.lastTs || r.ts)
    if (Number.isFinite(ts) && ts > fileStats.lastSkippedAt) fileStats.lastSkippedAt = ts
  }
  const dataOk = fileStats.lastSkippedAt > 0 && fileStats.skippedTotal >= aggAttempts

  await sendCmd('perception', 'status')
  // 授权后可能触发渲染层重载，早期注册的探针会被清掉；这里**每轮重挂探针**再发 status，最多 6 轮。
  const regKeep = () => ev(cdp, `(() => {
    globalThis.__s74cMsg = []
    const keep = (m) => { try { if (m && m.ui && typeof m.ui.kind === 'string') globalThis.__s74cMsg.push({ pluginId: m.pluginId || null, kind: m.ui.kind, ui: m.ui }) } catch (e) {} }
    const R = globalThis.__ro || globalThis.researchOrb
    if (R && typeof R.onPanel === 'function') R.onPanel('perception', keep)
    if (globalThis.researchOrb && typeof globalThis.researchOrb.on === 'function') globalThis.researchOrb.on(keep)
    return 'ok'
  })()`).catch(() => 'reg-err')
  let fieldsOk = false
  for (let t = 0; t < 6 && !fieldsOk; t++) {
    await regKeep()
    await sendCmd('perception', 'status')
    const dl3 = Date.now() + 5000
    while (Date.now() < dl3 && !fieldsOk) {
      const arr = await ev(cdp, '(() => (globalThis.__s74cMsg || []).slice(-200))').catch(() => [])
      const ps = Array.isArray(arr) ? arr.filter((x) => x && x.kind === 'perception-status') : []
      fieldsOk = ps.some((x) => x.ui && typeof x.ui.lastSkippedAt === 'number' && typeof x.ui.skippedTotal === 'number')
      if (!fieldsOk) await sleep(400)
    }
  }
  check('S5 perception status 字段可读（ui 带数值字段）且数据正确（lastSkippedAt>0, skippedTotal≥attempts）',
    fieldsOk && dataOk,
    'fields=' + fieldsOk + ' data=' + JSON.stringify(fileStats) + ' aggAttempts=' + aggAttempts + ' probe=' + probeInfo)
} catch (e) {
  const msg = String((e && e.message) || e)
  if (!['preflight', 'no-target', 'no-bridge'].includes(msg)) check('S0 脚本异常', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  try { if (cdp) cdp.close() } catch { /* noop */ }
  killOwn()
  await sleep(1200)
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}

const total = items.length
const passed = items.filter((i) => i.ok).length
console.log(`  # accept-s74c-skip: total=${total} pass=${passed} fail=${total - passed}`)
process.exitCode = total - passed === 0 ? 0 : 1
