// tools/check-cmd-collision.mjs —— S55·B1 命令名冲突检测（护栏）
//
// 背景：S54 发现 coach 与 timeline 都注册 name:'ui'，registry.runCommand 按注册顺序
// 先命中 coach → timeline 的整个面板后端静默断链（首页数据链死了没人知道）。
// 撞名不该靠运气发现：本工具把当前完整命令表打出来，重名即 FAIL 并列出两个注册点。
//
// 用法：
//   node tools\check-cmd-collision.mjs           # CLI：打印命令表 + 自检
//   import { scanCollisions } from './check-cmd-collision.mjs'  # 供 run-tests / app 启动自检复用
//
// 解析方式：正则扫 registerCommand({ ... name: 'xxx' })（跨行、含 ctx.ui. 前缀），
// 不做 AST —— 注册点是人写的固定形态，正则足够且不受语法树版本影响。

import { readFileSync, readdirSync, existsSync } from 'node:fs'
import { join, dirname, resolve, relative } from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = dirname(fileURLToPath(import.meta.url))
export const ROOT = resolve(__dirname, '..')
const PLUGINS_DIR = join(ROOT, 'packages', 'plugins')

const RE = /registerCommand\s*\(\s*\{[\s\S]{0,600}?name:\s*['"]([A-Za-z0-9_-]+)['"]/g

/**
 * 扫描所有插件源码里的命令注册点。
 * @returns {{ commands: Array<{name:string, plugin:string, file:string, line:number, loaded:boolean}>, collisions: Array<{name:string, sites:Array}> }}
 */
export function scanCollisions(pluginsDir = PLUGINS_DIR) {
  // 只统计 pack.json 实际加载的插件（未加载插件里的注册不会发生，不能算冲突）
  let loaded = null
  try {
    const pj = JSON.parse(readFileSync(join(ROOT, 'packages', 'packs', 'research', 'pack.json'), 'utf8'))
    loaded = new Set(Array.isArray(pj.plugins) ? pj.plugins : [])
  } catch { /* 读不到 pack.json 就不过滤 */ }
  const commands = []
  const dirs = existsSync(pluginsDir) ? readdirSync(pluginsDir) : []
  for (const plugin of dirs) {
    const file = join(pluginsDir, plugin, 'index.mjs')
    if (!existsSync(file)) continue
    const text = readFileSync(file, 'utf8')
    let m
    RE.lastIndex = 0
    while ((m = RE.exec(text)) !== null) {
      const idx = m.index
      const line = text.slice(0, idx).split('\n').length
      commands.push({
        name: m[1], plugin, line,
        file: relative(ROOT, file).replace(/\\/g, '/'),
        loaded: loaded ? loaded.has(plugin) : true,
      })
    }
  }
  const byName = new Map()
  for (const c of commands) {
    if (!c.loaded) continue
    if (!byName.has(c.name)) byName.set(c.name, [])
    byName.get(c.name).push(c)
  }
  const collisions = []
  for (const [name, sites] of byName) {
    if (sites.length > 1) collisions.push({ name, sites })
  }
  commands.sort((a, b) => a.name.localeCompare(b.name))
  return { commands, collisions }
}

// ------------------------------ CLI ------------------------------
const isMain = process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url))
if (isMain) {
  const items = []
  const check = (id, ok, detail = '') => {
    items.push({ id, ok: !!ok })
    console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
  }
  const { commands, collisions } = scanCollisions()
  const pluginCount = new Set(commands.map((c) => c.plugin)).size

  console.log(`[check-cmd-collision] 命令表（${commands.length} 条 / ${pluginCount} 个插件；[未加载] = 不在 pack.json，不参与冲突判定）：`)
  for (const c of commands) {
    console.log(`  ${c.name.padEnd(14)} ← ${c.plugin.padEnd(22)} ${c.file}:${c.line}${c.loaded ? '' : '  [未加载]'}`)
  }

  // C-1 无重名命令
  check('C-1 无重名命令（重名 = 按注册顺序先到先得 = 后注册者静默失联）',
    collisions.length === 0,
    collisions.length
      ? collisions.map((x) => x.name + ': ' + x.sites.map((s) => `${s.plugin}@${s.file}:${s.line}`).join(' vs ')).join(' | ')
      : `0 冲突 / ${commands.length} 条`)

  // C-2 命令表完整：每条都有来源行
  check('C-2 命令表每条都有来源文件与行号', commands.length > 0 && commands.every((c) => c.file && c.line > 0),
    `n=${commands.length}`)

  // C-3 面板后端归属：panel 必须由 timeline 注册且全局唯一
  const panelSites = commands.filter((c) => c.name === 'panel')
  check('C-3 面板后端 panel 由 timeline 独占（S54 撞名修复的回归守卫）',
    panelSites.length === 1 && panelSites[0].plugin === 'timeline',
    panelSites.map((s) => `${s.plugin}@${s.file}:${s.line}`).join(', ') || 'missing')

  // C-4 coach 的 /ui（CU 单步）未被改名/让位（禁止动 coach /ui 的护栏）
  const uiSites = commands.filter((c) => c.name === 'ui')
  check('C-4 coach /ui（CU 单步）保持原名且未被其他插件占用',
    uiSites.length === 1 && uiSites[0].plugin === 'coach',
    uiSites.map((s) => `${s.plugin}@${s.file}:${s.line}`).join(', ') || 'missing')

  const pass = items.filter((i) => i.ok).length
  console.log(`  # check-cmd-collision: total=${items.length} pass=${pass} fail=${items.length - pass}`)
  process.exitCode = items.length - pass === 0 ? 0 : 1
}
