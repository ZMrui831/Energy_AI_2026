// tools/check-submission.mjs —— 提交包自检（录完/出包后逐项核对，任一 FAIL 即 exit 1）
// 用法：
//   node tools/check-submission.mjs                        自动在 dist-submission\ 里找三项
//   node tools/check-submission.mjs --video <mp4> --pdf <pdf> --srt <srt>
// 判据（竞赛口径，写死在 THRESHOLD，不随命令行漂移）：
//   视频：mp4、时长 255–285s、≤200MB、有音轨（粗判）、文件名无禁用词
//   字幕：≥7 条、时间不重叠、无禁用词
//   PDF ：存在、文件名无禁用词、**中文字数 ≤1000**（提不出文字 → 显式标"需人工核对"且 FAIL）
// 证据：data\logs\submission-check.json
//
// 单行复跑：node tools/check-submission.mjs
//
// 纪律：零新增依赖（mp4 盒子/时长自己解析，PDF 只做 zlib 解流 + 文本算子粗提，
// 提不出就如实报"需人工核对"，不假装读过）。

import { existsSync, statSync, readFileSync, readdirSync, mkdirSync, writeFileSync, openSync, readSync, closeSync } from 'node:fs'
import { join, basename, extname } from 'node:path'
import { inflateSync, inflateRawSync } from 'node:zlib'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const arg = (k, d = null) => { const i = process.argv.indexOf(k); return i >= 0 ? process.argv[i + 1] : d }
// 匿名纪律：证据 JSON 可能被匿名工具扫到，只记项目内相对路径（项目外的素材只记文件名）
const relOf = (p) => (!p ? null : p.startsWith(PROJECT_ROOT) ? p.slice(PROJECT_ROOT.length + 1) : basename(p))
const OUT_DIR = join(PROJECT_ROOT, 'dist-submission')
const EVID = join(PROJECT_ROOT, 'data', 'logs', 'submission-check.json')

const THRESHOLD = {
  videoMinSec: 255,
  videoMaxSec: 285,
  videoMaxBytes: 200 * 1024 * 1024,
  srtMinCues: 7,
  pdfMaxCjk: 1000,
}

// 禁用词：以 tools\check-anonymity.mjs 的清单为准（仓库内 data\anonymity-deny.txt 可覆盖）
const DENY_FILE = join(PROJECT_ROOT, 'data', 'anonymity-deny.txt')
const DENY_DEFAULTS = [
  '上海交通大学', '上海交大', 'SJTU', '交大', '电子信息与电气工程学院', '电院', '能源学院',
  '能小猿', '指导教师', '指导老师', '团队名称', '队名',
  '54958', '张茂瑞', '茂瑞', '贾添翔', '卢达鑫', '徐新星', /* allow-hardcoded: 脱敏检测词表/基准，非路径引用 */
  '贾维斯', '萌源', 'dsh-orb', 'school-gateway', '学校网关',
  'C:\\Users', 'D:\\explorer', 'wxid_'
]
const denyWords = existsSync(DENY_FILE)
  ? readFileSync(DENY_FILE, 'utf8').split(/\r?\n/).map((s) => s.trim()).filter(Boolean)
  : [...DENY_DEFAULTS]

const checks = []
function check(name, ok, detail = '') {
  checks.push({ name, ok: !!ok, detail: String(detail) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + name + (detail ? '  ' + detail : ''))
  return !!ok
}

// ---------------------------------------------------------------- 文件名禁用词
function denyHits(text) {
  const hits = []
  for (const w of denyWords) if (w && text.includes(w)) hits.push(w)
  return hits
}
function checkFileName(label, path) {
  const name = basename(path || '')
  const hits = denyHits(name)
  check(`${label} 文件名无禁用词`, hits.length === 0, hits.length ? '命中：' + hits.join('，') : name)
}

// ---------------------------------------------------------------- MP4 解析
/** 读文件头尾各 headTail 字节（moov 常在尾部，非 faststart 的文件头里没有）。 */
function readHeadTail(path, headTail = 12 * 1024 * 1024) {
  const size = statSync(path).size
  const headLen = Math.min(size, headTail)
  const tailLen = Math.min(size - headLen, headTail)
  const fd = openSync(path, 'r')
  try {
    const head = Buffer.alloc(headLen)
    readSync(fd, head, 0, headLen, 0)
    const tail = Buffer.alloc(tailLen)
    readSync(fd, tail, 0, tailLen, size - tailLen)
    return { head, tail, size }
  } finally { closeSync(fd) }
}
/** 递归走 MP4 盒子，回调 (type, start, end, buf)。容器型盒子继续下钻。 */
const CONTAINERS = new Set(['moov', 'trak', 'mdia', 'minf', 'stbl', 'edts', 'udta'])
function walkBoxes(buf, base, end, onBox, depth = 0) {
  let p = base
  while (p + 8 <= end) {
    let size = buf.readUInt32BE(p)
    const type = buf.toString('latin1', p + 4, p + 8)
    let hdr = 8
    if (size === 1) { if (p + 16 > end) break; size = Number(buf.readBigUInt64BE(p + 8)); hdr = 16 }
    else if (size === 0) size = end - p
    if (size < hdr || p + size > end) break
    onBox(type, p + hdr, p + size, depth)
    if (CONTAINERS.has(type)) walkBoxes(buf, p + hdr, p + size, onBox, depth + 1)
    p += size
  }
}
function probeMp4(path) {
  const { head, tail, size } = readHeadTail(path)
  const out = { size, hasFtyp: false, durationSec: null, timescale: null, hasAudio: false, audioHow: '' }
  const scan = (buf) => {
    if (buf.length >= 12 && buf.toString('latin1', 4, 8) === 'ftyp') out.hasFtyp = true
    if (buf.includes(Buffer.from('mp4a', 'latin1'))) { out.hasAudio = true; out.audioHow = out.audioHow || 'stsd/mp4a' }
    walkBoxes(buf, 0, buf.length, (type, s, e) => {
      if (type === 'ftyp') out.hasFtyp = true
      if (type === 'mvhd' && e - s >= 100) {
        const ver = buf[s]
        if (ver === 0) { out.timescale = buf.readUInt32BE(s + 12); out.durationSec = buf.readUInt32BE(s + 16) / out.timescale }
        else if (ver === 1) { out.timescale = buf.readUInt32BE(s + 20); out.durationSec = Number(buf.readBigUInt64BE(s + 24)) / out.timescale }
      }
      if (type === 'hdlr' && e - s >= 12) {
        const h = buf.toString('latin1', s + 8, s + 12)
        if (h === 'soun') { out.hasAudio = true; out.audioHow = out.audioHow || 'hdlr=soun' }
      }
    })
  }
  scan(head); if (!out.durationSec || !out.hasAudio) scan(tail)
  return out
}

// ---------------------------------------------------------------- SRT 解析
function parseSrt(text) {
  const cues = []
  for (const block of text.split(/\r?\n\s*\r?\n/)) {
    const lines = block.split(/\r?\n/).filter((l) => l.trim())
    const ti = lines.findIndex((l) => /-->/.test(l))
    if (ti < 0) continue
    const m = lines[ti].match(/(\d{2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{1,3})/)
    if (!m) continue
    // a = [时, 分, 秒, 毫秒（可能只有 1–2 位，右补零到毫秒）]
    const toMs = (a) => (+a[0] * 3600 + +a[1] * 60 + +a[2]) * 1000 + Number(a[3].padEnd(3, '0'))
    const start = toMs(m.slice(1, 5)); const end = toMs(m.slice(5, 9))
    cues.push({ index: Number(lines[0]) || cues.length + 1, start, end, text: lines.slice(ti + 1).join('\n') })
  }
  return cues
}

// ---------------------------------------------------------------- PDF 粗提文本（best effort）
const CJK = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]/
function inflateAny(buf) {
  for (const fn of [inflateSync, inflateRawSync]) { try { return fn(buf) } catch { /* 换一种再试 */ } }
  return null
}
/** 解析 ToUnicode CMap（bfchar/bfrange）→ { '0041': 'A' } */
function parseCmap(text) {
  const map = {}
  const push = (hex, uni) => {
    const code = parseInt(hex, 16)
    if (Number.isNaN(code)) return
    let s = ''
    for (let i = 0; i < uni.length; i += 4) s += String.fromCharCode(parseInt(uni.slice(i, i + 4), 16))
    map[code] = s
  }
  const re = /beginbfchar([\s\S]*?)endbfchar|beginbfrange([\s\S]*?)endbfrange/g
  let m
  while ((m = re.exec(text))) {
    if (m[1]) {
      const inner = /<([0-9a-fA-F]+)\s*>\s*<([0-9a-fA-F]+)>/g
      let k; while ((k = inner.exec(m[1]))) push(k[1], k[2])
    } else if (m[2]) {
      const inner = /<([0-9a-fA-F]+)\s*>\s*<([0-9a-fA-F]+)\s*>\s*<([0-9a-fA-F]+)>/g
      let k; while ((k = inner.exec(m[2]))) {
        const lo = parseInt(k[1], 16); const hi = parseInt(k[2], 16); const uni = parseInt(k[3], 16)
        for (let c = lo; c <= hi; c++) map[c] = String.fromCharCode(uni + (c - lo))
      }
    }
  }
  return map
}
function extractPdfText(buf) {
  const cmaps = []
  let streamCount = 0, okCount = 0
  // ---- 第一遍：把所有流解出来，先收集 ToUnicode CMap（CMap 可能排在内容流之后，一遍扫会漏映射）----
  const decoded = []
  const reStream = /stream\r?\n/g
  const rawAll = buf.toString('latin1')
  let m
  while ((m = reStream.exec(rawAll))) {
    const s = m.index + m[0].length
    const e = buf.indexOf('endstream', s, 'latin1')
    if (e < 0) continue
    streamCount++
    const raw = buf.subarray(s, e)
    const out = inflateAny(raw)
    let t = out ? out.toString('utf8') : null
    if (!t) {
      // 未压缩流：只要看得出文本算子或 CMap 段就按 UTF-8 还原（图片/字体等二进制流自然被排除）
      const probe = raw.toString('latin1')
      if (/\bTj\b|\bTJ\b|\bBT\b|beginbfchar|beginbfrange/.test(probe)) t = Buffer.from(probe, 'latin1').toString('utf8')
    }
    if (!t) continue
    okCount++
    if (/beginbfchar|beginbfrange/.test(t)) cmaps.push(parseCmap(t))
    decoded.push(t)
  }
  // ---- 第二遍：统一用收集齐的 CMap 抽文本 ----
  let text = ''
  for (const t of decoded) {
    // 文本算子： (…) Tj / [ (…) … ] TJ / <hex> Tj
    const ops = /\((?:\\.|[^\\()])*\)|\bTj\b|\bTJ\b|<[0-9a-fA-F]+>/g
    let k
    while ((k = ops.exec(t))) {
      const tok = k[0]
      if (tok === 'Tj' || tok === 'TJ' || !tok) continue
      if (tok.startsWith('<')) {
        const hex = tok.slice(1, -1)
        if (hex.length % 4 !== 0) continue
        let s2 = ''
        for (let i = 0; i < hex.length; i += 4) {
          const code = parseInt(hex.slice(i, i + 4), 16)
          let ch = ''
          for (const cm of cmaps) if (cm[code]) { ch = cm[code]; break }
          s2 += ch || ''
        }
        text += s2
      } else {
        const inner = tok.slice(1, -1).replace(/\\([()\\])/g, '$1')
        text += /^[\x00-\x7f]+$/.test(inner) ? '' : inner // 纯 ASCII 多为字体名/算子噪声，中文要点在 CJK
      }
    }
  }
  return { text, streamCount, okCount }
}

// ---------------------------------------------------------------- 目标解析
function findInDir(dir, exts) {
  if (!existsSync(dir)) return null
  for (const n of readdirSync(dir)) if (exts.includes(extname(n).toLowerCase())) return join(dir, n)
  return null
}
// ---------------------------------------------------------------- 主流程
const wanted = { video: arg('--video'), pdf: arg('--pdf'), srt: arg('--srt') }
const resolved = {
  video: wanted.video,
  pdf: wanted.pdf,
  srt: wanted.srt,
}
if (!resolved.video) resolved.video = findInDir(OUT_DIR, ['.mp4'])
if (!resolved.pdf) resolved.pdf = findInDir(OUT_DIR, ['.pdf'])
if (!resolved.srt) resolved.srt = findInDir(OUT_DIR, ['.srt']) || (existsSync(join(PROJECT_ROOT, 'data', 'reports', 'record-demo.srt')) ? join(PROJECT_ROOT, 'data', 'reports', 'record-demo.srt') : null)

console.log('=== check-submission：提交包自检 | 案例：问源——面向科研场景的可验证 AI 悬浮球 ===')
console.log('  判据：视频 ' + THRESHOLD.videoMinSec + '–' + THRESHOLD.videoMaxSec + 's / ≤' + Math.round(THRESHOLD.videoMaxBytes / 1024 / 1024) + 'MB / mp4 / 有音轨；字幕 ≥' + THRESHOLD.srtMinCues + ' 条不重叠；PDF 中文字数 ≤' + THRESHOLD.pdfMaxCjk)
console.log('')

const report = { generatedAt: new Date().toISOString(), thresholds: THRESHOLD, items: {}, checks: [] }

// ---- 视频 ----
console.log('[视频]')
const video = { path: relOf(resolved.video) }
if (!resolved.video || !existsSync(resolved.video)) {
  check('视频存在', false, '未找到：' + (resolved.video || '(未给 --video，且 dist-submission\\ 里没有 .mp4)'))
  video.missing = true
} else {
  const st = statSync(resolved.video)
  checkFileName('视频', resolved.video)
  check('视频扩展名 .mp4', extname(resolved.video).toLowerCase() === '.mp4', basename(resolved.video))
  check('视频 ≤200MB', st.size <= THRESHOLD.videoMaxBytes, (st.size / 1024 / 1024).toFixed(1) + 'MB')
  const p = probeMp4(resolved.video)
  video.probe = { size: p.size, hasFtyp: p.hasFtyp, durationSec: p.durationSec, timescale: p.timescale, hasAudio: p.hasAudio, audioHow: p.audioHow }
  check('MP4 容器合法（ftyp）', p.hasFtyp, p.hasFtyp ? 'ftyp 存在' : '未找到 ftyp 盒')
  check('视频时长 255–285s', p.durationSec !== null && p.durationSec >= THRESHOLD.videoMinSec && p.durationSec <= THRESHOLD.videoMaxSec,
    p.durationSec === null ? '读不到 mvhd 时长（需人工核对）' : p.durationSec.toFixed(1) + 's')
  check('有音轨（粗判）', p.hasAudio, p.hasAudio ? p.audioHow : '未找到 soun/mp4a（可能无声，需人工核对）')
}
report.items.video = { file: resolved.video ? basename(resolved.video) : null, ...video }

// ---- 字幕 ----
console.log('\n[字幕]')
const srt = { path: relOf(resolved.srt) }
if (!resolved.srt || !existsSync(resolved.srt)) {
  check('字幕存在', false, '未找到：' + (resolved.srt || '(未给 --srt，且 dist-submission\\ 与 data\\reports\\ 都没有 .srt)'))
} else {
  checkFileName('字幕', resolved.srt)
  const cues = parseSrt(readFileSync(resolved.srt, 'utf8'))
  srt.cues = cues.length
  check('字幕 ≥7 条', cues.length >= THRESHOLD.srtMinCues, cues.length + ' 条')
  let overlap = null
  for (let i = 1; i < cues.length; i++) if (cues[i - 1].end > cues[i].start + 1) { overlap = { a: cues[i - 1], b: cues[i] }; break }
  check('字幕时间不重叠', !overlap, overlap ? '第 ' + overlap.a.index + '→' + overlap.b.index + ' 条重叠' : (cues.length ? '最后一条结束 ' + (cues[cues.length - 1].end / 1000).toFixed(1) + 's' : ''))
  const hits = [...new Set(cues.flatMap((c) => denyHits(c.text)))]
  check('字幕无禁用词', hits.length === 0, hits.length ? '命中：' + hits.join('，') : '干净')
}
report.items.srt = { file: resolved.srt ? basename(resolved.srt) : null, ...srt }

// ---- PDF ----
console.log('\n[PDF]')
const pdf = { path: relOf(resolved.pdf) }
if (!resolved.pdf || !existsSync(resolved.pdf)) {
  check('PDF 存在', false, '未找到：' + (resolved.pdf || '(未给 --pdf，且 dist-submission\\ 里没有 .pdf)'))
} else {
  checkFileName('PDF', resolved.pdf)
  const buf = readFileSync(resolved.pdf)
  const r = extractPdfText(buf)
  pdf.streams = r.streamCount; pdf.inflated = r.okCount
  const cjk = (r.text.match(new RegExp(CJK.source, 'g')) || []).length
  pdf.cjkChars = cjk
  if (cjk === 0) {
    check('PDF 中文字数 ≤1000', false, '提不出中文文本（流 ' + r.okCount + '/' + r.streamCount + ' 可解）→ **需人工核对**（按判据视为 FAIL）')
  } else {
    check('PDF 中文字数 ≤1000', cjk <= THRESHOLD.pdfMaxCjk, cjk + ' 字（粗提，流 ' + r.okCount + '/' + r.streamCount + ' 可解；如与实际不符请人工核对）')
  }
  // 正文禁用词：粗提文本扫一遍（提不出文本时无法判定，随"需人工核对"一起 FAIL）
  const pdfHits = [...new Set(denyHits(r.text))]
  pdf.hits = pdfHits
  check('PDF 正文无禁用词（粗提文本）', pdfHits.length === 0, pdfHits.length ? '命中：' + pdfHits.join('，') : (cjk ? '粗提文本干净（' + cjk + ' 字）' : '提不出文本，未能检查'))
}
report.items.pdf = { file: resolved.pdf ? basename(resolved.pdf) : null, ...pdf }

// ---- 汇总 ----
const pass = checks.filter((c) => c.ok).length
const fail = checks.length - pass
report.checks = checks
report.summary = { total: checks.length, pass, fail, verdict: fail === 0 ? 'PASS' : 'FAIL' }
try { mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true }); writeFileSync(EVID, JSON.stringify(report, null, 2), 'utf8') } catch { /* 审计尽力 */ }

console.log('\n' + '='.repeat(60))
console.log(' # check-submission: total=' + checks.length + ' pass=' + pass + ' fail=' + fail + ' → ' + report.summary.verdict)
console.log(' 证据 -> data\\logs\\submission-check.json')
if (fail > 0) console.log(' 下一步：修正上面 FAIL 项后复跑；PDF 提不出文字属"需人工核对"，请人工确认后手动放行。')
process.exit(fail === 0 ? 0 : 1)
