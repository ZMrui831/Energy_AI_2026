// tools/accept-stage5-compliance.mjs
//
// P-R5 必做 4：合规自检（静态 + 运行）。
//
// 静态：源码级断言——无伪装 UA / 无绕过鉴权 / 无伪造请求头 / 无清除对方日志 / 无批量抓取
//       （L1 是单页按需抽取，不存在遍历/翻页/并发扇出代码路径）。
// 运行：白名单外域被拒 / 黑名单硬拒 / 单域限速 ≥1s / robots 处理 / browser.jsonl 字段齐全。

import { readdirSync, readFileSync, statSync, existsSync } from 'node:fs'
import { join } from 'node:path'

import { createBrowserEngine } from '../packages/plugins/research-browser/lib/engine.mjs'
import { NORMAL_UA, gateDomain, grantTempAuth, isDeniedDomain } from '../packages/plugins/research-browser/lib/compliance.mjs'
import { PROJECT_ROOT, logPath } from '../packages/core/src/safefs.mjs'

const PKG = join(PROJECT_ROOT, 'packages', 'plugins', 'research-browser')
const AUDIT = logPath('browser.jsonl')

let failures = 0
const results = []
const check = (cond, label, extra = {}) => {
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${label}`)
  results.push({ ok: !!cond, label, ...extra })
  if (!cond) failures += 1
}

function collect(dir, out = []) {
  for (const n of readdirSync(dir)) {
    if (n.startsWith('.')) continue
    const p = join(dir, n)
    const st = statSync(p)
    if (st.isDirectory()) collect(p, out)
    else if (/\.(mjs|json)$/.test(n)) out.push(p)
  }
  return out
}

/** 剥离注释与字符串字面量：静态扫描只看可执行代码。 */
function code(text) {
  let out = '', i = 0
  while (i < text.length) {
    const c = text[i], nx = text[i + 1]
    if (c === '/' && nx === '/') { while (i < text.length && text[i] !== '\n') i++; continue }
    if (c === '/' && nx === '*') { i += 2; while (i < text.length && !(text[i] === '*' && text[i + 1] === '/')) i++; i += 2; continue }
    if (c === '"' || c === "'" || c === '`') { const q = c; i++; while (i < text.length) { if (text[i] === '\\') { i += 2; continue } if (text[i] === q) { i++; break } i++ } out += '""'; continue }
    out += c; i++
  }
  return out
}

const SRC = collect(PKG).map((p) => ({ path: p, code: code(readFileSync(p, 'utf8')) }))

async function main() {
  console.log('=== P-R5 必做 4：合规自检（静态 + 运行）===')

  // ---------- 静态断言 ----------
  console.log('--- 静态 ---')
  const bannedStatic = [
    { re: /setRequestHeader|Modify-Everywhere|x-forwarded-for|referer\s*:/i, why: '伪造/改写请求头' },
    { re: /Authorization\s*[:=]\s*['"`]/i, why: '硬编码鉴权头' },
    { re: /rmdir|del\s+.*\.log|truncate.*\.log/i, why: '清除对方日志' },
    { re: /for\s*\([^)]*\bpage\b[^)]*\)[^]{0,200}?(next|page\+1)/i, why: '翻页批量抓取循环' },
    { re: /Promise\.all\([^)]*\bfor\b|batchCrawl|crawlAll|spider/i, why: '批量/并发扇出抓取' },
    { re: /paywall|bypass|scrape.*pay/i, why: '绕过付费墙' },
  ]
  for (const { path, code: src } of SRC) {
    for (const b of bannedStatic) {
      check(!b.re.test(src), `静态：无「${b.why}」代码路径（${path.replace(PROJECT_ROOT, '.')}）`)
    }
  }
  // 伪装 UA：常量为普通桌面 UA，且代码中无 UA 伪造/随机轮换
  check(/Mozilla\/5\.0/.test(NORMAL_UA) && !/bot|crawler|spider/i.test(NORMAL_UA), '静态：NORMAL_UA 是普通桌面 UA，未伪装爬虫')
  const rotUa = SRC.filter((s) => /User-Agent/i.test(s.code) && /random|Math\.random|rotate/i.test(s.code))
  check(rotUa.length === 0, '静态：无 UA 随机轮换/伪造逻辑')
  // 黑名单硬拒在代码中真实存在
  const comp = readFileSync(join(PKG, 'lib', 'compliance.mjs'), 'utf8')
  check(/sci-hub/.test(comp) && /libgen/.test(comp), '静态：黑名单常量含 sci-hub 与 libgen')
  for (const d of ['sci-hub.se', 'libgen.is', 'libgen.rs', 'z-lib.io']) {
    check(isDeniedDomain(d) === true, `运行前判据：${d} 命中黑名单`)
  }
  check(gateDomain('https://sci-hub.se/x', { tempAuth: grantTempAuth(new Set(), 'sci-hub.se') }).allowed === false, '运行前判据：黑名单即使被临时授权也拒')

  // ---------- 运行断言 ----------
  console.log('--- 运行 ---')
  const engine = createBrowserEngine({})

  const r1 = await engine.browse({ url: 'https://example.com/' })
  check(!r1.ok && r1.code === 'E_DOMAIN_NOT_ALLOWED', `运行：白名单外域被拒（${r1.code}）`)

  const r2 = await engine.browse({ url: 'https://sci-hub.se/10.1/x' })
  check(!r2.ok && r2.code === 'E_DOMAIN_NOT_ALLOWED', `运行：黑名单 sci-hub 被拒（${r2.code}）`)

  const r3 = await engine.browse({ url: 'https://arxiv.org/abs/2301.00001' })
  check(r3.ok, `运行：白名单域可抓（${r3.ok ? 'ok' : r3.code}）`)

  // 单域限速 ≥1s：连续两次同域，间隔应 ≥1000ms
  const t0 = Date.now()
  await engine.browse({ url: 'https://arxiv.org/abs/2301.00002' })
  const gap = Date.now() - t0
  check(gap >= 1000, `运行：单域限速生效（同域两次间隔 ${gap}ms ≥ 1000ms）`)

  // robots 处理（白名单域走预检；这里直接验函数层）
  const { checkRobots } = await import('../packages/plugins/research-browser/lib/compliance.mjs')
  const rb = await checkRobots('https://arxiv.org/private/x', async () => ({ ok: true, text: 'User-agent: *\nDisallow: /private\n' }))
  check(rb.allowed === false, '运行：robots.txt Disallow 路径被拦截')
  const rb2 = await checkRobots('https://example.org/x', async () => ({ ok: true, text: 'Disallow: /\n' }))
  check(rb2.skipped === true, '运行：非白名单域不做 robots 预检（skipped）')

  // browser.jsonl 审计字段齐全
  const lines = readFileSync(AUDIT, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l))
  const decisions = [...new Set(lines.map((a) => a.decision))]
  check(lines.length > 0, `审计：browser.jsonl 共 ${lines.length} 行`)
  check(decisions.includes('allow') && decisions.includes('saved') && decisions.includes('deny'), `审计：decision 覆盖 allow/saved/deny（实际 ${decisions.join(',')}）`)
  const sample = lines[lines.length - 1]
  for (const f of ['ts', 'decision']) check(sample[f] !== undefined, `审计：字段 ${f} 存在`)
  check(lines.some((a) => a.host) && lines.some((a) => a.url !== undefined), '审计：含 host / url 字段')
  check(lines.some((a) => a.reason) || lines.some((a) => a.kind), '审计：含 reason 或 kind 字段')
  const denyLines = lines.filter((a) => a.decision === 'deny')
  check(denyLines.length >= 1, `审计：存在 deny 记录 ${denyLines.length} 条（例：${denyLines[0]?.kind || denyLines[0]?.reason}）`)
  const needsReason = denyLines.filter((a) => a.reason !== undefined || a.kind !== undefined)
  check(needsReason.length === denyLines.length, '审计：每条 deny 均带 reason/kind')

  console.log(`\n=== 结果：${failures === 0 ? '全部通过' : failures + ' 项失败'}（共 ${results.length} 项）===`)
  process.exit(failures === 0 ? 0 : 1)
}

main().catch((e) => { console.error('合规验收异常:', e); process.exit(2) })