// tools/_quota-sleep.mjs
//
// S31·B2 公共函数：把"配额静默 45s"从各探针里抽出来，避免令牌桶（10 req/min）碰撞。
// probe-s26-real / probe-s30-memory / probe-s31-* 统一 import 这里，而不是各自 inline sleep(45000)。
//
// 设计：
//   · QUOTA_SILENCE_MS 默认 45000（错开上一轮 9 请求占用的令牌窗）。
//   · makeQuotaSleeper({ sleep, log }) 返回一个 awaitQuotaWindow(ms?) —— 可注入 sleep/log 做测试。
//   · 不静默降级：只是等待；等待期间不抛错、不影响后续判定。
export const QUOTA_SILENCE_MS = 45000

export function makeQuotaSleeper({ sleep = (ms) => new Promise((r) => setTimeout(r, ms)), log = console.log } = {}) {
  return async function awaitQuotaWindow(ms = QUOTA_SILENCE_MS) {
    const sec = Math.round(ms / 1000)
    try { log(`  ... 配额静默 ${sec}s（错开上一轮令牌窗，避免 10 rpm 桶碰撞）`) } catch { /* log 不可用时忽略 */ }
    await sleep(ms)
    return true
  }
}

export default { QUOTA_SILENCE_MS, makeQuotaSleeper }
