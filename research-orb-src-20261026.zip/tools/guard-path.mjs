#!/usr/bin/env node
// 路径守卫：node tools/guard-path.mjs <path> [<path>...]
// 任一目标不在项目根之下 -> 打印违规路径并 exit 1
import { resolve, relative, isAbsolute } from 'node:path'
const ROOT = resolve(import.meta.dirname, '..')
const args = process.argv.slice(2)
if (args.length === 0) { console.error('guard-path: 需要至少一个路径参数'); process.exit(2) }
const bad = []
for (const a of args) {
  const p = resolve(a)
  const rel = relative(ROOT, p)
  if (rel.startsWith('..') || isAbsolute(rel)) bad.push(p)
}
if (bad.length > 0) {
  console.error('guard-path: 拒绝越界写入 ->')
  for (const b of bad) console.error('  ' + b)
  process.exit(1)
}
console.log('guard-path: OK (' + args.length + " 个路径均在 " + ROOT + ' 之下)')