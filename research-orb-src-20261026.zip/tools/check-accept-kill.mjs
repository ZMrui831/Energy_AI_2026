// tools/check-accept-kill.mjs —— S74c·P0-1 护栏：**验收/工具脚本的进程清理必须精确**
//
// 起因（主管实测，定性为"主管过失，最优先"）：
//   accept-s73-dev / accept-s51-e2e 按 **app 路径通配** 匹配后 taskkill，
//   00:31–00:56 把**用户正在跑的实例**杀掉 5 次。按进程名/app 路径匹配永远会误伤真人。
//
// 检查项（任一命中即 FAIL，退出码 1）：
//   R1 带星号的通配字面量：星号 + 项目名 + 星号的**连续**字面量——任何文件都不许有
//      （注意：本文件为描述规则不得不提到它，故用"星号通配"等文字表述，不写字面量本身）
//   R2 PowerShell 筛选串：`-like '…项目名…'` / `-match '项目名'` 这类按命令行文本捞进程的写法
//   R3 按进程名/镜像名杀：taskkill 的镜像名开关、Stop-Process 的 -Name 参数（二者都会误伤同名进程）
//   R4 起了 Electron 就必须带唯一标识：`--user-data-dir=${orbUdata(...)}` 或 `orbSpawnArgs(`
//   R5 起了 Electron 就必须有精确清理：`killMarked(` / `taskkill /PID <具体 pid>` /
//      `child.kill()`（Node 的 ChildProcess.kill 只作用于本进程 spawn 出来的子进程，天然精确）
//
// 允许的（不算违规）：
//   · 普通子串 `'research-orb'` 作为 **JS 参数/测试数据**（如 `cmdlineMatch: 'research-orb'`、
//     `listByCommandLine('research-orb', …)`、stub 里的 `app: 'research-orb'`）——
//     它不带星号、不进 PowerShell 筛选语境、不用于杀进程。
//   · `_orb-proc.mjs` 里的模式串用 **数组拼接 + 环境变量注入**，所以文件里没有通配字面量，
//     因此本护栏**零豁免**（不需要白名单）。
//
// 用法：node tools/check-accept-kill.mjs       （人读输出）
//       node tools/check-accept-kill.mjs --json（机器可读）

import { readdirSync, readFileSync, statSync } from 'node:fs'
import {join, resolve} from 'node:path'

const ROOT = resolve(import.meta.dirname, '..')
const SCAN_DIRS = ['tools', 'tests']

// 豁免（**明示，不隐藏**）：
//   · 本文件自身：规则定义必须描述被禁模式，否则无法写规则；
//   · `*.test.mjs`：测试文件的职责就是**断言"产品源码里没有这些写法"**，
//     因此必然要把禁用写法写成字符串/正则（如 tests/process-discipline.test.mjs、
//     tests/tools-shell.test.mjs 的拦截用例）。这些是**引用**不是执行。
//     测试文件仍受 R1（通配字面量）与 R4/R5（唯一标识 + 精确清理）约束。
const SELF_FILE = 'check-accept-kill.mjs'
const TEST_FILE = /\.test\.mjs$/

const R1 = /\*research-orb\*/            // 带星号的连续字面量
const R2 = /-like\s+['"]\*?[^'"]*research-orb|-match\s+['"]research-orb/i
// R3 只在**执行上下文**里才算违规：
//   · 测试文件必须把禁用写法写成字符串/正则才能断言"产品里没有它"（如 tests/process-discipline.test.mjs、
//     tests/tools-shell.test.mjs 的拦截用例、redteam-demo 的攻击样本）——这些是**引用**，不是执行；
//   · 真正的违规是"把 taskkill /IM 交给 spawnSync/execFileSync 去跑"，或 PowerShell 脚本里 Stop-Process -Name。
// R3 的正则用**拼接**写成：否则本文件自己描述规则时就会被自己命中。
const R3 = new RegExp(
  [
    '(spawnSync|execFileSync|execSync|spawn)\\([^\\n]*taskkill[^\\n]*', '/IM\\b',
    '|',
    '(powershell|-Command|\\bps\\()[^\n]*Stop-Process[^\\n]*-Name\\b',
  ].join(''),
  'i',
)
const R4_OK = /--user-data-dir=\$\{orbUdata\(|orbSpawnArgs\(/
// 精确清理三种形态：按 mark 回收 / 按具体 PID 杀（/pid 大小写不敏感）/ ChildProcess.kill（含带参调用）
const R5_OK = /killMarked\(|taskkill[^\n]*\/pid\b|\.kill\(/i
// "起了 Electron"的判定：有 spawn 调用 **且** 文件里有 Electron 启动特征。
// （只看 spawn( 会误判桩函数/普通子进程，如 accept-s67-shell 的 spawn 是纯 JS stub）
const SPAWN_CALL = /\bspawn\(/
const ELECTRON_HINT = /--no-sandbox|--remote-debugging-port|electron\.exe|dsh-orb-electron|desktop\\main\.mjs/

const findings = []
let files = 0

for (const dir of SCAN_DIRS) {
  let names = []
  try { names = readdirSync(join(ROOT, dir)) } catch { continue }
  for (const name of names) {
    if (!name.endsWith('.mjs')) continue
    const p = join(ROOT, dir, name)
    if (!statSync(p).isFile()) continue
    const src = readFileSync(p, 'utf8')
    files++
    const lines = src.split('\n')
    const flag = (re, rule) => {
      lines.forEach((ln, i) => {
        if (re.test(ln)) findings.push({ file: `${dir}/${name}`, line: i + 1, rule, text: ln.trim().slice(0, 160) })
      })
    }
    flag(R1, 'R1 通配字面量')
    if (name === SELF_FILE) continue // 规则定义文件：只统计，不自判
    if (!TEST_FILE.test(name)) {
      flag(R2, 'R2 PowerShell 筛选串')
      flag(R3, 'R3 按进程名/镜像名杀')
    }
    if (SPAWN_CALL.test(src) && ELECTRON_HINT.test(src)) {
      if (!R4_OK.test(src)) findings.push({ file: `${dir}/${name}`, line: 0, rule: 'R4 起 Electron 无唯一标识', text: '未发现 --user-data-dir=${orbUdata(...)} / orbSpawnArgs(' })
      if (!R5_OK.test(src)) findings.push({ file: `${dir}/${name}`, line: 0, rule: 'R5 起 Electron 无精确清理', text: '未发现 killMarked( / taskkill /PID' })
    }
  }
}

const jsonMode = process.argv.includes('--json')
if (jsonMode) {
  console.log(JSON.stringify({ scanned: files, findings: findings.length, items: findings }, null, 2))
} else {
  console.log(`check-accept-kill：扫描 ${files} 个 .mjs（tools + tests）`)
  console.log(`豁免（明示）：规则定义文件 ${SELF_FILE}；*.test.mjs 的 R2/R3（测试需引用禁用写法做断言）`)
  if (!findings.length) {
    console.log('PASS —— 0 项违规（无通配字面量 / 无按名杀 / 起 Electron 者均有唯一标识与精确清理）')
  } else {
    console.log(`FAIL —— ${findings.length} 项违规：`)
    for (const f of findings) console.log(`  [${f.rule}] ${f.file}${f.line ? ':' + f.line : ''}\n      ${f.text}`)
  }
}
process.exit(findings.length ? 1 : 0)
