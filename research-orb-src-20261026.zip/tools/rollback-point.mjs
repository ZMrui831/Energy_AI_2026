// tools/rollback-point.mjs —— S51 可逆化：为 UI 改造建"回滚点"
//
// 用法：
//   node tools\rollback-point.mjs --create [--label "s51-before"]
//   node tools\rollback-point.mjs --list
//   node tools\rollback-point.mjs --restore <id>
//
// 纪律：
//   · 回滚点落在项目根 `rollback\<id>\`，**不进 data\**（不污染业务数据、不影响隔离门禁）；
//   · 只备份"本轮要动的文件"，附 manifest.json 记录相对路径 + sha256 + 大小；
//   · restore 先校验 sha256 再写回；缺文件就报错，绝不"尽力而为"地半恢复。
//   · **备份即复制，不是移动** —— 回滚点本身不会被后续操作破坏。

import { createHash } from 'node:crypto'
import { copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs'
import {dirname, join, resolve} from 'node:path'

const ROOT = resolve(import.meta.dirname, '..')
// 回滚点放在 data\backups\rollback\ 下：
//   ① `backups` 在 check-imports 的 SKIP_DIR 里 —— 备份的 .mjs 不会被当成源码扫描
//      （放项目根 rollback\ 时踩过：备份里缺兄弟文件，239 号测试直接红）；
//   ② 语义就是"备份"，与交付物分开。
const BACKUP_ROOT = join(ROOT, 'data', 'backups', 'rollback')

/** 本轮 UI 改造可能触碰的文件（都在项目内，可整体回退）。 */
const WATCH = [
  'apps/desktop/main.mjs',
  'apps/desktop/ui-bridge.mjs',
  'packages/packs/research/pack.json',
  'packages/packs/research/ui/home.js',
  'packages/packs/research/ui/home-v1.js',
  'packages/packs/research/ui/design-v1.js',
  'packages/packs/research/ui/timeline.js',
  'packages/packs/research/ui/literature.js',
  'packages/packs/research/ui/timer.js',
  'packages/packs/research/ui/music.js',
  'docs/DESIGN-UI.md',
]

const sha = (buf) => createHash('sha256').update(buf).digest('hex')

function create(label) {
  const id = new Date().toISOString().replace(/[:.]/g, '-') + (label ? '-' + label : '')
  const dir = join(BACKUP_ROOT, id)
  mkdirSync(dir, { recursive: true })
  const files = []
  for (const rel of WATCH) {
    const abs = join(ROOT, rel)
    if (!existsSync(abs)) continue
    const buf = readFileSync(abs)
    const dst = join(dir, rel)
    mkdirSync(dirname(dst), { recursive: true })
    copyFileSync(abs, dst)
    files.push({ rel, bytes: buf.length, sha256: sha(buf) })
  }
  writeFileSync(join(dir, 'manifest.json'), JSON.stringify({ id, label: label || '', at: new Date().toISOString(), files }, null, 2), 'utf8')
  console.log(`[rollback] 回滚点已建：rollback\\${id}\\（${files.length} 个文件）`)
  for (const f of files) console.log(`   ${f.rel}  ${f.bytes}B  ${f.sha256.slice(0, 12)}`)
  return id
}

function list() {
  if (!existsSync(BACKUP_ROOT)) {
    console.log('[rollback] 还没有回滚点')
    return
  }
  const ids = readdirSync(BACKUP_ROOT, { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => d.name).sort()
  for (const id of ids) {
    const mf = join(BACKUP_ROOT, id, 'manifest.json')
    let n = 0
    let label = ''
    try {
      const m = JSON.parse(readFileSync(mf, 'utf8'))
      n = (m.files || []).length
      label = m.label || ''
    } catch { /* 旧点无 manifest */ }
    console.log(`   ${id}  ${n} 文件  ${label}`)
  }
}

function restore(id) {
  const dir = join(BACKUP_ROOT, id)
  const mf = join(dir, 'manifest.json')
  if (!existsSync(mf)) {
    console.error(`[rollback] 找不到回滚点：${id}`)
    process.exit(2)
  }
  const m = JSON.parse(readFileSync(mf, 'utf8'))
  let ok = 0
  const bad = []
  // 逐文件尽力恢复：任何一个文件被锁（应用正在运行就会这样）都不能中断其余文件，
  // 否则会停在"回滚了一半"的更糟状态 —— 这个坑刚踩过。
  for (const f of m.files || []) {
    const src = join(dir, f.rel)
    if (!existsSync(src)) { bad.push(f.rel + '（备份缺失）'); continue }
    const buf = readFileSync(src)
    if (sha(buf) !== f.sha256) { bad.push(f.rel + '（备份 sha 不符）'); continue }
    const dst = join(ROOT, f.rel)
    try {
      mkdirSync(dirname(dst), { recursive: true })
      writeFileSync(dst, buf)
      ok += 1
    } catch (e) {
      bad.push(f.rel + '（写入被拒：' + (e && e.code ? e.code : 'error') + '，应用可能正在运行）')
    }
  }
  console.log(`[rollback] 已恢复 ${ok} 个文件（回滚点 ${id}）`)
  if (bad.length > 0) {
    console.error('[rollback] 未恢复 ' + bad.length + ' 个：' + bad.join('；'))
    console.error('[rollback] 请**完全退出 research-orb** 后重跑本条命令。')
    process.exit(1)
  }
}

const argv = process.argv.slice(2)
if (argv.includes('--create')) {
  const i = argv.indexOf('--label')
  create(i >= 0 ? argv[i + 1] : '')
} else if (argv.includes('--list')) {
  list()
} else if (argv.includes('--restore')) {
  const id = argv[argv.indexOf('--restore') + 1]
  if (!id) { console.error('[rollback] --restore 需要 id'); process.exit(2) }
  restore(id)
} else {
  console.log('用法：--create [--label x] | --list | --restore <id>')
}
