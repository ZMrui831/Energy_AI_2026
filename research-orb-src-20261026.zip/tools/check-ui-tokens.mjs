// tools/check-ui-tokens.mjs —— S70·2C 配色门禁：ui/ 目录除 design-v1.js（token 源）外不得硬编码品牌色
//
// 规则：design-v1.js 是设计 token 的唯一出处（允许 hex）；其余 ui/*.js 中出现硬编码 hex（白/黑/透明除外）即 FAIL。
import { readFileSync, readdirSync, existsSync } from 'node:fs'
import { join, dirname, basename } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const UI = join(ROOT, 'packages', 'packs', 'research', 'ui')
const TOKEN_FILE = 'design-v1.js'
const BRAND = ['#1f9d8f', '#d1fae5', '#12171a']
const ALLOW = new Set(['#fff', '#ffffff', '#000', '#000000', '#ffffffff'])

if (!existsSync(UI)) { console.log('[check-ui-tokens] ui 目录不存在'); process.exit(0) }
const files = readdirSync(UI).filter((f) => f.endsWith('.js') && f !== TOKEN_FILE)
const violations = []
for (const f of files) {
  const txt = readFileSync(join(UI, f), 'utf8')
  const lc = txt.toLowerCase()
  for (const b of BRAND) if (lc.includes(b)) { violations.push(`${f}: 硬编码品牌色 ${b}`); break }
  // 通用 hex（排除纯白/黑）
  const hex = txt.match(/#[0-9a-fA-F]{3,8}\b/g) || []
  for (const h of hex) {
    if (ALLOW.has(h.toLowerCase())) continue
    violations.push(`${f}: 硬编码 hex ${h}`)
  }
}
if (violations.length) {
  console.log(`[check-ui-tokens] FAIL ${violations.length} 处：`)
  for (const v of violations.slice(0, 20)) console.log('  ✗ ' + v)
  process.exit(1)
}
console.log(`[check-ui-tokens] ✓ PASS：${files.length} 个 ui 文件无硬编码色（design-v1.js 为 token 唯一源）`)
