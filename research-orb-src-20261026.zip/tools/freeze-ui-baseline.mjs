// tools/freeze-ui-baseline.mjs —— D3 基线冻结命令（CONTRACT §7：基线不许自己漂）。
//
// 行为：CDP 真启动 → 展开 → __s5.freeze()（状态条/通知条打桩，易变内容掩码）→
//       逐状态截图写入 data/shots/ui-matrix/baseline/ → 写 LEDGER.json 哈希台账
//       （谁/何时/什么原因/旧哈希→新哈希；禁止静默刷新）。
//
// 用法：
//   node tools/freeze-ui-baseline.mjs --reason "S8：状态条打桩后重建基线"
//   node tools/freeze-ui-baseline.mjs --reason "..." --states default,learning
//
// 纪律：fail-closed（已有 research-orb electron 在跑则退出）；只杀自己起的进程（按 PID 树）。

import { spawn, spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { mkdirSync, writeFileSync, readFileSync, existsSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { UI_STATES } from '../packages/plugins/timeline/logic.mjs'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('freeze-ui-baseline')

const ELECTRON_EXE = ORB_ELECTRON
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const BASE = join(PROJECT_ROOT, 'data', 'shots', 'ui-matrix', 'baseline')
const LEDGER = join(BASE, 'LEDGER.json')
const PORT = 9350
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const sha = (p) => createHash('sha256').update(readFileSync(p)).digest('hex')

const argv = process.argv.slice(2)
const arg = (k, d = null) => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : d }
const reason = arg('--reason')
if (!reason) { console.error('用法: node tools/freeze-ui-baseline.mjs --reason "<冻结原因>" [--states a,b]'); process.exit(2) }
const states = (arg('--states') || '').split(',').map((s) => s.trim()).filter(Boolean)
const LIST = states.length ? states : UI_STATES.slice()

async function findTarget(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const list = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(t.url))
      if (page) return page
    } catch { /* 还没起来 */ }
    await sleep(300)
  }
  throw new Error(`CDP 目标未找到（port ${PORT}）`)
}

async function main() {
  mkdirSync(BASE, { recursive: true })

  if (countOrbAll() > 0) throw new Error('已有 research-orb electron 在运行（fail-closed）')

  const oldHashes = {}
  for (const st of LIST) {
    const p = join(BASE, `${st}.png`)
    if (existsSync(p)) oldHashes[st] = sha(p)
  }

  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN_MJS], { cwd: PROJECT_ROOT, env: childEnv, stdio: 'ignore' })
  console.log(`electron pid=${child.pid}`)
  try {
    const target = await findTarget()
    const ws = new WebSocket(target.webSocketDebuggerUrl)
    await new Promise((resolve, reject) => {
      ws.addEventListener('open', resolve)
      ws.addEventListener('error', () => reject(new Error('CDP WebSocket 连接失败')))
    })
    const pending = new Map()
    let id = 0
    ws.addEventListener('message', (ev) => {
      let m
      try { m = JSON.parse(ev.data) } catch { return }
      if (m.id !== undefined && pending.has(m.id)) {
        const p = pending.get(m.id)
        pending.delete(m.id)
        if (m.error) p.rej(new Error(m.error.message))
        else p.res(m.result)
      }
    })
    const send = (method, params = {}) => new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method, params })) })
    const ev = async (e) => (await send('Runtime.evaluate', { expression: e, returnByValue: true })).result.value
    await send('Page.enable'); await send('Runtime.enable')
    await sleep(6000)
    await ev(`window.researchOrb.send('window', { action: 'expand' })`)
    await sleep(2500)
    // D3：冻结易变内容（状态条/通知条打桩）
    const fro = await ev(`window.__s5 ? window.__s5.freeze() : false`)
    console.log(`freeze volatile: ${fro}`)
    await sleep(600)

    const files = []
    for (const st of LIST) {
      await ev(`window.__s5 && window.__s5.setState(${JSON.stringify(st)})`)
      await sleep(700)
      const s = await send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
      const p = join(BASE, `${st}.png`)
      writeFileSync(p, Buffer.from(s.data, 'base64'))
      const newSha = sha(p)
      files.push({ name: `${st}.png`, oldSha256: oldHashes[st] || null, newSha256: newSha, bytes: Buffer.from(s.data, 'base64').length })
      console.log(`  frozen shot: baseline/${st}.png (${files[files.length - 1].bytes}B) sha=${newSha.slice(0, 12)}…`)
    }
    await ev(`window.__s5 && window.__s5.setState('default')`)

    const ledger = existsSync(LEDGER) ? JSON.parse(readFileSync(LEDGER, 'utf8')) : { entries: [] }
    ledger.entries.push({
      at: new Date().toISOString(),
      by: process.env.USERNAME || process.env.USER || 'unknown',
      reason,
      states: LIST.slice(),
      files,
      frozen: true,
    })
    writeFileSync(LEDGER, JSON.stringify(ledger, null, 2))
    console.log(`LEDGER -> ${LEDGER}（${files.length} 项，旧→新哈希已记账）`)
  } finally {
    try { spawnSync('taskkill', ['/pid', String(child.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true }) } catch { /* noop */ }
    await sleep(800)

    console.log(`residue: ${String(countOrbAll())}`)
  }
  process.exit(0)
}

main().catch((e) => { console.error('冻结失败:', e); process.exit(2) })
