// tools/accept-s69-daily-idempotent.mjs —— S69·1A 日报幂等 + 分数留痕验收
// 单行复跑：node tools\accept-s69-daily-idempotent.mjs
import { mkdirSync, readFileSync, rmSync, statSync, existsSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createDailyPipeline } from '../packages/plugins/coach/daily.mjs'

const items = []
const check = (id, ok, detail = '') => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300) }); console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's69-daily')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(join(WORK, 'coach'), { recursive: true })
const COACH_DIR = join(WORK, 'coach')

// 固定时钟 + 固定夹具：同一天连跑 3 次（同一证据集 → 只写 1 次，其后 cached）
const T0 = Date.parse('2026-10-25T18:00:00+08:00')
let t = T0
const now = () => t
const FRAMES = [{ imagePath: join(WORK, 'f1.png'), window: 'Word', process: 'winword.exe' }]

const stubExtractor = {
  async extract() { return { ok: true, cached: false, frameId: 'fr-fix1', textSha256: 'sha-fix1', text: '写论文草稿', structured: { intent: '工作' }, source: 'stub' } },
}
const stubRouter = {
  async run(taskClass) {
    if (taskClass === 'summarize') return { ok: true, text: JSON.stringify(['写论文草稿']) }
    if (taskClass === 'score-plan') return { ok: true, text: JSON.stringify({ score: 80, advice: ['补齐第二章', '跑对比实验'] }) }
    return { ok: true, text: 'stub' }
  },
}

try {
  const p = createDailyPipeline({ dir: COACH_DIR, router: stubRouter, extractor: stubExtractor, now })
  const r1 = await p.run({ consentActive: true, goal: '两周完成综述', frames: FRAMES })
  const reportPath = r1.reportPath
  const m1 = statSync(reportPath).mtimeMs
  await new Promise((r) => setTimeout(r, 20)); t += 1000
  const r2 = await p.run({ consentActive: true, goal: '两周完成综述', frames: FRAMES })
  const m2 = statSync(reportPath).mtimeMs
  await new Promise((r) => setTimeout(r, 20)); t += 1000
  const r3 = await p.run({ consentActive: true, goal: '两周完成综述', frames: FRAMES })
  const m3 = statSync(reportPath).mtimeMs

  const dailyFiles = readdirSync(join(COACH_DIR, 'daily')).filter((f) => f.endsWith('.md'))
  check('ID-1 连跑 3 次 → 日报仅 1 份且 mtime 只变 1 次（第2/3次 cached）',
    dailyFiles.length === 1 && m2 === m1 && m3 === m1 && r2.cached === true && r3.cached === true,
    `files=${dailyFiles.length} mtime ${m1 === m2 && m2 === m3 ? '不变' : '变了'}`)

  check('ID-2 三次 score 一致（基数=当日全部有效轨迹，非本轮新增）', r1.score === 80 && r2.score === 80 && r3.score === 80, `scores=${r1.score}/${r2.score}/${r3.score}`)

  const sh = readFileSync(join(COACH_DIR, 'score-history.jsonl'), 'utf8').trim().split('\n').map((l) => JSON.parse(l))
  check('ID-3 scoreHistory 有 3 行且 trajectoryCount 一致（=当日 work/life 行数）',
    sh.length === 3 && sh.every((s) => s.trajectoryCount === sh[0].trajectoryCount) && sh[0].trajectoryCount === 1,
    `rows=${sh.length} counts=${sh.map((s) => s.trajectoryCount).join(',')}`)

  const report = readFileSync(reportPath, 'utf8')
  check('ID-4 日报含「评分变动（最近 3 次）」节', report.includes('## 评分变动（最近 3 次）'), '')
  check('ID-5 本轮新增与当日累计两个数字都给', report.includes('本轮新增') && report.includes('当日累计'), '')

  check('ID-6 指纹相同 → 第2/3次 cached:true（且非首轮）', r1.cached === false && r2.cached === true && r3.cached === true, `r1=${r1.cached} r2=${r2.cached} r3=${r3.cached}`)

  // ⑦ 口径自洽：scoreHistory 最后一条 trajectoryCount === 当日 trajectory.jsonl 中 line∈{work,life} 行数
  const traj = existsSync(join(COACH_DIR, 'trajectory.jsonl'))
    ? readFileSync(join(COACH_DIR, 'trajectory.jsonl'), 'utf8').trim().split('\n').map((l) => JSON.parse(l))
    : []
  const effectiveRows = traj.filter((x) => x.line === 'work' || x.line === 'life').length
  check('ID-7 口径自洽：scoreHistory 末条 trajectoryCount === work/life 轨迹行数', sh[sh.length - 1].trajectoryCount === effectiveRows && effectiveRows === 1, `last=${sh[sh.length - 1].trajectoryCount} trajWorkLife=${effectiveRows}`)
} catch (e) {
  check('ID-0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 300))
}

const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s69-daily-idempotent: total=${items.length} pass=${pass} fail=${items.length - pass}`)
try { mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true }) } catch { /* noop */ }
process.exit(items.every((i) => i.ok) ? 0 : 1)
