// tools/accept-s25b-daily.mjs —— S25·2C 每日流水线验收（真实桩三条轨迹；桩 router 显式 usagePath）。
// 单行复跑：node tools\accept-s25b-daily.mjs
// 证据：data\logs\s25b-daily-accept.json
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync, statSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createRouter } from '../packages/core/src/router.mjs'
import { createExtractor } from '../packages/plugins/coach/extract.mjs'
import { createDailyPipeline } from '../packages/plugins/coach/daily.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 240), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's25b-daily')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(join(WORK, 'coach'), { recursive: true })
mkdirSync(join(WORK, 'frames'), { recursive: true })
const COACH_DIR = join(WORK, 'coach')
const usagePath = join(WORK, 'usage.jsonl') // 桩 router 显式 usagePath（红线 2）

// 三张不同内容的测试图（帧）
const FRAMES = [
  { window: '论文阅读', process: 'msedge.exe', body: 'frame-A: 微电网综述第二章' },
  { window: '实验数据', process: 'Code.exe', body: 'frame-B: 下垂控制仿真脚本' },
  { window: '文献笔记', process: 'Typora.exe', body: 'frame-C: 相关工作表格整理' },
]
for (const f of FRAMES) writeFileSync(join(WORK, 'frames', f.window + '.png'), Buffer.from(f.body))

function makeStubRouter({ failSummarize = false, failScore = false, badScore = false } = {}) {
  return createRouter({
    providers: { cheap: { providerId: 'school-gateway', model: 'qwen' }, flagship: { providerId: 'deepseek-api', model: 'deepseek-chat' } },
    invoke: async ({ tier, taskClass }) => {
      if (taskClass === 'extract') return { text: '屏幕文字转录内容（桩）' }
      if (taskClass === 'summarize') {
        if (failSummarize) throw Object.assign(new Error('flagship down'), { code: 'E_HTTP_502' })
        return { text: JSON.stringify(['阅读微电网综述文献', '调试下垂控制仿真', '整理相关工作表格']) }
      }
      if (taskClass === 'score-plan') {
        if (failScore) throw Object.assign(new Error('flagship down'), { code: 'E_HTTP_502' })
        if (badScore) return { text: '这不是 JSON' }
        return { text: JSON.stringify({ score: 82, advice: ['补齐第二章证据', '跑下垂控制对比实验', '整理文献表为 bib'] }) }
      }
      return { text: 'stub' }
    },
    usagePath,
    audit: () => {},
  })
}

try {
  // ① 未同意感知：跳过 + 审计（一个请求都不发）
  const p1 = createDailyPipeline({ dir: COACH_DIR, router: makeStubRouter(), extractor: createExtractor({ dir: COACH_DIR, router: makeStubRouter(), trashDir: join(WORK, 'trash0') }) })
  const r0 = await p1.run({ consentActive: false, frames: FRAMES.map((f) => ({ imagePath: join(WORK, 'frames', f.window + '.png'), window: f.window, process: f.process })) })
  const auditText = () => readFileSync(join(PROJECT_ROOT, 'data', 'logs', 'coach.jsonl'), 'utf8')
  check('D1 未同意感知 → 跳过且审计 skipped-no-consent', r0.skipped === true && auditText().includes('skipped-no-consent') && !existsSync(join(COACH_DIR, 'trajectory.jsonl')))

  // ② 同意后跑通：三条轨迹 + summarize/score-plan 旗舰 + 日报
  const router = makeStubRouter()
  const tiers = []
  const probe = createRouter({ providers: { cheap: {}, flagship: {} }, invoke: async (p) => { tiers.push(p.tier + ':' + p.taskClass); return { text: 't' } }, audit: () => {}, usagePath: join(WORK, 'u2.jsonl') })
  void probe
  const extractor = createExtractor({ dir: COACH_DIR, router, trashDir: join(WORK, 'trash') })
  const pipeline = createDailyPipeline({ dir: COACH_DIR, router, extractor })
  const r1 = await pipeline.run({
    consentActive: true,
    goal: '两周内完成微电网综述初稿',
    frames: FRAMES.map((f) => ({ imagePath: join(WORK, 'frames', f.window + '.png'), window: f.window, process: f.process })),
  })
  check('D2 同意后流水线跑通（3 帧 → 3 轨迹）', r1.ok === true && r1.trajectoryCount === 3 && r1.cached === false)
  const traj = readFileSync(join(COACH_DIR, 'trajectory.jsonl'), 'utf8').trim().split('\n').map((l) => JSON.parse(l))
  check('D3 trajectory 行字段齐 {ts,window,process,intent,level,evidence:{frameId,textSha256}}', traj.length === 3 && traj.every((t) => t.ts && t.window && t.process && t.intent && t.level === 'direct' && t.evidence.frameId && t.evidence.textSha256))
  check('D4 summarize 归纳意图命中桩输出', traj[0].intent === '阅读微电网综述文献' && traj[1].intent === '调试下垂控制仿真' && traj[2].intent === '整理相关工作表格')
  const report1 = readFileSync(r1.reportPath, 'utf8')
  check('D5 日报含评分 82 与三条明日建议', /评分：82 \/ 100/.test(report1) && report1.includes('补齐第二章证据') && report1.split('\n').filter((l) => /^\d+\. /.test(l)).length >= 3)
  check('D6 日报可追溯：每条轨迹的 frameId+textSha256 出现在日报中', traj.every((t) => report1.includes(t.evidence.frameId) && report1.includes(t.evidence.textSha256.slice(0, 16))))

  // ③ 幂等：同日同内容重跑 → cached，不重写
  // 重新放三张同内容图（原图已被 2B 删除）→ 同哈希 → extract 走缓存 → 轨迹内容相同 → 日报 cached
  const restoreFrames = () => {
    for (const f of FRAMES) {
      const img = join(WORK, 'frames', f.window + '.png')
      if (!existsSync(img)) {
        const trashName = readdirSafe(join(WORK, 'trash')).filter((n) => n.includes(f.window)).sort().pop()
        if (trashName) writeFileSync(img, readFileSync(join(WORK, 'trash', trashName)))
      }
    }
  }
  restoreFrames()
  const before = statSync(r1.reportPath).mtimeMs
  const r2 = await pipeline.run({
    consentActive: true,
    goal: '两周内完成微电网综述初稿',
    frames: FRAMES.map((f) => ({ imagePath: join(WORK, 'frames', f.window + '.png'), window: f.window, process: f.process })),
  })
  check('D7 幂等：同日同内容重跑 cached=true 且日报不重写（mtime 不变）', r2.cached === true && statSync(r1.reportPath).mtimeMs === before)

  // ④ 内容变化 → 日报更新（新轨迹入账）
  restoreFrames()
  writeFileSync(join(WORK, 'frames', '论文阅读.png'), Buffer.from('frame-A2: 微电网综述第三章（新内容）'))
  const r3 = await pipeline.run({
    consentActive: true,
    goal: '两周内完成微电网综述初稿',
    frames: FRAMES.map((f) => ({ imagePath: join(WORK, 'frames', f.window + '.png'), window: f.window, process: f.process })),
  })
  const trajCount = readFileSync(join(COACH_DIR, 'trajectory.jsonl'), 'utf8').trim().split('\n').length
  const a2FrameId = 'fr-' + (await import('node:crypto')).createHash('sha256').update(Buffer.from('frame-A2: 微电网综述第三章（新内容）')).digest('hex').slice(0, 12)
  check('D8 内容变化 → 日报更新（A2 新 frameId 入报 cached=false；重复观测不重复入账 → 4 行）', r3.cached === false && trajCount === 4 && readFileSync(r3.reportPath, 'utf8').includes(a2FrameId), `trajCount=${trajCount}`)

  // ⑤ summarize 失败 → intent 诚实标注（不造假）
  const pBad = createDailyPipeline({ dir: join(WORK, 'coach-bad'), router: makeStubRouter({ failSummarize: true }), extractor: createExtractor({ dir: join(WORK, 'coach-bad'), router: makeStubRouter({ failSummarize: true }), trashDir: join(WORK, 'trash-bad') }) })
  writeFileSync(join(WORK, 'frames', 'b1.png'), Buffer.from('bad-sum frame'))
  const r4 = await pBad.run({ consentActive: true, frames: [{ imagePath: join(WORK, 'frames', 'b1.png'), window: '窗口', process: 'proc' }] })
  const badTraj = readFileSync(join(WORK, 'coach-bad', 'trajectory.jsonl'), 'utf8').trim().split('\n').map((l) => JSON.parse(l))
  check('D9 summarize 失败 → intent 诚实标注（未归纳）', r4.ok === true && badTraj[0].intent.includes('未归纳'))

  // ⑥ score-plan 失败 → 日报仍生成但 score: unavailable
  const pFail = createDailyPipeline({ dir: join(WORK, 'coach-scorefail'), router: makeStubRouter({ failScore: true }), extractor: createExtractor({ dir: join(WORK, 'coach-scorefail'), router: makeStubRouter({ failScore: true }), trashDir: join(WORK, 'trash-sf') }) })
  writeFileSync(join(WORK, 'frames', 'sf1.png'), Buffer.from('score-fail frame'))
  const r5 = await pFail.run({ consentActive: true, frames: [{ imagePath: join(WORK, 'frames', 'sf1.png'), window: '窗口', process: 'proc' }] })
  const reportFail = readFileSync(r5.reportPath, 'utf8')
  check('D10 score-plan 失败 → 日报仍生成且 score: unavailable（不造假）', r5.ok === true && r5.score === 'unavailable' && /评分：unavailable/.test(reportFail))

  // ⑦ score-plan 输出非 JSON → 同样 unavailable（不许猜分）
  const pBad2 = createDailyPipeline({ dir: join(WORK, 'coach-badjson'), router: makeStubRouter({ badScore: true }), extractor: createExtractor({ dir: join(WORK, 'coach-badjson'), router: makeStubRouter({ badScore: true }), trashDir: join(WORK, 'trash-bj') }) })
  writeFileSync(join(WORK, 'frames', 'bj1.png'), Buffer.from('bad-json frame'))
  const r6 = await pBad2.run({ consentActive: true, frames: [{ imagePath: join(WORK, 'frames', 'bj1.png'), window: '窗口', process: 'proc' }] })
  check('D11 score-plan 输出无法解析 → unavailable', r6.score === 'unavailable' && /无法解析/.test(readFileSync(r6.reportPath, 'utf8')))

  // ⑧ 原图处理后即删（2B 复用）：处理后帧图消失
  check('D12 处理后帧图即删（2B 复用，不留图）', FRAMES.every((f) => !existsSync(join(WORK, 'frames', f.window + '.png'))) && !existsSync(join(WORK, 'frames', 'b1.png')) && !existsSync(join(WORK, 'frames', 'sf1.png')))

  // ⑨ usage 无空 model 行（门禁）
  const rows = usageRows(usagePath)
  check('D13 桩 usage 全部有 model（无空 model 行）', rows.length > 0 && rows.every((r) => r.model !== '' && r.providerId !== ''))
} catch (e) {
  check('D0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 240))
} finally {
  rmSync(WORK, { recursive: true, force: true })
}

const pass = items.filter((i) => i.ok).length
const fail = items.length - pass
const out = { tool: 'accept-s25b-daily', at: new Date().toISOString(), total: items.length, pass, fail, items }
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's25b-daily-accept.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # accept-s25b-daily: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 证据 -> data/logs/s25b-daily-accept.json`)
process.exit(fail === 0 ? 0 : 1)

function readdirSafe(dir) { try { return readdirSync(dir) } catch { return [] } }
function usageRows(p) { try { return readFileSync(p, 'utf8').trim().split('\n').filter((l) => l.trim()).map((l) => JSON.parse(l)) } catch { return [] } }
