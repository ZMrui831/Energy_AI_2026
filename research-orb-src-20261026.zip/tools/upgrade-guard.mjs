// tools/upgrade-guard.mjs —— 手动升级/回滚守卫（本产品禁止自动更新）
// 用法：
//   node tools/upgrade-guard.mjs --zip <path>        预检（dry-run，默认）
//   node tools/upgrade-guard.mjs --backup            备份现行版本
//   node tools/upgrade-guard.mjs --apply --zip <path> 应用（须显式 --apply）
//   node tools/upgrade-guard.mjs --rollback           回滚到 last-known-good
import { readFileSync, existsSync, mkdirSync, copyFileSync, readdirSync, statSync } from 'node:fs'
import { execFileSync } from 'node:child_process'
import {join, basename, resolve} from 'node:path'
import { createHash } from 'node:crypto'

const ROOT = resolve(import.meta.dirname, '..')
const PKG = join(ROOT, 'package.json')
const LKG_DIR = join(ROOT, 'dist-package', 'last-known-good')
const BAK_DIR = join(ROOT, 'dist-package', 'backups')
const UP_LOG = join(ROOT, 'data', 'logs', 'upgrade.jsonl')

const argv = process.argv.slice(2)
const has = (f) => argv.includes(f)
const val = (f) => { const i = argv.indexOf(f); return i >= 0 ? argv[i + 1] : null }

const parseVer = (s) => String(s).replace(/^v/, '').split(/[-+]/)[0].split('.').map((x) => parseInt(x, 10) || 0)
const cmpVer = (a, b) => { const A = parseVer(a), B = parseVer(b); for (let i = 0; i < 3; i++) { if ((A[i] || 0) !== (B[i] || 0)) return (A[i] || 0) > (B[i] || 0) ? 1 : -1 } return 0 }
const sha256 = (p) => createHash('sha256').update(readFileSync(p)).digest('hex')
const nowIso = () => new Date().toISOString()


const installed = JSON.parse(readFileSync(PKG, 'utf8')).version

function audit(action, extra) {
  try {
    mkdirSync(join(ROOT, 'data', 'logs'), { recursive: true })
    const line = JSON.stringify({ ts: nowIso(), action, installed, ...extra }) + '\n'
    const cur = existsSync(UP_LOG) ? readFileSync(UP_LOG, 'utf8') : ''
    // 追加写（避免引入额外模块）
    execFileSync('node', ['-e', `require('fs').appendFileSync(${JSON.stringify(UP_LOG)}, ${JSON.stringify(line)})`], { stdio: 'ignore' })
    void cur
  } catch { /* 审计失败不阻断 */ }
}

if (has('--backup')) {
  mkdirSync(BAK_DIR, { recursive: true })
  const ts = nowIso().replace(/[:.]/g, '-')
  const dst = join(BAK_DIR, ts)
  mkdirSync(dst, { recursive: true })
  let n = 0
  for (const rel of ['apps', 'packages', 'tools', 'vendor', 'docs', 'package.json', 'start.cmd']) {
    const src = join(ROOT, rel)
    if (!existsSync(src)) continue
    copyFileSyncSafe(src, join(dst, rel))
    n++
  }
  console.log('[upgrade-guard] 备份完成 → ' + dst + '（条目 ' + n + '）')
  audit('backup', { dst })
  process.exit(0)
}

if (has('--rollback')) {
  if (!existsSync(LKG_DIR)) { console.error('[upgrade-guard] E_NO_LKG：找不到 last-known-good'); process.exit(2) }
  const zip = readdirSync(LKG_DIR).find((f) => f.endsWith('.zip'))
  const lkgTxt = join(LKG_DIR, 'LKG.txt')
  const want = existsSync(lkgTxt) ? (readFileSync(lkgTxt, 'utf8').match(/sha256\s*:\s*([0-9a-fA-F]{64})/) || [])[1] : null
  const got = zip ? sha256(join(LKG_DIR, zip)) : null
  if (want && got && want.toLowerCase() !== got.toLowerCase()) { console.error('[upgrade-guard] E_LKG_HASH_MISMATCH：LKG 包被改动，拒绝回滚'); process.exit(3) }
  console.log('[upgrade-guard] 回滚指引：把 ' + join(LKG_DIR, zip) + ' 解压覆盖项目目录，然后跑 check-imports + 全量测试 + 启动冒烟')
  audit('rollback-plan', { zip, sha256: got })
  process.exit(0)
}

const zip = val('--zip')
if (!zip) { console.error('[upgrade-guard] 用法：--zip <path> [--apply] | --backup | --rollback'); process.exit(1) }
if (!existsSync(zip)) { console.error('[upgrade-guard] E_ZIP_NOT_FOUND: ' + zip); process.exit(1) }

const m = basename(zip).match(/research-orb-(.+)-win-x64\.zip$/)
if (!m) { console.error('[upgrade-guard] E_BAD_ZIP_NAME：无法从文件名解析版本（期望 research-orb-<ver>-win-x64.zip）'); process.exit(1) }
const target = m[1]
const cmp = cmpVer(target, installed)
const warns = []
// 包内禁止项检查（只列文件名，不解压）
const list = execFileSync('tar', ['-tf', zip], { encoding: 'utf8' }).split(/\r?\n/).filter(Boolean)
for (const bad of ['secrets.json', 'browser-profile', 'node_modules/', '.venv/', '.snapshots/']) {
  if (list.some((l) => l.includes(bad))) warns.push('包内含禁止项: ' + bad)
}
if (!list.some((l) => l.includes('MANIFEST.sha256'))) warns.push('包内缺 MANIFEST.sha256')

console.log('[upgrade-guard] 现行版本 = ' + installed + '；目标版本 = ' + target + '；比较 = ' + (cmp > 0 ? '升级' : cmp === 0 ? '同版本' : '降级'))
for (const w of warns) console.log('  ⚠️ ' + w)

if (cmp <= 0) {
  console.error('[upgrade-guard] E_DOWNGRADE_REFUSED：目标版本不高于现行版本，拒绝执行（防止再次发生降级事故）')
  audit('refused', { zip, target, reason: 'downgrade-or-equal' })
  process.exit(4)
}
if (warns.length) { console.error('[upgrade-guard] E_PACKAGE_UNSAFE：包校验未通过，拒绝执行'); audit('refused', { zip, target, reason: warns.join(';') }); process.exit(5) }

if (!has('--apply')) {
  console.log('[upgrade-guard] dry-run 通过。加 --apply 才会真正应用（并先做 last-known-good 备份）。')
  audit('dry-run-ok', { zip, target })
  process.exit(0)
}
console.log('[upgrade-guard] 应用流程：① 停止应用 ② --backup ③ 解压覆盖 ④ check-imports ⑤ 全量测试 ⑥ 启动冒烟')
console.log('[upgrade-guard] 说明：解压覆盖由人工/脚本执行；本工具只负责版本校验、备份与审计。')
audit('apply-approved', { zip, target })

function copyFileSyncSafe(src, dst) {
  const st = statSync(src)
  if (st.isDirectory()) {
    mkdirSync(dst, { recursive: true })
    for (const e of readdirSync(src)) copyFileSyncSafe(join(src, e), join(dst, e))
  } else copyFileSync(src, dst)
}