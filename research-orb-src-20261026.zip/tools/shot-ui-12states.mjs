// tools/shot-ui-12states.mjs —— S48 基线重拍（每态两张：空态 / 有数据）
// S65·P1 T7 扩：新增 13–18 六态（感知卡有数据 / 番茄钟卡 / 首启引导 / 推荐收听 / T9 清理提示 / 多会话抽屉）。
//
// 单行复跑：node tools\shot-ui-12states.mjs   （T9 态需要 node ≥23 的 node:sqlite；不满足会明确告警并跳过）
// 产物：data\shots\ui-12states\state-<n>-<name>[-b].png；旧图整体移入 old\<时间戳>\
//
// 隔离：ORB_DATA_DIR 指临时目录（不污染真实库）；但**截图基线写真实 data\shots\**
// —— 这是任务书显式授权的写入，属于"基线资产"不是业务数据。
//
// 两趟实例（同一脚本内串行）：
//   · main 趟：空库 + 中途注入样本（感知审计/会话文件）→ 1–16、18 态；
//   · t9   趟：预置含回声的 sqlite（启动时才检测）→ 只拍 17 态（提示条未确认 / 已点一次待确认）。

import { existsSync, mkdirSync, readdirSync, renameSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import { spawn, spawnSync } from 'node:child_process'
import {mkMark, orbUdata, killMarked, countMarked, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('shot-ui-12states')

const ELECTRON = ORB_ELECTRON
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const OUT = join(PROJECT_ROOT, 'data', 'shots', 'ui-12states')
const PORT = 9336
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

// S74c·P0-1：这里原先用 OWN_MATCH 宽匹配（app 路径通配 -or '*apps*desktop*main.mjs*'）杀进程，
// **实测会把用户正在跑的实例一起杀掉**。现在改为按 `--user-data-dir=<唯一 MARK>` 精确回收：
//   · killOwn   只杀**本脚本自己起的**进程树（不会波及用户实例）
//   · countProcs 只数**本脚本的**进程（收尾自检用）
// 注：S65 曾担心"只按 app 路径通配会漏掉相对路径启动的实例"——现在靠 --user-data-dir 唯一标识，
// 只要是自己起的就一定带该标识，不会再漏，也不会再误伤。
const killOwn = () => killMarked(MARK)
const countProcs = () => countMarked(MARK)

async function findTarget(timeoutMs = 40000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await res.json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(String(t.url || '')))
      if (page) return page
    } catch { /* 等 */ }
    await sleep(350)
  }
  return null
}
function cdpConnect(wsUrl) {
  const ws = new WebSocket(wsUrl)
  let seq = 0
  const pending = new Map()
  const ready = new Promise((res, rej) => {
    ws.addEventListener('open', () => res())
    ws.addEventListener('error', () => rej(new Error('ws error')))
  })
  ws.addEventListener('message', (ev) => {
    let m = null
    try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
    if (!m || !m.id) return
    const p = pending.get(m.id)
    if (!p) return
    pending.delete(m.id)
    if (m.error) p.rej(new Error(JSON.stringify(m.error)))
    else p.res(m.result)
  })
  // S65：每条 CDP 命令带 12s 超时 —— 渲染层偶发不回包时**报错而不是无限等**
  // （实测：某次整趟卡死 10 分钟没有任何输出，就是因为这里没有超时）。
  const send = (method, params) => new Promise((res, rej) => {
    const id = ++seq
    pending.set(id, { res, rej })
    ws.send(JSON.stringify({ id, method, params }))
    setTimeout(() => { if (pending.has(id)) { pending.delete(id); rej(new Error('CDP 响应超时：' + method)) } }, 12000)
  })
  return { ready, send, close: () => { try { ws.close() } catch { /* noop */ } } }
}
async function evaluate(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r && r.exceptionDetails) throw new Error('evaluate: ' + JSON.stringify(r.exceptionDetails).slice(0, 200))
  return r && r.result ? r.result.value : undefined
}

// ── 18 态：每项两个变体（a=空态/默认，b=有数据/展开）────────────────────────
// 1–12 沿用 S48 编号与语义（基线可对比）；13–18 为 S65·P1 新增态。
// act 可以是字符串或字符串数组（数组按序执行，每步之间小睡）。
const SCROLL_POMO = "(() => { const c = document.getElementById('ro-pomodoro-card'); if (c) c.scrollIntoView({ block: 'center' }); return c ? 'ok' : 'nf' })()"
const SCROLL_PERCEP = "(() => { const r = document.querySelector('.ro-percep-row'); if (r) r.scrollIntoView({ block: 'center' }); return r ? 'ok' : 'nf' })()"
const SCROLL_PENDING = "(() => { const c = document.querySelector('#s5-home .s5-pending'); if (c) c.scrollIntoView({ block: 'center' }); return c ? 'ok' : 'nf' })()"
const STATES = [
  // 1 首页：a=空库（待处理卡"今天没有待办"空态）；b=有计划+日报（S66·P0-1：到期行+完成按钮+今日建议）
  {
    n: 1, name: 'home',
    actA: "window.__s5.page('home')",
    actB: [
      "globalThis.researchOrb.send('ui', { type: 'plugin:command', name: 'panel', args: 'status' })",
      "window.__s5.page('home')",
      SCROLL_PENDING,
    ],
    beforeB: seedPlansAndReport,
    sleepB: 2200,
  },
  { n: 2, name: 'chat', act: "window.__s5.page('chat')" },
  { n: 3, name: 'trajectory', act: "window.__s5.page('trajectory')" },
  { n: 4, name: 'notes', act: "window.__s5.page('notes')" },
  { n: 5, name: 'publish-list', act: "window.__s5.page('publish')" },
  { n: 6, name: 'publish-detail', act: "window.__s5.page('publish')" },
  { n: 7, name: 'settings', act: "window.__s5.page('settings')" },
  { n: 8, name: 'diagnostics', act: "window.__s5.page('settings'); document.getElementById('ro-ds-diag').open = true" },
  { n: 9, name: 'settings-actions', act: "window.__s5.page('settings'); setTimeout(() => { const p = document.getElementById('s5-settings'); if (p) p.scrollTop = p.scrollHeight }, 350)" },
  { n: 10, name: 'voice-card', act: "window.__s5.page('home'); window.__s5.setState('needs-confirm')" },
  { n: 11, name: 'learning', act: "window.__s5.page('home'); window.__s5.setState('monitoring')" },
  { n: 12, name: 'ball', act: "window.__s5.page('home')" },
  // 13 感知卡：a=空（七行全 —）；b=有数据（注入今日审计 → 采样/送模/省 MB 全部有数）
  {
    n: 13, name: 'perception-card',
    actA: ["window.__s5.page('home')", SCROLL_PERCEP],
    actB: [
      "globalThis.researchOrb.send('ui', { type: 'plugin:command', name: 'panel', args: 'status' })",
      "window.__s5.page('home')",
      SCROLL_PERCEP,
    ],
    beforeB: seedPerceptionAudit, // node 侧注入（感知卡读 perception.jsonl，是运行时读 → 中途注入即可）
    sleepB: 2200,
  },
  // 14 番茄钟卡：a=待机；b=运行中（点「开始」）
  {
    n: 14, name: 'pomodoro',
    actA: ["window.__s5.page('home')", SCROLL_POMO],
    actB: ["window.__s5.page('home')",
      "(() => { const c = document.getElementById('ro-pomodoro-card'); const b = [...c.querySelectorAll('button')].find((x) => /开始/.test(x.textContent || '')); if (b) b.click(); return b ? 'started' : 'nf' })()",
      SCROLL_POMO],
    sleepB: 1600,
  },
  // 15 首启引导：a=第 1 步；b=第 2 步（点「下一步」）。拍完统一点「跳过」还原（不动真实配置的语义）
  {
    n: 15, name: 'onboard',
    actA: [
      "window.__s5.page('settings')",
      "(() => { const b = [...document.querySelectorAll('#panel button')].find((x) => /重看新手引导/.test(x.textContent || '')); if (b) { b.click(); return 'clicked' } return 'nf' })()",
      "window.__s5.page('home')",
    ],
    actB: ["(() => { const c = document.getElementById('ro-onboard-card'); const b = [...c.querySelectorAll('button')].find((x) => /下一步/.test(x.textContent || '')); if (b) b.click(); return b ? 'next' : 'nf' })()"],
    sleepA: 1200,
  },
  // 16 推荐收听（设置页底部操作簇）：a=按钮可见；b=同区 + 诊断展开
  {
    n: 16, name: 'listen',
    actA: ["window.__s5.page('settings')",
      "(() => { const b = [...document.querySelectorAll('#panel button')].find((x) => /推荐收听/.test(x.textContent || '')); if (b) b.scrollIntoView({ block: 'center' }); return b ? 'ok' : 'nf' })()"],
    actB: ["window.__s5.page('settings')",
      "(() => { const b = [...document.querySelectorAll('#panel button')].find((x) => /推荐收听/.test(x.textContent || '')); if (b) b.scrollIntoView({ block: 'center' }); return b ? 'ok' : 'nf' })()"],
    sleepA: 900,
    sleepB: 900,
  },
  // 17 T9 清理提示（首页顶部）：a=待处理提示；b=点一次后的待确认文案（**不再点第二次**，第二次会关应用）
  {
    n: 17, name: 't9-cleanup', pass: 't9',
    actA: "window.__s5.page('home')",
    actB: "(() => { const b = document.getElementById('ro-t9-bar'); if (b) { b.click(); return 'armed' } return 'nf' })()",
    // S65：先验证提示条真的可见（S65 修的接线缺陷回归哨兵：不可见就明确报 FAIL，不静默出假基线）
    afterA: async (cdp) => {
      const v = await evaluate(cdp, "(() => { const c = document.getElementById('ro-t9-bar'); return c ? c.style.display + '|' + c.textContent.slice(0, 44) : 'nf' })()")
      const ok = typeof v === 'string' && v !== 'nf' && !/^none/.test(v) && v.includes('历史回声')
      console.log(`  [check] 17a T9 提示条可见性：${v} → ${ok ? 'PASS' : 'FAIL ← t9:pending 没到达渲染层'}`)
    },
  },
  // 18 多会话抽屉：a=收起（默认）；b=展开且有会话（预置会话文件 + multiSession.enabled）
  {
    n: 18, name: 'sessions-drawer',
    actA: "window.__s5.page('home')",
    actB: ["(() => { const b = document.getElementById('history'); if (b) { b.click(); return 'opened' } return 'nf' })()"],
    beforeA: seedSessions, // 抽屉收起时先备好会话文件 → b 变体点开就有列表
    sleepB: 1600,
  },
]

// ── 样本注入（只写隔离库；不碰真实 data）──────────────────────────────────
/** 感知审计样本：让感知卡七行都有数（含"省 X MB"）。 */
function seedPerceptionAudit(dataDir) {
  const now = Date.now()
  const rows = [
    { ts: now - 5400000, kind: 'frame-registered', frameId: 'fr-sample-1', window: '预置样本' },
    { ts: now - 5300000, kind: 'shot-saved', bytes: 1697375 },
    { ts: now - 5200000, kind: 'frame-registered', frameId: 'fr-sample-2', window: '预置样本' },
    { ts: now - 5100000, kind: 'skipped-sensitive', why: 'sensitive-window-heuristic', matched: '银行' },
    { ts: now - 5000000, kind: 'sent-to-model', frameId: 'fr-sample-1', bytesBefore: 1697375, bytesAfter: 38051 },
    { ts: now - 3600000, kind: 'frame-registered', frameId: 'fr-sample-3', window: '预置样本' },
    { ts: now - 3500000, kind: 'shot-saved', bytes: 1712004 },
    { ts: now - 3400000, kind: 'sent-to-model', frameId: 'fr-sample-3', bytesBefore: 1712004, bytesAfter: 41220 },
    { ts: now - 1800000, kind: 'frame-registered', frameId: 'fr-sample-4', window: '预置样本' },
  ]
  const p = join(dataDir, 'logs', 'perception.jsonl')
  mkdirSync(join(dataDir, 'logs'), { recursive: true })
  writeFileSync(p, rows.map((r) => JSON.stringify(r)).join('\n') + '\n', 'utf8')
  console.log('  [seed] perception.jsonl 已注入（今日样本 9 行：4 采样 / 2 送模 / 1 拒采）')
}
/**
 * S66·P0-1：待处理卡"有数据"变体样本 —— 计划账 1 条到期 + 1 条未到期 + 今日日报文件。
 * 路径口径：DATA_DIR = ORB_DATA_DIR 本身 → coach 目录在 <dataDir>/coach/。
 */
function seedPlansAndReport(dataDir) {
  const now = Date.now()
  const dueIso = new Date(now - 35 * 60 * 1000).toISOString()
  const nextIso = new Date(now + 3 * 3600 * 1000).toISOString()
  const rows = [
    { ts: dueIso, id: 'pl-shot-due-1', text: '整理微电网 MPC 两阶段调度笔记', dueAt: dueIso, status: 'pending', createdAt: dueIso, event: 'add', source: 'shot-sample' },
    { ts: nextIso, id: 'pl-shot-next-1', text: '预习分布式优化下一章', dueAt: nextIso, status: 'pending', createdAt: nextIso, event: 'add', source: 'shot-sample' },
  ]
  const coachDir = join(dataDir, 'coach')
  mkdirSync(coachDir, { recursive: true })
  writeFileSync(join(coachDir, 'plans.jsonl'), rows.map((r) => JSON.stringify(r)).join('\n') + '\n', 'utf8')
  // 今日日报（口径与 daily.mjs 输出一致：评分行 / 当日累计行 / 「## 明日建议」段）
  const d = new Date()
  const p2 = (n) => String(n).padStart(2, '0')
  const day = `${d.getFullYear()}${p2(d.getMonth() + 1)}${p2(d.getDate())}`
  const report = [
    '# 教练日报 ' + day,
    '',
    '- 评分：82 / 100（score-plan · 旗舰 LLM）',
    '- 轨迹：当日累计 4 条（本轮新增 3 条；全部可回指 trajectory.jsonl）',
    '- 蓝图联动：建议经人确认后可 /coach blueprint edit 更新',
    '',
    '## 明日建议',
    '',
    '1. 把 MPC 两阶段调度的约束推导整理成一张对比表。',
    '2. 用 25 分钟番茄钟专攻分布式优化第二章习题 2.3。',
    '',
  ].join('\n')
  const dailyDir = join(coachDir, 'daily')
  mkdirSync(dailyDir, { recursive: true })
  writeFileSync(join(dailyDir, `daily-${day}.md`), report, 'utf8')
  console.log('  [seed] plans.jsonl（1 到期 + 1 未到期）+ 今日日报（评分 82，建议 2 条）已注入（隔离库）')
}
/** 会话样本 + 多会话开关（抽屉要有列表）。 */
function seedSessions(dataDir) {
  const dir = join(dataDir, 'sessions')
  mkdirSync(dir, { recursive: true })
  const mk = (id, title, q) => [
    JSON.stringify({ type: 'session', id, createdAt: new Date(Date.now() - 3600000).toISOString(), title, provider: 'school-gateway', model: 'deepseek-chat' }),
    JSON.stringify({ type: 'user', ts: new Date(Date.now() - 3599000).toISOString(), text: q }),
    JSON.stringify({ type: 'assistant', ts: new Date(Date.now() - 3590000).toISOString(), text: '（预置样本：仅用于版面，不代表真实会话内容）' }),
  ].join('\n') + '\n'
  writeFileSync(join(dir, 's-sample-0001.jsonl'), mk('s-sample-0001', '预置样本：微电网调度检索', '预置样本问题一'), 'utf8')
  writeFileSync(join(dir, 's-sample-0002.jsonl'), mk('s-sample-0002', '预置样本：日报口径核对', '预置样本问题二'), 'utf8')
  console.log('  [seed] sessions 已注入（2 个预置会话，标题标注"预置样本"）')
}
/** T9 趟：预置含回声的 sqlite（启动时才扫描，必须启动前写好）。 */
async function seedT9Echo(dataDir) {
  const dbDir = join(dataDir, 'db')
  mkdirSync(dbDir, { recursive: true })
  const dbPath = join(dbDir, 'orb.sqlite')
  let DatabaseSync = null
  try {
    const mod = await import('node:sqlite')
    DatabaseSync = mod.DatabaseSync
  } catch (e) {
    console.error('  [seed] ✗ 本 Node 无 node:sqlite（需 ≥23）→ T9 提示态无法复现，跳过 17 态：' + String((e && e.message) || e))
    return false
  }
  const db = new DatabaseSync(dbPath)
  // 表名刻意与生命周期库的既有表错开（避免与迁移打架）；scanSessionEcho 扫全表，认得出来。
  db.exec('CREATE TABLE IF NOT EXISTS demo_echo_sample (id TEXT, text TEXT)')
  const ins = db.prepare('INSERT INTO demo_echo_sample (id, text) VALUES (?, ?)')
  ins.run('t1', '轨迹（20261025）：今天还没有片段。')
  ins.run('t2', '轨迹（20261025）：今天还没有片段。')
  ins.run('t3', '这是一条正常记录，不该被清理。')
  db.close()
  console.log('  [seed] orb.sqlite 已预置 2 条回声（T9 提示条才会在启动时出现）')
  return true
}

const tmpRoot = join(tmpdir(), 'orb-s48-shots-' + Date.now())
mkdirSync(tmpRoot, { recursive: true })
let saved = 0

function archiveOld() {
  if (!existsSync(OUT)) return
  const olds = readdirSync(OUT).filter((f) => /^state-.*\.png$/.test(f))
  if (olds.length === 0) return
  const stamp = new Date().toISOString().replace(/[:.]/g, '-')
  const oldDir = join(OUT, 'old', stamp)
  mkdirSync(oldDir, { recursive: true })
  for (const f of olds) {
    try { renameSync(join(OUT, f), join(oldDir, f)) } catch { /* 单个失败不阻塞 */ }
  }
  console.log(`[shots] 旧图 ${olds.length} 张 → old/${stamp}/`)
}

async function runPass(passName, states, seedFn) {
  const dataDir = join(tmpRoot, passName + '-data')
  mkdirSync(dataDir, { recursive: true })
  if (typeof seedFn === 'function') {
    const ok = await seedFn(dataDir)
    if (ok === false) return
  }
  let child = null
  let cdp = null
  try {
    const env = { ...process.env }
    delete env.ELECTRON_RUN_AS_NODE
    delete env.ORB_LOG_DIR
    env.ORB_DATA_DIR = dataDir
    child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], { cwd: PROJECT_ROOT, env, stdio: 'ignore' })
    const target = await findTarget()
    if (!target) throw new Error('CDP 未就绪')
    cdp = cdpConnect(target.webSocketDebuggerUrl)
    await Promise.race([cdp.ready, sleep(15000).then(() => { throw new Error('CDP WebSocket 15s 未连接') })])
    await cdp.send('Runtime.enable')
    await cdp.send('Page.enable')
    console.log(`  [pass ${passName}] CDP 已连上`)

    let bridge = false
    const deadline = Date.now() + 30000
    while (Date.now() < deadline) {
      try {
        bridge = await evaluate(cdp, 'typeof globalThis.__s5 === "object" && !!globalThis.__s5')
        if (bridge) break
      } catch { /* 等 */ }
      await sleep(400)
    }
    if (!bridge) throw new Error('__s5 未就绪（30s）')
    await evaluate(cdp, 'globalThis.researchOrb.send("window", { action: "expand" })')
    // S53 教训：固定 sleep 1500 冷启动会采到面板隐藏态 → 轮询等 panel 高度 > 100
    {
      const dl = Date.now() + 15000
      let up = false
      while (Date.now() < dl) {
        try {
          const h = await evaluate(cdp, '(() => { const p = document.getElementById("panel"); return p ? Math.round(p.getBoundingClientRect().height) : 0 })()')
          if (h > 100) { up = true; break }
        } catch { /* 等 */ }
        await sleep(300)
      }
      if (!up) console.error('[shots] 警告：15s 内面板未展开，截图可能采到隐藏态')
    }
    // 首启引导卡会盖住首页顶部（T9 条/感知卡）—— 拍照前跳过，保证基线稳定
    await evaluate(cdp, "(() => { const c = document.getElementById('ro-onboard-card'); if (c && getComputedStyle(c).display !== 'none') { const b = [...c.querySelectorAll('button')].find((x) => /跳过/.test(x.textContent || '')); if (b) b.click() } return 1 })()")
    await sleep(400)

    for (const st of states) {
      // 变体 a：空态/默认
      await evaluate(cdp, "document.getElementById('ro-ds-diag') && (document.getElementById('ro-ds-diag').open = false)")
      if (typeof st.beforeA === 'function') await st.beforeA(dataDir) // 注入必须在触发动作**之前**（点了再注入就来不及了）
      const actsA = Array.isArray(st.actA || st.act) ? st.actA || st.act : [st.actA || st.act]
      for (const a of actsA) await evaluate(cdp, a)
      await sleep(st.sleepA || 700)
      const shotA = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
      writeFileSync(join(OUT, `state-${st.n}-${st.name}.png`), Buffer.from(shotA.data, 'base64'))
      saved += 1
      if (typeof st.afterA === 'function') await st.afterA(cdp)

      // 变体 b：有数据/展开（诊断打开 + 有内容的状态）
      if (typeof st.beforeB === 'function') await st.beforeB(dataDir)
      const actsB = Array.isArray(st.actB || st.act) ? st.actB || st.act : [st.actB || st.act]
      for (const a of actsB) await evaluate(cdp, a)
      // 注意：Runtime.evaluate 是**全局作用域**，连续 `const d=` 会 "already declared"；一律用 IIFE 把变量关进去。
      await evaluate(cdp, "(() => { const d = document.getElementById('ro-ds-diag'); if (d) d.open = true })()")
      await sleep(st.sleepB || 600)
      const shotB = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
      writeFileSync(join(OUT, `state-${st.n}-${st.name}-b.png`), Buffer.from(shotB.data, 'base64'))
      saved += 1
      console.log(`  [shot] ${st.n}/18 ${st.name} (a+b)`)
    }

    // 收尾：引导卡若还开着就跳过（还原"已看过"），再拍球（收起态）
    await evaluate(cdp, "(() => { const c = document.getElementById('ro-onboard-card'); if (c && getComputedStyle(c).display !== 'none') { const b = [...c.querySelectorAll('button')].find((x) => /跳过/.test(x.textContent || '')); if (b) b.click() } return 1 })()")
    await sleep(300)
    if (passName === 'main') {
      await evaluate(cdp, 'globalThis.researchOrb.send("window", { action: "collapse" })')
      await sleep(1200)
      const ballShot = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
      writeFileSync(join(OUT, 'state-ball-collapsed.png'), Buffer.from(ballShot.data, 'base64'))
      saved += 1
      console.log('  [shot] ball-collapsed')
    }
  } catch (e) {
    console.error(`[shots] ${passName} 趟失败：` + String((e && e.message) || e))
  } finally {
    try { if (cdp) cdp.close() } catch { /* noop */ }
    killOwn()
    await sleep(1500)
  }
}

try {
  if (countProcs() > 0) {
    console.error('[shots] 已有 research-orb 在跑，先关闭再复跑（fail-closed）')
    process.exit(2)
  }
  archiveOld()
  mkdirSync(OUT, { recursive: true })
  const seedMain = (dataDir) => {
    // 多会话抽屉要 config 开关（启动时读一次 → 必须启动前写）
    mkdirSync(dataDir, { recursive: true })
    writeFileSync(join(dataDir, 'config.json'), JSON.stringify({ multiSession: { enabled: true } }, null, 2), 'utf8')
    console.log('  [seed] config.json：multiSession.enabled=true（隔离库）')
  }
  await runPass('main', STATES.filter((s) => (s.pass || 'main') === 'main'), seedMain)
  await runPass('t9', STATES.filter((s) => s.pass === 't9'), seedT9Echo)
} finally {
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}

console.log(`[shots] 完成：${saved} 张 -> data\\shots\\ui-12states\\`)
process.exitCode = saved >= 12 ? 0 : 1
