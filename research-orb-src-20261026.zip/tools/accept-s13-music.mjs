// tools/accept-s13-music.mjs
//
// S13.1「音乐律动光环」真应用验收（返修版）：真 electron + CDP（与 accept-ui-matrix 同口径）。
//
// 覆盖返修单 A–E：
//   A 静音心跳：静音 ≥2Hz 发 {level:0,peak:0,silent:true}；有声按 levelHz(30Hz)。
//   B 真停：关闭开关后 t+1.5s / t+5.5s 自有采集进程均 0；结束 0。
//   C 审计：关网播放尝试 → kind=network-disabled（含 host）；清单不可达 → kind=stations-unreachable。
//   D 自造声：data\tmp 生成 440Hz 正弦 WAV（纯 Node 写 RIFF+PCM）→ Media.SoundPlayer 播 2 秒
//     → 再断言 peak>0 / frames>0（不依赖环境音是否可听）。
//   E 残留判定：用 listOwnPowershell + level-start 审计 pid，不做命令行正则（查询进程
//     自匹配会造成假残留），并打印残留 PID 便于取证。
// 证据 JSON 统一 {id, ok, detail}，共 16 项。
//
// 纪律：fail-closed（已有 research-orb electron 在跑则退出）；只杀自己起的进程；
// 几何契约断言不变；结束恢复 network off（默认不联网红线）。

import { spawn, spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { inflateSync } from 'node:zlib'
import { join } from 'node:path'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { listOwnPowershell } from '../packages/plugins/music/level-collector.mjs'
import { writeMusicConfig } from '../apps/desktop/music-driver.mjs'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-s13-music')

const ELECTRON_EXE = ORB_ELECTRON
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const SHOTS = join(PROJECT_ROOT, 'data', 'shots', 's13-music')
const TMP_DIR = join(PROJECT_ROOT, 'data', 'tmp')
const WAV_PATH = join(TMP_DIR, 's13-440hz.wav')
const MUSIC_LOG_PATH = join(PROJECT_ROOT, 'data', 'logs', 'music.jsonl')
const APP_LOG = join(PROJECT_ROOT, 'data', 'logs', 'app.jsonl')
const OUT = join(PROJECT_ROOT, 'data', 'logs', 's13-music-accept.json')
const PORT = 9350

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const results = []
const t0 = Date.now()
const step = (s) => console.log(`[${((Date.now() - t0) / 1000).toFixed(1)}s] ${s}`)
/** 任何 CDP 调用都不得无限挂起：超时即抛（让脚本能收尾并如实报失败）。 */
function withTimeout(p, ms, label) {
  return Promise.race([
    p,
    new Promise((_, rej) => setTimeout(() => rej(new Error('CDP 超时: ' + label + ' (' + ms + 'ms)')), ms)),
  ])
}
/** 证据行统一 {id, ok, detail}（主管按这三个键解析）。 */
const check = (cond, id, detail = '') => {
  const ok = !!cond
  results.push({ id, ok, detail: String(detail) })
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${id}  ${detail}`)
  return ok
}
const log = (s) => console.log(s)

// ---------------------------------------------------------------------------
// PNG 解码 + SSIM（与 accept-ui-matrix 同口径，无依赖）
// ---------------------------------------------------------------------------
function decodePng(buf) {
  let off = 8
  let width = 0, height = 0, bitDepth = 8, colorType = 6
  const idat = []
  while (off < buf.length) {
    const len = buf.readUInt32BE(off)
    const type = buf.toString('ascii', off + 4, off + 8)
    const data = buf.subarray(off + 8, off + 8 + len)
    if (type === 'IHDR') {
      width = data.readUInt32BE(0); height = data.readUInt32BE(4)
      bitDepth = data[8]; colorType = data[9]
    } else if (type === 'IDAT') idat.push(data)
    off += 12 + len
  }
  if (bitDepth !== 8 || (colorType !== 6 && colorType !== 2)) throw new Error('unsupported png')
  const channels = colorType === 6 ? 4 : 3
  const raw = inflateSync(Buffer.concat(idat))
  const stride = width * channels
  const out = Buffer.alloc(width * height * channels)
  let pos = 0
  for (let y = 0; y < height; y++) {
    const filter = raw[pos]; pos += 1
    const row = raw.subarray(pos, pos + stride); pos += stride
    const cur = out.subarray(y * stride, (y + 1) * stride)
    const prev = y > 0 ? out.subarray((y - 1) * stride, (y - 1) * stride + stride) : null
    for (let x = 0; x < stride; x++) {
      const a = x >= channels ? cur[x - channels] : 0
      const b = prev ? prev[x] : 0
      const c = (prev && x >= channels) ? prev[x - channels] : 0
      let v = row[x]
      if (filter === 1) v += a
      else if (filter === 2) v += b
      else if (filter === 3) v += (a + b) >> 1
      else if (filter === 4) {
        const p = a + b - c
        const pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c)
        v += (pa <= pb && pa <= pc) ? a : (pb <= pc ? b : c)
      }
      cur[x] = v & 255
    }
  }
  return { width, height, channels, data: out }
}

function grayLuma(img) {
  const g = new Float64Array(img.width * img.height)
  for (let i = 0; i < g.length; i++) {
    const o = i * img.channels
    g[i] = 0.299 * img.data[o] + 0.587 * img.data[o + 1] + 0.114 * img.data[o + 2]
  }
  return g
}

function ssim(a, b) {
  if (a.width !== b.width || a.height !== b.height) return -1
  const ga = grayLuma(a), gb = grayLuma(b)
  const W = 8, C1 = (0.01 * 255) ** 2, C2 = (0.03 * 255) ** 2
  let total = 0, n = 0
  for (let y = 0; y + W <= a.height; y += W) {
    for (let x = 0; x + W <= a.width; x += W) {
      let sa = 0, sb = 0, saa = 0, sbb = 0, sab = 0
      for (let dy = 0; dy < W; dy++) for (let dx = 0; dx < W; dx++) {
        const i = (y + dy) * a.width + (x + dx)
        const va = ga[i], vb = gb[i]
        sa += va; sb += vb; saa += va * va; sbb += vb * vb; sab += va * vb
      }
      const N = W * W
      const ma = sa / N, mb = sb / N
      const cov = sab / N - ma * mb
      total += ((2 * ma * mb + C1) * (2 * cov + C2)) / ((ma * ma + mb * mb + C1) * (saa / N - ma * ma + sbb / N - mb * mb + C2))
      n += 1
    }
  }
  return n > 0 ? total / n : -1
}

// ---------------------------------------------------------------------------
// D：纯 Node 生成 440Hz 正弦 WAV（RIFF + PCM 16bit mono），零依赖
// ---------------------------------------------------------------------------
function writeWav440(path, seconds = 2, rate = 44100) {
  const n = Math.floor(rate * seconds)
  const dataBytes = n * 2
  const buf = Buffer.alloc(44 + dataBytes)
  buf.write('RIFF', 0); buf.writeUInt32LE(36 + dataBytes, 4); buf.write('WAVE', 8)
  buf.write('fmt ', 12); buf.writeUInt32LE(16, 16)
  buf.writeUInt16LE(1, 20)   // PCM
  buf.writeUInt16LE(1, 22)   // mono
  buf.writeUInt32LE(rate, 24); buf.writeUInt32LE(rate * 2, 28)
  buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34)
  buf.write('data', 36); buf.writeUInt32LE(dataBytes, 40)
  for (let i = 0; i < n; i++) {
    const v = Math.sin((2 * Math.PI * 440 * i) / rate) * 0.6
    buf.writeInt16LE(Math.round(v * 32767), 44 + i * 2)
  }
  writeFileSync(path, buf)
  return buf.length
}

// ---------------------------------------------------------------------------
// 审计读取：按 ts 过滤本运行产生的行（music.jsonl 跨运行 append-only）
// ---------------------------------------------------------------------------
function readAuditRows(sinceIso) {
  if (!existsSync(MUSIC_LOG_PATH)) return []
  return readFileSync(MUSIC_LOG_PATH, 'utf8').split('\n').filter(Boolean).map((l) => {
    try { return JSON.parse(l) } catch { return null }
  }).filter(Boolean).filter((r) => !sinceIso || !(typeof r.ts === 'string') || r.ts >= sinceIso)
}

/** 本运行 level-start 审计记录的采集器 pid（E：残留判定只认自己的 pid，不做命令行正则）。 */
function ownCollectorPids(sinceIso) {
  const pids = []
  for (const r of readAuditRows(sinceIso)) {
    if (r && r.kind === 'level-start' && Number.isFinite(r.pid) && !pids.includes(r.pid)) pids.push(r.pid)
  }
  return pids
}

const isAlivePid = (pid) => {
  try { process.kill(pid, 0); return true } catch { return false }
}

// ---------------------------------------------------------------------------
// CDP
// ---------------------------------------------------------------------------
let cdp = null
const openSockets = []
function trackWs(ws) { openSockets.push(ws); return ws }
function closeSockets() {
  for (const ws of openSockets) { try { ws.close() } catch { /* noop */ } }
  openSockets.length = 0
}
async function findTarget(pattern, timeoutMs = 40000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await res.json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && pattern.test(t.url))
      if (page) return page
    } catch { /* 还没起来 */ }
    await sleep(300)
  }
  return null
}

async function connectTo(target) {
  const ws = trackWs(new WebSocket(target.webSocketDebuggerUrl))
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve)
    ws.addEventListener('error', () => reject(new Error('CDP WebSocket 连接失败')))
  })
  const sess = { id: 0, pending: new Map() }
  ws.addEventListener('message', (ev) => {
    let m
    try { m = JSON.parse(ev.data) } catch { return }
    if (m.id !== undefined && sess.pending.has(m.id)) {
      const p = sess.pending.get(m.id)
      sess.pending.delete(m.id)
      m.error ? p.reject(new Error(m.error.message)) : p.resolve(m.result)
    }
  })
  const api = {
    send: (method, params = {}) => withTimeout(new Promise((resolve, reject) => {
      const id = ++sess.id
      sess.pending.set(id, { resolve, reject })
      ws.send(JSON.stringify({ id, method, params }))
    }), 20000, method),
    evaluate: async (expression) => {
      const r = await withTimeout(api.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true }), 20000, 'Runtime.evaluate')
      if (r && r.exceptionDetails) return { __exception: String(r.exceptionDetails.text || 'eval-threw') }
      return r && r.result ? r.result.value : undefined
    },
  }
  await api.send('Page.enable')
  await api.send('Runtime.enable')
  return api
}

async function shot(api, name) {
  const s = await withTimeout(api.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false }), 20000, 'captureScreenshot')
  if (!s || !s.data) throw new Error('截图失败')
  const abs = join(SHOTS, name)
  writeFileSync(abs, Buffer.from(s.data, 'base64'))
  return abs
}

/** 等 CONTRACT §7：pack-ui-injected 之后才允许交互。
 *  IMPORTANT：app.jsonl 跨运行 append-only，只认 bootOffset（字节）之后写入的标记；
 *  日志含中文，字节偏移 ≠ 字符偏移，必须用原始 Buffer 的 indexOf 按字节搜。 */
async function waitForPackUiInjected(timeoutMs = 120000, bootOffset = 0) {
  const deadline = Date.now() + timeoutMs
  const needle = Buffer.from('pack-ui-injected')
  while (Date.now() < deadline) {
    try {
      if (existsSync(APP_LOG)) {
        const buf = readFileSync(APP_LOG)
        if (buf.length > bootOffset && buf.indexOf(needle, bootOffset) >= 0) return true
      }
    } catch { /* noop */ }
    await sleep(500)
  }
  return false
}

function musicCmd(args) {
  // CONTRACT：plugin:command 必须走 'ui' 通道、payload 为 { type:'plugin:command', name, args }
  // （preload 的 SEND_CHANNELS 只有 ui/window/drag；直接用 'plugin:command' 当通道名会抛错）。
  return cdp.evaluate(`window.researchOrb && window.researchOrb.send('ui', { type: 'plugin:command', name: 'music', args: ${JSON.stringify(args)} })`)
}

async function main() {
  mkdirSync(SHOTS, { recursive: true })
  mkdirSync(TMP_DIR, { recursive: true })

const pre = countOrbAll()
  if (countOrbAll() > 0) throw new Error('已有 research-orb electron 在运行（fail-closed）')

  // 记录 boot 基线：app.jsonl 用字节偏移；music.jsonl 审计按 ts 过滤。
  const bootOffset = existsSync(APP_LOG) ? statSync(APP_LOG).size : 0
  const bootStartIso = new Date(Date.now() - 1000).toISOString()

  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN_MJS], { cwd: PROJECT_ROOT, env: childEnv, stdio: 'ignore' })
  log(`electron pid=${child.pid}`)

  let quietFrames = 0
  let playFrames = 0
  let maxPeak = 0
  let playLevels = []
  try {
    const injected = await waitForPackUiInjected(120000, bootOffset)
    step('pack-ui-injected=' + injected)
    check(injected, 'boot.pack-ui-injected', injected ? 'CONTRACT §7：标记出现在本实例 boot 偏移之后' : '120s 内未出现')
    const target = await findTarget(/floating\.html/i)
    if (!target) throw new Error('未找到面板 CDP 目标')
    cdp = await connectTo(target)
    step('panel CDP connected')
    // settle：pack 注入后渲染进程仍在收尾，先晾 6s 再交互（与 accept-ui-matrix 同口径）。
    await sleep(6000)

    // 电平录制器：经既有 main-event 下行订阅（不新增 IPC）。
    // IMPORTANT：必须 IIFE 包裹 —— 顶层 return 在 Runtime.evaluate 里是 SyntaxError，
    // 整段（含 window.__s13 赋值）都不会执行，表现为 frames=0 / __s13 undefined。
    const rec = await cdp.evaluate(`(() => {
      window.__s13 = { levels: [] }
      if (window.researchOrb && typeof window.researchOrb.on === 'function') {
        window.researchOrb.on(function (m) {
          if (m && m.type === 'music:level' && window.__s13.levels.length < 4000) window.__s13.levels.push(m)
        })
        return 'installed'
      }
      return 'no-researchOrb'
    })()`)
    if (rec !== 'installed') throw new Error('电平录制器安装失败: ' + JSON.stringify(rec))
    step('level recorder installed')

    // 几何前置：收起态（96×96）才能看到球 + 光环
    await cdp.evaluate(`window.researchOrb.send('window', { action: 'collapse' })`)
    await sleep(1200)
    step('collapsed')

    // ---- A：静音心跳（关开关 → 只有驱动器心跳帧，全部 silent:true）----
    // 两次采样取优：主进程事件循环会被环境 CPU 竞争饿 0.7-2.2s（实测 ts 间隔分布），
    // 单次 3s 窗口可能被停顿吃掉大半；契约语义是"静音时按 ≥2Hz 发"，取任一合格窗口。
    await musicCmd('off')
    await sleep(500)
    let quiet = null
    let quietFrames = 0
    let allSilent = false
    let medGap = -1
    for (let attempt = 1; attempt <= 2; attempt++) {
      await cdp.evaluate('window.__s13.levels.length = 0')
      await sleep(3000)
      quiet = await cdp.evaluate('window.__s13.levels.slice()')
      quietFrames = Array.isArray(quiet) ? quiet.length : 0
      allSilent = Array.isArray(quiet) && quiet.length > 0 && quiet.every((m) => m && m.silent === true)
      const gaps = Array.isArray(quiet)
        ? quiet.slice(1).map((m, i) => Number(m && m.ts) - Number(quiet[i] && quiet[i].ts)).filter((g) => g > 0).sort((a, b) => a - b)
        : []
      medGap = gaps.length ? gaps[Math.floor(gaps.length / 2)] : -1
      step(`quiet attempt ${attempt}: frames=${quietFrames} allSilent=${allSilent} gap中位=${medGap}ms`)
      if (quietFrames >= 6 && allSilent) break
    }
    check(quietFrames >= 6 && allSilent, 'A.silent-heartbeat',
      `静音 3s frames=${quietFrames}（要求≥6） allSilent=${allSilent} gap中位=${medGap}ms`)
    const quietShot = await shot(cdp, 's13-quiet.png')
    step('quiet shot done')

    // ---- C：关网播放尝试必须留审计（不得静默）----
    // 先显式关网：config.json 若被环境进程锁住，上轮遗留的 networkEnabled=true 会让
    // play 走不到关网分支（本轮 9/16 的教训）。
    await musicCmd('network off')
    await sleep(600)
    await musicCmd('play s13-accept-no-such-uuid')
    await sleep(800)
    let rows = readAuditRows(bootStartIso)
    const ndRows = rows.filter((r) => r.kind === 'network-disabled')
    check(ndRows.length >= 1 && ndRows.some((r) => r.host), 'C.play-network-disabled',
      `network-disabled 行=${ndRows.length} host=${ndRows[0] ? ndRows[0].host : '(none)'}`)

    // ---- D + A：造声播放（440Hz WAV → SoundPlayer 2s）→ peak>0 / frames≥20 ----
    await musicCmd('on')
    let collectorUp = false
    for (let i = 0; i < 20; i++) {
      if (readAuditRows(bootStartIso).some((r) => r.kind === 'level-start')) { collectorUp = true; break }
      await sleep(500)
    }
    step('collector up=' + collectorUp)
    const wavBytes = writeWav440(WAV_PATH, 2, 44100)
    log(`WAV -> ${WAV_PATH} (${wavBytes} B, 440Hz sine 2s)`)
    await cdp.evaluate('window.__s13.levels.length = 0')
    // 连播两遍（~4s 有声）：对抗主进程事件循环的环境停顿，保证 ≥20 帧可判
    const snd = spawn('powershell', ['-NoProfile', '-NonInteractive', '-Command',
      `$sp = New-Object Media.SoundPlayer '${WAV_PATH}'; $sp.PlaySync(); $sp.PlaySync()`], { stdio: 'ignore', windowsHide: true })
    await sleep(900) // 等 PowerShell 启动 + 声音开始
    const loudShot = await shot(cdp, 's13-loud.png')
    await Promise.race([new Promise((r) => snd.once('exit', r)), sleep(14000)])
    playLevels = await cdp.evaluate('window.__s13.levels.slice()')
    playFrames = Array.isArray(playLevels) ? playLevels.length : 0
    maxPeak = playFrames > 0 ? Math.max(...playLevels.map((m) => Number(m && m.peak) || 0)) : 0
    const anyOn = Array.isArray(playLevels) && playLevels.some((m) => m && m.on === true)
    step(`levels captured: frames=${playFrames} maxPeak=${maxPeak.toFixed(4)} anyOn=${anyOn}`)
    check(playFrames >= 20, 'A.play-frames', `播放窗口 frames=${playFrames}（要求≥20，30Hz 采集）`)
    check(maxPeak > 0, 'A.play-peak', `maxPeak=${maxPeak.toFixed(4)}（440Hz WAV 造声，要求>0）`)
    try {
      const s = ssim(decodePng(readFileSync(quietShot)), decodePng(readFileSync(loudShot)))
      check(s >= 0 && s < 0.999, 'A.halo-visual', `静音 vs 播放 SSIM=${s.toFixed(5)}（光环随电平变化）`)
    } catch (err) {
      check(false, 'A.halo-visual', String((err && err.message) || err))
    }

    // ---- C：清单（可达 → ok 审计；不可达 → stations-unreachable 审计）----
    await musicCmd('network on')
    await sleep(500)
    await musicCmd('stations')
    let stationsOkRow = null
    let stationsUnreachable = false
    for (let i = 0; i < 40; i++) {
      rows = readAuditRows(bootStartIso)
      const oks = rows.filter((r) => r.kind === 'stations' && r.result === 'ok')
      if (oks.length > 0) { stationsOkRow = oks[oks.length - 1]; break }
      if (rows.some((r) => r.kind === 'stations-unreachable')) { stationsUnreachable = true; break }
      await sleep(1000)
    }
    check(!!stationsOkRow || stationsUnreachable, 'C.stations',
      stationsOkRow ? `清单可达 stations=${stationsOkRow.count}` : (stationsUnreachable ? '清单不可达 → stations-unreachable 审计在（优雅降级）' : '40s 内无终态审计行'))

    // ---- B：关闭开关真停（自有 pid 判定，非命令行正则）----
    await musicCmd('off')
    await sleep(1500)
    // 清零录制器：只统计关闭之后的帧（否则累计的播放期 on=true 帧会误报）
    await cdp.evaluate('window.__s13.levels.length = 0')
    const pids = ownCollectorPids(bootStartIso)
    const r1 = listOwnPowershell(pids, isAlivePid)
    check(r1.allExited, 'B.stop-fast', `t+1.5s own-alive=${r1.alive.length} pids=[${pids.join(',')}]`)
    await sleep(4000)
    const r2 = listOwnPowershell(pids, isAlivePid)
    check(r2.allExited, 'B.stop-settled', `t+5.5s own-alive=${r2.alive.length} pids=[${pids.join(',')}]`)
    const offRaw = await cdp.evaluate(`(function(){ try {
        return window.__s13.levels.filter(function(m){return m.on===true}).length
      } catch (e) { return { __gone: String((e && e.message) || e) } } })()`)
    const offLevels = typeof offRaw === 'number' ? offRaw : -1
    check(offLevels === 0, 'A.off-frames',
      typeof offRaw === 'number' ? `关闭后 on=true 帧=${offLevels}（只允许 silent 心跳）` : `读取异常 raw=${JSON.stringify(offRaw)}`)

    // ---- 几何契约（不变）----
    const mainSrc = readFileSync(MAIN_MJS, 'utf8')
    check(/COLLAPSED_SIZE\s*=\s*\{\s*width:\s*96,\s*height:\s*96\s*\}/.test(mainSrc), 'GEO.collapsed-96', 'COLLAPSED_SIZE 96×96 未变')
    check(/EXPANDED_SIZE\s*=\s*\{\s*width:\s*420,\s*height:\s*620\s*\}/.test(mainSrc), 'GEO.expanded-420', 'EXPANDED_SIZE 420×620 未变')
    check(!/\.focus\(\)/.test(mainSrc), 'GEO.no-focus', 'main.mjs 无 .focus() 调用')

    // ---- 冻结态静止 ----
    await cdp.evaluate(`window.__s5 ? window.__s5.freeze() : false`)
    await sleep(900)
    const f1 = await shot(cdp, 's13-frozen-1.png')
    await sleep(1500)
    const f2 = await shot(cdp, 's13-frozen-2.png')
    try {
      const s = ssim(decodePng(readFileSync(f1)), decodePng(readFileSync(f2)))
      check(s >= 0.99, 'FROZEN.static', `冻结两帧 SSIM=${s.toFixed(5)}（动画全停）`)
    } catch (err) {
      check(false, 'FROZEN.static', String((err && err.message) || err))
    }
    await cdp.evaluate(`window.__s5 ? window.__s5.unfreeze() : false`)

    // ---- 电平序列 JSON（30Hz 证据）----
    const seqPath = join(SHOTS, 's13-level-sequence.json')
    writeFileSync(seqPath, JSON.stringify({
      generatedAt: new Date().toISOString(),
      tool: 'accept-s13-music',
      source: 'WASAPI render-endpoint peak via level-collector (30Hz) + driver silent heartbeat (2.5Hz)',
      quietFrames, playFrames, maxPeak,
      frames: playLevels,
    }, null, 2))
    const seqBytes = existsSync(seqPath) ? statSync(seqPath).size : 0
    check(seqBytes > 0, 'EVID.level-sequence', `${seqPath} (${seqBytes} B)`)

    // ---- 收尾残留（E：打印 PID 取证）----
    const pidsF = ownCollectorPids(bootStartIso)
    const rF = listOwnPowershell(pidsF, isAlivePid)
    check(rF.allExited, 'B.residue-final', `结束 own-alive=${rF.alive.length} pids=[${pidsF.join(',')}]`)
  } finally {
    // 恢复默认不联网 + 关播放（红线 1：networkEnabled 默认 false 不得被验收留在 true）
    if (cdp) {
      try { await musicCmd('network off') } catch { /* noop */ }
      try { await musicCmd('off') } catch { /* noop */ }
    }
    closeSockets()
    try { spawnSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore' }) } catch { /* noop */ }
  }

  // 进程收尾后：尽力把磁盘 config 恢复为默认关网态（红线 1）。config.json 被环境
  // 进程锁住时这里会 EPERM——如实留痕，不静默。
  try {
    writeMusicConfig({ enabled: false, networkEnabled: false })
    log('config.json 已恢复默认（enabled=false, networkEnabled=false）')
  } catch (err) {
    log(`WARN config.json 恢复失败（文件被锁）：${(err && err.message) || err}——锁释放后请手动 /music network off 一次`)
  }

  const failed = results.filter((r) => !r.ok).length
  const evidence = {
    tool: 'accept-s13-music',
    generatedAt: new Date().toISOString(),
    total: results.length,
    passed: results.length - failed,
    failed,
    results,
    artifacts: {
      shots: ['s13-quiet.png', 's13-loud.png', 's13-frozen-1.png', 's13-frozen-2.png'],
      levelSequence: 'data/shots/s13-music/s13-level-sequence.json',
      wav: 'data/tmp/s13-440hz.wav',
      auditLog: 'data/logs/music.jsonl',
    },
  }
  writeFileSync(OUT, JSON.stringify(evidence, null, 2))
  log(`\n# accept-s13-music: total=${results.length} pass=${results.length - failed} fail=${failed}`)
  log(`证据 -> ${OUT}`)
  process.exit(failed === 0 ? 0 : 1)
}

main().catch((err) => {
  console.error('ACCEPT FAILED:', err && err.message ? err.message : err)
  closeSockets()
  process.exit(2)
})
