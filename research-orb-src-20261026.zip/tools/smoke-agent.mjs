// tools/smoke-agent.mjs
//
// 阶段 1 开发期冒烟：用假 provider 验证 session 落盘 / agent 编排 / 中断 / 降级，
// 不碰真实网络、不读真实密钥。跑法：node tools\smoke-agent.mjs
//
// 这只证明"编排逻辑正确"，真实连通性由 --selftest 与验收 ① ② 覆盖。

import { existsSync, rmSync } from 'node:fs'

import { createAgent, DegradeController } from '../packages/core/src/agent.mjs'
import * as sessions from '../packages/core/src/session.mjs'
import { EVENT } from '../packages/core/src/providers/index.mjs'

const created = []
const log = (...a) => process.stdout.write(a.join(' ') + '\n')
let failures = 0
function check(name, ok, extra = '') {
  log(`${ok ? 'PASS' : 'FAIL'}  ${name}${extra ? '  ' + extra : ''}`)
  if (!ok) failures += 1
}

/** 记录冒烟开始前 data/sessions 里已有的文件，结束后把新增的一律清掉。 */
function snapshotSessionFiles() {
  try {
    return new Set(fs.readdirSync(sessions.SESSIONS_DIR))
  } catch {
    return new Set()
  }
}

/** 假 provider：可控地流式吐字、可控地失败、可控地拖长以便中断。 */
function makeFakeProvider({ id, models, script }) {
  return {
    id,
    name: id,
    kind: 'fake',
    defaultModel: models[0],
    describe: () => ({ id, name: id, kind: 'fake', defaultModel: models[0], models: [...models] }),
    describeConfig: () => ({ ready: true, models: [...models], baseUrl: 'https://fake.invalid', key: 'sk-f***' }),
    hasModel: (m) => models.includes(m),
    async listModels() {
      return models.map((m) => ({ id: m, name: m }))
    },
    async *chat({ model, signal }) {
      const behavior = script[model] || script.__default
      if (behavior === 'fail') {
        yield { type: EVENT.ERROR, code: 'E_RATE_LIMITED', status: 429, retryable: true, message: `${id}: HTTP 429`, provider: id, model }
        return
      }
      if (behavior === 'slow') {
        for (const ch of ['甲', '乙', '丙', '丁', '戊']) {
          if (signal && signal.aborted) {
            yield { type: EVENT.ERROR, code: 'E_ABORTED', message: '请求已被用户中断', retryable: false, aborted: true, provider: id, model }
            return
          }
          await new Promise((r) => setTimeout(r, 30))
          yield { type: EVENT.DELTA, text: ch, channel: 'content' }
        }
      } else {
        for (const ch of behavior || 'ok') {
          yield { type: EVENT.DELTA, text: ch, channel: 'content' }
        }
      }
      yield { type: EVENT.DONE, text: behavior === 'slow' ? '甲乙丙丁戊' : behavior, provider: id, model, usage: null, finishReason: 'stop' }
    },
  }
}

function makeProviders(list) {
  const map = new Map(list.map((p) => [p.id, p]))
  return {
    list: () => [...map.values()],
    byId: (id) => map.get(id) || null,
    has: (id) => map.has(id),
    net: { queueState: () => ({ waiting: 0, limited: 0, reasonerWindowUsed: 0, reasonerLimitPerMinute: 10, buckets: [] }) },
  }
}

const fs = await import('node:fs')

async function main() {
  const preexisting = snapshotSessionFiles()
  // ---------- 1. session 基本读写 ----------
  const s1 = sessions.createSession({ title: '冒烟会话', provider: 'fake', model: 'deepseek-chat' })
  created.push(s1.path)
  check('session: createSession 返回 id/path', !!s1.id && existsSync(s1.path), s1.id)
  check('session: 文件名符合 s-<stamp>-<hex>', /^s-\d{8}-\d{6}-[0-9a-f]{4}$/.test(s1.id), s1.id)

  sessions.appendUser(s1.id, '你好')
  sessions.appendAssistant(s1.id, { text: '你也好', provider: 'fake', model: 'deepseek-chat' })
  sessions.appendNotice(s1.id, { level: 'warn', code: 'E_DEGRADED', message: '已降级到 deepseek-chat（原因：测试）' })
  const read1 = sessions.readSession(s1.id)
  check('session: 读回 1 组对话 + 1 条 notice', read1.turns.length === 2 && read1.notices.length === 1 && read1.badLines === 0)
  check('session: historyMessages 只含 user/assistant', sessions.historyMessages(s1.id).length === 2)

  // ---------- 2. 越界 id 被拒 ----------
  let rejected = false
  try {
    sessions.sessionPath('../../evil')
  } catch (err) {
    rejected = err.code === 'E_BAD_SESSION_ID'
  }
  check('session: ../ 花招 id 被拒（E_BAD_SESSION_ID）', rejected)

  // ---------- 3. agent 正常一轮 + 落盘 ----------
  const fake = makeFakeProvider({ id: 'fake', models: ['deepseek-chat', 'deepseek-reasoner'], script: { __default: '答案是 42' } })
  const providers = makeProviders([fake])
  const agent = createAgent({ providers, systemPrompt: '你是冒烟助手' })
  const events = []
  const r1 = await agent.runTurn({ message: '问题一', providerId: 'fake', model: 'deepseek-chat', onEvent: (e) => events.push(e) })
  created.push(sessions.sessionPath(r1.sessionId))
  check('agent: 一轮跑通返回文本', r1.text === '答案是 42', JSON.stringify(r1.text))
  check('agent: 事件序列含 start/delta/done', events[0].type === 'start' && events.at(-1).type === 'done' && events.some((e) => e.type === 'delta'))
  check('agent: 未降级', r1.degraded === false && r1.error === null)
  const persisted = sessions.readSession(r1.sessionId)
  check('agent: user+assistant 均已落盘', persisted.turns.length === 2 && persisted.turns[1].text === '答案是 42')
  check('agent: 会话标题从首条消息派生', persisted.meta.title === '问题一', persisted.meta.title)

  // ---------- 4. 多轮：第二轮带上历史 ----------
  const r2 = await agent.runTurn({ sessionId: r1.sessionId, message: '问题二', providerId: 'fake', model: 'deepseek-chat' })
  const persisted2 = sessions.readSession(r1.sessionId)
  check('agent: 同一会话第二轮复用 id', r2.sessionId === r1.sessionId)
  check('agent: 第二轮后有 4 条对话行', persisted2.turns.length === 4, String(persisted2.turns.length))
  check('agent: 历史回放含"问题一"', persisted2.turns[0].text === '问题一' && persisted2.turns[2].text === '问题二')

  // ---------- 5. 中断 ----------
  const slow = makeFakeProvider({ id: 'slow', models: ['deepseek-chat'], script: { __default: 'slow' } })
  const agentSlow = createAgent({ providers: makeProviders([slow]) })
  const ac = new AbortController()
  const evSlow = []
  const p = agentSlow.runTurn({ message: '慢慢答', providerId: 'slow', model: 'deepseek-chat', signal: ac.signal, onEvent: (e) => evSlow.push(e) })
  setTimeout(() => ac.abort(), 80)
  const r3 = await p
  created.push(sessions.sessionPath(r3.sessionId))
  check('agent: 中断后返回 aborted=true', r3.aborted === true)
  check('agent: 中断保留了部分文本', r3.text.length > 0 && r3.text.length < 5, JSON.stringify(r3.text))
  const persisted3 = sessions.readSession(r3.sessionId)
  check('agent: 落盘行带 aborted:true', persisted3.turns[1].aborted === true)
  check('agent: 发出 aborted 事件', evSlow.some((e) => e.type === 'aborted'))

  // ---------- 6. 降级：reasoner 连续失败 3 次后自动改走 chat ----------
  const flaky = makeFakeProvider({
    id: 'flaky',
    models: ['deepseek-chat', 'deepseek-reasoner'],
    script: { 'deepseek-reasoner': 'fail', 'deepseek-chat': '降级后的答案' },
  })
  const agentFlaky = createAgent({ providers: makeProviders([flaky]), degradeAfter: 3 })
  const evDeg = []
  await agentFlaky.runTurn({ message: 't1', providerId: 'flaky', model: 'deepseek-reasoner', onEvent: (e) => evDeg.push(e) })
  await agentFlaky.runTurn({ message: 't2', providerId: 'flaky', model: 'deepseek-reasoner' })
  const r4 = await agentFlaky.runTurn({ message: 't3', providerId: 'flaky', model: 'deepseek-reasoner', onEvent: (e) => evDeg.push(e) })
  created.push(sessions.sessionPath(r4.sessionId))
  check('agent: 第 3 次失败触发降级', r4.degraded === true, JSON.stringify(r4.degradedReason))
  check('agent: 降级后同轮自动改走 deepseek-chat 并拿到答案', r4.model === 'deepseek-chat' && r4.text === '降级后的答案', r4.text)
  check('agent: 发出 degrade 事件且文案明示', evDeg.some((e) => e.type === 'degrade' && /已降级到 deepseek-chat/.test(e.message)))
  check('agent: notice 落盘（不静默）', sessions.readSession(r4.sessionId).notices.some((n) => n.code === 'E_DEGRADED'))
  const r5 = await agentFlaky.runTurn({ message: 't4', providerId: 'flaky', model: 'deepseek-reasoner' })
  check('agent: 降级态在新会话中依然生效', r5.degraded === true && r5.model === 'deepseek-chat')
  created.push(sessions.sessionPath(r5.sessionId))

  // ---------- 7. 降级控制器状态机 ----------
  const dc = new DegradeController({ threshold: 2 })
  const f1 = dc.recordFailure('p', { model: 'deepseek-reasoner', reason: 'x' })
  const f2 = dc.recordFailure('p', { model: 'deepseek-reasoner', reason: 'y' })
  check('DegradeController: 阈值前不降级', f1.degraded === false && f2.degraded === true && f2.newlyDegraded === true)
  check('DegradeController: snapshot 可序列化', JSON.parse(JSON.stringify(dc.snapshot())).length === 1)

  // ---------- 8. status() ----------
  const st = agentFlaky.status()
  check('agent: status() 带 queue + degrade', !!st.queue && Array.isArray(st.degrade))

  // 清理本次冒烟产生的会话文件（避免污染 data/sessions 列表）
  for (const p of created) {
    try {
      if (existsSync(p)) fs.unlinkSync(p)
    } catch {
      /* 忽略 */
    }
  }
  // 兜底：本轮 runTurn 内部自建的会话（未显式收集）也一并清掉
  let leftover = 0
  for (const name of snapshotSessionFiles()) {
    if (preexisting.has(name)) continue
    try {
      fs.unlinkSync(sessions.sessionPath(name.slice(0, -'.jsonl'.length)))
      leftover += 1
    } catch {
      /* 忽略 */
    }
  }
  if (leftover > 0) log(`(已清理 ${leftover} 个冒烟临时会话文件)`)
  log(`\n${failures === 0 ? 'ALL PASS' : failures + ' FAILED'}`)
  process.exit(failures === 0 ? 0 : 1)
}

main().catch((err) => {
  log('SMOKE THREW: ' + (err && err.stack ? err.stack : err))
  process.exit(2)
})
