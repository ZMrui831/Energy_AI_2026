// tools/scan-writes.mjs —— 只读：扫描 data/logs/writes.jsonl，统计越界写入与 data/browser 写入
import { readFileSync, existsSync } from 'node:fs'
import { resolve, sep } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const p = 'data/logs/writes.jsonl'
if (!existsSync(p)) { console.log(JSON.stringify({ exists: false })); process.exit(0) }

const root = resolve(PROJECT_ROOT).toLowerCase()
const lines = readFileSync(p, 'utf8').split('\n').filter(Boolean)
let parsed = 0
const outOfBounds = []
const browserWrites = []
const protectedHits = []
// P-R7：审计行里的 path **必须是绝对路径**。相对串靠"扫描脚本恰好在项目根下运行"
// 才能判定落点，换个 cwd 就整片失真 —— 这类行单列成缺陷，不能混在越界里。
const relativeRows = []

for (const l of lines) {
  let r
  try { r = JSON.parse(l) } catch { continue }
  parsed += 1
  const path = String(r.path || '')
  if (!path) continue
  if (!/^[A-Za-z]:[\\/]/.test(path) && !path.startsWith('\\\\')) relativeRows.push(path)
  const low = resolve(path).toLowerCase()
  if (low !== root && !low.startsWith(root + sep)) outOfBounds.push(path)
  if (low.includes(`${sep}data${sep}browser${sep}`)) browserWrites.push(path)
  if (r.protected === true) protectedHits.push({ path, reason: r.reason })
}

console.log(JSON.stringify({
  exists: true,
  totalLines: lines.length,
  parsed,
  outOfBoundsCount: outOfBounds.length,
  outOfBoundsSample: outOfBounds.slice(0, 10),
  relativePathCount: relativeRows.length,
  relativePathSample: [...new Set(relativeRows)].slice(0, 5),
  browserWriteCount: browserWrites.length,
  browserWriteSample: [...new Set(browserWrites)].slice(0, 5),
  protectedZoneWriteCount: protectedHits.length,
  protectedSample: protectedHits.slice(0, 5),
}, null, 2))