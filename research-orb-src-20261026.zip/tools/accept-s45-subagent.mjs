// tools/accept-s45-subagent.mjs —— S45·P1 只读子代理（spawn_researcher）验收（≥10 项）。
//
// 单行复跑：node tools\accept-s45-subagent.mjs
//
// 隔离纪律（与既有验收同一套）：
//   · 先设 ORB_LOG_DIR / ORB_DATA_DIR 到临时目录，**再**动态 import（safefs 在 import 时冻结目录）；
//   · 注入带写操作探针的 fs —— "只读零落盘"要能被计数证明，不能只靠注释承诺；
//   · fixture 全部落在临时目录，真实 data\ 非 logs 零写入。

import { mkdirSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

const stamp = Date.now()
const tmpRoot = join(tmpdir(), 's45-subagent-' + stamp)
const LOG_DIR = join(tmpRoot, 'logs')
const DATA_DIR = join(tmpRoot, 'data')
mkdirSync(LOG_DIR, { recursive: true })
mkdirSync(DATA_DIR, { recursive: true })
process.env.ORB_LOG_DIR = LOG_DIR
process.env.ORB_DATA_DIR = DATA_DIR

const nodeFsMod = await import('node:fs')
const { PROJECT_ROOT } = await import('../packages/core/src/safefs.mjs')
const { createToolRuntime } = await import('../packages/core/src/tools/index.mjs')
const { TIER } = await import('../packages/core/src/tools/permissions.mjs')
const sub = await import('../packages/core/src/tools/impl/subagent.mjs')

// executor 会读 data\modes\<id>.json 取当前模式的 denyWrite/denyExec。隔离数据树里没有这份
// 既定事实的话，一跑工具层就撞上 "modes: 未知模式 -> standard"。把项目里那份 standard.json
// 原样搬进隔离树 —— 只复制只读事实，不改任何生产数据。
mkdirSync(join(DATA_DIR, 'modes'), { recursive: true })
nodeFsMod.copyFileSync(
  join(PROJECT_ROOT, 'data', 'modes', 'standard.json'),
  join(DATA_DIR, 'modes', 'standard.json'),
)

const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}

// ---------------------------------------------------------------- 探针 fs
const WRITE_METHODS = new Set([
  'writeFileSync', 'writeFile', 'appendFileSync', 'appendFile', 'createWriteStream',
  'mkdirSync', 'mkdir', 'rmSync', 'rm', 'rmdirSync', 'renameSync', 'rename',
  'copyFileSync', 'copyFile', 'unlinkSync', 'unlink', 'truncateSync', 'utimesSync',
])
const writeCalls = []
let readCalls = 0
const realFs = nodeFsMod.default || nodeFsMod
const spyFs = new Proxy(realFs, {
  get(t, k) {
    const v = Reflect.get(t, k)
    if (typeof v !== 'function') return v
    if (WRITE_METHODS.has(String(k))) return (...a) => { writeCalls.push(String(k)); return v(...a) }
    if (k === 'readFileSync') return (...a) => { readCalls += 1; return v(...a) }
    return v.bind(t)
  },
})

// ---------------------------------------------------------------- fixture
// fixture 落在**隔离数据树内**：createPolicy 会把 DATA_DIR 加进授权根，
// 否则工具层会以 E_OUTSIDE_ROOTS 拒收（这是正确的安全行为，不是缺陷）。
const corpus = join(DATA_DIR, 'corpus')
mkdirSync(corpus, { recursive: true })
const small = join(corpus, 'small.md')
writeFileSync(small, '# 小样本\n- 只有两行\n')

// 大语料：60 行 × ~1150 字符 ≈ 69KB —— 越过 36864 闸门，也能把回传顶到 token 上限
const big = join(corpus, 'big.md')
const bigLines = []
for (let i = 1; i <= 60; i += 1) {
  bigLines.push(`第 ${i} 节 · ` + '这是一段很长的正文用于把回传顶到 token 上限并验证截断是否如实上报。'.repeat(40))
}
writeFileSync(big, bigLines.join('\n'))

// 短行语料：300 条命中 —— 用来证明"回传被 80 条封顶时，Y 仍是真实的扫描总数"
const many = join(corpus, 'many.md')
const manyLines = []
for (let i = 1; i <= 300; i += 1) manyLines.push(`- HIT-${i}：短行便于把命中条数堆到回传上限之上`)
writeFileSync(many, manyLines.join('\n'))

const snapshotDir = (dir) =>
  readdirSync(dir, { withFileTypes: false })
    .map((n) => {
      const st = statSync(join(dir, n))
      return `${n}|${st.size}|${Math.round(st.mtimeMs)}`
    })
    .sort()
    .join(';')
const fixtureBefore = snapshotDir(corpus)

// ---------------------------------------------------------------- 假 net（记账式）
let netCalls = []
const fakeNet = {
  async request(url) {
    netCalls.push(String(url))
    return { ok: true, status: 200, text: async () => '白名单内正文：SNODE-ID-42 存在于此页面。' }
  },
}

try {
  // S1 成本闸门：预估读取量太小 -> 不派
  const before1 = readCalls
  const r1 = await sub.spawnResearcher({ goal: '小样本：这个文件写了什么', paths: [small] }, { fs: spyFs })
  const audit1 = sub.readSubagentAudit({}).filter((r) => r.skipped === true)
  check(
    'S1 成本闸门 cheap-enough（预估 /24576 <1.5 不派，零读取）',
    r1.skipped === true && r1.skipReason === 'cheap-enough' && r1.evidence.length === 0 &&
      r1.outputTokens === 0 && r1.gate.ratio < 1.5 && readCalls === before1 && audit1.length >= 1,
    `ratio=${r1.gate.ratio} skip=${r1.skipReason} readDelta=${readCalls - before1} skip审计=${audit1.length}`,
  )

  // S2 真委派：可行 noble：证据带 文件:行
  const r2 = await sub.spawnResearcher({ goal: 'big.md 每一节讲了什么', paths: [big], keywords: ['第'] }, { fs: spyFs })
  const grepRefs = r2.evidence.filter((e) => e.kind === 'grep')
  check(
    'S2 越过闸门即委派（ok + 证据带 文件:行）',
    r2.ok === true && r2.skipped === false && grepRefs.length >= 2 &&
      grepRefs.every((e) => /:\d+$/.test(String(e.ref)) && e.line >= 1) && String(r2.output).includes('Found'),
    `evidence=${r2.evidence.length} grep=${grepRefs.length} tokens=${r2.outputTokens}`,
  )

  // S3 maxDepth:1 —— 二次委派 / 相对多层 / 递归通配 / 显式深度 全拒
  const d1 = await sub.spawnResearcher({ goal: '派了还想再派一层', capabilities: ['spawn'] }, { fs: spyFs })
  const d2 = await sub.spawnResearcher({ goal: '相对路径三层', paths: [join('a', 'b', 'c.md')] }, { fs: spyFs })
  const d3 = await sub.spawnResearcher({ goal: '递归通配', paths: [join(corpus, '**', '*.md')] }, { fs: spyFs })
  const d4 = await sub.spawnResearcher({ goal: '显式深度 2', delegationDepth: 2 }, { fs: spyFs })
  const allDepth = [d1, d2, d3, d4]
  check(
    'S3 maxDepth:1 阻断（spawn/多层/**/delegationDepth=2）',
    allDepth.every((r) => r.ok === false && r.code === 'E_SUBAGENT_DEPTH' && r.evidence.length === 0),
    allDepth.map((r) => r.code).join(','),
  )

  // S4 越权能力全拒（write/shell/db），零执行
  const before4 = readCalls
  const c1 = await sub.spawnResearcher({ goal: '顺便帮我写点东西', capabilities: ['write'] }, { fs: spyFs })
  const c2 = await sub.spawnResearcher({ goal: '顺便跑个命令', capabilities: ['shell'] }, { fs: spyFs })
  const c3 = await sub.spawnResearcher({ goal: '顺便查个库', capabilities: ['db'] }, { fs: spyFs })
  check(
    'S4 越权能力全拒（write/shell/db → E_SUBAGENT_CAP_DENIED，零执行）',
    [c1, c2, c3].every((r) => r.ok === false && r.code === 'E_SUBAGENT_CAP_DENIED' && r.evidence.length === 0) &&
      readCalls === before4,
    `readDelta=${readCalls - before4} codes=${[c1, c2, c3].map((r) => r.code).join(',')}`,
  )

  // S5 回传封顶 8192 token + 如实横幅 Found X of Y
  const r5 = await sub.spawnResearcher({ goal: '超长语料考验封顶', paths: [big], keywords: ['第'] }, { fs: spyFs })
  check(
    'S5 ≤8192 token 封顶（超了按节截断 + Found X of Y）',
    r5.outputTokens <= 8192 && r5.truncated === true &&
      /Found \d+ of \d+ 字符/.test(String(r5.output)) && /Found \d+ of \d+/.test(String(r5.output)),
    `tokens=${r5.outputTokens} shown=${r5.shownChars}/${r5.rawChars} 截断=${r5.truncated}`,
  )

  // S6 证据契约：每条结论必须有 文件:行 或 URL
  const okEvidence = r5.evidence.filter((e) => !e.unverifiable)
  check(
    'S6 证据契约（每条结论可回指：文件:行 或 https://）',
    okEvidence.length >= 1 && okEvidence.every((e) => /:\d+$/.test(String(e.ref)) || /^https?:\/\//i.test(String(e.ref))),
    `可回指=${okEvidence.length}/${r5.evidence.length}`,
  )

  // S7 无法验证契约：不存在的文件 + 白名单外 URL —— 写实 WRONG WRONG 而不猜
  netCalls = []
  const r7 = await sub.spawnResearcher(
    { goal: '混合：一半能读一半不能读', paths: [big, join(corpus, 'none.md')], urls: ['https://evil.example.com/a'], keywords: ['第'] },
    { fs: spyFs, net: fakeNet },
  )
  const missing = r7.evidence.find((e) => String(e.ref).includes('none.md'))
  const evil = r7.evidence.find((e) => String(e.ref).includes('evil.example.com'))
  check(
    'S7 无法验证契约（缺文件/白名单外 URL → 【无法验证+原因】，且零请求）',
    !!missing && String(missing.note).startsWith(sub.UNVERIFIABLE_PREFIX) &&
      !!evil && String(evil.note).includes('不在白名单') && netCalls.length === 0,
    `netCalls=${netCalls.length} missing=${!!missing} evil=${!!evil}`,
  )

  // S8 抽查：原文复核通过 / 篡改与缺文件 -> 作废并写 subagent-void
  const target = r2.evidence.find((e) => !e.unverifiable && e.kind !== 'glob')
  const v1 = await sub.verifyEvidence(target, { fs: spyFs })
  const v2 = await sub.verifyEvidence({ ...target, lineContent: '这句话原文里没有——掺了就是造假' }, { fs: spyFs })
  const v3 = await sub.verifyEvidence({ ref: join(corpus, '没有这个文件.md') + ':3', lineContent: 'x' }, { fs: spyFs })
  const voidRows = sub.readSubagentAudit({}).filter((r) => r.auditType === 'subagent-void')
  check(
    'S8 抽查可复核（真题 PASS / 篡改与缺文件作废 + void 审计）',
    v1.ok === true && v1.matched === true &&
      v2.ok === false && v2.code === 'E_EVIDENCE_VOID' &&
      v3.ok === false && voidRows.length >= 2 && voidRows.every((r) => r.ref && r.why),
    `v1=${v1.ok} v2=${v2.code} v3=${v3.ok} voidRows=${voidRows.length}`,
  )

  // S15 诚实口径：单文件只读 64KB 要写明；回传被封顶时 Y 必须是真实扫描总数
  const r15a = await sub.spawnResearcher({ goal: '单文件超过读取上限', paths: [big], keywords: ['第'] }, { fs: spyFs })
  const r15b = await sub.spawnResearcher({ goal: '命中数超过回传上限', paths: [big, many], keywords: ['第', '行'] }, { fs: spyFs })
  check(
    'S15 诚实口径（写明实读/总量；回传被封顶时 Y>X）',
    /实读 \d+\/\d+ 字节/.test(String(r15a.output)) && (r15a.coverage.readBytes > 0) && (r15a.coverage.readBytes < r15a.coverage.realBytes) &&
      r15b.scannedTotal > r15b.evidence.length && r15b.evidence.length === sub.MAX_RETURNED_EVIDENCE,
    `a: 实读 ${r15a.coverage.readBytes}/${r15a.coverage.realBytes}；b: Found ${r15b.evidence.length} of ${r15b.scannedTotal}`,
  )

  // S10 预算超支 -> 明确报错 + 审计 ok:false
  const r10 = await sub.spawnResearcher({ goal: '预算只有 1KB', paths: [big], budgetBytes: 1024 }, { fs: spyFs })
  check(
    'S10 预算超支（E_SUBAGENT_OVER_BUDGET，不硬读）',
    r10.ok === false && r10.code === 'E_SUBAGENT_OVER_BUDGET' && r10.evidence.length === 0 && r10.audit.ok === false,
    `预估=${r10.estimatedBytes} 预算=1024 code=${r10.code}`,
  )

  // S11 审计：spawn 行十字段齐全；void 行另有一套 {ref, why}（两类事实分开记，不可混写）
  const rows = sub.readSubagentAudit({})
  const spawnRows = rows.filter((r) => !r.auditType)
  const voidRowsAll = rows.filter((r) => r.auditType === 'subagent-void')
  const needKeys = ['ts', 'goal', 'paths', 'urls', 'budgetBytes', 'actualBytes', 'outputTokens', 'ok', 'evidenceCount', 'voidReason']
  check(
    'S11 审计字段齐全（spawn 行十字段 / void 行含 ref+why+ts）',
    spawnRows.length >= 6 && spawnRows.every((r) => needKeys.every((k) => Object.prototype.hasOwnProperty.call(r, k))) &&
      voidRowsAll.length >= 2 && voidRowsAll.every((r) => r.ref && r.why && r.ts),
    `spawn行=${spawnRows.length} 缺字段=${spawnRows.filter((r) => !needKeys.every((k) => k in r)).length} void行=${voidRowsAll.length}`,
  )

  // S12 工具层登记 + executor 闸门（headless 无确认也放行只读档 / 授权根外拒绝 / schema 先拒）
  const rt = createToolRuntime({})
  const before12 = rows.length
  const exOk = await rt.run({ toolId: sub.SUBAGENT_TOOL_ID, args: { goal: '工具层委派一次', paths: [big], keywords: ['第'] }, origin: 'accept-s45' })
  const exBad = await rt.run({ toolId: sub.SUBAGENT_TOOL_ID, args: { goal: '工具层塞个写能力', capabilities: ['shell'] }, origin: 'accept-s45' })
  const exOut = await rt.run({ toolId: sub.SUBAGENT_TOOL_ID, args: { goal: '工具层读红线文件', paths: ['C:\\Windows\\System32\\drivers\\etc\\hosts'] }, origin: 'accept-s45' })
  check(
    'S12 工具层接线（AUTO 档放行 / enum 外被 schema 拒 / 拒绝根被 deny）',
    rt.registry.has(sub.SUBAGENT_TOOL_ID) && rt.policy.tierOf(sub.SUBAGENT_TOOL_ID) === TIER.AUTO &&
      exOk.ok === true && exBad.ok === false && exBad.error.code === 'E_BAD_ARGS' &&
      exOut.denied === true && sub.readSubagentAudit({}).length > before12,
    `tier=${rt.policy.tierOf(sub.SUBAGENT_TOOL_ID)} exOk=${exOk.ok} exBad=${exBad.error && exBad.error.code} exOut=${exOut.error && exOut.error.code}`,
  )

  // S13 URL：白名单内注入才取、无 net 如实降级、URL 证据也可抽查（抽查本身要真抓一次）
  netCalls = []
  const u1 = await sub.spawnResearcher({ goal: '抓白名单内页面', paths: [big], urls: ['https://arxiv.org/abs/2401.00001'] }, { fs: spyFs, net: fakeNet })
  const fetchCount = netCalls.length
  const webEvidence = u1.evidence.find((e) => e.kind === 'web')
  const vUrl = webEvidence ? await sub.verifyEvidence(webEvidence, { fs: spyFs, net: fakeNet }) : { ok: false }
  const afterCheckCount = netCalls.length
  const u2 = await sub.spawnResearcher({ goal: '没给出网能力', paths: [big], urls: ['https://arxiv.org/abs/2401.00002'] }, { fs: spyFs })
  const noNet = u2.evidence.find((e) => String(e.ref).includes('2401.00002'))
  check(
    'S13 出网三态（白名单内可抓可抽查 / 白名单外零请求 / 无能力写无法验证）',
    fetchCount === 1 && afterCheckCount === 2 && !!webEvidence && String(webEvidence.lineContent).includes('SNODE-ID-42') &&
      vUrl.ok === true && !!noNet && String(noNet.note).startsWith(sub.UNVERIFIABLE_PREFIX),
    `抓取=${fetchCount} 抽查后=${afterCheckCount} web=${!!webEvidence} 抽查=${vUrl.ok} 无能力降级=${!!noNet}`,
  )

  // S14 失败不影响主会话（结构化返回，不抛）
  const bad1 = await sub.spawnResearcher({ goal: '' }, { fs: spyFs })
  const bad2 = await sub.spawnResearcher({ goal: '缺 param 也不炸', paths: ['not-a-path-随便'], budgetBytes: 99999999 }, { fs: spyFs })
  check(
    'S14 失败不抛（结构化返回，主会话照常继续）',
    bad1.ok === false && bad1.code === 'E_BAD_ARGS' && typeof bad2.ok === 'boolean',
    `bad1=${bad1.code} bad2.ok=${bad2.ok} bad2.code=${bad2.code}`,
  )
  // 最后一项：只读零落盘。写探针必须覆盖上面**每一路**分支，所以放在末位。
  const fixtureAfter = snapshotDir(corpus)
  check(
    'S9 只读零落盘（注入 fs 的写方法调用=0，fixture 未被改动）',
    writeCalls.length === 0 && fixtureBefore === fixtureAfter,
    `写调用=${writeCalls.length}${writeCalls.length ? '(' + writeCalls.join(',') + ')' : ''} fixtureSame=${fixtureBefore === fixtureAfter}`,
  )
} catch (e) {
  check('S0 验收脚本自身异常', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  try {
    rmSync(tmpRoot, { recursive: true, force: true })
  } catch {
    /* 临时目录清理失败不影响验收结论 */
  }
}

const total = items.length
const passed = items.filter((i) => i.ok).length
const failed = total - passed
console.log(`  # accept-s45-subagent: total=${total} pass=${passed} fail=${failed}`)
process.exitCode = failed === 0 ? 0 : 1
