// tools/probe-s31-failclosed.mjs —— S31·B1 fail-closed 全路径演练。
// 单行复跑：node tools\probe-s31-failclosed.mjs
//
// 取证口径：不启动 Electron，直接调教练子模块（与 UI 同一份代码）。
// 关键：consent 状态以【注入参数】方式模拟 denied / allowed，而不改写真实的
//       data/perception-config.json（避免扰动可能正在运行的宿主应用，也避免 EPERM 锁）。
//       这恰好等价于真实命令路径：manualAsk 读 consent → 把 consentActive 传给 daily/ask；
//       coachHealthCheck 也接收 consent 参数。所以注入的就是真实生效的闸。
//   · denied 下依次调 run-daily / ask / 健康检查(coachHealthCheck) / memory recall
//     → 每条降级但不崩、有审计行（skipped-no-consent / downgraded）、返回明确提示。
//   · 切回 allowed 验证恢复（skipped:false，真正跑通流水线/问询）。
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createRouter } from '../packages/core/src/router.mjs'
import { createExtractor } from '../packages/plugins/coach/extract.mjs'
import { createConfusionCoach } from '../packages/plugins/coach/confusion.mjs'
import { createDailyPipeline } from '../packages/plugins/coach/daily.mjs'
import { createHealthLedger } from '../packages/plugins/coach/health.mjs'
import { recallMemories } from '../packages/plugins/coach/memory.mjs'
import { readPerceptionConsent } from '../packages/plugins/coach/consent.mjs'
import { coachHealthCheck } from '../packages/plugins/coach/index.mjs'
import { auditPreflight } from '../packages/plugins/coach/audit-preflight.mjs'

const CFG = join(PROJECT_ROOT, 'data', 'perception-config.json')
const AUDIT = join(PROJECT_ROOT, 'data', 'logs', 'coach.jsonl')
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's31-failclosed')
const COACH_DIR = join(WORK, 'coach')
const IMG = join(WORK, 'frame.png')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 240), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

function stubRouter() {
  return createRouter({
    providers: { cheap: { providerId: 'school-gateway', model: 'qwen' }, flagship: { providerId: 'deepseek-api', model: 'deepseek-chat' } },
    invoke: async ({ taskClass }) => {
      if (taskClass === 'extract') return { text: '屏幕文字：测试页面（桩）' }
      if (taskClass === 'summarize') return { text: '["在查看测试页面"]' }
      if (taskClass === 'score-plan') return { text: '{"score":80,"advice":["继续推进"]}' }
      return { text: 'ok' }
    },
    audit: () => {},
  })
}
function readAudit() { try { return existsSync(AUDIT) ? readFileSync(AUDIT, 'utf8') : '' } catch { return '' } }

rmSync(WORK, { recursive: true, force: true })
mkdirSync(COACH_DIR, { recursive: true })
writeFileSync(IMG, Buffer.from('failclosed frame'))

// 只读读取真实 consent（不改动）用于报告
let realConsent = { mode: '?', active: false }
try { realConsent = readPerceptionConsent() } catch {}

try {
  // 先确认基线巡检本身可过（B3 联动）
  try { const pf = auditPreflight(); check('F0 审计完整性巡检可过（B3 前置）', pf.ok === true) } catch (e) { check('F0 审计完整性巡检可过（B3 前置）', false, e.message) }
  check('F0b 真实 perception 当前模式（仅报告）', true, 'mode=' + realConsent.mode + ' active=' + realConsent.active)

  const router = stubRouter()
  const extractor = createExtractor({ dir: COACH_DIR, router, trashDir: join(WORK, 'trash'), ocr: () => ({ ok: true, text: '兜底' }) })
  const daily = createDailyPipeline({ dir: COACH_DIR, router, extractor })
  const confusion = createConfusionCoach({ dir: COACH_DIR, router, extractor })

  // ===== 阶段一：consent=denied（注入） =====
  const denied = { mode: 'denied', active: false, source: 'injected-test' }
  const beforeAudit = readAudit()

  // ① run-daily：降级跳过 + 审计 skipped-no-consent + 明确提示
  const rd = await daily.run({ consentActive: denied.active, frames: [{ imagePath: IMG, window: 'w', process: 'p' }], goal: '测试' })
  const afterAudit = readAudit()
  const newSkips = (afterAudit.match(/"kind":"skipped-no-consent"/g) || []).length - (beforeAudit.match(/"kind":"skipped-no-consent"/g) || []).length
  check('F2 run-daily：denied 下降级跳过且不崩', rd.ok === false && rd.skipped === true)
  check('F3 run-daily：留审计 skipped-no-consent', newSkips >= 1, '新增 skipped-no-consent=' + newSkips)
  check('F4 run-daily：返回明确提示（告知未跑）', !!rd.reason && /未/.test(rd.reason), rd.reason || '')

  // ② ask：降级跳过 + 审计 + 明确提示
  const beforeAsk = readAudit()
  const ak = await confusion.ask({ imagePath: IMG, trigger: 'manual', consentActive: denied.active })
  const afterAsk = readAudit()
  const askSkips = (afterAsk.match(/"kind":"skipped-no-consent"/g) || []).length - (beforeAsk.match(/"kind":"skipped-no-consent"/g) || []).length
  check('F5 ask：denied 下降级跳过且不崩', ak.ok === false && ak.skipped === true)
  check('F6 ask：留审计 skipped-no-consent', askSkips >= 1, '新增=' + askSkips)

  // ③ 健康检查：降级但不崩 + 明确降级提示
  const hc = coachHealthCheck({ consent: denied })
  check('F7 健康检查：降级但不崩（ok=true, downgraded=true）', hc.ok === true && hc.downgraded === true)
  check('F8 健康检查：明确降级提示', !!hc.message && /降级|未激活/.test(hc.message), (hc.message || '').slice(0, 60))

  // ④ memory recall：未被感知闸影响，仍可用且不崩
  const mr = recallMemories('测试')
  check('F9 memory recall：降级但不崩（返回数组）', Array.isArray(mr), 'type=' + typeof mr)

  // ===== 阶段二：切回 allowed（注入）验证恢复 =====
  const allowed = { mode: 'metadata-only', active: true, source: 'injected-test' }
  const rd2 = await daily.run({ consentActive: allowed.active, frames: [{ imagePath: IMG, window: 'w', process: 'p' }], goal: '测试' })
  check('F11 恢复：run-daily 真正跑通（skipped=false, ok=true）', rd2.ok === true && rd2.skipped !== true, 'score=' + rd2.score)
  const ak2 = await confusion.ask({ imagePath: IMG, trigger: 'manual', consentActive: allowed.active })
  check('F12 恢复：ask 真正生成问询（ok=true）', ak2.ok === true && !!ak2.question, (ak2.question || '').slice(0, 40))
  const hc2 = coachHealthCheck({ consent: allowed })
  check('F13 恢复：健康检查不再降级（downgraded=false）', hc2.downgraded === false)
} catch (e) {
  check('Fx 探针异常', false, String((e && e.stack) || e).slice(0, 240))
} finally {
  rmSync(WORK, { recursive: true, force: true })
}

const pass = items.filter((i) => i.ok).length
const fail = items.length - pass
const out = { tool: 'probe-s31-failclosed', at: new Date().toISOString(), total: items.length, pass, fail, items }
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's31-failclosed.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # probe-s31-failclosed: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 证据 -> data/logs/s31-failclosed.json`)
process.exit(fail === 0 ? 0 : 1)
