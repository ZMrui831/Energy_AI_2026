// tools/setup-venv.mjs
//
// 一键重建受管 venv（满足"docx 独立验证 b 冷跑复现"的自带环境自建步骤）。
// 用受管 Python 3.13.12 建项目内 .venv，并精确锁定三个文档库。
// 不触碰全局任何 pip 包；.venv 在唯一可写根 D:\explorer!\\research-orb\ 内。
//
// 【P-R7 修订】.venv 此前只有 python-docx，工具层的 doc.xlsx / doc.pptx
// 要么"装进项目 venv"要么"降级为 CSV/HTML 并在工具描述里写明降级"。
// 主管要求：**允许装包，但必须装在项目 venv 里，且要能被这条脚本一键重建**
// ——否则别人冷跑一遍就退化，等于把能力建立在不可复现的环境上。
// 所以这里把 openpyxl 与 python-pptx 一起锁定，并在末尾逐个 import 校验。

import { existsSync } from 'node:fs'
import { spawnSync } from 'node:child_process'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const MANAGED_PY = `${process.env.USERPROFILE}\\workbuddy\\binaries\\python\\versions\\3.13.12\\python.exe`
const VENV_PY = PROJECT_ROOT + '\\.venv\\Scripts\\python.exe'

/** 精确锁定的依赖（顺序即安装顺序；新增库必须同时加进 CHECKS）。 */
const PACKAGES = [
  { spec: 'python-docx==1.1.2', module: 'docx', label: 'python-docx（doc.docx：正文宋体 / 标题楷体）' },
  { spec: 'openpyxl==3.1.5', module: 'openpyxl', label: 'openpyxl（doc.xlsx：真表格，不降级）' },
  { spec: 'python-pptx==1.0.2', module: 'pptx', label: 'python-pptx（doc.pptx：真演示文稿，不降级）' },
]

function run(cmd, args, label) {
  const r = spawnSync(cmd, args, { stdio: 'inherit' })
  if (r.status !== 0) {
    console.error(`[setup-venv] 失败：${label}`)
    process.exit(1)
  }
}

if (!existsSync(MANAGED_PY)) {
  console.error(`[setup-venv] 受管 Python 缺失：${MANAGED_PY}`)
  process.exit(1)
}

console.log('[setup-venv] 用受管 Python 3.13.12 建项目内 .venv ...')
run(MANAGED_PY, ['-m', 'venv', PROJECT_ROOT + '\\.venv'], '建 venv')

for (const p of PACKAGES) {
  console.log(`[setup-venv] 锁定 ${p.spec} ...`)
  run(VENV_PY, ['-m', 'pip', 'install', '--no-input', p.spec], `装 ${p.spec}`)
}

console.log('[setup-venv] 校验（逐个 import，缺一个就 exit 1）...')
for (const p of PACKAGES) {
  const chk = spawnSync(
    VENV_PY,
    ['-X', 'utf8', '-c', `import ${p.module}; print("${p.module}", getattr(${p.module}, "__version__", "ok"))`],
    { stdio: 'inherit', env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' } },
  )
  if (chk.status !== 0) {
    console.error(`[setup-venv] 校验失败：${p.module}（${p.label}）`)
    process.exit(1)
  }
}

console.log(`[setup-venv] 完成：venv=${VENV_PY} 已就绪（${PACKAGES.length} 个文档库），doc.docx/xlsx/pptx 均可复现。PROJECT_ROOT=${PROJECT_ROOT}`)
