// tools/memory-warmup.mjs —— S36·六：开拍前记忆预热（真跑一次读写链路，产出 data/reports/memory-warmup.md）。
// 单行复跑：node tools\memory-warmup.mjs
// 口径：真实数据树（不设 ORB_DATA_DIR）——本脚本就是"真跑一次"的预热，写入的是真实长期记忆。
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, dataPath, safeWrite } from '../packages/core/src/safefs.mjs'
import { setGoal, readGoal } from '../packages/plugins/coach/engine.mjs'
import { observeTurn } from '../packages/plugins/longterm-memory/write.mjs'
import { readLongTermMemoryContext } from '../packages/plugins/longterm-memory/context.mjs'

const GOAL = process.argv[2] || '两周内完成微电网综述的初稿与文献表（覆盖虚拟电厂与需求响应）'
const FACTS = [
  '用户的研究方向是智能电网综合能源系统的 AI 应用',
  '用户每周可投入约 10 小时推进综述写作',
  '综述优先覆盖虚拟电厂与需求响应两个章节',
]

console.log('[warmup] ① 设目标……')
const goal = setGoal(GOAL, { source: 'warmup' })

console.log('[warmup] ② 沉淀 3 条事实（真实写侧双闸）……')
const written = []
for (const f of FACTS) {
  const r = observeTurn({ userText: f })
  written.push({ text: f, result: r })
  console.log(`  · ${f.slice(0, 24)}… → written=${r.written}`)
}

console.log('[warmup] ③ 重开应用等价的 recall（S30 注入上下文）……')
const ctx = readLongTermMemoryContext({ query: '微电网 综述 虚拟电厂' })
const recallHit = typeof ctx === 'string' && (ctx.includes('综述') || ctx.includes('虚拟电厂'))

const lines = [
  '# 记忆预热报告（memory-warmup）',
  '',
  `- 时间：${new Date().toISOString()}`,
  '- 目的：开拍前真跑一次"设目标 → 说事实 → 重开应用 → /memory recall 取回"的完整读写链路，避免演示时空库冷启动。',
  '',
  '## ① 设定目标（/coach goal set）',
  '',
  `- 目标：${goal.goal}`,
  `- 落盘：data/coach/goal.json（source=${goal.source}）`,
  '',
  '## ② 沉淀事实（真实写侧：事实双闸 + 单轮 ≤2 条治理）',
  '',
  ...written.map((w, i) => `${i + 1}. ${w.text} → written=${w.result.written}${w.result.skipped ? '（skipped=' + w.result.skipped + '）' : ''}`),
  '',
  '## ③ recall 取回（等价于重开应用后的 /memory recall）',
  '',
  '```',
  ...(typeof ctx === 'string' && ctx ? ctx.split('\n') : ['（注入为空——若如此请检查写侧是否命中治理闸）']),
  '```',
  '',
  `- recall 命中："综述/虚拟电厂"出现在注入上下文中 = ${recallHit ? '是' : '否'}`,
  '',
  '## 复跑命令',
  '',
  '```',
  'node tools\\memory-warmup.mjs',
  '```',
  '',
  '## 截图位（开拍前补）',
  '',
  '- [ ] 应用重开后 /memory recall 的界面截图（含命中条目）。',
  '- [ ] data/memory/project/longterm.md 的文件内容特写（契约头 + 事实条目）。',
  '',
  '> 诚实口径：本报告由脚本真跑生成，recall 输出为原文摘录；界面截图需在真实应用里补拍（脚本环境无 GUI）。',
  '',
]

const reportsDir = dataPath('reports')
mkdirSync(reportsDir, { recursive: true })
const out = join(reportsDir, 'memory-warmup.md')
safeWrite(out, lines.join('\n'), 'utf8')
console.log(`[warmup] ④ 报告 → ${out}`)
console.log(`[warmup] recall 命中=${recallHit ? '是' : '否'}；goal=${goal.goal.slice(0, 20)}…；facts written=${written.filter((w) => w.result.written > 0).length}/3`)
process.exit(recallHit ? 0 : 1)
