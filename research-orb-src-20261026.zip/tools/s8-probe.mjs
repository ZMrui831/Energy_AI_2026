// tools/s8-probe.mjs —— S8 数据层探针（独立子进程；只动 argv 给的 workdir 内自建夹具）。
// 覆盖：D11-① 回收区到期（TTL 默认 + 可配，物理删除+审计留痕）；D11-② 抓屏登记一致
//       （DB 行/显式例外台账/无主 PNG 三分）；D11-② 产品路径（S1 工具抓屏→登记→保留→清理）。
// 用法：node tools/s8-probe.mjs --workdir <dir>
// 输出：stdout 单行紧凑 JSON。

import { mkdirSync, writeFileSync, utimesSync, existsSync, statSync } from 'node:fs'
import { join, resolve } from 'node:path'

import { createStore } from '../packages/core/src/db.mjs'
import { runCleanup, trashStats } from '../packages/core/src/lifecycle/cleaner.mjs'
import { registerExternalCapture, countExternalCaptures, knownExternalPaths } from '../packages/core/src/lifecycle/capture-registry.mjs'
import { createToolRuntime } from '../packages/core/src/tools/index.mjs'

const argv = process.argv.slice(2)
const arg = (k, d = null) => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : d }
const WORK = arg('--workdir') || resolve(import.meta.dirname, '..') + '/data/tmp/s8-probe-' + Date.now()
mkdirSync(WORK, { recursive: true })

const items = []
function report(id, clause, ok, detail, evidence = {}) {
  items.push({ id, clause, ok: !!ok, detail, evidence })
  console.error(`[${ok ? 'PASS' : 'FAIL'}] ${id} (${clause}) ${detail}`)
}

async function freshStore(name, cfg = null) {
  const dir = join(WORK, name)
  mkdirSync(join(dir, 'shots'), { recursive: true })
  mkdirSync(join(dir, 'trash'), { recursive: true })
  const store = await createStore({ driver: 'sqlite', dbPath: join(dir, 'orb.sqlite'), dataDir: dir, config: cfg })
  store.initMigrations()
  return { dir, store }
}
const fakePng = (p) => { writeFileSync(p, Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'base64')); return p }

async function main() {
  // ---------- S8-T1：回收区到期（默认 TTL 7 天；§2） ----------
  {
    const { dir, store } = await freshStore('fx-t1')
    const trashDir = join(dir, 'trash')
    const oldFile = join(trashDir, 'old-frame.png')
    const freshFile = join(trashDir, 'fresh-frame.png')
    fakePng(oldFile); fakePng(freshFile)
    const tenDaysAgo = new Date(Date.now() - 10 * 86400_000)
    utimesSync(oldFile, tenDaysAgo, tenDaysAgo)
    const s = await runCleanup({ store, shotsDir: join(dir, 'shots'), trashDir, dataDir: dir })
    const ev = store.listAuditEvents({ kind: 'trash-expired' })
    const ok = !existsSync(oldFile) && existsSync(freshFile) && s.trashExpired === 1 && ev.length === 1 &&
      JSON.parse(ev[0].metadata_json).age_days >= 9 && typeof JSON.parse(ev[0].metadata_json).bytes === 'number'
    report('S8-T1', 'CONTRACT §2 回收区到期（默认 TTL）：旧文件物理删除+审计留痕，新文件保留', ok,
      `trashExpired=${s.trashExpired}；旧文件在盘=${existsSync(oldFile)}；新文件在盘=${existsSync(freshFile)}；trash-expired 审计=${ev.length}（age_days=${ev.length ? JSON.parse(ev[0].metadata_json).age_days : '-'}）`,
      { stats: s, audit: ev.length ? JSON.parse(ev[0].metadata_json) : null })
    store.close()
  }

  // ---------- S8-T2：TTL 可配（retention.trashDays=2） ----------
  {
    const { dir, store } = await freshStore('fx-t2', { retention: { trashDays: 2 } })
    const trashDir = join(dir, 'trash')
    const threeDays = join(trashDir, 'three-days.png')
    const oneDay = join(trashDir, 'one-day.png')
    fakePng(threeDays); fakePng(oneDay)
    const t3 = new Date(Date.now() - 3 * 86400_000)
    utimesSync(threeDays, t3, t3)
    const s = await runCleanup({ store, shotsDir: join(dir, 'shots'), trashDir, dataDir: dir, config: { retention: { trashDays: 2 } } })
    const ok = !existsSync(threeDays) && existsSync(oneDay) && s.trashExpired === 1
    report('S8-T2', 'CONTRACT §2 回收区 TTL 可配（trashDays=2）', ok,
      `3 天前文件删除=${!existsSync(threeDays)}；1 天前文件保留=${existsSync(oneDay)}；trashExpired=${s.trashExpired}`,
      { stats: s })
    store.close()
  }

  // ---------- S8-T3：抓屏三分（DB 行 / 显式例外 / 无主） ----------
  {
    const { dir, store } = await freshStore('fx-t3')
    const shotsDir = join(dir, 'shots')
    const trashDir = join(dir, 'trash')
    // (a) DB 登记过的帧（产品路径）
    const registered = fakePng(join(shotsDir, 'registered.png'))
    store.insertRawFrame({ id: 'rf-t3', file_path: registered, sha256: 'e'.repeat(64), sensitivity: 'normal', created_at: new Date().toISOString(), expires_at: new Date(Date.now() + 3600_000).toISOString() })
    // (b) 非应用进程抓屏 → 显式例外通道
    const external = fakePng(join(shotsDir, 'external-harness.png'))
    const reg = registerExternalCapture({ dataDir: dir, filePath: external, reason: 'S8 验收：独立 harness 抓屏取证', by: 's8-probe' })
    // (c) 无主 PNG（既无 DB 行也未登记例外）
    const orphan = fakePng(join(shotsDir, 'orphan.png'))

    const s = await runCleanup({ store, shotsDir, trashDir, dataDir: dir })
    const movedAudit = store.listAuditEvents({ kind: 'orphan-moved' })
    const excAudit = store.listAuditEvents({ kind: 'orphan-scan-exceptions' })
    const ok = existsSync(registered) && existsSync(external) && !existsSync(orphan) &&
      reg.ok && s.orphansMoved === 1 && movedAudit.length === 1 &&
      JSON.parse(movedAudit[0].metadata_json).from.endsWith('orphan.png') &&
      countExternalCaptures(dir) === 1 && knownExternalPaths(dir).size === 1 &&
      excAudit.length === 1 && JSON.parse(excAudit[0].metadata_json).known_external === 1
    report('S8-T3', 'CONTRACT §2/§6 抓屏三分：DB 行与显式例外不搬，无主 PNG 才进回收站', ok,
      `DB 行在盘=${existsSync(registered)}；例外登记在盘=${existsSync(external)}（登记 ok=${reg.ok}）；无主搬走=${!existsSync(orphan)}；orphan-moved=${s.orphansMoved}；例外台账=${countExternalCaptures(dir)} 条`,
      { register: reg, stats: s, moved: movedAudit.length ? JSON.parse(movedAudit[0].metadata_json) : null, exceptions: countExternalCaptures(dir) })
    store.close()
  }

  // ---------- S8-T4：产品路径（S1 工具抓屏 → 登记 → 保留 → 清理；D6 口径） ----------
  {
    const { dir, store } = await freshStore('fx-t4')
    const shotsDir = join(dir, 'shots')
    const trashDir = join(dir, 'trash')
    // 抓屏走 S1 公开工具（host 注入真实落盘；与 demo-script 同路径）
    const runtime = createToolRuntime({
      host: { screen: { captureScreen: async () => {
        const p = fakePng(join(shotsDir, `cap-${Date.now()}.png`))
        const { readFileSync } = await import('node:fs')
        const { createHash } = await import('node:crypto')
        return { ok: true, pngPath: p, bytes: statSync(p).size, hash: createHash('sha256').update(readFileSync(p)).digest('hex'), width: 1, height: 1 }
      } } },
    })
    const cap = await runtime.run({ toolId: 'screen.capture', args: {} })
    const capOk = !!(cap && cap.ok && cap.value && cap.value.ok)
    // 登记（S3 公开 API）
    const row = store.insertRawFrame({
      id: 'rf-t4', file_path: cap.value.path, sha256: cap.value.hash, sensitivity: 'normal',
      created_at: new Date().toISOString(), expires_at: new Date(Date.now() - 1000).toISOString(), // 已过期
    })
    // 清理（产品清理轮）
    const s = await runCleanup({ store, shotsDir, trashDir, dataDir: dir })
    const after = store.getRawFrame('rf-t4')
    const delAudit = store.listAuditEvents({ kind: 'frame-deleted' })
    const ok = capOk && after.status === 'deleted' && !existsSync(cap.value.path) && s.deleted === 1 && delAudit.length === 1
    report('S8-T4', 'CONTRACT §2/§6 产品路径闭环：S1 抓屏→insertRawFrame→保留到期→清理删除', ok,
      `S1 screen.capture ok=${capOk}；insertRawFrame ok；清理后 status=${after.status}、文件在盘=${existsSync(cap.value.path)}；frame-deleted 审计=${delAudit.length}`,
      { captureOk: capOk, statusAfter: after.status, deleted: s.deleted })
    store.close()
  }

  // ---------- S8-T5：统计命令口径（§7 机器可读） ----------
  {
    const { dir, store } = await freshStore('fx-t5')
    const trashDir = join(dir, 'trash')
    fakePng(join(trashDir, 'a.png')); fakePng(join(trashDir, 'b.png'))
    const st = trashStats(trashDir)
    registerExternalCapture({ dataDir: dir, filePath: fakePng(join(dir, 'shots', 'x.png')), reason: '统计口径验证', by: 's8-probe' })
    const exc = countExternalCaptures(dir)
    const ok = st.files === 2 && st.bytes > 0 && exc === 1
    report('S8-T5', 'CONTRACT §7 回收区统计可机器读取（文件数/字节/例外条数）', ok,
      `trashStats files=${st.files} bytes=${st.bytes}；例外台账=${exc}`,
      { trashStats: st, exceptions: exc })
    store.close()
  }

  const okAll = items.every((i) => i.ok)
  process.stdout.write(JSON.stringify({ ok: okAll, workdir: WORK, items }) + '\n')
  process.exit(okAll ? 0 : 1)
}

main().catch((e) => {
  process.stdout.write(JSON.stringify({ ok: false, fatal: String((e && e.stack) || e), items }) + '\n')
  process.exit(2)
})
