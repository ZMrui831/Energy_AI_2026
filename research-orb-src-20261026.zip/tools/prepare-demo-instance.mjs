#!/usr/bin/env node
// tools/prepare-demo-instance.mjs —— S74c·P0-5 演示环境一键备齐（宣称 #18/#25 复跑前置）
//
// 解决缺陷：宣称 #25 复跑依赖"运行中 + 已授权 + 有当日数据"的实例、且旧文档没写清前置条件；
// #18 在干净克隆里也不好复跑。本脚本把"起实例 → 自动授权 → 播种 3 条增量夹具 → 打印端口"做成一条命令。
//
// 用法：
//   node tools\prepare-demo-instance.mjs            # 起隔离实例（默认端口 9336），备好环境后打印指令
//   node tools\prepare-demo-instance.mjs --port 9337
//   node tools\prepare-demo-instance.mjs --stop      # 停掉本脚本起的实例（只杀自己的标记，绝不碰用户实例）
//
// 之后即可按宣称复跑：
//   node tools\demo-claim-2.mjs --port 9336
//   node tools\coach-trigger.mjs --run-daily            （默认端口 9336，与 prepare 默认一致）
//
// 隔离口径：
//   · 进程隔离：独立 --user-data-dir（临时）+ 独立调试端口；若该端口已有实例在跑则拒绝（避免撞车）。
//   · 数据沿用主数据树（#25 的快照本就基于真实数据）；只往 data\coach\incremental.jsonl 写 3 条
//     demo-fixture-* 夹具（幂等：先剔除同名旧夹具再写，不覆盖真实增量行）。
//   · 授权走与人点「授权屏幕记录（本次会话）」同一条 /perception grant 命令（非后门）。

import { spawn } from 'node:child_process'
import { existsSync, mkdirSync, readFileSync, writeFileSync, rmSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { PROJECT_ROOT, dataPath, logPath } from '../packages/core/src/safefs.mjs'
import { countOrbAll, killMarked, mkMark, orbUdata, ORB_ELECTRON } from './_orb-proc.mjs'

const argv = process.argv.slice(2)
const arg = (n, d) => { const i = argv.indexOf(n); return i >= 0 && argv[i + 1] !== undefined ? argv[i + 1] : d }
const PORT = Number(arg('--port', 9336))
const ELECTRON = ORB_ELECTRON
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const STATE = join(PROJECT_ROOT, 'data', 'demo-instance.json')
const COACH_DIR = dataPath('coach')
const INCREMENTAL = join(COACH_DIR, 'incremental.jsonl')
const PERCEPTION_LOG = logPath('perception.jsonl')
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

function stop() {
  try {
    if (existsSync(STATE)) {
      const st = JSON.parse(readFileSync(STATE, 'utf8'))
      if (st && st.mark) killMarked(st.mark)
      rmSync(STATE, { force: true })
      console.log('[prepare] 已停止演示实例（mark=' + (st && st.mark) + '，port=' + (st && st.port) + '）')
    } else {
      console.log('[prepare] 无 data\\demo-instance.json，未发现由本脚本启动的实例（跳过）')
    }
  } catch (e) { console.error('[prepare] --stop 失败：' + String((e && e.message) || e)) }
  process.exit(0)
}
if (argv.includes('--stop')) stop()

// ---------- 端口占用预检（拒绝与已有实例撞车，不误杀用户实例） ----------
async function portBusy() {
  try {
    const r = await fetch(`http://127.0.0.1:${PORT}/json/list`)
    const l = await r.json()
    return Array.isArray(l) && l.length > 0
  } catch { return false }
}

// ---------- CDP 工具 ----------
async function findTarget(t = 40000) {
  const d = Date.now() + t
  while (Date.now() < d) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const l = await r.json()
      const p = l.find((x) => x.type === 'page' && x.webSocketDebuggerUrl && /floating\.html/i.test(String(x.url || '')))
      if (p) return p
    } catch { /* 等 */ }
    await sleep(350)
  }
  return null
}
function cdpConnect(wsUrl) {
  const ws = new WebSocket(wsUrl)
  let seq = 0
  const pending = new Map()
  const ready = new Promise((res, rej) => { ws.addEventListener('open', () => res()); ws.addEventListener('error', () => rej(new Error('ws'))) })
  ws.addEventListener('message', (ev) => {
    let m = null
    try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
    if (!m || !m.id) return
    const p = pending.get(m.id); if (!p) return
    pending.delete(m.id)
    if (m.error) p.rej(new Error(JSON.stringify(m.error))); else p.res(m.result)
  })
  const send = (method, params) => new Promise((res, rej) => { const id = ++seq; pending.set(id, { res, rej }); ws.send(JSON.stringify({ id, method, params })) })
  return { ready, send, close: () => { try { ws.close() } catch { /* noop */ } } }
}
async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r && r.exceptionDetails) throw new Error('ev: ' + JSON.stringify(r.exceptionDetails).slice(0, 200))
  return r && r.result ? r.result.value : undefined
}

// ---------- 播种 3 条增量夹具（幂等：剔除旧 demo-fixture-* 再写） ----------
function seedFixtures() {
  mkdirSync(COACH_DIR, { recursive: true })
  const nowIso = new Date().toISOString()
  const existing = existsSync(INCREMENTAL)
    ? readFileSync(INCREMENTAL, 'utf8').split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
    : []
  const realRows = existing.filter((r) => !String(r.frameId || '').startsWith('demo-fixture-'))
  const seed = [
    { app: 'Acrobat', intent: '学习', text: '屏幕：微电网 MPC 两阶段调度论文第 4 节，模型预测控制与下垂控制对比表' },
    { app: 'Zotero', intent: '工作', text: '屏幕：Zotero 文献库按综合能源方向整理论文，导出 bib 供报告引用' },
    { app: 'Excel', intent: '工作', text: '屏幕：Excel 整理仿真结果，光伏出力与负荷曲线对比，准备制图' },
  ].map((s, i) => ({
    ts: nowIso,
    window: s.app,
    process: s.app,
    text: s.text,
    frameId: 'demo-fixture-' + (i + 1),
    textSha256: 'demo-fx-sha-' + (i + 1),
    structured: { app: s.app, intent: s.intent, topic: s.text.slice(0, 20) },
    triggerSource: 'perception',
  }))
  const lines = [...realRows, ...seed].map((r) => JSON.stringify(r)).join('\n') + '\n'
  writeFileSync(INCREMENTAL, lines, 'utf8')
  return seed.length
}

let child = null
let cdp = null
let mark = null
try {
  if (await portBusy()) {
    console.error(`[prepare] ✗ 端口 ${PORT} 上已有实例在跑。演示要独占端口，请先关闭它，或换 --port。`)
    process.exit(1)
  }
  if (countOrbAll() > 0) console.log('[prepare] 提示：检测到已有 research-orb 实例在跑（不同端口）。本演示用独立端口 ' + PORT + '，不影响它们。')

  mark = mkMark('demo-instance')
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  // 关键：数据沿用主数据树（删掉隔离环境变量），与 coach-trigger / demo-claim-2 读同一份 data\logs
  delete env.ORB_DATA_DIR
  delete env.ORB_LOG_DIR
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(mark)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN],
    { cwd: PROJECT_ROOT, env, stdio: 'ignore', detached: true })
  child.unref()
  console.log('[prepare] 已启动隔离实例 pid=' + child.pid + '（port=' + PORT + '），等待 CDP…')

  const target = await findTarget()
  if (!target) throw new Error('CDP 未就绪（' + PORT + ' 无 floating.html）')
  cdp = cdpConnect(target.webSocketDebuggerUrl)
  await cdp.ready
  await cdp.send('Runtime.enable')
  let bridge = false
  const dl = Date.now() + 30000
  while (Date.now() < dl) {
    try { bridge = await ev(cdp, 'typeof globalThis.__s5 === "object" && !!(globalThis.__ro || globalThis.researchOrb)'); if (bridge) break } catch { /* 等 */ }
    await sleep(400)
  }
  if (!bridge) throw new Error('渲染层桥 __ro/__s5 未就绪')

  // 自动授权（与人点同一按钮/同一命令/同一审计）
  await ev(cdp, `globalThis.researchOrb.send('ui', { type:'plugin:command', name:'perception', args:'grant session' })`)
  let granted = false
  const gdl = Date.now() + 15000
  while (Date.now() < gdl) {
    await sleep(600)
    try {
      if (existsSync(PERCEPTION_LOG)) {
        const txt = readFileSync(PERCEPTION_LOG, 'utf8')
        if (/consent-granted/.test(txt)) { granted = true; break }
      }
    } catch { /* 等 */ }
    const consent = await ev(cdp, `(() => { try { return (globalThis.__ro && globalThis.__ro.state && globalThis.__ro.state.consent) || null } catch(e){ return null } })()`).catch(() => null)
    if (consent === 'session') { granted = true; break }
  }
  if (!granted) console.log('[prepare] ⚠ 15s 内未见授权生效，继续（可稍后手动 /perception grant session）')

  const seeded = seedFixtures()
  mkdirSync(join(PROJECT_ROOT, 'data'), { recursive: true })
  writeFileSync(STATE, JSON.stringify({ mark, port: PORT, pid: child.pid, startedAt: new Date().toISOString(), seeded }, null, 2), 'utf8')

  console.log('\n[prepare] ✓ 演示环境已备齐：')
  console.log('  端口 PORT     = ' + PORT + '（PID ' + child.pid + '）')
  console.log('  授权           = ' + (granted ? '会话 4h（consent-granted 已落审计）' : '未确认，请手动授权'))
  console.log('  当日数据       = 已播种 ' + seeded + ' 条增量夹具（data\\coach\\incremental.jsonl）')
  console.log('\n  按宣称复跑：')
  console.log('    node tools\\demo-claim-2.mjs --port ' + PORT)
  console.log('    node tools\\coach-trigger.mjs --run-daily' + (PORT === 9336 ? '' : ` --port ${PORT}`))
  console.log('\n  停止实例：node tools\\prepare-demo-instance.mjs --stop')
  try { cdp.close() } catch { /* noop */ }
  process.exit(0)
} catch (e) {
  console.error('[prepare] ✗ ' + String((e && e.message) || e))
  try { if (cdp) cdp.close() } catch { /* noop */ }
  if (mark) killMarked(mark)
  process.exit(1)
}
