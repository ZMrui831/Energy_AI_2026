// tools/accept-s29-leankit.mjs —— S29·阶段1 广进 kit 落地验收（≥10 项）。
// 单行复跑：node tools\accept-s29-leankit.mjs
// 证据：data\logs\s29-leankit-accept.json
import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync, statSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const NODE = process.execPath
const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 240), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's29-leankit')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(WORK, { recursive: true })

function runNode(script, args = [], cwd = PROJECT_ROOT) {
  return spawnSync(NODE, [script, ...args], { cwd, encoding: 'utf8', timeout: 60000, env: { ...process.env, NODE_OPTIONS: '' } })
}
function sha256File(p) { return createHash('sha256').update(readFileSync(p)).digest('hex') }

try {
  // ① kit 8 文件原样落地 tools\lean-kit\（与源逐文件 sha256 一致）
  // S67·3-C：不写死版本号——自动发现 Desktop 下最高版本 裁员广进-x.y.z\kit
  const SRC = (() => {
    try {
      const base = 'D:/Desktop'
      const cands = readdirSync(base).filter((n) => /^裁员广进-\d+\.\d+\.\d+$/.test(n)).sort((a, b) => {
        const va = a.split('-')[1].split('.').map(Number), vb = b.split('-')[1].split('.').map(Number)
        for (let i = 0; i < 3; i++) if (va[i] !== vb[i]) return va[i] - vb[i]
        return 0
      })
      if (cands.length) return join(base, cands[cands.length - 1], 'kit')
    } catch { /* ignore */ }
    return 'D:/Desktop/裁员广进-0.5.2/kit'
  })()
  const DST = join(PROJECT_ROOT, 'tools', 'lean-kit')
  const files = ['README.md', 'policy-lint.mjs', 'policy.example.json', 'policy.schema.json', 'portability.md', 'prompt-pagination.md', 'eval/sample.jsonl', 'eval/summarize-calls.mjs']
  const hashRows = []
  let kitOk = true
  for (const f of files) {
    const sp = join(SRC, f), dp = join(DST, f)
    if (!existsSync(sp) || !existsSync(dp)) { kitOk = false; hashRows.push({ file: f, ok: false, note: '缺失' }); continue }
    const a = sha256File(sp), b = sha256File(dp)
    hashRows.push({ file: f, src: a.slice(0, 16), dst: b.slice(0, 16), same: a === b })
    if (a !== b) kitOk = false
  }
  check('L1 kit 8 文件原样落地 tools\\lean-kit\\（sha256 逐文件一致）', kitOk && files.length === 8, JSON.stringify(hashRows.map((r) => r.file + ':' + (r.same ? '同' : '异'))))

  // ② policy FAIL=0（C1–C8 全 PASS）+ 工具数断言 27
  const policy = JSON.parse(readFileSync(join(PROJECT_ROOT, 'data', 'lean-policy.json'), 'utf8'))
  const agentTools = JSON.parse(readFileSync(join(PROJECT_ROOT, 'data', 'agent-tools.json'), 'utf8'))
  check('L2 lean-policy 关键值为真实值（maxTools=27 与导出清单一致）', policy.tools.maxTools === agentTools.tools.length && agentTools.tools.length === 27 && policy.rateLimit.requestsPerMinute === 10 && policy.output.truncationBanner === 'Found {shown} of {total}')
  const lint1 = runNode(join('tools', 'lean-kit', 'policy-lint.mjs'), ['--policy', 'data/lean-policy.json', '--agent-config', 'data/agent-tools.json'])
  let lint1Json = null
  try { lint1Json = JSON.parse((lint1.stdout || '').trim().split('\n').pop()) } catch { /* noop */ }
  check('L3 policy-lint --agent-config：PASS=8 FAIL=0 UNVERIFIED=0', !!lint1Json && lint1Json.fail === 0 && lint1Json.unverified === 0 && lint1Json.pass === 8, JSON.stringify(lint1Json && { pass: lint1Json.pass, fail: lint1Json.fail, unverified: lint1Json.unverified }))

  // ③ 三处横幅真实出现（support.truncate / fenceToolResult / fs.read 行内）
  const { truncate } = await import('../packages/core/src/tools/impl/support.mjs')
  const { fenceToolResult } = await import('../packages/core/src/agent.mjs')
  const t1 = truncate('微电网'.repeat(500), 100, '字符')
  const t2 = fenceToolResult('fs.read', 'ok', '内容'.repeat(5000))
  const fsSrc = readFileSync(join(PROJECT_ROOT, 'packages', 'core', 'src', 'tools', 'impl', 'fs.mjs'), 'utf8')
  check('L4 横幅口径 Found {shown} of {total} 三处真实出现', /Found 100 of 1500 字符/.test(t1.text) && /Found 6000 of 10000 字符/.test(t2) && /Found \$\{maxLine\} of \$\{ln.length\} 字符（行内截断）/.test(fsSrc), 'support.truncate + fenceToolResult + fs.read 行内')

  // ④ E1 对照：修复后（截断有+报总数）PASS；反证（截断有+不报）FAIL——证明 lint 真把关
  const goodObs = join(WORK, 'good.jsonl')
  writeFileSync(goodObs, JSON.stringify({ tool: 'fs.read', args: { path: 'big.txt' }, returnBytes: 65536, truncated: true, shownMatches: 0, totalMatches: 0, reportedTotal: true, modelAnswer: '共 1500 字符，已显示前 100（Found 100 of 1500）', usage: {} }) + '\n', 'utf8')
  const lint2 = runNode(join('tools', 'lean-kit', 'policy-lint.mjs'), ['--policy', 'data/lean-policy.json', '--observed', goodObs])
  const e1Good = JSON.parse((lint2.stdout || '').trim().split('\n').pop()).checks.find((c) => c.id === 'E1')
  const badObs = join(WORK, 'bad.jsonl')
  writeFileSync(badObs, JSON.stringify({ tool: 'fs.read', args: { path: 'big.txt' }, returnBytes: 65536, truncated: true, shownMatches: 0, totalMatches: 0, reportedTotal: false, modelAnswer: '文件内容就是前 100 字符这些', usage: {} }) + '\n', 'utf8')
  const lint3 = runNode(join('tools', 'lean-kit', 'policy-lint.mjs'), ['--policy', 'data/lean-policy.json', '--observed', badObs])
  const e1Bad = JSON.parse((lint3.stdout || '').trim().split('\n').pop()).checks.find((c) => c.id === 'E1')
  check('L5 E1 判定双向有效：修复后 PASS / 反证（截断不报总数）FAIL', e1Good.verdict === 'PASS' && e1Bad.verdict === 'FAIL', `good=${e1Good.verdict} bad=${e1Bad.verdict}`)

  // ⑤ calls-from-usage 适配器：fixture usage → calls schema（取不到写 null，不编造）
  // D25 修复：本项检验的是【转换契约】，不该依赖真实 data/logs/usage.jsonl 非空
  const fxUsage = join(WORK, 'fixture-usage.jsonl')
  const fxRows = []
  for (let k = 0; k < 60; k++) {
    fxRows.push(JSON.stringify({ ts: new Date(1750000000000 + k * 1000).toISOString(), taskClass: k % 3 === 0 ? 'extract' : k % 3 === 1 ? 'summarize' : 'score-plan', tier: k % 3 === 0 ? 'cheap' : 'flagship', providerId: 'fixture', model: 'fixture-model', fallback: false, ok: true, ms: 100 + k, tokens: 100 + k }))
  }
  writeFileSync(fxUsage, fxRows.join('\n') + '\n', 'utf8')
  const callsOut = join(WORK, 'calls.jsonl')
  const adapt = runNode(join('tools', 'calls-from-usage.mjs'), ['--in', fxUsage, '--out', callsOut])
  const callRows = readFileSync(callsOut, 'utf8').trim().split('\n').filter(Boolean).map((l) => JSON.parse(l))
  const keysOk = callRows.every((r) => 'returnBytes' in r && 'truncated' in r && 'shownMatches' in r && 'totalMatches' in r && 'reportedTotal' in r && r.usage && typeof r.usage === 'object')
  check('L6 calls-from-usage：fixture usage→calls schema，缺字段为 null 不编造', callRows.length === 60 && keysOk, `rows=${callRows.length} keysOk=${keysOk} sample=${JSON.stringify(callRows[0] || null).slice(0, 120)}`)

  // ⑥ 分页契约在 system（≤120 token）
  const { PAGINATION_PROMPT } = await import('../packages/core/src/pagination-prompt.mjs')
  const tok = Math.ceil(PAGINATION_PROMPT.length / 2)
  check(`L7 分页契约进 system 且 ≤120 token（实测 ${tok}）`, tok <= 120 && PAGINATION_PROMPT.includes('必须报告 Y') && PAGINATION_PROMPT.includes('offset'), PAGINATION_PROMPT.split('\n')[0])
  const mainSrc = readFileSync(join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs'), 'utf8')
  check('L8 main.mjs 已接线分页契约段（profileSys 拼接）', /PAGINATION_PROMPT/.test(mainSrc) && /joined \? joined \+ '\\n' \+ PAGINATION_PROMPT : PAGINATION_PROMPT/.test(mainSrc))

  // ⑦ 真实问答样例：一次真实工具截断的完整链路（构造大文件 → truncate → banner）
  const bigFile = join(WORK, 'big.txt')
  writeFileSync(bigFile, '微电网逆变器'.repeat(400), 'utf8') // 6×400 = 2400 字
  const realTrunc = truncate(readFileSync(bigFile, 'utf8'), 100, '字符')
  check('L9 真实截断样例可复现（大文件 2400 字 → Found 100 of 2400）', /Found 100 of 2400 字符/.test(realTrunc.text) && realTrunc.truncated === true, realTrunc.text.split('\n').pop())

  // ⑧ kit 只读未改（源目录哈希仍与落地一致——反向验证）
  let srcUnchanged = true
  for (const f of files) {
    const sp = join(SRC, f)
    if (existsSync(sp) && sha256File(sp) !== hashRows.find((r) => r.file === f).src + hashRows.find((r) => r.file === f).src) { /* 16 位前缀比对见下 */ }
  }
  check('L10 源 kit 未被改动（对比首轮记录的 sha256 前缀）', hashRows.every((r) => r.src === sha256File(join(SRC, r.file)).slice(0, 16)))
} catch (e) {
  check('L0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 240))
} finally {
  rmSync(WORK, { recursive: true, force: true })
}

const pass = items.filter((i) => i.ok).length
const fail = items.length - pass
const out = { tool: 'accept-s29-leankit', at: new Date().toISOString(), total: items.length, pass, fail, items }
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's29-leankit-accept.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # accept-s29-leankit: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 证据 -> data/logs/s29-leankit-accept.json`)
process.exit(fail === 0 ? 0 : 1)
