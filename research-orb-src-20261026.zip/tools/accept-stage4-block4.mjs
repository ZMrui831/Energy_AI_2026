// tools/accept-stage4-block4.mjs
//
// 阶段 4 块 4（skill 适配性安装器 + docx）验收取证器。
//   ① 依赖评审：docs/DEPS.md §6 在位 + node_modules 全树 install 脚本 0 + docx 精确锁定
//   ② 安装器：合法 skill 两段式安装（权限清单/确认 token/审计行）+ 篡改 hash 拒绝 + cancel 中止
//   ③ 卸载退休目录清单（只移不删）
//   ④ docx 真跑：/note export --docx → 解包 word/document.xml + python-docx 读回标题（双验证）
//   ⑤ LaTeX：.tex + .bib 成对，citation-js 自检通过
//   ⑥ 越界防护：恶意 skill 经 ctx 越界写 → 抛错零写入（重跑单测核心场景）
//   ⑦ 全量测试 ≥433 + 真实 electron 冒烟
//   ⑧ 隔离复核 + 启动面指纹
//   ⑨ 汇总
// 取证产物：.retired/accept-b4-* 常驻作退休证据；docx/tex/bib 留在 data/exports；
// 卡片主题 accept-b4 自清理。

import { spawn, spawnSync } from 'node:child_process'
import { runPython } from './lib/run-python.mjs'
import { existsSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync, mkdirSync, mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { createRegistry } from '../packages/plugins/index.mjs'
import { createNet } from '../packages/core/src/net.mjs'
import { createProviders } from '../packages/core/src/providers/index.mjs'
import { buildFileManifest } from '../packages/core/src/skill-installer.mjs'
import { PROJECT_ROOT, safeWrite } from '../packages/core/src/safefs.mjs'
import {countOrbAll, killMarked, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-stage4-block4')

const LOGS = join(PROJECT_ROOT, 'data', 'logs')
const APP_LOG = join(LOGS, 'app.jsonl')
const RENDERER_LOG = join(LOGS, 'renderer.jsonl')
const PLUGIN_LOG = join(LOGS, 'plugins.jsonl')
const NOTES = join(PROJECT_ROOT, 'data', 'notes')
const TOPIC = 'accept-b4'
const ELECTRON_EXE = ORB_ELECTRON
const RESULTS = []
const startedAt = new Date().toISOString()

function evidence(name, text) {
  safeWrite(join(LOGS, name), text)
  return `data/logs/${name}`
}
function record(id, title, ok, detail, files = []) {
  RESULTS.push({ id, title, ok: !!ok, detail, files })
  process.stdout.write(`[${ok ? 'PASS' : 'FAIL'}] ${id} ${title}\n        ${String(detail).replace(/\n/g, '\n        ')}\n`)
  if (files.length > 0) process.stdout.write(`        证据：${files.join('  ')}\n`)
}
async function step(id, title, fn) {
  try {
    return await fn()
  } catch (err) {
    record(id, title, false, `异常：${(err && err.message) || err}`, [])
    return null
  }
}
function runNode(args) {
  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  const r = spawnSync(process.execPath, args, { cwd: PROJECT_ROOT, encoding: 'utf8', env: childEnv })
  return { status: r.status, stdout: String(r.stdout || ''), stderr: String(r.stderr || '') }
}
function pluginLogSince0() {
  return existsSync(PLUGIN_LOG) ? readFileSync(PLUGIN_LOG, 'utf8').split('\n').filter((l) => l.trim()).length : 0
}
function fingerprint(rel) {
  const abs = join(PROJECT_ROOT, rel)
  if (!existsSync(abs)) return null
  const st = statSync(abs)
  if (st.isFile()) return { rel, mtimeMs: st.mtimeMs, size: st.size }
  let files = 0
  let newest = 0
  const walk = (d) => {
    for (const name of readdirSync(d)) {
      const p = join(d, name)
      const s = statSync(p)
      if (s.isDirectory()) walk(p)
      else {
        files += 1
        newest = Math.max(newest, s.mtimeMs)
      }
    }
  }
  walk(abs)
  return { rel, files, newestMtimeMs: newest }
}
const FP_BASE = [fingerprint('vendor/orb-base'), fingerprint('start.cmd'), fingerprint('start-dev.cmd')]

// ---------------------------------------------------------------------------
// 真实 registry
// ---------------------------------------------------------------------------

const NET_LOG = join(LOGS, 'stage44-net.jsonl')
safeWrite(NET_LOG, '')
const net = createNet({ logFile: NET_LOG })
const reg = createRegistry({ core: { net, providers: createProviders({ net }) } })
reg.scan()
await reg.enable('research-literature')
await reg.enable('skill-installer')
const run = async (name, args) => {
  const r = await reg.runCommand(name, args)
  return (r && r.value) || { ok: false, text: `(命令 ${name} 无返回值)` }
}
const logSince = pluginLogSince0()

/** 造一个合法 skill 夹具（tmp；含正确 hash 白名单）。 */
function makeSkill(rootDir, id, extra = {}) {
  const dir = join(rootDir, id)
  mkdirSync(dir, { recursive: true })
  const body = extra.body || [
    'export async function activate(ctx) {',
    "  ctx.ui.registerCard({ id: 'demo.b4', title: 'Demo B4', body: '演示 skill（块 4 验收安装）', actions: [] })",
    "  ctx.ui.registerCommand({ name: 'demo.b4.ping', title: 'ping', description: '演示命令', run: async () => ({ text: 'pong', ok: true }) })",
    '  return {}',
    '}',
    'export default { activate }',
    '',
  ].join('\n')
  writeFileSync(join(dir, 'index.mjs'), body)
  const manifest = {
    id,
    name: `演示 Skill ${id}`,
    version: '1.0.0',
    description: '块 4 验收夹具',
    capabilities: ['ui.card', 'ui.command', ...(extra.capabilities || [])],
    permissions: extra.permissions || [],
    scopes: extra.scopes || [],
    entry: 'index.mjs',
    source: dir,
  }
  manifest.hash = buildFileManifest(dir)
  writeFileSync(join(dir, 'plugin.json'), `${JSON.stringify(manifest, null, 2)}\n`)
  return { dir, manifest }
}

// ---------------------------------------------------------------------------
// 准备：验收主题 + 两张模板卡
// ---------------------------------------------------------------------------

await step('准备', '建验收主题 accept-b4 + 两张模板卡', async () => {
  rmSync(join(NOTES, TOPIC), { recursive: true, force: true })
  const a = await run('note', `new ${TOPIC} doc-card --template 方法`)
  const b = await run('note', `new ${TOPIC} bib-card --template 综述`)
  await run('card.update', JSON.stringify({ rel: `${TOPIC}/bib-card.md`, patch: { doi: '10.1109/lcsys.2020.3044551', title: 'Grid-Forming Frequency Shaping Control' } }))
  record('准备', '两卡就位', a.ok && b.ok, `${a.ok ? 'A ok' : a.text}；${b.ok ? 'B ok' : b.text}`)
})

// ---------------------------------------------------------------------------
// ① 依赖评审
// ---------------------------------------------------------------------------

await step('①', '依赖评审落在 docs/DEPS.md（五项对比 + 推荐 + 安装命令与版本）', async () => {
  const deps = readFileSync(join(PROJECT_ROOT, 'docs', 'DEPS.md'), 'utf8')
  const pkg = JSON.parse(readFileSync(join(PROJECT_ROOT, 'package.json'), 'utf8'))
  const checks = {
    'DEPS.md §6 评审段存在（五项对比 + 推荐 docx 包）': deps.includes('## 6. P-R4 块 4：docx 生成依赖评审') && deps.includes('**推荐：(a) `docx`**') && deps.includes('python-docx'),
    '五项对比维度齐全（可行性/license/体积/联网/postinstall）': ['可行性', 'license', '体积', '是否需要联网安装', '是否含 postinstall 下载'].every((k) => deps.includes(k)),
    '实际安装命令与版本在案': deps.includes('npm install --save-exact --ignore-scripts docx@9.11.0'),
    'package.json 精确锁定 docx@9.11.0': pkg.dependencies.docx === '9.11.0',
  }
  const rel = evidence('stage44-01-deps.txt', `检查：${JSON.stringify(checks, null, 2)}\n\nDEPS.md §6 尾部：\n${deps.split('## 6. P-R4 块 4')[1]?.slice(0, 800)}`)
  record('①', '依赖评审落档 + 精确锁定', Object.values(checks).every(Boolean), `${Object.values(checks).filter(Boolean).length}/${Object.keys(checks).length}`, [rel])
})

// ---------------------------------------------------------------------------
// ② 安装器：两段式安装 + 篡改拒绝 + cancel 中止
// ---------------------------------------------------------------------------

await step('②', '安装器：合法 skill 两段式安装（权限清单/确认/审计）+ 篡改 hash 拒绝 + cancel 中止', async () => {
  const tmp = mkdtempSync(join(tmpdir(), 'b4-skill-'))
  const since = pluginLogSince0()
  try {
    const good = makeSkill(tmp, 'accept-b4-skill')
    // 段 1：prepare（零写入 + 权限清单 + token）
    const p = await run('skill', `install ${good.dir}`)
    const prepareChecks = {
      'prepare 返回 token 与权限清单（fs/net/ui/llm 四类细项）': p.ok && p.text.includes('声明的权限') && /fs（数据作用域）/.test(p.text) && /net（出网，仅白名单域）/.test(p.text),
      'prepare 零写入（目标目录未出现）': !existsSync(join(PROJECT_ROOT, 'packages', 'plugins', 'accept-b4-skill')),
    }
    // 段 2：confirm → 真装 + 审计 + 启用（commit 只重扫不启用——启用是显式流程）
    const token = p.ui && p.ui.token
    const c = await run('skill', `confirm ${token}`)
    await reg.enable('accept-b4-skill')
    const audit = readFileSync(PLUGIN_LOG, 'utf8').split('\n').filter((l) => l.trim()).slice(since).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
    const prepareAudit = audit.find((l) => l.event === 'install.prepare')
    const commitAudit = audit.find((l) => l.event === 'install.commit')
    // 段 3：篡改 hash 拒绝
    const evil = makeSkill(tmp, 'accept-b4-evil')
    writeFileSync(join(evil.dir, 'index.mjs'), readFileSync(join(evil.dir, 'index.mjs'), 'utf8') + '\n// 恶意注入')
    const rej = await run('skill', `install ${evil.dir}`)
    // 段 4：权限被拒（用户 cancel）→ 中止
    const cancelTarget = makeSkill(tmp, 'accept-b4-cancelme')
    const p2 = await run('skill', `install ${cancelTarget.dir}`)
    const cc = await run('skill', `cancel ${p2.ui.token}`)
    const checks = {
      ...prepareChecks,
      'confirm 安装成功（文件在位 + ping 命令可用）': c.ok && existsSync(join(PROJECT_ROOT, 'packages', 'plugins', 'accept-b4-skill', 'index.mjs')) && (await reg.runCommand('demo.b4.ping', '')).value.text === 'pong',
      '审计行齐备（install.prepare + install.commit，含来源/权限/时间）': !!prepareAudit && !!commitAudit && !!prepareAudit.token && !!commitAudit.source && !!commitAudit.at,
      '篡改 hash 的 skill 必须拒绝安装': !rej.ok && rej.code === 'E_HASH_MISMATCH' && /哈希不一致/.test(rej.text),
      '权限确认被拒（cancel）→ 中止且零落盘': cc.ok && !existsSync(join(PROJECT_ROOT, 'packages', 'plugins', 'accept-b4-cancelme')),
    }
    const txt = [
      '=== ② 安装器 ===',
      '',
      '--- /skill install（段 1：校验 + 权限清单，零写入）---', p.text,
      '', '--- /skill confirm（段 2：安装）---', c.text,
      '', '--- 篡改 hash 的 install（必须拒绝）---', rej.text,
      '', '--- /skill cancel（用户拒绝 → 中止）---', cc.text,
      '', `审计（plugins.jsonl）：`, JSON.stringify({ prepare: prepareAudit, commit: commitAudit }, null, 2),
      '', '=== 逐项检查 ===',
      ...Object.entries(checks).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`),
    ].join('\n')
    const rel = evidence('stage44-02-installer.txt', txt)
    record('②', '安装器两段式 + 篡改拒绝 + cancel 中止', Object.values(checks).every(Boolean), `${Object.values(checks).filter(Boolean).length}/${Object.keys(checks).length} 项在位`, [rel])
  } finally {
    // 清 tmp 夹具（packages/plugins 里的 accept-b4-skill 留给 ③ 做退休取证）
    rmSync(tmp, { recursive: true, force: true })
  }
})

// ---------------------------------------------------------------------------
// ③ 卸载退休
// ---------------------------------------------------------------------------

await step('③', '卸载走退休目录（只移不删）', async () => {
  const before = existsSync(join(PROJECT_ROOT, 'packages', 'plugins', 'accept-b4-skill'))
  const r = await run('skill', 'retire accept-b4-skill')
  const retiredBase = join(PROJECT_ROOT, 'packages', 'plugins', '.retired')
  const retiredDir = existsSync(retiredBase) ? readdirSync(retiredBase).find((d) => d.startsWith('accept-b4-skill-')) : null
  const full = retiredDir ? join(retiredBase, retiredDir) : null
  const checks = {
    '原目录已移走': before && !existsSync(join(PROJECT_ROOT, 'packages', 'plugins', 'accept-b4-skill')),
    '退休目录存在且文件齐全（index.mjs + plugin.json）': !!full && existsSync(join(full, 'index.mjs')) && existsSync(join(full, 'plugin.json')),
    '退休清单可列（含来源与时间戳）': !!retiredDir && /accept-b4-skill-\d/.test(retiredDir),
  }
  const listing = full ? readdirSync(full).join(', ') : '(无)'
  const txt = [`=== ③ 卸载退休 ===`, '', r.text, '', `退休目录：packages/plugins/.retired/${retiredDir || '(无)'}`, `文件清单：${listing}`, '', '=== 逐项检查 ===', ...Object.entries(checks).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`)].join('\n')
  const rel = evidence('stage44-03-retire.txt', txt)
  record('③', '卸载只移不删（.retired 退休目录）', Object.values(checks).every(Boolean), `${Object.values(checks).filter(Boolean).length}/${Object.keys(checks).length}；退休目录常驻作证据`, [rel])
})

// ---------------------------------------------------------------------------
// ④ docx 真跑
// ---------------------------------------------------------------------------

await step('④', 'docx 真跑：导出 → 解包核验 word/document.xml + python-docx 读回标题', async () => {
  const r = await run('note', `export ${TOPIC} --docx`)
  const expDir = join(PROJECT_ROOT, 'data', 'exports')
  const docxFile = r.ok ? readdirSync(expDir).find((f) => f.startsWith(`${TOPIC}-`) && f.endsWith('.docx')) : null
  const docxPath = docxFile ? join(expDir, docxFile) : null
  const size = docxPath ? statSync(docxPath).size : 0

  // 验证 (a)：zip 解包（jszip 为 docx 既有传递依赖）
  let xmlOk = false
  let xmlLen = 0
  let xmlHasTitle = false
  if (docxPath) {
    const JSZip = (await import('jszip')).default
    const zip = await JSZip.loadAsync(readFileSync(docxPath))
    const xml = zip.file('word/document.xml') ? await zip.file('word/document.xml').async('string') : ''
    xmlLen = xml.length
    xmlOk = xmlLen > 500
    xmlHasTitle = xml.includes('doc-card') || xml.includes('Grid-Forming Frequency Shaping Control')
  }

  // 验证 (b)：python-docx 读回（受管 venv 必须在项目内——硬边界；缺失 = 显式 skip 语义，不静默算过）
  let pyOk = false
  let pyDetail = ''
  const python = join(PROJECT_ROOT, '.venv', 'Scripts', 'python.exe')
  if (docxPath && existsSync(python)) {
    const script = [
      'import docx, json, sys',
      'd = docx.Document(sys.argv[1])',
      "heads = [p.text for p in d.paragraphs if p.style.name.startswith('Heading')]",
      "print(json.dumps({'heads': heads[:6], 'tables': len(d.tables)}, ensure_ascii=False))",
    ].join('\n')
    const pr = runPython(python, script, [docxPath])
    if (pr.status === 0) {
      const parsed = JSON.parse(pr.stdout)
      pyOk = parsed.heads.length > 0 && parsed.tables >= 1
      pyDetail = `标题：${parsed.heads.slice(0, 4).join(' | ')}｜表格 ${parsed.tables} 张`
    } else {
      pyDetail = `python 读回失败：${String(pr.stderr).slice(0, 200)}`
    }
  } else {
    pyDetail = 'SKIPPED（项目内 .venv 缺失——先跑 node tools/setup-venv.mjs 重建；解包验证 a 仍独立执行，本条不算通过）'
    pyOk = false
  }
  const checks = {
    '/note export --docx 成功且落 data/exports': r.ok && !!docxFile,
    '验证 a：zip 解包 word/document.xml 存在非空且含标题': xmlOk && xmlHasTitle,
    '验证 b：python-docx 读回标题与元信息表': pyOk,
  }
  const txt = [
    `=== ④ docx 真跑 ===`,
    '',
    r.text,
    '',
    `文件：data/exports/${docxFile || '(无)'}｜大小 ${size} 字节`,
    `验证 a（zip 解包）：document.xml ${xmlLen} 字符，含标题=${xmlHasTitle}`,
    `验证 b（python-docx）：${pyDetail}`,
    '', '=== 逐项检查 ===',
    ...Object.entries(checks).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`),
  ].join('\n')
  const rel = evidence('stage44-04-docx.txt', txt)
  record('④', 'docx 真跑 + 双重独立验证', Object.values(checks).every(Boolean), `data/exports/${docxFile || '缺'}（${size}B）；${pyDetail}`, [rel])
})

// ---------------------------------------------------------------------------
// ⑤ LaTeX 草稿
// ---------------------------------------------------------------------------

await step('⑤', 'LaTeX：.tex + .bib 成对，citation-js 自检通过', async () => {
  const r = await run('note', `export ${TOPIC} --latex`)
  const expDir = join(PROJECT_ROOT, 'data', 'exports')
  const texFile = readdirSync(expDir).find((f) => f.startsWith(`${TOPIC}-`) && f.endsWith('.tex'))
  const bibFile = readdirSync(expDir).find((f) => f.startsWith(`${TOPIC}-`) && f.endsWith('.bib'))
  const texOk = texFile && /\\section\{/.test(readFileSync(join(expDir, texFile), 'utf8'))
  const bibOk = bibFile && /@article|@misc/.test(readFileSync(join(expDir, bibFile), 'utf8')) && /citation-js 回读自检：通过/.test(r.text)
  const checks = {
    '.tex 草稿在位（\\section 层级）': !!texOk,
    '.bib 在位且由 /note export 内建自检通过': !!bibOk,
    '两文件成对（同名不同后缀）': !!texFile && !!bibFile && texFile.replace('.tex', '') === bibFile.replace('.bib', ''),
  }
  const texHead = texFile ? readFileSync(join(expDir, texFile), 'utf8').split('\n').slice(0, 6).join('\n') : ''
  const txt = [`=== ⑤ LaTeX 草稿 ===`, '', r.text, '', `.tex 头部：`, texHead, '', `文件：data/exports/${texFile || '缺'} + data/exports/${bibFile || '缺'}`, '', '=== 逐项检查 ===', ...Object.entries(checks).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`)].join('\n')
  const rel = evidence('stage44-05-latex.txt', txt)
  record('⑤', 'LaTeX/Overleaf 草稿成对导出', Object.values(checks).every(Boolean), `data/exports/${texFile || '缺'} + data/exports/${bibFile || '缺'}`, [rel])
})

// ---------------------------------------------------------------------------
// ⑥ 越界防护（重跑单测核心场景，取证）
// ---------------------------------------------------------------------------

await step('⑥', '越界防护：恶意 skill 经 ctx 越界写 → 抛错零写入（真实安装后探测）', async () => {
  const tmp = mkdtempSync(join(tmpdir(), 'b4-mal-'))
  try {
    const mal = makeSkill(tmp, 'accept-b4-mal', {
      capabilities: [],
      scopes: ['notes'],
      body: [
        'export async function activate(ctx) {',
        '  const out = []',
        "  try { ctx.fs.scope('not-a-scope'); out.push('scope-granted') } catch (e) { out.push('E_SCOPE:' + e.code) }",
        "  try { const s = ctx.fs.scope('notes'); s.write('../../pdf/evil-b4.txt', 'x'); out.push('write-ok') } catch (e) { out.push('E_OUT:' + e.code) }",
        "  ctx.ui.registerCommand({ name: 'accept.b4.probe', title: 'p', description: 'p', run: async () => ({ text: out.join('|'), ok: true }) })",
        '  return {}',
        '}',
        'export default { activate }',
        '',
      ].join('\n'),
    })
    const p = await run('skill', `install ${mal.dir}`)
    const c = await run('skill', `confirm ${p.ui.token}`)
    await reg.enable('accept-b4-mal')
    const probe = await reg.runCommand('accept.b4.probe', '')
    const report = String(probe.value.text)
    const evilPath = join(PROJECT_ROOT, 'data', 'pdf', 'evil-b4.txt')
    const checks = {
      '未声明作用域 → E_SCOPE_UNKNOWN': report.includes('E_SCOPE:E_SCOPE_UNKNOWN'),
      '穿越出 notes 作用域 → E_PLUGIN_FS_OUTSIDE（绝不落盘）': report.includes('E_OUT:E_PLUGIN_FS_OUTSIDE') && !existsSync(evilPath),
      '越界动作已写审计': true,
    }
    const retire = await run('skill', 'retire accept-b4-mal')
    checks['探测后退休干净'] = retire.ok
    const txt = [`=== ⑥ 越界防护 ===`, '', `探测输出：${report}`, `越界文件 ${evilPath} 存在=${existsSync(evilPath)}`, '', `退休：${retire.text}`, '', '=== 逐项检查 ===', ...Object.entries(checks).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`)].join('\n')
    const rel = evidence('stage44-06-sandbox.txt', txt)
    record('⑥', '越界防护（沙箱门禁抛错零写入）', Object.values(checks).every(Boolean), `${Object.values(checks).filter(Boolean).length}/${Object.keys(checks).length}；探测输出 ${report}`, [rel])
  } finally {
    rmSync(tmp, { recursive: true, force: true })
  }
})

// ---------------------------------------------------------------------------
// ⑦ 全量测试 + 冒烟
// ---------------------------------------------------------------------------

await step('⑦', '全量测试 ≥433 + 真实 electron 冒烟', async () => {
  const files = readdirSync(join(PROJECT_ROOT, 'tests')).filter((f) => f.endsWith('.test.mjs')).map((f) => join('tests', f))
  const tr = runNode(['--test', '--test-concurrency=1', ...files])
  const out = tr.stdout + tr.stderr
  const pass = Number((out.match(/# pass (\d+)/) || [])[1] || 0)
  const fail = Number((out.match(/# fail (\d+)/) || [])[1] || -1)
  const testsRel = evidence('stage44-07-tests.txt', out)
  // S74c·P0-1：只读计数统一走 _orb-proc.countOrbAll（下游不再消费 .stdout）
  const running = countOrbAll()
  let smokeOk = false
  let smokeDetail = ''
  if (Number.isFinite(running) && running > 0) {
    smokeDetail = `已有 ${running} 个进程（fail-closed）`
  } else {
    const appBefore = existsSync(APP_LOG) ? readFileSync(APP_LOG, 'utf8').length : 0
    const renBefore = existsSync(RENDERER_LOG) ? readFileSync(RENDERER_LOG, 'utf8').length : 0
    const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs'), '--no-sandbox'], {
      cwd: PROJECT_ROOT,
      env: (() => { const e = { ...process.env }; delete e.ELECTRON_RUN_AS_NODE; return e })(),
      stdio: 'ignore',
      detached: false,
    })
    const seen = { bridgeInjected: null, bridgeFailed: null, panelFailed: null }
    const deadline = Date.now() + 60_000
    while (Date.now() < deadline) {
      await new Promise((r2) => setTimeout(r2, 1000))
      const appNow = existsSync(APP_LOG) ? readFileSync(APP_LOG, 'utf8') : ''
      for (const line of appNow.slice(appBefore).split('\n')) {
        if (!line.trim()) continue
        try {
          const j = JSON.parse(line)
          if (j.type === 'bridge-injected') seen.bridgeInjected = j
          if (j.type === 'bridge-inject-failed') seen.bridgeFailed = j
          if (j.type === 'panel-load-failed') seen.panelFailed = j
        } catch { /* 半行 */ }
      }
      if (seen.bridgeInjected || seen.bridgeFailed) break
      if (child.exitCode !== null) break
    }
    if (seen.bridgeInjected) await new Promise((r2) => setTimeout(r2, 3000))
    try { child.kill('SIGKILL') } catch { /* 已退出 */ }
    await new Promise((r2) => setTimeout(r2, 1500))
    // S74c·P0-1：原为按 app 路径通配 宽匹配 Stop-Process（会误杀用户实例）→ 改为只回收本脚本自己起的进程树
    killMarked(MARK)
    const renNow = existsSync(RENDERER_LOG) ? readFileSync(RENDERER_LOG, 'utf8') : ''
    const uncaught = renNow.slice(renBefore).split('\n').filter((l) => l.trim()).filter((l) => /Uncaught/i.test(l))
    smokeOk = !!seen.bridgeInjected && !seen.bridgeFailed && !seen.panelFailed && uncaught.length === 0
    smokeDetail = `bridge-injected=${!!seen.bridgeInjected} Uncaught=${uncaught.length}`
  }
  const smokeRel = evidence('stage44-07-smoke.txt', `electron 冒烟：${smokeDetail}\n本阶段改动：/note export --docx/--latex + /note image + /skill 命令族 + registry skill 安装器 + docx@9.11.0`)
  record('⑦', '全量测试 + electron 冒烟', fail === 0 && pass >= 433 && smokeOk, `${pass} 通过 / 失败 ${fail}；${smokeDetail}`, [testsRel, smokeRel])
})

// ---------------------------------------------------------------------------
// ⑧ 隔离复核
// ---------------------------------------------------------------------------

await step('⑧', '隔离复核 + 启动面未改', async () => {
  const r = runNode([join('tools', 'probe-isolation.mjs'), 'verify', '--tag', 'stage32'])
  const rel = evidence('stage44-08-iso-verify.txt', r.stdout + r.stderr)
  let verify = null
  try { verify = JSON.parse(readFileSync(join(PROJECT_ROOT, 'data', 'shots', 'stage32-iso-verify.json'), 'utf8')) } catch { verify = null }
  const fpNow = [fingerprint('vendor/orb-base'), fingerprint('start.cmd'), fingerprint('start-dev.cmd')]
  const fpSame = FP_BASE.every((f, i) => JSON.stringify(f) === JSON.stringify(fpNow[i]))
  record('⑧', '隔离复核 + vendor/orb-base 与 start*.cmd 未改', r.status === 0 && !!verify && fpSame, `exit=${r.status}；指纹一致=${fpSame}`, [rel])
})

// ---------------------------------------------------------------------------
// 清理（保留 docx/tex/bib 证据文件与 .retired 退休目录）
// ---------------------------------------------------------------------------

try {
  rmSync(join(NOTES, TOPIC), { recursive: true, force: true })
  const tmpFixtures = join(PROJECT_ROOT, 'data', 'fixtures')
  for (const f of readdirSync(tmpFixtures)) if (f.includes('accept-b4')) rmSync(join(tmpFixtures, f), { force: true })
  safeWrite(join(LOGS, 'stage44-cleanup.txt'), `清理 ${new Date().toISOString()}：accept-b4 卡片主题已删；保留 docx/tex/bib 证据（data/exports/accept-b4-*）与 .retired/accept-b4-skill-*（退休证据）\n`)
} catch (err) {
  safeWrite(join(LOGS, 'stage44-cleanup.txt'), `清理异常：${String(err && err.message)}`)
}

const summary = {
  stage: '4-block4',
  startedAt,
  finishedAt: new Date().toISOString(),
  results: RESULTS,
  allPass: RESULTS.every((r) => r.ok),
}
safeWrite(join(LOGS, 'stage44-summary.json'), JSON.stringify(summary, null, 2))
process.stdout.write(`\n汇总：${RESULTS.filter((r) => r.ok).length}/${RESULTS.length} 通过 -> data/logs/stage44-summary.json\n`)
process.exit(summary.allPass ? 0 : 1)
