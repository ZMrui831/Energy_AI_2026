// tools/accept-stage3-1.mjs
//
// 阶段 3.1 验收取证器（主管判定"主体通过"后的 3 项必须补齐 + 1 项卫生）。
//
// 验收项（与任务书一一对应）：
//   ① 项目/阶段/里程碑端到端：真跑 /project new gfm → add-stage → /start gfm 文献综述
//      （真实计时 8 秒）→ /stop → done+milestone → /today；断言 data/projects/gfm.json、
//      data/timer/<today>.jsonl 的 start/stop 行带 projectId/stageId、日报把时间归到
//      电网构网型逆变器惯量支撑 / 文献综述（分项目 + 阶段子行）。
//   ② 加速数据不得污染真实进度：子进程 scale=60 跑一轮 + scale=1 跑一轮，/today 后
//      日报"专注时长"只等于 scale=1 部分，加速部分单列"测试/加速数据"区；
//      加速启动时 /start 文案显式提示"数据不计入进度"。
//   ③ 文档与实现逐字段对齐（ARCH/README 静态检查，任务在文档任务里做，此处贴命中）。
//   ④ 卫生：data\ 顶层只剩领域目录 + .chromium；应用启动 core-ready 且 userData 指向
//      data\.chromium（spawn electron 实测；GPU 崩溃为环境问题，对照证据另附）。
//   ⑤ 全量测试 ≥319 条全绿。
//   ⑥ 隔离复核：probe-isolation verify（对阶段 3 基线，证明本阶段零改动）+ baseline 留档。
//   ⑦ 汇报 ≤15 行由最终交付文本承担，此处输出 summary.json。
//
// 用法：node tools/accept-stage3-1.mjs
// 产物：data/logs/stage31-*.txt / .json + data/logs/stage31-summary.json

import { spawn, spawnSync } from 'node:child_process'
import { existsSync, readFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'

import { createCoreHost } from '../apps/desktop/core-host.mjs'
import { PROJECT_ROOT, safeWrite } from '../packages/core/src/safefs.mjs'
import { dayKeyOf } from '../packages/core/src/timer-store.mjs'
import { fmtDuration } from '../packages/core/src/report.mjs'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-stage3-1')

const LOGS = join(PROJECT_ROOT, 'data', 'logs')
const RESULTS = []

const startedAt = new Date().toISOString()

function evidence(name, text) {
  safeWrite(join(LOGS, name), text)
  return `data/logs/${name}`
}
function jsonEvidence(name, obj) {
  return evidence(name, JSON.stringify(obj, null, 2))
}
function record(id, title, ok, detail, files = []) {
  RESULTS.push({ id, title, ok: !!ok, detail, files })
  process.stdout.write(`[${ok ? 'PASS' : 'FAIL'}] ${id} ${title}\n        ${String(detail).replace(/\n/g, '\n        ')}\n`)
  if (files.length > 0) process.stdout.write(`        证据：${files.join('  ')}\n`)
}
async function step(id, title, fn) {
  try {
    return await fn()
  } catch (err) {
    record(id, title, false, `异常：${(err && err.message) || err}`, [])
    return null
  }
}
function runNode(args, { env = null } = {}) {
  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  if (env) Object.assign(childEnv, env)
  const r = spawnSync(process.execPath, args, { cwd: PROJECT_ROOT, encoding: 'utf8', env: childEnv })
  return { status: r.status, stdout: String(r.stdout || ''), stderr: String(r.stderr || '') }
}

// ---------------------------------------------------------------------------
// 前置：host + 清残留运行态 + 记录当天账本基线（按 sessionId 过滤，不拿全天总额冒充）
// ---------------------------------------------------------------------------

const host = createCoreHost()
const reg = host.registry
const enabled = await reg.enableAll()
process.stdout.write(`插件启用：${enabled.map((e) => `${e.id}:${e.enabled ? 'on' : 'off'}`).join('  ')}\n`)
const preState = host.timer.status()
if (preState.status !== 'idle') {
  host.timer.stop({ reason: 'accept-preclean' })
  process.stdout.write(`前置清理：磁盘上残留 ${preState.status} 会话，已收尾\n`)
}
const TODAY = dayKeyOf(Date.now())
process.stdout.write(`验收日期键：${TODAY}\n\n`)

// ---------------------------------------------------------------------------
// ① 项目/阶段/里程碑端到端
// ---------------------------------------------------------------------------

await step('①', '项目/阶段/里程碑端到端（真跑命令 + 断言账本与日报）', async () => {
  const trace = []
  const t = (label, r) => {
    trace.push(`$ ${label}\n  -> ok=${r.ok}${r.ok ? '' : ' code=' + r.code}\n${((r.value && r.value.text) || r.error || '').split('\n').map((l) => '  ' + l).join('\n')}`)
    return r
  }
  const newP = t('/project new gfm 电网构网型逆变器惯量支撑', await reg.runCommand('project', 'new gfm 电网构网型逆变器惯量支撑'))
  const addS = t('/project add-stage gfm 文献综述', await reg.runCommand('project', 'add-stage gfm 文献综述'))
  const startR = t('/start gfm 文献综述', await reg.runCommand('start', 'gfm 文献综述'))
  // 真实计时一小段（8 秒）：任务书要求"跑一小段真实计时"，这里用 wall clock 真等
  await new Promise((r) => setTimeout(r, 8000))
  const stopR = t('/stop', await reg.runCommand('stop', ''))
  const doneR = t('/project done gfm 文献综述 完成文献精读与综述初稿', await reg.runCommand('project', 'done gfm 文献综述 完成文献精读与综述初稿'))
  const todayR = t('/today', await reg.runCommand('today', ''))

  // --- 断言 1：data/projects/gfm.json ---
  const projFile = join(PROJECT_ROOT, 'data', 'projects', 'gfm.json')
  const proj = existsSync(projFile) ? JSON.parse(readFileSync(projFile, 'utf8')) : null
  const projOk =
    !!proj &&
    proj.id === 'gfm' &&
    proj.name === '电网构网型逆变器惯量支撑' &&
    Array.isArray(proj.stages) &&
    proj.stages.length === 1 &&
    proj.stages[0].name === '文献综述' &&
    proj.stages[0].done === true &&
    proj.stages[0].milestone === '完成文献精读与综述初稿'

  // --- 断言 2：timer 账本 start/stop 行带 projectId/stageId（按本次 sessionId 过滤）---
  const dayFile = join(PROJECT_ROOT, 'data', 'timer', `${TODAY}.jsonl`)
  const records = existsSync(dayFile)
    ? readFileSync(dayFile, 'utf8').split('\n').filter((l) => l.trim()).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
    : []
  const sessionId = startR.value && startR.value.ui && startR.value.ui.snapshot && startR.value.ui.snapshot.sessionId
  const mine = records.filter((r) => r.sessionId === sessionId)
  const startRow = mine.find((r) => r.type === 'start')
  const stopRow = mine.find((r) => r.type === 'stop')
  const segSum = mine.filter((r) => r.type === 'segment').reduce((s, r) => s + (Number(r.sec) || 0), 0)
  const ledgerOk =
    !!startRow && startRow.projectId === 'gfm' && startRow.stageId === 's1' &&
    !!stopRow && stopRow.projectId === 'gfm' && stopRow.stageId === 's1' &&
    segSum >= 7 && segSum <= 10 && // 真实 8 秒（调度余量），不猜不补
    stopRow.totalSec === segSum

  // --- 断言 3：日报把该段时间归到 电网构网型逆变器惯量支撑 / 文献综述 ---
  const dailyPath = join(PROJECT_ROOT, 'data', 'reports', `daily-${TODAY}.md`)
  const md = existsSync(dailyPath) ? readFileSync(dailyPath, 'utf8') : ''
  const progPath = join(PROJECT_ROOT, 'data', 'progress', `${TODAY}.json`)
  const prog = existsSync(progPath) ? JSON.parse(readFileSync(progPath, 'utf8')) : null
  const row = prog && prog.byProject.find((r) => r.projectId === 'gfm')
  const stageRow = row && (row.stages || []).find((s) => s.stageId === 's1')
  // 幂等口径：期望值从账本重算（当天 gfm/s1 的全部 segment 求和，排除加速会话）。
  // 不能写"只等于本次 8 秒"——重复跑验收会累加，第二轮必误报（与 ②c 同款思路）。
  const scaledIds = new Set(records.filter((r) => r.type === 'start' && r.timeScale != null && r.timeScale !== 1).map((r) => r.sessionId))
  const gfmSeg = records.filter((r) => r.type === 'segment' && r.projectId === 'gfm' && !scaledIds.has(r.sessionId))
  const expectedProjectSec = gfmSeg.reduce((s, r) => s + (Number(r.sec) || 0), 0)
  const expectedStageSec = gfmSeg.filter((r) => r.stageId === 's1').reduce((s, r) => s + (Number(r.sec) || 0), 0)
  const dailyOk =
    !!prog &&
    !!row &&
    row.focusSec === expectedProjectSec && // 精确相等：日报数字 == 账本重算（含本次会话）
    !!stageRow &&
    stageRow.stageName === '文献综述' &&
    stageRow.focusSec === expectedStageSec &&
    md.includes('- 电网构网型逆变器惯量支撑：' + fmtDuration(expectedProjectSec)) &&
    md.includes('  - 文献综述：' + fmtDuration(expectedStageSec))

  const txt = [
    '=== 命令轨迹 ===',
    ...trace,
    '',
    '=== data/projects/gfm.json ===',
    JSON.stringify(proj, null, 2),
    '',
    `=== data/timer/${TODAY}.jsonl（本次 sessionId=${sessionId}）===`,
    ...mine.map((r) => JSON.stringify(r)),
    `本段落账：${segSum}s（真实等待 8s）`,
    '',
    '=== 日报分项目段（节选） ===',
    ...md.split('\n').filter((l) => l.includes('电网构网型逆变器') || l.includes('文献综述')).map((l) => '  ' + l),
    '',
    '=== data/progress/' + TODAY + '.json（byProject 节选） ===',
    JSON.stringify(prog ? { focusSec: prog.focusSec, sessionCount: prog.sessionCount, byProject: prog.byProject, scaled: prog.scaled } : null, null, 2),
  ].join('\n')
  const rel = evidence('stage31-01-project-e2e.txt', txt)
  const jsonRel = jsonEvidence('stage31-01-project-e2e.json', {
    at: new Date().toISOString(),
    sessionId,
    segSum,
    project: proj,
    startRow, stopRow,
    dailyHasProject: md.includes('- 电网构网型逆变器惯量支撑：' + fmtDuration(expectedProjectSec)),
    dailyHasStage: md.includes('  - 文献综述：' + fmtDuration(expectedStageSec)),
    expectedProjectSec,
    expectedStageSec,
    progressByProject: prog ? prog.byProject : null,
  })
  const ok = newP.ok && addS.ok && startR.ok && stopR.ok && doneR.ok && todayR.ok && projOk && ledgerOk && dailyOk
  record('①', '项目/阶段/里程碑端到端：gfm.json 正确、账本行带 projectId/stageId、日报归到 gfm/文献综述', ok,
    `项目文件=${projOk ? 'OK' : 'FAIL'} 账本行=${ledgerOk ? 'OK' : 'FAIL'}（本段 ${segSum}s）日报分类=${dailyOk ? 'OK' : 'FAIL'}`, [rel, jsonRel])
  return { sessionId, segSum }
})

// ---------------------------------------------------------------------------
// ② 加速数据不得污染真实进度（scale=60 + scale=1 对照）
// ---------------------------------------------------------------------------

await step('②a', 'scale=60 加速探针（子进程）', async () => {
  const r = runNode([join('tools', 'probe-stage3-1.mjs'), 'fast'], { env: { RESEARCH_ORB_TIME_SCALE: '60' } })
  const rel = evidence('stage31-02a-scale-fast.txt', r.stdout + r.stderr)
  const last = r.stdout.trim().split('\n').filter(Boolean).pop() || '{}'
  let probe = null
  try { probe = JSON.parse(last) } catch { probe = null }
  const jsonRel = jsonEvidence('stage31-02a-scale-fast.json', { at: new Date().toISOString(), probe })
  const ok = !!probe && probe.timeScale === 60 && probe.startOk && probe.stopOk && probe.scaleWarn === true && probe.ledgerSec >= 60 && probe.ledgerSec <= 100 && probe.stopCompleted === true
  record('②a', 'scale=60：/start 显式提示"加速测试模式…不计入进度"，1 分钟番茄 ~1.3 秒真实走完', ok,
    `timeScale=${probe && probe.timeScale} 真实=${probe && probe.realMs}ms 落账=${probe && probe.ledgerSec}s 加速提示=${probe && probe.scaleWarn}`, [rel, jsonRel])
  return probe
})

await step('②b', 'scale=1 真实探针（子进程）', async () => {
  const r = runNode([join('tools', 'probe-stage3-1.mjs'), 'real'], { env: { RESEARCH_ORB_TIME_SCALE: '' } })
  const rel = evidence('stage31-02b-scale-real.txt', r.stdout + r.stderr)
  const last = r.stdout.trim().split('\n').filter(Boolean).pop() || '{}'
  let probe = null
  try { probe = JSON.parse(last) } catch { probe = null }
  const jsonRel = jsonEvidence('stage31-02b-scale-real.json', { at: new Date().toISOString(), probe })
  const ok = !!probe && probe.timeScale === 1 && probe.startOk && probe.stopOk && probe.scaleWarn === false && probe.ledgerSec >= 2 && probe.ledgerSec <= 7
  record('②b', 'scale=1：真实 3.5 秒只记 ~3.5 秒，无加速提示', ok,
    `timeScale=${probe && probe.timeScale} 真实=${probe && probe.realMs}ms 落账=${probe && probe.ledgerSec}s 加速提示=${probe && probe.scaleWarn}`, [rel, jsonRel])
  return probe
})

await step('②c', '日报数字对照：专注只含 scale=1，加速单列', async () => {
  // 从账本直接重算两种口径（幂等：重复跑验收也成立）
  const dayFile = join(PROJECT_ROOT, 'data', 'timer', `${TODAY}.jsonl`)
  const records = readFileSync(dayFile, 'utf8').split('\n').filter((l) => l.trim()).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
  const scaledIds = new Set(records.filter((r) => r.type === 'start' && r.timeScale != null && r.timeScale !== 1).map((r) => r.sessionId))
  const realSeg = records.filter((r) => r.type === 'segment' && !scaledIds.has(r.sessionId))
  const fastSeg = records.filter((r) => r.type === 'segment' && scaledIds.has(r.sessionId))
  const expectedReal = realSeg.reduce((s, r) => s + (Number(r.sec) || 0), 0)
  const expectedFast = fastSeg.reduce((s, r) => s + (Number(r.sec) || 0), 0)
  const scaledSessions = scaledIds.size

  const r = await reg.runCommand('today', '')
  const ui = (r.value && r.value.ui) || {}
  const progPath = join(PROJECT_ROOT, 'data', 'progress', `${TODAY}.json`)
  const prog = JSON.parse(readFileSync(progPath, 'utf8'))
  const dailyPath = join(PROJECT_ROOT, 'data', 'reports', `daily-${TODAY}.md`)
  const md = readFileSync(dailyPath, 'utf8')

  const okReal = prog.focusSec === expectedReal
  const okFast = prog.scaled && prog.scaled.focusSec === expectedFast && prog.scaled.sessionCount === scaledSessions
  const okMd =
    md.includes(`专注时长：**${fmtDuration(expectedReal)}**`) &&
    expectedFast > 0 &&
    md.includes('## 测试 / 加速数据（不计入上方统计）') &&
    md.includes(`加速计时：${fmtDuration(expectedFast)}`) &&
    md.includes(`加速会话：${scaledSessions} 个`)
  const cmdOk = (r.value && r.value.text || '').includes('另有加速测试会话')

  // 日报节选：从"一、计时总览"到"三、复盘与建议"之前（含加速区）
  const head = md.split('\n')
  const from = head.findIndex((l) => l.startsWith('## 一、'))
  const to = head.findIndex((l) => l.startsWith('## 三、'))
  const excerpt = head.slice(from, to).map((l) => '  ' + l).join('\n')
  const txt = [
    `账本口径重算（按 start 行 timeScale 黑名单，sessionId=${[...scaledIds].join(',') || '无'}）：`,
    `  真实（scale=1）段合计：${expectedReal}s`,
    `  加速（scale≠1）段合计：${expectedFast}s（${scaledSessions} 个会话）`,
    '',
    '=== /today 命令输出 ===',
    (r.value && r.value.text) || '',
    '',
    '=== data/progress/' + TODAY + '.json（关键字段） ===',
    JSON.stringify({ focusSec: prog.focusSec, segmentCount: prog.segmentCount, sessionCount: prog.sessionCount, scaled: prog.scaled }, null, 2),
    '',
    '=== data/reports/daily-' + TODAY + '.md（计时总览 + 加速区） ===',
    excerpt,
  ].join('\n')
  const rel = evidence('stage31-02c-scale-vs-daily.txt', txt)
  const jsonRel = jsonEvidence('stage31-02c-scale-vs-daily.json', {
    at: new Date().toISOString(),
    expectedReal, expectedFast, scaledSessions,
    progressFocusSec: prog.focusSec,
    progressScaled: prog.scaled,
    okReal, okFast, okMd, cmdOk,
  })
  record('②c', '日报专注时长 == scale=1 部分（' + expectedReal + 's），加速 ' + expectedFast + 's 单列', okReal && okFast && okMd && cmdOk,
    `progress.focusSec=${prog.focusSec}（账本真实 ${expectedReal}） scaled=${JSON.stringify(prog.scaled)} 日报渲染=${okMd ? 'OK' : 'FAIL'} 命令提示=${cmdOk ? 'OK' : 'FAIL'}`, [rel, jsonRel])
})

// ---------------------------------------------------------------------------
// ③ 文档与实现逐字段对齐（静态检查；修正在 docs 任务里完成）
// ---------------------------------------------------------------------------

await step('③', 'ARCH.md / README.md 与实际实现逐字段对齐（静态检查）', async () => {
  const arch = readFileSync(join(PROJECT_ROOT, 'docs', 'ARCH.md'), 'utf8')
  const readme = readFileSync(join(PROJECT_ROOT, 'README.md'), 'utf8')
  const checks = {
    'ARCH: interrupted（实况类型名，非 recovered）': arch.includes('interrupted') && !/type:\s*'recovered'/.test(arch),
    'ARCH: segment kind 六型（focus/pause/final/midnight/interrupted/idle-trim）': ['focus', 'pause', 'final', 'midnight', 'interrupted', 'idle-trim'].every((k) => arch.includes(k)),
    'ARCH: start 行带 timeScale': arch.includes('timeScale'),
    'ARCH: 加速数据排除口径（scaled 单列）': arch.includes('scaled') || arch.includes('加速'),
    'ARCH: milestone（阶段完成备注）': arch.includes('milestone'),
    'ARCH: data/.chromium（userData 分层）': arch.includes('.chromium'),
    'README: data 顶层目录说明（.chromium 单列）': readme.includes('.chromium'),
    'README: /start 位置参数语法': readme.includes('<项目>') || readme.includes('位置参数'),
    'README: /project done 里程碑': readme.includes('里程碑'),
    'README: 测试/加速数据区说明': readme.includes('加速'),
  }
  const lines = Object.entries(checks).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`)
  const rel = evidence('stage31-03-docs-align.txt', lines.join('\n') + '\n\n（说明：字段口径以代码为准 —— packages/core/src/timer.mjs / progress.mjs / report.mjs；本条只证明文档已跟上）')
  const jsonRel = jsonEvidence('stage31-03-docs-align.json', { at: new Date().toISOString(), checks })
  record('③', 'ARCH.md / README.md 与实际 schema 逐字段对齐', Object.values(checks).every(Boolean), `${Object.values(checks).filter(Boolean).length}/${Object.keys(checks).length} 项在位`, [rel, jsonRel])
})

// ---------------------------------------------------------------------------
// ④ 卫生：data 顶层清单 + 应用启动 core-ready（userData 指向 data/.chromium）
// ---------------------------------------------------------------------------

await step('④', 'data\ 顶层只剩领域目录 + .chromium；应用启动 core-ready', async () => {
  const top = readdirSync(join(PROJECT_ROOT, 'data')).sort()
  // 注意：projects 由本工具 ① 号项（项目端到端真跑）创建，故预期清单含它；
  // 阶段 3 核验时 data\projects 尚不存在，早期静态清单漏过一项，此处钉死。
  const expectTop = ['.chromium', 'exports', 'fixtures', 'index', 'logs', 'notes', 'pdf', 'progress', 'projects', 'reports', 'secrets.example.json', 'secrets.json', 'sessions', 'shots', 'timer']
  const topOk = JSON.stringify(top) === JSON.stringify(expectTop.sort())

  // spawn electron 实测：等 app.jsonl 出现本次 pid 的 core-ready（userData 指向 .chromium）
  const before = readFileSync(join(LOGS, 'app.jsonl'), 'utf8')
  const child = spawn(ORB_ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, `${PROJECT_ROOT}/apps/desktop/main.mjs`], {
    cwd: PROJECT_ROOT,
    env: (() => { const e = { ...process.env }; delete e.ELECTRON_RUN_AS_NODE; return e })(),
    stdio: 'ignore',
    detached: false,
  })
  let coreReady = null
  const deadline = Date.now() + 30_000
  while (Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, 1000))
    const now = readFileSync(join(LOGS, 'app.jsonl'), 'utf8')
    const added = now.slice(before.length).split('\n').filter((l) => l.trim())
    for (const line of added) {
      try {
        const j = JSON.parse(line)
        if (j.type === 'start') coreReady = { start: j }
        if (j.type === 'core-ready' && coreReady) coreReady.ready = j
      } catch { /* 半行跳过 */ }
    }
    if (coreReady && coreReady.ready) break
    if (child.exitCode !== null) break
  }
  // 只杀本次启动的 research-orb 进程树（绝不碰 dsh-orb helper）
  try { child.kill('SIGKILL') } catch { /* 已退出 */ }
  await new Promise((r) => setTimeout(r, 1500))
const killRes = countOrbAll()

  const userDataOk = !!coreReady && !!coreReady.start && String(coreReady.start.userData || '').endsWith('data\\.chromium')
  const readyOk = !!coreReady && !!coreReady.ready
  const txt = [
    '=== data\\ 顶层清单 ===',
    top.join('  '),
    `期望（领域目录 + .chromium）：${expectTop.join('  ')}`,
    `一致：${topOk ? '是' : '否'}`,
    '',
    '=== electron 启动实测（本次 pid 的 app.jsonl 行） ===',
    JSON.stringify(coreReady, null, 2),
    '',
    'userData 指向 data\\.chromium：' + (userDataOk ? '是' : '否'),
    'core-ready 装配完成：' + (readyOk ? '是' : '否'),
    '',
    '（附：GPU 进程在本机环境崩溃 —— 已用三次对照排除与本次改动的关系：',
    ' userData 指 data\\ 崩、指 data\\.chromium 崩、--disable-gpu 也崩，同为 0xC0000005；',
    ' 主进程每次均正常落 core-ready / timer-driver-ready / tray-ready，倒在窗口渲染。',
    ' 该环境问题不影响本验收项的"应用可启动 + 数据分层"结论。）',
  ].join('\n')
  const rel = evidence('stage31-04-hygiene-boot.txt', txt)
  const jsonRel = jsonEvidence('stage31-04-hygiene-boot.json', {
    at: new Date().toISOString(),
    dataTop: top,
    expectTop,
    topOk,
    coreReady,
    userDataOk,
    readyOk,
  })
  record('④', 'data\ 顶层 15 项（12 领域 + secrets×2 + .chromium）；electron 启动 core-ready 且 userData=data\\.chromium', topOk && userDataOk && readyOk,
    `顶层一致=${topOk} userData=${userDataOk ? 'OK' : 'FAIL'} core-ready=${readyOk ? 'OK' : 'FAIL'}`, [rel, jsonRel])
})

// ---------------------------------------------------------------------------
// ⑤ 全量测试
// ---------------------------------------------------------------------------

await step('⑤', 'node --test 全量（≥319 条全绿）', async () => {
  const files = readdirSync(join(PROJECT_ROOT, 'tests')).filter((f) => f.endsWith('.test.mjs')).map((f) => join('tests', f))
  const r = runNode(['--test', '--test-concurrency=1', ...files])
  const out = r.stdout + r.stderr
  const rel = evidence('stage31-05-tests.txt', out)
  const m = /# tests (\d+)[\s\S]*?# pass (\d+)[\s\S]*?# fail (\d+)/.exec(out)
  const total = m ? Number(m[1]) : 0
  const pass = m ? Number(m[2]) : 0
  const fail = m ? Number(m[3]) : 0
  const jsonRel = jsonEvidence('stage31-05-tests.json', { at: new Date().toISOString(), total, pass, fail, files: files.length })
  record('⑤', `全量 ${total} 条（≥319）全绿`, fail === 0 && total >= 319 && r.status === 0, `${pass}/${total} 通过，失败 ${fail}`, [rel, jsonRel])
})

// ---------------------------------------------------------------------------
// ⑥ 隔离复核（对阶段 3 基线：本阶段零改动）+ 本阶段基线留档
// ---------------------------------------------------------------------------

await step('⑥a', '隔离复核：对阶段 3 基线 verify（dsh-orb 零改动）', async () => {
  const r = runNode([join('tools', 'probe-isolation.mjs'), 'verify', '--tag', 'stage3'])
  const rel = evidence('stage31-06a-iso-verify.txt', r.stdout + r.stderr)
  let verify = null
  try { verify = JSON.parse(readFileSync(join(PROJECT_ROOT, 'data', 'shots', 'stage3-iso-verify.json'), 'utf8')) } catch { verify = null }
  const ok = r.status === 0 && !!verify
  record('⑥a', 'probe-isolation verify（stage3 基线）：orb 哈希/helper-data/计划任务/writes.jsonl 越界 0', ok, `exit=${r.status}；结论=${verify ? JSON.stringify(verify.conclusion || verify).slice(0, 300) : '(无)'}`, [rel])
})

await step('⑥b', '隔离基线留档（--tag stage31）', async () => {
  const r = runNode([join('tools', 'probe-isolation.mjs'), 'baseline', '--tag', 'stage31'])
  const rel = evidence('stage31-06b-iso-baseline.txt', r.stdout + r.stderr)
  const ok = r.status === 0 && existsSync(join(PROJECT_ROOT, 'data', 'shots', 'stage31-iso-baseline.json'))
  record('⑥b', 'probe-isolation baseline 留档（阶段 3.1 指纹）', ok, `exit=${r.status}；基线文件 ${ok ? '已生成' : '缺失'}`, [rel])
})

// ---------------------------------------------------------------------------
// 汇总
// ---------------------------------------------------------------------------

const summary = {
  stage: '3.1',
  startedAt,
  finishedAt: new Date().toISOString(),
  dayKey: TODAY,
  results: RESULTS,
  allPass: RESULTS.every((r) => r.ok),
}
safeWrite(join(LOGS, 'stage31-summary.json'), JSON.stringify(summary, null, 2))
process.stdout.write(`\n汇总：${RESULTS.filter((r) => r.ok).length}/${RESULTS.length} 通过 -> data/logs/stage31-summary.json\n`)
await host.dispose()
process.exit(summary.allPass ? 0 : 1)
