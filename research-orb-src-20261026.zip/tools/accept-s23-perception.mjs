// tools/accept-s23-perception.mjs —— S23·B 变化分类 + 活动摘要验收。
// 单行复跑：node tools\accept-s23-perception.mjs
// 判据（任务书）：合成灰度帧序列驱动 diff，断言三档分类、摘要文案、敏感窗口略过；
//   附一条真抓屏最小冒烟（1 帧；无桌面环境时如实 SKIP，不算 FAIL）。
// 证据落 data\logs\s23-perception-accept.json。
import { spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import diffModule, { computeDiff } from '../packages/plugins/perception/diff.mjs'
const { DIFF_W, DIFF_H } = diffModule
import { classifyChange } from '../packages/plugins/perception/classify.mjs'
import { createSummarizer, createSummaryWriter, buildSummaryRecord } from '../packages/plugins/perception/summary.mjs'

const items = []
const check = (id, ok, detail, evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's23-perception')
const SUMMARY_DIR = join(WORK, 'summary')
const CAPTURE_DIR = join(WORK, 'capture')

rmSync(WORK, { recursive: true, force: true })
mkdirSync(SUMMARY_DIR, { recursive: true })
mkdirSync(CAPTURE_DIR, { recursive: true })

// 与 perception-config.json 默认阈值同源（复用既有字段，不改默认值）
const THRESHOLDS = { changeScoreCandidate: 0.08, changeScoreNormal: 0.12 }

// ---- 合成帧（256×144 灰度）----
const N = DIFF_W * DIFF_H
function baseFrame() { const f = new Uint8Array(N); f.fill(128); return f }
// minor：每 11 像素取 1 个置 255（≈9% 像素迁桶 → changeScore≈0.09，落在 [0.08,0.12)）
function minorFrame() { const f = baseFrame(); for (let i = 0; i < N; i += 11) f[i] = 255; return f }
// major：左半幅全部置 255
function majorFrame() { const f = baseFrame(); for (let y = 0; y < DIFF_H; y++) { for (let x = 0; x < DIFF_W / 2; x++) f[y * DIFF_W + x] = 255 } return f }

const base = baseFrame()
const minor = minorFrame()
const major = majorFrame()

try {
  // ---- ① 三档分类 ----
  console.log('# ① 变化分类 none/minor/major（规则式，阈值沿用既有字段）')
  const dNone = computeDiff(base, baseFrame())
  const cNone = classifyChange({ changeScore: dNone.changeScore, thresholds: THRESHOLDS })
  check('P1 同帧 → none', cNone.level === 'none' && dNone.changeScore < 0.001, `score=${dNone.changeScore.toFixed(5)} reason=${cNone.reason}`)

  const dMinor = computeDiff(base, minor)
  const cMinor = classifyChange({ changeScore: dMinor.changeScore, thresholds: THRESHOLDS })
  check('P2 微变帧 → minor（score 落在 [0.08,0.12)）', cMinor.level === 'minor' && dMinor.changeScore >= 0.08 && dMinor.changeScore < 0.12, `score=${dMinor.changeScore.toFixed(4)} reason=${cMinor.reason}`)

  const dMajor = computeDiff(base, major)
  const cMajor = classifyChange({ changeScore: dMajor.changeScore, thresholds: THRESHOLDS })
  check('P3 大变帧 → major', cMajor.level === 'major', `score=${dMajor.changeScore.toFixed(4)} reason=${cMajor.reason}`)

  // 滚动：连续 minor 累计（第 3 帧起 reason 标注滚动）
  const cRoll = classifyChange({ changeScore: dMinor.changeScore, consecutiveMinor: 3, thresholds: THRESHOLDS })
  check('P4 连续 3 帧 minor → 滚动累计', cRoll.level === 'minor' && /滚动累计/.test(cRoll.reason), cRoll.reason)

  // 切窗：前台进程/标题变化（零像素依赖，changeScore=0 也判 major）
  const cSwitch = classifyChange({ changeScore: 0, prevWindow: { process: 'Code.exe', title: 'engine.mjs' }, curWindow: { process: 'msedge.exe', title: '论文页' }, thresholds: THRESHOLDS })
  check('P5 前台进程变化 → major「切窗」', cSwitch.level === 'major' && /切窗/.test(cSwitch.reason) && /msedge/.test(cSwitch.reason), cSwitch.reason)
  const cTitle = classifyChange({ changeScore: 0, prevWindow: { process: 'msedge.exe', title: 'A' }, curWindow: { process: 'msedge.exe', title: 'B' }, thresholds: THRESHOLDS })
  check('P6 标题变化 → major「切窗：标题变化」', cTitle.level === 'major' && /标题/.test(cTitle.reason), cTitle.reason)

  // ---- ② 活动摘要（规则式文案）----
  console.log('# ② 活动摘要（每 intervalMs 一条，规则式中文）')
  const t0 = 1760000000000
  const sum = createSummarizer({ intervalMs: 5 * 60 * 1000 })
  let out = null
  for (let i = 0; i < 8; i++) {
    const ts = t0 + i * 60 * 1000
    sum.observe({ ts, process: 'msedge.exe', title: '论文页', sensitive: false }) // 1Hz 停留推进
    out = sum.maybeFlush(ts) // 与 perception/index.mjs 的 _onSample 同一接线：observe 后尝试到点收口
    if (out) break
  }
  check('P7 到点（5 分钟）产出一条摘要', !!out && !!out.text, out && out.text)
  check('P8 摘要文案含前台/时长/变化次数', !!out && /前台 msedge\.exe（论文页）/.test(out.text) && /画面变化 0 次/.test(out.text) && out.dwellMs >= 5 * 60 * 1000, out && out.text)

  // 变化计数 + 切窗计数（noteChange 与切窗返回值）
  const sum2 = createSummarizer({ intervalMs: 5 * 60 * 1000 })
  sum2.observe({ ts: t0, process: 'msedge.exe', title: '论文页', sensitive: false })
  sum2.noteChange({ level: 'minor', reason: '画面微变' })
  sum2.noteChange({ level: 'minor', reason: '滚动累计（连续 3 帧微变）' })
  sum2.noteChange({ level: 'major', reason: '画面大变' })
  const switched = sum2.observe({ ts: t0 + 6 * 60 * 1000, process: 'Code.exe', title: 'engine.mjs', sensitive: false })
  check('P9 切窗关闭旧窗：changes=3、switches=1、level=major', !!switched && switched.changes === 3 && switched.switches === 1 && switched.level === 'major', switched && switched.text)

  // 敏感窗口：摘要脱敏
  const sum3 = createSummarizer({ intervalMs: 5 * 60 * 1000 })
  sum3.observe({ ts: t0, process: '1Password.exe', title: '银行登录', sensitive: true })
  const sRec = sum3.flush(t0 + 6 * 60 * 1000)
  check('P10 敏感窗口摘要脱敏（已略，process/title=null）', !!sRec && sRec.text === '敏感窗口（已略）' && sRec.process === null && sRec.title === null && sRec.sensitive === true, sRec && sRec.text)

  // buildSummaryRecord 纯函数（示例样例：任务书文案格式）
  const sample = buildSummaryRecord({ startTs: t0, lastTs: t0 + 12 * 60 * 1000, process: 'msedge.exe', title: '论文页', changes: 3, switches: 1, minor: 2, major: 1 }, t0 + 12 * 60 * 1000)
  check('P11 摘要样例（12 分钟/3 次变化/1 次切窗）', sample.text === '前台 msedge.exe（论文页）12 分钟，画面变化 3 次（1 次切窗）', sample.text)

  // 落盘：summary-YYYYMMDD.jsonl
  const writer = createSummaryWriter({ dir: SUMMARY_DIR })
  const p1 = writer.write(sample, t0)
  const p2 = writer.write(sRec, t0)
  const files = existsSync(SUMMARY_DIR) ? readdirSafe(SUMMARY_DIR) : []
  const jsonl = p1 && existsSync(p1) ? readFileSync(p1, 'utf8').split('\n').filter((l) => l.trim()) : []
  const texts = jsonl.map((l) => { try { return JSON.parse(l).text } catch { return null } })
  check('P12 摘要落 summary-*.jsonl（JSONL 可解析，含常规+脱敏两条）', !!p1 && files.length >= 1 && texts.includes(sample.text) && texts.includes('敏感窗口（已略）'), `files=${files.join(',')} lines=${jsonl.length}`)

  // ---- ③ 真抓屏最小冒烟（1 帧；无桌面环境如实 SKIP）----
  console.log('# ③ 真抓屏冒烟（1 帧，PowerShell CopyFromScreen；无桌面则 SKIP）')
  const png = join(CAPTURE_DIR, 'frame-1.png')
  const psScript = [
    'Add-Type -AssemblyName System.Windows.Forms,System.Drawing;',
    '$b=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds;',
    '$bmp=New-Object System.Drawing.Bitmap $b.Width,$b.Height;',
    '$g=[System.Drawing.Graphics]::FromImage($bmp);',
    '$g.CopyFromScreen($b.Location,[System.Drawing.Point]::Empty,$b.Size);',
    `$bmp.Save('${png.replace(/\\/g, '\\\\')}',[System.Drawing.Imaging.ImageFormat]::Png);`,
    '$g.Dispose();$bmp.Dispose();',
  ].join(' ')
  const ps = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', psScript], { timeout: 30000 })
  const captured = existsSync(png) && statSync(png).size > 0
  if (captured) {
    check('P13 真抓屏 1 帧成功（PNG 落盘且非空）', true, `bytes=${statSync(png).size}`, { status: 'OK' })
  } else {
    const reason = (ps.error && ps.error.code) || (ps.stderr && String(ps.stderr).slice(0, 120)) || 'capture-failed'
    check('P13 真抓屏冒烟（无交互桌面 → 如实 SKIP，不算失败）', true, `status=SKIP reason=${reason}`, { status: 'SKIP', reason })
  }
} catch (e) {
  check('P0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  rmSync(WORK, { recursive: true, force: true })
}

const pass = items.filter((i) => i.ok).length
const fail = items.length - pass
const out = { tool: 'accept-s23-perception', at: new Date().toISOString(), total: items.length, pass, fail, items }
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's23-perception-accept.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # accept-s23-perception: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 证据 -> data/logs/s23-perception-accept.json`)
process.exit(fail === 0 ? 0 : 1)

function readdirSafe(dir) {
  try { return readdirSync(dir) } catch { return [] }
}
