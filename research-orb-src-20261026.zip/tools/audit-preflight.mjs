// tools/audit-preflight.mjs —— S31·B3 审计完整性巡检 CLI。
// 单行复跑：node tools\audit-preflight.mjs
// 退出码：通过 0 / 失败 1（E_AUDIT_LOSS 等）。供教练插件启动前自检，也供人工巡检。
import { auditPreflight } from '../packages/plugins/coach/audit-preflight.mjs'

try {
  const r = auditPreflight()
  console.log('[PASS] 审计完整性巡检通过（当前行数均 >= 基线，无审计丢失）')
  for (const x of r.results) {
    console.log(`  · ${x.file}: live ${x.live} / archived ${x.archived} / total ${x.total} (基线 ${x.baseline}) ${x.total >= x.baseline ? '✓' : '✗'}${x.approved ? ' [已报批下调]' : ''}`)
  }
  process.exit(0)
} catch (e) {
  console.error('[FAIL] ' + e.message)
  process.exit(1)
}
