// tools/_probe-datadir-writer.mjs —— S34·P0 辅助：在 ORB_DATA_DIR 下做真实生产写入，供验收子进程调用。
import { dataPath, safeWrite, DATA_DIR } from '../packages/core/src/safefs.mjs'
import { saveSettings, loadSettings } from '../packages/core/src/settings.mjs'

saveSettings({ demo: true }) // 写 config.json（跟随 DATA_DIR）
saveSettings({ demo: false })
safeWrite(dataPath('notes', 's34-probe.md'), 'probe\n', 'utf8') // 写 notes/
console.log(JSON.stringify({ DATA_DIR, config: loadSettings() }))
