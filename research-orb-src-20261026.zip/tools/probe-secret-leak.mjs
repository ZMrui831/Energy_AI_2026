// tools/probe-secret-leak.mjs
//
// 验收 ④ 取证：证明密钥明文没有落到任何日志/源码/会话/笔记里。
//
// 做法：从两个凭据来源读出【明文】，拿它去逐文件搜索，然后【只打印命中数与掩码】，
// 绝不把明文写进 stdout —— 否则取证脚本自己就成了泄漏点。
//
// 跑法：node tools\probe-secret-leak.mjs
// 产物：data\shots\stage1-acceptance-secrets.json

import { existsSync, readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs'
import { extname, join, relative } from 'node:path'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { deepseekConfig, gatewayConfig, maskKey, SECRETS_PATH, DEFAULT_CLAUDE_SETTINGS_PATH } from '../packages/core/src/config.mjs'

const OUT = join(PROJECT_ROOT, 'data', 'shots', 'stage1-acceptance-secrets.json')

const ds = deepseekConfig({ secretsPath: SECRETS_PATH })
const gw = gatewayConfig({ secretsPath: SECRETS_PATH, settingsPath: DEFAULT_CLAUDE_SETTINGS_PATH })

/** 待搜索的明文（只在内存里，不打印）。 */
const needles = [
  { label: 'deepseek.apiKey', value: ds.apiKey },
  { label: 'gateway.authToken', value: gw.authToken },
].filter((n) => typeof n.value === 'string' && n.value.length >= 8)

// 顺带查几类"半明文"：key 去掉前缀后的主体、以及常见截断形态
const extras = needles.flatMap((n) => {
  const body = n.value.replace(/^sk-/, '')
  return body.length >= 8 ? [{ label: n.label + '.body', value: body }] : []
})

const ALL = [...needles, ...extras]

const SCAN_DIRS = [
  'data/logs',
  'data/sessions',
  'data/notes',
  'data/shots',
  'apps',
  'packages',
  'tests',
  'tools',
  'docs',
]
const SCAN_ROOT_FILES = ['README.md', 'SAFETY.md', 'start.cmd', 'start-dev.cmd']
// 只扫文本类扩展名；.png 是压缩过的位图，明文不可能以字面量形态存在，另行按字节扫
const TEXT_EXT = new Set(['.jsonl', '.json', '.mjs', '.cjs', '.js', '.md', '.cmd', '.txt', '.yaml', '.yml', '.html', '.css'])
const BINARY_EXT = new Set(['.png'])

function walk(dir, out = []) {
  if (!existsSync(dir)) return out
  for (const name of readdirSync(dir)) {
    const abs = join(dir, name)
    let st = null
    try {
      st = statSync(abs)
    } catch {
      continue
    }
    if (st.isDirectory()) walk(abs, out)
    else out.push(abs)
  }
  return out
}

const files = []
for (const d of SCAN_DIRS) files.push(...walk(join(PROJECT_ROOT, d)))
for (const f of SCAN_ROOT_FILES) {
  const abs = join(PROJECT_ROOT, f)
  if (existsSync(abs)) files.push(abs)
}

const hits = []
let scannedText = 0
let scannedBinary = 0

for (const abs of files) {
  const ext = extname(abs).toLowerCase()
  if (!TEXT_EXT.has(ext) && !BINARY_EXT.has(ext)) continue
  let buf = null
  try {
    buf = readFileSync(abs)
  } catch {
    continue
  }
  const rel = relative(PROJECT_ROOT, abs).replace(/\\/g, '/')
  if (TEXT_EXT.has(ext)) {
    scannedText += 1
    const text = buf.toString('utf8')
    for (const n of ALL) {
      if (text.includes(n.value)) {
        // 不打印明文，只打印它出现在哪个文件的第几行
        const lines = text.split('\n')
        lines.forEach((line, i) => {
          if (line.includes(n.value)) hits.push({ file: rel, line: i + 1, which: n.label })
        })
      }
    }
  } else {
    scannedBinary += 1
    for (const n of ALL) {
      if (buf.includes(Buffer.from(n.value, 'utf8'))) hits.push({ file: rel, line: 0, which: n.label })
    }
  }
}

// 反向自证：掩码形态确实存在（说明日志里记录的是掩码而不是别的）
const netLog = join(PROJECT_ROOT, 'data', 'logs', 'net.jsonl')
const netText = existsSync(netLog) ? readFileSync(netLog, 'utf8') : ''
const authLikeInNet = /"authorization"|x-api-key|Bearer [A-Za-z0-9._-]{8,}/i.test(netText)

const evidence = {
  ts: new Date().toISOString(),
  needleLabels: ALL.map((n) => ({ label: n.label, masked: maskKey(n.value), length: n.value.length })),
  scanned: { text: scannedText, binary: scannedBinary, total: files.length },
  leakHits: hits,
  leakCount: hits.length,
  netLogContainsAuthHeader: authLikeInNet,
  note: 'net.jsonl 只记录 URL/状态/耗时，从不记录请求头；本项应为 false',
}

writeFileSync(OUT, JSON.stringify(evidence, null, 2))

process.stdout.write(`扫描文件：文本 ${scannedText} / 位图 ${scannedBinary}\n`)
for (const n of evidence.needleLabels) {
  process.stdout.write(`  待查明文 ${n.label}: ${n.masked} (len=${n.length})\n`)
}
process.stdout.write(`明文命中：${hits.length}\n`)
for (const h of hits.slice(0, 20)) process.stdout.write(`  ! ${h.file}:${h.line} <- ${h.which}\n`)
process.stdout.write(`net.jsonl 含 authorization/x-api-key/Bearer: ${authLikeInNet}\n`)
process.stdout.write(`evidence -> ${OUT}\n`)

const ok = hits.length === 0 && authLikeInNet === false
process.stdout.write(ok ? 'SECRET-LEAK PROBE OK（0 命中）\n' : 'SECRET-LEAK PROBE FAILED\n')
process.exit(ok ? 0 : 1)
