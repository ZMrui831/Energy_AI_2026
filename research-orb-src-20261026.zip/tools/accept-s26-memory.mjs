// tools/accept-s26-memory.mjs —— S26·P1 记忆适配层验收。
// 单行复跑：node tools\accept-s26-memory.mjs
// 证据：data\logs\s26-memory-accept.json
import { spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync, unlinkSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createRouter } from '../packages/core/src/router.mjs'
import { createExtractor } from '../packages/plugins/coach/extract.mjs'
import { createDailyPipeline } from '../packages/plugins/coach/daily.mjs'
import { listMemories, saveMemory, markDone, recallMemories, readMemorySystemContext, MEMORY_MAX_TOKENS, estimateTokens } from '../packages/plugins/coach/memory.mjs'
import { activate as coachActivate } from '../packages/plugins/coach/index.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 240), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's26-memory')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(join(WORK, 'coach'), { recursive: true })
const COACH_DIR = join(WORK, 'coach')
// /mem 写真实 data\coach\memory——D21/D22：先快照，finally 复位（var 提升供 finally 可见）
var REAL_MEM = join(PROJECT_ROOT, 'data', 'coach', 'memory')
var memBefore = existsSync(REAL_MEM) ? readdirSync(REAL_MEM) : []

try {
  // ① save + recall（同进程）
  saveMemory({ title: '微电网综述第二章提纲', body: '一、下垂控制；二、孤岛运行；三、二次调频', kind: 'note', tags: ['综述'], dir: COACH_DIR })
  const hits = recallMemories('下垂控制', COACH_DIR)
  check('M1 save + recall 同进程命中', hits.length === 1 && hits[0].title === '微电网综述第二章提纲')

  // ② 新进程仍可 recall（子进程 import 真实模块读盘；绝对 file URL 避免相对解析歧义）
  const memModUrl = 'file:///' + join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'memory.mjs').replace(/\\/g, '/')
  const child = [
    `import { recallMemories, listMemories } from ${JSON.stringify(memModUrl)}`,
    `const hits = recallMemories('孤岛运行', ${JSON.stringify(COACH_DIR)})`,
    `const all = listMemories(${JSON.stringify(COACH_DIR)})`,
    "console.log('CHILD:' + JSON.stringify({ hits: hits.length, total: all.length, first: hits[0] && hits[0].title }))",
  ].join('\n')
  const childPath = join(WORK, 'recall-child.mjs')
  writeFileSync(childPath, child, 'utf8')
  const r = spawnSync(process.execPath, [childPath], { encoding: 'utf8', timeout: 30000, env: { ...process.env, NODE_OPTIONS: '' } })
  const line = (r.stdout || '').split('\n').find((l) => l.startsWith('CHILD:'))
  const childOut = line ? JSON.parse(line.slice(6)) : null
  check('M2 新进程仍可 recall（跨会话 Markdown 持久化）', !!childOut && childOut.hits === 1 && childOut.total === 1, childOut ? JSON.stringify(childOut) : String(r.stderr || r.stdout || 'no output').slice(0, 120))

  // ③ 一级注入：目标+轨迹+计划三段 ≤400 token
  writeFileSync(join(COACH_DIR, 'trajectory.jsonl'), [
    JSON.stringify({ ts: new Date().toISOString(), window: '论文', process: 'msedge.exe', intent: '阅读下垂控制文献', level: 'direct', evidence: { frameId: 'fr-a', textSha256: 'sha-a' } }),
    JSON.stringify({ ts: new Date().toISOString(), window: '代码', process: 'Code.exe', intent: '调试仿真脚本', level: 'direct', evidence: { frameId: 'fr-b', textSha256: 'sha-b' } }),
  ].join('\n') + '\n', 'utf8')
  saveMemory({ title: '补跑下垂控制对比实验', body: '来自日报建议', kind: 'plan', dir: COACH_DIR })
  const sys = readMemorySystemContext({ dir: COACH_DIR, goal: '两周内完成微电网综述初稿' })
  check('M3 一级注入含 目标/未完成计划/最近轨迹 三段', /【当前目标】/.test(sys) && /【未完成计划】/.test(sys) && /【最近研究轨迹】/.test(sys))
  check(`M4 一级注入 ≤${MEMORY_MAX_TOKENS} token（实测 ${estimateTokens(sys)}）`, estimateTokens(sys) <= MEMORY_MAX_TOKENS)

  // ⑤ 无记忆不注入
  const empty = readMemorySystemContext({ dir: join(WORK, 'empty-coach'), goal: '' })
  check('M5 无记忆不注入（返回空串）', empty === '')

  // ⑥ 超长内容被压缩（三条超长轨迹+超长目标）
  const longTraj = Array.from({ length: 3 }, (_, i) => JSON.stringify({ ts: new Date().toISOString(), window: 'w' + i, process: 'p', intent: '超长意图描述'.repeat(50), level: 'direct', evidence: { frameId: 'fr' + i, textSha256: 's' + i } })).join('\n') + '\n'
  writeFileSync(join(COACH_DIR, 'trajectory.jsonl'), longTraj, 'utf8')
  const sysLong = readMemorySystemContext({ dir: COACH_DIR, goal: '目标'.repeat(100) })
  check('M6 超长内容压缩到预算内（保目标优先）', estimateTokens(sysLong) <= MEMORY_MAX_TOKENS && sysLong.includes('【当前目标】'))

  // ⑦ 日报自动入库（真实 daily 跑一轮 → memory 出现 daily + plan）
  const stubRouter = createRouter({
    providers: { cheap: { providerId: 'school-gateway', model: 'qwen' }, flagship: { providerId: 'deepseek-api', model: 'deepseek-chat' } },
    invoke: async ({ taskClass }) => {
      if (taskClass === 'extract') return { text: '屏幕文字转录（桩）' }
      if (taskClass === 'summarize') return { text: JSON.stringify(['阅读微电网综述']) }
      return { text: JSON.stringify({ score: 88, advice: ['整理 bib', '补实验数据'] }) }
    },
    usagePath: join(WORK, 'usage.jsonl'), // 桩显式 usagePath（红线）
    audit: () => {},
  })
  const extractor = createExtractor({ dir: COACH_DIR, router: stubRouter, trashDir: join(WORK, 'trash') })
  const daily = createDailyPipeline({ dir: COACH_DIR, router: stubRouter, extractor })
  writeFileSync(join(WORK, 'f1.png'), Buffer.from('daily-memory frame'))
  const dr = await daily.run({ consentActive: true, goal: '两周内完成微电网综述初稿', frames: [{ imagePath: join(WORK, 'f1.png'), window: '论文', process: 'msedge.exe' }] })
  const mems = listMemories(COACH_DIR)
  const dailyBody = mems.find((m) => m.kind === 'daily')
  // 自动侧只产 1 条 daily；plan 仅剩 M3 手动建的那 1 条（日报建议不再一建议一文件）
  check('M7 日报自动入库（仅 1 条 daily；建议拼进正文；无新 plan 文件）', dr.ok === true && mems.filter((m) => m.kind === 'daily').length === 1 && mems.filter((m) => m.kind === 'plan').length === 1 && dailyBody && dailyBody.body.includes('整理 bib') && dailyBody.body.includes('补实验数据'), `daily=${mems.filter((m) => m.kind === 'daily').length} plans=${mems.filter((m) => m.kind === 'plan').length}`)

  // ⑧ plan done 标记
  const plan = mems.find((m) => m.kind === 'plan' && !m.done)
  markDone(plan.file, COACH_DIR)
  check('M8 plan done 标记（recall/stats 可见）', listMemories(COACH_DIR).find((m) => m.file === plan.file).done === true)

  // ⑨ /mem 四命令（真实 activate，fake ctx；写真实 data\coach\memory —— D21/D22 快照复位）
  const cmds = {}
  await coachActivate({ net: { available: false }, ui: { registerCommand: (s) => { cmds[s.name] = s.run }, registerCard: () => {} }, log: console })
  const saveR = await cmds.mem('save 手动记忆标题 | 手动记忆正文')
  const listR = await cmds.mem('list')
  const statsR = await cmds.mem('stats')
  const recallR = await cmds.mem('recall 手动记忆')
  check('M9 /mem save|list|stats|recall 四命令真实可用', saveR.ok === true && listR.ok === true && statsR.ok === true && recallR.ok === true && recallR.text.includes('手动记忆标题'), (recallR.text || '').split('\n')[0])
  const savedFile = listMemories().find((m) => m.title === '手动记忆标题')
  const doneR = savedFile ? await cmds.mem('done ' + savedFile.file) : { ok: false }
  check('M10 /mem done 标记完成', doneR.ok === true && listMemories().find((m) => m.file === savedFile.file).done === true)
} catch (e) {
  check('M0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 240))
} finally {
  // 还原真实 data\coach\memory（D21/D22：/mem 写的是真实目录，快照复位）
  try {
    if (existsSync(REAL_MEM)) {
      for (const f of readdirSync(REAL_MEM)) {
        if (!memBefore.includes(f)) unlinkSync(join(REAL_MEM, f))
      }
    }
  } catch { /* 尽力 */ }
  rmSync(WORK, { recursive: true, force: true })
}

const pass = items.filter((i) => i.ok).length
const fail = items.length - pass
const out = { tool: 'accept-s26-memory', at: new Date().toISOString(), total: items.length, pass, fail, items }
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's26-memory-accept.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # accept-s26-memory: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 证据 -> data/logs/s26-memory-accept.json`)
process.exit(fail === 0 ? 0 : 1)
