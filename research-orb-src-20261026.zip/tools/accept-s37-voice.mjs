// tools/accept-s37-voice.mjs —— S37·C 语音最小闭环验收（≥8 项）。
// 单行复跑：node tools\accept-s37-voice.mjs
// 证据：data\logs\s37-voice-accept.json
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'

// 验收隔离：先设 ORB_LOG_DIR/ORB_DATA_DIR 再动态 import（safefs 在 import 时定格目录）
process.env.ORB_LOG_DIR = join(tmpdir(), 's37-voice-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's37-voice-data-' + Date.now())
const { PROJECT_ROOT, dataPath } = await import('../packages/core/src/safefs.mjs')
const { transcribeAudio, synthesizeWav, makeDraftFromTranscript, playAndCleanup, wavDurationSec, recordContract } = await import('../packages/core/src/voice.mjs')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

const GEN = join(PROJECT_ROOT, 'tools', 'gen-voice-test-wav.mjs')
function genWav(text) {
  const out = join(tmpdir(), `s37-voice-${Date.now()}-${Math.random().toString(36).slice(2, 6)}.wav`)
  const r = spawnSync(process.execPath, [GEN, out, text], { encoding: 'utf8', timeout: 90000, cwd: PROJECT_ROOT })
  return { out, ok: existsSync(out), gen: String(r.stdout || '') }
}
const countPy = () => {
  const r = spawnSync('tasklist', ['/FI', 'IMAGENAME eq python.exe'], { encoding: 'utf8' })
  return (String(r.stdout || '').match(/python\.exe/g) || []).length
}

try {
  // V-1 真音频转写：SAPI 语音 → faster_whisper（tiny，本地模型目录）
  // 新生成的 wav 可能被宿主文件监视短暂锁住 → 生成后等待 + 转写最多 3 次重试（瞬态锁≠产品缺陷）
  const g1 = genWav('今天北京天气晴，适合出门散步，适合远程会议')
  for (let i = 0; i < 20 && !existsSync(g1.out); i++) { /* 等生成落盘 */ }
  const sleep = (ms) => new Promise((res) => setTimeout(res, ms))
  await sleep(1000)
  let t1 = transcribeAudio(g1.out)
  for (let attempt = 0; attempt < 2 && t1.ok !== true; attempt++) {
    await sleep(2500)
    t1 = transcribeAudio(g1.out)
  }
  check('V-1 真音频转写（faster_whisper）', t1.ok === true && /散步|远程会议|天气/.test(t1.text || '') && t1.audioSec > 3,
    `text=${(t1.text || '').slice(0, 24)}… audioSec=${t1.audioSec} model=${t1.model && String(t1.model).split(/[\\/]/).pop()}`, {})

  // V-2 文本入框不自动发（契约：autoSend:false）
  const d1 = makeDraftFromTranscript(t1.ok ? t1.text : '')
  check('V-2 文本入框不自动发', d1.autoSend === false && d1.source === 'voice' && d1.text.length > 0,
    `autoSend=${d1.autoSend} source=${d1.source}`, {})

  // V-3 TTS：wav 时长 > 0（CosyVoice2 不可用 → SAPI 兜底真产出，fallback 如实标注）
  const s1 = synthesizeWav('这是语音播报的验收测试。')
  check('V-3 TTS wav 时长>0', s1.ok === true && wavDurationSec(s1.wavPath) > 0.5,
    `provider=${s1.provider} fallback=${s1.fallback} sec=${s1.durationSec}`, {})

  // V-4 不可用降级：显式 cosyvoice → ok:false + 明确原因
  const s2 = synthesizeWav('只走 CosyVoice2 的降级测试。', { provider: 'cosyvoice' })
  check('V-4 CosyVoice2 不可用降级（明确原因）', s2.ok === false && s2.code === 'E_VOICE_UNAVAILABLE' && /CosyVoice2|venv|模型/.test(s2.reason || ''),
    `code=${s2.code} reason=${(s2.reason || '').slice(0, 50)}`, {})

  // V-5 ASR 文件缺失 → 降级不崩
  const t5 = transcribeAudio(join(tmpdir(), 'not-exists-' + Date.now() + '.wav'))
  check('V-5 ASR 降级不崩（原因明确）', t5.ok === false && t5.code === 'E_VOICE_UNAVAILABLE' && (t5.reason || '').length > 8,
    `reason=${(t5.reason || '').slice(0, 40)}`, {})

  // V-6 wav 落系统临时目录
  check('V-6 wav 在系统临时目录', s1.ok && s1.wavPath.startsWith(tmpdir()) && existsSync(s1.wavPath),
    `path=${s1.wavPath.split(/[\\/]/).pop()}`, {})

  // V-7 播后删（播放器注入桩；播放后文件删除）
  const before = s1.wavPath
  const pc = playAndCleanup(before, { player: () => { /* 注入桩：真实播放由宿主接系统播放器 */ } })
  check('V-7 播后删', pc.removed === true && !existsSync(before), `removed=${pc.removed}`, {})

  // V-8 无残留进程：本模块全部用 spawnSync（同步跑完即退）——验收查"我们的脚本"相关进程为零
  // （全局 python.exe 计数不可用：宿主自身常驻 python 会污染计数）。
  const probeResidue = () => {
    const r = spawnSync('powershell', ['-NoProfile', '-Command',
      "Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | Where-Object { $_.CommandLine -match 'voice-asr|voice-cosy' } | Measure-Object | Select-Object -ExpandProperty Count"], { encoding: 'utf8', timeout: 60000 })
    return Number(String(r.stdout || '').trim()) || 0
  }
  const g8 = genWav('再来一次确认无残留进程')
  transcribeAudio(g8.out)
  synthesizeWav('无残留进程确认。')
  const residue = probeResidue()
  check('V-8 无残留进程（本模块脚本零驻留）', residue === 0, `voice 相关进程=${residue}`, {})
  try { rmSync(g8.out, { force: true }) } catch { /* 尽力 */ }

  // V-9 录制契约：按住说话 ≤15s；源码无常驻 VAD/唤醒词/常驻进程
  const rc = recordContract()
  const voiceSrc = readFileSync(join(PROJECT_ROOT, 'packages', 'core', 'src', 'voice.mjs'), 'utf8')
  const noResident = !/setInterval|spawn\(/.test(voiceSrc) && /spawnSync/.test(voiceSrc)
  check('V-9 录制契约（按住说话 ≤15s，零常驻）', rc.kind === 'push-to-talk' && rc.maxSec === 15 && noResident,
    `kind=${rc.kind} maxSec=${rc.maxSec} 零常驻=${noResident}`, {})

  // V-10 降级不影响主流程：全部调用走 try 语义（返回值而非抛出）
  let threw = false
  let r10 = null
  try { r10 = transcribeAudio(join(tmpdir(), 'again-missing.wav')) } catch { threw = true }
  check('V-10 降级不影响主流程（返回值不抛出）', !threw && r10 && r10.ok === false,
    `threw=${threw} ok=${r10 && r10.ok}`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's37-voice-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s37-voice: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
