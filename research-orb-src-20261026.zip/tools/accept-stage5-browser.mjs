// tools/accept-stage5-browser.mjs
//
// 阶段 5 验收脚本：真实无头浏览器（本机 Edge/Chrome，CDP）跑通 L1。
// 验收点：
//   1) 白名单域（arxiv.org）可被抽取并落 data/browser/<host>/<slug>.json；
//   2) 抽取结果含 标题/作者/年份/DOI/摘要/正文片段 等结构化字段；
//   3) browser.jsonl 审计留下 allow/saved 记录（白名单审计留痕）；
//   4) --temp 临时 profile 路径不污染持久 profile；
//   5) /web auth <domain> 临时授权通道可放行非白名单域（审计留痕）。
//
// 说明：出网上网由本机浏览器进程直连（遵守白名单网关），不下载任何浏览器二进制。

import { existsSync, readFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import { createBrowserEngine } from '../packages/plugins/research-browser/lib/engine.mjs'
import { PROJECT_ROOT, logPath } from '../packages/core/src/safefs.mjs'

const WHITELIST_URL = 'https://arxiv.org/abs/2301.00001'
const AUDIT_LOG = logPath('browser.jsonl')

function readAudit() {
  if (!existsSync(AUDIT_LOG)) return []
  return readFileSync(AUDIT_LOG, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l))
}

let failures = 0
const check = (cond, label) => {
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${label}`)
  if (!cond) failures += 1
}

const engine = createBrowserEngine({}) // 真实浏览器探测 + 真实 CDP 抽取

async function main() {
  console.log('=== L1 真实无头浏览器验收 ===')
  console.log('detected browser exe:', engine._state().exe || '(none)')
  check(!!engine._state().exe, '本机存在 Edge/Chrome（未下载二进制）')

  // 1) 白名单域真实抽取
  const r = await engine.browse({ url: WHITELIST_URL })
  console.log('browse result:', r.ok ? `ok path=${r.path}` : `FAIL ${r.code}:${r.reason}`)
  check(r.ok, `白名单域可抽取: ${WHITELIST_URL}`)
  if (r.ok) {
    check(existsSync(r.path), `证据文件已落盘: ${r.path}`)
    const d = JSON.parse(readFileSync(r.path, 'utf8'))
    console.log(`  标题=${JSON.stringify(d.title)} 作者=${JSON.stringify(d.authors)} 年份=${d.year} DOI=${d.doi}`)
    console.log(`  摘要长度=${d.abstract.length} 正文片段长度=${d.snippet.length}`)
    check(typeof d.title === 'string' && d.title.length > 0, '含标题')
    check(Array.isArray(d.authors), '含作者字段')
    check(d.host === 'arxiv.org', 'host 归一为 arxiv.org')
    check(d.fetchedAt && d.retrievedBy, '含 fetchedAt/retrievedBy 元数据')
  }

  // 3) 白名单审计留痕
  const audit = readAudit()
  const allowed = audit.filter((a) => a.decision === 'allow' && a.host === 'arxiv.org')
  const saved = audit.filter((a) => a.decision === 'saved' && a.host === 'arxiv.org')
  check(allowed.length >= 1, `browser.jsonl 有 allow 记录（白名单审计）: ${allowed.length}`)
  check(saved.length >= 1, `browser.jsonl 有 saved 记录: ${saved.length}`)

  // 4) 临时 profile（不污染持久 profile）
  // 注：持久 profile 在首轮浏览后存在延迟写盘，先 settle 再快照，避免把"首轮延迟写"误判为临时模式污染。
  const snap = () => new Set([...readdirSync(engine._state().persistentProfileDir)].sort())
  await new Promise((r) => setTimeout(r, 1200))
  const before = snap()
  const r2 = await engine.browse({ url: WHITELIST_URL, opts: { temp: true } })
  await new Promise((r) => setTimeout(r, 500))
  const after = snap()
  check(r2.ok, '临时 profile 模式可抽取')
  check([...before].join(',') === [...after].join(','), '临时 profile 未污染持久 profile 目录')
  if (r2.ok) check(r2.data.usedTempProfile === true, '证据标记 usedTempProfile=true')

  // 5) 临时授权通道
  const r3before = await engine.browse({ url: 'https://example.com/article' })
  check(!r3before.ok, '非白名单域默认被拒')
  engine.authorizeTemp('example.com')
  const r3 = await engine.browse({ url: 'https://example.com/article' })
  console.log('temp-auth browse:', r3.ok ? `ok path=${r3.path}` : `FAIL ${r3.code}:${r3.reason}`)
  check(r3.ok, 'authorizeTemp 后非白名单域放行（审计留痕）')

  console.log(`\n=== 结果：${failures === 0 ? '全部通过' : failures + ' 项失败'} ===`)
  process.exit(failures === 0 ? 0 : 1)
}

main().catch((e) => {
  console.error('验收脚本异常:', e)
  process.exit(2)
})
