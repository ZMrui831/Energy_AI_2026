// tools/composite-icons.mjs
//
// P-R6.1 外观验收取证：图标放大对照 + 球在亮/暗壁纸上的分离度。
//
// 纪律：零依赖零下载 —— PNG 解码/编码都是本项目自写的最小实现
//（RGBA8 非隔行；解码支持全部 5 种行滤波），放大用最近邻（保留像素边界，便于评审小尺寸细节）。
//
// 产物（data\shots\）：
//   stage61-icon-16px-zoom.png     托盘 16px → 8× 放大（128px）
//   stage61-icon-96px-zoom.png     球 96px → 3× 放大（288px）
//   stage61-ball-on-light.png      球 2× 放大铺在纯白壁纸上（亮壁纸分离度）
//   stage61-ball-on-dark.png       球 2× 放大铺在深灰壁纸上（暗壁纸分离度）

import { readFileSync, writeFileSync } from 'node:fs'
import { inflateSync, deflateSync } from 'node:zlib'
import { join } from 'node:path'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const ICONS = join(PROJECT_ROOT, 'apps', 'desktop', 'assets', 'icons')
const SHOTS = join(PROJECT_ROOT, 'data', 'shots')

// ---------------------------------------------------------------------------
// 最小 PNG 解码（RGBA8，非隔行，5 种行滤波）
// ---------------------------------------------------------------------------
function decodePng(buf) {
  let off = 8
  let w = 0, h = 0, bitDepth = 0, colorType = 0
  let idat = []
  while (off < buf.length) {
    const len = buf.readUInt32BE(off)
    const type = buf.subarray(off + 4, off + 8).toString('ascii')
    const data = buf.subarray(off + 8, off + 8 + len)
    if (type === 'IHDR') {
      w = data.readUInt32BE(0)
      h = data.readUInt32BE(4)
      bitDepth = data[8]
      colorType = data[9]
      if (bitDepth !== 8 || colorType !== 6) throw new Error(`仅支持 RGBA8：depth=${bitDepth} type=${colorType}`)
      if (data[12] !== 0) throw new Error('不支持隔行 PNG')
    } else if (type === 'IDAT') {
      idat.push(data)
    } else if (type === 'IEND') {
      break
    }
    off += 12 + len
  }
  const raw = inflateSync(Buffer.concat(idat))
  const stride = w * 4
  const out = new Uint8Array(w * h * 4)
  const paeth = (a, b, c) => {
    const p = a + b - c
    const pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c)
    return pa <= pb && pa <= pc ? a : pb <= pc ? b : c
  }
  for (let y = 0; y < h; y += 1) {
    const filter = raw[y * (stride + 1)]
    const row = raw.subarray(y * (stride + 1) + 1, (y + 1) * (stride + 1))
    for (let x = 0; x < stride; x += 1) {
      const left = x >= 4 ? row[x - 4] : 0
      const up = y > 0 ? out[(y - 1) * stride + x] : 0
      const ul = y > 0 && x >= 4 ? out[(y - 1) * stride + x - 4] : 0
      let v = row[x]
      if (filter === 1) v = (v + left) & 0xff
      else if (filter === 2) v = (v + up) & 0xff
      else if (filter === 3) v = (v + ((left + up) >> 1)) & 0xff
      else if (filter === 4) v = (v + paeth(left, up, ul)) & 0xff
      out[y * stride + x] = v
    }
  }
  return { data: out, width: w, height: h }
}

// ---------------------------------------------------------------------------
// 最小 PNG 编码（与 tools/make-icons.mjs 同一实现）
// ---------------------------------------------------------------------------
const CRC_TABLE = (() => {
  const t = new Int32Array(256)
  for (let n = 0; n < 256; n += 1) {
    let c = n
    for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1
    t[n] = c
  }
  return t
})()
function crc32(buf) {
  let c = -1
  for (let i = 0; i < buf.length; i += 1) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8)
  return (c ^ -1) >>> 0
}
function chunk(type, data) {
  const len = Buffer.alloc(4)
  len.writeUInt32BE(data.length, 0)
  const typeBuf = Buffer.from(type, 'ascii')
  const crcBuf = Buffer.alloc(4)
  crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0)
  return Buffer.concat([len, typeBuf, data, crcBuf])
}
function encodePng(rgba, w, h) {
  const stride = w * 4
  const raw = Buffer.alloc((stride + 1) * h)
  for (let y = 0; y < h; y += 1) {
    raw[y * (stride + 1)] = 0
    Buffer.from(rgba.buffer, rgba.byteOffset + y * stride, stride).copy(raw, y * (stride + 1) + 1)
  }
  const ihdr = Buffer.alloc(13)
  ihdr.writeUInt32BE(w, 0)
  ihdr.writeUInt32BE(h, 4)
  ihdr[8] = 8
  ihdr[9] = 6
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk('IHDR', ihdr),
    chunk('IDAT', deflateSync(raw, { level: 9 })),
    chunk('IEND', Buffer.alloc(0)),
  ])
}

/** 最近邻放大（保留像素边界，评审小尺寸细节时不做平滑）。 */
function upscale(img, factor) {
  const { data, width: w, height: h } = img
  const W = w * factor
  const H = h * factor
  const out = new Uint8Array(W * H * 4)
  for (let y = 0; y < H; y += 1) {
    const sy = Math.floor(y / factor)
    for (let x = 0; x < W; x += 1) {
      const sx = Math.floor(x / factor)
      const si = (sy * w + sx) * 4
      const di = (y * W + x) * 4
      out[di] = data[si]
      out[di + 1] = data[si + 1]
      out[di + 2] = data[si + 2]
      out[di + 3] = data[si + 3]
    }
  }
  return { data: out, width: W, height: H }
}

/** 铺底色（按 alpha 合成），pad 使图标居中并留边。 */
function onBackground(img, [r, g, b], pad = 16) {
  const W = img.width + pad * 2
  const H = img.height + pad * 2
  const out = new Uint8Array(W * H * 4)
  for (let i = 0; i < W * H; i += 1) {
    out[i * 4] = r
    out[i * 4 + 1] = g
    out[i * 4 + 2] = b
    out[i * 4 + 3] = 255
  }
  for (let y = 0; y < img.height; y += 1) {
    for (let x = 0; x < img.width; x += 1) {
      const si = (y * img.width + x) * 4
      const a = img.data[si + 3] / 255
      const di = ((y + pad) * W + (x + pad)) * 4
      out[di] = Math.round(img.data[si] * a + out[di] * (1 - a))
      out[di + 1] = Math.round(img.data[si + 1] * a + out[di + 1] * (1 - a))
      out[di + 2] = Math.round(img.data[si + 2] * a + out[di + 2] * (1 - a))
      out[di + 3] = 255
    }
  }
  return { data: out, width: W, height: H }
}

function main() {
  const jobs = [
    { src: 'tray-16.png', factor: 8, out: 'stage61-icon-16px-zoom.png', note: '托盘 16px → 8×（128px）' },
    { src: 'ball.png', factor: 3, out: 'stage61-icon-96px-zoom.png', note: '球 96px → 3×（288px）' },
  ]
  for (const j of jobs) {
    const img = decodePng(readFileSync(join(ICONS, j.src)))
    const big = upscale(img, j.factor)
    writeFileSync(join(SHOTS, j.out), encodePng(big.data, big.width, big.height))
    console.log(`made data/shots/${j.out}  (${j.note}; ${big.width}x${big.height})`)
  }
  // 亮/暗壁纸：球 2× 铺在纯白 / 深灰上
  const ball = decodePng(readFileSync(join(ICONS, 'ball.png')))
  const big2 = upscale(ball, 2)
  writeFileSync(join(SHOTS, 'stage61-ball-on-light.png'), (() => {
    const c = onBackground(big2, [255, 255, 255], 24)
    return encodePng(c.data, c.width, c.height)
  })())
  writeFileSync(join(SHOTS, 'stage61-ball-on-dark.png'), (() => {
    const c = onBackground(big2, [16, 22, 31], 24)
    return encodePng(c.data, c.width, c.height)
  })())
  console.log('made data/shots/stage61-ball-on-light.png  (纯白壁纸)')
  console.log('made data/shots/stage61-ball-on-dark.png   (深灰壁纸)')
}

main()
