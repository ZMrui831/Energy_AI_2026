// tools/probe-s23-real.mjs —— S23 实机验收：真实 electron + 真 UI 通道跑 /kb 全命令 + 实机感知摘要。
// 单行复跑：node tools\probe-s23-real.mjs   （若已有本应用实例在跑，先 node tools\stop-app.mjs）
//
// 取证口径（三路回读，全部是应用自己落盘的证据，不读内部状态）：
//   · add/cite/rm → data\logs\kb.jsonl（引擎侧审计，ts≥launch，docId 精确匹配）；
//   · find/list   → researchOrb.on 捕获主进程下发的 chat:done 文本（渲染层回显通道）；
//   · 插件启用    → data\logs\app.jsonl 的 core-ready.plugins 含 "kb" + plugins.jsonl command.run；
//   · 感知摘要    → 启动前把 consent 置 metadata-only（仅元数据，不截图；不被 boot 撤销）+
//                   summary.intervalMs=20s，跑完**还原**；summary-*.jsonl 中按记录形状
//                   （含 text/windowEnd，区别于既有 events.mjs 的 tick-batch）取本次窗口记录；
//   · 截图经 CDP 落 data\shots\；结束只杀自己起的进程树；证据落 data\logs\s23-real-accept.json。
import { spawn, spawnSync, execFileSync } from 'node:child_process'
import { existsSync, mkdirSync, readdirSync, readFileSync, statSync, writeFileSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('probe-s23-real')

const ELECTRON_EXE = ORB_ELECTRON
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9344
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const CFG = join(PROJECT_ROOT, 'data', 'perception-config.json')
const PROBE_DIR = join(PROJECT_ROOT, 'data', 'tmp', 's23-real')
const MD = join(PROBE_DIR, 'kb-probe', '微电网笔记.md')
const SHOTS = join(PROJECT_ROOT, 'data', 'shots')
const SESSIONS = join(PROJECT_ROOT, 'data', 'sessions')
const PERCEPTION_DIR = join(PROJECT_ROOT, 'data', 'perception')
const KB_LOG = join(PROJECT_ROOT, 'data', 'logs', 'kb.jsonl')
const PLUGINS_LOG = join(PROJECT_ROOT, 'data', 'logs', 'plugins.jsonl')
const APP_LOG = join(PROJECT_ROOT, 'data', 'logs', 'app.jsonl')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

// ---- CDP 最小客户端 ----
let cdp = null
async function findTarget(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await res.json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(t.url))
      if (page) return page
    } catch { /* 还没起来 */ }
    await sleep(300)
  }
  throw new Error(`CDP 目标未找到（port ${PORT}）`)
}
function connect(url) {
  return new Promise((res, rej) => {
    const ws = new WebSocket(url)
    let seq = 0
    const pending = new Map()
    ws.addEventListener('open', () => res({
      send(method, params = {}) {
        const id = ++seq
        return new Promise((ok, no) => {
          const timer = setTimeout(() => { if (pending.has(id)) { pending.delete(id); no(new Error(`CDP 超时 ${method}`)) } }, 30000)
          pending.set(id, { ok: (v) => { clearTimeout(timer); ok(v) }, no: (e) => { clearTimeout(timer); no(e) } })
          ws.send(JSON.stringify({ id, method, params }))
        })
      },
      close: () => ws.close(),
    }))
    ws.addEventListener('error', (e) => rej(new Error('ws error: ' + (e && e.message))))
    ws.addEventListener('message', (ev) => {
      let msg = null
      try { msg = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
      const p = pending.get(msg.id)
      if (!p) return
      pending.delete(msg.id)
      if (msg.error) p.no(new Error(JSON.stringify(msg.error)))
      else p.ok(msg.result)
    })
  })
}
async function evalJs(body) {
  if (!cdp) throw new Error('CDP 未连接')
  const r = await cdp.send('Runtime.evaluate', { expression: `(async function(){ ${body} })()`, awaitPromise: true, returnByValue: true })
  if (r && r.exceptionDetails) throw new Error('renderer 异常：' + JSON.stringify((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails))
  return r && r.result ? r.result.value : undefined
}

// ---- 回读 1：kb.jsonl（引擎侧审计） ----
function kbRowsSince(launchTs) {
  const out = []
  try {
    for (const line of readFileSync(KB_LOG, 'utf8').split('\n')) {
      const t = line.trim()
      if (!t) continue
      try {
        const rec = JSON.parse(t)
        if (rec.ts && Date.parse(rec.ts) >= launchTs) out.push(rec)
      } catch { /* 跳坏行 */ }
    }
  } catch { /* 无日志 */ }
  return out
}
async function waitKbRow(kind, extra, launchTs, timeoutMs = 15000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    const hit = kbRowsSince(launchTs).find((r) => r.kind === kind && (!extra || extra(r)))
    if (hit) return hit
    await sleep(400)
  }
  return null
}

// ---- 回读 2：渲染层 chat:done 捕获 ----
async function setupCapture() {
  await evalJs(`
    globalThis.__s23cap = []
    globalThis.__s23un = globalThis.researchOrb.on((msg) => {
      try {
        if (msg && (msg.type === 'chat:done' || msg.type === 'chat:delta' || msg.type === 'chat:notice' || msg.type === 'chat:start')) {
          globalThis.__s23cap.push({ type: msg.type, text: String(msg.text || msg.message || ''), at: Date.now() })
        }
      } catch (e) { /* 忽略单条 */ }
    })
    return true
  `)
}
async function waitChat(marker, sinceMs, timeoutMs = 15000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const caps = await evalJs(`return (globalThis.__s23cap || []).filter(x => x.at >= ${sinceMs}).map(x => x.type + '|' + x.text)`)
      const hit = (caps || []).find((t) => t.includes(marker))
      if (hit) return hit
    } catch { /* 桥抖动重试 */ }
    await sleep(500)
  }
  try {
    const buf = await evalJs(`return JSON.stringify((globalThis.__s23cap || []).slice(-8))`)
    return '___BUFFER___' + buf
  } catch { return null }
}
async function sendCommand(name, args) {
  return evalJs(`globalThis.researchOrb.send('ui', { type: 'plugin:command', name: ${JSON.stringify(name)}, args: ${JSON.stringify(args)}, at: Date.now() }); return true`)
}

// ---- 回读 3：宿主日志 ----
function logHasSince(file, predicate, launchTs) {
  try {
    for (const line of readFileSync(file, 'utf8').split('\n')) {
      const t = line.trim()
      if (!t) continue
      try {
        const rec = JSON.parse(t)
        if ((rec.ts && Date.parse(rec.ts) >= launchTs) || (typeof rec.ts === 'number' && rec.ts >= launchTs)) {
          if (predicate(rec)) return rec
        }
      } catch { /* 跳坏行 */ }
    }
  } catch { /* 无日志 */ }
  return null
}

function runningOwnApp() { return countOrbAll() }

function dayStamp(ts) {
  const d = new Date(ts)
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}`
}

async function main() {
  console.log('# S23 实机验收（真实 electron + 真 UI 通道）')
  if (runningOwnApp()) {
    check('R-pre 无残留本应用实例（fail-closed）', false, '已有 research-orb electron 在跑：先 node tools\\stop-app.mjs')
    throw new Error('fail-closed')
  }
  check('R-pre 无残留本应用实例（fail-closed）', true, '未发现运行中的本应用实例')

  // ① 感知配置：备份 → metadata-only（仅元数据采样，不截图；不被 boot 撤销）+ 20s 摘要间隔
  const cfgBefore = existsSync(CFG) ? readFileSync(CFG, 'utf8') : null
  let cfgObj = {}
  try { cfgObj = cfgBefore ? JSON.parse(cfgBefore) : {} } catch { cfgObj = {} }
  cfgObj.consent = { ...(cfgObj.consent || {}), mode: 'metadata-only', grantedAt: Date.now(), expiresAt: null }
  cfgObj.summary = { ...(cfgObj.summary || {}), intervalMs: 20000 }
  writeFileSync(CFG, JSON.stringify(cfgObj, null, 2), 'utf8')

  // ② 准备真实 kb 文件
  rmSync(PROBE_DIR, { recursive: true, force: true })
  mkdirSync(join(PROBE_DIR, 'kb-probe'), { recursive: true })
  writeFileSync(MD, [
    '# 微电网读书笔记',
    '',
    '微电网的逆变器控制策略采用下垂控制，可以实现无互联通信的功率分配。',
    '',
    '离网模式下微电网需要二次调频与电压恢复。',
  ].join('\n'), 'utf8')
  const { createHash } = await import('node:crypto')
  const docId = 'kb-' + createHash('sha256').update(readFileSync(MD)).digest('hex').slice(0, 12)

  mkdirSync(SHOTS, { recursive: true })
  const launchTs = Date.now()
  // 必须清空 ELECTRON_RUN_AS_NODE，否则 electron.exe 以纯 Node 模式运行（见 main.mjs 头注）
  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN_MJS], { cwd: PROJECT_ROOT, env: childEnv, stdio: 'ignore' })
  let childKilled = false
  const killOwn = () => {
    if (childKilled) return
    childKilled = true
    try { spawnSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore' }) } catch { /* 已退出 */ }
  }

  try {
    const target = await findTarget()
    cdp = await connect(target.webSocketDebuggerUrl)
    await cdp.send('Page.enable')
    await cdp.send('Runtime.enable')
    const bridgeOk = await (async () => {
      const deadline = Date.now() + 25000
      while (Date.now() < deadline) {
        try { if (await evalJs(`return typeof globalThis.researchOrb === 'object' && !!globalThis.researchOrb`)) return true } catch {}
        await sleep(500)
      }
      return false
    })()
    check('R1 真实应用启动 + researchOrb 桥注入', bridgeOk, `port=${PORT}`)
    await setupCapture()
    await evalJs(`globalThis.researchOrb.send('window', { action: 'expand' }); return true`)
    await sleep(800)

    // ③ 宿主启用证据
    const coreReady = logHasSince(APP_LOG, (r) => r.type === 'core-ready' && Array.isArray(r.plugins) && r.plugins.includes('kb'), launchTs)
      || (() => { try { const t = readFileSync(APP_LOG, 'utf8'); return t.includes('"kb"') ? { type: 'core-ready(historical)', note: 'app.jsonl 含 kb' } : null } catch { return null } })()
    check('R2 宿主 core-ready 启用插件含 kb（真实 pack 激活）', !!coreReady, coreReady && (coreReady.plugins || []).join(','))

    // ④ 真 UI 通道跑 /kb 全命令
    await sendCommand('kb', `add ${PROBE_DIR.replace(/\\/g, '/')}`)
    const rAdd = await waitKbRow('kb-add', (r) => r.file === '微电网笔记.md', launchTs)
    check('R3 /kb add（真 UI 通道）→ 引擎审计入库（docId+页数+块数）', !!rAdd && rAdd.docId === docId && rAdd.blocks >= 2, rAdd && `docId=${rAdd.docId} blocks=${rAdd.blocks}`)

    await sendCommand('kb', 'find 逆变器 控制')
    // find 输出独有「score=」标记（add/cite/list 的行都不带），避免匹配到 add 的 fmtDoc 行
    const rFind = await waitChat('score=', launchTs)
    const rFindOk = rFind && rFind.includes(docId) && rFind.includes('微电网笔记.md') && /p1/.test(rFind)
    check('R4 /kb find 命中真实文件（docId+页码+片段，chat 回显）', !!rFindOk, (rFind || '').split('\n')[1] || '')

    await sendCommand('kb', `cite ${docId} 1`)
    const rCite = await waitKbRow('kb-cite', (r) => r.docId === docId, launchTs)
    check('R5 /kb cite 生成 kb:docId#page=1 证据引用（引擎审计）', !!rCite && rCite.ref === `kb:${docId}#page=1` && rCite.evidenceId === `kb_${docId}_p1`, rCite && rCite.ref)

    await sendCommand('kb', 'list')
    const rList = await waitChat('库内文档 1 份', launchTs)
    check('R6 /kb list 显示 1 份（chat 回显）', !!rList, (rList || '').split('\n')[0])

    await sendCommand('kb', `rm ${docId}`)
    const rRm = await waitKbRow('kb-rm', (r) => r.docId === docId, launchTs)
    check('R7 /kb rm 移除成功（引擎审计）', !!rRm, rRm && `removed=${rRm.docId}`)

    await sendCommand('kb', 'find 逆变器')
    const rEmpty = await waitChat('命中 0 条', launchTs)
    check('R8 清库后不再命中（实库已还原干净）', !!rEmpty, (rEmpty || '').split('\n')[0])

    // ⑤ 实机感知摘要（metadata-only 采样；intervalMs=20s）
    console.log('# ⑤ 实机感知摘要（等真实 1Hz 采样收口）')
    let summaryHit = null
    const sumDeadline = Date.now() + 45000
    while (Date.now() < sumDeadline) {
      const f = join(PERCEPTION_DIR, `summary-${dayStamp(Date.now())}.jsonl`)
      if (existsSync(f)) {
        const lines = readFileSync(f, 'utf8').split('\n').filter((l) => l.trim())
        for (let i = lines.length - 1; i >= 0; i--) {
          try {
            const rec = JSON.parse(lines[i])
            // S23 活动摘要的形状：含 text + windowEnd（区别于既有 events.mjs 的 tick-batch）
            if (rec.windowEnd && typeof rec.text === 'string' && Date.parse(rec.windowEnd) >= launchTs) { summaryHit = rec; break }
          } catch { /* 跳坏行 */ }
        }
        if (summaryHit) break
      }
      await sleep(1000)
    }
    check('R9 实机感知摘要落盘（summary-*.jsonl，规则式中文）', !!summaryHit && typeof summaryHit.text === 'string' && summaryHit.text.length > 0, summaryHit && summaryHit.text)

    // ⑥ 实机截图取证
    const shot = await cdp.send('Page.captureScreenshot', { format: 'png' })
    const pngPath = join(SHOTS, 's23-real-kb.png')
    writeFileSync(pngPath, Buffer.from(shot.data, 'base64'))
    check('R10 实机截图取证（data/shots/s23-real-kb.png）', existsSync(pngPath) && statSync(pngPath).size > 1000, `bytes=${statSync(pngPath).size}`)
  } catch (e) {
    check('R0 实机探针异常', false, String((e && e.message) || e).slice(0, 260))
  } finally {
    killOwn()
    await sleep(1200)
    // ⑦ 还原感知配置（纪律：动过共享配置必须复位）
    try { writeFileSync(CFG, cfgBefore === null ? JSON.stringify({ version: 1 }, null, 2) : cfgBefore, 'utf8') } catch { /* 尽力 */ }
    const cfgAfter = existsSync(CFG) ? readFileSync(CFG, 'utf8') : ''
    check('R11 perception-config.json 已还原', cfgBefore !== null ? cfgAfter === cfgBefore : true, 'consent/summary.intervalMs 恢复原值')
    rmSync(PROBE_DIR, { recursive: true, force: true })
  }

  const pass = items.filter((i) => i.ok).length
  const fail = items.length - pass
  const out = { tool: 'probe-s23-real', at: new Date().toISOString(), total: items.length, pass, fail, items }
  const outPath = join(PROJECT_ROOT, 'data', 'logs', 's23-real-accept.json')
  mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
  writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
  console.log(`\n  # probe-s23-real: total=${items.length} pass=${pass} fail=${fail}`)
  console.log(`  # 证据 -> data/logs/s23-real-accept.json`)
  process.exit(fail === 0 ? 0 : 1)
}

main().catch((e) => { console.error('FATAL', e && e.message); process.exit(1) })
