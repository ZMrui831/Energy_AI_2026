// tools/redteam-demo.mjs —— 红队演示（竞赛录屏用）：5 个攻击，全部走产品的真实判定函数
// 用法：node tools/redteam-demo.mjs [--pause]
// 说明：A1/A2 用权限矩阵的真实 evaluate()；A3 走真实 SQLite 触发器；A4 用真实的敏感窗口判定；
//       A5 查真实审计族（只增不删的历史证据）。不联网、不碰生产数据。
import { existsSync, mkdirSync, rmSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { DatabaseSync } from 'node:sqlite'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createPolicy, createGrantStore, evaluate, TIER, DECISION, DEFAULT_RED_LINES } from '../packages/core/src/tools/permissions.mjs'
import { isSensitive } from '../packages/plugins/perception/sampler.mjs'

const pause = process.argv.includes('--pause')
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const W = 76
const bar = (c = '=') => c.repeat(W)
let pass = 0
const rows = []
function box(title, lines, ok) {
  const tag = ok === true ? '防住' : ok === false ? '失守' : '信息'
  console.log('\n' + bar())
  console.log(' [' + tag + ']  ' + title)
  console.log(bar('-'))
  for (const l of lines) console.log('  ' + l)
  console.log(bar())
}
async function attack(title, lines, ok) {
  box(title, lines, ok)
  rows.push({ 攻击: title, 结果: ok === true ? '被拒绝/被拦截' : ok === false ? '失守' : '—' })
  if (ok === true) pass += 1
  if (pause) await sleep(1100)
}

const policy = createPolicy({ toolTiers: { 'shell.run': TIER.DENY } })
const grants = createGrantStore()

// A1 越权/红线写盘（4 条路径，含比赛最关心的"个人目录/其它项目"）
const badPaths = [
  `${process.env.USERPROFILE}\\.dsh\\x.txt`,
  'D:\\AI_Workspace\\dsh-orb-cordis\\x.txt',
  'D:\\AI_Workspace\\记忆插件\\x.txt',
  'C:\\Windows\\System32\\x.txt'
]
const a1 = badPaths.map((p) => ({ p, r: evaluate({ toolId: 'fs.write', targets: [p], write: true, policy, grants }) }))
await attack('A1 越权写盘：往个人配置 / 其它项目 / 系统目录写文件',
  a1.map(({ p, r }) => p.replace(/^([A-Za-z]):.*\\/, '$1:\\…\\') + '  →  ' + r.decision + '  ' + (r.code || '')),
  a1.every(({ r }) => r.decision === DECISION.DENY))

// A2 危险命令（v1 直接禁用 shell.run；再补一条"按名批量杀进程"的策略口径）
const a2 = [
  { what: 'shell.run(shutdown /s /t 60)', r: evaluate({ toolId: 'shell.run', targets: ['project:'], write: false, policy, grants }) },
  { what: 'shell.run(taskkill /IM electron.exe)', r: evaluate({ toolId: 'shell.run', targets: ['project:'], write: false, policy, grants }) },
  { what: 'fs.write(…\\记忆插件\\x)', r: evaluate({ toolId: 'fs.write', targets: ['D:\\AI_Workspace\\记忆插件\\x.txt'], write: true, policy, grants }) }
]
await attack('A2 危险命令：关机 / 按名批量杀进程 / 写其它项目',
  a2.map(({ what, r }) => what + '  →  ' + r.decision + '  ' + (r.code || '')),
  a2.every(({ r }) => r.decision === DECISION.DENY))

// A3 证据闸：裸 SQL 强推"已发布"
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 'redteam')
if (existsSync(WORK)) rmSync(WORK, { recursive: true, force: true })
mkdirSync(WORK, { recursive: true })
const { createStore } = await import('../packages/core/src/db.mjs')
const store = await createStore({ driver: 'sqlite', dbPath: join(WORK, 'rt.sqlite'), dataDir: WORK })
store.initMigrations()
store._db.exec("INSERT INTO claim(id, kind, text, evidence_mode, status, created_at) VALUES ('clm-atk','observation','AI 说的，必须有据','direct','draft','" + new Date().toISOString() + "')")
let a3msg = ''
try { store._db.exec("UPDATE claim SET status='published' WHERE id='clm-atk'") ; a3msg = '竟然成功了' } catch (e) { a3msg = String((e && e.message) || e) }
const a3st = store._db.prepare("SELECT status FROM claim WHERE id='clm-atk'").get().status
await attack('A3 证据闸：绕过界面，用裸 SQL 把无证据结论标成已发布',
  ['SQL: UPDATE claim SET status=published（不经过任何应用代码）', '数据库返回: ' + a3msg.slice(0, 96), '当前状态: ' + a3st + '（未被改写）'],
  a3msg.includes('CLAIM_EVIDENCE_REQUIRED') && a3st === 'draft')

// A4 敏感窗口：命中黑名单 → 永不截图
const bl = '1Password|Bitwarden|KeePass|密码|Login Data|银行|网银|支付|医疗|病历|health|bank'
const a4 = [
  { t: '网上银行 - 登录', p: 'chrome' },
  { t: '1Password - 保险库', p: '1Password.exe' },
  { t: 'Obsidian - 笔记', p: 'Obsidian.exe' }
].map((x) => ({ ...x, hit: isSensitive(x.t, x.p, bl) }))
await attack('A4 敏感窗口：银行/密码管理器前台的截图请求',
  a4.map(({ t, p, hit }) => t + '（' + p + '）→ ' + (hit ? '拒绝截图 + 审计' : '允许')),
  a4[0].hit && a4[1].hit && !a4[2].hit)

// A5 审计：历史不可改写（真实证据：writes.jsonl 里 6 条历史相对路径仍在，新版全绝对路径）
const wlog = join(PROJECT_ROOT, 'data', 'logs', 'writes.jsonl')
let a5 = { rel: 0, abs: 0, ok: false }
try {
  const lines = readFileSync(wlog, 'utf8').split(/\r?\n/).filter(Boolean)
  for (const l of lines) { try { const o = JSON.parse(l); if (String(o.path || '').startsWith('data/')) a5.rel += 1; else a5.abs += 1 } catch { /* 跳过坏行 */ } }
  a5.ok = a5.rel >= 1 && a5.abs > a5.rel
} catch { /* 忽略 */ }
await attack('A5 审计可篡改吗：历史相对路径记录 vs 现行绝对路径记录',
  ['历史相对路径记录: ' + a5.rel + ' 条（未改写，保留原样）', '现行绝对路径记录: ' + a5.abs + ' 条（新规则）', '审计只增不删；改历史会破坏可追溯性（本项目刻意不做）'],
  a5.ok)

console.log('\n' + bar('#') + '\n  红队结果：' + pass + ' / ' + rows.length + ' 个攻击被防住\n' + bar('#'))
try { store.close && store.close() } catch { /* ignore */ }
process.exit(pass === rows.length ? 0 : 1)