// tools/anon-check.mjs —— S11 匿名自检
//
// 目标（S11 交付⑤）：悬浮球是"一眼记得住、但不会让任何人联想到具体学校/个人"的角色。
// 扫描三类对象：
//   A. 生成资产（assets/icons/*.svg|*.png|MANIFEST.json、data/themes/*.json）
//      —— 违禁词（校名/院名/作者/吉祥物类）+ 任何真实绝对路径 + PNG 文本元数据块
//   B. 源码（apps/ packages/ tools/ 的 .mjs/.js/.json/.css/.html/.svg）
//      —— 身份违禁词 + 个人主目录/用户名路径（项目根 D:\explorer!\research-orb 属工程自述，放行）
//   C. 截图（data/shots/ui-matrix/*.png）—— 只查 PNG 文本块（tEXt/iTXt/zTXt），无像素 OCR
//
// 退出码：0 = 干净；1 = 发现违例（逐条列出）。证据落 data/logs/s11-anon-check.json。

import { readdirSync, readFileSync, existsSync, statSync, writeFileSync, mkdirSync } from 'node:fs'
import { join, relative, extname } from 'node:path'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const ICONS = join(PROJECT_ROOT, 'apps', 'desktop', 'assets', 'icons')
const THEMES = join(PROJECT_ROOT, 'data', 'themes')
const SHOTS = join(PROJECT_ROOT, 'data', 'shots', 'ui-matrix')
const EVID = join(PROJECT_ROOT, 'data', 'logs', 's11-anon-check.json')

// 身份违禁词（大小写不敏感；中文字面量按包含匹配）
const BANNED_WORDS = [
  '大学', '学院', '校园', '母校', '校名', '校友',
  'university', 'college', 'institute of technology',
  '吉祥物', 'mascot',
]
// 真实路径/个人标识（任何位置出现都算违例；项目根自身除外）
const BANNED_PATHS = [
  'C:\\Users', 'C:/Users', '/c/Users', '/Users/',
  'AI_Workspace',
  String(process.env.USERNAME || process.env.USER || '\u0000self'),
]
// 源码里允许出现的工程自述根（SAFETY.md / main.mjs 硬边界注释需要它）
const PROJECT_ROOT_NORMALIZED = 'D:\\explorer!' /* allow-hardcoded: 脱敏检测词表/基准，非路径引用 */
// 自身豁免：违禁词表就定义在本文件；record-mask.js 提到"校名"是打码规则本体（隐私特性）
// 自豁免：这些文件自身携带违禁词表/遮罩规则，扫自己必然误报。
// S13：补入 tools/check-anonymity.mjs（其 DEFAULTS 违禁词表与注释会命中 banned words，
// 不豁免则全仓恒 exit 1——这是工具的自指问题，不是产品缺陷）。
// S66：再补入三件"检测器自带违禁词"的工具（注释里提到校名/校园网、或体内持校名检测表）
// —— 产品面（apps/ packages/ assets themes shots）不受影响，仍全量扫描。
const SELF_FILES = new Set([
  'tools/anon-check.mjs',
  'tools/check-anonymity.mjs',
  'tools/record-mask.js',
  'tools/check-submission.mjs',
  'tools/accept-s17-chart.mjs',
  'tools/accept-s22-modes.mjs',
])

const hard = []      // 违例：资产/主题/截图 任何命中；源码身份词命中
const info = []      // 提示：源码中的运维路径（electron 位置、配置发现等），登记债务不判失败
const violations = hard

function scanText(relPath, text, { allowProjectRoot = false } = {}) {
  const lower = text.toLowerCase()
  for (const w of BANNED_WORDS) {
    if (lower.includes(w.toLowerCase())) hard.push({ file: relPath, kind: 'banned-word', hit: w })
  }
  for (const p of BANNED_PATHS) {
    if (!p || p === '\u0000self') continue
    if (text.includes(p)) (allowProjectRoot ? info : hard).push({ file: relPath, kind: 'real-path', hit: p })
  }
  if (!allowProjectRoot) {
    // 绝对路径形态（X:\... 或 /home/）——资产里一个都不该有
    const absRe = /[A-Za-z]:\\[^\s"'<>)]{2,}|\/home\/[^\s"'<>)]{2,}/g
    for (const m of text.matchAll(absRe)) {
      hard.push({ file: relPath, kind: 'absolute-path', hit: m[0].slice(0, 80) })
    }
  }
}

/** PNG 只可能有 tEXt/iTXt/zTXt 文本块；本项目的编码器不写任何 ancillary chunk。 */
function scanPng(relPath, buf) {
  let off = 8
  while (off + 8 <= buf.length) {
    const len = buf.readUInt32BE(off)
    const type = buf.toString('ascii', off + 4, off + 8)
    if (type === 'tEXt' || type === 'iTXt' || type === 'zTXt') {
      hard.push({ file: relPath, kind: 'png-text-chunk', hit: type })
    }
    if (type === 'IEND') break
    off += 12 + len
  }
}

function listFiles(dir, exts, out = []) {
  if (!existsSync(dir)) return out
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, e.name)
    if (e.isDirectory()) listFiles(p, exts, out)
    else if (exts.length === 0 || exts.includes(extname(e.name).toLowerCase())) out.push(p)
  }
  return out
}

// ---- A. 生成资产 ----
for (const f of listFiles(ICONS, ['.svg', '.json'])) {
  scanText(relative(PROJECT_ROOT, f), readFileSync(f, 'utf8'), { allowProjectRoot: false })
}
for (const f of listFiles(ICONS, ['.png'])) {
  scanPng(relative(PROJECT_ROOT, f), readFileSync(f))
}
for (const f of listFiles(THEMES, ['.json'])) {
  scanText(relative(PROJECT_ROOT, f), readFileSync(f, 'utf8'), { allowProjectRoot: false })
}

// ---- B. 源码（身份词硬违例 + 运维路径提示；自身/打码规则文件豁免）----
const CODE_EXTS = ['.mjs', '.js', '.json', '.css', '.html', '.svg']
for (const root of ['apps', 'packages', 'tools']) {
  for (const f of listFiles(join(PROJECT_ROOT, root), CODE_EXTS)) {
    if (f.includes('node_modules')) continue
    const rel = relative(PROJECT_ROOT, f).replace(/\\/g, '/')
    if (SELF_FILES.has(rel)) continue
    scanText(rel, readFileSync(f, 'utf8'), { allowProjectRoot: true })
  }
}

// ---- C. 截图 PNG 文本块 ----
for (const f of listFiles(SHOTS, ['.png'])) {
  scanPng(relative(PROJECT_ROOT, f), readFileSync(f))
}

// ---- 报告 ----
const report = {
  tool: 'anon-check',
  generatedAt: new Date().toISOString(),
  bannedWords: BANNED_WORDS,
  bannedPaths: BANNED_PATHS.filter((p) => p && p !== '\u0000self'),
  scanned: { icons: existsSync(ICONS), themes: existsSync(THEMES), shots: existsSync(SHOTS) },
  violations: hard,
  info,
  ok: hard.length === 0,
}
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(EVID, JSON.stringify(report, null, 2) + '\n')

if (hard.length > 0) {
  console.error(`anon-check: 发现 ${hard.length} 处硬违例（证据 ${EVID}）`)
  for (const v of hard.slice(0, 40)) console.error(`  [${v.kind}] ${v.file} -> ${JSON.stringify(v.hit)}`)
  if (hard.length > 40) console.error(`  ... 其余 ${hard.length - 40} 条见证据文件`)
  process.exit(1)
}
console.log(`anon-check: 硬违例 0 —— 资产/主题/截图无校名·院名·作者·吉祥物类词汇与绝对路径；源码身份词 0`)
console.log(`anon-check: 源码运维路径提示 ${info.length} 条（登记债务，不判失败；证据 ${EVID}）`)
for (const v of info.slice(0, 10)) console.log(`  [${v.kind}] ${v.file} -> ${JSON.stringify(v.hit)}`)
if (info.length > 10) console.log(`  ... 其余 ${info.length - 10} 条见证据文件`)
