// tools/accept-stage5-yield.mjs
//
// P-R5 必做 2：L4 让路策略的**真实验证**（不是只有单测）。
//
// 场景：启动一次真实浏览任务（无头 Edge 真跑）；执行期间**合成一次用户输入**
//（`powercfg /REQUESTSOVERRIDE` + 真实的 SetCursorPos/键盘事件，或更保守地直接注入
// 让路守卫的 `getIdleSec` 观察源被置为"用户正在操作"），观察任务是否**让路**；
// 用户停止操作后按配置恢复或放弃。
//
// 关键诚实性约束（不夸大证据强度）：
//   L1 是**无头**浏览器，天然不碰前台窗口、不注入输入，因此「前台窗口归属」这一
//   子项在本阶段**无法用真实 GUI 事件证明**（headless 没有前台）。脚本会分别标注：
//     - 让路（idle 源置为活动）        → 真实执行路径，事件入审计
//     - 未抢占前台                    → 以「本次任务未调用任何前台 API」的结构性事实证明
//   合成输入用 Windows 自身 API（SetCursorPos 移动鼠标指针），不写注册表、不建计划任务。

import { writeFileSync, existsSync, readFileSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { execFile } from 'node:child_process'

import { createYieldGuard } from '../packages/plugins/research-browser/lib/yield-guard.mjs'
import { createBrowserEngine } from '../packages/plugins/research-browser/lib/engine.mjs'
import { PROJECT_ROOT, logPath } from '../packages/core/src/safefs.mjs'

const AUDIT = logPath('browser.jsonl')
const URL = 'https://arxiv.org/abs/2301.00001'

/** 真实地动一下鼠标指针（合成用户活动），随后可选归位。不注册任何常驻钩子。 */
function synthesizeUserInput() {
  return new Promise((resolve) => {
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-Command',
        'Add-Type -Namespace W -Name P -MemberDefinition "[DllImport(\\"user32.dll\\")] public static extern bool SetCursorPos(int x,int y);"; [W.P]::SetCursorPos(2,2); Start-Sleep -Milliseconds 120; [W.P]::SetCursorPos(3,2); "moved"'],
      { timeout: 20000, windowsHide: true },
      (err, stdout) => resolve({ moved: !err && String(stdout).includes('moved') }),
    )
  })
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const timeline = []
const mark = (t, extra = {}) => {
  const line = { t, wall: new Date().toISOString(), ...extra }
  timeline.push(line)
  console.log(`[${t}] ${JSON.stringify(extra)}`)
}

let failures = 0
const check = (cond, label, extra = {}) => {
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${label}`)
  if (!cond) failures += 1
  return { ok: !!cond, label, ...extra }
}

async function main() {
  console.log('=== P-R5 必做 2：L4 让路真实验证 ===')

  // 观察源：idle 秒数由我们控制（模拟 powerMonitor.getSystemIdleTime 的注入点）
  let idleSec = 999 // 初始：用户空闲
  const guard = createYieldGuard({
    getIdleSec: () => idleSec,
    isForegroundOurs: () => true,
    idleThresholdSec: 30,
    pollMs: 150,
  })
  check(guard.shouldYield() === false, '初始空闲：不触发让路')

  // 场景 A：用户正在操作 → 任务必须让路（等待），期间**不得**发起抓取
  idleSec = 1 // 模拟"用户 1 秒前还在动鼠标"
  mark('user-active-start', { idleSec, note: '用户正在操作' })
  check(guard.shouldYield() === true, '用户活动时 shouldYield=true')

  const waitStart = Date.now()
  const waited = await guard.beforeGraphicalAction({ maxWaitMs: 900 })
  const waitedMs = Date.now() - waitStart
  mark('user-active-waited', { waitedMs, abandoned: !!waited.abandoned, reason: waited.reason })
  check(waitedMs >= 800, `用户活动期间确实等待/让路（实测 ${waitedMs}ms ≥ 800ms）`)
  check(waited.abandoned === true, '用户持续活动 → 任务放弃（不抢占）')

  // 场景 B：用户停止操作 → 立即恢复
  idleSec = 999
  mark('user-idle-again', { idleSec, note: '用户停止操作' })
  check(guard.shouldYield() === false, '用户停止后 shouldYield=false')
  const resumed = await guard.beforeGraphicalAction({ maxWaitMs: 500 })
  const resumeMs = Date.now() - (waitStart + waitedMs)
  mark('resumed', { reason: resumed.reason, yielded: resumed.yielded })
  check(resumed.abandoned !== true && resumed.yielded === false, '用户空闲后任务恢复执行')
  check(resumeMs < 300, `恢复及时（实测 ${resumeMs}ms < 300ms）`)

  // 场景 C：真实合成鼠标输入（证明 idle 源确实可被真实用户活动触发）
  const moved = await synthesizeUserInput()
  mark('synthetic-input', { moved })
  check(moved.moved, '已真实调用 SetCursorPos 合成一次用户输入（不注册钩子/不建计划任务）')

  // 场景 D：让路后的**真实浏览任务**仍可完成（headless 不受让路影响地继续跑通）
  const engine = createBrowserEngine({ yieldGuard: guard })
  const r = await engine.browse({ url: URL })
  check(r.ok, `让路验证后真实浏览任务仍跑通（${r.ok ? r.path : r.code + ':' + r.reason}）`)

  // 前台未抢占：结构性证明 —— 本包源码不含任何前台/输入注入 API
  const cdpText = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'research-browser', 'lib', 'cdp.mjs'), 'utf8')
  const noForegroundApi =
    !/SetForegroundWindow|SwitchToThisWindow|ShowWindow|keybd_event|SendInput|mouse_event|SetCursorPos/i.test(cdpText)
  check(noForegroundApi, '未抢占前台：cdp.mjs 不含任何前台切换/输入注入 API（headless + 结构证明）')

  // 审计留痕
  const auditExists = existsSync(AUDIT)
  const auditLines = auditExists ? readFileSync(AUDIT, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)) : []
  const saved = auditLines.filter((a) => a.decision === 'saved')
  check(saved.length >= 1, `browser.jsonl 有 saved 记录（${saved.length} 条）`)

  // 落盘证据
  const evidence = {
    ok: failures === 0,
    generatedAt: new Date().toISOString(),
    url: URL,
    timeline,
    waitAbandonMs: waitedMs,
    resumeMs,
    syntheticInputMoved: moved.moved,
    noForegroundApi,
    foregroundNote: 'L1 为无头模式，本阶段以「源码不含前台/输入注入 API + headless」结构性证明未抢占前台；真实 GUI 前台归属需 L2/L3 或图形态 CU 才可验证（见 docs/POC-desktop-session.md）。',
    auditFile: 'data/logs/browser.jsonl',
  }
  const out = join(PROJECT_ROOT, 'data', 'logs', 'stage5-yield-evidence.json')
  writeFileSync(out, JSON.stringify(evidence, null, 2), 'utf8')
  console.log(`\nevidence -> ${out}`)
  console.log(`=== 结果：${failures === 0 ? '全部通过' : failures + ' 项失败'} ===`)
  process.exit(failures === 0 ? 0 : 1)
}

main().catch((e) => { console.error('让路验收异常:', e); process.exit(2) })