// 隔离验收取证工具（只读）：对 dsh-orb 相关目录做确定性指纹 + 文件清单
import { createHash } from 'node:crypto'
import { readdirSync, readFileSync, statSync, writeFileSync, existsSync } from 'node:fs'
import { join } from 'node:path'

const TARGETS = {
  'dsh-orb-module': `${process.env.USERPROFILE}\\.dsh\\profiles\\desktop\\node_modules\\dsh-orb`,
  'orb-helper-data': `${process.env.USERPROFILE}\\.dsh\\dsh-orb\\helper-data`,
}

function walk(dir, out = []) {
  if (!existsSync(dir)) return out
  for (const name of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, name.name)
    if (name.isDirectory()) walk(p, out)
    else if (name.isFile()) out.push(p)
  }
  return out
}

const report = {}
for (const [key, dir] of Object.entries(TARGETS)) {
  const files = walk(dir).sort()
  const h = createHash('sha256')
  let totalBytes = 0
  const listing = []
  for (const f of files) {
    const st = statSync(f)
    const rel = f.slice(dir.length + 1)
    // 被运行中的 helper 占用的文件（原生 .node/句柄）读不到内容：退回 size+mtime 指纹，
    // 仍然足以发现"被改写/被替换"，并避免因 EBUSY 直接失败。
    let contentHash
    try {
      contentHash = createHash('sha256').update(readFileSync(f)).digest('hex')
    } catch (err) {
      contentHash = `${err.code}:${st.size}:${Math.round(st.mtimeMs)}`
    }
    h.update(rel + '\u0000' + st.size + '\u0000' + contentHash + '\n')
    totalBytes += st.size
    listing.push({ rel, size: st.size, mtime: new Date(st.mtimeMs).toISOString() })
  }
  report[key] = { dir, exists: existsSync(dir), files: files.length, totalBytes, digest: h.digest('hex'), listing }
}

const out = process.argv[2] || '/tmp/baseline.json'
writeFileSync(out, JSON.stringify(report, null, 1))
for (const [k, v] of Object.entries(report)) {
  console.log(`${k}: files=${v.files} bytes=${v.totalBytes} digest=${v.digest.slice(0, 32)}…`)
}
console.log('written -> ' + out)
