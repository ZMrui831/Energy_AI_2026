// tools/accept-s10-chat.mjs —— S10 镜 4 前半验收：会话消息一键成结论（CDP 驱动真实应用）。
//
// 独立性（CONTRACT §7）：CDP 驱动真实 electron；真实 IPC（researchOrb.send）+
// 真实 DOM 点击；不调用本片新增函数。本机未配置 provider（无 LLM），助手消息节点
// 经 CDP 注入（与底座 addMessage('assistant') 产物同构：.ro-msg.ro-assistant），
// 按钮装饰/点击/建稿/补证据/发布链路全真——此点在证据里显式申报。
//
// 单行复跑：node tools/run-isolated.mjs --label s10 --cmd "node tools/accept-s10-chat.mjs"

import './_accept-isolate.mjs' // S67·3-A：先于产品模块求值，把 data/logs 指到临时目录
import { spawn, spawnSync, execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { mkdirSync, writeFileSync, readFileSync, existsSync, rmSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT, logPath, dataPath } from '../packages/core/src/safefs.mjs'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-s10-chat')

const ELECTRON_EXE = ORB_ELECTRON
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const SHOTS = join(PROJECT_ROOT, 'data', 'shots', 's10')
const PORT = 9353
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const sha = (p) => createHash('sha256').update(readFileSync(p)).digest('hex')

mkdirSync(SHOTS, { recursive: true })
const items = []
function report(id, clause, ok, detail, evidence = {}) {
  items.push({ id, clause, ok: !!ok, detail, evidence })
  console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`)
}

async function findTarget(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const list = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(t.url))
      if (page) return page
    } catch { /* 还没起来 */ }
    await sleep(300)
  }
  throw new Error(`CDP 目标未找到（port ${PORT}）`)
}

let cdp = null
async function connectCdp() {
  const target = await findTarget()
  const ws = new WebSocket(target.webSocketDebuggerUrl)
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve)
    ws.addEventListener('error', () => reject(new Error('CDP WebSocket 连接失败')))
  })
  const pending = new Map()
  let id = 0
  ws.addEventListener('message', (ev) => {
    let m
    try { m = JSON.parse(ev.data) } catch { return }
    if (m.id !== undefined && pending.has(m.id)) {
      const p = pending.get(m.id)
      pending.delete(m.id)
      if (m.error) p.rej(new Error(m.error.message))
      else p.res(m.result)
    }
  })
  cdp = {
    send: (method, params = {}) => new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method, params })) }),
    evaluate: async (expression) => {
      const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true })
      return r && r.result ? r.result.value : undefined
    },
  }
  await cdp.send('Page.enable')
  await cdp.send('Runtime.enable')
}

async function shot(name) {
  const s = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
  const abs = join(SHOTS, name)
  writeFileSync(abs, Buffer.from(s.data, 'base64'))
  return abs
}
const cmd = (name, args) => cdp.evaluate(`window.researchOrb && window.researchOrb.send('ui', { type: 'plugin:command', name: ${JSON.stringify(name)}, args: ${JSON.stringify(args)} })`)
const dom = (expr) => cdp.evaluate(`(() => (${expr}))()`)

/** 前置状态：确保库内有一帧 ready 原图（补证据步骤用；S3 公开 API，显式申报）。 */
async function ensureReadyFrame() {
  const { DatabaseSync } = await import('node:sqlite')
  const d = new DatabaseSync(dataPath('db', 'orb.sqlite'))
  const row = d.prepare("SELECT id FROM raw_frame WHERE status = 'ready' ORDER BY created_at DESC LIMIT 1").get()
  if (row) { d.close(); return { created: false, id: row.id } }
  d.close()
  const { createStore } = await import('../packages/core/src/db.mjs')
  const shotsDir = join(PROJECT_ROOT, 'data', 'shots')
  mkdirSync(shotsDir, { recursive: true })
  const p = join(shotsDir, `s10-setup-${Date.now()}.png`)
  writeFileSync(p, Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'base64'))
  const store = await createStore({ driver: 'auto', dbPath: dataPath('db', 'orb.sqlite'), dataDir: dataPath('db') })
  const id = `rf-s10-setup-${Date.now()}`
  store.insertRawFrame({ id, file_path: p, sha256: createHash('sha256').update(readFileSync(p)).digest('hex'), sensitivity: 'normal', created_at: new Date().toISOString(), expires_at: new Date(Date.now() + 6 * 3600e3).toISOString() })
  store.close()
  return { created: true, id }
}

async function main() {
  const frame = await ensureReadyFrame()
  console.log(`  前置状态：ready 原图 ${frame.id}（${frame.created ? '本次经 S3 公开 API 新建' : '库内已有'}）`)

  if (countOrbAll() > 0) throw new Error('已有 research-orb electron 在运行（fail-closed）')

  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN_MJS], { cwd: PROJECT_ROOT, env: childEnv, stdio: 'ignore' })
  console.log(`  electron pid=${child.pid}`)
  try {
    await connectCdp()
    await sleep(7000)
    await cdp.evaluate(`window.researchOrb.send('window', { action: 'expand' })`)
    await sleep(2500)

    // 1) 注入一条助手回复（与 addMessage('assistant') 同构），进对话页
    const injected = await dom(`(() => {
      const t = document.getElementById('transcript')
      if (!t) return { ok: false, reason: 'no-transcript' }
      const node = document.createElement('div')
      node.className = 'ro-msg ro-assistant'
      const span = document.createElement('span')
      span.textContent = 'S10 验收：这段助手回复应当能被一键转成结论，并在证据不足时当场说明缺什么。'
      node.appendChild(span)
      t.appendChild(node)
      return { ok: true }
    })()`)
    await dom(`window.__s5 && window.__s5.page('chat')`)
    await sleep(900)
    const hasBtn = await dom(`(() => {
      const nodes = Array.from(document.querySelectorAll('#transcript .ro-msg.ro-assistant'))
      const last = nodes[nodes.length - 1]
      const btn = last ? Array.from(last.querySelectorAll('button')).find((b) => b.textContent === '转为结论') : null
      return { assistantCount: nodes.length, hasButton: !!btn, btnText: btn ? btn.textContent : null }
    })()`)
    report('S10-C1', 'CONTRACT §5/§6 对话页助手回复带"转为结论"入口', injected && injected.ok && hasBtn && hasBtn.hasButton,
      `助手消息=${hasBtn && hasBtn.assistantCount} 条；入口按钮存在=${hasBtn && hasBtn.hasButton}`, { injected, dom: hasBtn })
    await shot('c1-chat-toclaim.png')

    // 2) 点击"转为结论" → 跳发布页 → 新草稿（none）+ 缺证据禁发布 + 缺什么
    const click = await dom(`(() => {
      const nodes = Array.from(document.querySelectorAll('#transcript .ro-msg.ro-assistant'))
      const last = nodes[nodes.length - 1]
      const btn = last ? Array.from(last.querySelectorAll('button')).find((b) => b.textContent === '转为结论') : null
      if (!btn) return { ok: false, reason: 'no-button' }
      btn.click()
      return { ok: true }
    })()`)
    await sleep(2500)
    const afterCreate = await dom(`(() => {
      const page = document.getElementById('s5-publish')
      const rows = Array.from(document.querySelectorAll('#s5-publish .s5-row')).map((r) => r.textContent)
      const noneBadge = document.querySelector('#s5-publish .s5-none')
      const note = Array.from(document.querySelectorAll('#s5-publish .s5-note')).map((n) => n.textContent).find((t) => /不可发布|缺/.test(t))
      const pubBtn = Array.from(document.querySelectorAll('#s5-publish button')).find((b) => b.textContent === '发布')
      return { onPublish: !!(page && page.classList.contains('s5-on')), rows: rows.slice(0, 3), noneBadge: noneBadge ? noneBadge.textContent : null, blockedNote: note || null, publishBtn: !!pubBtn }
    })()`)
    report('S10-C2', 'CONTRACT §6 一键成稿：跳发布页 + none 降级徽标 + 禁发布且写明缺什么',
      click && click.ok && afterCreate && afterCreate.onPublish && afterCreate.noneBadge && afterCreate.blockedNote && !afterCreate.publishBtn,
      `跳发布页=${afterCreate && afterCreate.onPublish}；徽标="${afterCreate && afterCreate.noneBadge}"；拒因="${afterCreate && afterCreate.blockedNote ? afterCreate.blockedNote.slice(0, 46) : '无'}"；发布按钮=${afterCreate && afterCreate.publishBtn}`,
      { click, afterCreate })
    await shot('c2-blocked-missing-evidence.png')

    // 3) 补证据（关联今日原图）→ 发布成功
    const attach = await dom(`(() => {
      const btn = Array.from(document.querySelectorAll('#s5-publish button')).find((b) => b.textContent === '关联今日原图')
      if (!btn) return { ok: false, reason: 'no-attach-button' }
      btn.click()
      return { ok: true }
    })()`)
    await sleep(2000)
    const afterAttach = await dom(`(() => {
      const rows = Array.from(document.querySelectorAll('#s5-publish .s5-row')).map((r) => r.textContent)
      const pubBtn = Array.from(document.querySelectorAll('#s5-publish button')).find((b) => b.textContent === '发布')
      return { hasEvidenceId: rows.some((t) => /rf-/.test(t)), publishBtn: !!pubBtn, rows: rows.slice(0, 3) }
    })()`)
    const publish = await dom(`(() => {
      const btn = Array.from(document.querySelectorAll('#s5-publish button')).find((b) => b.textContent === '发布')
      if (!btn) return { ok: false, reason: 'no-publish-button' }
      btn.click()
      return { ok: true }
    })()`)
    await sleep(2500)
    const afterPublish = await dom(`(() => {
      const rows = Array.from(document.querySelectorAll('#s5-publish .s5-row')).map((r) => r.textContent)
      const note = (document.getElementById('s5-notice') || {}).textContent || ''
      return { published: rows.some((t) => /\\[published\\]/.test(t)), notice: note.slice(0, 60), rows: rows.slice(0, 3) }
    })()`)
    report('S10-C3', 'CONTRACT §6 补证据后发布成功（走 S6 publishClaim，不绕过）',
      attach && attach.ok && afterAttach && afterAttach.publishBtn && publish && publish.ok && afterPublish && afterPublish.published,
      `补证据后证据ID可见=${afterAttach && afterAttach.hasEvidenceId}；发布点击=${publish && publish.ok}；published 态=${afterPublish && afterPublish.published}；提示="${afterPublish && afterPublish.notice}"`,
      { attach, afterAttach, publish, afterPublish })
    await shot('c3-published.png')
  } finally {
    try { spawnSync('taskkill', ['/pid', String(child.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true }) } catch { /* noop */ }
    await sleep(800)

    report('S10-CLEAN', '§7 进程收尾', countOrbAll()=== 0, `残留=${String(countOrbAll())}`, {})
  }

  const out = {
    label: 's10-chat-to-claim',
    ts: new Date().toISOString(),
    verdict: items.every((i) => i.ok) ? 'accept' : 'reject',
    preState: { readyFrame: frame, provider: '未配置 provider：助手消息节点经 CDP 注入（与 addMessage 同构）——显式申报' },
    rerun: 'node tools/run-isolated.mjs --label s10 --cmd "node tools/accept-s10-chat.mjs"',
    independence: { ui: 'CDP 驱动真实应用；真实 IPC + 真实 DOM 点击；未调用本片新增函数', selfReported: ['assistant 消息节点为 CDP 注入（无 provider 环境的确定性替代；与底座 addMessage 产物同构）'] },
    items,
    artifacts: [
      { path: 'packages/packs/research/ui/home.js', sha256: sha(join(PROJECT_ROOT, 'packages/packs/research/ui/home.js')) },
      { path: 'packages/plugins/timeline/index.mjs', sha256: sha(join(PROJECT_ROOT, 'packages/plugins/timeline/index.mjs')) },
      { path: 'tools/accept-s10-chat.mjs', sha256: sha(join(PROJECT_ROOT, 'tools/accept-s10-chat.mjs')) },
      ...['c1-chat-toclaim.png', 'c2-blocked-missing-evidence.png', 'c3-published.png'].filter((f) => existsSync(join(SHOTS, f))).map((f) => ({ path: `data/shots/s10/${f}`, sha256: sha(join(SHOTS, f)) })),
    ],
  }
  const runRoot = process.env.ORB_RUN_ROOT
  const payload = JSON.stringify(out, null, 2)
  writeFileSync(logPath('s10-chat-evidence.json'), payload)
  if (runRoot) { try { writeFileSync(join(runRoot, 's10-chat-evidence.json'), payload) } catch { /* noop */ } }
  console.log(`S10 镜4-会话成结论：${items.filter((i) => i.ok).length}/${items.length} → ${out.verdict}`)
  console.log(`证据：${logPath('s10-chat-evidence.json')}`)
  process.exit(out.verdict === 'accept' ? 0 : 1)
}

main().catch((e) => { console.error('S10 chat 验收异常:', e); process.exit(2) })
