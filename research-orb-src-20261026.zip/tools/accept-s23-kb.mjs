// tools/accept-s23-kb.mjs —— S23·A 本地知识库端到端验收：真实文件 + 真实 DB。
// 单行复跑：node tools\accept-s23-kb.mjs
// 判据（任务书）：登记 3 个文件（含 1 个伪 PDF 报错路径）→ 检索命中正确 doc →
//   cite 生成证据 → attach 成功 → 重置清空。证据落 data\logs\s23-kb-accept.json。
import './_accept-isolate.mjs' // S67·3-A：先于产品模块求值，把 data/logs 指到临时目录
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createStore } from '../packages/core/src/db.mjs'
import { createClaim, attachEvidence, publishClaim, countPublishableEvidence } from '../packages/core/src/lifecycle/publish.mjs'
import { createKb, KB_BLOCK_CHARS, KB_OVERLAP_CHARS } from '../packages/plugins/kb/engine.mjs'

const items = []
const check = (id, ok, detail, evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's23-kb')
const KB_DIR = join(WORK, 'kb')
const DB_DIR = join(WORK, 'db')
const LOG = join(PROJECT_ROOT, 'data', 'logs', 'kb.jsonl')

// ---- 准备：3 个文件（含 1 个伪 PDF）----
rmSync(WORK, { recursive: true, force: true })
mkdirSync(join(WORK, 'notes'), { recursive: true })
mkdirSync(join(WORK, 'papers'), { recursive: true })
writeFileSync(join(WORK, 'notes', '微电网.md'), [
  '# 微电网读书笔记',
  '',
  '微电网的逆变器控制策略采用下垂控制，可以实现无互联通信的功率分配。',
  '',
  '离网模式下微电网需要二次调频与电压恢复。',
].join('\n'), 'utf8')
const hvdcBody = [
  'HVDC transmission 高压直流输电概述',
  '',
  // 单段 ≈2400 字：验证 800/80 滑窗分块（≥3 个 ≥500 字的块）
  'HVDC transmission systems use converters. ' + '换流器与逆变器协同运行，'.repeat(200),
].join('\n')
writeFileSync(join(WORK, 'papers', 'hvdc-long.txt'), hvdcBody, 'utf8')
writeFileSync(join(WORK, 'papers', 'fake.pdf'), 'this is definitely not a pdf file body —— 伪 PDF 报错路径', 'utf8')

let pass = 0
let fail = 0
try {
  const kb = createKb({ dir: KB_DIR })

  // ① 登记 3 个文件（1 个伪 PDF 报错）
  console.log('# ① 登记目录（3 个文件，其中 1 个伪 PDF）')
  const r = await kb.addPath(WORK)
  check('K1 新增 2 份文档', r.added.length === 2, `added=${r.added.length}`)
  check('K2 伪 PDF 如实报错（不伪装成功）', r.errors.length === 1 && r.errors[0].file === 'fake.pdf', `errors=${JSON.stringify(r.errors.map((e) => e.file))}`)
  const md = r.added.find((d) => d.fileName === '微电网.md')
  const hvdc = r.added.find((d) => d.fileName === 'hvdc-long.txt')
  check('K3 文档元数据齐（fileName/kind/pages/blocks/chars/sha256）', !!(md && hvdc && md.kind === 'text' && md.sha256 && hvdc.sha256 && md.pages >= 1), `md.blocks=${md && md.blocks} hvdc.blocks=${hvdc && hvdc.blocks}`)

  // ② 分块 800/80（hvdc 长段落）
  const hvdcChunks = kb._chunks.filter((c) => c.docId === hvdc.docId)
  const big = hvdcChunks.filter((c) => c.text.length >= 500)
  check('K4 长段落滑窗分块 ≥3 块且每块 ≤800 字', big.length >= 3 && big.every((c) => c.text.length <= KB_BLOCK_CHARS), `bigBlocks=${big.length}`)
  let overlapOk = true
  for (let i = 1; i < big.length; i++) {
    const tail = big[i - 1].text.slice(-KB_OVERLAP_CHARS)
    if (!big[i].text.startsWith(tail)) { overlapOk = false; break }
  }
  check('K5 相邻块重叠 80 字', overlapOk, `overlap=${KB_OVERLAP_CHARS}`)
  check('K6 每块保留 docId+page+blockIndex', hvdcChunks.every((c) => c.docId === hvdc.docId && c.page >= 1 && Number.isFinite(c.blockIndex)), `chunks=${hvdcChunks.length}`)

  // ③ 检索命中正确 doc
  console.log('# ② 检索')
  const h1 = kb.find('逆变器 控制')
  check('K7 检索「逆变器 控制」命中微电网.md', h1.hits.length > 0 && h1.hits[0].docId === md.docId, `top=${h1.hits[0] && h1.hits[0].fileName} score=${h1.hits[0] && h1.hits[0].score}`)
  check('K8 命中带 page/score/snippet', h1.hits[0].page === 1 && h1.hits[0].score > 0 && h1.hits[0].snippet.length > 0, `snippet=${h1.hits[0].snippet}`)
  const h2 = kb.find('HVDC transmission')
  check('K9 检索「HVDC transmission」命中 hvdc-long.txt', h2.hits.length > 0 && h2.hits[0].docId === hvdc.docId, `top=${h2.hits[0] && h2.hits[0].fileName}`)
  const h3 = kb.find('逆变器', { topN: 500 })
  check('K10 topN 受 mode caps 约束（≤min(cap,50)，不写死）', h3.topN <= 50 && h3.topN >= 1, `topN=${h3.topN}`)

  // ④ cite → 证据引用 → attach → 发布闸
  console.log('# ③ cite + 证据链')
  const c = kb.cite(md.docId, 1)
  check('K11 cite 生成 kb:docId#page=N', c.ref === `kb:${md.docId}#page=1` && c.evidenceId === `kb_${md.docId}_p1`, c.ref)
  check('K12 证据卡带本地文件+页码+sha256', c.fileName === '微电网.md' && c.page === 1 && String(c.sha256).length === 64, `${c.fileName} p${c.page}`)
  let threw = false
  try { kb.cite('kb-notexist0000', 1) } catch (e) { threw = e && e.code === 'E_KB_NO_DOC' }
  check('K13 cite 不存在 docId → E_KB_NO_DOC', threw)

  const store = await createStore({ driver: 'sqlite', dbPath: join(DB_DIR, 'orb.sqlite'), dataDir: DB_DIR })
  try {
    store.initMigrations()
    createClaim(store, { id: 'clm-s23-kb', kind: 'observation', text: '本地知识库检索显示微电网逆变器采用下垂控制（kb 引用）。', evidenceMode: 'direct' })
    // layer 受 0002 迁移 CHECK 约束（raw_frame/observation/summary/evidence_item/audit），
    // kb 引用走通用 evidence_item 层；"本地文件+页码"由 evidenceId（kb_<docId>_p<page>）
    // 与 kb.jsonl 审计行共同承载。
    const at = attachEvidence(store, { claimId: 'clm-s23-kb', evidenceId: c.evidenceId, layer: 'evidence_item', relation: 'direct', sha256: c.sha256 })
    check('K14 attachEvidence 挂链成功（layer=evidence_item，id 含 docId+page）', at && at.ok === true, `evidenceId=${c.evidenceId}`)
    const pub = publishClaim(store, 'clm-s23-kb')
    check('K15 kb 证据过发布闸（published）', pub && pub.ok === true && pub.status === 'published', `evidenceCount=${countPublishableEvidence(store, 'clm-s23-kb')}`)
  } finally {
    try { store.close && store.close() } catch { /* ignore */ }
  }

  // ⑤ 审计 + 重置清空
  console.log('# ④ 审计与重置')
  const logLines = existsSync(LOG) ? readFileSync(LOG, 'utf8').split('\n').filter((l) => l.trim()) : []
  const kinds = new Set(logLines.map((l) => { try { return JSON.parse(l).kind } catch { return '' } }))
  check('K16 kb.jsonl 留痕（kb-add/kb-cite）', kinds.has('kb-add') && kinds.has('kb-cite'), `kinds=${[...kinds].filter((k) => k.startsWith('kb-')).join(',')}`)
  kb.rm(md.docId)
  kb.rm(hvdc.docId)
  check('K17 重置清空：库空且不再命中', kb.list().length === 0 && kb.find('逆变器').hits.length === 0 && kb.find('HVDC').hits.length === 0, `docs=${kb.list().length}`)
  let threw2 = false
  try { kb.rm(md.docId) } catch (e) { threw2 = e && e.code === 'E_KB_NO_DOC' }
  check('K18 清空后 rm 报 E_KB_NO_DOC', threw2)
} catch (e) {
  check('K0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  rmSync(WORK, { recursive: true, force: true })
}

pass = items.filter((i) => i.ok).length
fail = items.length - pass
const out = { tool: 'accept-s23-kb', at: new Date().toISOString(), total: items.length, pass, fail, items }
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's23-kb-accept.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # accept-s23-kb: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 证据 -> data/logs/s23-kb-accept.json`)
process.exit(fail === 0 ? 0 : 1)
