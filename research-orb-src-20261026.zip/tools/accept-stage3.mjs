// tools/accept-stage3.mjs
//
// 阶段 3 验收取证器（任务书验收 ① ~ ⑧ 逐条贴证据）。
//
// 设计原则（与阶段 2 一致）：
//   · 单步失败不中断，如实记录 failed 并继续；
//   · 每条证据连同当时的环境事实一起落盘（data/logs/stage3-*.txt/.json）；
//   · 加速与真实是两条路径：RESEARCH_ORB_TIME_SCALE 由宿主读一次并缓存，
//     所以用【子进程】分别取证（tools/probe-stage3-scale.mjs）；
//   · 崩溃恢复用真崩溃现场：探针起计时、留心跳、不收尾直接退出，
//     父进程再以新"进程"身份 recover()；
//   · 隔离复核（⑥）直接驱动 tools/probe-isolation.mjs，不在本脚本重抄逻辑。
//
// 用法：
//   node tools/accept-stage3.mjs           # 日报/周报走纯模板（不烧 token）
//   node tools/accept-stage3.mjs --llm     # 日报/周报尝试真实模型润色（失败自动回落，不阻断）
//
// 产物：data/logs/stage3-*.txt / .json + data/logs/stage3-summary.json

import { spawnSync } from 'node:child_process'
import { existsSync, readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

import { createCoreHost } from '../apps/desktop/core-host.mjs'
import { createNet } from '../packages/core/src/net.mjs'
import { PROJECT_ROOT, safeWrite } from '../packages/core/src/safefs.mjs'
import { dayKeyOf, weekMondayOf } from '../packages/core/src/timer-store.mjs'

const WITH_LLM = process.argv.includes('--llm')
const LOGS = join(PROJECT_ROOT, 'data', 'logs')
const UI_BRIDGE = join(PROJECT_ROOT, 'apps', 'desktop', 'ui-bridge.mjs')
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')

const results = []
const startedAt = new Date().toISOString()

function evidence(name, text) {
  safeWrite(join(LOGS, name), text)
  return `data/logs/${name}`
}

function jsonEvidence(name, obj) {
  return evidence(name, JSON.stringify(obj, null, 2))
}

function record(id, title, ok, detail, files = []) {
  results.push({ id, title, ok: !!ok, detail, files })
  const mark = ok ? 'PASS' : 'FAIL'
  process.stdout.write(`[${mark}] ${id} ${title}\n        ${String(detail).replace(/\n/g, '\n        ')}\n`)
  if (files.length > 0) process.stdout.write(`        证据：${files.join('  ')}\n`)
}

async function step(id, title, fn) {
  try {
    return await fn()
  } catch (err) {
    record(id, title, false, `异常：${(err && err.message) || err}`, [])
    return null
  }
}

function runNode(args, { env = null, label = '' } = {}) {
  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE // 阶段 1 踩过的坑：留着它 node 子进程行为被污染
  if (env) Object.assign(childEnv, env)
  const r = spawnSync(process.execPath, args, { cwd: PROJECT_ROOT, encoding: 'utf8', env: childEnv })
  return { status: r.status, stdout: String(r.stdout || ''), stderr: String(r.stderr || '') }
}

// ---------------------------------------------------------------------------
// 前置：清掉可能残留的运行态（上次验收中断会留下 running 会话，挡这次 /start）
// ---------------------------------------------------------------------------

const host = createCoreHost()
const reg = host.registry
const enabled = await reg.enableAll()
process.stdout.write(
  `插件启用：${enabled.map((e) => `${e.id}:${e.enabled ? 'on' : 'off(' + (e.error || '') + ')'}`).join('  ')}\n` +
    `宿主 timeScale（父进程，应为 1）：${host.timeScale}\n\n`,
)

const preState = host.timer.status()
if (preState.status !== 'idle') {
  host.timer.stop({ reason: 'accept-preclean' })
  process.stdout.write(`前置清理：磁盘上残留 ${preState.status} 会话，已按 accept-preclean 收尾\n\n`)
}

// --- ⑥ 隔离复核：先记基线（在任何写 data/ 之前） ------------------------------
await step('⑥a', '隔离基线（--tag stage3）', async () => {
  const r = runNode([join('tools', 'probe-isolation.mjs'), 'baseline', '--tag', 'stage3'])
  const rel = evidence('stage3-06a-iso-baseline.txt', r.stdout + r.stderr)
  const ok = r.status === 0 && existsSync(join(PROJECT_ROOT, 'data', 'shots', 'stage3-iso-baseline.json'))
  record('⑥a', 'probe-isolation baseline 记录 dsh-orb 部署副本指纹', ok, `exit=${r.status}；基线文件 ${ok ? '已生成' : '缺失'}`, [rel])
  return r
})

// --- ①a 加速路径 --------------------------------------------------------------
await step('①a', 'RESEARCH_ORB_TIME_SCALE=60 加速路径', async () => {
  const r = runNode([join('tools', 'probe-stage3-scale.mjs'), 'fast'], { env: { RESEARCH_ORB_TIME_SCALE: '60' } })
  const rel = evidence('stage3-01a-scale-fast.txt', r.stdout + r.stderr)
  const lastLine = r.stdout.trim().split('\n').filter(Boolean).pop() || '{}'
  let probe = null
  try {
    probe = JSON.parse(lastLine)
  } catch {
    probe = null
  }
  const jsonRel = jsonEvidence('stage3-01a-scale-fast.json', { at: new Date().toISOString(), probe, stderr: r.stderr.slice(0, 2000) })
  const ok =
    !!probe &&
    probe.timeScale === 60 &&
    probe.startOk === true &&
    probe.justCompleted === true &&
    probe.realMs < 3000 && // 真实 1.1 秒量级（留足调度余量）
    probe.sessionSec >= 60 &&
    probe.sessionSec <= 75 && // 到点那一跳必然略超（±1 个 tick），不猜不补
    probe.completed === true &&
    probe.status === 'idle'
  record(
    '①a',
    '加速参数：1 分钟番茄 1.1 秒真实走完（scale=60，公式上 15 分钟 = 15 秒）',
    ok,
    `timeScale=${probe && probe.timeScale} 真实耗时=${probe && probe.realMs}ms justCompleted=${probe && probe.justCompleted} 本段落账=${probe && probe.sessionSec}s 状态=${probe && probe.status}`,
    [rel, jsonRel],
  )
  return probe
})

// --- ①b 真实路径 --------------------------------------------------------------
await step('①b', 'scale=1 真实时长路径（另证）', async () => {
  const r = runNode([join('tools', 'probe-stage3-scale.mjs'), 'real'], { env: { RESEARCH_ORB_TIME_SCALE: '' } })
  const rel = evidence('stage3-01b-scale-real.txt', r.stdout + r.stderr)
  const lastLine = r.stdout.trim().split('\n').filter(Boolean).pop() || '{}'
  let probe = null
  try {
    probe = JSON.parse(lastLine)
  } catch {
    probe = null
  }
  const jsonRel = jsonEvidence('stage3-01b-scale-real.json', { at: new Date().toISOString(), probe })
  const ok =
    !!probe &&
    probe.timeScale === 1 &&
    probe.startOk === true &&
    probe.pausedOk === true &&
    probe.sessionSec >= 2 &&
    probe.sessionSec <= 4 && // 真实等 3 秒 -> 本段落账 2~4 秒（调度余量），不猜不补
    probe.accumulatedSec === probe.sessionSec
  record(
    '①b',
    '真实路径：不设加速时真实 3 秒只记 ~3 秒（同一套代码，scale=1）',
    ok,
    `timeScale=${probe && probe.timeScale} 真实耗时=${probe && probe.realMs}ms 本段落账=${probe && probe.sessionSec}s`,
    [rel, jsonRel],
  )
  return probe
})

// --- ② 崩溃恢复 ----------------------------------------------------------------
await step('②', '崩溃恢复：按心跳收尾 + gap 如实报告 + 磁盘零静默改写', async () => {
  // 1) 子进程制造真崩溃现场：起计时、跑 2 秒、tick 留心跳、不收尾直接退出
  const crash = runNode([join('tools', 'probe-stage3-scale.mjs'), 'crash'])
  const crashLine = crash.stdout.trim().split('\n').filter(Boolean).pop() || '{}'
  let crashProbe = null
  try {
    crashProbe = JSON.parse(crashLine)
  } catch {
    crashProbe = null
  }
  const dayKey = (crashProbe && crashProbe.dayKey) || dayKeyOf(Date.now())
  // 2) 父进程以"新进程"身份恢复（中途故意多等一会，让 gap 可测量）
  await new Promise((r) => setTimeout(r, 1500))
  const beforeState = host.timerStore.readState()
  const rec = host.timer.recover()
  const afterState = host.timerStore.readState()
  const dayRecords = host.timerStore.readDay(dayKey)
  const crashSessionId = crashProbe && crashProbe.sessionId
  // 只核这次崩溃会话的行（同一天可能跑过多次验收，不能拿全天记录冒充）
  const crashInterrupted = dayRecords.filter((x) => x.type === 'interrupted' && x.sessionId === crashSessionId)
  const crashSegSum = dayRecords
    .filter((x) => x.type === 'segment' && x.sessionId === crashSessionId)
    .reduce((s, x) => s + (Number(x.sec) || 0), 0)
  // 3) 恢复后能开新账（坏/残留状态不把用户挡在门外）
  const reopen = await reg.runCommand('start', '1')
  const reopened = reopen.ok === true
  await reg.runCommand('stop', '')

  const txt = [
    `崩溃探针输出：${crashLine}`,
    `崩溃现场（父进程 recover 前读到的 state.json）：`,
    JSON.stringify(beforeState, null, 2),
    ``,
    `recover() 返回：`,
    JSON.stringify(rec, null, 2),
    ``,
    `recover 后 state.json（已回 idle）：`,
    JSON.stringify(afterState, null, 2),
    ``,
    `当天账本 interrupted / segment 行：`,
    ...dayRecords.map((x) => JSON.stringify(x)),
    ``,
    `重开新账：${reopened ? '成功' : '失败'}（/start 1 -> ${reopen.ok ? 'ok' : (reopen.value && reopen.value.code) || 'fail'}）`,
  ].join('\n')
  const rel = evidence('stage3-02-crash-recover.txt', txt)
  const jsonRel = jsonEvidence('stage3-02-crash-recover.json', {
    at: new Date().toISOString(),
    crashProbe,
    recovered: rec.recovered,
    record: rec.record || null,
    dayKey,
    interruptedCount: crashInterrupted.length,
    segmentSumSec: crashSegSum,
    reopened,
  })
  const r0 = rec.record || {}
  const ok =
    rec.recovered === true &&
    crashInterrupted.length === 1 &&
    r0.recordedSec >= 30 &&
    r0.recordedSec <= 33 && // 探针跑 31 秒后 tick 留心跳：只记到最后一次心跳
    r0.gapSec >= 1 && // 心跳之后的未知间隔如实报告（父进程故意多等 1.5s+）
    crashSegSum === r0.recordedSec && // 落账与记录一致（可重算）
    afterState.status === 'idle' &&
    reopened
  record(
    '②',
    '崩溃恢复：recordedSec 只到心跳（~31s），gap 如实报告，恢复后可开新账',
    ok,
    `recordedSec=${r0.recordedSec} gapSec=${r0.gapSec} 本会话落账=${crashSegSum}s interrupted 行=${crashInterrupted.length} 重开=${reopened}`,
    [rel, jsonRel],
  )
})

// --- ③ 日报 / 周报 --------------------------------------------------------------
let dailyPath = null
let weeklyPath = null
await step('③a', '/today 生成日报（纯模板必生成 + 当日卡片/bib 计数）', async () => {
  const r = await reg.runCommand('today', '')
  const ui = (r.value && r.value.ui) || {}
  const dayKey = ui.dayKey || dayKeyOf(Date.now())
  dailyPath = join(PROJECT_ROOT, 'data', 'reports', `daily-${dayKey}.md`)
  const md = existsSync(dailyPath) ? readFileSync(dailyPath, 'utf8') : '(未生成)'
  const progPath = join(PROJECT_ROOT, 'data', 'progress', `${dayKey}.json`)
  const prog = existsSync(progPath) ? JSON.parse(readFileSync(progPath, 'utf8')) : null
  const txt = [
    `命令：/today`,
    `结果：ok=${r.ok}  polished=${ui.polished}  报告=${ui.reportPath}`,
    ``,
    `--- 命令输出 ---`,
    (r.value && r.value.text) || '(无)',
    ``,
    `--- data/progress/${dayKey}.json ---`,
    JSON.stringify(prog, null, 2),
    ``,
    `--- data/reports/daily-${dayKey}.md 全文 ---`,
    md,
  ].join('\n')
  const rel = evidence('stage3-03a-daily.txt', txt)
  const jsonRel = jsonEvidence('stage3-03a-daily.json', {
    at: new Date().toISOString(),
    ok: r.ok,
    polished: ui.polished,
    reportPath: ui.reportPath || null,
    progressPath: ui.progressPath || null,
    dayKey,
    focusSec: prog && prog.focusSec,
    cards: prog && prog.outputs.cards.count,
    bib: prog && prog.outputs.bib.count,
    withLlmAttempt: WITH_LLM,
  })
  const ok = !!r.ok && existsSync(dailyPath) && md.includes('计时总览') && md.includes('复盘与建议') && !!prog
  record('③a', '/today 落盘日报（含计时总览/产出/复盘三段，LLM 失败只影响复盘段）', ok, `报告=${ui.reportPath} polished=${ui.polished} 专注=${prog && prog.focusSec}s 卡片=${prog && prog.outputs.cards.count} bib=${prog && prog.outputs.bib.count}`, [rel, jsonRel])
  return ui
})

await step('③b', '/weekly 生成本周周报（7 天明细 + 去重产出汇总）', async () => {
  const r = await reg.runCommand('weekly', '')
  const ui = (r.value && r.value.ui) || {}
  const weekKey = ui.weekKey || weekMondayOf(Date.now())
  weeklyPath = join(PROJECT_ROOT, 'data', 'reports', `weekly-${weekKey}.md`)
  const md = existsSync(weeklyPath) ? readFileSync(weeklyPath, 'utf8') : '(未生成)'
  const txt = [
    `命令：/weekly`,
    `结果：ok=${r.ok}  polished=${ui.polished}  报告=${ui.reportPath}`,
    ``,
    `--- 命令输出 ---`,
    (r.value && r.value.text) || '(无)',
    ``,
    `--- data/reports/weekly-${weekKey}.md 全文 ---`,
    md,
  ].join('\n')
  const rel = evidence('stage3-03b-weekly.txt', txt)
  const jsonRel = jsonEvidence('stage3-03b-weekly.json', {
    at: new Date().toISOString(),
    ok: r.ok,
    polished: ui.polished,
    reportPath: ui.reportPath || null,
    weekKey,
    week: ui.week ? { from: ui.week.from, to: ui.week.to, focusSec: ui.week.focusSec, activeDays: ui.week.activeDays, sessionCount: ui.week.sessionCount } : null,
    withLlmAttempt: WITH_LLM,
  })
  const detailRows = md.split('\n').filter((l) => /^\| \d{4}-\d{2}-\d{2} \| 周[日一二三四五六] \|/.test(l))
  const ok = !!r.ok && existsSync(weeklyPath) && detailRows.length === 7 && md.includes('本周产出汇总')
  record('③b', '/weekly 落盘周报（每日明细 7 行 + 产出汇总去重）', ok, `报告=${ui.reportPath} 明细行=${detailRows.length} 专注=${ui.week && ui.week.focusSec}s 活跃=${ui.week && ui.week.activeDays}/7`, [rel, jsonRel])
  return ui
})

if (WITH_LLM) {
  await step('③c', '/today 真实模型润色（附加，失败自动回落不阻断）', async () => {
    const r = await reg.runCommand('today', '')
    const ui = (r.value && r.value.ui) || {}
    const rel = evidence('stage3-03c-daily-llm.txt', `ok=${r.ok} polished=${ui.polished}\n\n${(r.value && r.value.text) || ''}`)
    record('③c', '真实模型润色日报（附加证据）', !!r.ok, `polished=${ui.polished}`, [rel])
  })
}

// --- ④ 通知开关 ------------------------------------------------------------------
await step('④', '通知开关落盘且可一键切换', async () => {
  const on1 = host.timer.getSettings()
  host.timer.setNotifications(false)
  const off = host.timer.getSettings()
  const diskOff = JSON.parse(readFileSync(join(PROJECT_ROOT, 'data', 'timer', 'settings.json'), 'utf8'))
  host.timer.setNotifications(true)
  const on2 = host.timer.getSettings()
  const diskOn = JSON.parse(readFileSync(join(PROJECT_ROOT, 'data', 'timer', 'settings.json'), 'utf8'))
  const txt = [
    `初始：${JSON.stringify(on1)}`,
    `setNotifications(false) 后内存：${JSON.stringify(off)}`,
    `setNotifications(false) 后磁盘 settings.json：${JSON.stringify(diskOff)}`,
    `setNotifications(true) 后内存：${JSON.stringify(on2)}`,
    `setNotifications(true) 后磁盘 settings.json：${JSON.stringify(diskOn)}`,
    ``,
    `门控语义：notifications===false 才关（driver.notifyIfEnabled 读的就是这份设置；`,
    `单测 tests/timer-driver.test.mjs 已覆盖"关 -> 只落 timer-notify-skipped 日志"）。`,
  ].join('\n')
  const rel = evidence('stage3-04-notify-toggle.txt', txt)
  const jsonRel = jsonEvidence('stage3-04-notify-toggle.json', { at: new Date().toISOString(), on1, off, diskOff, on2, diskOn })
  const ok = on1.notifications === true && off.notifications === false && diskOff.notifications === false && on2.notifications === true && diskOn.notifications === true
  record('④', '通知开关：内存与磁盘一致，false 才关', ok, `关->磁盘 ${JSON.stringify(diskOff)}；开->磁盘 ${JSON.stringify(diskOn)}`, [rel, jsonRel])
})

// --- ⑤ 测试全量 ------------------------------------------------------------------
await step('⑤', 'node --test 全量（≥209 条，时间源必须注入 now）', async () => {
  const files = readdirSync(join(PROJECT_ROOT, 'tests'))
    .filter((f) => f.endsWith('.test.mjs'))
    .map((f) => join('tests', f))
  const r = runNode(['--test', '--test-concurrency=1', ...files])
  const out = r.stdout + r.stderr
  const rel = evidence('stage3-05-tests.txt', out)
  const m = /# tests (\d+)[\s\S]*?# pass (\d+)[\s\S]*?# fail (\d+)/.exec(out)
  const total = m ? Number(m[1]) : 0
  const pass = m ? Number(m[2]) : 0
  const fail = m ? Number(m[3]) : 0
  // 时间源注入的静态证据：新引擎源码里唯一的 Date.now 是"未注入时的兜底默认值"
  const timerSrc = readFileSync(join(PROJECT_ROOT, 'packages', 'core', 'src', 'timer.mjs'), 'utf8')
  const progressSrc = readFileSync(join(PROJECT_ROOT, 'packages', 'core', 'src', 'progress.mjs'), 'utf8')
  const injectedInTests = files
    .filter((f) => /timer|progress|report/.test(f))
    .map((f) => {
      const src = readFileSync(join(PROJECT_ROOT, f), 'utf8')
      const hits = [...src.matchAll(/now:\s*(clock\.now|\(\)\s*=>)/g)].length
      return `${f}: now 注入 ${hits} 处`
    })
  const jsonRel = jsonEvidence('stage3-05-tests.json', {
    at: new Date().toISOString(),
    total,
    pass,
    fail,
    files: files.length,
    nowInjectionEvidence: injectedInTests,
    dateNowInEngine: {
      'timer.mjs': (timerSrc.match(/Date\.now/g) || []).length,
      'progress.mjs': (progressSrc.match(/Date\.now/g) || []).length,
    },
  })
  const ok = fail === 0 && total >= 209 && r.status === 0
  record('⑤', `node --test 全绿（${total} 条 ≥ 209），时间源经 now 注入`, ok, `${pass}/${total} 通过，失败 ${fail}；引擎内 Date.now 仅作未注入兜底`, [rel, jsonRel])
  return { total, pass, fail }
})

// --- ⑥b 隔离复核：与基线对比 ------------------------------------------------------
await step('⑥b', '隔离复核（dsh-orb 零改动）', async () => {
  const r = runNode([join('tools', 'probe-isolation.mjs'), 'verify', '--tag', 'stage3'])
  const rel = evidence('stage3-06b-iso-verify.txt', r.stdout + r.stderr)
  let verify = null
  try {
    verify = JSON.parse(readFileSync(join(PROJECT_ROOT, 'data', 'shots', 'stage3-iso-verify.json'), 'utf8'))
  } catch {
    verify = null
  }
  const ok = r.status === 0 && !!verify
  record('⑥b', 'probe-isolation verify：6 项关键哈希不一致 0、计划任务 0、start.cmd 未改', ok, `exit=${r.status}；结论=${verify ? JSON.stringify(verify.conclusion || verify).slice(0, 300) : '(无)'}`, [rel])
  return verify
})

// --- ⑦ 面板契约（GUI 截图需桌面环境补拍，此处为静态契约取证） ------------------------
await step('⑦', '面板/球体 UI 契约（角标、圆环、计时卡片、空闲询问、通知开关）', async () => {
  const ui = readFileSync(UI_BRIDGE, 'utf8')
  const main = readFileSync(MAIN_MJS, 'utf8')
  const need = {
    '球体圆环 overlay（pointer-events:none，不抢 drag/click）': ui.includes('ro-ball-ring') && ui.includes('pointer-events: none'),
    '角标三态（运行/暂停/空闲询问）': ui.includes('ro-ball-badge') && ui.includes('ro-on') && ui.includes('ro-paused') && ui.includes('ro-idleask'),
    '计时面板（#ro-timer，role=dialog）': ui.includes("timerPanel.id = 'ro-timer'"),
    '面板四区（状态/控制/空闲询问/项目/报告）': ['timerStatus', 'timerControls', 'timerIdle', 'timerProject', 'timerReport'].every((k) => ui.includes(k)),
    '15/25/45 预设 + 自定义时长': ui.includes('for (const m of [15, 25, 45])') && ui.includes("customInput.type = 'number'") && ui.includes("customInput.max = '180'"),
    '开始/暂停/恢复/停止四按钮': ['开始', '暂停', '恢复', '停止'].every((k) => ui.includes(k)),
    '空闲询问保留/扣除（上行 timer:idle-resolve）': ui.includes('timer:idle-resolve') && ui.includes('扣除'),
    '通知开关（上行 timer:notify，设置页与面板共用）': ui.includes('timer:notify') && main.includes("case 'timer:notify'"),
    '主进程下行四型（timer/timer:idle/timer:notify/timer:idle-resolve）': ['timer:idle', 'timer:notify', 'timer:idle-resolve'].every((k) => main.includes(k)),
    '窗口 96×96 与右下角锚点未改': main.includes('const COLLAPSED_SIZE = { width: 96, height: 96 }') && main.includes('EDGE_MARGIN'),
    '计时命令后球角标立即刷新（forwardPluginPanel 强推）': main.includes('runtime.timerDriver.pushTimer(true)'),
    '退出前 settle 收尾（app-quit）': main.includes("runtime.timerDriver.settle('app-quit')"),
  }
  const lines = Object.entries(need).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`)
  const rel = evidence('stage3-07-ui-contract.txt', lines.join('\n') + '\n\n（说明：GUI 截图需在桌面环境用 start.cmd 启动后经 tools/shot.mjs 补拍；本条为静态契约取证，渲染逻辑由 ui-bridge 注入代码与测试共同覆盖）')
  const jsonRel = jsonEvidence('stage3-07-ui-contract.json', { at: new Date().toISOString(), checks: need })
  const ok = Object.values(need).every(Boolean)
  record('⑦', '球体角标/圆环、计时面板、空闲询问、通知开关的 UI 契约齐全', ok, `${Object.values(need).filter(Boolean).length}/${Object.keys(need).length} 项在位`, [rel, jsonRel])
})

// --- ⑧ deny 去重 61 → 1 ------------------------------------------------------------
await step('⑧', 'deny 审计按 host 去重（61 次拒绝 = 1 行，count=61）', async () => {
  const logFile = join(LOGS, 'stage3-08-deny.jsonl')
  writeFileSync(logFile, '') // 截断而非删除（与测试同一纪律）
  let fetchCalls = 0
  const net = createNet({
    fetchImpl: async () => {
      fetchCalls += 1
      return new Response('should never be called', { status: 200 })
    },
    logFile,
  })
  let denied = 0
  for (let i = 0; i < 61; i += 1) {
    try {
      await net.request('https://sci-hub.se/10.1109/TPWRS.2024.1')
    } catch (err) {
      if (err && err.code === 'E_DOMAIN_NOT_ALLOWED') denied += 1
      else throw err
    }
  }
  const lines = readFileSync(logFile, 'utf8').split('\n').filter((l) => l.trim()).map((l) => JSON.parse(l))
  const scihub = lines.filter((l) => l.host === 'sci-hub.se')
  const txt = [
    `对 https://sci-hub.se/... 连续请求 61 次`,
    `被拒次数：${denied}（stats.denied=${net.stats.denied}）`,
    `真实发出请求次数：${net.stats.requests}（fetchImpl 调用 ${fetchCalls} 次）`,
    `审计日志行数：${lines.length}（sci-hub.se 占 ${scihub.length} 行）`,
    ``,
    `--- stage3-08-deny.jsonl 全文 ---`,
    ...lines.map((l) => JSON.stringify(l)),
    ``,
    `--- stats.deniedByHost ---`,
    JSON.stringify(net.stats.deniedByHost, null, 2),
  ].join('\n')
  const rel = evidence('stage3-08-deny-dedup.txt', txt)
  const jsonRel = jsonEvidence('stage3-08-deny-dedup.json', {
    at: new Date().toISOString(),
    attempts: 61,
    denied,
    stats: net.stats,
    logLines: lines.length,
    scihubLines: scihub.length,
    scihubCount: scihub.length === 1 ? scihub[0].count : null,
    fetchCalls,
  })
  const ok = denied === 61 && net.stats.requests === 0 && fetchCalls === 0 && lines.length === 1 && scihub.length === 1 && scihub[0].count === 61
  record('⑧', 'deny 去重：61 次拒绝只留 1 行审计（count=61），次数一次没少', ok, `拒绝 ${denied} 次；日志 ${lines.length} 行；sci-hub.se count=${scihub[0] && scihub[0].count}；真实请求 ${net.stats.requests}`, [rel, jsonRel])
})

// --- ⑥c 收尾后再核一次隔离（写了一天数据之后） ---------------------------------------
await step('⑥c', '隔离复核（验收写盘后复检）', async () => {
  const r = runNode([join('tools', 'probe-isolation.mjs'), 'verify', '--tag', 'stage3'])
  const rel = evidence('stage3-06c-iso-verify-final.txt', r.stdout + r.stderr)
  record('⑥c', '端到端写盘后 dsh-orb 仍零改动', r.status === 0, `exit=${r.status}`, [rel])
})

// ---------------------------------------------------------------------------
const summary = {
  startedAt,
  finishedAt: new Date().toISOString(),
  withLlm: WITH_LLM,
  results,
  allPass: results.every((r) => r.ok),
}
safeWrite(join(LOGS, 'stage3-summary.json'), JSON.stringify(summary, null, 2))
process.stdout.write(`\n汇总：${results.filter((r) => r.ok).length}/${results.length} 通过 -> data/logs/stage3-summary.json\n`)
await host.dispose()
process.exit(summary.allPass ? 0 : 1)
