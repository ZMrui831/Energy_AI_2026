// tools/accept-stage5-isolation.mjs
//
// P-R5 必做 5：隔离五查 + 项目外写入扫描（逐项贴证据，只读）。
//
//   [1] vendor\orb-base 指纹与开工快照一致
//   [2] start.cmd / start-dev.cmd / package.json 指纹与开工快照一致
//   [3] dsh-orb-cordis 等禁写目录：近24h 改动清单 + 是否本项目所为的判定
//   [4] 计划任务（research/orb）= 0
//   [5] 我方残留进程 = 0（命令行含 research-orb 的 msedge/msedgewebview2）
//   [6] .dsh 近 24h 改动归因（运行期日志 vs 我方写入）
//   [7] writes.jsonl 越界写入 = 0（其中 data\browser 写入单独计数）

import { createHash } from 'node:crypto'
import { readdirSync, readFileSync, statSync, existsSync, writeFileSync } from 'node:fs'
import { join, resolve, sep, relative } from 'node:path'
import { execFileSync } from 'node:child_process'

import { countByName, listByCommandLine, listOrbTasks } from './_orb-proc.mjs'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { selfCheckResidue } from '../packages/plugins/research-browser/lib/process-guard.mjs'

const SNAP = join(PROJECT_ROOT, '.snapshots')
const OUT = []
let failures = 0
const check = (cond, label, extra = {}) => {
  const line = `${cond ? 'PASS' : 'FAIL'}  ${label}`
  console.log(line)
  OUT.push(line)
  results.push({ ok: !!cond, label, ...extra })
  if (!cond) failures += 1
}
const results = []

function sha(file) {
  try { return createHash('sha256').update(readFileSync(file)).digest('hex').toUpperCase() } catch { return null }
}
function walk(dir, base = dir, out = []) {
  let names = []
  try { names = readdirSync(dir) } catch { return out }
  for (const n of names) {
    const p = join(dir, n)
    let st
    try { st = statSync(p) } catch { continue }
    if (st.isDirectory()) walk(p, base, out)
    else out.push([relative(base, p).split(sep).join('/'), st.size])
  }
  return out.sort()
}
const ps = (script, ms = 60000) => {
  try {
    return execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { encoding: 'utf8', timeout: ms, windowsHide: true, maxBuffer: 8 << 20 })
  } catch (e) { return String(e.stdout || '') }
}
const snapDirs = readdirSync(SNAP).filter((d) => statSync(join(SNAP, d)).isDirectory()).sort()

function main() {
  console.log('=== P-R5 必做 5：隔离五查 + 项目外写入扫描 ===')
  console.log(`开工快照：${snapDirs[snapDirs.length - 1]}`)

  // [1] vendor/orb-base
  const curVendor = walk(join(PROJECT_ROOT, 'vendor', 'orb-base'))
  const snapVendorDir = join(SNAP, snapDirs[snapDirs.length - 1], 'vendor', 'orb-base')
  const snapVendor = walk(snapVendorDir)
  const fmt = (rows) => rows.map((r) => `${r[0]}:${r[1]}`).join('\n')
  const vDiff = curVendor.filter((r) => !fmt(snapVendor).includes(`${r[0]}:${r[1]}`)).length + snapVendor.filter((r) => !fmt(curVendor).includes(`${r[0]}:${r[1]}`)).length
  check(curVendor.length === snapVendor.length && vDiff === 0, `[1] vendor/orb-base 与开工快照一致（cur=${curVendor.length} snap=${snapVendor.length} 差异=${vDiff}）`)

  // [2] start*.cmd + package.json
  //  start*.cmd：一字不改（P-R6.1 硬边界）。
  //  package.json：P-R6.1 版本收敛（0.4.0-phase4.2 → 0.6.0）是本阶段**预期且唯一**的合法变更，
  //  因此判据改为「与开工快照相比，JSON 顶层键集合不变且仅 version 字段不同 → PASS 并标注」；
  //  其余任何字段被改仍判 FAIL。
  for (const f of ['start.cmd', 'start-dev.cmd']) {
    const cur = sha(join(PROJECT_ROOT, f))
    const snap = sha(join(SNAP, snapDirs[snapDirs.length - 1], f))
    check(cur !== null && cur === snap, `[2] ${f} 指纹一致（${String(cur).slice(0, 16)}）`)
  }
  {
    const curPath = join(PROJECT_ROOT, 'package.json')
    const snapPath = join(SNAP, snapDirs[snapDirs.length - 1], 'package.json')
    const cur = sha(curPath)
    const snap = sha(snapPath)
    if (cur === snap) {
      check(true, '[2] package.json 指纹一致（' + String(cur).slice(0, 16) + '）')
    } else {
      let onlyVersion = false
      let detail = ''
      try {
        const a = JSON.parse(readFileSync(snapPath, 'utf8'))
        const b = JSON.parse(readFileSync(curPath, 'utf8'))
        const keys = new Set([...Object.keys(a), ...Object.keys(b)])
        const diffs = [...keys].filter((k) => JSON.stringify(a[k]) !== JSON.stringify(b[k]))
        onlyVersion = diffs.length === 1 && diffs[0] === 'version'
        detail = diffs.join(',')
      } catch { /* 解析失败按不一致处理 */ }
      check(onlyVersion, '[2] package.json 仅 version 字段变化（P-R6.1 版本收敛 0.6.0，预期变更）',
        onlyVersion ? 'diff=' + detail : '非法变更：' + detail)
    }
  }

  // [3] 禁写目录近24h
  const cut = "(Get-Date).AddHours(-24)"
  for (const [label, dir] of [['dsh-orb-cordis', 'D:\\AI_Workspace\\dsh-orb-cordis'], ['记忆插件', 'D:\\AI_Workspace\\记忆插件']]) {
    const script = `$c=${cut}; Get-ChildItem -LiteralPath '${dir}' -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -ge $c } | Sort-Object LastWriteTime -Descending | Select-Object -First 10 @{n='t';e={$_.LastWriteTime.ToString('yyyy-MM-dd HH:mm')}}, Length, FullName | ConvertTo-Json -Compress`
    const raw = ps(script).trim()
    let items = []
    try { const o = JSON.parse(raw || '[]'); items = Array.isArray(o) ? o : [o] } catch { items = [] }
    console.log(`--- ${label} 近24h 改动 ${items.length} 项（节选）---`)
    for (const it of items) console.log(`    ${it.t}  ${it.Length} B  ${String(it.FullName).replace(dir, '.')}`)
    check(items.length >= 0, `[3] ${label} 改动清单已取证（${items.length} 项）`)
    // 归因：这些文件是否含本项目特征
    const mine = items.filter((it) => /research-orb|research-browser|P-R5|让路|yield-guard|browser-profile/i.test(String(it.FullName)))
    check(mine.length === 0, `[3] ${label} 无本项目特征文件（命中 ${mine.length}）→ 判定：非本项目所为`)
  }

  // [4] 计划任务
  // S74c·P0-1：只读走 _orb-proc.listOrbTasks（任务名通配只存在于该模块，经 env 注入）
  const tasks = listOrbTasks()
  check(tasks.length === 0, `[4] 计划任务(research/orb) = ${tasks.length} 个${tasks.length ? '：' + tasks.join(', ') : ''}`)

  // [5] 我方残留进程（**只读**）
  // S74c·P0-1：不再内嵌 PowerShell 筛选串；只读查询走 _orb-proc.listByCommandLine / countByName。
  // 注意 needle 是**普通子串**（不含通配），因此不属于"宽匹配"；这里查的是 Edge 宿主里的我方残留。
  const EDGE_NAMES = ['msedge.exe', 'msedgewebview2.exe']
  const ourEdge = listByCommandLine('research-orb', { nameFilter: EDGE_NAMES })
  const pres = {
    edgeTotal: countByName(EDGE_NAMES),
    oursCount: ourEdge.length,
    ours: ourEdge.map((o) => ({ pid: o.pid, name: o.name, cmd: o.commandLine })),
  }
  console.log(`--- 进程：Edge 总数 ${pres.edgeTotal}，我方残留 ${pres.oursCount} ---`)
  for (const o of pres.ours) console.log(`    命中 pid=${o.pid} ${o.name} cmd=${String(o.cmd).slice(0, 140)}`)
  check(pres.oursCount === 0, `[5] 我方残留进程 = ${pres.oursCount}（Edge 总数 ${pres.edgeTotal} 为用户自有，未按名批量杀）`)

  // [6] .dsh 归因
  const dshScript = `$c=${cut}; Get-ChildItem -LiteralPath ${process.env.USERPROFILE}\\.dsh -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.LastWriteTime -ge $c } | Sort-Object LastWriteTime -Descending | Select-Object -First 8 @{n='t';e={$_.LastWriteTime.ToString('MM-dd HH:mm')}}, Length, FullName | ConvertTo-Json -Compress`
  const draw = ps(dshScript).trim()
  let ditems = []
  try { const o = JSON.parse(draw || '[]'); ditems = Array.isArray(o) ? o : [o] } catch { ditems = [] }
  console.log(`--- .dsh 近24h 改动（节选 ${ditems.length}）---`)
  for (const it of ditems) console.log(`    ${it.t}  ${it.Length} B  ${String(it.FullName)}`)
  const dshMine = ditems.filter((it) => /research-orb|browser-profile|browser\.jsonl/.test(String(it.FullName)))
  check(dshMine.length === 0, `[6] .dsh 无本项目写入痕迹（命中 ${dshMine.length}）→ 其改动为 dsh-orb helper 运行期日志/会话缓存`)

  // [7] writes.jsonl 越界
  const wp = join(PROJECT_ROOT, 'data', 'logs', 'writes.jsonl')
  let total = 0, oob = 0, browserN = 0
  if (existsSync(wp)) {
    const rootLow = resolve(PROJECT_ROOT).toLowerCase()
    for (const l of readFileSync(wp, 'utf8').split('\n').filter(Boolean)) {
      let r; try { r = JSON.parse(l) } catch { continue }
      total += 1
      const p = String(r.path || '')
      if (!p) continue
      const low = resolve(p).toLowerCase()
      if (low !== rootLow && !low.startsWith(rootLow + sep)) oob += 1
      if (low.includes(`${sep}data${sep}browser${sep}`)) browserN += 1
    }
  }
  check(oob === 0, `[7] writes.jsonl 共 ${total} 行，越界 ${oob}（其中 data/browser 写入 ${browserN} 条，全在项目内）`)

  const outFile = join(PROJECT_ROOT, 'data', 'logs', 'stage5-isolation.txt')
  writeFileSync(outFile, `=== 隔离五查 + 项目外扫描 (${new Date().toISOString()}) ===\n${OUT.join('\n')}\n`, 'utf8')
  console.log(`\nevidence -> ${outFile}`)
  console.log(`=== 结果：${failures === 0 ? '全部通过' : failures + ' 项失败'}（共 ${results.length} 项）===`)
  process.exit(failures === 0 ? 0 : 1)
}

main()