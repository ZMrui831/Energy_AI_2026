// tools/accept-stage61.mjs
//
// P-R6.1 外观微调验收（真 electron，逐条贴证据）：
//   评审① 纵向留白 → 今日概览卡（pack 提供，无假数据，友好空态）
//   评审② 顶栏三件套对齐（实测 getBoundingClientRect，贴数字）
//   评审③ 文字层级（代码路径 .ro-code = font.mono + textDim）
//   评审④ 球在亮/暗壁纸分离度（ball.ring 外圈描边 + 外发光；壁纸合成图见 composite-icons）
//   评审⑤ 图标 16px/96px 放大对照（见 composite-icons）
//   评审⑥ composer 间距到 spacing token + 占位文案随 pack 变化（research vs general 实测）
// 另含：版本 0.6.0 五处一致（托盘/设置页/plugin.json/pack.json）截图与静态证据。
//
// 「改前」= data\shots\stage6-theme-sky-blue.png（P-R6 收尾时的 sky-blue 实拍）。
// 「改后」= 本工具产出的 stage61-*.png。主题一律默认 sky-blue。

import { spawn, spawnSync } from 'node:child_process'
import { existsSync, readFileSync, writeFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { loadSettings, saveSettings } from '../packages/core/src/settings.mjs'
import { listThemes, readTheme, contrastRatio } from '../packages/core/src/themes.mjs'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-stage61')

const ELECTRON_EXE = ORB_ELECTRON
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const SHOTS = join(PROJECT_ROOT, 'data', 'shots')
const LOG = join(PROJECT_ROOT, 'data', 'logs', 'stage61-appearance.txt')
const PORT = 9356

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const OUT = []
const results = []
const log = (s) => { OUT.push(s); console.log(s) }
const check = (cond, label, extra = '') => {
  log(`${cond ? 'PASS' : 'FAIL'}  ${label}${extra ? '  ' + extra : ''}`)
  results.push({ ok: !!cond, label, extra })
  return !!cond
}

async function findTarget(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const list = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(t.url))
      if (page) return page
    } catch { /* 还没起来 */ }
    await sleep(300)
  }
  throw new Error(`CDP 目标未找到（port ${PORT}）`)
}

let cdp = null
async function connectCdp() {
  const target = await findTarget()
  const ws = new WebSocket(target.webSocketDebuggerUrl)
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve)
    ws.addEventListener('error', () => reject(new Error('CDP WebSocket 连接失败')))
  })
  const session = { ws, _id: 0, _pending: new Map() }
  ws.addEventListener('message', (ev) => {
    let m
    try { m = JSON.parse(ev.data) } catch { return }
    if (m.id !== undefined && session._pending.has(m.id)) {
      const p = session._pending.get(m.id)
      session._pending.delete(m.id)
      if (m.error) p.reject(new Error(m.error.message))
      else p.resolve(m.result)
    }
  })
  cdp = {
    send: (method, params = {}) => {
      const id = ++session._id
      return new Promise((resolve, reject) => {
        session._pending.set(id, { resolve, reject })
        session.ws.send(JSON.stringify({ id, method, params }))
      })
    },
    evaluate: async (expression) => {
      const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true })
      return r && r.result ? r.result.value : undefined
    },
    close: () => { try { session.ws.close() } catch { /* noop */ } },
  }
  await cdp.send('Page.enable')
  await cdp.send('Runtime.enable')
  return cdp
}

async function shot(name) {
  const s = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
  if (!s || !s.data) throw new Error('截图失败')
  writeFileSync(join(SHOTS, name), Buffer.from(s.data, 'base64'))
  const bytes = Buffer.from(s.data, 'base64').length
  log(`shot: data/shots/${name} (${bytes} bytes)`)
  return `data/shots/${name}`
}

async function reloadPanel() {
  await cdp.send('Page.reload', { ignoreCache: true })
  await sleep(5500)
}

function killOwnElectron(pid) {
  if (!pid) return
  spawnSync('taskkill', ['/pid', String(pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true })
}

async function main() {
  log('=== P-R6.1 外观微调验收（真 electron，主题=sky-blue 默认）===')

  // 静态前置：主题 token
  const themes = listThemes()
  check(themes.some((t) => t.name === 'sky-blue' && t.ok), '默认主题 sky-blue 存在且通过校验')
  const sky = readTheme('sky-blue')
  check(contrastRatio(sky.colors.text, sky.colors.panel) >= 4.5, '对比度：正文 ≥4.5:1', `${contrastRatio(sky.colors.text, sky.colors.panel).toFixed(2)}:1`)
  // ball.ring 已进入 CSS（外圈描边 + 外发光）
  const css = (await import('../packages/core/src/themes.mjs')).themeToCss(sky)
  check(css.includes('0 0 0 1.5px') && css.includes(sky.ball.ring), '评审④ 球体外圈描边已用 ball.ring token', `ring=${sky.ball.ring}`)
  check(css.includes('--ro-mono:') && css.includes('--ro-spacing:'), 'themeToCss 输出 --ro-mono / --ro-spacing token')

  // C1：data/fonts 目录存在 + README
  const fontsDir = join(PROJECT_ROOT, 'data', 'fonts')
  check(existsSync(fontsDir) && existsSync(join(fontsDir, 'README.txt')), 'C1 data\\fonts 目录存在且含 README.txt', 'data/fonts/README.txt')

  // C2：ARCH.md 架构事实
  const arch = readFileSync(join(PROJECT_ROOT, 'docs', 'ARCH.md'), 'utf8')
  check(arch.includes('不属领域词') && arch.includes('不含** `计时/进度`'.replace('**', '**')), 'C2 ARCH.md 写明计时/进度属 core 且词表不含 计时/进度')
  // C3：THEMES.md 评审结论保留
  const th = readFileSync(join(PROJECT_ROOT, 'docs', 'THEMES.md'), 'utf8')
  check(th.includes('OpenProps') && th.includes('自建 CSS 变量主题'), 'C3 THEMES.md 保留"不引 OpenProps/UnoCSS/Tailwind/Radix，自建"结论')

  // 版本收敛静态证据：package.json 是唯一真相
  const pkg = JSON.parse(readFileSync(join(PROJECT_ROOT, 'package.json'), 'utf8'))
  const plugVersions = readdirSync(join(PROJECT_ROOT, 'packages', 'plugins'))
    .map((d) => join(PROJECT_ROOT, 'packages', 'plugins', d, 'plugin.json'))
    .filter((f) => existsSync(f))
    .map((f) => JSON.parse(readFileSync(f, 'utf8')).version)
  const packVersions = readdirSync(join(PROJECT_ROOT, 'packages', 'packs'))
    .map((d) => join(PROJECT_ROOT, 'packages', 'packs', d, 'pack.json'))
    .filter((f) => existsSync(f))
    .map((f) => JSON.parse(readFileSync(f, 'utf8')).version)
  check(pkg.version === '0.6.0', '版本收敛：package.json = 0.6.0', pkg.version)
  check(plugVersions.every((v) => v === '0.6.0') && plugVersions.length >= 8, `版本收敛：${plugVersions.length}×plugin.json 全为 0.6.0`)
  check(packVersions.every((v) => v === '0.6.0') && packVersions.length >= 4, `版本收敛：${packVersions.length}×pack.json 全为 0.6.0`)

  // --- 启动 electron ---

  if (countOrbAll() > 0) throw new Error('已有 research-orb electron 在运行（fail-closed）')

  saveSettings({ theme: 'sky-blue', activePack: 'research', enabledPacks: ['research'] })
  let child = null
  try {
    const childEnv = { ...process.env, RESEARCH_ORB_TIME_SCALE: '2' }
    delete childEnv.ELECTRON_RUN_AS_NODE
    child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN_MJS], { cwd: PROJECT_ROOT, env: childEnv, stdio: 'ignore' })
    log(`electron pid=${child.pid}`)
    await connectCdp()
    await sleep(5500)

    // 展开面板
    await cdp.send('Runtime.evaluate', { expression: `window.researchOrb.send('window', { action: 'expand' })` })
    await sleep(1500)

    // —— 评审②：顶栏对齐（实测数字）——
    const bars = await cdp.evaluate(`(() => {
      const ids = ['history', 'permission-button', 'new-conversation']
      const out = {}
      for (const id of ids) {
        const el = document.getElementById(id)
        if (!el) continue
        const r = el.getBoundingClientRect()
        out[id] = { top: Math.round(r.top * 10) / 10, h: Math.round(r.height * 10) / 10, cy: Math.round((r.top + r.height / 2) * 10) / 10 }
      }
      return out
    })()`)
    const cys = Object.values(bars).map((b) => b.cy)
    const spread = cys.length === 3 ? Math.max(...cys) - Math.min(...cys) : -1
    check(cys.length === 3 && spread <= 1.5, '评审② 顶栏三件套视觉中心对齐（实测中心差 ≤1.5px）',
      Object.entries(bars).map(([k, v]) => `${k}: cy=${v.cy} h=${v.h}`).join(' | '))
    // chip 文本超长走省略号
    const ellip = await cdp.evaluate(`(() => {
      const l = document.getElementById('permission-label')
      if (!l) return null
      const cs = getComputedStyle(l)
      return { overflow: cs.textOverflow, whiteSpace: cs.whiteSpace, maxW: Math.round(l.getBoundingClientRect().width) }
    })()`)
    check(ellip && ellip.overflow === 'ellipsis' && ellip.whiteSpace === 'nowrap', '评审② chip 文本超长走省略号', JSON.stringify(ellip))

    // —— 评审③：文字层级（.ro-code 用等宽 + 次要色）——
    const code = await cdp.evaluate(`(() => {
      const c = document.querySelector('.ro-code')
      if (!c) return null
      const cs = getComputedStyle(c)
      return { font: cs.fontFamily.slice(0, 40), color: cs.color, monoVar: getComputedStyle(document.documentElement).getPropertyValue('--ro-mono').trim() }
    })()`)
    const hex2rgb = (h) => {
      let x = String(h).replace('#', '')
      if (x.length === 3) x = x.split('').map((c) => c + c).join('')
      return 'rgb(' + [0, 2, 4].map((i) => parseInt(x.slice(i, i + 2), 16)).join(', ') + ')'
    }
    const dimRgb = hex2rgb(sky.colors.textDim)
    check(!!code && /Consolas|mono/i.test(code.font) && code.color === dimRgb,
      '评审③ 代码路径用 font.mono + textDim 呈现', code ? `${code.font} / ${code.color}（期望 ${dimRgb}）` : 'n/a')
    const layers = await cdp.evaluate(`(() => {
      const t = document.querySelector('.ro-welcome-title')
      const line = document.querySelector('.ro-welcome-line:not(.ro-welcome-sub)')
      const sub = document.querySelector('.ro-welcome-sub')
      const f = (el) => el ? getComputedStyle(el).fontSize : null
      return { title: f(t), line: f(line), sub: f(sub) }
    })()`)
    check(layers.title && layers.line && layers.sub && layers.title !== layers.line && layers.line !== layers.sub,
      '评审③ 三层级分明（标题/正文/次要字号互不相同）', JSON.stringify(layers))

    // —— 评审①：概览卡（pack 提供，无假数据）——
    const ov = await cdp.evaluate(`(() => {
      const cards = [...document.querySelectorAll('.ro-ov-card')]
      return {
        count: cards.length,
        titles: cards.map((c) => c.querySelector('.ro-ov-title') && c.querySelector('.ro-ov-title').textContent),
        emptyState: !!document.querySelector('.ro-ov-empty'),
        bottomGap: (() => {
          const last = document.elementFromPoint(210, 560)
          const tr = document.getElementById('transcript')
          if (!tr) return null
          return { transcriptH: Math.round(tr.getBoundingClientRect().height), winH: window.innerHeight }
        })(),
      }
    })()`)
    check(ov.count >= 1 || ov.emptyState, '评审① 概览卡已渲染（pack 数据 或 友好空态，无假数据）', `cards=${ov.count} titles=${JSON.stringify(ov.titles)}`)
    const hasReal = ov.titles && ov.titles.every((t) => /今日概览/.test(t || ''))
    check(hasReal, '评审① 概览卡标题为真实汇总（非占位假数据）', JSON.stringify(ov.titles))

    await shot('stage61-after-research.png')

    // —— 评审④：球体外圈描边实测（box-shadow 含 ring 色）——
    const ball = await cdp.evaluate(`(() => {
      const b = document.getElementById('ball')
      if (!b) return null
      const cs = getComputedStyle(b)
      const themeEl = document.getElementById('ro-theme')
      const themeRule = themeEl ? (themeEl.textContent.split('}').find((x) => x.includes('#ball')) || '') : ''
      return { shadow: cs.boxShadow.slice(0, 400), ring: getComputedStyle(document.documentElement).getPropertyValue('--ro-ring').trim(), themeRule }
    })()`)
    // 判据：注入的 #ro-theme 样式层里，#ball 规则必须同时含 ring 色的描边与外发光
    //（computed boxShadow 的归一化格式跨版本不稳定，样式层内容才是级联真相；
    //  视觉复核见 data/shots/stage61-ball-collapsed.png —— 球外圈确有 1.5px 浅色描边 + 外发光）
    const ringRgb = hex2rgb(ball ? ball.ring : '#000000')
    check(!!ball && !!ball.themeRule && ball.themeRule.includes(ball.ring) && ball.themeRule.includes('0 0 7px'),
      '评审④ 球体 #ball 规则含 ball.ring 描边 + 外发光（样式层级联真相）', ball ? `ring=${ball.ring} (${ringRgb})` : 'n/a')

    // —— 评审⑥a：research 占位文案 ——
    const ph1 = await cdp.evaluate(`document.getElementById('prompt').getAttribute('data-placeholder')`)
    check(typeof ph1 === 'string' && ph1.includes('/start'), '评审⑥a research 占位文案语境化', ph1)

    // —— 评审⑥b：切到 general，占位文案随之变化 ——
    saveSettings({ activePack: 'general', enabledPacks: ['general'], theme: 'warm-sand' })
    await reloadPanel()
    await cdp.send('Runtime.evaluate', { expression: `window.researchOrb.send('window', { action: 'expand' })` })
    await sleep(1500)
    const ph2 = await cdp.evaluate(`document.getElementById('prompt').getAttribute('data-placeholder')`)
    check(typeof ph2 === 'string' && ph2 !== ph1, '评审⑥b 切到 general 后占位文案随之变化', `research="${ph1}" → general="${ph2}"`)
    await shot('stage61-after-general.png')

    // 切回 research + sky-blue
    saveSettings({ activePack: 'research', enabledPacks: ['research'], theme: 'sky-blue' })
    await reloadPanel()
    await cdp.send('Runtime.evaluate', { expression: `window.researchOrb.send('window', { action: 'expand' })` })
    await sleep(1500)

    // —— 版本 0.6.0：设置页截图（含版本串）——
    const title = await cdp.evaluate(`document.querySelector('.ro-welcome-title') && document.querySelector('.ro-welcome-title').textContent`)
    check(title === 'research-orb v0.6.0', '版本收敛：面板标题显示 v0.6.0', title)
    await cdp.evaluate(`(() => {
      const btn = document.getElementById('permission-button')
      if (btn) btn.click()
    })()`)
    await sleep(900)
    await shot('stage61-settings-version-0.6.0.png')

    // 收起（回到球态，便于看球体外圈）
    await cdp.send('Runtime.evaluate', { expression: `window.researchOrb.send('window', { action: 'collapse' })` })
    await sleep(900)
    await shot('stage61-ball-collapsed.png')
  } finally {
    try { cdp && cdp.close() } catch { /* noop */ }
        spawnSync('taskkill', ['/pid', String(child.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true })
    await sleep(800)

    check(countOrbAll()=== 0, '进程收尾：我方 electron 残留 = 0', String(countOrbAll()))
  }

  const failed = results.filter((r) => !r.ok).length
  writeFileSync(LOG, `=== P-R6.1 外观微调验收 (${new Date().toISOString()}) ===\n${OUT.join('\n')}\n\n=== ${failed === 0 ? '全部通过' : failed + ' 项失败'}（共 ${results.length} 项）===\n`, 'utf8')
  log(`\nevidence -> ${LOG}`)
  log(`=== 结果：${failed === 0 ? '全部通过' : failed + ' 项失败'}（共 ${results.length} 项）===`)
  process.exit(failed === 0 ? 0 : 1)
}

main().catch((e) => { console.error('外观微调验收异常:', e); process.exit(2) })