// tools/accept-s8-hygiene.mjs —— S8 卫生与可比性验收（数据层探针 + CDP 驱动真实应用）。
//
// 独立性（CONTRACT §7）：
//   · 数据层：tools/s8-probe.mjs 独立子进程 + 独立夹具库（不在真实库造脏数据）。
//   · UI 层：CDP 驱动真实 electron；D3 用连续两次**同状态冻结截图**证明可比；
//     D4 用真实 DOM 点击走四态；不直接调用本片实现的函数（__s5 只作截图辅助）。
//
// 单行复跑：
//   node tools/run-isolated.mjs --label s8 --cmd "node tools/accept-s8-hygiene.mjs"

import { spawn, spawnSync, execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { inflateSync } from 'node:zlib'
import { mkdirSync, writeFileSync, readFileSync, existsSync, rmSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT, logPath } from '../packages/core/src/safefs.mjs'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-s8-hygiene')

const ELECTRON_EXE = ORB_ELECTRON
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const SHOTS = join(PROJECT_ROOT, 'data', 'shots', 's8')
const PORT = 9351
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const sha = (p) => createHash('sha256').update(readFileSync(p)).digest('hex')

mkdirSync(SHOTS, { recursive: true })
const nowTag = new Date().toISOString().replace(/[:.]/g, '-')
const PROBE_WORK = join(PROJECT_ROOT, 'data', 'tmp', `s8-accept-${nowTag}`)
mkdirSync(PROBE_WORK, { recursive: true })

const items = []
function report(id, clause, ok, detail, evidence = {}) {
  items.push({ id, clause, ok: !!ok, detail, evidence })
  console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`)
}

// ---------- PNG 解码 + SSIM（与 accept-ui-matrix 同口径） ----------
function decodePng(buf) {
  let off = 8
  let width = 0, height = 0, colorType = 6
  const idat = []
  while (off < buf.length) {
    const len = buf.readUInt32BE(off)
    const type = buf.toString('ascii', off + 4, off + 8)
    const data = buf.subarray(off + 8, off + 8 + len)
    if (type === 'IHDR') { width = data.readUInt32BE(0); height = data.readUInt32BE(4); colorType = data[9] }
    else if (type === 'IDAT') idat.push(data)
    off += 12 + len
  }
  if (colorType !== 6 && colorType !== 2) throw new Error('unsupported png')
  const ch = colorType === 6 ? 4 : 3
  const raw = inflateSync(Buffer.concat(idat))
  const stride = width * ch
  const out = Buffer.alloc(height * stride)
  let prev = Buffer.alloc(stride)
  for (let y = 0; y < height; y++) {
    const f = raw[y * (stride + 1)]
    const line = raw.subarray(y * (stride + 1) + 1, y * (stride + 1) + 1 + stride)
    const cur = out.subarray(y * stride, (y + 1) * stride)
    for (let x = 0; x < stride; x++) {
      const a = x >= ch ? cur[x - ch] : 0
      const b = prev[x]
      const c = x >= ch ? prev[x - ch] : 0
      let v = line[x]
      if (f === 1) v = (v + a) & 0xff
      else if (f === 2) v = (v + b) & 0xff
      else if (f === 3) v = (v + ((a + b) >> 1)) & 0xff
      else if (f === 4) {
        const p = a + b - c
        const pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c)
        v = (v + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c)) & 0xff
      }
      cur[x] = v
    }
    prev = cur
  }
  return { width, height, channels: ch, data: out }
}
function ssim(a, b) {
  if (a.width !== b.width || a.height !== b.height) return -1
  const W = 8, C1 = (0.01 * 255) ** 2, C2 = (0.03 * 255) ** 2
  const ga = new Float64Array(a.width * a.height), gb = new Float64Array(b.width * b.height)
  for (let i = 0; i < ga.length; i++) {
    const oa = i * a.channels, ob = i * b.channels
    ga[i] = 0.299 * a.data[oa] + 0.587 * a.data[oa + 1] + 0.114 * a.data[oa + 2]
    gb[i] = 0.299 * b.data[ob] + 0.587 * b.data[ob + 1] + 0.114 * b.data[ob + 2]
  }
  let total = 0, n = 0
  for (let y = 0; y + W <= a.height; y += W) {
    for (let x = 0; x + W <= a.width; x += W) {
      let sa = 0, sb = 0, saa = 0, sbb = 0, sab = 0
      for (let dy = 0; dy < W; dy++) for (let dx = 0; dx < W; dx++) {
        const i = (y + dy) * a.width + (x + dx)
        const va = ga[i], vb = gb[i]
        sa += va; sb += vb; saa += va * va; sbb += vb * vb; sab += va * vb
      }
      const N = W * W, ma = sa / N, mb = sb / N
      const cov = sab / N - ma * mb
      total += ((2 * ma * mb + C1) * (2 * cov + C2)) / ((ma * ma + mb * mb + C1) * (saa / N - ma * ma + sbb / N - mb * mb + C2))
      n += 1
    }
  }
  return n > 0 ? total / n : -1
}

// ---------- 数据层探针 ----------
function runProbe() {
  const r = spawnSync(process.execPath, [join(PROJECT_ROOT, 'tools', 's8-probe.mjs'), '--workdir', PROBE_WORK], {
    encoding: 'utf8', timeout: 180_000, cwd: PROJECT_ROOT,
  })
  try {
    const line = String(r.stdout || '').trim().split('\n').filter(Boolean).pop()
    return JSON.parse(line)
  } catch {
    return { ok: false, fatal: 'probe no json', stderr: String(r.stderr || '').slice(0, 400) }
  }
}

// ---------- CDP ----------
async function findTarget(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const list = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(t.url))
      if (page) return page
    } catch { /* 还没起来 */ }
    await sleep(300)
  }
  throw new Error(`CDP 目标未找到（port ${PORT}）`)
}

let cdp = null
async function connectCdp() {
  const target = await findTarget()
  const ws = new WebSocket(target.webSocketDebuggerUrl)
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve)
    ws.addEventListener('error', () => reject(new Error('CDP WebSocket 连接失败')))
  })
  const pending = new Map()
  let id = 0
  ws.addEventListener('message', (ev) => {
    let m
    try { m = JSON.parse(ev.data) } catch { return }
    if (m.id !== undefined && pending.has(m.id)) {
      const p = pending.get(m.id)
      pending.delete(m.id)
      if (m.error) p.rej(new Error(m.error.message))
      else p.res(m.result)
    }
  })
  cdp = {
    send: (method, params = {}) => new Promise((res, rej) => { const i = ++id; pending.set(i, { res, rej }); ws.send(JSON.stringify({ id: i, method, params })) }),
    evaluate: async (expression) => {
      const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true })
      return r && r.result ? r.result.value : undefined
    },
  }
  await cdp.send('Page.enable')
  await cdp.send('Runtime.enable')
}

async function shot(name) {
  const s = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
  const abs = join(SHOTS, name)
  writeFileSync(abs, Buffer.from(s.data, 'base64'))
  return abs
}
const cmd = (name, args) => cdp.evaluate(`window.researchOrb && window.researchOrb.send('ui', { type: 'plugin:command', name: ${JSON.stringify(name)}, args: ${JSON.stringify(args)} })`)
// 注意：表达式体（不是块体）——否则裸表达式不求值返回
const dom = (expr) => cdp.evaluate(`(() => (${expr}))()`)

/** 前置状态：授予一个有效 session 同意（S2 consent.grant 官方 API；显式申报）。 */
async function grantConsent() {
  const { grant } = await import('../packages/plugins/perception/consent.mjs')
  const { saveConfig } = await import('../packages/plugins/perception/index.mjs')
  const p = join(PROJECT_ROOT, 'data', 'perception-config.json')
  const cfg = existsSync(p) ? JSON.parse(readFileSync(p, 'utf8')) : {}
  cfg.consent = grant('session', { ttl: 4 * 60 * 60 * 1000, policyVersion: (cfg.consent || {}).policyVersion })
  saveConfig(cfg)
  return { grantedAt: cfg.consent.grantedAt, mode: cfg.consent.mode }
}

async function main() {
  console.log('== S8 数据层探针（独立子进程 + 独立夹具）==')
  const probe = runProbe()
  for (const it of (probe.items || [])) report(it.id, it.clause, it.ok, it.detail, it.evidence)
  if (!probe.items) report('S8-D0', '§7 探针可执行', false, probe.fatal || 'probe failed', { stderr: probe.stderr })

  console.log('== S8 UI 层（CDP 驱动真实应用）==')

  if (countOrbAll() > 0) throw new Error('已有 research-orb electron 在运行（fail-closed）')

  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN_MJS], { cwd: PROJECT_ROOT, env: childEnv, stdio: 'ignore' })
  console.log(`  electron pid=${child.pid}`)

  try {
    await connectCdp()
    await sleep(6000)
    await cdp.evaluate(`window.researchOrb.send('window', { action: 'expand' })`)
    await sleep(2500)

    // ---------- D3：连续两次同状态冻结截图必须可比 ----------
    await cdp.evaluate(`window.__s5 && window.__s5.setState('learning')`)
    await sleep(900)
    await cdp.evaluate(`window.__s5 ? window.__s5.freeze() : false`)
    await sleep(600)
    const a1 = await shot('d3-frozen-A.png')
    await sleep(3000) // 真实时间流逝（未冻结时状态条会变）
    const a2 = await shot('d3-frozen-B.png')
    const ssimAB = ssim(decodePng(readFileSync(a1)), decodePng(readFileSync(a2)))
    // 对照组：解冻后两次截图（易变内容会漂——证明冻结确实在起作用）
    await cdp.evaluate(`window.__s5 ? window.__s5.unfreeze() : false`)
    await sleep(2500)
    const u1 = await shot('d3-unfrozen-A.png')
    await sleep(3000)
    const u2 = await shot('d3-unfrozen-B.png')
    const ssimUV = ssim(decodePng(readFileSync(u1)), decodePng(readFileSync(u2)))
    await cdp.evaluate(`window.__s5 ? window.__s5.freeze() : false`)
    await sleep(400)
    report('S8-D3', 'CONTRACT §7 基线可比：同状态连续冻结截图 SSIM≈1', ssimAB >= 0.999,
      `冻结两次 SSIM=${ssimAB.toFixed(5)}（阈值 0.999）；对照组（解冻）SSIM=${ssimUV.toFixed(5)}（易变内容确实会漂，冻结有效）`,
      { ssimFrozen: ssimAB, ssimUnfrozenControl: ssimUV, shots: [a1, a2, u1, u2] })

    // ---------- D4：等待态四态 ----------
    // (1) 前置：consent=denied（基线态）→ 点开始 → 同一 evaluate 内同步读 busy → 失败（原因+下一步）
    const click1 = await dom(`(() => {
      const btn = Array.from(document.querySelectorAll('#s5-home .s5-actions button')).find((b) => /开始学习/.test(b.textContent))
      if (!btn) return { ok: false, reason: 'no-learn-button' }
      btn.click()
      return { ok: true, busy: window.__s5 ? window.__s5.learnState() : null }
    })()`)
    await sleep(2500)
    const fail1 = await dom(`({
      state: window.__s5 ? window.__s5.learnState() : null,
      notice: (document.getElementById('s5-notice') || {}).textContent || null,
      noticeVisible: (document.getElementById('s5-notice') || {}).style ? document.getElementById('s5-notice').style.display !== 'none' : false,
    })`)
    const busy1 = click1 && click1.busy
    const okD4a = click1 && click1.ok && busy1 && busy1.state === 'busy' && busy1.disabled === true && /开始中/.test(busy1.text || '') &&
      fail1 && fail1.state && fail1.state.state === 'failure' && fail1.noticeVisible && /需要重新授权/.test(fail1.notice || '') && /下一步/.test(fail1.notice || '')
    report('S8-D4a', 'CONTRACT §5 等待态：进行中可观测 + 失败给原因与下一步', okD4a,
      `点击后（同帧）learnState=${JSON.stringify(busy1)}；失败态=${fail1 && fail1.state && fail1.state.state}；通知含原因+下一步=${okD4a}`,
      { busy: busy1, failure: fail1 })
    await shot('d4-failure.png')

    // (2) 前置：授予 session 同意（显式申报）→ 点开始 → 同帧 busy → 成功（学习中）
    const consent = await grantConsent()
    console.log(`  前置状态：session 同意已授予（grantedAt=${new Date(consent.grantedAt).toISOString()}）`)
    await sleep(500)
    const click2 = await dom(`(() => {
      const btn = Array.from(document.querySelectorAll('#s5-home .s5-actions button')).find((b) => /开始学习/.test(b.textContent))
      if (!btn) return { ok: false, reason: 'no-learn-button' }
      btn.click()
      return { ok: true, busy: window.__s5 ? window.__s5.learnState() : null }
    })()`)
    const busy2 = click2 && click2.busy
    let success2 = null
    for (let i = 0; i < 25; i++) {
      await sleep(1000)
      success2 = await dom(`({
        state: window.__s5 ? window.__s5.learnState() : null,
        notice: (document.getElementById('s5-notice') || {}).textContent || null,
      })`)
      if (success2 && success2.state && success2.state.state === 'success') break
    }
    const okD4b = click2 && click2.ok && busy2 && busy2.state === 'busy' && success2 && success2.state && success2.state.state === 'success' &&
      /结束学习/.test(success2.state.text || '') && /已开始学习/.test(success2.notice || '')
    report('S8-D4b', 'CONTRACT §5 等待态：成功态（按钮切「结束学习」+ 落账提示）', okD4b,
      `busy=${busy2 && busy2.state}；success=${success2 && success2.state && success2.state.state}；按钮="${success2 && success2.state && success2.state.text}"`,
      { busy: busy2, success: success2, consent })
    await shot('d4-success-learning.png')

    // (3) 点结束学习 → 同帧 busy（结束中…）→ 成功（开始学习 + 已落账）
    const click3 = await dom(`(() => {
      const btn = Array.from(document.querySelectorAll('#s5-home .s5-actions button')).find((b) => /结束学习/.test(b.textContent))
      if (!btn) return { ok: false, reason: 'no-stop-button' }
      btn.click()
      return { ok: true, busy: window.__s5 ? window.__s5.learnState() : null }
    })()`)
    const busy3 = click3 && click3.busy
    let success3 = null
    for (let i = 0; i < 25; i++) {
      await sleep(1000)
      success3 = await dom(`({
        state: window.__s5 ? window.__s5.learnState() : null,
        notice: (document.getElementById('s5-notice') || {}).textContent || null,
      })`)
      if (success3 && success3.state && success3.state.state === 'success' && /开始学习/.test(success3.state.text || '')) break
    }
    const okD4c = click3 && click3.ok && busy3 && busy3.state === 'busy' && /结束中/.test(busy3.text || '') &&
      success3 && success3.state && success3.state.state === 'success' && /开始学习/.test(success3.state.text || '') && /已落账|已结束学习/.test(success3.notice || '')
    report('S8-D4c', 'CONTRACT §5 等待态：结束学习同样四态（结束中…→成功+落账）', okD4c,
      `busy="${busy3 && busy3.text}"；success 按钮="${success3 && success3.state && success3.state.text}"；通知="${success3 && success3.notice ? success3.notice.slice(0, 40) : ''}"`,
      { busy: busy3, success: success3 })
    await shot('d4-success-stopped.png')

    // (4) 统计命令：回收区口径可见（/ui trash）
    await cmd('ui', 'trash')
    await sleep(1200)
    const trashView = await dom(`({
      notice: (document.getElementById('s5-notice') || {}).textContent || null,
      transcript: (document.getElementById('transcript') || {}).textContent || '',
    })`)
    const trashText = `${trashView && trashView.notice || ''} ${trashView && trashView.transcript || ''}`
    report('S8-T6', 'CONTRACT §2/§7 回收区统计从面板可读（文件数/体积/TTL/例外条数）', /回收区/.test(trashText) && /TTL/.test(trashText),
      `面板文本："${trashText.match(/回收区[^"]*/) ? trashText.match(/回收区[^，]*/)[0] : '未出现'}"`,
      { text: trashText.slice(0, 200) })
  } finally {
    try { spawnSync('taskkill', ['/pid', String(child.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true }) } catch { /* noop */ }
    await sleep(800)

    report('S8-CLEAN', '§7 进程收尾', countOrbAll()=== 0, `我方 electron 残留=${String(countOrbAll())}`, {})
  }

  const artifacts = [
    { path: 'packages/core/src/lifecycle/cleaner.mjs', sha256: sha(join(PROJECT_ROOT, 'packages/core/src/lifecycle/cleaner.mjs')) },
    { path: 'packages/core/src/lifecycle/capture-registry.mjs', sha256: sha(join(PROJECT_ROOT, 'packages/core/src/lifecycle/capture-registry.mjs')) },
    { path: 'packages/packs/research/ui/home.js', sha256: sha(join(PROJECT_ROOT, 'packages/packs/research/ui/home.js')) },
    { path: 'packages/plugins/timeline/index.mjs', sha256: sha(join(PROJECT_ROOT, 'packages/plugins/timeline/index.mjs')) },
    { path: 'data/lifecycle-config.json', sha256: sha(join(PROJECT_ROOT, 'data/lifecycle-config.json')) },
    { path: 'tools/s8-probe.mjs', sha256: sha(join(PROJECT_ROOT, 'tools/s8-probe.mjs')) },
    { path: 'tools/accept-s8-hygiene.mjs', sha256: sha(join(PROJECT_ROOT, 'tools/accept-s8-hygiene.mjs')) },
    { path: 'tools/freeze-ui-baseline.mjs', sha256: sha(join(PROJECT_ROOT, 'tools/freeze-ui-baseline.mjs')) },
  ]
  for (const f of ['d3-frozen-A.png', 'd3-frozen-B.png', 'd3-unfrozen-A.png', 'd3-unfrozen-B.png', 'd4-failure.png', 'd4-success-learning.png', 'd4-success-stopped.png']) {
    const p = join(SHOTS, f)
    if (existsSync(p)) artifacts.push({ path: `data/shots/s8/${f}`, sha256: sha(p) })
  }

  const out = {
    label: 's8-hygiene',
    ts: new Date().toISOString(),
    verdict: null,
    preState: {
      productionDb: 'run-isolated 快照/还原（data/db/orb.sqlite）',
      fixtures: `探针自建于 ${PROBE_WORK}`,
      app: 'CDP 真启动（--no-sandbox + remote-debugging）',
      d4Consent: 'D4b 前经 S2 consent.grant 授予 session（显式申报；run-isolated 还原）',
    },
    rerun: 'node tools/run-isolated.mjs --label s8 --cmd "node tools/accept-s8-hygiene.mjs"',
    independence: {
      data: 's8-probe.mjs 独立子进程 + 独立夹具库',
      ui: 'CDP 驱动真实应用；D4 用真实 DOM 点击；__s5 仅作截图/状态读取辅助',
      baseline: 'D3 用连续两次同状态冻结截图自证可比 + 解冻对照组',
      selfReported: [],
    },
    items,
    artifacts,
  }
  const failed = items.filter((i) => !i.ok)
  out.verdict = failed.length === 0 ? 'accept' : 'reject'
  out.failures = failed.map((f) => ({ id: f.id, reason: f.detail }))

  const runRoot = process.env.ORB_RUN_ROOT
  const payload = JSON.stringify(out, null, 2)
  writeFileSync(logPath('s8-accept-evidence.json'), payload)
  if (runRoot) { try { writeFileSync(join(runRoot, 's8-evidence.json'), payload) } catch { /* noop */ } }
  console.log(`S8 卫生与可比性验收：${items.filter((i) => i.ok).length}/${items.length} 通过 → ${out.verdict}`)
  console.log(`证据：${logPath('s8-accept-evidence.json')}`)
  try { rmSync(PROBE_WORK, { recursive: true, force: true }) } catch { /* noop */ }
  process.exit(out.verdict === 'accept' ? 0 : 1)
}

main().catch((e) => { console.error('S8 验收异常:', e); process.exit(2) })
