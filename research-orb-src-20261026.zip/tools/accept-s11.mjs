// tools/accept-s11.mjs —— S11 验收编排（CONTRACT §7：验收独立性）
//
// 确定性检查（本脚本直接跑）：
//   T1 主题：teal 为默认；四套主题全过 schema；对比度约束（正文≥4.5/次要≥3/强调≥4.5）；
//      themeToCss 输出 --ro-warn/--ro-danger/--ro-info/--ro-face 且不含几何 token / width / height
//   T2 图标：重跑 make-icons；候选 A/B/C（ball 96 / tray 32 / tray-16 16）+ 四态表情
//      （face-*.svg + ball-face-*.png）+ 两张 montage + MANIFEST selected=A 全部存在
//   T3 匿名自检：node tools/anon-check.mjs 硬违例 = 0
//   T4 几何契约（静态）：main.mjs 的 COLLAPSED_SIZE 96×96 / EXPANDED_SIZE 420×620 未变、
//      无 .focus() 调用、面板走 showInactive
//   T5 运行时接线（静态）：ui-bridge 注入四态表情（setOrbExpression/FACE_INNER 四键）；
//      home.js 在询问/失败/清除时调用；timer.js 角标色走 var(--ro-*)；组件无新增硬编码青绿
// 可选（--electron）：真 electron + CDP 的 12 态 UI 矩阵 + 基线重冻
//   （accept-ui-matrix --refreeze；需本机 electron，冷启动约 3–4 分钟）
//
// 用法：node tools/accept-s11.mjs [--electron]

import { spawnSync } from 'node:child_process'
import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import * as T from '../packages/core/src/themes.mjs'

const OUT = []
const results = []
const log = (s) => { OUT.push(s); console.log(s) }
const check = (cond, label, extra = '') => {
  log(`${cond ? 'PASS' : 'FAIL'}  ${label}${extra ? '  ' + extra : ''}`)
  results.push({ ok: !!cond, label, extra: String(extra) })
  return !!cond
}
const EVID = join(PROJECT_ROOT, 'data', 'logs', 's11-accept-evidence.json')
const ICONS = join(PROJECT_ROOT, 'apps', 'desktop', 'assets', 'icons')

// ---- T1 主题 ----
function t1Themes() {
  check(T.DEFAULT_THEME === 'teal', 'T1 默认主题 = teal', T.DEFAULT_THEME)
  const names = ['teal', 'sky-blue', 'warm-sand', 'ink-dark']
  for (const n of names) {
    const th = T.readTheme(n) // 校验不过会抛
    const body = T.contrastRatio(th.colors.text, th.colors.panel)
    const dim = T.contrastRatio(th.colors.textDim, th.colors.panel)
    const acc = T.contrastRatio(th.colors.accent, th.colors.panel)
    check(body >= 4.5 && dim >= 3 && acc >= 4.5, `T1 ${n} 对比度（正文/次要/强调）`,
      `${body.toFixed(2)}/${dim.toFixed(2)}/${acc.toFixed(2)}`)
  }
  for (const n of names) {
    const css = T.themeToCss(T.readTheme(n))
    check(['--ro-warn', '--ro-danger', '--ro-info', '--ro-face'].every((v) => css.includes(v)),
      `T1 ${n} themeToCss 输出语义色 token`)
    check(!css.includes('--ball:') && !/\bwidth\s*:/.test(css) && !/\bheight\s*:/.test(css),
      `T1 ${n} themeToCss 不含几何 token / width / height`)
    const th = T.readTheme(n)
    check(['warn', 'danger', 'info', 'face'].every((k) => th.colors[k]), `T1 ${n} colors 含 warn/danger/info/face`)
  }
}

// ---- T2 图标 ----
function t2Icons() {
  const r = spawnSync(process.execPath, [join(PROJECT_ROOT, 'tools', 'make-icons.mjs')], { cwd: PROJECT_ROOT, encoding: 'utf8' })
  check(r.status === 0, 'T2 make-icons 生成成功', r.stderr && r.stderr.slice(0, 120))
  const need = []
  for (const k of ['A', 'B', 'C']) {
    need.push(`ball-${k}.svg`, `ball-${k}.png`, `ball-run-${k}.svg`, `ball-run-${k}.png`,
      `tray-${k}.svg`, `tray-${k}.png`, `tray-${k}-16.png`)
  }
  for (const m of ['idle', 'thinking', 'need-help', 'error']) {
    need.push(`face-${m}.svg`, `ball-face-${m}.png`)
  }
  need.push('ball.svg', 'ball.png', 'ball-run.svg', 'ball-run.png', 'tray.svg', 'tray.png', 'tray-16.png',
    'candidates-sheet.png', 'expressions-sheet.png', 'MANIFEST.json')
  const missing = need.filter((f) => !existsSync(join(ICONS, f)))
  check(missing.length === 0, 'T2 候选×3 + 四态表情 + 选中产物 + montage 齐全', missing.join(',') || `${need.length} 个文件`)
  try {
    const man = JSON.parse(readFileSync(join(ICONS, 'MANIFEST.json'), 'utf8'))
    check(man.selected === 'A', 'T2 MANIFEST 选定 A（轨道球）', `selected=${man.selected}`)
    check(man.palette && man.palette.from === '#5eead4' && man.palette.to === '#0d9488',
      'T2 MANIFEST 调色板 = 青绿（镜像 teal.theme.json）', JSON.stringify(man.palette))
    check(Array.isArray(man.expressions) && man.expressions.length === 4, 'T2 MANIFEST 含四态表情')
  } catch (e) {
    check(false, 'T2 MANIFEST 可解析', String(e).slice(0, 120))
  }
  // 16px 托盘必须存在且非空（小尺寸可辨识的载体）
  const t16 = join(ICONS, 'tray-16.png')
  check(existsSync(t16) && readFileSync(t16).length > 300, 'T2 16px 托盘位图存在且非空', existsSync(t16) ? `${readFileSync(t16).length} B` : '缺失')
}

// ---- T3 匿名自检 ----
function t3Anon() {
  const r = spawnSync(process.execPath, [join(PROJECT_ROOT, 'tools', 'anon-check.mjs')], { cwd: PROJECT_ROOT, encoding: 'utf8' })
  check(r.status === 0, 'T3 匿名自检硬违例 = 0', (r.stdout || '').split('\n')[0] || '')
}

// ---- T4 几何契约（静态）----
function t4Geometry() {
  const main = readFileSync(join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs'), 'utf8')
  check(/COLLAPSED_SIZE = \{ width: 96, height: 96 \}/.test(main), 'T4 球 96×96 常量未变')
  check(/EXPANDED_SIZE = \{ width: 420, height: 620 \}/.test(main), 'T4 展开 420×620 常量未变')
  // S67·4-B：T4 从"全文无 .focus()"升级为结构断言——聚焦只在唯一入口 activateForInteraction，
  // 且仅用户交互路径（展开/composer 点击）调用；showInactive 被动路径不聚焦。
  const _lines = main.split('\n')
  const _fnRanges = (() => {
    const out = []
    for (let i = 0; i < _lines.length; i++) {
      const m = _lines[i].match(/^\s*function\s+([A-Za-z_$][\w$]*)\s*\(/)
      if (!m) continue
      let depth = 0, started = false, end = -1
      for (let j = i; j < _lines.length; j++) {
        for (const ch of _lines[j]) { if (ch === '{') { depth++; started = true } else if (ch === '}') depth-- }
        if (started && depth === 0) { end = j; break }
      }
      out.push({ name: m[1], start: i, end })
    }
    return out
  })()
  const _enclosing = (idx) => {
    let best = null
    for (const r of _fnRanges) if (r.start <= idx && idx <= r.end && (!best || (r.end - r.start) < (best.end - best.start))) best = r
    return best ? best.name : '(top-level)'
  }
  const _sites = []
  _lines.forEach((l, i) => {
    if (!/\.focus\(\)/.test(l)) return
    if (/^\s*(\*|\/\/)/.test(l)) return // 注释行不算调用
    _sites.push({ line: i + 1, fn: _enclosing(i) })
  })
  const _bad = _sites.filter((s) => s.fn !== 'activateForInteraction')
  check(/function activateForInteraction\s*\(/.test(main), 'T4 存在唯一聚焦入口 activateForInteraction')
  check(_sites.length >= 1 && _bad.length === 0,
    'T4 无抢前台：所有 .focus() 调用均在 activateForInteraction 内（' + _sites.map((s) => 'L' + s.line + ':' + s.fn).join(', ') + ( _bad.length ? '｜越界=' + _bad.map((s) => s.fn).join(',') : '') + '）')
  check(/win\.showInactive\(\)/.test(main) && /else\s*\{\s*win\.showInactive\(\)/.test(main),
    'T4 被动展示不聚焦：showInactive 分支独立存在，不调用 focus')
}

// ---- T5 运行时接线（静态）----
function t5Wiring() {
  const bridge = readFileSync(join(PROJECT_ROOT, 'apps', 'desktop', 'ui-bridge.mjs'), 'utf8')
  check(/setOrbExpression/.test(bridge) && /FACE_INNER/.test(bridge), 'T5 ui-bridge 注入表情机制')
  for (const m of ['idle', 'thinking', 'need-help', 'error']) {
    check(new RegExp(`'${m}'`).test(bridge), `T5 表情态 ${m} 已定义`)
  }
  check(/ro-ball-face/.test(bridge), 'T5 #ball-face 叠加层样式存在（pointer-events:none）')
  check(/var\(--ro-face/.test(bridge), 'T5 表情色走 --ro-face token')
  check(!/#fde68a|#fca5a5|#fbbf24|#f87171|#7dd3fc/.test(bridge) || /var\(--ro-/.test(bridge),
    'T5 角标/圆环色已路由到 var(--ro-*)')
  const home = readFileSync(join(PROJECT_ROOT, 'packages', 'packs', 'research', 'ui', 'home-v1.js'), 'utf8')
  check(/setOrbExpression\('need-help'\)/.test(home), 'T5 home.js 询问卡 → need-help')
  check(/setOrbExpression\('error'\)/.test(home), 'T5 home.js 失败 → error')
  check(/setOrbExpression\('clear'\)/.test(home), 'T5 home.js 用户动作 → clear')
  const timer = readFileSync(join(PROJECT_ROOT, 'packages', 'packs', 'research', 'ui', 'timer.js'), 'utf8')
  check(/var\(--ro-warn\)|var\(--ro-danger\)|var\(--ro-info\)/.test(timer), 'T5 timer.js 圆环色走 var(--ro-*)')
  const themesCore = readFileSync(join(PROJECT_ROOT, 'packages', 'core', 'src', 'themes.mjs'), 'utf8')
  check(/DEFAULT_THEME = 'teal'/.test(themesCore), 'T5 core 默认主题常量 = teal')
}

// ---- 可选：真 electron 12 态矩阵 + 基线重冻 ----
function t6Electron() {
  const r = spawnSync(process.execPath, [join(PROJECT_ROOT, 'tools', 'accept-ui-matrix.mjs'), '--refreeze'],
    { cwd: PROJECT_ROOT, encoding: 'utf8', timeout: 420000, maxBuffer: 32 * 1024 * 1024 })
  const tail = (r.stdout || '').trim().split('\n').filter(Boolean).slice(-3).join(' | ')
  check(r.status === 0, 'T6 electron 12 态矩阵 + 基线重冻（--refreeze）', tail || `exit=${r.status}`)
  const mig = join(PROJECT_ROOT, 'data', 'shots', 'ui-matrix', 'baseline-s11-migration.json')
  check(existsSync(mig), 'T6 old→new 基线哈希映射已落盘', 'data/shots/ui-matrix/baseline-s11-migration.json')
}

// ---- 主流程 ----
const wantElectron = process.argv.includes('--electron')
t1Themes()
t2Icons()
t3Anon()
t4Geometry()
t5Wiring()
if (wantElectron) t6Electron()
else log('INFO  未加 --electron：真机 12 态矩阵跳过（在本机跑 `node tools/accept-ui-matrix.mjs --refreeze`，或 run-isolated --label s11）')

const failed = results.filter((r) => !r.ok).length
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(EVID, JSON.stringify({
  tool: 'accept-s11', generatedAt: new Date().toISOString(), electron: wantElectron,
  results, failed, total: results.length,
}, null, 2) + '\n')
log(`\nevidence -> ${EVID}`)
log(`=== S11 验收：${failed === 0 ? '全部通过' : failed + ' 项失败'}（共 ${results.length} 项）===`)
process.exit(failed === 0 ? 0 : 1)
