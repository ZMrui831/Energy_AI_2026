// tools/s7-probe.mjs —— S7 数据层探针（独立子进程；只动 argv 给的 workdir 内自建夹具）。
// 覆盖：D10 清理终态优化（文件不存在 → deleted(reason=already-gone)，不空转重试）；
//       对照组（目录路径仍走 error/retryable，证明熔断未破坏）；
//       数据层证据闸仍在（裸 SQL）。
// 用法：node tools/s7-probe.mjs --workdir <dir>
// 输出：stdout 单行紧凑 JSON。

import { mkdirSync, writeFileSync, rmSync } from 'node:fs'
import {join, resolve} from 'node:path'

import { createStore } from '../packages/core/src/db.mjs'
import { runCleanup } from '../packages/core/src/lifecycle/cleaner.mjs'

const argv = process.argv.slice(2)
const arg = (k, d = null) => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : d }
const WORK = arg('--workdir') || join(resolve(import.meta.dirname, '..'), 'data', 'tmp', `s7-probe-${Date.now()}`)
mkdirSync(WORK, { recursive: true })

const items = []
function report(id, clause, ok, detail, evidence = {}) {
  items.push({ id, clause, ok: !!ok, detail, evidence })
  console.error(`[${ok ? 'PASS' : 'FAIL'}] ${id} (${clause}) ${detail}`)
}

async function freshStore(name) {
  const dir = join(WORK, name)
  mkdirSync(dir, { recursive: true })
  const store = await createStore({ driver: 'sqlite', dbPath: join(dir, 'orb.sqlite'), dataDir: dir })
  store.initMigrations()
  return { dir, store }
}

async function main() {
  const nowIso = new Date().toISOString()
  const PAST = new Date(Date.now() - 3600_000).toISOString()

  // ---------- S7-D10：文件不存在 → 单轮终态 deleted(reason=already-gone) ----------
  {
    const { dir, store } = await freshStore('fx-d10')
    mkdirSync(join(dir, 'shots'), { recursive: true })
    const ghost = join(dir, 'shots', 'already-gone.png')
    // 登记一帧（已过期），但文件从不创建（模拟孤儿清扫后文件已不在 / 外部已删）
    store.insertRawFrame({ id: 'ghost-1', file_path: ghost, sha256: 'c'.repeat(64), sensitivity: 'normal', created_at: PAST, expires_at: PAST })
    const s1 = await runCleanup({ store, shotsDir: join(dir, 'shots'), trashDir: join(dir, 'trash') })
    const row = store.getRawFrame('ghost-1')
    const ev = store.listAuditEvents({ kind: 'frame-deleted' })
    const reasonOk = ev.length === 1 && JSON.parse(ev[0].metadata_json).reason === 'already-gone'
    const s2 = await runCleanup({ store, shotsDir: join(dir, 'shots'), trashDir: join(dir, 'trash') })
    const row2 = store.getRawFrame('ghost-1')
    const stuckAudits = store.listAuditEvents({ kind: 'lifecycle-stuck' }).length
    const ok = s1.deleted === 1 && s1.errored === 0 && row.status === 'deleted' && reasonOk && row2.status === 'deleted' && stuckAudits === 0
    report('S7-D10', 'CONTRACT §1.4/D10 文件不存在 → 单轮终态 deleted(reason=already-gone)', ok,
      `第1轮 deleted=${s1.deleted} errored=${s1.errored} stuck=${s1.stuck}；status=${row.status}；审计 reason=already-gone=${reasonOk}；stuck 审计=${stuckAudits}；第2轮无变化=${row2.status === 'deleted'}`,
      { round1: s1, status: row.status, auditReason: ev.length ? JSON.parse(ev[0].metadata_json).reason : null, stuckAudits, round2Status: row2.status })
    store.close()
  }

  // ---------- S7-D10c：对照组——目录路径仍走 error + 可重试（熔断未破坏） ----------
  {
    const { dir, store } = await freshStore('fx-d10c')
    mkdirSync(join(dir, 'blocked-dir'), { recursive: true })
    store.insertRawFrame({ id: 'blk-1', file_path: join(dir, 'blocked-dir'), sha256: 'd'.repeat(64), sensitivity: 'normal', created_at: PAST, expires_at: PAST })
    const s1 = await runCleanup({ store, shotsDir: join(dir, 'shots'), trashDir: join(dir, 'trash') })
    const row = store.getRawFrame('blk-1')
    const ok = s1.errored === 1 && row.status === 'error' && String(row.error).includes('E_DELETE_RETRYABLE')
    report('S7-D10c', 'CONTRACT §1.4 对照组：非 ENOENT 失败仍走 error/重试（熔断未破坏）', ok,
      `目录路径 → errored=${s1.errored} status=${row.status} error=${String(row.error).slice(0, 40)}`,
      { round1: s1, status: row.status, error: String(row.error).slice(0, 80) })
    store.close()
  }

  // ---------- S7-GATE：数据层证据闸仍在（裸 SQL，不经 publish.mjs） ----------
  {
    const { store } = await freshStore('fx-gate')
    store._db.prepare("INSERT INTO claim(id, kind, text, evidence_mode, status, created_at) VALUES ('clm-gate','observation','裸 SQL 发布尝试','direct','draft',?)").run(nowIso)
    let msg = null
    try { store._db.exec("UPDATE claim SET status = 'published' WHERE id = 'clm-gate'") } catch (e) { msg = String(e && e.message) }
    const status = store._db.prepare("SELECT status FROM claim WHERE id = 'clm-gate'").get().status
    const ok = !!msg && msg.includes('CLAIM_EVIDENCE_REQUIRED') && status === 'draft'
    report('S7-GATE', 'CONTRACT §6 数据层证据闸未被 UI 片削弱（裸 SQL 复验）', ok,
      `裸 SQL UPDATE → ${msg ? msg.slice(0, 60) : '未抛错'}；status=${status}`,
      { triggerMessage: msg, status, via: 'raw SQL' })
    store.close()
  }

  const okAll = items.every((i) => i.ok)
  process.stdout.write(JSON.stringify({ ok: okAll, workdir: WORK, items }) + '\n')
  process.exit(okAll ? 0 : 1)
}

main().catch((e) => {
  process.stdout.write(JSON.stringify({ ok: false, fatal: String((e && e.stack) || e), items }) + '\n')
  process.exit(2)
})
