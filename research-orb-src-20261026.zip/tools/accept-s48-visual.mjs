// tools/accept-s48-visual.mjs —— S48·P1 视觉缺陷验收（≥6 项，实到 8 项）
//
// 单行复跑：node tools\accept-s48-visual.mjs
//
// 与 accept-s47-ui-consistency 的分工：那份验"设计系统有没有落地"，
// 这份验"人眼看得见的三处缺陷有没有真修" —— ① accent 大块 ② 透字 ③ 文字对比。
// 全部读 computedStyle / 几何矩形，不看源码字符串。

import { mkdtempSync, rmSync, cpSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import { spawn, spawnSync } from 'node:child_process'
import {killMarked, countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-s48-visual')

const ELECTRON = ORB_ELECTRON
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9335
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 360) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}
const countProcs = () => countOrbAll()
const killOwn = () => killMarked(MARK)

async function findTarget(timeoutMs = 40000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await res.json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(String(t.url || '')))
      if (page) return page
    } catch { /* 还没起来 */ }
    await sleep(350)
  }
  return null
}

function cdpConnect(wsUrl) {
  const ws = new WebSocket(wsUrl)
  let seq = 0
  const pending = new Map()
  const ready = new Promise((res, rej) => {
    ws.addEventListener('open', () => res())
    ws.addEventListener('error', () => rej(new Error('ws error')))
  })
  ws.addEventListener('message', (ev) => {
    let m = null
    try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
    if (!m || !m.id) return
    const p = pending.get(m.id)
    if (!p) return
    pending.delete(m.id)
    if (m.error) p.rej(new Error(JSON.stringify(m.error)))
    else p.res(m.result)
  })
  const send = (method, params) => new Promise((res, rej) => {
    const id = ++seq
    pending.set(id, { res, rej })
    ws.send(JSON.stringify({ id, method, params }))
  })
  return { ready, send, close: () => { try { ws.close() } catch { /* noop */ } } }
}
async function evaluate(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r && r.exceptionDetails) throw new Error('evaluate 异常：' + JSON.stringify(r.exceptionDetails).slice(0, 300))
  return r && r.result ? r.result.value : undefined
}

/** 页内探针：accent 大块 / alpha / 字阶 / 对比抽样 / 窗口框 / 各页空态 / 禁词。 */
const PROBE = `(() => {
  const ACCENT = [45, 212, 191]
  const near = (rgb) => {
    if (!rgb) return false
    const m = /rgba?\\(([^)]+)\\)/.exec(rgb)
    if (!m) return false
    const p = m[1].split(',').map((x) => Number(x.trim()))
    if (p.length < 3) return false
    // 判定"薄荷绿"：G 明显高于 R 与 B，且饱和度够
    return p[1] > 120 && p[1] - p[0] > 40 && Math.abs(p[2] - p[1]) < 90 && p[1] > p[2] - 10
  }
  const panel = document.getElementById('panel')
  const pcs = getComputedStyle(panel)
  const alpha = (() => {
    const m = /rgba?\\(([^)]+)\\)/.exec(pcs.backgroundColor)
    if (!m) return 1
    const p = m[1].split(',').map((x) => Number(x.trim()))
    return p.length >= 4 ? p[3] : 1
  })()
  const pr = panel.getBoundingClientRect()

  // ① accent 大块：扫 **整个 body**（含 #panel 之外 —— 顶部/底部的绿条不排除在面板外），
  //    面积 > 40×40 且无文字/无子元素；button/球/状态点豁免。
  const accentBlocks = []
  const accentAll = []
  for (const el of document.body.querySelectorAll('*')) {
    const cs = getComputedStyle(el)
    const bg = cs.backgroundColor
    if (!near(bg)) continue
    const r = el.getBoundingClientRect()
    const txt = (el.innerText || '').trim()
    const isControl = /^(BUTTON|INPUT|TEXTAREA|SELECT)$/.test(el.tagName)
    const exempt = isControl || el.id === 'ball' || el.id === 'ball-gif' || el.classList.contains('ds-dot') || el.closest('#ro-ds-nav') || el.closest('#ball')
    const rec = {
      tag: el.tagName, id: el.id || '', cls: String(el.className || '').slice(0, 48),
      w: Math.round(r.width), h: Math.round(r.height), bg,
      text: txt.slice(0, 40), kids: el.children.length, area: Math.round(r.width * r.height),
    }
    if (accentAll.length < 12) accentAll.push(rec)
    if (exempt) continue
    if (r.width < 40 || r.height < 40) continue
    accentBlocks.push(rec)
  }
  accentBlocks.sort((a, b) => b.area - a.area)

  // ② 字阶
  const sizes = new Set()
  for (const el of panel.querySelectorAll('*')) {
    const r = el.getBoundingClientRect()
    if (r.width < 1 || r.height < 1) continue
    const cs = getComputedStyle(el)
    if (cs.display === 'none' || cs.visibility === 'hidden') continue
    sizes.add(cs.fontSize)
  }

  // ③ 对比抽样：按**角色**取 5 处（不按索引 —— 首页没有 .s5-row 时索引会错位）
  const pickRole = (role, sels) => {
    for (const sel of sels) {
      const el = panel.querySelector(sel)
      if (!el) continue
      const cs = getComputedStyle(el)
      const r = el.getBoundingClientRect()
      if (r.width < 1 || r.height < 1) continue
      return { role, sel, color: cs.color, fs: cs.fontSize, text: (el.textContent || '').trim().slice(0, 28) }
    }
    return null
  }
  const contrast = [
    pickRole('title', ['#ro-s5-topbar .ds-page-name']),
    // S55：body 角色只取次级文本选择器。.s5-row .s5-grow 是列表主文本（设计系统 L84-85 定义
    // 就是 primary），把它当 body 会在待处理区首次真正渲染（S54 面板后端复活）后误判。
    pickRole('body', ['.s5-sub', '#ro-ds-foot .ds-t12', '.ds-t12']),
    pickRole('meta', ['.ds-t11', '.s5-badge']),
    pickRole('btn', ['#ro-s5 button.ro-btn', '#panel button.ro-btn']),
    pickRole('empty', ['.ds-empty-text']),
  ].filter(Boolean)

  // ④ 窗口框 vs 面板
  const frame = { w: window.outerWidth, h: window.outerHeight }
  const avail = { w: window.screen.availWidth, h: window.screen.availHeight }

  // ⑤ 各页空态（切页后由外层驱动，这里只报当前页）
  const visLists = Array.from(panel.querySelectorAll('.s5-list')).filter((n) => n.offsetParent !== null)
  const withEmpty = visLists.filter((n) => {
    const s = n.nextElementSibling
    return !!(s && s.hasAttribute('data-empty-state'))
  }).length

  const text = document.body.innerText || ''
  const navBtns = Array.from(document.querySelectorAll('#ro-ds-nav .ds-nav-btn'))
  return JSON.stringify({
    alpha,
    bg: pcs.backgroundColor,
    backdrop: pcs.backdropFilter || '',
    accentBlocks: accentBlocks.slice(0, 6),
    accentAll: accentAll.slice(0, 8),
    accentCount: accentBlocks.length,
    sizes: Array.from(sizes).sort(),
    contrast,
    frame,
    avail,
    panel: { w: Math.round(pr.width), h: Math.round(pr.height) },
    visLists: visLists.length,
    withEmpty,
    navCount: navBtns.length,
    navLabels: navBtns.map((b) => b.getAttribute('aria-label') || ''),
    ban: {
      ms: /\\bms\\b/.test(text) || /\\d\\s*ms\\b/.test(text),
      words: ['reasoner', 'rpm', 'sk-', '降级'].filter((w) => text.includes(w)),
      drive: /[A-Za-z]:\\\\/.test(text),
    },
  })
})()`

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s48-vis-'))
let child = null
let cdp = null
try {
  if (countProcs() > 0) {
    check('V-0 预检（已有实例在跑则退出）', false, '请先关闭 research-orb')
    throw new Error('preflight')
  }
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  delete env.ORB_LOG_DIR
  env.ORB_DATA_DIR = join(tmpRoot, 'data')
  // 主题保真（教训：临时数据目录无 themes 时应用回退 vendor 默认亮色 → 采样到假主题）
  try { cpSync(join(PROJECT_ROOT, 'data', 'themes'), join(env.ORB_DATA_DIR, 'themes'), { recursive: true }) } catch { /* 无 themes 也不阻塞 */ }
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], { cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] })
  const tail = []
  const push = (b) => { tail.push(String(b)); while (tail.length > 30) tail.shift() }
  if (child.stdout) child.stdout.on('data', push)
  if (child.stderr) child.stderr.on('data', push)

  const target = await findTarget()
  if (!target) {
    check('V-0 启动（CDP floating.html）', false, '未起来：' + tail.join('').slice(-500))
    throw new Error('no-target')
  }
  cdp = cdpConnect(target.webSocketDebuggerUrl)
  await cdp.ready
  await cdp.send('Runtime.enable')
  let bridge = false
  const deadline = Date.now() + 30000
  while (Date.now() < deadline) {
    try {
      // S57 健壮性：只等 researchOrb 会太早（preload 一注入就为真，ui-bridge 尚未就绪 → expand 丢失）。
      // 等 __s5（渲染层）就绪再发 expand。
      bridge = await evaluate(cdp, 'typeof globalThis.__s5 === "object" && typeof globalThis.researchOrb === "object"')
      if (bridge) break
    } catch { /* 等 */ }
    await sleep(400)
  }
  await evaluate(cdp, 'globalThis.researchOrb && globalThis.researchOrb.send("window", { action: "expand" })')
  // 等 panel 真正可见再采样（教训：固定 sleep 1500ms 在冷启动时会采到隐藏态 ——
  // display:none 下 computedStyle 仍可读 → V-2/V-6 假绿，rect 全 0 → V-3/V-5/V-7/V-8 假红）
  let panelUp = false
  const upDeadline = Date.now() + 20000
  let tries = 0
  while (Date.now() < upDeadline) {
    try {
      const h = await evaluate(cdp, '(() => { const p = document.getElementById("panel"); return p ? Math.round(p.getBoundingClientRect().height) : 0 })()')
      if (h > 100) { panelUp = true; break }
      // 每 ~1.5s 重发一次 expand（幂等），避免冷启动时序导致首次 expand 丢失
      tries += 1
      if (tries % 5 === 0) await evaluate(cdp, 'globalThis.researchOrb && globalThis.researchOrb.send("window", { action: "expand" })')
    } catch { /* 等 */ }
    await sleep(300)
  }
  if (!panelUp) {
    check('V-0 expand 后 panel 可见', false, '15s 内 panel 高度未超过 100')
    throw new Error('no-panel')
  }
  await sleep(600)

  const p = JSON.parse(await evaluate(cdp, PROBE))
  console.log('  [INFO] alpha=' + p.alpha + ' bg=' + p.bg + ' frame=' + JSON.stringify(p.frame) + ' panel=' + JSON.stringify(p.panel) + ' avail=' + JSON.stringify(p.avail))
  console.log('  [INFO] accent 块=' + p.accentCount + ' ' + JSON.stringify(p.accentBlocks))
  console.log('  [INFO] 对比抽样=' + JSON.stringify(p.contrast))
  console.log('  [INFO] 字阶=' + JSON.stringify(p.sizes) + ' 导航=' + p.navCount + ' ' + JSON.stringify(p.navLabels))

  // V-1 无 accent 大块（除按钮/球/状态点）
  check('V-1 无 >40×40 的 accent 空块', p.accentCount === 0,
    p.accentCount === 0 ? '0 块' : ('最大块 ' + JSON.stringify(p.accentBlocks[0])))

  // V-2 面板 alpha ≥ 0.96（实底，不依赖 backdrop-filter）
  check('V-2 面板实底 alpha ≥ 0.96', p.alpha >= 0.96, `alpha=${p.alpha} bg=${p.bg} backdrop=${p.backdrop || '(空)'}`)

  // V-3 字阶 ⊆ {11,12,13,14} 且 ≥4 档
  const ALLOW = ['11px', '12px', '13px', '14px']
  const bad = p.sizes.filter((s) => !ALLOW.includes(s))
  check('V-3 字阶 ⊆ {11,12,13,14} 且 ≥4 档', bad.length === 0 && p.sizes.length >= 4, `在用=${JSON.stringify(p.sizes)} 越界=${JSON.stringify(bad)}`)

  // V-4 导航 6 项且 label 唯一
  check('V-4 导航 6 项且 label 无重复', p.navCount === 6 && new Set(p.navLabels).size === 6, `count=${p.navCount} ${JSON.stringify(p.navLabels)}`)

  // V-5 当前页每个可见列表都有空态
  check('V-5 每个可见列表都有空态', p.visLists > 0 && p.withEmpty === p.visLists, `可见列表=${p.visLists} 带空态=${p.withEmpty}`)

  // V-6 默认态不露技术指标
  check('V-6 文本不含 ms/reasoner/rpm/降级/sk-/盘符', p.ban.ms === false && p.ban.words.length === 0 && p.ban.drive === false,
    `ms=${p.ban.ms} words=${JSON.stringify(p.ban.words)} drive=${p.ban.drive}`)

  // V-7 对比分层：抽查 5 处（title/body/meta/btn/empty）按角色比对
  const PRIMARY = 'rgb(231, 239, 242)'
  const SECOND = 'rgb(154, 167, 174)'
  const TERT = 'rgb(107, 119, 128)'
  const byRole = Object.fromEntries(p.contrast.map((x) => [x.role, x]))
  const titleOk = !!byRole.title && byRole.title.color === PRIMARY && byRole.title.fs === '14px'
  const bodyOk = !!byRole.body && byRole.body.color === SECOND
  const metaOk = !!byRole.meta && byRole.meta.color === TERT && byRole.meta.fs === '11px'
  const btnOk = !!byRole.btn && byRole.btn.color === PRIMARY
  const emptyOk = !!byRole.empty && byRole.empty.color === SECOND
  check('V-7 对比分层 5 处（title/body/meta/btn/empty 各归其位）',
    Object.keys(byRole).length >= 5 && titleOk && bodyOk && metaOk && btnOk && emptyOk,
    JSON.stringify(p.contrast.map((x) => x.role + '=' + x.color + '/' + x.fs)))

  // V-8 窗框 = 面板（S51 回退后 EXPANDED_FRAME=EXPANDED_SIZE，#panel inset:0 贴满窗口；
  //    旧公式「面板+96+16」是球+面板弹出时代的几何，已过时。outer 含 1~2px 边框，给 ±3 容差）
  const expectH = p.panel.h
  const diffH = Math.abs(p.frame.h - expectH)
  check('V-8 窗框 = 面板（±3）且 ≤ 工作区', diffH <= 3 && p.frame.h <= p.avail.h && p.frame.w <= p.avail.w,
    `frame=${p.frame.w}×${p.frame.h} 期望高=${expectH}(面板${p.panel.h}) 差=${diffH} 工作区=${p.avail.w}×${p.avail.h}`)
} catch (e) {
  const msg = String((e && e.message) || e)
  if (!['preflight', 'no-target'].includes(msg)) check('V-0 验收脚本异常', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  try { if (cdp) cdp.close() } catch { /* noop */ }
  killOwn()
  await sleep(1200)
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}

const total = items.length
const passed = items.filter((i) => i.ok).length
console.log(`  # accept-s48-visual: total=${total} pass=${passed} fail=${total - passed}`)
process.exitCode = total - passed === 0 ? 0 : 1
