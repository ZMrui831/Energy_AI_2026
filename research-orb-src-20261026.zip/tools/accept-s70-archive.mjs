// tools/accept-s70-archive.mjs —— S70·2A 归档与节律验收（北京时间切日 / 日目录 / 指令分级）
// 单行复跑：node tools\accept-s70-archive.mjs
import { mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { bjParts, dayDirName, sessionRelName, isArchivedDay, classifyMessageKind, summarizeArchive, archiveLine, instructionLine } from '../packages/core/src/session-rhythm.mjs'
import { scanSessions } from '../packages/core/src/session-index.mjs'

const items = []
const check = (id, ok, detail = '') => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300) }); console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's70-archive')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(WORK, { recursive: true })

// 固定时刻：2026-10-25 12:00 北京 = UTC 04:00
const NOW = Date.UTC(2026, 9, 25, 4, 0, 0)
const bj = (h, m, s = 0) => Date.UTC(2026, 9, 25, h - 8, m, s) // 北京 h:m → UTC
const sessLine = (title) => JSON.stringify({ type: 'session', id: 's', createdAt: new Date(NOW).toISOString(), title }) + '\n' + JSON.stringify({ type: 'user', text: 'hi' }) + '\n'

try {
  // ① 跨日切分：北京 23:59 vs 次日 00:01 → 不同日目录
  const d1 = bjParts(bj(23, 59)).yyyymmdd
  const d2 = bjParts(bj(23, 59, 0) + 2 * 60e3).yyyymmdd // +2 分钟 → 次日 00:01
  check('A-1 跨日切分：23:59 与次日 00:01 落到不同日目录', d1 === '20261025' && d2 === '20261026', `${d1} vs ${d2}`)

  // ② 时区正确：UTC 15:59 = 北京 23:59（同日）；UTC 16:00 = 北京次日 00:00
  const p1 = bjParts(Date.UTC(2026, 9, 25, 15, 59))
  const p2 = bjParts(Date.UTC(2026, 9, 25, 16, 0))
  check('A-2 时区正确（UTC 15:59=北京23:59 同 20261025；+1min=次日 20261026）', p1.yyyymmdd === '20261025' && p1.h === 23 && p1.mi === 59 && p2.yyyymmdd === '20261026' && p2.h === 0, `p1=${p1.yyyymmdd} ${p1.h}:${p1.mi} p2=${p2.yyyymmdd} ${p2.h}:${p2.mi}`)

  // ③ 归档语义：昨日=归档，今日=非归档；summarizeArchive 只计非今日
  const y = isArchivedDay('20261024', NOW), t = isArchivedDay('20261025', NOW)
  const sroot = join(WORK, 'sessions')
  mkdirSync(join(sroot, '20261024'), { recursive: true })
  writeFileSync(join(sroot, '20261024', 's-20261024-090000-aa.jsonl'), sessLine('昨日A'))
  mkdirSync(join(sroot, '20261025'), { recursive: true })
  writeFileSync(join(sroot, '20261025', 's-20261025-100000-bb.jsonl'), sessLine('今日B'))
  const sum = summarizeArchive(sroot, NOW)
  check('A-3 归档：昨日=已归档 今日=非归档 + 只统计非今日（1 会话 2 消息）', y === true && t === false && sum.archivedSessions === 1 && sum.archivedMsgs === 2 && sum.earliestDay === '20261024', JSON.stringify(sum))

  // ④ 日报两行：归档行 + 指令行
  mkdirSync(join(sroot, '20261025'), { recursive: true })
  writeFileSync(join(sroot, '20261025', 'instructions.jsonl'), JSON.stringify({ kind: 'instruction', text: 'a' }) + '\n' + JSON.stringify({ kind: 'instruction', text: 'b' }) + '\n' + JSON.stringify({ kind: 'instruction', text: 'c' }) + '\n')
  const aLine = archiveLine(sroot, NOW)
  const iLine = instructionLine(sroot, NOW)
  check('A-4 日报「归档」行（N 会话/M 消息/最早）与「指令」行（今日 3 条）', /今日归档 1 个会话（2 条消息），最早 2026-10-24/.test(aLine) && /今日 3 条指令/.test(iLine), `${aLine} ｜ ${iLine}`)

  // ⑤ 旧平铺兼容：根目录平铺 + 日目录文件都能被 scanSessions 读到
  writeFileSync(join(sroot, 's-legacy-20261001.jsonl'), sessLine('旧平铺'))
  const page = scanSessions({ dir: sroot, offset: 0, pageSize: 50 })
  const ids = page.items.map((x) => x.id)
  check('A-5 旧平铺兼容：根目录平铺 + 日目录会话合并可读（共 3 条）', page.ok && page.items.length === 3 && ids.includes('s-legacy-20261001') && ids.some((i) => i.startsWith('s-20261024')) && ids.includes('s-20261025-100000-bb'), `items=${page.items.length} ids=${ids.join(',')}`)

  // ⑥ instruction 分级 ≥4 例（3 instruction + 1 chat）
  const kinds = ['以后统一用 A 方案', '必须每天跑日报', '改成 B 格式', '今天天气不错'].map(classifyMessageKind)
  check('A-6 instruction 分级（3 instruction + 1 chat）', kinds[0] === 'instruction' && kinds[1] === 'instruction' && kinds[2] === 'instruction' && kinds[3] === 'chat', kinds.join(','))
} catch (e) {
  check('A-0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 300))
}

const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s70-archive: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(items.every((i) => i.ok) ? 0 : 1)
