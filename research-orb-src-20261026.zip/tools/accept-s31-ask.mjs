// tools/accept-s31-ask.mjs —— S31·A1 手动问询入口验收（≥8 项）。
// 单行复跑：node tools\accept-s31-ask.mjs
// 证据：data\logs\s31-ask-accept.json
//
// 覆盖：手动触发成功 / 上下文含最近 3 条轨迹 / 冷却抑制 / 冷却可配 /
//      未同意拒绝+审计 / 记忆 hints 进上下文 / 审计齐 / 真实 /coach ask 命令接线（denied 下返回 E_NO_CONSENT）。
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createRouter } from '../packages/core/src/router.mjs'
import { createExtractor } from '../packages/plugins/coach/extract.mjs'
import { createConfusionCoach, ASK_COOLDOWN_MS_DEFAULT } from '../packages/plugins/coach/confusion.mjs'
import { activate } from '../packages/plugins/coach/index.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 240), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's31-ask')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(join(WORK, 'coach'), { recursive: true })
const COACH_DIR = join(WORK, 'coach')
const usagePath = join(WORK, 'usage.jsonl')
const AUDIT = join(PROJECT_ROOT, 'data', 'logs', 'coach.jsonl')

let t = 1000000
const now = () => t

// 种子轨迹 5 条（最近 3 条应进上下文）
const seedRows = Array.from({ length: 5 }, (_, i) => JSON.stringify({
  ts: new Date(1000000 + i * 60000).toISOString(),
  window: '窗口' + i, process: 'proc' + i + '.exe', intent: '意图' + i, level: 'direct',
  evidence: { frameId: 'fr-seed' + i, textSha256: 'sha' + i },
}))
writeFileSync(join(COACH_DIR, 'trajectory.jsonl'), seedRows.join('\n') + '\n', 'utf8')

const IMG = join(WORK, 'frame.png')
writeFileSync(IMG, Buffer.from('ask frame body'))
// S67·3-C：extractor 按设计删原图，多步复用同一 IMG 会失败；每步给新副本
let _imgSeq = 0
const freshImg = () => { const p = join(WORK, `frame-${++_imgSeq}.png`); writeFileSync(p, Buffer.from('ask frame body')); return p }

function makeStubRouter() {
  return createRouter({
    providers: { cheap: { providerId: 'school-gateway', model: 'qwen' }, flagship: { providerId: 'deepseek-api', model: 'deepseek-chat' } },
    invoke: async ({ taskClass }) => {
      if (taskClass === 'extract') return { text: '屏幕文字：求解下垂控制参数始终发散（桩）' }
      return { text: '教练观察到你在调下垂控制参数。是参考模型的频带选得太宽，还是仿真步长不匹配？' }
    },
    usagePath, audit: () => {},
  })
}
const mk = (over = {}) => createConfusionCoach({
  dir: COACH_DIR, router: makeStubRouter(), now,
  extractor: createExtractor({ dir: COACH_DIR, router: makeStubRouter(), trashDir: join(WORK, 'trash'), ocr: () => ({ ok: true, text: '兜底文本' }) }),
  ...over,
})

try {
  const coach = mk()
  const auditStart = existsSync(AUDIT) ? readFileSync(AUDIT, 'utf8').length : 0

  // ① 主动 ask：成功 + 问询非空 + 含预期内容
  const r1 = await coach.ask({ imagePath: freshImg(), trigger: 'manual', window: '仿真窗口', process: 'Code.exe', consentActive: true })
  check('K1 /coach ask 主动触发成功且问询非空', r1.ok === true && String(r1.question).includes('下垂控制'))

  // ② 上下文含最近 3 条轨迹（seed4/3/2）
  check('K2 上下文含最近 3 条轨迹（seed 末尾 3 条）', r1.context.recentTrajectory === 3)

  // ③ 冷却期内不重复
  t += 60000
  const r2 = await coach.ask({ imagePath: freshImg(), trigger: 'manual', consentActive: true })
  check('K3 冷却期内不重复（cooledDown=true）', r2.cooledDown === true && r2.ok === false)

  // ④ 冷却可配（0 = 每次可问）
  const coachNoCd = mk({ cooldownMs: 0 })
  const a1 = await coachNoCd.ask({ imagePath: freshImg(), trigger: 'manual', consentActive: true })
  const a2 = await coachNoCd.ask({ imagePath: freshImg(), trigger: 'manual', consentActive: true })
  check('K4 冷却可配（0 分钟 → 连续两问都不冷却）', a1.ok === true && a2.ok === true)

  // ⑤ 未同意 → 跳过 + 审计 skipped-no-consent
  t += 60000
  const r4 = await coach.ask({ imagePath: freshImg(), trigger: 'manual', consentActive: false })
  const auditNow = readFileSync(AUDIT, 'utf8')
  check('K5 未同意感知 → 跳过且审计 skipped-no-consent', r4.skipped === true && auditNow.includes('skipped-no-consent'))

  // ⑥ 记忆 hints 进上下文（自动附到问询末尾）——需越过 30min 冷却
  t += ASK_COOLDOWN_MS_DEFAULT + 60000
  const r5 = await coach.ask({ imagePath: freshImg(), trigger: 'manual', consentActive: true, memoryHints: ['相关记忆：测试记忆XYZ'] })
  check('K6 记忆 hints 进入问询上下文（自动附相关记忆）', r5.ok === true && /测试记忆XYZ/.test(r5.question))

  // ⑦ 审计 coach-ask 行（trigger/frameId/llmOk/recentTrajectory 齐）——只验本测试运行新增的行
  const tail = readFileSync(AUDIT, 'utf8').slice(auditStart)
  const askRows = tail.split('\n').filter((l) => l.includes('"kind":"coach-ask"')).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
  check('K7 审计 coach-ask 行（trigger/frameId/llmOk/recentTrajectory 齐）', askRows.length >= 1 && askRows.some((r) => r.trigger && r.frameId && typeof r.llmOk === 'boolean'), 'askRows=' + askRows.length)

  // ⑧ 自动问询同路径（auto-dwell）仍可用——需越过冷却
  t += ASK_COOLDOWN_MS_DEFAULT + 60000
  const r6 = await coach.ask({ imagePath: freshImg(), trigger: 'auto-dwell', window: '仿真窗口', consentActive: true })
  check('K8 auto-dwell 同路径可用（与手动共用 confusion.ask）', r6.ok === true)
} catch (e) {
  check('K0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 240))
}

// ⑨ 集成：真实 /coach ask 命令接线 —— denied 感知下应返回 E_NO_CONSENT（验证命令存在 + 同意闸）
try {
  const commands = {}
  const mockCtx = {
    log: { info() {}, warn() {}, error() {} },
    ui: { registerCommand: (c) => { commands[c.name] = c }, registerCard() {}, notify() {} },
    net: null,
    core: { screen: { captureScreen: async () => ({ ok: true, pngPath: IMG }) } },
    globalShortcut: null,
  }
  const res = await activate(mockCtx)
  const askCmd = commands['coach']
  if (!askCmd) {
    check('K9 /coach ask 命令已注册（集成）', false, '未找到 coach 命令')
  } else {
    const out = await askCmd.run('ask')
    check('K9 /coach ask 命令接线 + 同意闸（denied→E_NO_CONSENT）', out && out.code === 'E_NO_CONSENT' && out.ok === false, 'code=' + (out && out.code))
  }
  if (res && typeof res.deactivate === 'function') { try { res.deactivate() } catch {} }
} catch (e) {
  check('K9 /coach ask 命令接线（集成）', false, String((e && e.stack) || e).slice(0, 240))
}

const pass = items.filter((i) => i.ok).length
const fail = items.length - pass
const out = { tool: 'accept-s31-ask', at: new Date().toISOString(), total: items.length, pass, fail, items }
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's31-ask-accept.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # accept-s31-ask: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 证据 -> data/logs/s31-ask-accept.json`)
process.exit(fail === 0 ? 0 : 1)
