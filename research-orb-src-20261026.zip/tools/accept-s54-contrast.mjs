// tools/accept-s54-contrast.mjs —— S55·C5 对比度兜底（≥3 项）
//
// 判据：正文 ≥ 4.5:1、元信息 ≥ 3:1、无近白亮块（亮度 > 0.92）。
// 做法：隔离实例读**真实计算值**（元素 computedStyle.color / backgroundColor），
// Node 侧用 WCAG 相对亮度公式换算 —— 不手估、不读源码字面量。
//
// 用法：node tools\accept-s54-contrast.mjs   （需应用退出；fail-closed；隔离数据目录）

import { mkdtempSync, rmSync, cpSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import { spawn, spawnSync } from 'node:child_process'
import {killMarked, countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-s54-contrast')

const ELECTRON = ORB_ELECTRON
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9345
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}
const countProcs = () => countOrbAll()
const killOwn = () => killMarked(MARK)

async function findTarget(t = 40000) {
  const d = Date.now() + t
  while (Date.now() < d) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const l = await r.json()
      const p = l.find((x) => x.type === 'page' && x.webSocketDebuggerUrl && /floating\.html/i.test(String(x.url || '')))
      if (p) return p
    } catch { /* 等 */ }
    await sleep(350)
  }
  return null
}
function cdpConnect(wsUrl) {
  const ws = new WebSocket(wsUrl)
  let seq = 0
  const pending = new Map()
  const ready = new Promise((res, rej) => { ws.addEventListener('open', () => res()); ws.addEventListener('error', () => rej(new Error('ws'))) })
  ws.addEventListener('message', (ev) => {
    let m = null
    try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
    if (!m || !m.id) return
    const p = pending.get(m.id); if (!p) return
    pending.delete(m.id)
    if (m.error) p.rej(new Error(JSON.stringify(m.error))); else p.res(m.result)
  })
  const send = (method, params) => new Promise((res, rej) => { const id = ++seq; pending.set(id, { res, rej }); ws.send(JSON.stringify({ id, method, params })) })
  return { ready, send, close: () => { try { ws.close() } catch { /* noop */ } } }
}
async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r && r.exceptionDetails) throw new Error('ev: ' + JSON.stringify(r.exceptionDetails).slice(0, 240))
  return r && r.result ? r.result.value : undefined
}

// ---------- WCAG 相对亮度与对比度 ----------
function parseColor(s) {
  if (!s) return null
  const t = String(s).trim()
  const hex = /^#([0-9a-f]{6})$/i.exec(t)
  if (hex) {
    const n = parseInt(hex[1], 16)
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
  }
  const m = /rgba?\(([^)]+)\)/.exec(t)
  if (!m) return null
  const p = m[1].split(',').map((x) => Number(x.trim()))
  if (p.length < 3 || p.some((x) => !Number.isFinite(x))) return null
  return [p[0], p[1], p[2]]
}
const lin = (c) => { const x = c / 255; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4) }
const relLum = ([r, g, b]) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)
function contrast(a, b) {
  const la = relLum(a), lb = relLum(b)
  const hi = Math.max(la, lb), lo = Math.min(la, lb)
  return (hi + 0.05) / (lo + 0.05)
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s54-contrast-'))
let child = null
let cdp = null
try {
  if (countProcs() > 0) { console.log('PREFLIGHT-FAIL: 已有实例在跑'); process.exit(2) }
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  delete env.ORB_LOG_DIR
  env.ORB_DATA_DIR = join(tmpRoot, 'data')
  try { cpSync(join(PROJECT_ROOT, 'data', 'themes'), join(env.ORB_DATA_DIR, 'themes'), { recursive: true }) } catch { /* 就算了 */ }
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], { cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] })
  const target = await findTarget()
  if (!target) { console.log('NO-TARGET'); process.exit(3) }
  cdp = cdpConnect(target.webSocketDebuggerUrl)
  await cdp.ready
  await cdp.send('Runtime.enable')
  let bridge = false
  const dl = Date.now() + 30000
  while (Date.now() < dl) {
    try { bridge = await ev(cdp, 'typeof globalThis.__s5 === "object" && typeof globalThis.researchOrb === "object"'); if (bridge) break } catch { /* 等 */ }
    await sleep(400)
  }
  if (!bridge) { console.log('NO-BRIDGE'); process.exit(3) }
  await ev(cdp, 'globalThis.researchOrb.send("window", { action: "expand" })')
  await sleep(2200)

  // 读真实计算值：正文 / 元信息 / 卡片底 + 亮块扫描
  const p = JSON.parse(await ev(cdp, `(() => {
    const lumOf = (bg) => {
      if (!bg) return null
      const m = /rgba?\\(([^)]+)\\)/.exec(bg)
      if (!m) return null
      const a = m[1].split(',').map((x) => Number(x.trim()))
      if (a.length >= 4 && a[3] === 0) return null
      return (0.299 * (a[0] || 0) + 0.587 * (a[1] || 0) + 0.114 * (a[2] || 0)) / 255
    }
    const pick = (sel) => {
      const el = document.querySelector(sel)
      if (!el) return null
      const cs = getComputedStyle(el)
      return { color: cs.color, bg: cs.backgroundColor, fs: cs.fontSize, text: (el.textContent || '').trim().slice(0, 24) }
    }
    const card = document.querySelector('#ro-percep-card')
    const bad = []
    for (const el of document.getElementById('panel').querySelectorAll('*')) {
      const cs = getComputedStyle(el)
      const L = lumOf(cs.backgroundColor)
      if (L === null || L <= 0.92) continue
      const r = el.getBoundingClientRect()
      if (r.width < 1 || r.height < 1 || cs.display === 'none' || cs.visibility === 'hidden') continue
      bad.push({ tag: el.tagName, id: el.id || '', cls: String(el.className || '').slice(0, 30), bg: cs.backgroundColor })
    }
    return JSON.stringify({
      body: pick('#ro-percep-card .ro-percep-v'),
      meta: pick('#ro-percep-card .ro-percep-sub .ro-percep-k'),
      title: pick('#ro-percep-card .ro-percep-title'),
      cardBg: card ? getComputedStyle(card).backgroundColor : null,
      panelBg: getComputedStyle(document.getElementById('panel')).backgroundColor,
      badCount: bad.length,
      bad: bad.slice(0, 4),
    })
  })()`))
  console.log('[采样] ' + JSON.stringify(p))

  const cardBg = parseColor(p.cardBg) || parseColor(p.panelBg)
  const cBody = p.body ? parseColor(p.body.color) : null
  const cMeta = p.meta ? parseColor(p.meta.color) : null
  const cTitle = p.title ? parseColor(p.title.color) : null

  // X-1 正文（感知卡数值行）≥ 4.5
  const rBody = cBody && cardBg ? contrast(cBody, cardBg) : 0
  check('X-1 正文对比度 ≥ 4.5:1（感知卡数值行 vs 卡片底）', rBody >= 4.5,
    `ratio=${rBody.toFixed(2)} color=${p.body && p.body.color} bg=${p.cardBg}`)

  // X-2 元信息（副标）≥ 3.0
  const rMeta = cMeta && cardBg ? contrast(cMeta, cardBg) : 0
  check('X-2 元信息对比度 ≥ 3:1（副标/小字 vs 卡片底）', rMeta >= 3,
    `ratio=${rMeta.toFixed(2)} color=${p.meta && p.meta.color} bg=${p.cardBg}`)

  // X-3 标题（正文加强）≥ 4.5
  const rTitle = cTitle && cardBg ? contrast(cTitle, cardBg) : 0
  check('X-3 标题对比度 ≥ 4.5:1', rTitle >= 4.5, `ratio=${rTitle.toFixed(2)} color=${p.title && p.title.color}`)

  // X-4 无近白亮块（与 E-15 同判据：亮度 > 0.92）
  check('X-4 面板内无近白亮块（亮度 ≤ 0.92）', p.badCount === 0, JSON.stringify({ badCount: p.badCount, bad: p.bad }))
} catch (e) {
  console.log('ACCEPT-ERROR: ' + String((e && e.stack) || e).slice(0, 400))
} finally {
  try { if (cdp) cdp.close() } catch { /* noop */ }
  killOwn()
  await sleep(1200)
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}
const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s54-contrast: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exitCode = items.length - pass === 0 ? 0 : 1
