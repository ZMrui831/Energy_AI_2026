// tools/diag-t1-occlusion.mjs —— T1 遮挡诊断（S53 修复后用户仍反馈"遮挡没被消除"）
//
// 纪律（血的教训）：computedStyle 证明不了"屏幕上谁挡谁"；"在 panel 里找"≠"在窗口里找"；
// 宿主自身的伪元素不在 querySelectorAll('*') 里。所以本脚本一律：
//   A. 窗口坐标 elementsFromPoint 命中栈（topmost 在前，逐项给 tag/id/class/bg/z/rect/文字长度）
//   B. 伪元素扫描（::before/::after，含 #panel/body/html 自身 —— querySelectorAll 扫不到它们）
//   C. 所有定位元素与 composer 条带的交集 + z-index 排序
//
// 用法：node tools\diag-t1-occlusion.mjs   （需应用退出；隔离数据目录，不碰真实 data）

import { mkdtempSync, rmSync, cpSync, existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import { spawn, spawnSync } from 'node:child_process'
import {killMarked, countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('diag-t1-occlusion')

const ELECTRON = ORB_ELECTRON
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9341
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const countProcs = () => countOrbAll()
const killOwn = () => killMarked(MARK)

async function findTarget(t = 40000) {
  const d = Date.now() + t
  while (Date.now() < d) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const l = await r.json()
      const p = l.find((x) => x.type === 'page' && x.webSocketDebuggerUrl && /floating\.html/i.test(String(x.url || '')))
      if (p) return p
    } catch { /* 等 */ }
    await sleep(350)
  }
  return null
}
function cdpConnect(wsUrl) {
  const ws = new WebSocket(wsUrl)
  let seq = 0
  const pending = new Map()
  const ready = new Promise((res, rej) => { ws.addEventListener('open', () => res()); ws.addEventListener('error', () => rej(new Error('ws'))) })
  ws.addEventListener('message', (ev) => {
    let m = null
    try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
    if (!m || !m.id) return
    const p = pending.get(m.id); if (!p) return
    pending.delete(m.id)
    if (m.error) p.rej(new Error(JSON.stringify(m.error))); else p.res(m.result)
  })
  const send = (method, params) => new Promise((res, rej) => { const id = ++seq; pending.set(id, { res, rej }); ws.send(JSON.stringify({ id, method, params })) })
  return { ready, send, close: () => { try { ws.close() } catch { /* noop */ } } }
}
async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r && r.exceptionDetails) throw new Error('ev: ' + JSON.stringify(r.exceptionDetails).slice(0, 300))
  return r && r.result ? r.result.value : undefined
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-t1-diag-'))
let child = null
let cdp = null
try {
  if (countProcs() > 0) { console.log('PREFLIGHT-FAIL: 已有 research-orb 实例在跑，退出（fail-closed，不杀用户进程）'); process.exit(2) }
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  delete env.ORB_LOG_DIR
  env.ORB_DATA_DIR = join(tmpRoot, 'data')
  // 关键（假绿教训）：隔离实例的临时数据目录里没有 themes\ → 应用回退到 vendor 默认亮色，
  // 而真实用户跑的是 teal（--input-bg=#d1fae5）。把项目真实 themes 复制进去，让应用自己注入。
  try { cpSync(join(PROJECT_ROOT, 'data', 'themes'), join(env.ORB_DATA_DIR, 'themes'), { recursive: true }) } catch { /* 无 themes 目录就算了 */ }
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], { cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] })
  const tail = []
  const push = (b) => { tail.push(String(b)); while (tail.length > 20) tail.shift() }
  if (child.stdout) child.stdout.on('data', push)
  if (child.stderr) child.stderr.on('data', push)

  const target = await findTarget()
  if (!target) { console.log('NO-TARGET: CDP 未就绪：' + tail.join('').slice(-300)); process.exit(3) }
  cdp = cdpConnect(target.webSocketDebuggerUrl)
  await cdp.ready
  await cdp.send('Runtime.enable')
  const dl = Date.now() + 30000
  let bridge = false
  while (Date.now() < dl) {
    try { bridge = await ev(cdp, 'typeof globalThis.__s5 === "object" && typeof globalThis.researchOrb === "object"'); if (bridge) break } catch { /* 等 */ }
    await sleep(400)
  }
  if (!bridge) { console.log('NO-BRIDGE: 30s 未就绪'); process.exit(3) }
  await ev(cdp, 'globalThis.researchOrb.send("window", { action: "expand" })')
  await sleep(1500)
  await ev(cdp, 'window.__s5.page("chat")')
  await sleep(1800)

  // ---------- 0. 环境与主题事实 ----------
  const env0 = JSON.parse(await ev(cdp, `(() => {
    const cs = getComputedStyle(document.getElementById('panel'))
    const body = document.body
    return JSON.stringify({
      win: [window.innerWidth, window.innerHeight],
      dpr: window.devicePixelRatio,
      bodyCls: body.className,
      theme: document.documentElement.getAttribute('data-ds-theme') || null,
      inputBg: cs.getPropertyValue('--input-bg').trim(),
      ballVar: cs.getPropertyValue('--ball').trim(),
      composerH: cs.getPropertyValue('--composer-height').trim(),
      dsChat: body.classList.contains('ds-chat'),
      page: window.__s5.currentPage(),
    })
  })()`))
  console.log('== 0. 环境 ==')
  console.log(JSON.stringify(env0, null, 1))

  // ---------- A. 分区命中栈：标题行 / composer 条带 / 内容带 ----------
  const diagA = JSON.parse(await ev(cdp, `(() => {
    const strip = document.getElementById('composer').getBoundingClientRect()
    const prompt = document.getElementById('prompt').getBoundingClientRect()
    const OWN = new Set(['composer','prompt','composer-input-row','mic-btn','voice-btn','wake-btn','voiceprint-btn','memory-btn','input-label'])
    const owned = (el) => el && (OWN.has(el.id) || (el.closest && !!el.closest('#composer')))
    const desc = (el) => {
      const cs = getComputedStyle(el)
      const r = el.getBoundingClientRect()
      return { tag: el.tagName, id: el.id || null, cls: (el.className && el.className.baseVal !== undefined ? '' : String(el.className || '')).slice(0, 36),
        bg: cs.backgroundColor, op: cs.opacity, z: cs.zIndex,
        rect: [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)],
        text: (el.textContent || '').trim().length }
    }
    const probe = (x, y, okFn) => {
      const stack = document.elementsFromPoint(x, y)
      if (!stack || !stack.length) return { x, y, err: 'empty' }
      let firstForeign = -1
      for (let i = 0; i < stack.length; i++) { if (!okFn(stack[i])) { firstForeign = i; break } }
      return { x, y, firstForeign: firstForeign < 0 ? null : firstForeign, top: desc(stack[0]),
        foreign: firstForeign >= 0 ? desc(stack[firstForeign]) : null }
    }
    // 合法占位者：导航（左缘）、球与顶栏（标题行）、面板本身（最底）
    const okCommon = (el) => el && (el.id === 'panel' || el.id === 'ro-ds-nav' || el.id === 'ball' ||
      el.id === 'ro-s5-topbar' || (el.closest && (el.closest('#ro-ds-nav') || el.closest('#ro-s5-topbar') || el.closest('#ball'))))
    const inStrip = (el) => owned(el) || okCommon(el)
    const pts = []
    const W = window.innerWidth, H = window.innerHeight
    // R1 标题行（y 10..52，跳过导航区 x<48）
    for (const y of [14, 26, 38, 50]) for (const x of [52, 90, 150, 220, 300, 360, 390, 404]) pts.push({ r: 'R1标题行', ...probe(Math.round(x), Math.round(y), okCommon) })
    // R2 composer 条带内部（按条带百分比取点）
    for (const fy of [0.1, 0.3, 0.5, 0.7, 0.9]) for (const fx of [0.03, 0.08, 0.15, 0.3, 0.5, 0.7, 0.88, 0.97]) {
      const x = Math.round(strip.left + strip.width * fx), y = Math.round(strip.top + strip.height * fy)
      pts.push({ r: 'R2输入条', ...probe(x, y, inStrip) })
    }
    // R3 prompt 左缘（导航覆盖嫌疑区：prompt.left .. prompt.left+20）
    for (const fy of [0.2, 0.5, 0.8]) for (const dx of [1, 4, 8, 12, 16, 20]) {
      const x = Math.round(prompt.left + dx), y = Math.round(prompt.top + prompt.height * fy)
      pts.push({ r: 'R3 prompt左缘', ...probe(x, y, inStrip) })
    }
    // R4 内容带（y 60..540）
    for (const y of [70, 150, 300, 450, 525]) for (const x of [70, 200, 390]) pts.push({ r: 'R4内容带', ...probe(Math.round(x), Math.round(y), okCommon) })
    return JSON.stringify({
      strip: [Math.round(strip.left), Math.round(strip.top), Math.round(strip.width), Math.round(strip.height)],
      prompt: [Math.round(prompt.left), Math.round(prompt.top), Math.round(prompt.width), Math.round(prompt.height)],
      W, H, pts,
    })
  })()`))
  console.log('\\n== A. 分区命中栈（窗口 ' + diagA.W + '×' + diagA.H + '，composer=' + JSON.stringify(diagA.strip) + '，prompt=' + JSON.stringify(diagA.prompt) + '）==')
  for (const p of diagA.pts) {
    const bad = p.firstForeign === 0
    console.log((bad ? '  [遮挡] ' : '  [ok]   ') + p.r + ` (${p.x},${p.y}) top=${p.top.tag}${p.top.id ? '#' + p.top.id : ''}${p.top.cls ? '.' + p.top.cls.split(' ')[0] : ''} bg=${p.top.bg} z=${p.top.z}` +
      (p.foreign ? ` | 外来层#${p.firstForeign}=${p.foreign.tag}${p.foreign.id ? '#' + p.foreign.id : ''} rect=${JSON.stringify(p.foreign.rect)} text=${p.foreign.text}` : ''))
  }
  const badPts = diagA.pts.filter((p) => p.firstForeign === 0)
  console.log('  → 被外来层压住的点数: ' + badPts.length + '/' + diagA.pts.length)
  const badByRegion = {}
  for (const p of badPts) badByRegion[p.r] = (badByRegion[p.r] || 0) + 1
  console.log('  → 按区域: ' + JSON.stringify(badByRegion))

  // ---------- B. 伪元素扫描（含 querySelectorAll 扫不到的宿主自身） ----------
  const diagB = JSON.parse(await ev(cdp, `(() => {
    const out = []
    const hosts = Array.from(document.querySelectorAll('*'))
    for (const h of [document.documentElement, document.body, document.getElementById('panel')]) if (h && !hosts.includes(h)) hosts.push(h)
    for (const host of hosts) {
      for (const pseudo of ['::before', '::after']) {
        let cs = null
        try { cs = getComputedStyle(host, pseudo) } catch { continue }
        if (!cs) continue
        const content = cs.content
        if (content === 'none' || content === 'normal') continue
        if (cs.display === 'none') continue
        const bg = cs.backgroundColor
        const hasText = content !== '""' && content !== "''" && content.length > 2
        if (bg === 'rgba(0, 0, 0, 0)' && !hasText) continue
        const r = host.getBoundingClientRect()
        out.push({ host: host.tagName + (host.id ? '#' + host.id : '') + (host.className && typeof host.className === 'string' ? '.' + host.className.split(' ')[0] : ''),
          pseudo, content: content.slice(0, 30), display: cs.display, position: cs.position, bg,
          w: cs.width, h: cs.height, z: cs.zIndex, hasText: !!hasText,
          hostRect: [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)] })
      }
    }
    return JSON.stringify(out)
  })()`))
  console.log('\\n== B. 可见伪元素（content!=none 且有底色或文字）==')
  for (const p of diagB) console.log('  ' + JSON.stringify(p))
  if (!diagB.length) console.log('  （无）')

  // ---------- C. 与 composer 条带相交的定位元素（按 z-index 排序） ----------
  const diagC = JSON.parse(await ev(cdp, `(() => {
    const strip = document.getElementById('composer').getBoundingClientRect()
    const out = []
    for (const el of document.querySelectorAll('*')) {
      const cs = getComputedStyle(el)
      if (cs.position === 'static' || cs.display === 'none' || cs.visibility === 'hidden') continue
      const r = el.getBoundingClientRect()
      if (r.width === 0 || r.height === 0) continue
      const hit = !(r.right < strip.left || r.left > strip.right || r.bottom < strip.top || r.top > strip.bottom)
      if (!hit) continue
      out.push({ tag: el.tagName, id: el.id || null, cls: typeof el.className === 'string' ? el.className.slice(0, 40) : '',
        pos: cs.position, z: cs.zIndex, bg: cs.backgroundColor, op: cs.opacity,
        rect: [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)],
        text: (el.textContent || '').trim().slice(0, 40) })
    }
    out.sort((a, b) => (Number(b.z) || 0) - (Number(a.z) || 0))
    return JSON.stringify(out)
  })()`))
  console.log('\\n== C. 与 composer 条带相交的定位元素（z 降序）==')
  for (const e of diagC) console.log('  ' + JSON.stringify(e))
  if (!diagC.length) console.log('  （无）')

  // ---------- D. 关键元素计算态（验证 S53 修复是否真生效） ----------
  const diagD = JSON.parse(await ev(cdp, `(() => {
    const g = (id) => { const e = document.getElementById(id); if (!e) return null; const cs = getComputedStyle(e); const r = e.getBoundingClientRect()
      return { display: cs.display, bg: cs.backgroundColor, z: cs.zIndex, pos: cs.position, rect: [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)] } }
    const pa = getComputedStyle(document.getElementById('panel'), '::after')
    return JSON.stringify({
      foot: g('ro-ds-foot'), panelAfter: { display: pa.display, bg: pa.backgroundColor, h: pa.height, content: pa.content },
      transcript: g('transcript'), status: g('status'), ball: g('ball'), stop: g('stop'),
      selChip: g('selection-chip'), nav: g('ro-ds-nav'), roS5: g('ro-s5'), topbar: g('ro-s5-topbar'),
    })
  })()`))
  console.log('\\n== D. 关键元素计算态 ==')
  console.log(JSON.stringify(diagD, null, 1))

  // ---------- E. 滚动条宽度（"滚动条压字"投诉的量化） ----------
  const diagE = JSON.parse(await ev(cdp, `(() => {
    const out = {}
    const probe = (id) => {
      const e = document.getElementById(id) || document.querySelector(id)
      if (!e) return null
      const cs = getComputedStyle(e)
      return { sw: e.offsetWidth - e.clientWidth, sh: e.offsetHeight - e.clientHeight,
        ovY: cs.overflowY, scrollH: e.scrollHeight, clientH: e.clientHeight,
        scrollable: e.scrollHeight > e.clientHeight + 1 }
    }
    for (const id of ['transcript', 'prompt', 'ro-s5', 's5-home']) out[id] = probe(id)
    const page = document.querySelector('.s5-page.s5-on')
    out['s5-page.on'] = page ? { cls: page.className, ...probe(page) } : null
    return JSON.stringify(out)
  })()`))
  console.log('\\n== E. 滚动条（sw/sh = 布局宽高 - 客户区宽高，即滚动条占用 px）==')
  console.log(JSON.stringify(diagE, null, 1))

  // ---------- F. 首页态：顶栏/页面滚动/底栏/三钮颜色/askCard 定位 ----------
  await ev(cdp, 'window.__s5.page("home")')
  await sleep(1200)
  const diagF = JSON.parse(await ev(cdp, `(() => {
    const g = (sel) => { const e = document.querySelector(sel); if (!e) return null
      const cs = getComputedStyle(e); const r = e.getBoundingClientRect()
      return { display: cs.display, pos: cs.position, bg: cs.backgroundColor, z: cs.zIndex,
        bottom: cs.bottom, rect: [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)] } }
    const page = document.querySelector('.s5-page.s5-on')
    const inflow = []
    for (const el of document.getElementById('panel').children) {
      const cs = getComputedStyle(el)
      if (cs.display === 'none' || cs.position === 'absolute' || cs.position === 'fixed') continue
      const r = el.getBoundingClientRect()
      inflow.push({ id: el.id || el.tagName, h: Math.round(r.height), top: Math.round(r.top), text: (el.textContent || '').trim().slice(0, 30) })
    }
    return JSON.stringify({
      page: window.__s5.currentPage(),
      dsChat: document.body.classList.contains('ds-chat'),
      inflow,
      topbar: g('#ro-s5-topbar'), home: g('#s5-home'), foot: g('#ro-ds-foot'),
      music: g('#ro-music-btn'), newConv: g('#new-conversation'), history: g('#history'),
      ask: g('#s5-ask'), roS5: g('#ro-s5'),
      homeScroll: page ? { scrollH: page.scrollHeight, clientH: page.clientHeight, ovY: getComputedStyle(page).overflowY } : null,
      // 首页底栏上方必须留出内容空间：foot.top 与 home 内容底部不得重叠
      footClear: (() => { const f = document.getElementById('ro-ds-foot').getBoundingClientRect()
        const p = document.querySelector('.s5-page.s5-on')
        return p ? Math.round(f.top - (p.getBoundingClientRect().top + p.scrollHeight)) : null })(),
    })
  })()`))
  console.log('\\n== F. 首页态 ==')
  console.log(JSON.stringify(diagF, null, 1))

  // ---------- G. 6px 偏移溯源：panel padding 与 status 计量 ----------
  const diagG = JSON.parse(await ev(cdp, `(() => {
    const p = document.getElementById('panel')
    const pc = getComputedStyle(p)
    const s = document.getElementById('status')
    const sc = getComputedStyle(s)
    const t = document.getElementById('ro-s5-topbar')
    const tc = getComputedStyle(t)
    return JSON.stringify({
      panelPad: [pc.paddingTop, pc.paddingBottom, pc.paddingLeft], panelBorder: pc.borderTopWidth,
      status: { mt: sc.marginTop, mb: sc.marginBottom, h: sc.height, display: sc.display, vis: sc.visibility, ov: sc.overflow, pos: sc.position },
      topbar: { mt: tc.marginTop, h: tc.height, display: tc.display },
      panelRect: (() => { const r = p.getBoundingClientRect(); return [Math.round(r.top), Math.round(r.height)] })(),
    })
  })()`))
  console.log('\\n== G. 6px 偏移溯源 ==')
  console.log(JSON.stringify(diagG, null, 1))
} catch (e) {
  console.log('DIAG-ERROR: ' + String((e && e.stack) || e).slice(0, 500))
  process.exitCode = 1
} finally {
  try { if (cdp) cdp.close() } catch { /* noop */ }
  killOwn()
  await sleep(1200)
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}
