// tools/accept-s74-dev-seed.mjs —— S74·1-A dev 接口种子化验收（起隔离应用 → dev-agent CLI）
// 单行复跑：node tools\accept-s74-dev-seed.mjs   （含真实 GLM：两轮 bench，约 6-10 分钟）
import { spawn, spawnSync } from 'node:child_process'
import { appendFileSync, cpSync, existsSync, mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-s74-dev-seed')

const ELECTRON = ORB_ELECTRON
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9343
const CLI = join(PROJECT_ROOT, 'tools', 'dev-agent.mjs')
const BUILTIN_SUITE = join(PROJECT_ROOT, 'tests', 'bench', 'vision-basic.json')

const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300) })
  console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`)
  try { if (!ok) appendFileSync(join(PROJECT_ROOT, 'data', 'tmp', 's74-debug.log'), '【' + id + '】' + String(detail).slice(0, 300) + '\n【CLI 完整输出】' + _lastCli + '\n\n') } catch { /* noop */ }
}

const countProcs = () => countOrbAll()

let child = null
let tmpRoot = null
let DEV_ENV = null
let _lastCli = ''
const runCli = (args, timeout = 420000) => {
  const r = spawnSync(process.execPath, [CLI, '--port=' + PORT, ...args], { cwd: PROJECT_ROOT, encoding: 'utf8', timeout, env: DEV_ENV })
  let json = null
  try { json = JSON.parse(String(r.stdout || '').trim()) } catch { /* 非 JSON */ }
  _lastCli = 'stdout=' + String(r.stdout || '').slice(0, 400) + ' ｜stderr=' + String(r.stderr || '').slice(0, 200)
  return { json, stdout: String(r.stdout || ''), status: r.status }
}

try {
  if (countProcs() > 0) { check('A-0 预检', false, '已有 research-orb 实例在跑'); throw new Error('preflight') }
  if (!existsSync(BUILTIN_SUITE)) { check('A-0 预检', false, '内置 suite 缺失：' + BUILTIN_SUITE); throw new Error('suite') }
  tmpRoot = mkdtempSync(join(tmpdir(), 's74-seed-'))
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  delete env.ORB_LOG_DIR
  env.ORB_DATA_DIR = join(tmpRoot, 'data') // **全新数据目录**：prompts 目录不存在 → 靠 prompt 子命令自动 seed
  try { cpSync(join(PROJECT_ROOT, 'data', 'themes'), join(env.ORB_DATA_DIR, 'themes'), { recursive: true }) } catch { /* noop */ }
  for (const f of ['providers.json', 'vision-context.json']) { try { cpSync(join(PROJECT_ROOT, 'data', f), join(env.ORB_DATA_DIR, f)) } catch { /* noop */ } }
  DEV_ENV = env
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], { cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] })
  child.stdout.resume(); child.stderr.resume()

  // 等应用起来 + 桥注入
  const http = await import('node:http')
  let page = null
  const dl0 = Date.now() + 90000
  while (Date.now() < dl0 && !page) {
    try {
      const list = await new Promise((res, rej) => { http.default.get(`http://127.0.0.1:${PORT}/json/list`, (r) => { let b = ''; r.on('data', (c) => { b += c }); r.on('end', () => { try { res(JSON.parse(b)) } catch (e) { rej(e) } }) }).on('error', rej) })
      page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl) || null
    } catch { /* 未起 → 等 */ }
    if (!page) await sleep(800)
  }
  if (!page) { check('A-0 启动', false, '90s 内 CDP 未就绪'); throw new Error('no-cdp') }
  const appLogPath = join(DEV_ENV.ORB_DATA_DIR, 'logs', 'app.jsonl')
  const dl1 = Date.now() + 45000
  let bridgeReady = false
  while (Date.now() < dl1 && !bridgeReady) {
    try { if (existsSync(appLogPath) && readFileSync(appLogPath, 'utf8').includes('bridge-injected')) bridgeReady = true } catch { /* noop */ }
    if (!bridgeReady) await sleep(800)
  }
  if (!bridgeReady) { check('A-0 启动', false, '45s 内桥未注入'); throw new Error('no-bridge') }
  await sleep(1500)

  const promptsDir = join(DEV_ENV.ORB_DATA_DIR, 'prompts')
  const idxPath = join(promptsDir, 'index.json')

  // ① 全新数据目录：prompt get 自动 seed 且 history 有 v1
  const g = runCli(['prompt', 'get', '--kind', 'vision'])
  const h = runCli(['prompt', 'history', '--kind', 'vision'])
  const seededFiles = ['vision-v1.txt', 'recall-v1.txt', 'chat-v1.txt', 'context-v1.json'].filter((f) => existsSync(join(promptsDir, f)))
  check('A-1 全新目录 prompt get 自动 seed（4 个 v1 文件 + index.json）且 history 有 v1',
    g.json && g.json.ok === true && seededFiles.length === 4 && existsSync(idxPath)
    && h.json && h.json.ok === true && Array.isArray(h.json.versions) && h.json.versions.some((v) => v.id === 'vision-v1') && h.json.active === 'vision-v1',
    `seeded=${seededFiles.length}/4 active=${h.json && h.json.active} versions=${h.json && h.json.versions ? h.json.versions.map((v) => v.id).join(',') : '-'}`)
  check('A-1b v1 内容与代码常量逐字一致（seed==常量 sha256）',
    g.json && g.json.ok === true && g.json.chars === 607 && /research-orb 自身面板/.test(String(g.json.content)), `chars=${g.json && g.json.chars}`)

  // ② rollback --id v1 可用（即使没做过 set）
  const rb = runCli(['prompt', 'rollback', '--id', 'v1'])
  const g2 = runCli(['prompt', 'get', '--kind', 'vision'])
  check('A-2 rollback --id v1 成功且内容复原', rb.json && rb.json.ok === true && rb.json.to === 'vision-v1' && g2.json && g2.json.ok === true && g2.json.content === g.json.content, `to=${rb.json && rb.json.to} chars=${g2.json && g2.json.chars}`)

  // ③ seed 幂等（用**未被 set 过**的 kind：连跑两次 v1 文件 mtime/size 不变、versions 仍 1 条）
  const g4a = runCli(['prompt', 'get', '--kind', 'recall'])
  const rf = join(promptsDir, 'recall-v1.txt')
  const sig0 = statSync(rf).mtimeMs + ':' + statSync(rf).size
  const g4b = runCli(['prompt', 'get', '--kind', 'recall'])
  const h4 = runCli(['prompt', 'history', '--kind', 'recall'])
  const sig1 = statSync(rf).mtimeMs + ':' + statSync(rf).size
  check('A-4 seed 幂等：连跑两次不覆盖 v1（mtime/size 不变、versions 仍 1 条）',
    g4a.json && g4a.json.ok === true && g4b.json && g4b.json.content === g4a.json.content && sig0 === sig1
    && h4.json && h4.json.versions.length === 1 && h4.json.active === 'recall-v1',
    `sigSame=${sig0 === sig1} versions=${h4.json && h4.json.versions.length} active=${h4.json && h4.json.active}`)

  // ④ diff 非空（先 set --apply 造一个不同的 active，再 diff v1 → active）
  const pA = join(tmpRoot, 'promptA.txt')
  writeFileSync(pA, 'S74 测试提示词 A：第一行\n第二行\n')
  const sA = runCli(['prompt', 'set', '--kind', 'vision', '--file', pA, '--apply'])
  const df = runCli(['prompt', 'diff', '--kind', 'vision', '--from', 'v1', '--to', 'active'])
  const dfOk = df.json && df.json.ok === true && df.json.identical === false && String(df.json.diff || '').length > 40 && df.json.from === 'vision-v1'
  check('A-3 diff --from v1 --to active 输出非空统一 diff', dfOk, `from=${df.json && df.json.from} to=${df.json && df.json.to} added=${df.json && df.json.added} removed=${df.json && df.json.removed} identical=${df.json && df.json.identical}`)

  // ⑤ 主管可直接跑：bench（无 --suite）→ 内置 vision-basic.json
  const b0 = runCli(['bench'], 480000)
  const b0Ok = b0.json && b0.json.ok === true && b0.json.total === 10 && Number.isFinite(b0.json.passRate) && /vision-basic\.json$/.test(String(b0.json.suite || ''))
  check('A-5 bench（不带 --suite）直接跑内置套件（10 例，给 passRate）', b0Ok,
    `suite=${b0.json && b0.json.suite} passRate=${b0.json && b0.json.passRate} tools=${b0.json && b0.json.tools ? b0.json.tools.join('|') : '-'}`)
  const summary0 = b0.json && b0.json.results ? b0.json.results.map((r) => `${r.id}:${r.pass ? 'P' : 'F'}(${r.tool})`).join(' ') : ''
  console.log('   [bench-default] ' + summary0)

  // ⑥ 显式 --suite 路径也可运行
  const b1 = runCli(['bench', '--suite', BUILTIN_SUITE, '--repeat', '1'], 480000)
  const b1Ok = b1.json && b1.json.ok === true && b1.json.total === 10 && Number.isFinite(b1.json.passRate)
  check('A-6 bench --suite <绝对路径> 可运行并给 passRate', b1Ok, `passRate=${b1.json && b1.json.passRate}`)
  const summary1 = b1.json && b1.json.results ? b1.json.results.map((r) => `${r.id}:${r.pass ? 'P' : 'F'}(${r.tool})`).join(' ') : ''
  console.log('   [bench-explicit] ' + summary1)
  try { writeFileSync(join(PROJECT_ROOT, 'data', 'tmp', 's74-bench-last.json'), JSON.stringify(b1.json || b0.json, null, 2)) } catch { /* noop */ }
} catch (e) {
  check('A-0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  try { if (child) { child.kill(); await sleep(1500) } } catch { /* noop */ }
  try { if (tmpRoot) rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}

const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s74-dev-seed: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(items.every((i) => i.ok) ? 0 : 1)

function sleep(ms) { return new Promise((r) => setTimeout(r, ms)) }
