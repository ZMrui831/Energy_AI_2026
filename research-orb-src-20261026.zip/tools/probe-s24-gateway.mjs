// tools/probe-s24-gateway.mjs —— S24-0 探针：只验证，零产品改动。
// Q1 网关连通（GET /models）｜Q2 qwen 视觉（POST chat/completions，1 张缩图）｜Q3 WinRT OCR｜Q4 白名单核对
// 纪律：网络请求共 2 个（≤6 上限）；密钥运行时直读 ~/.claude/settings.json 的 env（ORB_SJTU_API_KEY
//       未设置时的既有 school-gateway 路径），值不打印、不写任何文件/日志；证据 data/logs/s24-probe.json。
// 单行复跑：node tools\probe-s24-gateway.mjs
import { spawnSync } from 'node:child_process'
import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const BASE = 'https://models.sjtu.edu.cn/api/v1'
const OUT = join(PROJECT_ROOT, 'data', 'logs', 's24-probe.json')
const TMP = join(PROJECT_ROOT, 'data', 'tmp', 's24')
const SHOT = join(PROJECT_ROOT, 'data', 'shots', 'capture-2026-10-22T07-02-06-999Z.png')

const out = {
  at: new Date().toISOString(),
  keySource: null,
  gw: { ok: false, status: null, models: [] },
  vision: { ok: null, evidence: null, httpStatus: null },
  ocr: { ok: false, text200: '', engine: null },
  allowlist: { present: false, path: 'packages/core/src/domains.json', domain: 'models.sjtu.edu.cn' },
  memory: { shape: null, entry: null, notes: [] },
}

function readToken() {
  // ORB_SJTU_API_KEY 若在进程 env 则优先（本片前提）；否则走 school-gateway 既有路径：
  // config.mjs 的 school-gateway authToken 就来自 ~/.claude/settings.json 的 env（运行时直读）。
  if (process.env.ORB_SJTU_API_KEY) return { token: process.env.ORB_SJTU_API_KEY, source: 'env ORB_SJTU_API_KEY' }
  try {
    const doc = JSON.parse(readFileSync(`${process.env.USERPROFILE}//.claude/settings.json`, 'utf8'))
    const t = doc && doc.env && doc.env.ANTHROPIC_AUTH_TOKEN
    if (t) return { token: String(t), source: '~/.claude/settings.json env.ANTHROPIC_AUTH_TOKEN（config.mjs school-gateway 既有读取路径，运行时直读，未落盘未打印）' }
  } catch { /* 忽略 */ }
  return { token: null, source: null }
}

function smallImage() {
  // 640 宽缩图（子进程 powershell System.Drawing，不在本进程加载 .NET）
  if (!existsSync(SHOT)) return null
  mkdirSync(TMP, { recursive: true })
  const dst = join(TMP, 'vision-probe.png')
  const script = [
    'Add-Type -AssemblyName System.Drawing;',
    `$i=[System.Drawing.Image]::FromFile('${SHOT.replace(/\\/g, '\\\\')}');`,
    '$w=640;$h=[int]($i.Height*$w/$i.Width);',
    '$b=New-Object System.Drawing.Bitmap $w,$h;',
    '$g=[System.Drawing.Graphics]::FromImage($b);$g.InterpolationMode="HighQualityBicubic";',
    '$g.DrawImage($i,0,0,$w,$h);',
    `$b.Save('${dst.replace(/\\/g, '\\\\')}',[System.Drawing.Imaging.ImageFormat]::Png);`,
    '$g.Dispose();$b.Dispose();$i.Dispose();',
  ].join(' ')
  const r = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { timeout: 30000, encoding: 'utf8' })
  return existsSync(dst) ? dst : null
}

// ---- Q3：WinRT Windows.Media.Ocr（零依赖，子进程 powershell） ----
function runOcr(imagePath) {
  // 注意：绝对路径内联进脚本串会被宿主脱敏层替换成 UNABLE_TO_MASK_PATH，改走环境变量传参。
  const script = `
$ErrorActionPreference='Stop'
$imagePath = $env:S24_IMG
try {
  [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  [Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime] | Out-Null
  [Windows.Graphics.Imaging.BitmapDecoder,Windows.Foundation,ContentType=WindowsRuntime] | Out-Null
  [Windows.Storage.StorageFile,Windows.Foundation,ContentType=WindowsRuntime] | Out-Null
  [Windows.Globalization.Language,Windows.Foundation,ContentType=WindowsRuntime] | Out-Null
  $m = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation\`1' })[0]
  function Await($op, $t) { $task = $m.MakeGenericMethod($t).Invoke($null, @($op)); $task.Wait(); $task.Result }
  $avail = ([Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages | ForEach-Object { $_.LanguageTag }) -join ','
  $engine = 'UserProfileLanguages'
  $ocr = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
  if (-not $ocr -and $avail -ne '') {
    $first = ($avail.Split(',')[0] | ForEach-Object { $_.Trim() }) -join ''
    $ocr = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage((New-Object Windows.Globalization.Language($first)))
    $engine = 'first-of:' + $first
  }
  if (-not $ocr) { Write-Output ('JSON:' + (@{ ok=$false; engine=('none; avail=' + $avail); text='' } | ConvertTo-Json -Compress)); exit 0 }
  try {
    $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($imagePath)) ([Windows.Storage.StorageFile])
  } catch { Write-Output ('JSON:' + (@{ ok=$false; engine=('step:GetFile ' + $_.Exception.GetBaseException().Message); text='' } | ConvertTo-Json -Compress)); exit 0 }
  try {
    $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
    $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $bmp = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
  } catch { Write-Output ('JSON:' + (@{ ok=$false; engine=('step:decode ' + $_.Exception.GetBaseException().Message); text='' } | ConvertTo-Json -Compress)); exit 0 }
  try {
    $res = Await ($ocr.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
  } catch { Write-Output ('JSON:' + (@{ ok=$false; engine=('step:recognize ' + $_.Exception.GetBaseException().Message); text='' } | ConvertTo-Json -Compress)); exit 0 }
  $obj = @{ ok = $true; engine = $engine + ' maxDim=' + $ocr.MaxImageDimension; text = $res.Text }
  Write-Output ('JSON:' + ($obj | ConvertTo-Json -Compress))
} catch {
  $msg = $_.Exception.Message
  Write-Output ('JSON:' + (@{ ok=$false; engine=$null; text=''; err=$msg } | ConvertTo-Json -Compress))
}
`
  const r = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { timeout: 60000, encoding: 'utf8', env: { ...process.env, S24_IMG: imagePath } })
  const line = (r.stdout || '').split('\n').find((l) => l.startsWith('JSON:'))
  if (!line) return { ok: false, engine: null, text: '', err: ((r.stderr || '') + (r.stdout || '')).slice(0, 240) }
  try { return JSON.parse(line.slice(5)) } catch { return { ok: false, engine: null, text: line.slice(5, 205) } }
}

async function main() {
  const ocrOnly = process.argv.includes('--ocr-only')
  if (ocrOnly) {
    // 只补跑 Q3（零网络），合并进既有证据
    const prev = existsSync(OUT) ? JSON.parse(readFileSync(OUT, 'utf8')) : {}
    const o = runOcr(SHOT)
    prev.ocr = { ok: !!o.ok, text200: String(o.text || '').replace(/\s+/g, ' ').slice(0, 200), engine: o.engine || null, err: o.err || undefined }
    writeFileSync(OUT, JSON.stringify(prev, null, 2), 'utf8')
    console.log('[Q3-retry] ok=' + prev.ocr.ok + ' engine=' + prev.ocr.engine + ' text=' + prev.ocr.text200.slice(0, 100))
    return
  }
  const { token, source } = readToken()
  out.keySource = source ? source + '；另：进程/用户/机器级 ORB_SJTU_API_KEY 均未设置' : '无可用密钥来源；ORB_SJTU_API_KEY 未设置'

  const headers = { Authorization: 'Bearer ' + (token || 'MISSING') }

  // ---- Q1 连通性：GET /models（1 个请求） ----
  try {
    const res = await fetch(BASE + '/models', { headers, signal: AbortSignal.timeout(20000) })
    out.gw.status = res.status
    const text = await res.text()
    if (res.ok) {
      try {
        const doc = JSON.parse(text)
        const list = Array.isArray(doc.data) ? doc.data.map((m) => m.id).filter(Boolean) : []
        out.gw.models = list
        out.gw.ok = true
      } catch { out.gw.models = ['(非 JSON: ' + text.slice(0, 120) + ')'] }
    } else {
      out.gw.models = ['HTTP ' + res.status + ': ' + text.slice(0, 160)]
    }
  } catch (e) {
    out.gw.status = 'NETWORK_ERROR'
    out.gw.models = [String((e && e.message) || e).slice(0, 160) + (e && e.cause ? ' / ' + String(e.cause.message || e.cause).slice(0, 80) : '')]
  }
  console.log('[Q1] status=' + out.gw.status + ' models=' + JSON.stringify(out.gw.models).slice(0, 300))

  // ---- Q2 视觉：POST chat/completions（1 个请求） ----
  if (out.gw.ok) {
    const img = smallImage()
    if (img) {
      const b64 = readFileSync(img).toString('base64')
      const body = {
        model: 'qwen',
        messages: [{
          role: 'user',
          content: [
            { type: 'image_url', image_url: { url: 'data:image/png;base64,' + b64 } },
            { type: 'text', text: '请用一两句话描述这张截图里有什么（窗口标题或主要文字即可）。' },
          ],
        }],
        max_tokens: 200,
      }
      try {
        const res = await fetch(BASE + '/chat/completions', {
          method: 'POST', headers: { ...headers, 'Content-Type': 'application/json' },
          body: JSON.stringify(body), signal: AbortSignal.timeout(60000),
        })
        const text = await res.text()
        out.vision.httpStatus = res.status
        out.vision.evidence = text.slice(0, 2048) // 原样保存，截断 2KB
        if (res.ok) {
          try {
            const doc = JSON.parse(text)
            const answer = doc.choices && doc.choices[0] && doc.choices[0].message && (doc.choices[0].message.content || '')
            // 视觉判定：答案里出现对截图内容的描述性词（不是"我看不到图/无法处理图片"类）
            const negative = /无法|不能|看不到|不支持|as a text|cannot see|no image/i.test(String(answer))
            out.vision.ok = !negative && String(answer).length > 10
            out.vision.answer = String(answer).slice(0, 300)
          } catch { out.vision.ok = false }
        } else {
          // 400/422 且错误提到 content/type/vision → 纯文本模型
          out.vision.ok = false
          out.vision.diagnosis = /content|type|vision|image|multimodal/i.test(text) ? '错误提到 image/content/vision → 判定：qwen 该调用名此协议下为纯文本' : 'HTTP ' + res.status
        }
      } catch (e) {
        out.vision.ok = false
        out.vision.evidence = 'NETWORK_ERROR ' + String((e && e.message) || e).slice(0, 200)
      }
    } else {
      out.vision.evidence = '无可用截图（未消耗请求）'
    }
  } else {
    out.vision.evidence = '网关未连通（Q1 失败），未消耗视觉请求'
  }
  console.log('[Q2] httpStatus=' + out.vision.httpStatus + ' ok=' + out.vision.ok + ' answer=' + String(out.vision.answer || '').slice(0, 120))

  // ---- Q3 OCR（零网络） ----
  if (existsSync(SHOT)) {
    const o = runOcr(SHOT)
    out.ocr = { ok: !!o.ok, text200: String(o.text || '').replace(/\s+/g, ' ').slice(0, 200), engine: o.engine || null, err: o.err || undefined }
  } else {
    out.ocr = { ok: false, text200: '', engine: null, err: '截图不存在' }
  }
  console.log('[Q3] ocr ok=' + out.ocr.ok + ' engine=' + out.ocr.engine + ' text=' + out.ocr.text200.slice(0, 80))

  // ---- 白名单核对（只读，不擅自改） ----
  try {
    const d = JSON.parse(readFileSync(join(PROJECT_ROOT, 'packages', 'core', 'src', 'domains.json'), 'utf8'))
    const list = (Array.isArray(d.allowedDomains) ? d.allowedDomains : []).map((x) => String(x).toLowerCase())
    out.allowlist.present = list.includes('models.sjtu.edu.cn')
    out.allowlist.total = list.length
  } catch { out.allowlist.present = false }
  console.log('[白名单] models.sjtu.edu.cn 在 packages/core/src/domains.json: ' + out.allowlist.present + '（共 ' + (out.allowlist.total || '?') + ' 域，未做任何修改）')

  writeFileSync(OUT, JSON.stringify(out, null, 2), 'utf8')
  console.log('[证据] ' + OUT)
}

main().catch((e) => { console.error('FATAL', (e && e.message) || e); process.exit(1) })
