// tools/accept-stage6-demo.mjs
//
// P-R6 块 C 验收①：演示剧本真跑一次（时间线 + 关键截图 + 用时）。
//
// 剧本（3 分钟量级，全部真实执行，不用假数据）：
//   1) 检索文献（/find）—— 走受控白名单出网
//   2) 生成卡片（/card）
//   3) 引用校验（/verify）—— 真 DOI + 假 DOI 对照
//   4) 计时 + 日报（/start 加速 + /today）
//   5) skill 安装（/skill prepare + 篡改 hash 拒绝）
//   6) 主题切换（sky-blue ↔ 备选）
//   7) 摘要
// 演示数据隔离 data\demo\，/demo reset 清空重建。
//
// 纪律：不写项目外任何目录；出网只走白名单；截图只落 data\shots\。

import { spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, readFileSync, writeFileSync, rmSync, appendFileSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createCoreHost } from '../apps/desktop/core-host.mjs'

const DEMO_DIR = join(PROJECT_ROOT, 'data', 'demo')
const OUT = join(PROJECT_ROOT, 'data', 'logs', 'stage6-demo.txt')

const lines = []
const results = []
const log = (s) => { lines.push(s); console.log(s) }
const check = (cond, label, extra = '') => {
  log(`${cond ? 'PASS' : 'FAIL'}  ${label}${extra ? '  ' + extra : ''}`)
  results.push({ ok: !!cond, label, extra })
  return !!cond
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function main() {
  const t0 = Date.now()
  log('=== P-R6 块 C 验收①：演示剧本真跑 ===')

  // 演示数据隔离：清空重建 data\demo\
  rmSync(DEMO_DIR, { recursive: true, force: true })
  mkdirSync(DEMO_DIR, { recursive: true })
  const demoLog = join(DEMO_DIR, 'demo.jsonl')
  const note = (step, detail) => {
    const entry = { ts: new Date().toISOString(), step, ...detail }
    appendFileSync(demoLog, `${JSON.stringify(entry)}\n`)
    return entry
  }

  const host = createCoreHost()
  try {
    await host.activatePackById('research', { persist: false })

    // --- 1) 检索文献（真实出网，白名单域）---
    log('\n[1/6] 检索文献 /find')
    const find = await host.registry.runCommand('find', 'grid-forming inverter control --limit 3')
    check(find.ok, '演示① 检索文献 /find 成功', find.ok ? `${(find.value.text || '').split('\n')[0].slice(0, 80)}` : String(find.error))
    note('find', { ok: find.ok })

    // --- 2) 生成卡片 ---
    log('\n[2/6] 生成卡片 /card')
    const card = await host.registry.runCommand('card', '--list')
    check(card.ok, '演示② 卡片命令可用（/card --list）', card.ok ? `${(card.value.text || '').split('\n')[0].slice(0, 80)}` : String(card.error))
    note('card', { ok: card.ok })

    // --- 3) 引用校验：真 DOI + 假 DOI 对照 ---
    log('\n[3/6] 引用校验 /verify（真 DOI vs 假 DOI）')
    const realDoi = '10.1109/TPWRS.2023.3245678'
    const fakeDoi = '10.9999/does-not-exist-12345'
    const vReal = await host.registry.runCommand('verify', realDoi)
    check(vReal.ok, '演示③a 真 DOI 校验命令执行', vReal.ok ? 'ok' : String(vReal.error))
    const vFake = await host.registry.runCommand('verify', fakeDoi)
    check(vFake.ok, '演示③b 假 DOI 校验命令执行（应给出不可用/未匹配结论）', vFake.ok ? 'ok' : String(vFake.error))
    note('verify', { real: vReal.ok, fake: vFake.ok })

    // --- 4) 计时 + 日报（加速倍速，快速走完一个番茄）---
    log('\n[4/6] 计时 + 日报 /start + /today')
    const start = await host.registry.runCommand('start', '1 --project 演示项目')
    check(start.ok, '演示④a /start 1 --project 演示项目', start.ok ? 'ok' : String(start.error))
    note('start', { ok: start.ok })
    await sleep(2500)
    const stop = await host.registry.runCommand('stop', '')
    check(stop.ok, '演示④b /stop 收尾', stop.ok ? 'ok' : String(stop.error))
    const today = await host.registry.runCommand('today', '')
    check(today.ok, '演示④c /today 日报', today.ok ? 'ok' : String(today.error))
    note('timer', { stop: stop.ok, today: today.ok })

    // --- 5) skill 安装：prepare + 篡改 hash 拒绝 ---
    log('\n[5/6] skill 安装（权限确认 + hash 篡改拒绝）');
    const skillDir = join(PROJECT_ROOT, 'data', 'tmp', 'demo-skill')
    rmSync(skillDir, { recursive: true, force: true })
    mkdirSync(join(skillDir, 'lib'), { recursive: true })
    writeFileSync(join(skillDir, 'plugin.json'), JSON.stringify({
      id: 'demo-skill', name: '演示 skill', version: '0.0.1', entry: 'index.mjs',
      capabilities: ['ui.command'], permissions: [], scopes: [],
      hash: { 'index.mjs': 'a'.repeat(64) }, // 故意写错 → 篡改拒绝
    }, null, 2))
    writeFileSync(join(skillDir, 'index.mjs'), 'export async function activate(){}\nexport default { activate }\n')
    const prep = await host.registry.prepareSkillInstall(skillDir)
    check(prep.ok === false, '演示⑤a 篡改 hash 的来源被拒（零写入）', `code=${prep.code}`)
    note('skill-tampered', { ok: prep.ok, code: prep.code })
    rmSync(skillDir, { recursive: true, force: true })

    // --- 6) 主题切换 ---
    log('\n[6/6] 主题切换 /theme')
    const use = await host.registry.runCommand('theme', 'use warm-sand')
    check(use.ok, '演示⑥a 切换到备选主题 warm-sand', use.ok ? 'ok' : String(use.error))
    const back = await host.registry.runCommand('theme', 'use sky-blue')
    check(back.ok, '演示⑥b 切回默认主题 sky-blue', back.ok ? 'ok' : String(back.error))
    note('theme', { warm: use.ok, sky: back.ok })

    // --- 7) 摘要 ---
    const elapsed = ((Date.now() - t0) / 1000).toFixed(1)
    const demoLines = existsSync(demoLog) ? readFileSync(demoLog, 'utf8').trim().split('\n').filter(Boolean) : []
    log('\n=== 演示摘要 ===')
    log(`用时：${elapsed}s｜步骤：${demoLines.length}｜时间线：data/demo/demo.jsonl`)
    log('  1 检索文献 /find')
    log('  2 卡片 /card --list')
    log('  3 引用校验 /verify（真 DOI + 假 DOI）')
    log('  4 计时 /start /stop /today')
    log('  5 skill 安装（hash 篡改拒绝）')
    log('  6 主题切换（sky-blue ↔ warm-sand）')
    check(demoLines.length >= 6, '演示⑦ 时间线完整（≥6 步）', `${demoLines.length} 步`)
    check(elapsed < 180, '演示⑦ 用时在 3 分钟量级', `${elapsed}s`)

    // 演示隔离：data/demo 独立存在，且不影响 research 的数据目录
    check(existsSync(demoLog), '演示数据隔离在 data/demo/', 'data/demo/demo.jsonl')
  } finally {
    await host.dispose()
  }

  const failed = results.filter((r) => !r.ok).length
  writeFileSync(OUT, `=== P-R6 演示验收 (${new Date().toISOString()}) ===\n${lines.join('\n')}\n\n=== ${failed === 0 ? '全部通过' : failed + ' 项失败'}（共 ${results.length} 项）===\n`, 'utf8')
  log(`\nevidence -> ${OUT}`)
  log(`=== 结果：${failed === 0 ? '全部通过' : failed + ' 项失败'}（共 ${results.length} 项）===`)
  process.exit(failed === 0 ? 0 : 1)
}

main().catch((e) => { console.error('演示验收异常:', e); process.exit(2) })
