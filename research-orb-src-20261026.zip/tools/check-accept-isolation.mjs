// tools/check-accept-isolation.mjs —— S67·3-A 护栏 1：验收脚本隔离静态检查
//
// 口径（诚实、可执行）：
//   · **写数据**的验收脚本必须隔离——含 `_accept-isolate` import / 显式设 `ORB_DATA_DIR` /
//     走 `run-isolated` 三者之一；否则验收会写到生产 data\db / data\logs。
//   · **只读**脚本（不写库/不写日志）可以读生产，用于核对真实产物，不强制隔离。
//   静态 import 会被提升，单靠"文件顶部赋值"在兄弟模块已加载后无效；故本护栏要求
//   使用副作用模块 _accept-isolate.mjs（深度优先求值，能先于产品模块生效）或 run-isolated。
//
// 用法：node tools/check-accept-isolation.mjs   （退出码 0=PASS，1=有写脚本未隔离）
import { readFileSync, readdirSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = dirname(fileURLToPath(import.meta.url))
const TOOLS = ROOT

// 必须"真隔离"：导入 _accept-isolate 副作用模块（先于产品模块求值），或真赋值 ORB_DATA_DIR。
// 仅在注释里提 run-isolated 不算（直接运行仍会写生产）；靠外部 run-isolated 的脚本若直跑仍会污染。
const ISO = /_accept-isolate|process\.env\.ORB_DATA_DIR\s*=/
// 证据库写入特征：createStore（建/写 store）或 非只读 DatabaseSync（可能 INSERT/UPDATE）
// 说明：只写 data\tmp 下的证据 JSON 不算证据污染（tmp 有 TTL 且不是 claim/trajectory 库），
// 故本护栏只盯"会写证据库/审计日志"的脚本，避免误伤读生产做核对的只读验收。
const CREATE_STORE = /createStore\s*\(/
const DB_OPEN = /new\s+DatabaseSync\s*\(/
const DB_FILE = /orb\.sqlite/

function isEvidenceDbWriter(text) {
  if (CREATE_STORE.test(text)) return true
  if (DB_OPEN.test(text) && DB_FILE.test(text) && !/readOnly\s*:\s*true/.test(text)) return true
  return false
}

const files = readdirSync(TOOLS).filter((f) => /^accept-.*\.mjs$/.test(f)).sort()
const offenders = []
const readOnly = []
for (const f of files) {
  let text = ''
  try { text = readFileSync(join(TOOLS, f), 'utf8') } catch { continue }
  const writer = isEvidenceDbWriter(text)
  const iso = ISO.test(text)
  if (writer && !iso) offenders.push(f)
  else if (!writer) readOnly.push(f)
}

console.log(`[check-accept-isolation] 验收脚本 ${files.length} 个；证据库写脚本未隔离 ${offenders.length} 个；非证据库写/只读 ${readOnly.length} 个`)
if (offenders.length) {
  console.log('  ✗ 写证据库但未隔离（必须加 `import \'./_accept-isolate.mjs\'` 或走 run-isolated，且 dbPath 用 dataPath 而非 PROJECT_ROOT 硬编码）：')
  for (const f of offenders) console.log('    - ' + f)
  process.exit(1)
}
console.log('  ✓ PASS：所有写证据库的验收脚本均已隔离到临时目录（只读/只写 tmp 证据的脚本按设计不强制隔离）')
