// tools/accept-s23-verify-preprint.mjs —— S23·C1 预印本行内标记 [预印本] 验收（离线，零网络）。
// 单行复跑：node tools\accept-s23-verify-preprint.mjs
// 证据落 data\logs\s23-verify-preprint.json。
import { mkdirSync, writeFileSync, appendFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, logPath } from '../packages/core/src/safefs.mjs'
import { parsePreprint, tagPreprint, renderPreprintNotice, PREPRINT_TAG, PREPRINT_DOI_PREFIXES } from '../packages/plugins/research-literature/connectors/preprint.mjs'

const items = []
const check = (id, ok, detail, evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

try {
  // ① 各信号源（离线元数据，不联网）
  console.log('# ① 预印本信号解析（Crossref/OpenAlex/arXiv/DOI 前缀/URL 主机）')
  const cr = parsePreprint({ crossrefMessage: { type: 'posted-content', title: ['A study'] } })
  check('V1 Crossref type=posted-content → 预印本', cr.preprint === true && cr.source === 'crossref', JSON.stringify(cr.signals))

  const oa = parsePreprint({ openalexWork: { type: 'preprint' } })
  check('V2 OpenAlex type=preprint → 预印本', oa.preprint === true && oa.source === 'openalex', JSON.stringify(oa.signals))

  const ax = parsePreprint({ arxivEntry: { id: '2401.12345' } })
  check('V3 arXiv 条目 → 预印本（arXiv 本身即预印本平台）', ax.preprint === true && ax.source === 'arxiv', JSON.stringify(ax.signals))

  const dp = parsePreprint({ doi: '10.48550/arXiv.2401.12345' })
  check('V4 arXiv DOI 前缀 10.48550 → 预印本', dp.preprint === true && dp.source === 'doi-prefix', JSON.stringify(dp.signals))

  const uh = parsePreprint({ url: 'https://arxiv.org/abs/2401.12345' })
  check('V5 URL 主机 arxiv.org → 预印本', uh.preprint === true && uh.source === 'url-host', JSON.stringify(uh.signals))

  // ② 非预印本：期刊文章 + 普通 DOI → 不标记
  console.log('# ② 非预印本不误标')
  const jr = parsePreprint({ crossrefMessage: { type: 'journal-article' }, doi: '10.1016/j.apenergy.2024.01.001', url: 'https://doi.org/10.1016/j.apenergy.2024.01.001' })
  check('V6 期刊文章 + Elsevier DOI → 不标记', jr.preprint === false, JSON.stringify(jr.signals))
  check('V7 行内标记为空串（不污染正常引用）', tagPreprint(jr) === '', `tag="${tagPreprint(jr)}"`)

  // ③ 行内标记与提示文案
  console.log('# ③ 行内标记 [预印本] 与保守口径提示')
  check('V8 tagPreprint → [预印本]', tagPreprint(cr) === '[预印本]' && PREPRINT_TAG === '预印本', tagPreprint(cr))
  const notice = renderPreprintNotice(cr)
  check('V9 提示含"预印本/未经…同行评审终稿/版本与检索时间"口径', /预印本/.test(notice) && /同行评审终稿/.test(notice) && /版本与检索时间/.test(notice), notice.split('\n')[0])
  check('V10 非预印本提示为空（不输出多余段落）', renderPreprintNotice(jr) === '')

  // ④ DOI 前缀表完整（5 个已知预印本平台）
  check('V11 DOI 前缀表含 5 个已知预印本平台', PREPRINT_DOI_PREFIXES.length === 5 && PREPRINT_DOI_PREFIXES.includes('10.1101') && PREPRINT_DOI_PREFIXES.includes('10.21203'), PREPRINT_DOI_PREFIXES.join(','))

  // ⑤ 端到端：/verify meta 的行内标记出口（走 verifyMeta 同一段判定组合逻辑的等价路径）
  console.log('# ④ /verify meta 出口的判定组合（元数据信号 ∪ ref 证据）')
  // 与 index.mjs verifyMeta 相同的组合：connector 信号 ∪ assessment.isPreprint（ref 含 arxiv.org）
  const refLikeArxiv = 'https://arxiv.org/abs/1706.03762'
  const combined = parsePreprint({ url: refLikeArxiv, doi: null })
  check('V12 verify-meta 组合判定：URL 含 arxiv.org → 报告行内出现 [预印本]', combined.preprint === true && `[${PREPRINT_TAG}]` === tagPreprint(combined), tagPreprint(combined))

  // 审计留痕（与 kb.jsonl 同风格，落 verify 侧日志）
  try {
    appendFileSync(logPath('kb.jsonl'), JSON.stringify({ ts: new Date().toISOString(), kind: 's23-verify-preprint', tagged: items.filter((i) => i.ok).length }) + '\n')
  } catch { /* 审计尽力 */ }
} catch (e) {
  check('V0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 300))
}

const pass = items.filter((i) => i.ok).length
const fail = items.length - pass
const out = {
  tool: 'accept-s23-verify-preprint',
  at: new Date().toISOString(),
  rerun: 'node tools\\accept-s23-verify-preprint.mjs',
  total: items.length, pass, fail, items,
}
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's23-verify-preprint.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # accept-s23-verify-preprint: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 复跑：node tools\\accept-s23-verify-preprint.mjs`)
console.log(`  # 证据 -> data/logs/s23-verify-preprint.json`)
process.exit(fail === 0 ? 0 : 1)
