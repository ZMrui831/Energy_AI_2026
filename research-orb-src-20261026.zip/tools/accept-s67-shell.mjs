// tools/accept-s67-shell.mjs
//
// S67·1-A 验收：shell.run 元字符 / 明文禁用首词 / git 子命令降级。
// 既有 tools-shell.test.mjs 已覆盖闸门，这里用**真实注册链路 + 假 child** 复验：
// 拒采命令绝不能派生进程；放行命令才派生。

import { EventEmitter } from 'node:events'
import { createToolRegistry, defineTool } from '../packages/core/src/tools/registry.mjs'
import { registerShellTools, classifyCommand } from '../packages/core/src/tools/impl/shell.mjs'
import { createPathResolver } from '../packages/core/src/tools/paths.mjs'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

let pass = 0
let fail = 0
const fails = []
function check(name, cond, detail = '') {
  if (cond) {
    pass += 1
    console.log(`[PASS] ${name}`)
  } else {
    fail += 1
    fails.push(name + (detail ? ' —— ' + detail : ''))
    console.log(`[FAIL] ${name}${detail ? ' —— ' + detail : ''}`)
  }
}

function fakeChild() {
  const calls = []
  return {
    calls,
    spawn(cmd, args, opts) {
      calls.push({ cmd, args, opts })
      const proc = new EventEmitter()
      proc.pid = 4242
      proc.stdout = new EventEmitter()
      proc.stderr = new EventEmitter()
      proc.kill = () => true
      setImmediate(() => {
        proc.stdout.emit('data', Buffer.from('OK', 'utf8'))
        proc.emit('close', 0)
      })
      return proc
    },
    spawnSync(cmd, args) {
      calls.push({ cmd, args, sync: true })
      return { status: 0, stdout: '', stderr: '' }
    },
  }
}

const paths = createPathResolver({ root: PROJECT_ROOT, home: process.env.USERPROFILE, env: { USERPROFILE: process.env.USERPROFILE }, desktopReader: () => 'D:\\Desktop' })
const ctx = { paths, signal: null, emit: () => {}, toolId: 'shell.run' }
function build(child) {
  const reg = createToolRegistry()
  registerShellTools(reg, { child, roots: [PROJECT_ROOT, 'D:\\Desktop'] })
  return reg
}

// 1) 纯函数：元字符整体拒绝
check('1-A-1 元字符 & 被拒 E_SHELL_METACHAR', classifyCommand('echo hi & del important.txt').code === 'E_SHELL_METACHAR')
check('1-A-2 元字符 | 被拒', classifyCommand('dir | findstr x').code === 'E_SHELL_METACHAR')
check('1-A-3 重定向 > 被拒', classifyCommand('echo hi > a.txt').code === 'E_SHELL_METACHAR')

// 4) 明文禁用首词（无参数也拒）
check('1-A-4 裸 del 无参数也拒 E_CMD_BANNED', classifyCommand('del foo.txt').code === 'E_CMD_BANNED')
check('1-A-5 裸 rd 无参数也拒', classifyCommand('rd build').code === 'E_CMD_BANNED')

// 6) git 子命令降级
check('1-A-6 git push 拒 E_CMD_BANNED', classifyCommand('git push origin main').code === 'E_CMD_BANNED')
check('1-A-7 git status 放行', classifyCommand('git status').ok === true)

// 8) 集成：拒采命令**绝不派生进程**
{
  const child = fakeChild()
  const reg = build(child)
  let threw = false
  try {
    await reg.get('shell.run').run({ command: 'echo hi & del x' }, ctx)
  } catch (e) {
    threw = e.code === 'E_SHELL_METACHAR'
  }
  check('1-A-8 元字符命令被拒且不派生进程', threw && child.calls.length === 0, `calls=${child.calls.length}`)
}

// 9) 集成：放行命令正常派生
{
  const child = fakeChild()
  const reg = build(child)
  const r = await reg.get('shell.run').run({ command: 'echo hello' }, ctx)
  check('1-A-9 白名单命令执行且派生进程', r.ok === true && child.calls.length === 1, `calls=${child.calls.length}`)
}

console.log(`\n[accept-s67-shell] ${pass} 通过 / ${fail} 失败`)
if (fail > 0) {
  console.log('失败项：\n - ' + fails.join('\n - '))
  process.exit(1)
}
process.exit(0)
