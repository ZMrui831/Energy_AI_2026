// tools/accept-s47-app-isolation.mjs —— S47·P0 应用级数据隔离验收（10 项，要求 ≥8）。
//
// 单行复跑：node tools\accept-s47-app-isolation.mjs
//
// 为什么必须真启动：P0 的 bug 是"应用本体不跟随 ORB_DATA_DIR"——只有把真 Electron 拉起来，
// 才能证明 db / .chromium / logs 三处都挪进临时目录、而真实 data\ 全程一个字节没动。
//
// 纪律：
//   · fail-closed：已有 research-orb electron 在跑就退出，绝不杀用户正在用的实例；
//   · 只杀自己起的（按命令行含 research-orb 过滤，且退出前复查残留=0）；
//   · 反向验证走**零写入**路径（只读打开真实库），避免为了证明"没改坏"而把真实 data 写一遍。

import { existsSync, mkdtempSync, readdirSync, readFileSync, rmSync, statSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {dirname, join, relative, resolve} from 'node:path'
import { spawn, spawnSync } from 'node:child_process'
import {killMarked, countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-s47-app-isolation')

const ELECTRON = ORB_ELECTRON
const PYTHON = `${process.env.USERPROFILE}\\.workbuddy\\binaries\\python\\versions\\3.13.12\\python.exe`
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const REAL_DATA = join(PROJECT_ROOT, 'data')
const REAL_DB = join(REAL_DATA, 'db', 'orb.sqlite')
const PORT = 9333
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 320) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}

// ---------------------------------------------------------------- 快照与差异
function snap(root) {
  const m = new Map()
  const walk = (d) => {
    let ents = []
    try {
      ents = readdirSync(d, { withFileTypes: true })
    } catch {
      return
    }
    for (const e of ents) {
      const p = join(d, e.name)
      if (e.isDirectory()) walk(p)
      else if (e.isFile()) {
        try {
          const st = statSync(p)
          m.set(relative(root, p), st.size + '|' + Math.round(st.mtimeMs))
        } catch {
          /* 忽略瞬时消失的文件 */
        }
      }
    }
  }
  walk(root)
  return m
}
function diffSnap(a, b) {
  const added = []
  const changed = []
  const removed = []
  for (const [k, v] of b) {
    if (!a.has(k)) added.push(k)
    else if (a.get(k) !== v) changed.push(k)
  }
  for (const k of a.keys()) if (!b.has(k)) removed.push(k)
  return { added, changed, removed }
}

// ---------------------------------------------------------------- sqlite 只读查询
function sqliteCount(dbPath, table) {
  // URI 必须用 pathlib.as_uri()（file:///D:/...），手拼 "file:D:/..." 会被当成相对路径 →
  // "unable to open database file"（已踩过一次）。WAL 库只读打开可能需要 immutable 兜底，
  // 两种都试，并把实际读取模式如实返回。
  const code = String.raw`
import sqlite3, json, pathlib
p = r"${dbPath}"
table = "${table}"
out = {"ok": False, "error": "not attempted"}
for suffix in ["?mode=ro", "?mode=ro&immutable=1"]:
    try:
        uri = pathlib.Path(p).as_uri() + suffix
        con = sqlite3.connect(uri, uri=True)
        n = con.execute('SELECT count(*) FROM "' + table + '"').fetchone()[0]
        tables = [r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        out = {"ok": True, "count": n, "tables": tables, "mode": suffix}
        con.close()
        break
    except Exception as e:
        out = {"ok": False, "error": type(e).__name__ + ": " + str(e), "mode": suffix}
print(json.dumps(out))
`
  const r = spawnSync(PYTHON, ['-c', code], { encoding: 'utf8', timeout: 20000, windowsHide: true })
  const last = String(r.stdout || '').trim().split('\n').filter(Boolean).pop() || '{}'
  try {
    return JSON.parse(last)
  } catch {
    return { ok: false, error: 'bad json: ' + last.slice(0, 120) }
  }
}

// ---------------------------------------------------------------- 进程
function countProcs() { return countOrbAll() }
function killOwn() { return killMarked(MARK) }

// ---------------------------------------------------------------- 启动与等待
function launch(dataDir) {
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  delete env.ORB_LOG_DIR
  if (dataDir) env.ORB_DATA_DIR = dataDir
  else delete env.ORB_DATA_DIR
  const child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], {
    cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'],
  })
  const tail = []
  const push = (b) => {
    tail.push(String(b))
    while (tail.length > 40) tail.shift()
  }
  if (child.stdout) child.stdout.on('data', push)
  if (child.stderr) child.stderr.on('data', push)
  child.__tail = () => tail.join('').slice(-1200)
  return child
}

async function waitCdp(timeoutMs = 40000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await res.json()
      if (Array.isArray(list) && list.some((t) => t.type === 'page' && /floating\.html/i.test(String(t.url || '')))) return true
    } catch {
      /* 还没起来 */
    }
    await sleep(400)
  }
  return false
}

// ---------------------------------------------------------------- 主流程
const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-ui-look-'))
const tmpData = join(tmpRoot, 'data')

try {
  const pre = countProcs()
  if (pre > 0) {
    check('I-0 预检（已有 research-orb 实例在跑则退出，不杀用户进程）', false, `已存在 ${pre} 个实例；请先关闭再复跑`)
    throw new Error('preflight-instance-running')
  }

  // S48·P0（断言自伤修复，方案 A：先读后拍）：
  // sqlite 以 mode=ro 打开 WAL 库**仍会触碰 -shm**（shared memory 的 mtime 会变）。
  // 原来顺序是 snap() → sqliteCount()，于是 after 快照必然看到 -shm 变化 —— 自己把自己判红。
  // 现在把"读真实库"全部挪到快照之前，基线本身就包含这次触碰。
  const realClaims = sqliteCount(REAL_DB, 'claim')
  const before = snap(REAL_DATA)
  console.log(`  [INFO] 真实库 claim=${realClaims.ok ? realClaims.count : JSON.stringify(realClaims)}  真实 data 文件数=${before.size}`)

  // ---- 第一次隔离启动
  const child = launch(tmpData)
  const up1 = await waitCdp()
  check('I-1 以 ORB_DATA_DIR=<temp> 启动真应用（CDP 出现 floating.html）', up1 === true, up1 ? `数据目录=${tmpData.replace(tmpRoot, '<tmp>')}` : `未起来；stderr 尾部：${(child.__tail && child.__tail()) || '无'}`)

  const tmpDb = join(tmpData, 'db', 'orb.sqlite')
  check('I-2 临时目录出现 db/orb.sqlite', existsSync(tmpDb), `存在=${existsSync(tmpDb)} size=${existsSync(tmpDb) ? statSync(tmpDb).size : 0}`)

  const tmpChromium = join(tmpData, '.chromium')
  let chromiumEntries = 0
  try {
    chromiumEntries = readdirSync(tmpChromium).length
  } catch {
    chromiumEntries = 0
  }
  check('I-3 临时目录出现 .chromium（Chromium userData 跟随）', existsSync(tmpChromium) && chromiumEntries > 0, `存在=${existsSync(tmpChromium)} 条目=${chromiumEntries}`)

  const tmpLogs = join(tmpData, 'logs', 'app.jsonl')
  check('I-4 LOG_DIR 一并跟随（未单独设 ORB_LOG_DIR，日志落在 <temp>/data/logs）', existsSync(tmpLogs) && statSync(tmpLogs).size > 0, `app.jsonl 存在=${existsSync(tmpLogs)} size=${existsSync(tmpLogs) ? statSync(tmpLogs).size : 0}`)

  const tmpClaims = sqliteCount(tmpDb, 'claim')
  check(
    'I-5 查询返回 0 条（临时库 claim=0，对照真实库 >0）',
    tmpClaims.ok === true && tmpClaims.count === 0 && realClaims.ok === true && realClaims.count > 0,
    `临时=${tmpClaims.ok ? tmpClaims.count : JSON.stringify(tmpClaims)} 真实=${realClaims.ok ? realClaims.count : '?'} 表=${(tmpClaims.tables || []).length} 张`,
  )

  // ---- 关闭并检查残留
  killOwn()
  await sleep(3000)
  const residual1 = countProcs()
  check('I-6 关窗后进程残留=0', residual1 === 0, `残留=${residual1}`)

  // -shm/-wal 是**基线遗留**（10/23–10/24 早前的真实运行留下），不能拿"存在"当失败依据；
  // 正确判据是"本次启动没有新增它们"。基线遗留如实列出，交给人工决定要不要清。
  const sidePaths = ['-shm', '-wal'].map((s) => REAL_DB + s)
  const sideInBase = sidePaths.filter((p) => before.has(relative(REAL_DATA, p)))
  const sideNow = sidePaths.filter((p) => existsSync(p))
  const sideNew = sideNow.filter((p) => !sideInBase.includes(p))
  check(
    'I-7 关闭后真实 db 的 -shm/-wal 无新增（基线遗留如实列出，不算本次改动）',
    sideNew.length === 0,
    `基线已有=${sideInBase.length} 现存在=${sideNow.length} 新增=${sideNew.length}${sideInBase.length ? ' 遗留=' + sideInBase.map((p) => p.split('\\').pop()).join(',') : ''}`,
  )

  const after1 = snap(REAL_DATA)
  const d1 = diffSnap(before, after1)
  check(
    'I-8 真实 data 全程零新增/零修改（mtime+size 全量对比）',
    d1.added.length === 0 && d1.changed.length === 0 && d1.removed.length === 0,
    `新增=${d1.added.length} 修改=${d1.changed.length} 删除=${d1.removed.length}${d1.added.length ? ' 例:' + d1.added.slice(0, 3).join(',') : ''}${d1.changed.length ? ' 例:' + d1.changed.slice(0, 3).join(',') : ''}`,
  )

  // ---- 二次启动幂等（同一临时目录）
  const before2 = snap(REAL_DATA)
  const child2 = launch(tmpData)
  const up2 = await waitCdp()
  const tmpClaims2 = sqliteCount(tmpDb, 'claim')
  killOwn()
  await sleep(3000)
  const after2 = snap(REAL_DATA)
  const d2 = diffSnap(before2, after2)
  check(
    'I-9 二次启动幂等（仍 0 条 + 真实 data 仍零改动）',
    up2 === true && tmpClaims2.ok === true && tmpClaims2.count === 0 && d2.added.length === 0 && d2.changed.length === 0,
    `二次 claim=${tmpClaims2.ok ? tmpClaims2.count : '?'} 真实改动=${d2.added.length + d2.changed.length}${up2 ? '' : ' 启动失败:' + ((child2.__tail && child2.__tail()) || '')}`,
  )

  // ---- 反向验证（零写入）：不设 ORB_DATA_DIR 时，路径解析仍指向真实 data
  const nodeExe = process.execPath
  const probeCode = "import('file:///" + join(PROJECT_ROOT, 'packages/core/src/safefs.mjs').replace(/\\/g, '/') + "').then(m => console.log(JSON.stringify({data: m.DATA_DIR, logs: m.LOG_DIR, real: m.REAL_DATA_DIR})))"
  const envNoData = { ...process.env }
  delete envNoData.ORB_DATA_DIR
  delete envNoData.ORB_LOG_DIR
  const pr = spawnSync(nodeExe, ['-e', probeCode], { encoding: 'utf8', env: envNoData, timeout: 20000 })
  let parsed = null
  try {
    parsed = JSON.parse(String(pr.stdout || '').trim().split('\n').pop())
  } catch {
    parsed = null
  }
  const defaultOk = !!parsed &&
    parsed.data.toLowerCase() === join(PROJECT_ROOT, 'data').toLowerCase() &&
    parsed.logs.toLowerCase() === join(PROJECT_ROOT, 'data', 'logs').toLowerCase()
  const realDbNow = sqliteCount(REAL_DB, 'claim')
  check(
    'I-10 反向验证：不设 ORB_DATA_DIR 时仍指向真实 data（只读校验，零写入）',
    defaultOk && realDbNow.ok === true && realDbNow.count > 0,
    `DATA_DIR=${parsed ? String(parsed.data).replace(PROJECT_ROOT, '<root>') : '解析失败'} LOG_DIR=${parsed ? String(parsed.logs).replace(PROJECT_ROOT, '<root>') : '?'} 真实库可读=${realDbNow.ok} claim=${realDbNow.count}`,
  )
} catch (e) {
  if (String((e && e.message) || e) !== 'preflight-instance-running') {
    check('I-0 验收脚本自身异常', false, String((e && e.stack) || e).slice(0, 300))
  }
} finally {
  killOwn()
  await sleep(1200)
  try {
    rmSync(tmpRoot, { recursive: true, force: true })
  } catch {
    /* 临时目录清理失败不影响结论 */
  }
}

const total = items.length
const passed = items.filter((i) => i.ok).length
const failed = total - passed
console.log(`  # accept-s47-app-isolation: total=${total} pass=${passed} fail=${failed}`)
process.exitCode = failed === 0 ? 0 : 1
