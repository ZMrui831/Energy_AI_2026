// tools/accept-s42-voice-oneshot.mjs —— S42·A3 语音唤起即说验收（≥7 项）。
// 单行复跑：node tools\accept-s42-voice-oneshot.mjs
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

process.env.ORB_LOG_DIR = join(tmpdir(), 's42-vo-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's42-vo-data-' + Date.now())
const { dataPath, PROJECT_ROOT } = await import('../packages/core/src/safefs.mjs')
const { createOneShotSession, rmsOf } = await import('../packages/core/src/voice-oneshot.mjs')
const { writeVoiceConfig } = await import('../packages/core/src/voice-settings.mjs')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

// 合成 PCM：chunkMs=100ms @16k → 1600 样本
const loudChunk = () => { const b = Buffer.alloc(3200); for (let i = 0; i < 1600; i++) b.writeInt16LE(Math.round(8000 * Math.sin(i / 4)), i * 2); return b }
const quietChunk = () => Buffer.alloc(3200)

try {
  // V-1 默认关：start 拒绝（未唤醒前不加载模型——transcribe 不该被碰）
  let modelTouched = false
  const s0 = createOneShotSession({ configDoc: {}, transcribe: () => { modelTouched = true; return { ok: true, text: 'x' } } })
  const r0 = s0.start()
  check('V-1 默认关：未唤醒不加载模型', r0.ok === false && r0.code === 'E_VOICE_DISABLED' && modelTouched === false,
    `code=${r0.code} modelTouched=${modelTouched}`, {})

  // V-2 开启后：按下即录（状态 recording）
  writeVoiceConfig({ enabled: true })
  const transcribeStub = (blob) => ({ ok: true, text: '今天北京天气晴，适合出门散步' })
  const s = createOneShotSession({ transcribe: transcribeStub })
  const r1 = s.start()
  check('V-2 按下即录（recording）', r1.ok === true && s.state === 'recording', `state=${s.state}`, {})

  // V-3 静音 1.2s 自动结束（loud×5 → quiet×13 = 1300ms → 自动 stop）
  for (let i = 0; i < 5; i++) s.push(loudChunk())
  let auto = null
  for (let i = 0; i < 13 && s.state === 'recording'; i++) auto = s.push(quietChunk())
  check('V-3 静音 1.2s 自动结束', s.autoStopped === true && s.state === 'transcribing' || s.state === 'done',
    `autoStopped=${s.autoStopped} state=${s.state}`, {})

  // V-4 状态卡四态齐（recording→transcribing→done）
  check('V-4 状态序列', s.states.includes('recording') && s.states.includes('transcribing') && s.states.includes('done'),
    `states=${s.states.join('→')}`, {})

  // V-5 文本入框不自动发（draft autoSend:false）
  const fin = auto && auto.draft ? auto : s.states.includes('done') ? { draft: { autoSend: false } } : null
  check('V-5 文本入框不自动发', !!fin && fin.draft && fin.draft.autoSend === false && fin.draft.source === 'voice-oneshot',
    `autoSend=${fin && fin.draft && fin.draft.autoSend}`, {})

  // V-6 失败降级不影响键盘（转写器抛异常 → error 态、不抛出）
  const s2 = createOneShotSession({ transcribe: () => { throw new Error('模型崩了') } })
  s2.start()
  s2.push(loudChunk())
  let threw = false
  let r2 = null
  try { r2 = s2.stop() } catch (e) { threw = true }
  check('V-6 失败降级不抛出', !threw && r2 && r2.ok === false && s2.state === 'error' && /键盘/.test(r2.reason || ''),
    `state=${s2.state} threw=${threw}`, {})

  // V-7 RMS 静音判定正确（静音块 rms=0 < 阈值；响块 ≥ 阈值）
  check('V-7 RMS 判定', rmsOf(quietChunk()) === 0 && rmsOf(loudChunk()) >= 300, `quiet=0 loud>=300`, {})

  // V-8 零常驻（源码静态断言：无 spawn/setInterval——纯状态机）
  const src = readFileSync(join(PROJECT_ROOT, 'packages', 'core', 'src', 'voice-oneshot.mjs'), 'utf8')
  check('V-8 零常驻纯状态机', !/spawnSync|spawn\(|setInterval|setTimeout/.test(src), `无进程无定时器`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's42-voice-oneshot-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s42-voice-oneshot: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
