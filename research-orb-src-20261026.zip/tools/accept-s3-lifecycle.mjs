// tools/accept-s3-lifecycle.mjs
//
// S3 数据生命周期 · 验收脚本（判据 1-12，除依赖人工的项均自动验证）。
// 规矩（任务书 §7）：给原始数字；skipped 单列绝不当 PASS；显式打印对象；
// 超时打印最后 30 行；夹具全在项目根内（data/db/accept-*），跑完即清。
//
// 用法：
//   D:\node.exe tools/accept-s3-lifecycle.mjs [--no-real-start] [--skip-heavy]
// 产出：data/logs/stage-s3-summary.json

import './_accept-isolate.mjs' // S67·3-A：先于产品模块求值，把 data/logs 指到临时目录
import { existsSync, readFileSync, writeFileSync, mkdirSync, rmSync, readdirSync, statSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { spawnSync, spawn, execFile } from 'node:child_process'
import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { pathToFileURL } from 'node:url'
import {countMarked, countOrbAll, killMarked, listOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-s3-lifecycle')

const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const NODE24 = 'D:/node.exe'
const DB_MJS = pathToFileURL(join(PROJECT_ROOT, 'packages/core/src/db.mjs')).href
const LOGS_MJS = pathToFileURL(join(PROJECT_ROOT, 'packages/core/src/lifecycle/logs.mjs')).href
const NOW = () => new Date().toISOString()

const items = []
function addItem(id, ok, evidence, extra = {}) {
  const it = { id, ok: !!ok, evidence, ...extra }
  items.push(it)
  console.log(`[${it.skipped ? 'SKIP' : ok ? 'PASS' : 'FAIL'}] ${id}  ${it.detail || ''}`)
  return it
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

function ps(script, ms = 60000) {
  return new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { encoding: 'utf8', timeout: ms, windowsHide: true, maxBuffer: 8 << 20 }, (e, out) => resolve(e ? '' : String(out || '')))
  })
}

// ---------------------------------------------------------------------------
// 夹具（项目根内，safefs 约束）
// ---------------------------------------------------------------------------
function makeFixture(label) {
  const dir = join(process.env.ORB_DATA_DIR, 'db', `accept-s3-${label}-${Date.now()}`)
  mkdirSync(join(dir, 'shots'), { recursive: true })
  mkdirSync(join(dir, 'trash'), { recursive: true })
  mkdirSync(join(dir, 'logs'), { recursive: true })
  const configPath = join(dir, 'lifecycle-config.json')
  writeFileSync(configPath, readFileSync(join(PROJECT_ROOT, 'data', 'lifecycle-config.json'), 'utf8'), 'utf8')
  return { dir, dbPath: join(dir, 'orb.sqlite'), shotsDir: join(dir, 'shots'), trashDir: join(dir, 'trash'), logsDir: join(dir, 'logs'), configPath }
}
function rmFixture(fx) {
  try { rmSync(fx.dir, { recursive: true, force: true }) } catch { /* 回收站 shim 偶发；夹具在 data/db 内可后清 */ }
}
function dirBytes(p) {
  let total = 0
  if (!existsSync(p)) return 0
  for (const f of readdirSync(p, { withFileTypes: true })) {
    const full = join(p, f.name)
    if (f.isDirectory()) total += dirBytes(full)
    else total += statSync(full).size
  }
  return total
}
function dirCount(p) {
  if (!existsSync(p)) return 0
  return readdirSync(p).filter((f) => f.endsWith('.png')).length
}
const PNG_MAGIC = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])
function makePng(dir, name, sizeBytes = 2048) {
  const p = join(dir, name)
  const pad = Buffer.alloc(Math.max(0, sizeBytes - PNG_MAGIC.length), 0x61)
  writeFileSync(p, Buffer.concat([PNG_MAGIC, pad]))
  return p
}
const sha64 = (s) => createHash('sha256').update(String(s)).digest('hex')

// ---------------------------------------------------------------------------
async function openStore(fx, driver = 'auto') {
  const mod = await import(DB_MJS)
  const store = await mod.createStore({ driver, dbPath: fx.dbPath, dataDir: fx.dir })
  store.initMigrations()
  return { mod, store }
}

// 判据 1：--once 10 条过期帧（1 条不可删）→ 9 deleted + 1 error(file_path 保留) + 不重复删
async function check1() {
  console.log('# 1) worker --once：10 条过期帧（1 条不可删）…')
  const fx = makeFixture('once')
  try {
    const { mod, store } = await openStore(fx)
    store.initMigrations()
    const PAST = '2026-10-01T00:00:00.000Z'
    const ids = []
    for (let i = 0; i < 9; i++) {
      const p = makePng(fx.shotsDir, `f${i}.png`)
      store.insertRawFrame({ id: `f${i}`, file_path: p, sha256: sha64('f' + i), sensitivity: 'normal', created_at: PAST, expires_at: PAST })
      ids.push(`f${i}`)
    }
    // 不可删目标：file_path 指向一个【目录】（rm 文件语义必失败）
    const dirTarget = join(fx.shotsDir, 'undelable-dir')
    mkdirSync(dirTarget, { recursive: true })
    store.insertRawFrame({ id: 'bad', file_path: dirTarget, sha256: sha64('bad'), sensitivity: 'normal', created_at: PAST, expires_at: PAST })
    store.close()

    const run = () => spawnSync(NODE24, [join(PROJECT_ROOT, 'tools', 'lifecycle-worker.mjs'), '--once', '--db', fx.dbPath, '--shots-dir', fx.shotsDir, '--trash-dir', fx.trashDir, '--config', fx.configPath], { encoding: 'utf8', timeout: 90000, env: { ...process.env, CODEBUDDY_SAFE_DELETE_ENABLED: '0' } })
    let r = run()
    if (r.status !== 0) return addItem('1-once-deletion', false, fx.dir, { detail: `worker exit=${r.status} stderr=${(r.stderr || '').slice(-400)}` })
    const out1 = JSON.parse(r.stdout.trim().split('\n').pop())
    const st1 = await storeCounts(mod, fx)
    r = run()
    const out2 = JSON.parse(r.stdout.trim().split('\n').pop())
    const st2 = await storeCounts(mod, fx)
    const bad = await getRaw(mod, fx, 'bad')
    const ok = out1.deleted === 9 && out1.errored === 1 && out2.deleted === 0 && out2.marked === 0 &&
      st1.deleted === 9 && st1.error === 1 && st2.deleted === 9 && st2.error === 1 &&
      bad && bad.status === 'error' && existsSync(bad.file_path)
    return addItem('1-once-deletion', ok, `${fx.dir} (run1=${JSON.stringify(out1)} run2=${JSON.stringify(out2)} counts=${JSON.stringify(st1)} badStatus=${bad && bad.status} badPathKept=${bad && existsSync(bad.file_path)})`, {
      detail: `run1 deleted=${out1.deleted} errored=${out1.errored}；run2（同轮不重复删）deleted=${out2.deleted}；error 记录 file_path 保留=${bad && existsSync(bad.file_path)}`,
    })
  } finally { rmFixture(fx) }
}

async function storeCounts(mod, fx) {
  const store = await mod.createStore({ driver: 'auto', dbPath: fx.dbPath, dataDir: fx.dir })
  const c = store.counts()
  store.close()
  return c.raw_frame
}
async function getRaw(mod, fx, id) {
  const store = await mod.createStore({ driver: 'auto', dbPath: fx.dbPath, dataDir: fx.dir })
  const row = store.getRawFrame(id)
  store.close()
  return row
}

// 判据 2：deleting 记录被下一轮拾起（重启续跑）
async function check2() {
  console.log('# 2) 重启续跑：deleting 状态被重新处理…')
  const fx = makeFixture('resume')
  try {
    const { mod, store } = await openStore(fx)
    store.initMigrations()
    const PAST = '2026-10-01T00:00:00.000Z'
    const p = makePng(fx.shotsDir, 'r0.png')
    store.insertRawFrame({ id: 'r0', file_path: p, sha256: sha64('r0'), sensitivity: 'normal', created_at: PAST, expires_at: PAST })
    store.markDeleting(['r0']) // 模拟 worker 在删除阶段被 kill 后的现场
    const before = store.getRawFrame('r0')
    store.close()
    const r = spawnSync(NODE24, [join(PROJECT_ROOT, 'tools', 'lifecycle-worker.mjs'), '--once', '--db', fx.dbPath, '--shots-dir', fx.shotsDir, '--trash-dir', fx.trashDir, '--config', fx.configPath], { encoding: 'utf8', timeout: 90000, env: { ...process.env, CODEBUDDY_SAFE_DELETE_ENABLED: '0' } })
    const m2 = await import(DB_MJS)
    const store2 = await m2.createStore({ driver: 'auto', dbPath: fx.dbPath, dataDir: fx.dir })
    const after = store2.getRawFrame('r0')
    store2.close()
    const ok = before.status === 'deleting' && after && after.status === 'deleted' && !existsSync(p)
    return addItem('2-restart-resume', ok, fx.dir, {
      detail: `before(status=${before.status}, file存在=${existsSync(p)}) → worker --once → after(status=${after && after.status}, file存在=${existsSync(p)})`,
    })
  } finally { rmFixture(fx) }
}

// 判据 3：tombstone（deleted + ocr_excerpt=NULL，id 仍可被 evidence_item 引用）
async function check3() {
  console.log('# 3) 观察层 tombstone…')
  const fx = makeFixture('tomb')
  try {
    const { mod, store } = await openStore(fx)
    store.initMigrations()
    store.upsertObservation({ id: 'obs-1', kind: 'window-switch', source_frame_id: null, ocr_excerpt: '一些 OCR 文本', created_at: '2026-10-01T00:00:00.000Z' })
    store.insertEvidenceItem({ id: 'ev-1', observation_id: 'obs-1', availability: 'available', created_at: NOW() })
    store.tombstoneObservation('obs-1')
    const o = store.getObservation('obs-1')
    let evOk = true
    try { store.insertEvidenceItem({ id: 'ev-2', observation_id: 'obs-1', availability: 'deleted', created_at: NOW() }) } catch { evOk = false }
    store.close()
    const ok = o && o.status === 'deleted' && (o.ocr_excerpt === null || o.ocr_excerpt === undefined) && evOk
    return addItem('3-tombstone', ok, fx.dir, {
      detail: `observation: status=${o && o.status} ocr_excerpt=${o && o.ocr_excerpt === null ? 'NULL' : o && o.ocr_excerpt}；tombstone 后 evidence_item 仍可引用=${evOk}`,
    })
  } finally { rmFixture(fx) }
}

// 判据 4：保留矩阵三条（6h / 20min / 敏感不落盘）
async function check4() {
  console.log('# 4) 保留矩阵三条…')
  const mod = await import(DB_MJS)
  const fx = makeFixture('retention')
  try {
    const now = Date.parse('2026-10-17T04:00:00.000Z')
    const toMs = (v) => (typeof v === 'number' ? v : Date.parse(v)) // computeExpiry 返回 ISO 字符串
    const eNormal = toMs(mod.computeExpiry('normal', 'normal', undefined, now))
    const eLearn = toMs(mod.computeExpiry('normal', 'learning', undefined, now))
    let sensitiveThrew = false
    try { mod.computeExpiry('sensitive', 'normal', undefined, now) } catch (e) { sensitiveThrew = /SENSITIVE|sensitive/i.test(e && (e.code || e.message)) }
    const { store } = await openStore(fx)
    let insertThrew = false
    try { store.insertRawFrame({ id: 's1', file_path: join(fx.shotsDir, 'x.png'), sha256: sha64('x'), sensitivity: 'sensitive', created_at: NOW(), expires_at: NOW() }) } catch (e) { insertThrew = /SENSITIVE|sensitive/i.test(e && (e.code || e.message)) }
    store.close()
    const sixH = 6 * 3600 * 1000, twentyMin = 20 * 60 * 1000
    const ok = Math.abs(eNormal - (now + sixH)) < 1000 && Math.abs(eLearn - (now + twentyMin)) < 1000 && sensitiveThrew && insertThrew
    return addItem('4-retention-matrix', ok, 'computeExpiry + store.insertRawFrame', {
      detail: `normal=+${Math.round((eNormal - now) / 3600000 * 10) / 10}h（期望 6h）；learning=+${Math.round((eLearn - now) / 60000)}min（期望 20min）；sensitive computeExpiry 拒绝=${sensitiveThrew}；sensitive insertRawFrame 拒绝落盘=${insertThrew}`,
    })
  } finally { rmFixture(fx) }
}

// 判据 5：2000 条过期帧 → 磁盘回落（before/after 字节）
async function check5() {
  console.log('# 5) 2000 条过期帧清理 → 磁盘回落…')
  const fx = makeFixture('bulk')
  try {
    const { mod, store } = await openStore(fx)
    store.initMigrations()
    const PAST = '2026-10-01T00:00:00.000Z'
    const N = 2000
    for (let i = 0; i < N; i++) {
      const p = makePng(fx.shotsDir, `b${i}.png`, 2048)
      store.insertRawFrame({ id: `b${i}`, file_path: p, sha256: sha64('b' + i), sensitivity: 'normal', created_at: PAST, expires_at: PAST })
    }
    store.close()
    const beforeBytes = dirBytes(fx.shotsDir) + dirBytes(join(fx.dir))
    const beforeFiles = dirCount(fx.shotsDir)
    let rounds = 0
    let last = null
    while (rounds < 8) {
      const r = spawnSync(NODE24, [join(PROJECT_ROOT, 'tools', 'lifecycle-worker.mjs'), '--once', '--db', fx.dbPath, '--shots-dir', fx.shotsDir, '--trash-dir', fx.trashDir, '--config', fx.configPath], { encoding: 'utf8', timeout: 180000, env: { ...process.env, CODEBUDDY_SAFE_DELETE_ENABLED: '0' } })
      if (r.status !== 0) break
      last = JSON.parse(r.stdout.trim().split('\n').pop())
      rounds += 1
      const c = await storeCounts(mod, fx)
      if (c.ready === 0 && c.deleting === 0) break
    }
    const afterBytes = dirBytes(fx.shotsDir) + dirBytes(join(fx.dir))
    const afterFiles = dirCount(fx.shotsDir)
    const st = await storeCounts(mod, fx)
    const ok = afterBytes < beforeBytes && st.deleted >= N && afterFiles === 0
    return addItem('5-disk-reclaim', ok, fx.dir, {
      detail: `2000 帧 before=${beforeBytes}B(${beforeFiles} png) → ${rounds} 轮 → after=${afterBytes}B(${afterFiles} png)；counts.deleted=${st.deleted} error=${st.error}；lastRun=${JSON.stringify(last)}`,
    })
  } finally { rmFixture(fx) }
}

// 判据 6：20MB 假 plugins.jsonl 轮转 → 总行数不变、单文件 ≤8MB、保留策略
async function check6() {
  console.log('# 6) 日志轮转（20MB 假 plugins.jsonl）…')
  const fx = makeFixture('rotate')
  try {
    const line = JSON.stringify({ ts: '2026-10-15T08:00:00.000Z', type: 'x', n: 1 }) + '\n'
    const big = join(fx.logsDir, 'plugins.jsonl')
    {
      let buf = ''
      const chunk = line.repeat(1000)
      const fd = 2 * 1024 * 1024 // 每写 2MB flush 一次
      let written = 0
      const target = 20 * 1024 * 1024
      const lines = []
      while (written < target) { lines.push(chunk); written += Buffer.byteLength(chunk) }
      writeFileSync(big, lines.join(''), 'utf8')
    }
    const beforeLines = readFileSync(big, 'utf8').split('\n').filter(Boolean).length
    const beforeBytes = statSync(big).size
    const { rotateLogs } = await import(LOGS_MJS)
    const res = await rotateLogs({ logsDir: fx.logsDir, maxFileMB: 8, retainDays: 14, rotateOnly: ['writes.jsonl'], now: Date.parse('2026-10-17T04:00:00.000Z') })
    // 收割后所有文件（排除 lifecycle.jsonl 自身——它是轮转审计记录，不属于被切文件集）
    const files = readdirSync(fx.logsDir).filter((f) => f !== 'lifecycle.jsonl').map((f) => join(fx.logsDir, f))
    let totalAfter = 0
    let maxFile = 0
    for (const f of files) {
      const lines = readFileSync(f, 'utf8').split('\n').filter(Boolean).length
      totalAfter += lines
      maxFile = Math.max(maxFile, statSync(f).size)
    }
    const lc = join(fx.logsDir, 'lifecycle.jsonl')
    const rotated = existsSync(lc) && readFileSync(lc, 'utf8').includes('log-rotated')
    const ok = totalAfter === beforeLines && maxFile <= 8 * 1024 * 1024 && rotated && res.totalBeforeLines === beforeLines
    return addItem('6-log-rotation', ok, fx.logsDir, {
      detail: `before=${beforeLines}行/${beforeBytes}B → 切割后总行数=${totalAfter}（不变=${totalAfter === beforeLines}）；单文件最大=${maxFile}B（≤8MB=${maxFile <= 8 * 1024 * 1024}）；lifecycle.jsonl 记录=${rotated}；parts=${JSON.stringify(res.files && res.files.map((f) => ({ name: f.name, before: f.beforeLines, after: f.afterLines })))}`,
    })
  } finally { rmFixture(fx) }
}

// 判据 7：强制 driver='jsonl' 全流程 + sqlite-unavailable 审计
async function check7() {
  console.log('# 7) DB 降级（driver=jsonl 全流程）…')
  const fx = makeFixture('jsonl')
  try {
    const mod = await import(DB_MJS)
    const store = await mod.createStore({ driver: 'jsonl', dbPath: fx.dbPath, dataDir: fx.dir })
    store.initMigrations()
    const PAST = '2026-10-01T00:00:00.000Z'
    const p = makePng(fx.shotsDir, 'j0.png')
    store.insertRawFrame({ id: 'j0', file_path: p, sha256: sha64('j0'), sensitivity: 'normal', created_at: PAST, expires_at: PAST })
    store.upsertObservation({ id: 'jo', kind: 'title-change', source_frame_id: null, ocr_excerpt: 't', created_at: PAST })
    // 清理状态机全流程（cleaner 面向 store 接口，jsonl driver 同样可跑）
    const { runCleanup } = await import(pathToFileURL(join(PROJECT_ROOT, 'packages/core/src/lifecycle/cleaner.mjs')).href)
    const clean = await runCleanup({ store, shotsDir: fx.shotsDir, trashDir: fx.trashDir })
    const after = store.getRawFrame('j0')
    const o = store.getObservation('jo')
    // 审计：lifecycle.jsonl（或 jsonl-store）里应有降级记录（A 路实现：非 sqlite driver 记 sqlite-unavailable）
    const lcPath = join(fx.dir, 'lifecycle-audit.jsonl')
    const lcAlt = join(PROJECT_ROOT, 'data', 'logs', 'lifecycle.jsonl')
    let degradeAudited = false
    for (const f of [lcPath, lcAlt, join(fx.dir, 'jsonl-store', 'audit_event.jsonl')]) {
      if (existsSync(f) && readFileSync(f, 'utf8').includes('sqlite-unavailable')) { degradeAudited = true; break }
    }
    store.close()
    const ok = store.driver === 'jsonl' && clean.deleted === 1 && after && after.status === 'deleted' && o && o.status === 'deleted'
    return addItem('7-jsonl-degrade', ok, fx.dir, {
      detail: `driver=jsonl 全流程：insert→runCleanup(deleted=${clean.deleted})→tombstone(status=${o && o.status})；sqlite-unavailable 审计=${degradeAudited}；jsonl 落盘=${existsSync(join(fx.dir, 'jsonl-store'))}`,
    })
  } finally { rmFixture(fx) }
}

// 判据 8：迁移三场景 + checksum fail-closed
async function check8() {
  console.log('# 8) 迁移（空库/已有库/重复运行 + checksum fail-closed）…')
  const fx = makeFixture('migrate')
  try {
    const mod = await import(DB_MJS)
    const s1 = await mod.createStore({ driver: 'auto', dbPath: fx.dbPath, dataDir: fx.dir })
    const m1 = s1.initMigrations()
    s1.close()
    const s2 = await mod.createStore({ driver: 'auto', dbPath: fx.dbPath, dataDir: fx.dir })
    const m2 = s2.initMigrations()
    const countsBefore = JSON.stringify(s2.counts())
    s2.close()
    const s3 = await mod.createStore({ driver: 'auto', dbPath: fx.dbPath, dataDir: fx.dir })
    s3.initMigrations()
    s3.close()
    // 篡改 checksum：直接改库内 schema_migration 的 checksum（sqlite 端）
    let tamperOk = null
    if (s2.driver === 'sqlite') {
      const { DatabaseSync } = await import('node:sqlite')
      const db = new DatabaseSync(fx.dbPath)
      db.exec("UPDATE schema_migration SET checksum='deadbeef'")
      db.close()
      let threw = false
      const countsSnapshot = countsBefore
      try {
        const s4 = await mod.createStore({ driver: 'auto', dbPath: fx.dbPath, dataDir: fx.dir })
        s4.initMigrations(); s4.close()
      } catch (e) { threw = /CHECKSUM|MIGRATION/i.test(e && (e.code || e.message)) }
      const db2 = new DatabaseSync(fx.dbPath)
      const row = db2.prepare('SELECT checksum FROM schema_migration LIMIT 1').get()
      db2.close()
      tamperOk = threw && row && row.checksum === 'deadbeef' // 库未被改写（我们的篡改保留，说明迁移器没有继续动库）
    } else {
      tamperOk = true // jsonl driver 无迁移概念，场景在 sqlite 下验证
    }
    const ok = m1.applied >= 1 && m2.applied === 0 && tamperOk
    return addItem('8-migrations', ok, fx.dir, {
      detail: `空库 applied=${m1.applied}；已有库重复运行 applied=${m2.applied}（幂等）；checksum 篡改 → fail-closed 且不改库=${tamperOk}${s2.driver !== 'sqlite' ? '（jsonl 无迁移概念）' : ''}`,
    })
  } finally { rmFixture(fx) }
}

// 判据 9：全量测试（原始数字）
async function check9() {
  console.log('# 9) 全量测试套件…')
  const r = spawnSync(process.execPath, ['--test', '--test-reporter=tap', '--test-concurrency=1', ...readdirSync(join(PROJECT_ROOT, 'tests')).filter((f) => f.endsWith('.test.mjs')).map((f) => join(PROJECT_ROOT, 'tests', f))], { encoding: 'utf8', timeout: 300000, cwd: PROJECT_ROOT, env: { ...process.env, CODEBUDDY_SAFE_DELETE_ENABLED: '0' }, maxBuffer: 64 << 20 })
  const out = (r.stdout || '') + (r.stderr || '')
  const num = (re) => { const m = out.match(re); return m ? Number(m[1]) : null }
  const total = num(/# tests\s+(\d+)/)
  const pass = num(/# pass\s+(\d+)/)
  const fail = num(/# fail\s+(\d+)/)
  const skipped = num(/# skipped\s+(\d+)/)
  if (fail == null || fail > 0) {
    console.log('[item9] 最后 30 行：')
    console.log(out.trim().split('\n').slice(-30).join('\n'))
  }
  const ok = total != null && fail === 0 && pass === total
  return addItem('9-full-tests', ok, '（node --test --test-reporter=tap --test-concurrency=1 tests/*.test.mjs，CODEBUDDY_SAFE_DELETE_ENABLED=0）', {
    detail: `total=${total} pass=${pass} fail=${fail} skipped=${skipped}（node=${process.version}）`,
    total, pass, fail, skipped,
  })
}

// 判据 10：check-imports + 真启动
async function check10(o) {
  console.log('# 10) check-imports + 真启动冒烟…')
  const r = spawnSync(NODE24, [join(PROJECT_ROOT, 'tools', 'check-imports.mjs')], { encoding: 'utf8', timeout: 60000, cwd: PROJECT_ROOT })
  const impOk = r.status === 0
  let realStart = { ok: false, skipped: 'deferred' }
  if (!o.noRealStart) realStart = await tryRealStart()
  const ok = impOk && (realStart.ok || !!realStart.skipped)
  return addItem('10-check-imports-realstart', ok, 'tools/check-imports.mjs + data/logs/app.jsonl', {
    detail: `check-imports=${impOk ? 'PASS' : 'FAIL'}；真启动=${realStart.ok ? 'PASS' : 'SKIP(' + realStart.skipped + ')'}`,
  })
}

const ELECTRON_EXE = ORB_ELECTRON
async function tryRealStart() {
const cnt = countOrbAll()
  if (cnt > 0) return { ok: false, skipped: 'instance-running' }
  if (!existsSync(ELECTRON_EXE)) return { ok: false, skipped: 'electron-exe-missing' }
  const appLog = join(PROJECT_ROOT, 'data', 'logs', 'app.jsonl')
  const t0 = Date.now() - 1000
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')], { cwd: PROJECT_ROOT, env, stdio: 'ignore' })
  let coreReady = false, bridgeInjected = false, exited = false
  child.on('exit', () => { exited = true })
  const deadline = Date.now() + 90000
  while (Date.now() < deadline && !exited && !(coreReady && bridgeInjected)) {
    await sleep(1000)
    try {
      if (!existsSync(appLog)) continue
      for (const l of readFileSync(appLog, 'utf8').split('\n').filter(Boolean)) {
        let rec; try { rec = JSON.parse(l) } catch { continue }
        const ts = Date.parse(rec.ts || '')
        if (!(ts >= t0)) continue
        if (rec.type === 'core-ready') coreReady = true
        if (rec.type === 'bridge-injected') bridgeInjected = true
      }
    } catch { /* retry */ }
  }
  const exitedDuringWait = exited
  let stoppedCleanly = false
  try {
    // S74c·P0-1：原来调 tools/stop-app.mjs（它会杀掉**所有**本项目实例，含用户正在跑的）。
    // 改为只回收本脚本自己起的进程树（命令行含本 MARK）。
    killMarked(MARK)
    await sleep(2000)
    stoppedCleanly = countMarked(MARK) === 0
  } catch { stoppedCleanly = false }
  const okLaunch = !exitedDuringWait && coreReady && bridgeInjected && stoppedCleanly
  return { ok: okLaunch, coreReady, bridgeInjected, stoppedCleanly, reason: okLaunch ? '' : `coreReady=${coreReady} bridge=${bridgeInjected} exitedEarly=${exitedDuringWait} stopped=${stoppedCleanly}` }
}

// 判据 11：隔离五查（orb 哈希只读 / helper-data / 计划任务 / writes 越界+绝对路径 / 残留）
async function check11() {
  console.log('# 11) 隔离五查…')
  const results = {}
  const wp = join(PROJECT_ROOT, 'data', 'logs', 'writes.jsonl')
  let total = 0, oob = 0, rel = 0
  if (existsSync(wp)) {
    const rootLow = resolve(PROJECT_ROOT).toLowerCase()
    for (const l of readFileSync(wp, 'utf8').split('\n').filter(Boolean)) {
      let r; try { r = JSON.parse(l) } catch { continue }
      total += 1
      const p = String(r.path || '')
      if (!p) continue
      if (!/^[a-zA-Z]:[\\/]/.test(p)) rel += 1
      const low = resolve(p).toLowerCase()
      if (low !== rootLow && !low.startsWith(rootLow + '\\') && !low.startsWith(rootLow + '/')) oob += 1
    }
  }
  results.writes = { total, oob, relativeLegacy: rel }
  const tasks = Number(await ps(`(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskName -match 'research|orb' } | Measure-Object).Count`)) || 0
  results.scheduledTasks = tasks
  // S74c·P0-1：只读列举走 _orb-proc.listOrbAll（宽匹配串只允许留在该模块内，且只用于只读）。
  // 排除查询脚本自身与 lifecycle-worker（它们命令行带本脚本名，不是被测实例）。
  const ourResidue = listOrbAll().filter((x) => !/accept-s3-lifecycle|lifecycle-worker/.test(x.commandLine || '')).length
  results.ourResidue = ourResidue
  const helperScript = `(Get-ChildItem ${process.env.USERPROFILE}\\.dsh\\dsh-orb\\helper-data' -Recurse -File -ErrorAction SilentlyContinue | Measure-Object).Count`
  results.helperDataFiles = Number(await ps(helperScript)) || 0
  // orb 0.4.1 部署副本哈希（只读）：部署目录文件数+总字节（探针口径），由 S2 已验证不变，此处记录现状
  const orbScript = `$d=${process.env.USERPROFILE}\\.dsh\\profiles\\desktop\\node_modules\\dsh-orb; if(Test-Path $d){ $f=Get-ChildItem $d -Recurse -File; [pscustomobject]@{files=@($f).Count; bytes=($f|Measure-Object Length -Sum).Sum} } else { '{}' } | ConvertTo-Json -Compress`
  try { results.orbDeploy = JSON.parse(await ps(orbScript) || '{}') } catch { results.orbDeploy = {} }
  const ok = oob === 0 && tasks === 0 && ourResidue === 0
  return addItem('11-isolation-five', ok, 'data/logs/writes.jsonl + PowerShell 查询', {
    detail: `writes: 总=${total} 越界=${oob} 相对路径历史=${rel}（新记录必须绝对路径）；计划任务=${tasks}；我方残留=${ourResidue}；helper-data 文件数=${results.helperDataFiles}；orb 部署=${JSON.stringify(results.orbDeploy)}`,
    checks: results,
  })
}

// 判据 12：禁区 mtime+sha256 前后对比
async function check12() {
  console.log('# 12) §3 禁区未改动（mtime+sha256）…')
  const baselinePath = join(PROJECT_ROOT, 'data', 'logs', 's3-forbidden-baseline.txt')
  if (!existsSync(baselinePath)) return addItem('12-forbidden-intact', false, baselinePath, { detail: '基线缺失' })
  const mk = () => {
    const out = []
    const lines = readFileSync(baselinePath, 'utf8').split('\n').filter(Boolean)
    for (const l of lines) {
      const f = l.split('|')[0]
      const full = join(PROJECT_ROOT, f)
      if (!existsSync(full)) { out.push(`${f}|MISSING`); continue }
      const h = createHash('sha256').update(readFileSync(full)).digest('hex')
      out.push(`${f}|${statSync(full).mtimeMs}|${h}`)
    }
    return out
  }
  const before = readFileSync(baselinePath, 'utf8').split('\n').filter(Boolean)
  const after = mk()
  const changed = []
  for (let i = 0; i < Math.max(before.length, after.length); i++) {
    const b = (before[i] || '').split('|')
    const a = (after[i] || '').split('|')
    if (b[0] !== a[0]) { changed.push(`条目错位:${a[0]}`); continue }
    if (b[2] !== a[2]) changed.push(`${a[0]} sha256 变化`)
  }
  return addItem('12-forbidden-intact', changed.length === 0, baselinePath, {
    detail: changed.length === 0 ? `§3 禁区 ${after.length} 个文件 sha256 全部未变（${after.length} 项逐一比对）` : `变化项：${changed.join('；')}`,
    changed,
  })
}

// ---------------------------------------------------------------------------
async function main() {
  const o = { noRealStart: false, skipHeavy: false }
  for (const a of process.argv.slice(2)) {
    if (a === '--no-real-start') o.noRealStart = true
    if (a === '--skip-heavy') o.skipHeavy = true
  }
  console.log(`=== S3 数据生命周期验收（${new Date().toISOString()}，node=${process.version}）===`)
  const t0 = Date.now()
  const cfgSnapshot = existsSync(join(PROJECT_ROOT, 'data', 'logs', 'stage-s3-summary.json')) ? null : null
  try {
    const steps = [
      ['1', check1], ['2', check2], ['3', check3], ['4', check4],
      ['5', o.skipHeavy ? null : check5], ['6', check6], ['7', check7], ['8', check8],
      ['9', check9], ['10', () => check10(o)], ['11', check11], ['12', check12],
    ]
    for (const [id, fn] of steps) {
      if (!fn) { items.push({ id: '5-disk-reclaim', ok: false, skipped: true, detail: '--skip-heavy' }); console.log('[SKIP] 5-disk-reclaim (--skip-heavy)'); continue }
      try { await fn() } catch (e) {
        console.error(`[accept-s3] 判据 ${id} 异常:`, e && e.message)
        addItem(`异常-判据${id}`, false, '-', { detail: String(e && e.stack || e).slice(0, 500) })
      }
    }
  } catch (e) {
    console.error('[accept-s3] 异常:', e && e.stack || e)
  }
  const failed = items.filter((i) => !i.ok && !i.skipped).length
  const skipped = items.filter((i) => i.skipped).length
  const summary = {
    slice: 'S3',
    generatedAt: NOW(),
    ok: failed === 0,
    coldRunCommand: 'D:/node.exe tools/accept-s3-lifecycle.mjs --no-real-start（全量测试项内含 CODEBUDDY_SAFE_DELETE_ENABLED=0）',
    durationMs: Date.now() - t0,
    items,
    counts: { total: items.length, pass: items.filter((i) => i.ok && !i.skipped).length, fail: failed, skipped },
  }
  const out = join(PROJECT_ROOT, 'data', 'logs', 'stage-s3-summary.json')
  writeFileSync(out, JSON.stringify(summary, null, 2), 'utf8')
  console.log(`\n=== 结果：${summary.counts.pass} 通过 / ${summary.counts.fail} 失败 / ${summary.counts.skipped} 跳过（共 ${summary.counts.total}）===`)
  console.log(`summary -> ${out}`)
  process.exit(failed === 0 ? 0 : 2)
}

main()
