// tools/accept-s33-rotate.mjs —— S33·E 轮转与基线张力验收（≥4 项）。
// 单行复跑：node tools\accept-s33-rotate.mjs
// 证据：data\logs\s33-rotate-accept.json
//
// 覆盖：archiveFile 归档到 rotated/<file>.<ts>.jsonl + MANIFEST 记账 /
//      轮转后 live+archived 总量不变（守恒）/ 轮转后 audit-preflight 通过 /
//      删归档 → total 下降并报 E_AUDIT_LOSS / audit-preflight 结果含 live/archived/total 三字段。
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { archiveFile, archiveStats, readManifest, rotatedDir, manifestPath } from '../packages/core/src/log-archive.mjs'
import { auditPreflight } from '../packages/plugins/coach/audit-preflight.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

function seedRoot(liveLines) {
  const root = mkdtempSync(join(tmpdir(), 'orb-rot-'))
  const logsDir = join(root, 'data', 'logs')
  mkdirSync(logsDir, { recursive: true })
  writeFileSync(join(logsDir, 'writes.jsonl'), Array.from({ length: liveLines }, (_, i) => JSON.stringify({ i, pad: 'x'.repeat(20) })).join('\n') + '\n')
  writeFileSync(join(logsDir, 's25-audit-preflight.json'), JSON.stringify({ at: 'x', D23: 'rot', 'writes.jsonl': liveLines }, null, 2))
  return { root, logsDir }
}

try {
  const LIVE = 50
  const { root, logsDir } = seedRoot(LIVE)
  try {
    const before = archiveStats(logsDir, 'writes.jsonl')

    // E1：归档落盘 + MANIFEST 记账
    const a = archiveFile(logsDir, 'writes.jsonl', { now: Date.parse('2026-10-23T12:00:00Z') })
    const rotated = rotatedDir(logsDir)
    const manifest = readManifest(logsDir)
    const destExists = !!a.dest && existsSync(join(rotated, a.dest))
    const manOk = manifest.some((e) => e.file === 'writes.jsonl' && e.archivedLines === LIVE && e.at && e.dest)
    check('E1', a.archivedLines === LIVE && destExists && manOk && existsSync(manifestPath(logsDir)),
      `archivedLines=${a.archivedLines} dest=${a.dest} manifest=${manOk}`, { dest: a.dest })

    // E2：轮转后 live+archived 总量守恒（total 不变）
    const after = archiveStats(logsDir, 'writes.jsonl')
    check('E2', after.live === 0 && after.archived === LIVE && after.total === before.total,
      `before.total=${before.total} after(live=${after.live}+arch=${after.archived})=${after.total}`, { after: { live: after.live, archived: after.archived, total: after.total } })

    // E5：audit-preflight 结果含 live/archived/total 三字段（三列口径）
    const r = auditPreflight({ root })
    const row = r.results.find((x) => x.file === 'writes.jsonl')
    const threeCols = row && typeof row.live === 'number' && typeof row.archived === 'number' && typeof row.total === 'number'
    check('E5', threeCols, `live=${row && row.live} archived=${row && row.archived} total=${row && row.total}`, { row })

    // E3：轮转后 preflight 通过（total 仍 >= 基线）
    check('E3', r.ok === true && row.total >= row.baseline, `ok=${r.ok} total=${row && row.total} baseline=${row && row.baseline}`, {})

    // E4：删归档 → total 下降 → E_AUDIT_LOSS
    rmSync(join(rotated, a.dest), { force: true })
    const afterDel = archiveStats(logsDir, 'writes.jsonl')
    let threw = null
    try { auditPreflight({ root }) } catch (e) { threw = e && e.code }
    check('E4', afterDel.total === 0 && threw === 'E_AUDIT_LOSS',
      `afterDel.total=${afterDel.total} throw=${threw}`, { afterDel: { live: afterDel.live, archived: afterDel.archived, total: afterDel.total } })
  } finally {
    try { rmSync(root, { recursive: true, force: true }) } catch { /* 尽力 */ }
  }
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(join(PROJECT_ROOT, 'data', 'logs', 's33-rotate-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s33-rotate: total=${items.length} pass=${pass} fail=${items.length - pass}`)
console.log('  # 证据 -> data/logs/s33-rotate-accept.json')
process.exit(pass === items.length ? 0 : 1)
