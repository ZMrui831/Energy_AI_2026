// tools/check-runtime-deps.mjs —— S67·4-C 运行时依赖可验证护栏
//
// 口径（方案 A·诚实）：依赖**已锁定并随包提供**，不依赖联网安装。本护栏逐个 import() 验证：
//   ① package.json 声明的运行时依赖全部可解析且可加载；
//   ② 实际存在 node_modules（随包提供的前提）。
// 有效性自证：把 node_modules 临时改名后再跑本脚本应 FAIL（README/EVIDENCE 记录）。
import { readFileSync, existsSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'
import { createRequire } from 'node:module'

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(import.meta.url)

// 已知的 6 个运行时依赖（与 package.json dependencies 对齐）
const EXPECTED = ['@citation-js/core', '@citation-js/plugin-bibtex', '@orama/orama', 'docx', 'gray-matter', 'unpdf']

let declared = []
try {
  const pkg = JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8'))
  declared = Object.keys(pkg.dependencies || {})
} catch (e) {
  console.log('[check-runtime-deps] 读 package.json 失败：' + e.message)
}

// ① node_modules 存在（随包提供）
const nm = join(ROOT, 'node_modules')
const nmOk = existsSync(nm)
console.log('[check-runtime-deps] node_modules 存在 = ' + nmOk)

// ② 声明与期望一致（防止悄悄增加依赖却没同步护栏）
const notInExpected = declared.filter((d) => !EXPECTED.includes(d))
const notDeclared = EXPECTED.filter((d) => !declared.includes(d))
if (notInExpected.length || notDeclared.length) {
  console.log('[check-runtime-deps] ⚠ 声明/期望不一致：多出[' + notInExpected.join(',') + '] 缺少[' + notDeclared.join(',') + ']')
}

// ③ 逐个解析 + 真实加载
const missing = []
const loadFail = []
for (const d of EXPECTED) {
  try { require.resolve(d) } catch { missing.push(d); continue }
  try { await import(d) } catch (e) { loadFail.push(d + ' (' + (e && e.code) + ')') }
}

console.log('[check-runtime-deps] 依赖 ' + EXPECTED.length + ' 个：可解析 ' + (EXPECTED.length - missing.length) + '，可加载 ' + (EXPECTED.length - missing.length - loadFail.length))
if (missing.length) console.log('  ✗ 缺失（不可解析）：' + missing.join(', '))
if (loadFail.length) console.log('  ✗ 加载失败：' + loadFail.join(', '))

const ok = nmOk && missing.length === 0 && loadFail.length === 0 && notInExpected.length === 0 && notDeclared.length === 0
if (!ok) {
  console.log('  ✗ FAIL：运行时依赖未全部随包可用（或不一致）')
  process.exit(1)
}
console.log('  ✓ PASS：6 个运行时依赖已锁定并随包提供，全部可 import()')
