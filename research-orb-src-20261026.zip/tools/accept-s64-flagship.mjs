// tools/accept-s64-flagship.mjs —— S64 旗舰推理模型适配验收（8 项）
//
// 背景：deepseek-v4-pro 也是推理模型 —— 无 reasoning_effort 时 max_tokens 全被思考吃掉
//      （finish=length、content 0 字）→ 日报 score unavailable。三档：score-plan/summarize=none、
//      reason=low；content 空走 reasoning_content 兜底；score-plan/summarize max_tokens≥800。
// 用法：node tools\accept-s64-flagship.mjs   （需真实 deepseek + zhipu key）

import { mkdtempSync, rmSync, mkdirSync, copyFileSync, existsSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'

const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 320) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s64-'))
process.env.ORB_DATA_DIR = join(tmpRoot, 'data')
mkdirSync(join(tmpRoot, 'data', 'logs'), { recursive: true })
mkdirSync(join(tmpRoot, 'data', 'coach'), { recursive: true })
mkdirSync(join(tmpRoot, 'data', 'trash'), { recursive: true })
try {
  for (const f of ['secrets.json', 'providers.json']) {
    const src = join(PROJECT_ROOT, 'data', f)
    if (existsSync(src)) copyFileSync(src, join(tmpRoot, 'data', f))
  }
} catch { /* 失败会以"密钥不可用"如实报错 */ }

const realFetch = globalThis.fetch
let calls = []
const stub = (responder) => {
  calls = []
  globalThis.fetch = async (url, init) => {
    const body = init && init.body ? JSON.parse(init.body) : null
    calls.push({ url, body })
    const r = responder(body, calls.length)
    return { ok: true, status: 200, json: async () => r.doc, text: async () => JSON.stringify(r.doc || {}) }
  }
}

try {
  const { makeInvoke } = await import('../packages/plugins/coach/index.mjs')
  const invoke = makeInvoke(null)
  const flagship = { providerId: 'deepseek-api', model: 'deepseek-v4-pro', authRef: 'secrets:deepseek' }

  // ---------- F-1 请求体三档 reasoning_effort + max_tokens≥800 ----------
  stub(() => ({ doc: { choices: [{ message: { content: '{"score":50,"advice":[]}' }, finish_reason: 'stop' }], usage: { total_tokens: 100, completion_tokens: 20 } } }))
  await invoke({ tier: 'flagship', provider: flagship, taskClass: 'score-plan', payload: { messages: [{ role: 'user', content: 'x' }], maxTokens: 400 } })
  const scorePlanBody = calls[0] && calls[0].body
  await invoke({ tier: 'flagship', provider: flagship, taskClass: 'summarize', payload: { messages: [{ role: 'user', content: 'x' }] } })
  const summarizeBody = calls[1] && calls[1].body
  await invoke({ tier: 'flagship', provider: flagship, taskClass: 'reason', payload: { messages: [{ role: 'user', content: 'x' }] } })
  const reasonBody = calls[2] && calls[2].body
  check('F-1 三档 reasoning_effort（score-plan=none、summarize=none、reason=low）+ score-plan max_tokens 抬到 ≥800',
    scorePlanBody.reasoning_effort === 'none' && summarizeBody.reasoning_effort === 'none' && reasonBody.reasoning_effort === 'low' &&
    scorePlanBody.max_tokens >= 800,
    JSON.stringify({ scorePlan: scorePlanBody.reasoning_effort, summarize: summarizeBody.reasoning_effort, reason: reasonBody.reasoning_effort, maxTokens: scorePlanBody.max_tokens }))

  // ---------- F-5 content 空 → reasoning 兜底并标记 ----------
  stub(() => ({ doc: { choices: [{ message: { content: '', reasoning_content: '{"score":50,"advice":["a"]}' }, finish_reason: 'stop' }], usage: { total_tokens: 100, completion_tokens: 30 } } }))
  const r5 = await invoke({ tier: 'flagship', provider: flagship, taskClass: 'score-plan', payload: { messages: [{ role: 'user', content: 'x' }] } })
  check('F-5 content 空时 reasoning_content 兜底并标 usedReasoningFallback',
    /"score":50/.test(String(r5.text)) && r5.meta && r5.meta.usedReasoningFallback === true,
    JSON.stringify({ text: String(r5.text).slice(0, 40), meta: r5.meta }))

  // ---------- F-6 usage 行含 reasoningEffort + completionTokens ----------
  const { createRouter } = await import('../packages/core/src/router.mjs')
  stub(() => ({ doc: { choices: [{ message: { content: '{"score":66,"advice":["b"]}' }, finish_reason: 'stop' }], usage: { total_tokens: 110, completion_tokens: 25 } } }))
  const usagePath = join(tmpRoot, 'data', 'logs', 'usage.jsonl')
  const router6 = createRouter({
    providers: { flagship, cheap: { providerId: 'school-gateway', model: 'qwen' }, vision: { providerId: 'zhipu', model: 'glm-5.3-flash', baseUrl: 'https://open.bigmodel.cn/api/paas/v4', authRef: 'secrets:zhipu' } },
    invoke, audit: () => {}, usagePath,
  })
  await router6.run('score-plan', { messages: [{ role: 'user', content: 'x' }] })
  const row = readFileSync(usagePath, 'utf8').split('\n').filter((l) => l.trim()).map((l) => { try { return JSON.parse(l) } catch { return null } }).find((x) => x && x.tier === 'flagship')
  check('F-6 usage 审计行含 reasoningEffort 与 completionTokens',
    !!row && row.reasoningEffort === 'none' && Number.isFinite(Number(row.completionTokens)),
    JSON.stringify(row))

  // ---------- F-2/3/4 真调 score-plan ×3（JSON.parse + score 数字 + finish=stop + 稳定） ----------
  globalThis.fetch = realFetch // 恢复真网络
  const runs = []
  for (let i = 0; i < 3; i++) {
    const t0 = Date.now()
    try {
      const r = await router6.run('score-plan', {
        messages: [
          { role: 'system', content: '你是科研教练。根据目标与今日轨迹给出今日投入评分（0-100 整数）与明日 1-3 条建议。只输出 JSON：{"score":82,"advice":["..."]}' },
          { role: 'user', content: '目标：微电网 MPC 调度研究。今日轨迹：撰写方法章节、检索光伏预测文献。' },
        ],
      })
      runs.push({ ms: Date.now() - t0, ok: r.ok, text: String(r.text || ''), meta: r.meta || {}, error: r.error })
    } catch (e) {
      runs.push({ ms: Date.now() - t0, error: String((e && e.message) || e).slice(0, 140) })
    }
  }
  const parseLoose = (s) => {
    let t = String(s || '').trim()
    const m = /```(?:json)?\s*([\s\S]*?)```/.exec(t)
    if (m) t = m[1].trim()
    const b = t.indexOf('{')
    const e = t.lastIndexOf('}')
    if (b >= 0 && e > b) t = t.slice(b, e + 1)
    try { return JSON.parse(t) } catch { return null }
  }
  const parsed = runs.map((x) => parseLoose(x.text))
  const allOk = runs.every((x) => x.ok === true)
  const allStop = runs.every((x) => x.meta && x.meta.finish === 'stop')
  const allScore = parsed.every((p) => p && Number.isFinite(Number(p.score)))
  const scores = parsed.map((p) => (p ? Number(p.score) : null))
  const allFast = runs.every((x) => x.ms < 60000)
  check('F-2/3/4 真调 score-plan ×3：ok + finish=stop + content 可解析且 score 为数字（0-100）',
    allOk && allStop && allScore && allFast && scores.every((s) => s >= 0 && s <= 100),
    JSON.stringify({ ms: runs.map((x) => x.ms), finish: runs.map((x) => x.meta && x.meta.finish), scores, efforts: runs.map((x) => x.meta && x.meta.reasoningEffort) }))

  // ---------- F-7 端到端：真跑 daily.run（fixture 图 + 真 vision/summarize/score-plan）→ 日报 score 为数字 ----------
  const FIXTURE = join(PROJECT_ROOT, 'tests', 'fixtures', 'vision', 'text-dense-1280x800.png')
  if (!existsSync(FIXTURE)) throw new Error('fixture 缺失（先跑 accept-s62-reasoning 生成）')
  const img = join(tmpRoot, 'frame.png')
  copyFileSync(FIXTURE, img)
  const { createDailyPipeline } = await import('../packages/plugins/coach/daily.mjs')
  const { createExtractor } = await import('../packages/plugins/coach/extract.mjs')
  const extractor = createExtractor({ dir: join(tmpRoot, 'data', 'coach'), trashDir: join(tmpRoot, 'data', 'trash'), router: router6 })
  const daily = createDailyPipeline({ dir: join(tmpRoot, 'data', 'coach'), router: router6, extractor })
  const rd = await daily.run({
    consentActive: true,
    frames: [{ imagePath: img, window: '文档/论文写作', process: '学习' }],
    goal: '微电网 MPC 调度研究',
  })
  check('F-7 端到端 daily.run：日报 score 为数字（非 unavailable），trajectoryCount=本轮新增行数',
    rd.ok === true && Number.isFinite(Number(rd.score)) && rd.score >= 0 && rd.score <= 100,
    JSON.stringify({ score: rd.score, trajectoryCount: rd.trajectoryCount, reportPath: rd.reportPath && String(rd.reportPath).split('\\').pop() }))
} catch (e) {
  check('F-0 验收异常', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  globalThis.fetch = realFetch
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}
const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s64-flagship: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exitCode = items.length - pass === 0 ? 0 : 1
