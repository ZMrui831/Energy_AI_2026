// tools/perception-run.mjs
//
// 感知层 S2 · 独立运行器（非插件，纯 Node 脚本）。
//
// 自己做：spawn collector.ps1（真实 PS 助手）→ 跑采样 / 事件 / 聚合 / 差分决策循环，
// 连续录 N 分钟（默认 30，--minutes 1 快速验证，--quick 缩短默认时长），产出：
//   · data/perception/events-*.jsonl  （立即落盘事件）
//   · data/perception/summary-*.jsonl （内存聚合批次）
//   · data/perception/accept/run-*.json（本次运行证据：事件数 / 批次 / 原图决策间隔统计）
//
// 关于"原图"：本脚本不依赖 Electron，无法真正截屏。它【忠实地按 sampler.decide 的
// 差分与截图闸门】算出"本应落原图"的每一次决策并记录时间戳，用相邻时间差统计来证明
// 节奏约束（每60s≤1 / 每20s≤1 / learning 下界20s）成立。真实截屏由 Electron 宿主内的
// 插件（index.mjs）完成。
//
// 用法：
//   node tools/perception-run.mjs [--minutes 30] [--state normal] [--quick]

import { existsSync, mkdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT, appendJsonl, safeWrite } from '../packages/core/src/safefs.mjs'
import { startCollector } from '../packages/plugins/perception/collector.mjs'
import { createEventRecorder } from '../packages/plugins/perception/events.mjs'
import { decide, isSensitive, LEARNING_MIN_INTERVAL_MS } from '../packages/plugins/perception/sampler.mjs'

const VALID_STATES = ['idle', 'normal', 'candidate', 'learning', 'dnd']

function parseArgs(argv) {
  const out = { minutes: 30, state: 'normal', quick: false }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]
    if (a === '--minutes') out.minutes = Number(argv[++i]) || out.minutes
    else if (a === '--state') {
      const s = argv[++i]
      out.state = VALID_STATES.includes(s) ? s : 'normal'
    } else if (a === '--quick') {
      out.quick = true
    }
  }
  if (out.quick && argv.indexOf('--minutes') === -1) out.minutes = 1
  return out
}

function captureAllowed(cap, now, captureTimes, lastShotSavedTs) {
  const recent = captureTimes.filter((t) => now - t < 60000)
  if (now - lastShotSavedTs < cap.minIntervalMs) return false
  if (recent.length >= cap.maxPerMinute) return false
  return true
}

function intervalStats(times) {
  if (times.length < 2) return { count: times.length, minGapMs: null, maxGapMs: null, meanGapMs: null }
  const gaps = []
  for (let i = 1; i < times.length; i++) gaps.push(times[i] - times[i - 1])
  return {
    count: times.length,
    minGapMs: Math.min(...gaps),
    maxGapMs: Math.max(...gaps),
    meanGapMs: Math.round(gaps.reduce((a, b) => a + b, 0) / gaps.length),
  }
}

async function main() {
  const args = parseArgs(process.argv.slice(2))
  const startTs = Date.now()
  const processStartedAt = startTs
  const endTs = startTs + args.minutes * 60_000

  const recorder = createEventRecorder()
  let events = 0
  // 统计：原图决策（应落原图）时间戳与敏感拒采
  const captureTimes = []
  let lastShotSavedTs = 0
  let lastDiffTs = 0
  let captureDecisions = 0
  let rejectedSensitive = 0
  let samples = 0

  const collector = startCollector({
    onSample: (s) => {
      samples += 1
      const t = Date.now()
      const sensitive = isSensitive(s.title, s.process, undefined)
      const decision = decide(args.state, { sensitive }, {
        coldStart: true,
        processStartedAt,
        now: t,
      })
      // 事件（立即落盘）+ 聚合（批次）
      const r = recorder.tick({
        ts: s.ts,
        pid: s.pid,
        hwnd: s.hwnd,
        process: s.process,
        title: s.title,
        idleMs: s.idleMs,
        isFullscreen: s.isFullscreen,
        state: args.state,
        consent: 'session',
      })
      events += r.events.length
      // —— 原图决策（不应真正截屏，仅统计节奏）——
      const cap = decision.capture
      if (cap.enabled && !sensitive && t - lastDiffTs >= decision.diffMs) {
        lastDiffTs = t
        if (captureAllowed(cap, t, captureTimes, lastShotSavedTs)) {
          captureDecisions += 1
          captureTimes.push(t)
          lastShotSavedTs = t
        }
      } else if (cap.enabled && sensitive) {
        rejectedSensitive += 1
      }
    },
  })

  // 主循环：到点停止
  await new Promise((resolve) => {
    const timer = setInterval(() => {
      if (Date.now() >= endTs) {
        clearInterval(timer)
        resolve()
      }
    }, 500)
  })

  collector.stop()
  recorder.flush()

  const stats = intervalStats(captureTimes)
  const summary = {
    ts: new Date().toISOString(),
    state: args.state,
    plannedMinutes: args.minutes,
    actualMs: Date.now() - startTs,
    samples,
    eventsWritten: events,
    summaryBatches: countSummaryBatches(startTs),
    captureDecisions,
    rejectedSensitive,
    captureIntervalStats: stats,
    learningMinIntervalMs: LEARNING_MIN_INTERVAL_MS,
    note: '本脚本不依赖 Electron，无法真实截屏；captureDecisions 为按 sampler.decide 闸门算出的"本应落原图"决策数，用于验证节奏约束（每60s≤1 / learning 下界20s）。',
  }

  const acceptDir = join(PROJECT_ROOT, 'data', 'perception', 'accept')
  if (!existsSync(acceptDir)) mkdirSync(acceptDir, { recursive: true })
  const evidencePath = join(acceptDir, `run-${startTs}.json`)
  safeWrite(evidencePath, JSON.stringify(summary, null, 2))

  // 控制台汇总
  console.log('=== perception-run 汇总 ===')
  console.log(`状态: ${summary.state}  计划: ${summary.plannedMinutes}min  实际: ${(summary.actualMs / 1000).toFixed(1)}s`)
  console.log(`采样数: ${samples}  事件落盘: ${events}  批次: ${summary.summaryBatches}`)
  console.log(`应落原图决策: ${captureDecisions}  敏感拒采: ${rejectedSensitive}`)
  console.log(`原图间隔统计: ${JSON.stringify(stats)}`)
  console.log(`证据: ${evidencePath}`)
  return summary
}

function countSummaryBatches(sinceTs) {
  // 精确计数：读当天的 summary-YYYYMMDD.jsonl，统计 ts >= sinceTs 的批次行数。
  // （旧实现按时长估算，属于掺水证据，已改为真实计数。）
  try {
    const d = new Date(sinceTs)
    const ymd = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}`
    const p = join(PROJECT_ROOT, 'data', 'perception', `summary-${ymd}.jsonl`)
    if (!existsSync(p)) return 0
    const lines = readFileSync(p, 'utf8').split('\n').filter(Boolean)
    return lines.filter((l) => {
      try { return JSON.parse(l).ts >= sinceTs } catch { return false }
    }).length
  } catch {
    return 0
  }
}

main().then(
  () => process.exit(0),
  (e) => {
    console.error('[perception-run] 失败:', e && e.message)
    process.exit(1)
  },
)
