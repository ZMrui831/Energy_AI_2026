// tools/accept-s39-voice-card.mjs —— S39·F4 语音隐私开关+状态卡验收（≥6 项）。
// 单行复跑：node tools\accept-s39-voice-card.mjs
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

process.env.ORB_LOG_DIR = join(tmpdir(), 's39-vc-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's39-vc-data-' + Date.now())
const { dataPath } = await import('../packages/core/src/safefs.mjs')
const { readVoiceConfig, writeVoiceConfig, setVoiceEnabled, gatedTranscribe, voiceStatusCard } = await import('../packages/core/src/voice-settings.mjs')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

const auditRows = () => {
  const f = join(process.env.ORB_LOG_DIR, 'coach.jsonl')
  try { return readFileSync(f, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)) } catch { return [] }
}

try {
  // F4-1 默认全关
  const c0 = readVoiceConfig()
  check('F4-1 默认关（enabled/retainAudio=false）', c0.enabled === false && c0.retainAudio === false,
    `enabled=${c0.enabled} retainAudio=${c0.retainAudio}`, {})

  // F4-2 关时拒录（明确提示）+ 审计行
  const refused = gatedTranscribe({}, { transcribe: () => ({ ok: true, text: '不该被调用' }) })
  const refusedAudit = auditRows().some((r) => r.kind === 'voice-refused')
  check('F4-2 关时拒录+审计', refused.ok === false && refused.code === 'E_VOICE_DISABLED' && /已关闭/.test(refused.reason) && refusedAudit,
    `code=${refused.code} audit=${refusedAudit}`, {})

  // F4-3 开启首弹一次说明（explainedOn 记忆位）
  const on1 = setVoiceEnabled(true)
  const on2 = setVoiceEnabled(true)
  check('F4-3 开启首弹一次说明', on1.firstTime === true && typeof on1.briefing === 'string' && on1.briefing.length > 10 && on2.firstTime === false,
    `first=${on1.firstTime} second=${on2.firstTime}`, {})

  // F4-4 开启后可录一次（闸放行）
  let called = false
  const passed = gatedTranscribe({ wav: 'x.wav' }, { transcribe: () => { called = true; return { ok: true, text: '转写结果' } } })
  check('F4-4 开启后可录（闸放行）', passed.ok === true && called === true && passed.text === '转写结果',
    `called=${called}`, {})

  // F4-5 状态卡文案（麦克风按住说话时开 / 音频不落盘 / 无常驻）
  const card = voiceStatusCard(readVoiceConfig())
  check('F4-5 状态卡文案', card.includes('按住说话时开') && card.includes('不落盘') && card.includes('无（明确不做）'),
    `card 行数=${card.split('\n').length}`, {})

  // F4-6 不落盘：retainAudio 默认 false → 播后删契约（关闭后拒录 + retainAudio 保持 false）
  const off = setVoiceEnabled(false)
  const refused2 = gatedTranscribe({}, { transcribe: () => ({ ok: true, text: 'x' }) })
  check('F4-6 关后拒录+音频仍不落盘', off.config.enabled === false && off.config.retainAudio === false && refused2.ok === false,
    `enabled=${off.config.enabled} retainAudio=${off.config.retainAudio}`, {})

  // F4-7 toggle 审计行（voice-toggle）
  const toggleAudit = auditRows().filter((r) => r.kind === 'voice-toggle')
  check('F4-7 toggle 审计行', toggleAudit.length >= 3, `toggles=${toggleAudit.length}`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's39-voice-card-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s39-voice-card: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
