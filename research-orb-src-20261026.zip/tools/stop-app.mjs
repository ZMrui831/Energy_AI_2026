// tools/stop-app.mjs —— 用户**显式**调用的"停止 research-orb 应用"入口
//
// 与验收脚本的区别（重要）：
//   · 验收脚本（accept-*）**绝不**按 app 路径通配杀进程——那会误杀用户正在跑的实例（S74c·P0-1 实测 5 次）；
//   · 本工具是用户主动要求"停掉本应用"，杀掉本项目的 electron 实例就是它的**功能**，
//     但仍然只杀"命令行属于本项目"的 electron 实例，其它 electron / Edge 一律不碰。
// 查询口径统一走 _orb-proc.listOrbAll（只读列举），本文件不再内嵌 PowerShell 筛选串。

import { execFileSync } from 'node:child_process'
import { listOrbAll } from './_orb-proc.mjs'

function list() {
  return listOrbAll() // [{pid, name, commandLine}]，只读
}

const found = list()
if (found.length === 0) {
  console.log('[research-orb] 没有正在运行的本应用进程（其它 electron/Edge 进程未被检查、更未被触碰）')
  process.exit(0)
}
console.log('[research-orb] 将停止以下进程（判据：electron 实例且命令行属于本项目）：')
for (const p of found) console.log('  pid=' + p.pid + '  ' + String(p.commandLine).slice(0, 130))
for (const p of found) {
  try { execFileSync('taskkill', ['/PID', String(p.pid), '/T', '/F'], { stdio: 'ignore' }) } catch { /* 已退出 */ }
}
console.log('[research-orb] 停止完成；剩余本应用进程 = ' + list().length)
