// tools/clean-test-residue.mjs
//
// S33·D 测试残留清理：把"跑测试会留下的垃圾"变成可一键清、可幂等、可取证的动作。
// 清理对象（只清明确属于测试的）：
//   · packages/plugins/test-b4-*          （skill-installer 安装测试残留）
//   · packages/plugins/.retired/test-b4-*  （retire 测试残留）
//   · data/tmp/<name> 且 name 以 test- / probe- / s2 开头（测试临时目录）
// 纪律：只清这些名字；其它一律不碰。删除走 3 次/300ms 重试（Windows 文件锁）。
//
// 用法：
//   node tools/clean-test-residue.mjs            # 清理并打印前后文件数
//   也可被 run-tests.mjs 在开头 import 调用。
import { existsSync, mkdirSync, readdirSync, renameSync, rmSync, statSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = dirname(fileURLToPath(import.meta.url))
export const PROJECT_ROOT = resolve(__dirname, '..')

const RETRY_DELAYS_MS = [300, 300]
function sleepSync(ms) {
  try { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms) } catch { const t = Date.now() + ms; while (Date.now() < t) { /* busy */ } }
}
function renameAside(p, root) {
  try {
    const tmp = join(root, 'data', 'tmp', '_sktrash')
    mkdirSync(tmp, { recursive: true })
    renameSync(p, join(tmp, Date.now() + '-' + p.replace(/.*[\\/]/, '')))
    return true
  } catch { return false }
}
function rmRetry(p) {
  let last = null
  for (let i = 0; i <= RETRY_DELAYS_MS.length; i++) {
    try { rmSync(p, { recursive: true, force: true }); return true } catch (e) {
      last = e
      if (i === RETRY_DELAYS_MS.length) break
      sleepSync(RETRY_DELAYS_MS[i])
    }
  }
  return last ? false : true
}
function countFiles(p) {
  if (!existsSync(p)) return 0
  let s
  try { s = statSync(p) } catch { return 0 }
  if (!s.isDirectory()) return 1
  let n = 0
  try { for (const c of readdirSync(p)) n += countFiles(join(p, c)) } catch { /* 读不到跳过 */ }
  return n
}

/** 是否属于测试临时目录（data/tmp 下只清这些前缀）。 */
export const isTestTmpName = (n) => /^(test-|probe-|s2|pr6-)/.test(String(n))

/** 固定名的测试临时目录（不属于 data/tmp 前缀规则的）。 */
const FIXED_TEST_DIRS = ['data/.tmp-chart-test', 'data/.tmp-music-test']

/** 收集需要清理的目标（绝对路径）。 */
export function collectResidue(root = PROJECT_ROOT) {
  const pluginsDir = join(root, 'packages', 'plugins')
  const retiredDir = join(pluginsDir, '.retired')
  const tmpDir = join(root, 'data', 'tmp')
  const targets = []
  if (existsSync(pluginsDir)) {
    for (const n of readdirSync(pluginsDir)) if (n.startsWith('test-b4-')) targets.push(join(pluginsDir, n))
  }
  if (existsSync(retiredDir)) {
    for (const n of readdirSync(retiredDir)) if (n.startsWith('test-b4-')) targets.push(join(retiredDir, n))
  }
  if (existsSync(tmpDir)) {
    for (const n of readdirSync(tmpDir)) if (isTestTmpName(n)) targets.push(join(tmpDir, n))
  }
  const skTrash = join(root, 'packages', '.skill-test-trash')
  if (existsSync(skTrash)) targets.push(skTrash)
  return targets
}

/**
 * 清理残留。
 * @returns {{before:number, after:number, removed:string[], remaining:string[], dryRun:boolean}}
 */
export function cleanResidue({ root = PROJECT_ROOT, dryRun = false } = {}) {
  const targets = collectResidue(root)
  const before = targets.reduce((a, p) => a + countFiles(p), 0)
  if (!dryRun) for (const p of targets) { if (!rmRetry(p) && existsSync(p)) renameAside(p, root) }
  const remainingTargets = dryRun ? targets : collectResidue(root)
  const after = remainingTargets.reduce((a, p) => a + countFiles(p), 0)
  return { before, after, removed: targets.map((p) => p.replace(/^.*[\\/]/, '')), remaining: remainingTargets.map((p) => p.replace(/^.*[\\/]/, '')), dryRun }
}

/**
 * S33：释放陈旧文件锁。Windows 文件监视会把测试要重写的真实运行时状态（config/demo/hello/packs journal）
 * 锁住，导致 EPERM。这里把**可重建**的目标重命名进 data/tmp（rename 对锁文件仍可用），
 * 让测试从干净、可写状态开始；下次 run-tests 的 cleanResidue 会统一清掉这些 test-lockrel-*。
 * @returns {string[]} 被释放的相对路径
 */
export const RELEASABLE = ['data/config.json', 'data/notes/hello', 'data/demo']
export function releaseStaleLocks({ root = PROJECT_ROOT } = {}) {
  const tmp = join(root, 'data', 'tmp')
  mkdirSync(tmp, { recursive: true })
  const rels = [...RELEASABLE]
  const packsDir = join(root, 'data', 'packs')
  if (existsSync(packsDir)) {
    for (const p of readdirSync(packsDir)) {
      const j = join(packsDir, p, 'journal.jsonl')
      if (existsSync(j)) rels.push(join('data', 'packs', p, 'journal.jsonl'))
    }
  }
  const moved = []
  for (const rel of rels) {
    const src = join(root, rel)
    if (!existsSync(src)) continue
    const dest = join(tmp, `test-lockrel-${rel.replace(/[\\/]/g, '_')}-${Date.now()}`)
    try { renameSync(src, dest); moved.push(rel) } catch { /* 留在原地（非致命） */ }
  }
  return moved
}

const isMain = (() => {
  try { return process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url)) } catch { return false }
})()

if (isMain) {
  const r = cleanResidue({ root: process.argv[2] ? resolve(process.argv[2]) : PROJECT_ROOT })
  console.log(`[clean-test-residue] 清理前文件数=${r.before} 清理后文件数=${r.after} 移除条目=${r.removed.length}`)
  if (r.removed.length) console.log('  已移除：' + r.removed.join(', '))
  if (r.remaining.length) console.log('  仍残留（可能被占用）：' + r.remaining.join(', '))
  process.exit(0)
}

export default { PROJECT_ROOT, isTestTmpName, collectResidue, cleanResidue, releaseStaleLocks, RELEASABLE }
