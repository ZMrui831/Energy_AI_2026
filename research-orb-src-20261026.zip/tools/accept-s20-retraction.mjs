// tools/accept-s20-retraction.mjs
// S20·B 验收：① 命中 DOI 标 [已撤稿] ② 发布"已证实"→被拒且 code 明确 ③ 改假设语气→可保存 ④ 证据 JSON 落盘。
// 口径严守：只宣称"基于 Crossref/OpenAlex 元数据的撤稿标记检查"，不声称自动判撤稿。
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { parseRetraction, lookupRetraction, tagRetracted, assertRetractionGate, RetractionError } from '../packages/plugins/research-literature/connectors/retraction.mjs'

let pass = 0
let fail = 0
function check(name, cond, extra = '') {
  if (cond) { pass++; console.log('  [PASS]', name) }
  else { fail++; console.log('  [FAIL]', name, extra) }
}

async function main() {
  // 用真实预验证数据（B.1 已实测命中）离线复现，保证验收确定性
  const pre = JSON.parse(readFileSync(join(PROJECT_ROOT, 'data', 'logs', 's20-retraction-precheck.json'), 'utf8'))
  const locked = pre.locked
  const doi = locked.doi
  const crossrefMessage = { title: locked.fields.title_display ? undefined : 'RETRACTED: Wakefield MMR', is_retracted: locked.fields['is-retracted'] }
  // 用预验证里真实返回的字段重建 openalex work
  const openalexWork = { is_retracted: pre.candidates[0].openalex['is_retracted'] }

  // ① 命中 DOI 被标 [已撤稿]
  const parsed = parseRetraction({ crossrefMessage, openalexWork })
  check('预验证 DOI 判定为已撤稿', parsed.retracted === true, JSON.stringify(parsed))
  check('命中标记 = [已撤稿]', tagRetracted(parsed) === '[已撤稿]')

  // lookupRetraction（离线 mock，验证连接器可走通）
  const mockGet = async (url) => {
    if (url.includes('crossref')) return { message: crossrefMessage }
    if (url.includes('openalex')) return openalexWork
    return {}
  }
  const looked = await lookupRetraction(doi, { getJson: mockGet })
  check('lookupRetraction 返回 retracted=true', looked.retracted === true)
  check('lookupRetraction source 明确', looked.source === 'openalex' || looked.source === 'crossref')

  // ② 用它发布"已证实"→被拒且 code 明确
  let rejected = null
  try {
    assertRetractionGate({ doi, retracted: true, text: '该撤稿论文的结论已证实有效' })
  } catch (e) {
    if (e instanceof RetractionError) rejected = e
  }
  check('发布"已证实"被拒', !!rejected && rejected.code === 'E_RETRACTED_VERIFIED')
  check('拒绝带明确引导', !!rejected && /待核实|假设/.test(rejected.guidance))

  // ③ 改假设语气→可保存
  let saved = null
  try {
    saved = assertRetractionGate({ doi, retracted: true, text: '假设该撤稿论文结论存疑，待核实原始声明' })
  } catch (e) { saved = { threw: e.code } }
  check('假设语气可保存（未被拒）', saved && saved.ok === true && !saved.threw)

  // 非撤稿 DOI 不受限
  const okPlain = assertRetractionGate({ doi: '10.1234/x.y', retracted: false, text: '该论文已证实有效' })
  check('非撤稿 DOI 不受影响', okPlain.ok === true)

  // ④ 证据 JSON 落盘
  const evidence = {
    generatedAt: new Date().toISOString(),
    lockedDoi: doi,
    claim: '仅基于 Crossref/OpenAlex 元数据做撤稿标记检查；不替代人工核查，不声称自动判撤稿。',
    parseRetraction: parsed,
    lookupRetraction: { retracted: looked.retracted, source: looked.source },
    tag: tagRetracted(parsed),
    gate: {
      verifiedRejected: rejected ? { code: rejected.code, guidance: rejected.guidance } : null,
      hypotheticalSaved: saved && saved.ok === true,
    },
  }
  const dir = join(PROJECT_ROOT, 'data', 'logs')
  mkdirSync(dir, { recursive: true })
  writeFileSync(join(dir, 's20-retraction-accept.json'), JSON.stringify(evidence, null, 2), 'utf8')
  console.log('  证据 -> data/logs/s20-retraction-accept.json')

  // 最佳努力：真实联网复验一次（失败不计入失败，仅作旁证）
  try {
    const liveGet = async (url) => { const r = await fetch(url, { signal: AbortSignal.timeout(12000) }); return r.json() }
    const live = await lookupRetraction(doi, { getJson: liveGet })
    console.log('  [旁证] 真实联网 lookupRetraction:', live.retracted ? 'retracted=true' : 'retracted=false', 'source=' + (live.source || 'none'))
  } catch (e) {
    console.log('  [旁证] 真实联网跳过（环境无外网或限流）：', e.code || e.message)
  }

  console.log(`# accept-s20-retraction: total=${pass + fail} pass=${pass} fail=${fail}`)
  process.exit(fail ? 1 : 0)
}

main().catch((e) => { console.error('FATAL', e); process.exit(1) })
