// tools/accept-s63-merge.mjs —— S63·P1-2 "增量→轨迹"合并真实验证（4 项）
//
// 流程：隔离实例 → 写入 2 行假增量（带 structured）→ CDP 点设置页授权 → coach-trigger 逻辑发
//      /coach run-daily → 断言 ① incremental.jsonl 清空 ② trajectory 行数 +N ③ 日报更新
//      ④ usage 的 vision 行增量 ≤1（增量行不重复送模；那 1 次是 run-daily 自己的抓屏）。
// 用法：node tools\accept-s63-merge.mjs   （需真实 zhipu/deepseek key；应用不得已在跑）

import { spawn, spawnSync } from 'node:child_process'
import { mkdtempSync, rmSync, mkdirSync, writeFileSync, copyFileSync, existsSync, readFileSync, readdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import {mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-s63-merge')

const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const ELECTRON = ORB_ELECTRON
const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s63-merge-'))
process.env.ORB_DATA_DIR = join(tmpRoot, 'data')
const DATA = join(tmpRoot, 'data')
mkdirSync(join(DATA, 'logs'), { recursive: true })
mkdirSync(join(DATA, 'coach'), { recursive: true })
mkdirSync(join(DATA, 'trash'), { recursive: true })
mkdirSync(join(DATA, 'tmp'), { recursive: true })
try { if (existsSync(join(PROJECT_ROOT, 'data', 'themes'))) { rmSync(join(DATA, 'themes'), { force: true, recursive: true }); copyFileSync(join(PROJECT_ROOT, 'data', 'themes'), join(DATA, 'themes')) } } catch { /* 无就算 */ }
for (const f of ['secrets.json', 'providers.json', 'domains.json']) {
  const src = join(PROJECT_ROOT, 'data', f)
  const dst = join('packages', 'core', 'src', f)
  if (f === 'domains.json') continue
  if (existsSync(src)) copyFileSync(src, join(DATA, f))
}

const PORT = 9347
let child = null
let cdp = null
let saved = 0
const ev = async (cdp2, expr) => {
  const r = await cdp2.send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true })
  return r.result && r.result.value
}
const countLines = (p) => (existsSync(p) ? readFileSync(p, 'utf8').split('\n').filter((l) => l.trim()).length : 0)

const killOwn = () => spawnSync('powershell', ['-NoProfile', '-Command',
  "Get-CimInstance Win32_Process -Filter \"Name='electron.exe'\" | Where-Object { $_.CommandLine -like '*orb-s63-merge*' -or $_.CommandLine -like '*apps*desktop*main.mjs*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }; 'done'",
], { encoding: 'utf8', timeout: 20000 })

async function findTarget(timeoutMs = 45000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await res.json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(String(t.url || '')))
      if (page) return page
    } catch { /* 等 */ }
    await sleep(350)
  }
  return null
}
function cdpConnect(url) {
  const ws = new WebSocket(url)
  let id = 0
  const pending = new Map()
  ws.addEventListener('message', (ev) => {
    try { const m = JSON.parse(String(ev.data)); if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id) } } catch { /* noop */ }
  })
  const ready = new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', () => rej(new Error('ws-fail'))) })
  const send = (method, params = {}) => new Promise((res, rej) => {
    const mid = ++id
    pending.set(mid, (m) => (m.error ? rej(new Error(m.error.message)) : res(m.result)))
    ws.send(JSON.stringify({ id: mid, method, params }))
    setTimeout(() => { if (pending.has(mid)) { pending.delete(mid); rej(new Error('cdp-timeout')) } }, 60000)
  })
  return { ready, send, close: () => { try { ws.close() } catch { /* noop */ } } }
}

try {
  // 造两行假增量（结构化字段齐；textSha256 唯一 → evidenceKey 不与任何真实帧撞）
  const incFile = join(DATA, 'coach', 'incremental.jsonl')
  writeFileSync(incFile, [
    JSON.stringify({ ts: new Date().toISOString(), window: '文档/论文写作', process: '学习', frameId: 'fr-merge01', textSha256: 'merge-hash-01', text: '增量观测一：正在撰写微电网 MPC 两阶段调度方法章节。', structured: { app: '文档/论文写作', intent: '学习', topic: 'MPC 两阶段调度', entities: ['微电网', 'MPC'] }, source: 'zhipu' }),
    JSON.stringify({ ts: new Date().toISOString(), window: '文献检索', process: '学习', frameId: 'fr-merge02', textSha256: 'merge-hash-02', text: '增量观测二：检索 2024 年光伏并网预测文献。', structured: { app: '文献检索', intent: '学习', topic: '光伏并网预测', entities: ['光伏'] }, source: 'zhipu' }),
  ].join('\n'), 'utf8')

  // 启动隔离实例（与 accept-s51-e2e 同参数：--no-sandbox --remote-debugging-port）
  killOwn()
  await sleep(1500)
  const errTail = []
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE // 宿主环境可能带着它 → electron.exe 退化成 node（bad option --no-sandbox）
  delete env.ORB_LOG_DIR
  env.ORB_DATA_DIR = DATA
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')], {
    env,
    cwd: PROJECT_ROOT,
    stdio: ['ignore', 'pipe', 'pipe'],
  })
  if (child.stderr) child.stderr.on('data', (b) => { errTail.push(String(b)); if (errTail.length > 20) errTail.shift() })
  if (child.stdout) child.stdout.on('data', (b) => { errTail.push(String(b)); if (errTail.length > 20) errTail.shift() })
  const target = await findTarget()
  if (!target) throw new Error('隔离实例未起来（CDP 无 floating.html）：' + errTail.join('').slice(-400))
  cdp = cdpConnect(target.webSocketDebuggerUrl)
  await cdp.ready
  await cdp.send('Runtime.enable')
  // 等渲染层就绪 + 展开面板
  for (let i = 0; i < 40; i++) {
    const ok = await ev(cdp, 'typeof globalThis.__s5 === "object" && typeof globalThis.researchOrb === "object"')
    if (ok) break
    await sleep(500)
  }
  await ev(cdp, 'globalThis.researchOrb.send("window", { action: "expand" })')
  await sleep(2500)

  // 授权（设置页 → 授权屏幕记录）
  await ev(cdp, '(() => { const b = document.querySelector(\'#ro-ds-nav .ds-nav-btn[data-page="settings"]\'); if (b) b.click(); return 1 })()')
  await sleep(800)
  const granted = await ev(cdp, `(() => {
    const btns = Array.from(document.querySelectorAll('#ro-ds-settings button, #ro-ds-settings input, #panel button'))
    const b = btns.find((x) => /授权屏幕记录/.test(x.textContent || ''))
    if (b) { b.click(); return 'clicked' }
    return 'not-found'
  })()`)
  await sleep(1200)
  check('M-0 前置：授权已点（' + granted + '）', granted === 'clicked', granted)

  // before
  const trajBefore = countLines(join(DATA, 'coach', 'trajectory.jsonl'))
  const usagePath = join(DATA, 'logs', 'usage.jsonl')
  const visionBefore = existsSync(usagePath) ? readFileSync(usagePath, 'utf8').split('\n').filter((l) => l.trim()).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter((x) => x && x.tier === 'vision').length : 0
  const dailyBefore = existsSync(join(DATA, 'coach', 'daily')) ? readdirSync(join(DATA, 'coach', 'daily')).length : 0

  // 发 /coach run-daily（走真管线）
  await ev(cdp, `globalThis.researchOrb.send('ui', { type: 'plugin:command', name: 'coach', args: 'run-daily' })`)
  // 等合并发生（incremental.jsonl 消失）+ 日报轮完成（真调 summarize/score-plan 可能 10-40s）
  let merged = false
  for (let i = 0; i < 90; i++) {
    await sleep(1000)
    if (!existsSync(incFile)) { merged = true; break }
  }
  await sleep(8000)
  const trajAfter = countLines(join(DATA, 'coach', 'trajectory.jsonl'))
  const usageRows = existsSync(usagePath) ? readFileSync(usagePath, 'utf8').split('\n').filter((l) => l.trim()).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean) : []
  const visionAfter = usageRows.filter((x) => x.tier === 'vision').length
  const dailyFiles = existsSync(join(DATA, 'coach', 'daily')) ? readdirSync(join(DATA, 'coach', 'daily')) : []

  check('M-1 ① incremental.jsonl 合并后清空', merged === true || !existsSync(incFile), JSON.stringify({ merged }))
  check('M-2 ② trajectory 行数 +2（两行假增量并入账）', trajAfter >= trajBefore + 2, JSON.stringify({ before: trajBefore, after: trajAfter }))
  check('M-3 ③ 日报轮有产物（daily 目录文件数增加，trajectoryCount 含增量）', dailyFiles.length >= dailyBefore && dailyFiles.length > 0, JSON.stringify({ before: dailyBefore, files: dailyFiles.slice(0, 4) }))
  check('M-4 ④ 不重复送模（usage vision 行增量 ≤1：增量行走缓存合并，1 次为 run-daily 自身抓屏）',
    visionAfter - visionBefore <= 1, JSON.stringify({ before: visionBefore, after: visionAfter }))

  saved = 4
} catch (e) {
  check('M-0 验收异常', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  try { if (cdp) cdp.close() } catch { /* noop */ }
  killOwn()
  // S65：显式杀掉自己 spawn 的子进程 —— electron 存活时 node 事件循环不空转退出，
  // 之前靠 rmSync 拖垮实例"碰巧"退出，本轮实例挺住了 → 整趟 30 分钟无输出假死。
  try { if (child && !child.killed) { child.kill('SIGKILL') } } catch { /* 尽力 */ }
  await sleep(1200)
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}
const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s63-merge: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exitCode = items.length - pass === 0 ? 0 : 1
