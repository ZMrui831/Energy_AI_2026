// tools/probe-hotkey-altf4.mjs —— S45·P2 第 1 条：**先探后写**的探针。
//
// 单行复跑：node tools\probe-hotkey-altf4.mjs [--json]
//
// 为什么要先探：六单步第 3 步原设计用 Alt+F4 关自建窗口。如果 assertAllowedHotkey
// 对 alt+f4 直接抛错，就必须改路（click 关闭按钮 / backend close / WM_CLOSE 报批），
// 而且这条结论要写进 COMPUTER-USE-B.md —— **不许假装它通过了**。
//
// 纪律：
//   · **dry-run**：只调纯校验函数（assertAllowedHotkey / requireNormalizedPosition /
//     modelPositionToHid），**绝不调用** backend.hotkey / click / typeText —— 一个 HID
//     事件都不发，键盘鼠标状态不受影响；
//   · 只读：不写任何文件，不落截图；
//   · 路径遵循 DSH_ORB_PLUGIN，缺省走默认运行时安装目录。

import { readdirSync } from 'node:fs'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'

const PLUGIN = process.env.DSH_ORB_PLUGIN || `${process.env.USERPROFILE}//.dsh/profiles/desktop/node_modules/dsh-orb`
const CU_DIR = join(PLUGIN, 'dist', 'computer-use')

// ---------------------------------------------------------------- 加载（按函数名取导出）
function backendChunk() {
  let hit = []
  try {
    hit = readdirSync(CU_DIR).filter((f) => /^backend-.*\.js$/.test(f))
  } catch {
    hit = []
  }
  if (hit.length === 0) {
    console.error(`[probe] 找不到 backend-*.js -> ${CU_DIR}`)
    console.error('[probe] 请设置 DSH_ORB_PLUGIN=<已安装的 dsh-orb 目录>')
    process.exit(2)
  }
  return pathToFileURL(join(CU_DIR, hit[0])).href
}

const mod = await import(backendChunk())
const pick = (name) => Object.values(mod).find((v) => typeof v === 'function' && v.name === name)

const assertAllowedHotkey = pick('assertAllowedHotkey')
const requireNormalizedPosition = pick('requireNormalizedPosition')
const modelPositionToHid = pick('modelPositionToHid')

// ---------------------------------------------------------------- 探测：热键白名单
/** 逐个组合试两种调用形态（array / {keys}），把"是拒绝还是签名不对"区分开。 */
function tryAssert(fn, keys) {
  if (typeof fn !== 'function') return { ok: false, threw: false, note: '未提供 assertAllowedHotkey' }
  const shape = (v) => {
    if (v === undefined) return 'undefined'
    if (Array.isArray(v)) return `array(${v.length})`
    return typeof v
  }
  const out = []
  for (const via of ['array', 'object']) {
    try {
      const ret = via === 'array' ? fn(keys) : fn({ keys })
      out.push({ via, outcome: 'pass', ret: shape(ret) })
    } catch (e) {
      const msg = String((e && e.message) || e)
      out.push({
        via,
        outcome: 'throw',
        code: (e && e.code) || null,
        msg: msg.replace(/\s+/g, ' ').slice(0, 160),
      })
    }
  }
  // 两种形态都抛，且抛的不是"参数结构"问题 -> 判定为**真拒绝**
  const allThrow = out.every((o) => o.outcome === 'throw')
  const structLike = /Expected|must be|Invalid|type|undefined|not an object|Cannot read/i
  const structural = allThrow && out.every((o) => structLike.test(o.msg || ''))
  const passForm = out.find((o) => o.outcome === 'pass')
  return {
    ok: !!passForm,
    verdict: passForm ? 'ALLOWED' : structural ? 'UNKNOWN(signature)' : 'DENIED',
    via: passForm ? passForm.via : null,
    detail: out,
  }
}

const CASES = [
  ['alt', 'f4'],
  ['ctrl', 'a'],
  ['ctrl', 'c'],
  ['ctrl', 'v'],
  ['ctrl', 's'],
  ['ctrl', 'w'],
  ['alt', 'tab'],
  ['win', 'r'],
  ['ctrl', 'alt', 'delete'],
  ['ctrl', 'shift', 'esc'],
  ['alt'],
  ['f5'],
]

const hotkeyResults = CASES.map((keys) => ({
  keys: keys.join('+'),
  ...tryAssert(assertAllowedHotkey, keys),
}))

// ---------------------------------------------------------------- 探测：坐标校验与换算（纯函数）
function tryPure(fn, args) {
  if (typeof fn !== 'function') return { note: 'not provided' }
  try {
    const ret = fn(...args)
    return { ok: true, ret: JSON.stringify(ret) }
  } catch (e) {
    return { ok: false, code: (e && e.code) || null, msg: String((e && e.message) || e).slice(0, 160) }
  }
}

const BOUNDS = { x: 280, y: 89, width: 1360, height: 871 } // 实测的那块屏
const posCases = [
  ['居中 500,500', [500, 500]],
  ['左上 0,0', [0, 0]],
  ['右下 1000,1000', [1000, 1000]],
  ['越界 1001,500', [1001, 500]],
  ['越界 -1,500', [-1, 500]],
  ['非整数 500.5,500', [500.5, 500]],
]
const posResults = posCases.map(([label, p]) => ({ label, ...tryPure(requireNormalizedPosition, [p]) }))

const hidSamples = [0, 500, 1000].map((nx) => ({ nx, ...tryPure(modelPositionToHid, [[nx, nx], BOUNDS]) }))

// ---------------------------------------------------------------- 输出
const altF4 = hotkeyResults.find((r) => r.keys === 'alt+f4')
const allowed = hotkeyResults.filter((r) => r.verdict === 'ALLOWED').map((r) => r.keys)
const denied = hotkeyResults.filter((r) => r.verdict === 'DENIED').map((r) => r.keys)
const unknown = hotkeyResults.filter((r) => r.verdict !== 'ALLOWED' && r.verdict !== 'DENIED').map((r) => r.keys)

const jsonMode = process.argv.includes('--json')
if (jsonMode) {
  console.log(JSON.stringify({ plugin: PLUGIN, altF4, allowed, denied, unknown, posResults, hidSamples }, null, 2))
} else {
  console.log('=== S45·P2 第 1 条探针：assertAllowedHotkey 态度（dry-run，未发任何 HID 事件）===')
  console.log(`backend 目录：${CU_DIR}`)
  console.log('')
  console.log('-- 逐组合结果 --')
  for (const r of hotkeyResults) {
    const d = r.detail.filter((x) => x.outcome === 'throw').map((x) => `${x.via}:${x.code || x.msg}`).join(' | ')
    console.log(
      `  ${r.keys.padEnd(22)} ${String(r.verdict).padEnd(18)} ${r.verdict === 'ALLOWED' ? '(via ' + r.via + ')' : d}`,
    )
  }
  console.log('')
  console.log(`ALT+F4 结论：${altF4.verdict}`)
  console.log(`允许组合（${allowed.length}）：${allowed.join(', ') || '（无）'}`)
  console.log(`拒绝组合（${denied.length}）：${denied.join(', ') || '（无）'}`)
  if (unknown.length > 0) console.log(`签名不定（${unknown.length}）：${unknown.join(', ')}`)
  console.log('')
  console.log('-- 坐标校验 requireNormalizedPosition（0–1000 语义）--')
  for (const r of posResults) {
    console.log(`  ${r.label.padEnd(18)} ${r.ok ? '通过 ret=' + r.ret : '抛错 ' + (r.code || r.msg || r.note)}`)
  }
  console.log('')
  console.log('-- modelPositionToHid 换算抽样（纯函数，仅供对照）--')
  for (const s of hidSamples) console.log(`  nx=${String(s.nx).padEnd(5)} -> ${s.ok ? s.ret : '抛错 ' + (s.code || s.msg)}`)
  console.log('')
  console.log('-- assertAllowedHotkey 源码片段（看其内部允许清单）--')
  console.log(String(assertAllowedHotkey).slice(0, 1400))
}

process.exitCode = 0
