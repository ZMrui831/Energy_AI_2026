// tools/calls-from-usage.mjs —— S29·1.4 观测适配器：usage.jsonl（教练 LLM 调用）→ kit calls.jsonl schema。
// 单行复跑：node tools\calls-from-usage.mjs [--in data\logs\usage.jsonl] [--out data\logs\calls.jsonl]
//
// 映射口径（诚实，取不到写 null，不许编）：
//   tool        ← providerId（school-gateway / deepseek-api）
//   args        ← { taskClass, model }
//   returnBytes ← null（usage 不记返回字节）
//   truncated   ← false（LLM 调用不经工具截断层；banner 改造只覆盖工具结果）
//   shown/totalMatches ← null（非匹配类调用）
//   reportedTotal ← false（reportedTotal 语义是"截断时上报了总数"；本管线无截断 → false）
//   usage       ← { inputTokens: null（usage.jsonl 只记 total）, outputTokens: null, cacheReadTokens: null }
//                  + totalTokens（本项目自有字段，total>0 时透传；E1 只读上面五个字段，不影响判定）
// 注意：E1 判定的"截断诚实"主语是【工具调用】；本适配器覆盖 LLM 调用观测。
// 工具调用的截断观测以 accept-s29-leankit 的真实截断样例（truncated=true + reportedTotal=true）行注入。
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const argv = process.argv.slice(2)
const argOf = (name, def) => { const i = argv.indexOf(name); return i >= 0 && argv[i + 1] ? argv[i + 1] : def }
const IN = argOf('--in', join(PROJECT_ROOT, 'data', 'logs', 'usage.jsonl'))
const OUT = argOf('--out', join(PROJECT_ROOT, 'data', 'logs', 'calls.jsonl'))

let rows = []
try {
  rows = readFileSync(IN, 'utf8').split('\n').map((l) => l.trim()).filter(Boolean).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
} catch { /* 无文件则空 */ }

const out = rows.map((r) => ({
  tool: r.providerId || null,
  args: { taskClass: r.taskClass || null, model: r.model || null },
  returnBytes: null,
  truncated: false,
  shownMatches: null,
  totalMatches: null,
  reportedTotal: false,
  usage: {
    inputTokens: null,
    outputTokens: null,
    cacheReadTokens: null,
    ...(Number.isFinite(r.tokens) ? { totalTokens: r.tokens } : {}),
    ...(Number.isFinite(r.ms) ? { latencyMs: r.ms } : {}),
    ok: r.ok === true,
  },
}))

mkdirSync(join(OUT, '..'), { recursive: true })
writeFileSync(OUT, out.map((r) => JSON.stringify(r)).join('\n') + (out.length ? '\n' : ''), 'utf8')
console.log(`calls-from-usage: ${rows.length} 行 usage → ${out.length} 行 calls（${OUT}）`)
