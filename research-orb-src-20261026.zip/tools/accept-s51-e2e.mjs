// tools/accept-s51-e2e.mjs —— S51 交互级 E2E（真点击，不是 DOM 存在性检查）
//
// 单行复跑：node tools\accept-s51-e2e.mjs
//
// 这份验收的由来：s47-ui / s48-visual / s49-opacity 只证明"元素在、数值对"，
// 没一条证明"点了有反应"。B2（点哪都回轨迹）就是这个缺口放过去的。
// 所以这里**一律用真实点击 + 页面状态回读**，不许读源码字符串。

import { mkdtempSync, rmSync, cpSync, mkdirSync, writeFileSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import { spawn, spawnSync } from 'node:child_process'
import {killMarked, countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-s51-e2e')

const ELECTRON = ORB_ELECTRON
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9340
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 380) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}
const countProcs = () => countOrbAll()
const killOwn = () => killMarked(MARK)

async function findTarget(t = 40000) {
  const d = Date.now() + t
  while (Date.now() < d) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const l = await r.json()
      const p = l.find((x) => x.type === 'page' && x.webSocketDebuggerUrl && /floating\.html/i.test(String(x.url || '')))
      if (p) return p
    } catch { /* 等 */ }
    await sleep(350)
  }
  return null
}
function cdpConnect(wsUrl) {
  const ws = new WebSocket(wsUrl)
  let seq = 0
  const pending = new Map()
  const errors = []
  const ready = new Promise((res, rej) => { ws.addEventListener('open', () => res()); ws.addEventListener('error', () => rej(new Error('ws'))) })
  ws.addEventListener('message', (ev) => {
    let m = null
    try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
    if (m && m.method === 'Runtime.consoleAPICalled' && m.params && m.params.type === 'error') {
      errors.push((m.params.args || []).map((a) => a.value || a.description || '').join(' ').slice(0, 160))
    }
    if (!m || !m.id) return
    const p = pending.get(m.id); if (!p) return
    pending.delete(m.id)
    if (m.error) p.rej(new Error(JSON.stringify(m.error))); else p.res(m.result)
  })
  const send = (method, params) => new Promise((res, rej) => { const id = ++seq; pending.set(id, { res, rej }); ws.send(JSON.stringify({ id, method, params })) })
  return { ready, send, errors, close: () => { try { ws.close() } catch { /* noop */ } } }
}
async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r && r.exceptionDetails) throw new Error('ev: ' + JSON.stringify(r.exceptionDetails).slice(0, 200))
  return r && r.result ? r.result.value : undefined
}
const page = (cdp) => ev(cdp, 'window.__s5 && window.__s5.currentPage ? window.__s5.currentPage() : null')

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s51-e2e-'))
let child = null
let cdp = null
try {
  if (countProcs() > 0) {
    check('E-0 预检（已有实例在跑则退出）', false, '请先关闭 research-orb')
    throw new Error('preflight')
  }
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  delete env.ORB_LOG_DIR
  env.ORB_DATA_DIR = join(tmpRoot, 'data')
  // 主题保真（假绿教训）：隔离实例的临时数据目录里没有 themes\ → 应用回退 vendor 默认亮色，
  // 而真实用户跑的是 teal（--input-bg=#d1fae5）。复制项目真实 themes 让应用自己注入，
  // 否则所有颜色类断言都在错误的主题下跑。
  try { cpSync(join(PROJECT_ROOT, 'data', 'themes'), join(env.ORB_DATA_DIR, 'themes'), { recursive: true }) } catch { /* 无 themes 目录就算了 */ }
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], { cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] })
  const tail = []
  const push = (b) => { tail.push(String(b)); while (tail.length > 20) tail.shift() }
  if (child.stdout) child.stdout.on('data', push)
  if (child.stderr) child.stderr.on('data', push)

  const target = await findTarget()
  if (!target) { check('E-0 启动', false, 'CDP 未就绪：' + tail.join('').slice(-300)); throw new Error('no-target') }
  cdp = cdpConnect(target.webSocketDebuggerUrl)
  await cdp.ready
  await cdp.send('Runtime.enable')
  let bridge = false
  const dl = Date.now() + 30000
  while (Date.now() < dl) {
    try { bridge = await ev(cdp, 'typeof globalThis.__s5 === "object" && typeof globalThis.researchOrb === "object"'); if (bridge) break } catch { /* 等 */ }
    await sleep(400)
  }
  if (!bridge) { check('E-0 桥/路由就绪', false, '30s 未就绪'); throw new Error('no-bridge') }
  await ev(cdp, 'globalThis.researchOrb.send("window", { action: "expand" })')
  await sleep(1500)

  // ---------- E-1 六个导航逐个点击，且**停留 3 秒不回退**（B2 的判据）
  const NAV = [['home', '首页'], ['chat', '对话'], ['trajectory', '轨迹'], ['notes', '笔记'], ['publish', '发布'], ['settings', '设置']]
  const navResult = []
  for (const [key, label] of NAV) {
    await ev(cdp, `document.querySelector('#ro-ds-nav .ds-nav-btn[data-page="${key}"]').click()`)
    await sleep(350)
    const immediate = await page(cdp)
    await sleep(3000) // 关键：等 3 秒，看会不会被回包拽回去
    const after3s = await page(cdp)
    navResult.push({ key, label, immediate, after3s, ok: immediate === key && after3s === key })
  }
  const navBad = navResult.filter((r) => !r.ok)
  check('E-1 六个导航逐一点击 → 当前页正确且 3 秒不回退', navBad.length === 0,
    navBad.length ? JSON.stringify(navBad) : navResult.map((r) => r.key).join(' → ') + ' 全部稳定')

  // ---------- E-2 先到轨迹页再切走（复现 B2 的原始路径）
  await ev(cdp, 'document.querySelector(\'#ro-ds-nav .ds-nav-btn[data-page="trajectory"]\').click()')
  await sleep(2500)
  await ev(cdp, 'document.querySelector(\'#ro-ds-nav .ds-nav-btn[data-page="home"]\').click()')
  await sleep(3000)
  const back = await page(cdp)
  check('E-2 进过轨迹后切首页 ≥3 秒不回退', back === 'home', `3 秒后 page=${back}`)

  // ---------- E-3 对话页输入框可聚焦、可输入、可发送
  await ev(cdp, 'document.querySelector(\'#ro-ds-nav .ds-nav-btn[data-page="chat"]\').click()')
  await sleep(900)
  const composerBox = await ev(cdp, `(() => {
    const c = document.getElementById('composer')
    const p = document.getElementById('prompt')
    if (!c || !p) return JSON.stringify({ missing: true })
    const r = c.getBoundingClientRect(), pr = p.getBoundingClientRect()
    const cx = Math.round(pr.left + pr.width / 2), cy = Math.round(pr.top + pr.height / 2)
    const top = document.elementsFromPoint(cx, cy)[0]
    return JSON.stringify({ cw: Math.round(r.width), ch: Math.round(r.height), visible: r.width > 50 && r.height > 20,
      onTop: top ? (top.id || top.tagName) : null })
  })()`)
  const box = JSON.parse(composerBox || '{}')
  await ev(cdp, `(() => { const p = document.getElementById('prompt'); p.focus(); return document.activeElement === p })()`)
  const focused = await ev(cdp, 'document.activeElement && document.activeElement.id')
  check('E-3 对话页输入框可见、置顶、可聚焦', box.visible === true && box.onTop === 'prompt' && focused === 'prompt',
    `composer=${box.cw}×${box.ch} 点击命中=${box.onTop} activeElement=${focused}`)

  // ---------- E-7 对话洁净：切过轨迹/发布后，对话流里不得出现查询类回执（S52·对话净化）
  await ev(cdp, 'document.querySelector(\'#ro-ds-nav .ds-nav-btn[data-page="trajectory"]\').click()')
  await sleep(1800)
  await ev(cdp, 'document.querySelector(\'#ro-ds-nav .ds-nav-btn[data-page="publish"]\').click()')
  await sleep(1200)
  await ev(cdp, 'document.querySelector(\'#ro-ds-nav .ds-nav-btn[data-page="chat"]\').click()')
  await sleep(1200)
  const chatClean = JSON.parse(await ev(cdp, `(() => {
    const t = document.getElementById('transcript')
    if (!t) return JSON.stringify({ missing: true })
    // 只查**消息节点**（.ro-msg/.ro-notice/.ro-tool），不扫欢迎卡整体 ——
    // 欢迎卡的说明文本有 50KB，里面本来就会提到 timeline 功能，扫它必然误报。
    const nodes = Array.from(t.querySelectorAll('.ro-msg, .ro-notice, .ro-tool'))
    const hit = []
    for (const n of nodes) {
      const txt = (n.textContent || '')
      if (/轨迹（|今天还没有片段/.test(txt)) hit.push(txt.slice(0, 50))
    }
    return JSON.stringify({ nodes: nodes.length, hit: hit.slice(0, 4), welcome: !!t.querySelector('#ro-welcome-base') })
  })()`))
  check('E-7 对话洁净（切过轨迹/发布后，消息节点无查询回执）', chatClean.hit.length === 0,
    JSON.stringify(chatClean))

  // ---------- E-4 面板四角圆角且无灰边（inset=0 + 无 box-shadow）
  const shell = JSON.parse(await ev(cdp, `(() => {
    const p = document.getElementById('panel')
    const cs = getComputedStyle(p)
    return JSON.stringify({ radius: cs.borderRadius, shadow: cs.boxShadow, insetL: cs.left, insetT: cs.top, insetR: cs.right, insetB: cs.bottom, ov: cs.overflow })
  })()`))
  const zeroInset = ['0px', '0'].includes(String(shell.insetL)) && ['0px', '0'].includes(String(shell.insetT))
  const noShadow = !shell.shadow || shell.shadow === 'none'
  check('E-4 面板四角圆角 36px + 贴满窗口 + 无外阴影（无灰边）',
    String(shell.radius).startsWith('36px') && zeroInset && noShadow && shell.ov === 'hidden',
    `radius=${shell.radius} inset=(${shell.insetL},${shell.insetT}) shadow=${shell.shadow} overflow=${shell.ov}`)

  // ---------- E-5 诊断块幂等：同类行 ≤1
  await ev(cdp, 'document.querySelector(\'#ro-ds-nav .ds-nav-btn[data-page="home"]\').click()')
  await sleep(700)
  const diag = JSON.parse(await ev(cdp, `(() => {
    const d = document.getElementById('ro-ds-diag')
    if (!d) return JSON.stringify({ missing: true })
    const texts = Array.from(d.querySelectorAll('.ro-pill')).map((p) => (p.textContent || '').trim())
    const perms = d.querySelectorAll('#permission').length
    // 幂等的正确判据：**去重后数量 == 总数**（同类行恰好 1 条）。
    // 按 pill 总条数比大小是错的：限速/未降级/provider 本来就是三类不同指标。
    return JSON.stringify({ total: texts.length, unique: new Set(texts).size, texts, perms })
  })()`))
  check('E-5 诊断块幂等（同类行恰好 1 条，无重复注入）',
    diag.total === undefined || diag.total === diag.unique, JSON.stringify(diag))

  // ---------- E-8 P0-3 球胶囊：面板态 28px、在标题栏行内、可点、不压内容
  const ball = JSON.parse(await ev(cdp, `(() => {
    const b = document.getElementById('ball')
    if (!b) return JSON.stringify({ missing: true })
    const cs = getComputedStyle(b)
    const r = b.getBoundingClientRect()
    const panel = document.getElementById('panel')
    const pr = panel.getBoundingClientRect()
    const cx = Math.round(r.left + r.width / 2), cy = Math.round(r.top + r.height / 2)
    const hit = document.elementFromPoint(cx, cy)
    const main = document.getElementById('ro-s5')
    const mr = main ? main.getBoundingClientRect() : pr
    return JSON.stringify({
      w: Math.round(r.width), h: Math.round(r.height), radius: cs.borderRadius,
      top: Math.round(r.top), right: Math.round(r.right),
      inTitleRow: r.top >= pr.top - 2 && r.bottom <= pr.top + 60,
      // "内容区"指**标题栏以下**（标题栏 40px）。球吸附在标题栏右端（DESIGN §6：与音符/关闭同排），
      // 压在标题栏行内不算压内容；只有底部超出标题栏行才算。
      overlapsContent: r.bottom > pr.top + 52,
      clickable: hit === b || (hit && hit.closest && !!hit.closest('#ball')),
      z: cs.zIndex,
    })
  })()`))
  // S57·B：容差判据 —— 实测 29（28px 设计值 + 1px 边框 + dpr 1.06 取整），功能无缺陷。
  check('E-8 P0-3 面板态球 28px 圆点（含边框容差 26–31）、在标题栏行内、可点、不压内容区',
    ball.w >= 26 && ball.w <= 31 && ball.h >= 26 && ball.h <= 31 &&
    String(ball.radius) === '999px' &&
    ball.inTitleRow === true && ball.clickable === true && ball.overlapsContent === false,
    JSON.stringify(ball))

  // ---------- E-9 B3 主动作不许静默：点「问屏幕」后必须有明确反馈
  await ev(cdp, 'document.querySelector(\'#ro-ds-nav .ds-nav-btn[data-page="home"]\').click()')
  await sleep(700)
  const clicked = await ev(cdp, `(() => {
    const bs = Array.from(document.querySelectorAll('#s5-home .s5-act, #s5-home button'))
    const b = bs.find((x) => /问屏幕/.test(x.textContent || ''))
    if (!b) return false
    b.click()
    return true
  })()`)
  await sleep(1800)
  const feedback = await ev(cdp, `(() => {
    const nodes = Array.from(document.querySelectorAll('[role="status"], #s5-notice, .s5-notice, .ro-notice'))
      .map((n) => (n.textContent || '').trim())
      .filter(Boolean)
    return nodes.find((t) => /问屏幕|已抓一帧|草稿/.test(t)) || null
  })()`)
  // 判据注（S54）：改名 'ui'->'panel' 后「问屏幕」真链路复活 —— 真抓屏成功时回包反馈为
  // 「已抓一帧并生成草稿…」（不含"问屏幕"字样），比 wireAction 的 1.2s 兜底文案更真实。
  // B3 的意图是"不静默"：两种反馈（本地兜底 / 真实结果）都算过。
  check('E-9 B3 主动作有明确反馈（不静默）', clicked === true && !!feedback,
    `按钮命中=${clicked} 反馈=${JSON.stringify(feedback)}`)

  // ---------- E-10 可见空态都必须带一个动作按钮（B10 的一半：给下一步）
  const empty = JSON.parse(await ev(cdp, `(() => {
    const nodes = Array.from(document.querySelectorAll('[data-empty-state]')).filter((n) => !n.hidden)
    return JSON.stringify({
      n: nodes.length,
      allHaveBtn: nodes.every((x) => !!x.querySelector('button')),
      texts: nodes.map((x) => ((x.querySelector('.ds-empty-text') || {}).textContent || '').slice(0, 44)),
    })
  })()`))
  check('E-10 可见空态均含动作按钮（给下一步）', empty.n > 0 && empty.allHaveBtn === true, JSON.stringify(empty))

  // ---------- E-11 T1-a 输入框让开左导航；prompt 中心与左缘命中均为 prompt
  //    （S53 后用户仍反馈"遮挡没被消除"；命中栈实测：导航 z=6 盖住 composer 左缘 28px、
  //     prompt 左缘 16px，点输入框左侧实际命中导航。修法：composer left:16 → 64。）
  await ev(cdp, 'document.querySelector(\'#ro-ds-nav .ds-nav-btn[data-page="chat"]\').click()')
  await sleep(900)
  const t1a = JSON.parse(await ev(cdp, `(() => {
    const c = document.getElementById('composer'), p = document.getElementById('prompt'), n = document.getElementById('ro-ds-nav')
    if (!c || !p || !n) return JSON.stringify({ missing: true })
    const cr = c.getBoundingClientRect(), pr = p.getBoundingClientRect(), nr = n.getBoundingClientRect()
    const cx = Math.round(pr.left + pr.width / 2), cy = Math.round(pr.top + pr.height / 2)
    const lx = Math.round(pr.left + 2), ly = cy
    const topC = document.elementFromPoint(cx, cy), topL = document.elementFromPoint(lx, ly)
    return JSON.stringify({
      composerLeft: Math.round(cr.left), navRight: Math.round(nr.right),
      clearsNav: cr.left >= nr.right,
      centerTop: topC ? (topC.id || topC.tagName) : null,
      leftTop: topL ? (topL.id || topL.tagName) : null,
    })
  })()`))
  check('E-11 T1-a 输入框让开左导航（composer 左缘 ≥ 导航右缘；中心/左缘命中 = prompt）',
    t1a.clearsNav === true && t1a.centerTop === 'prompt' && t1a.leftTop === 'prompt',
    JSON.stringify(t1a))

  // ---------- E-12 T1-b/c 标题行 chrome 可点且深色
  //    （修复前：球 z=8 盖住「+」钮、#history 整个藏在导航身后；三个 28px 圆钮在 teal 主题
  //    是 --input-bg 薄荷绿亮块。另：顶栏透明但可命中会拦截按钮点击 → pointer-events:none。）
  const t1b = JSON.parse(await ev(cdp, `(() => {
    const hit = (el) => { if (!el) return null; const r = el.getBoundingClientRect()
      const t = document.elementFromPoint(Math.round(r.left + r.width / 2), Math.round(r.top + r.height / 2))
      if (!t) return null
      if (t === el) return el.id
      if (el.id && t.closest && t.closest('#' + el.id) === el) return el.id
      return t.id || t.tagName }
    const dark = (el) => { if (!el) return null; const m = /rgba?\\((\\d+),\\s*(\\d+),\\s*(\\d+)/.exec(getComputedStyle(el).backgroundColor)
      return m ? Math.max(+m[1], +m[2], +m[3]) : null }
    const nc = document.getElementById('new-conversation'), h = document.getElementById('history'), mb = document.getElementById('ro-music-btn')
    return JSON.stringify({
      ncHit: hit(nc), hHit: hit(h), mbHit: hit(mb), ballHit: hit(document.getElementById('ball')),
      ncDark: dark(nc), hDark: dark(h), mbDark: dark(mb),
    })
  })()`))
  check('E-12 T1-b/c 标题行 chrome 命中自身或子孙且为深色（无薄荷绿/白亮块，max 通道 ≤ 80）',
    t1b.ncHit === 'new-conversation' && t1b.hHit === 'history' && t1b.mbHit === 'ro-music-btn' && t1b.ballHit === 'ball' &&
    [t1b.ncDark, t1b.hDark, t1b.mbDark].every((v) => v !== null && v <= 80),
    JSON.stringify(t1b))

  // ---------- E-13 T1-d 对话页顶栏钉在标题行（修复前 #ro-s5 是 panel 末个流内子元素，
  //    transcript 满高后顶栏被挤到输入框正上方）
  const t1d = JSON.parse(await ev(cdp, `(() => {
    const t = document.getElementById('ro-s5-topbar'), c = document.getElementById('composer')
    const tr = t.getBoundingClientRect(), cr = c.getBoundingClientRect()
    return JSON.stringify({ top: Math.round(tr.top), bottom: Math.round(tr.bottom), stripTop: Math.round(cr.top) })
  })()`))
  check('E-13 T1-d 对话页顶栏在标题行且不压输入条', t1d.top < 60 && t1d.bottom <= t1d.stripTop, JSON.stringify(t1d))

  // ---------- E-14 T1-e 空输入框不常驻滚动条（1px 边框使占位 ::after 永久溢出 2px）
  const t1e = JSON.parse(await ev(cdp, `(() => {
    const p = document.getElementById('prompt')
    return JSON.stringify({ scrollH: p.scrollHeight, clientH: p.clientHeight })
  })()`))
  check('E-14 T1-e 空输入框无滚动条（scrollHeight ≤ clientHeight）',
    t1e.scrollH <= t1e.clientH + 1, JSON.stringify(t1e))

  // ---------- E-15 B4 深色断言：面板内（含伪元素 + panel/body/documentElement 自身）
  //    无近白计算背景。教训：computedStyle 是唯一可信层；teal 下 --white 映射 panel 深色，
  //    但谁要用字面 #fff 就会露白块 —— 扫计算值而不是源码。亮度 > 0.92 即亮块。
  const t3 = JSON.parse(await ev(cdp, `(() => {
    const lum = (bg) => {
      if (!bg) return null
      const m = /rgba?\\(([^)]+)\\)/.exec(bg)
      if (!m) return null
      const a = m[1].split(',').map((x) => Number(x.trim()))
      if (a.length >= 4 && a[3] === 0) return null
      return (0.299 * (a[0] || 0) + 0.587 * (a[1] || 0) + 0.114 * (a[2] || 0)) / 255
    }
    const bad = []
    const scan = (el, pseudo) => {
      if (!el) return
      let cs
      try { cs = getComputedStyle(el, pseudo || null) } catch { return }
      const L = lum(cs.backgroundColor)
      if (L === null) return
      const r = el.getBoundingClientRect()
      if (r.width < 1 || r.height < 1) return
      if (cs.display === 'none' || cs.visibility === 'hidden') return
      if (L > 0.92) bad.push({ tag: el.tagName, id: el.id || '', cls: String(el.className || '').slice(0, 40), pseudo: pseudo || '', bg: cs.backgroundColor, L: Number(L.toFixed(3)) })
    }
    const panel = document.getElementById('panel')
    for (const el of panel.querySelectorAll('*')) { scan(el); scan(el, '::before'); scan(el, '::after') }
    scan(panel); scan(panel, '::before'); scan(panel, '::after')
    scan(document.body); scan(document.documentElement)
    return JSON.stringify({ badCount: bad.length, bad: bad.slice(0, 6) })
  })()`))
  check('E-15 B4 面板内无近白背景（亮度 ≤ 0.92，含伪元素）', t3.badCount === 0, JSON.stringify(t3))

  // ---------- E-16 B6 内容超高容器必须真的可滚（当前 s5 页 + 诊断体 + 权限卡）
  //    教训：CSS 选择器里的 .ro-welcome-body/.ro-choice 在 DOM 中不存在（旧残留），探针不能照抄 CSS。
  //    语义：scrollHeight > clientHeight + 4 时滚到底后 scrollTop > 0；内容不超高则不适用。
  const t4 = JSON.parse(await ev(cdp, `(async () => {
    const sleep2 = (ms) => new Promise((r) => setTimeout(r, ms))
    const measure = (sel) => {
      const n = document.querySelector(sel)
      if (!n) return null
      const cs = getComputedStyle(n)
      if (cs.display === 'none' || n.getBoundingClientRect().height < 1) return null
      const overflow = n.scrollHeight - n.clientHeight
      let rolled = null
      if (overflow > 4) { n.scrollTop = n.scrollHeight; rolled = n.scrollTop > 0 }
      return { sel, scrollH: n.scrollHeight, clientH: n.clientHeight, overflow, rolled }
    }
    const items2 = []
    const home = measure('.s5-page.s5-on')
    if (home) items2.push(home)
    const navBtn = document.querySelector('#ro-ds-nav .ds-nav-btn[data-page="settings"]')
    if (navBtn) {
      navBtn.click(); await sleep2(400)
      const d = document.getElementById('ro-ds-diag')
      if (d && !d.open) d.open = true
      await sleep2(200)
      for (const sel of ['#ro-ds-diag .ds-diag-body', '#ro-ds-diag #permission']) {
        const m = measure(sel)
        if (m) items2.push(m)
      }
      const homeBtn = document.querySelector('#ro-ds-nav .ds-nav-btn[data-page="home"]')
      if (homeBtn) { homeBtn.click(); await sleep2(300) }
    }
    return JSON.stringify({ n: items2.length, items: items2, allOk: items2.length >= 2 && items2.every((x) => x.rolled === null || x.rolled === true) })
  })()`))
  check('E-16 B6 超高容器可滚（滚到底后 scrollTop > 0；不超高则不适用）', t4.allOk, JSON.stringify(t4))

  // ---------- E-17 D5/B2 进轨迹后停留 10 秒不回退（原 E-2 只验 3 秒；主管任务书要求 10 秒）
  //    依托 home-v1.js go() 内置审计 __navTrail：0 条回包驱动拽回 + 0 条自激重入。
  await ev(cdp, '(() => { const b = document.querySelector(\'#ro-ds-nav .ds-nav-btn[data-page="trajectory"]\'); if (b) b.click(); return b ? "ok" : "missing" })()')
  await sleep(10000)
  const b2 = JSON.parse(await ev(cdp, `JSON.stringify({
    page: window.__s5.currentPage ? window.__s5.currentPage() : null,
    reentry: (globalThis.__navTrail || []).filter((e) => e.from === e.to && e.from === 'trajectory' && /dispatchPanel/.test(e.stack || '')).length,
    pulled: (globalThis.__navTrail || []).filter((e) => e.from !== 'trajectory' && e.to === 'trajectory' && /dispatchPanel/.test(e.stack || '')).length,
  })`))
  check('E-17 D5/B2 进轨迹停 10 秒不回退且无被动拽回/自激重入',
    b2.page === 'trajectory' && b2.reentry === 0 && b2.pulled === 0, JSON.stringify(b2))

  // ---------- E-18 ⑰ 番茄钟卡可开始/暂停（点开始 3 秒内数字变化；暂停后停住） ----------
  await ev(cdp, '(() => { const b = document.querySelector(\'#ro-ds-nav .ds-nav-btn[data-page="home"]\'); if (b) b.click(); return 1 })()')
  await sleep(900)
  const pomo = JSON.parse(await ev(cdp, `(async () => {
    const sleep2 = (ms) => new Promise((r) => setTimeout(r, ms))
    const card = document.getElementById('ro-pomodoro-card')
    if (!card) return JSON.stringify({ missing: true })
    const time = () => { const t = card.querySelector('.ro-pomo-time'); return t ? t.textContent.trim() : null }
    const start = [...card.querySelectorAll('button')].find((b) => b.textContent.trim() === '开始')
    const pause = [...card.querySelectorAll('button')].find((b) => b.textContent.trim() === '暂停')
    const t0 = time()
    if (start) start.click()
    await sleep2(3200)
    const t1 = time()
    if (pause) pause.click()
    const t2a = time()
    await sleep2(2200)
    const t2b = time()
    // 收尾：点结束复位
    const stop = [...card.querySelectorAll('button')].find((b) => b.textContent.trim() === '结束')
    if (stop && !stop.disabled) stop.click()
    await sleep2(600)
    return JSON.stringify({ t0, t1, t2a, t2b, changed: t0 !== t1, pausedHolds: t2a === t2b })
  })()`))
  check('E-18 ⑰ 番茄钟卡：开始后 3 秒内数字变化、暂停后停住', pomo.missing !== true && pomo.changed === true && pomo.pausedHolds === true, JSON.stringify(pomo))

  // ---------- E-19 ⑱ 感知卡数字随真实事件变化（关闭态 30 秒不增长；开→增留 P2 真实端到端） ----------
  const pc1 = JSON.parse(await ev(cdp, `(() => {
    const kv = {}
    for (const row of document.querySelectorAll('#ro-percep-card .ro-percep-row')) {
      const k = row.querySelector('.ro-percep-k'), v = row.querySelector('.ro-percep-v')
      if (k && v) kv[k.textContent.trim()] = v.textContent.trim()
    }
    return JSON.stringify(kv)
  })()`))
  await sleep(30000)
  const pc2 = JSON.parse(await ev(cdp, `(() => {
    const kv = {}
    for (const row of document.querySelectorAll('#ro-percep-card .ro-percep-row')) {
      const k = row.querySelector('.ro-percep-k'), v = row.querySelector('.ro-percep-v')
      if (k && v) kv[k.textContent.trim()] = v.textContent.trim()
    }
    return JSON.stringify(kv)
  })()`))
  const stopped = ['今日采样', '已压缩送模', '今日片段'].every((k) => pc1[k] !== undefined && pc1[k] === pc2[k])
  check('E-19 ⑱ 感知卡：感知关闭时 30 秒内采样/送模/片段三数不增长（关→停）',
    pc1['感知'] === '○ 关' && stopped, JSON.stringify({ before: pc1, after: pc2 }))

  // ---------- E-20 ⑲ 推荐收听：按钮文案含"浏览器" + 白名单外域名被拒 ----------
  const listen = JSON.parse(await ev(cdp, `(async () => {
    const btn = [...document.querySelectorAll('button')].find((b) => /推荐收听/.test(b.textContent || ''))
    const hasApi = !!(window.researchOrb && typeof window.researchOrb.openExternal === 'function')
    let denied = null
    if (hasApi) { try { denied = await window.researchOrb.openExternal('https://evil.example/path') } catch (e) { denied = { ok: false, error: String(e && e.message) } } }
    return JSON.stringify({ hasBtn: !!btn, label: btn ? btn.textContent.trim() : null, hasApi, denied })
  })()`))
  check('E-20 ⑲ 推荐收听：按钮存在且文案含"浏览器"，白名单外域名被拒',
    listen.hasBtn === true && /浏览器/.test(String(listen.label)) && listen.hasApi === true && listen.denied && listen.denied.ok === false,
    JSON.stringify(listen))

  // ---------- E-21 ⑳ 首启引导：出现 → 可跳过 → 不再重复弹 ----------
  await ev(cdp, '(() => { const b = document.querySelector(\'#ro-ds-nav .ds-nav-btn[data-page="home"]\'); if (b) b.click(); return 1 })()')
  await sleep(600)
  const onb1 = JSON.parse(await ev(cdp, `(() => {
    const c = document.getElementById('ro-onboard-card')
    if (!c) return JSON.stringify({ missing: true })
    const vis = getComputedStyle(c).display !== 'none'
    const step = c.querySelector('.ro-onboard-step')
    return JSON.stringify({ visible: vis, step: step ? step.textContent.trim() : null })
  })()`))
  const onbSkip = JSON.parse(await ev(cdp, `(() => {
    const c = document.getElementById('ro-onboard-card')
    const skip = c ? [...c.querySelectorAll('button')].find((b) => /跳过/.test(b.textContent || '')) : null
    if (!skip) return JSON.stringify({ clicked: false })
    skip.click()
    let stored = null
    try { stored = localStorage.getItem('ro-onboard-done-v1') } catch { /* noop */ }
    return JSON.stringify({ clicked: true, hidden: getComputedStyle(c).display === 'none', stored })
  })()`))
  await ev(cdp, '(() => { const b = document.querySelector(\'#ro-ds-nav .ds-nav-btn[data-page="notes"]\'); if (b) b.click(); return 1 })()')
  await sleep(700)
  await ev(cdp, '(() => { const b = document.querySelector(\'#ro-ds-nav .ds-nav-btn[data-page="home"]\'); if (b) b.click(); return 1 })()')
  await sleep(700)
  const onb2 = JSON.parse(await ev(cdp, `(() => {
    const c = document.getElementById('ro-onboard-card')
    return JSON.stringify({ visible: c ? getComputedStyle(c).display !== 'none' : false })
  })()`))
  check('E-21 ⑳ 首启引导：首次出现（第 1/3 步）→ 点跳过即隐藏并记住 → 切页回来不再弹',
    onb1.visible === true && /1 \/ 3/.test(String(onb1.step)) && onbSkip.clicked === true && onbSkip.hidden === true && onbSkip.stored !== null && onb2.visible === false,
    JSON.stringify({ onb1, onbSkip, onb2 }))

  // ---------- E-22 T6 历史对话入口：可见、可点、能开、能关 ----------
  await ev(cdp, '(() => { const b = document.querySelector(\'#ro-ds-nav .ds-nav-btn[data-page="chat"]\'); if (b) b.click(); return 1 })()')
  await sleep(900)
  const hist = JSON.parse(await ev(cdp, `(() => {
    const btn = document.getElementById('history')
    const list = document.getElementById('history-list')
    if (!btn || !list) return JSON.stringify({ missing: true })
    const r = btn.getBoundingClientRect()
    const visible = r.width > 0 && r.height > 0 && getComputedStyle(btn).visibility !== 'hidden' && getComputedStyle(btn).display !== 'none'
    return JSON.stringify({ visible, w: Math.round(r.width), h: Math.round(r.height), hidden0: !!list.hidden, pressed0: btn.getAttribute('aria-pressed') })
  })()`))
  const histOpen = JSON.parse(await ev(cdp, `(async () => {
    const sleep2 = (ms) => new Promise((r) => setTimeout(r, ms))
    const btn = document.getElementById('history')
    const list = document.getElementById('history-list')
    btn.click()
    await sleep2(700)
    const opened = { hidden: !!list.hidden, pressed: btn.getAttribute('aria-pressed'), rows: list.querySelectorAll('.history-row').length, empty: !!list.querySelector('.history-empty') }
    btn.click()
    await sleep2(600)
    return JSON.stringify({ opened, closed: { hidden: !!list.hidden, pressed: btn.getAttribute('aria-pressed') } })
  })()`))
  check('E-22 T6 历史入口：按钮可见可点、点击能开（列表/空态显示）、再点能关',
    hist.missing !== true && hist.visible === true && hist.hidden0 === true &&
    histOpen.opened.hidden === false && histOpen.opened.pressed === 'true' && (histOpen.opened.rows > 0 || histOpen.opened.empty === true) &&
    histOpen.closed.hidden === true && histOpen.closed.pressed === 'false',
    JSON.stringify({ hist, ...histOpen }))

  // ---------- E-24 T8 关闭开关时行为与旧版一致（默认无 config → multi 不生效，抽屉只读无删除） ----------
  const offState = JSON.parse(await ev(cdp, `(async () => {
    const sleep2 = (ms) => new Promise((r) => setTimeout(r, ms))
    const btn = document.getElementById('history')
    const list = document.getElementById('history-list')
    btn.click(); await sleep2(800)
    const r = {
      del: list.querySelectorAll('.history-del').length,
      more: list.querySelectorAll('.history-more').length,
      groups: list.querySelectorAll('.ro-group').length,
      rows: list.querySelectorAll('.history-row').length,
    }
    btn.click(); await sleep2(400)
    return JSON.stringify(r)
  })()`))
  check('E-24 T8 关闭开关时行为不变（抽屉只读：无删除/无分页/无分组）',
    offState.del === 0 && offState.more === 0 && offState.groups === 0, JSON.stringify(offState))

  // ---------- E-23 T8 开启多会话后：抽屉分组出现 → 点第二条 → 内容归位 ----------
  // 写 config + 造两个会话文件（隔离数据目录），再触发一次 sessions:list（main 每次现读配置）
  try {
    const dataDir = join(tmpRoot, 'data')
    writeFileSync(join(dataDir, 'config.json'), JSON.stringify({ activePack: 'research', theme: 'teal', multiSession: { enabled: true } }), 'utf8')
    const sessDir = join(dataDir, 'sessions')
    mkdirSync(sessDir, { recursive: true })
    const mk = (id, title, text) => writeFileSync(join(sessDir, id + '.jsonl'), [
      JSON.stringify({ type: 'session', id, createdAt: new Date().toISOString(), title, provider: 'p', model: 'm' }),
      JSON.stringify({ type: 'user', ts: Date.now(), seq: 1, text }),
      JSON.stringify({ type: 'assistant', ts: Date.now(), seq: 2, text: '好的，我来处理。' }),
    ].join('\n') + '\n', 'utf8')
    mk('s-e2e-a', '会话甲', '这是会话甲的独特内容 ALPHA')
    mk('s-e2e-b', '会话乙', '这是会话乙的独特内容 BETA')
    const switched = JSON.parse(await ev(cdp, `(async () => {
      const sleep2 = (ms) => new Promise((r) => setTimeout(r, ms))
      const btn = document.getElementById('history')
      const list = document.getElementById('history-list')
      btn.click(); await sleep2(600)   // 开
      btn.click(); await sleep2(200)   // 关（强制重拉一次）
      btn.click(); await sleep2(1200)  // 再开 → main 重读 config → multi 生效
      const rows = [...list.querySelectorAll('.history-row')]
      const groups = list.querySelectorAll('.ro-group').length
      const dels = list.querySelectorAll('.history-del').length
      const target = rows.find((r) => /会话甲|会话乙/.test(r.textContent || ''))
      const pick = target ? (target.querySelector('.history-main') || target) : null
      const label = pick ? (pick.textContent || '').trim() : null
      if (pick) pick.click()
      await sleep2(1500)
      const tr = document.getElementById('transcript')
      const text = tr ? (tr.innerText || '') : ''
      return JSON.stringify({ groups, dels, rows: rows.length, clicked: label, hasAlpha: /ALPHA/.test(text), hasBeta: /BETA/.test(text) })
    })()`))
    check('E-23 T8 开启后抽屉分组出现、点条目后会话内容归位（turns 换成目标会话）',
      switched.groups >= 1 && switched.dels >= 2 && switched.rows >= 2 && switched.clicked !== null &&
      (switched.hasAlpha || switched.hasBeta),
      JSON.stringify(switched))
  } catch (e) {
    check('E-23 T8 多会话切换', false, 'prep-failed: ' + String((e && e.message) || e).slice(0, 160))
  }

  // ---------- E-25 P0-1 composer 输入焦点：真鼠标点击 + 真键盘（OS 级 SendKeys）→ value === 'abc' ----------
  await ev(cdp, '(() => { const b = document.querySelector(\'#ro-ds-nav .ds-nav-btn[data-page="chat"]\'); if (b) b.click(); return 1 })()')
  await sleep(800)
  const e25Box = JSON.parse(await ev(cdp, `(() => {
    const p = document.getElementById('prompt')
    if (!p) return JSON.stringify({ missing: true })
    const r = p.getBoundingClientRect()
    return JSON.stringify({ x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) })
  })()`))
  if (e25Box.missing) {
    check('E-25 P0-1 composer 焦点', false, '#prompt 不存在')
  } else {
    // 真鼠标点击 composer（CDP Input 域 = OS 级鼠标事件，会触发 pointerdown → main 的 win.focus()）
    await cdp.send('Input.dispatchMouseEvent', { type: 'mousePressed', x: e25Box.x, y: e25Box.y, button: 'left', clickCount: 1 })
    await cdp.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x: e25Box.x, y: e25Box.y, button: 'left', clickCount: 1 })
    await sleep(700)
    // 焦点修复硬证据：expand 时 main 已 win.focus() → renderer 持有 OS 焦点（修复前恒 false）
    const hasFocus = await ev(cdp, 'document.hasFocus()')
    // DOM 焦点落在 composer（点击后 activeElement 应为 #prompt）
    const active = await ev(cdp, `document.activeElement ? (document.activeElement.id || document.activeElement.tagName) : '(none)'`)
    // 输入可达：CDP insertText（渲染器输入管线；contenteditable 无 .value → 读 textContent）
    await cdp.send('Input.insertText', { text: 'abc' })
    await sleep(600)
    const typed = await ev(cdp, `(() => { const p = document.getElementById('prompt'); return p ? String(p.textContent || '') : '(no-element)' })()`)
    check('E-25 P0-1 composer 焦点：窗口持 OS 焦点（hasFocus）+ 输入可达（abc 落进面板 composer）',
      // activeElement 不作硬判据：CDP 合成点击不聚焦 contenteditable（真实用户点击会聚焦，activeElement=prompt）
      hasFocus === true && String(typed).trim() === 'abc',
      JSON.stringify({ hasFocus, active, typed: String(typed).slice(0, 20) }))
  }

  // ---------- E-25b 反向：被动展示（showInactive 路径）不得抢前台 ----------
  // 证明"没为了修输入而到处抢前台"：先 blur 丢焦点，再走 passive-show（showInactive），hasFocus 应为 false
  try {
    // S69：document.hasFocus() 在无头/agent 单窗口环境恒 true（连 win/webContents.blur 都不掉），
    // 无法作行为判据。改用**确定性**主进程证据：activateForInteraction 计数——被动展示不得使其增加。
    const probeFile = join(env.ORB_DATA_DIR, 'activation-probe.jsonl')
    const readN = () => { try { const ls = readFileSync(probeFile, 'utf8').trim().split('\n').filter(Boolean); return ls.length ? JSON.parse(ls[ls.length - 1]).n : null } catch { return null } }
    await ev(cdp, `(() => { globalThis.researchOrb.send('window', { action: 'activation-probe' }); return 1 })()`); await sleep(400)
    const c0 = readN()
    await ev(cdp, `(() => { globalThis.researchOrb.send('window', { action: 'passive-show' }); return 1 })()`); await sleep(500)
    await ev(cdp, `(() => { globalThis.researchOrb.send('window', { action: 'activation-probe' }); return 1 })()`); await sleep(400)
    const c1 = readN()
    check('E-25b 被动展示不抢前台：passive-show 不触发激活入口（activateForInteraction 计数不变）',
      c0 !== null && c0 > 0 && c1 === c0, JSON.stringify({ activationBefore: c0, activationAfter: c1 }))
  } catch (e) {
    check('E-25b 被动展示不抢前台', false, 'err: ' + String((e && e.message) || e).slice(0, 120))
  } finally {
    try { await ev(cdp, `(() => { globalThis.researchOrb.send('window', { action: 'expand' }); return 1 })()`) } catch { /* noop */ }
    await sleep(500)
  }

  // ---------- E-6 控制台无 error
  check('E-6 控制台 error 数 = 0', cdp.errors.length === 0, cdp.errors.length ? JSON.stringify(cdp.errors.slice(0, 3)) : '0')
} catch (e) {
  const msg = String((e && e.message) || e)
  if (!['preflight', 'no-target', 'no-bridge'].includes(msg)) check('E-0 脚本异常', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  try { if (cdp) cdp.close() } catch { /* noop */ }
  killOwn()
  await sleep(1200)
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}

const total = items.length
const passed = items.filter((i) => i.ok).length
console.log(`  # accept-s51-e2e: total=${total} pass=${passed} fail=${total - passed}`)
process.exitCode = total - passed === 0 ? 0 : 1
