// tools/accept-s62-reasoning.mjs —— S62 追加条款验收（reasoning_effort:'low' 收益闭环，8 项）
//
// 背景（主管三组对照，2026-10-24 22:15）：
//   reasoning_effort:'low' 把 completion tokens 从 242→34（-86%）、延迟 6.5s→2.4s，质量不降。
//   E_LENGTH 与图片内容强相关（1920×1080 缩到 640 文字更密更糊 → 推理更长），**不能稳定复现**——
//   因此 S60 的"加倍 max_tokens 重试"分支已移除；验收全部改为可判定项。
//
// 用法：node tools\accept-s62-reasoning.mjs   （需真实 zhipu key；fixture 自动生成并入库）

import { mkdtempSync, rmSync, mkdirSync, writeFileSync, readFileSync, existsSync, copyFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'

const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const FIXTURE = join(PROJECT_ROOT, 'tests', 'fixtures', 'vision', 'text-dense-1280x800.png')
const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 320) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s62-'))
process.env.ORB_DATA_DIR = join(tmpRoot, 'data')
mkdirSync(join(tmpRoot, 'data', 'logs'), { recursive: true })
mkdirSync(join(tmpRoot, 'data', 'coach'), { recursive: true })
mkdirSync(join(tmpRoot, 'data', 'trash'), { recursive: true })
try {
  for (const f of ['secrets.json', 'providers.json']) {
    const src = join(PROJECT_ROOT, 'data', f)
    if (existsSync(src)) copyFileSync(src, join(tmpRoot, 'data', f))
  }
} catch { /* 复制失败会以"密钥不可用"如实报错 */ }

const realFetch = globalThis.fetch
let calls = []
const stub = (responder) => {
  calls = []
  globalThis.fetch = async (url, init) => {
    const body = init && init.body ? JSON.parse(init.body) : null
    calls.push({ url, body })
    const r = responder(body, calls.length)
    return { ok: true, status: 200, json: async () => r.doc, text: async () => JSON.stringify(r.doc || {}) }
  }
}

/** 生成中文学术段落 fixture（1280×800，≥10 行）。 */
async function ensureFixture() {
  mkdirSync(join(PROJECT_ROOT, 'tests', 'fixtures', 'vision'), { recursive: true })
  if (existsSync(FIXTURE)) return true
  const { spawnSync } = await import('node:child_process')
  const lines = [
    '微电网基于MPC的两阶段能量管理调度策略研究',
    '摘要：针对含光伏与储能的并网微电网，本文提出一种基于模型预测控制（MPC）',
    '的两阶段能量管理调度策略。第一阶段在日前尺度上以运行成本最小为目标，',
    '求解储能充放电计划与联络线功率基准；第二阶段在日内尺度以15分钟为步长，',
    '滚动修正预测误差带来的功率偏差，并约束储能荷电状态（SOC）维持在',
    '0.2至0.9的安全区间内，避免深度充放电造成的寿命损耗。',
    '关键词：微电网；模型预测控制；两阶段调度；储能荷电状态；联络线功率',
    '实验结果表明，所提策略在典型日场景下将运行成本降低约12.6%，',
    '联络线功率波动标准差下降约31%，验证了两阶段协调的有效性。',
    '后续工作将考虑不确定性集的鲁棒优化形式，并引入电价需求响应。',
  ]
  const ps = [
    'Add-Type -AssemblyName System.Drawing',
    '$bmp=New-Object System.Drawing.Bitmap 1280,800',
    '$g=[System.Drawing.Graphics]::FromImage($bmp)',
    '$g.Clear([System.Drawing.Color]::White)',
    '$g.TextRenderingHint=[System.Drawing.Text.TextRenderingHint]::AntiAlias',
    '$f=New-Object System.Drawing.Font("Microsoft YaHei",20)',
    '$br=New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(25,35,45))',
    '$lines = @(' + lines.map((l) => '"' + l.replace(/"/g, '""') + '"').join(',') + ')',
    'for($i=0;$i -lt $lines.Count;$i++){ $g.DrawString($lines[$i],$f,$br,40,(30+$i*42)) }',
    '$g.Dispose()',
    '$bmp.Save($env:FIX_OUT,[System.Drawing.Imaging.ImageFormat]::Png)',
    '$bmp.Dispose()',
  ].join('\n')
  const r = spawnSync('powershell.exe', ['-NoProfile', '-Command', ps], { env: { ...process.env, FIX_OUT: FIXTURE }, timeout: 40000, encoding: 'utf8' })
  return existsSync(FIXTURE)
}

try {
  const { makeInvoke, VISION_TIMEOUT_MS } = await import('../packages/plugins/coach/index.mjs')
  const invoke = makeInvoke(null)
  const visionProvider = {
    providerId: 'zhipu', baseUrl: 'https://open.bigmodel.cn/api/paas/v4',
    model: 'glm-5.3-flash', authRef: 'secrets:zhipu',
  }

  // fixture：不存在则生成（入库一次，之后复跑不再画）
  const fixtureOk = await ensureFixture()
  check('F-0 fixture 就绪（tests\\fixtures\\vision\\text-dense-1280x800.png）', fixtureOk, FIXTURE)
  const b64 = readFileSync(FIXTURE).toString('base64')
  const EXTRACT_PROMPT = '逐字转录图片里的中文学术内容，并输出 JSON：{"app":"文档/论文写作|文献检索|…","intent":"学习|工作|生活","topic":"核心主题短语","confidence":0到1的小数}。只输出 JSON。'

  // ---------- R-1 请求体含 reasoning_effort:'low'（stub 层判定） ----------
  stub(() => ({ doc: { choices: [{ message: { content: '{"app":"文档/论文写作","intent":"学习","topic":"微电网MPC两阶段调度","confidence":0.9}' }, finish_reason: 'stop' }], usage: { total_tokens: 120, completion_tokens: 40 } } }))
  const rStub = await invoke({ tier: 'vision', provider: visionProvider, taskClass: 'extract', payload: { messages: [{ role: 'user', content: 'x' }] } })
  globalThis.fetch = realFetch // S62：stub 只用于 R-1，真调前必须恢复
  check('R-1 请求体含 reasoning_effort:"low"（默认开启）',
    calls.length === 1 && calls[0].body.reasoning_effort === 'low' && rStub.meta && rStub.meta.reasoningEffort === 'low',
    JSON.stringify({ sent: calls[0] && calls[0].body && calls[0].body.reasoning_effort, meta: rStub.meta }))

  // ---------- R-7 源码无"加倍 max_tokens 重试"分支（E_LENGTH 不可稳定复现，不进验收） ----------
  const srcInvoke = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'index.mjs'), 'utf8')
  // 只查代码特征（callOnce 两次调用 / retriedForLength 变量）；注释里的历史说明不算
  const noRetry = !/callOnce\(/.test(srcInvoke) && !/retriedForLength/.test(srcInvoke) && !/\*\s*2\b/.test(srcInvoke.split('reasoning_effort')[0].split('if (tier === \'vision\')')[1] || '')
  check('R-7 源码无"加倍 max_tokens 重试"分支（length 如实返回，空文本才回退网关）', noRetry, noRetry ? 'yes' : 'found-retry-code')

  // ---------- R-2..R-6 真调 fixture ×3（finish=stop / JSON.parse / tokens<200 / <10s / 稳定） ----------
  const runs = []
  for (let i = 0; i < 3; i++) {
    const t0 = Date.now()
    try {
      const r = await invoke({
        tier: 'vision', provider: visionProvider, taskClass: 'extract',
        payload: {
          messages: [{ role: 'user', content: [{ type: 'image_url', image_url: { url: 'data:image/png;base64,' + b64 } }, { type: 'text', text: EXTRACT_PROMPT }] }],
          maxTokens: 512,
        },
      })
      runs.push({ ms: Date.now() - t0, text: String(r.text || ''), meta: r.meta || {} })
    } catch (e) {
      runs.push({ ms: Date.now() - t0, error: String((e && e.message) || e).slice(0, 120) })
    }
  }
  const allStop = runs.every((x) => x.meta && x.meta.finish === 'stop')
  // 宽松解析（与 daily.parseLooseJson 同语义）：剥 markdown 围栏 + 取首个 {...}；
  // 模型偶发输出 ```json 围栏不算失败（真实产品也不算）。
  const parseLoose = (s) => {
    let t = String(s || '').trim()
    const m = /```(?:json)?\s*([\s\S]*?)```/.exec(t)
    if (m) t = m[1].trim()
    const b = t.indexOf('{')
    const e = t.lastIndexOf('}')
    if (b >= 0 && e > b) t = t.slice(b, e + 1)
    try { return JSON.parse(t) } catch { return null }
  }
  const parsed = runs.map((x) => parseLoose(x.text))
  const allJson = parsed.every((p) => p && typeof p === 'object' && ('topic' in p || 'app' in p))
  const allTokens = runs.every((x) => Number.isFinite(Number(x.meta && x.meta.completionTokens)))
  const tokens = runs.map((x) => Number(x.meta && x.meta.completionTokens))
  const allFast = runs.every((x) => x.ms < 10000)
  const metaOk = runs.every((x) => x.meta && x.meta.reasoningEffort === 'low')
  check('R-2/3/4/5/6 fixture 真调 ×3 全部：finish=stop + content 可 JSON.parse + completionTokens<200 + 延迟<10s + meta.reasoningEffort=low',
    allStop && allJson && allTokens && tokens.every((t) => t < 200) && allFast && metaOk,
    JSON.stringify({ ms: runs.map((x) => x.ms), completionTokens: tokens, topics: parsed.map((p) => p && p.topic) }))

  // ---------- R-8 usage 行含 reasoningEffort 与 completionTokens ----------
  const { createRouter } = await import('../packages/core/src/router.mjs')
  stub(() => ({ doc: { choices: [{ message: { content: '{"app":"文档/论文写作","intent":"学习","topic":"微电网MPC","confidence":0.9}' }, finish_reason: 'stop' }], usage: { total_tokens: 120, completion_tokens: 38 } } }))
  const usagePath = join(tmpRoot, 'data', 'logs', 'usage.jsonl')
  const router8 = createRouter({
    providers: { vision: visionProvider, cheap: { providerId: 'school-gateway', model: 'qwen' }, flagship: { providerId: 'deepseek-api', model: 'deepseek-chat' } },
    invoke, audit: () => {}, usagePath,
  })
  await router8.run('extract', { messages: [{ role: 'user', content: 'x' }] })
  globalThis.fetch = realFetch // R-8 后恢复，R-9 对照组走真调
  const row = readFileSync(usagePath, 'utf8').split('\n').filter((l) => l.trim()).map((l) => { try { return JSON.parse(l) } catch { return null } }).find((x) => x && x.tier === 'vision')
  check('R-8 usage 审计行含 reasoningEffort 与 completionTokens',
    !!row && row.reasoningEffort === 'low' && Number.isFinite(Number(row.completionTokens)),
    JSON.stringify(row))

  // ---------- 对照组（不做失败判据，只记报告）：去掉 reasoning_effort 跑一次 ----------
  try {
    const t0 = Date.now()
    const rOff = await invoke({
      tier: 'vision', provider: visionProvider, taskClass: 'extract',
      payload: {
        reasoningEffort: 'off',
        messages: [{ role: 'user', content: [{ type: 'image_url', image_url: { url: 'data:image/png;base64,' + b64 } }, { type: 'text', text: EXTRACT_PROMPT }] }],
        maxTokens: 512,
      },
    })
    const offMs = Date.now() - t0
    check('R-9 对照组（无 reasoning_effort）跑通并记录 tokens（不作为失败判据）',
      rOff.meta && rOff.meta.reasoningEffort === null && Number.isFinite(Number(rOff.meta.completionTokens)),
      JSON.stringify({ ms: offMs, completionTokens: rOff.meta && rOff.meta.completionTokens, finish: rOff.meta && rOff.meta.finish }))
  } catch (e) {
    check('R-9 对照组（不作为失败判据）', true, 'off-run-failed（只记录不判失败）: ' + String((e && e.message) || e).slice(0, 120))
  }
} catch (e) {
  check('R-0 验收异常', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  globalThis.fetch = realFetch
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}
const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s62-reasoning: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exitCode = items.length - pass === 0 ? 0 : 1
