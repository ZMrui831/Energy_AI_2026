// tools/_accept-isolate.mjs —— S67·3-A 隔离副作用模块
//
// 用法：作为验收脚本的**第一个 import**：
//   import './_accept-isolate.mjs'
//   import { ... } from 产品模块          // 兄弟模块在它之后求值 → 读到临时目录
//
// 原理：ESM 依赖按 import 语句顺序**深度优先求值**，本模块 body 先于后续 import 的产品模块
// （safefs/db/...）执行；因此在这里设置 process.env 能在 safefs 解析 DATA_DIR 之前生效。
//
// 行为：仅当未显式设置时，把 ORB_DATA_DIR / ORB_LOG_DIR 指到临时目录（幂等、无副作用于只读脚本）。
import { mkdtempSync, mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

if (!process.env.ORB_DATA_DIR) {
  const root = mkdtempSync(join(tmpdir(), 'orb-accept-'))
  process.env.ORB_DATA_DIR = root
  try { mkdirSync(join(root, 'logs'), { recursive: true }) } catch { /* ignore */ }
  try { mkdirSync(join(root, 'db'), { recursive: true }) } catch { /* ignore */ }
}
if (!process.env.ORB_LOG_DIR) process.env.ORB_LOG_DIR = join(process.env.ORB_DATA_DIR, 'logs')
