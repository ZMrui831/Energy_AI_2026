// tools/accept-s31-templates.mjs —— S31·A2 健康提醒文案模板验收（≥6 项）。
// 单行复跑：node tools\accept-s31-templates.mjs
// 证据：data\logs\s31-templates-accept.json
//
// 覆盖：三档各自出文案 / 建议语气（非命令式）/ 同档连续提醒轮换不同句 /
//       久坐 50min 触发休息档 / 娱乐 90min 触发出去走走档 / 番茄钟完成触发 pomodoro 档 / 每档 3 条模板。
import { mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { HEALTH_TEMPLATES, createHealthLedger, HEALTH_DEFAULTS } from '../packages/plugins/coach/health.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 240), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's31-templates')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(WORK, { recursive: true })

let t = 1000000
const now = () => t
const SOFT = /(不妨|建议|可以|要不要|考虑|试试|合上|起身|起来|站起)/

try {
  // ① 每档 3 条模板且都为建议语气（非命令式）
  const tiers = ['rest', 'walk', 'pomodoro']
  const allThree = tiers.every((k) => Array.isArray(HEALTH_TEMPLATES[k]) && HEALTH_TEMPLATES[k].length === 3)
  check('T1 三档各 3 条模板', allThree, 'rest/walk/pomodoro 各 ' + tiers.map((k) => HEALTH_TEMPLATES[k].length).join('/'))
  const allSoft = tiers.every((k) => HEALTH_TEMPLATES[k].every((m) => SOFT.test(m)))
  check('T2 每条模板均为建议语气（含不妨/建议/可以等，非命令式）', allSoft)

  // ② 久坐 50min → 休息/喝水档（rest）
  const r1 = []
  const ledRest = createHealthLedger({ dir: join(WORK, 'rest'), now, restCapMin: 50, capMin: 90, cooldownMs: 1, remind: async (i) => r1.push(i) })
  for (let i = 0; i < 5; i++) { t += 60000; await ledRest.feed({ process: 'Code.exe', title: '论文', dwellMin: 10 }) } // 50min 工作
  check('T3 久坐 50min 触发 rest（休息/喝水）档', r1.some((x) => x.type === 'rest' && x.message), 'reminders=' + JSON.stringify(r1.map((x) => x.type)))

  // ③ 娱乐 90min → 出去走走档（walk）
  const r2 = []
  const ledWalk = createHealthLedger({ dir: join(WORK, 'walk'), now, restCapMin: 50, capMin: 90, cooldownMs: 1, remind: async (i) => r2.push(i) })
  for (let i = 0; i < 9; i++) { t += 60000; await ledWalk.feed({ process: 'mpv.exe', title: '电影', dwellMin: 10 }) } // 90min 娱乐
  check('T4 娱乐 90min 触发 walk（出去走走）档', r2.some((x) => x.type === 'walk' && x.message))
  // 工作不触发 walk、娱乐不触发 rest（档位隔离）
  check('T5 档位隔离：工作只产 rest、娱乐只产 walk', !r1.some((x) => x.type === 'walk') && !r2.some((x) => x.type === 'rest'))

  // ⑥ 番茄钟完成 → pomodoro 档
  const r3 = []
  const ledPomo = createHealthLedger({ dir: join(WORK, 'pomo'), now, cooldownMs: 1, remind: async (i) => r3.push(i) })
  await ledPomo.pomodoroComplete(25)
  check('T6 番茄钟完成（25min）触发 pomodoro 档', r3.length === 1 && r3[0].type === 'pomodoro' && SOFT.test(r3[0].message))

  // ⑦ 同档连续提醒轮换不同句（rest 档两次提醒文案不同）
  const r4 = []
  const ledRot = createHealthLedger({ dir: join(WORK, 'rot'), now, restCapMin: 50, capMin: 90, cooldownMs: 1, remind: async (i) => r4.push(i.message) })
  for (let i = 0; i < 5; i++) { t += 60000; await ledRot.feed({ process: 'Code.exe', title: '论文', dwellMin: 10 }) } // 第一次 rest
  t += 10 // 越过冷却
  for (let i = 0; i < 5; i++) { t += 60000; await ledRot.feed({ process: 'Code.exe', title: '论文', dwellMin: 10 }) } // 第二次 rest（不同句）
  check('T7 同档连续提醒轮换不同句（rest 两次文案不同）', r4.filter(Boolean).length >= 2 && r4[0] !== r4[r4.length - 1], 'rest 文案=' + JSON.stringify(r4.filter(Boolean).slice(0, 2)))
} catch (e) {
  check('T0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 240))
}

const pass = items.filter((i) => i.ok).length
const fail = items.length - pass
const out = { tool: 'accept-s31-templates', at: new Date().toISOString(), total: items.length, pass, fail, items }
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's31-templates-accept.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # accept-s31-templates: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 证据 -> data/logs/s31-templates-accept.json`)
process.exit(fail === 0 ? 0 : 1)
