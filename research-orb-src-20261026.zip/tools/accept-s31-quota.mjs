// tools/accept-s31-quota.mjs —— S31·B2 配额墙与超时兜底验收（≥8 项）。
// 单行复跑：node tools\accept-s31-quota.mjs
// 证据：data\logs\s31-quota-accept.json
//
// 覆盖：10 rpm 令牌桶不许绕（排队不失败 + rate-wait 审计）/ extract 45s 超时标 extract-timeout 且不写半条轨迹 /
//       daily 遇超时返回 aborted / /usage 今日旗舰统计 / 费用区间表述 / 公共配额静默函数可复用。
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createRouter } from '../packages/core/src/router.mjs'
import { createExtractor } from '../packages/plugins/coach/extract.mjs'
import { createDailyPipeline } from '../packages/plugins/coach/daily.mjs'
import { usageStats } from '../packages/plugins/coach/index.mjs'
import { makeQuotaSleeper } from './_quota-sleep.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 240), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's31-quota')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(WORK, { recursive: true })
const usagePath = join(WORK, 'usage.jsonl')
const AUDIT = join(PROJECT_ROOT, 'data', 'logs', 'coach.jsonl')
const IMG = join(WORK, 'frame.png')
writeFileSync(IMG, Buffer.from('quota frame body'))

try {
  // ① 10 rpm 令牌桶不许绕：12 连发全部成功（排队不失败）
  let vt = 0
  const limiterNow = () => vt
  const fakeSleep = (ms) => { vt += ms; return Promise.resolve() }
  let rateWaits = 0
  let invokeCalls = 0
  const router = createRouter({
    providers: { cheap: { providerId: 'school-gateway', model: 'qwen' }, flagship: { providerId: 'deepseek-api', model: 'deepseek-chat' } },
    invoke: async ({ taskClass }) => { invokeCalls += 1; return { text: 'ok ' + taskClass } },
    now: limiterNow, sleep: fakeSleep, usagePath, audit: () => {},
    onRateWait: (w) => { rateWaits += 1 },
  })
  let allOk = true
  for (let i = 0; i < 12; i++) {
    const r = await router.run('extract', { messages: [], maxTokens: 1 })
    if (!r.ok) allOk = false
  }
  check('Q1 10 rpm 桶不许绕：12 连发全部成功（排队不失败）', allOk && invokeCalls === 12, 'invokeCalls=' + invokeCalls)
  check('Q2 桶满排队产生 rate-wait 审计（≥1 次）', rateWaits >= 1, 'rateWaits=' + rateWaits)

  // ③ extract 超时（注入 150ms 加速；真实默认 45s）→ 标 E_EXTRACT_TIMEOUT
  const slowRouter = createRouter({
    providers: { cheap: { providerId: 'school-gateway', model: 'qwen' }, flagship: { providerId: 'deepseek-api', model: 'deepseek-chat' } },
    invoke: async () => new Promise((res) => setTimeout(() => res({ text: 'late' }), 800)),
    usagePath, audit: () => {},
  })
  const ext = createExtractor({ dir: join(WORK, 'ext'), router: slowRouter, trashDir: join(WORK, 'trash'), extractTimeoutMs: 150, ocr: () => ({ ok: false, text: '', err: 'no-engine' }) })
  let errCode = null
  let errAt = Date.now()
  try { await ext.extract({ imagePath: IMG }) } catch (e) { errCode = (e && e.code) || '?'; errAt = Date.now() - errAt }
  check('Q3 extract 超 150ms 触发 E_EXTRACT_TIMEOUT（不取半条轨迹）', errCode === 'E_EXTRACT_TIMEOUT', 'code=' + errCode + ' 耗时≈' + errAt + 'ms')

  // ④ daily 遇 extract 超时 → aborted 且不写半条轨迹
  const daily = createDailyPipeline({ dir: join(WORK, 'daily'), router: slowRouter, extractor: createExtractor({ dir: join(WORK, 'daily'), router: slowRouter, trashDir: join(WORK, 'trash2'), extractTimeoutMs: 150, ocr: () => ({ ok: false, text: '', err: 'no-engine' }) }) })
  const trajFile = join(WORK, 'daily', 'trajectory.jsonl')
  const before = existsSync(trajFile) ? readFileSync(trajFile, 'utf8').split('\n').filter(Boolean).length : 0
  const dr = await daily.run({ consentActive: true, frames: [{ imagePath: IMG, window: 'w', process: 'p' }], goal: 'g' })
  const after = existsSync(trajFile) ? readFileSync(trajFile, 'utf8').split('\n').filter(Boolean).length : 0
  check('Q4 daily 遇 extract 超时返回 aborted 且不写半条轨迹', dr.aborted === true && dr.skipped === true && after === before, 'before=' + before + ' after=' + after)
  check('Q9 中止原因含 extract 超时文案', /extract 超时/.test(dr.reason || ''), dr.reason || '')

  // ⑤ /usage 今日旗舰统计（独立 usage.jsonl）
  const todayStr = new Date().toISOString().slice(0, 10)
  const yester = new Date(Date.now() - 86400000).toISOString()
  const rows = [
    JSON.stringify({ ts: todayStr + 'T10:00:00.000Z', taskClass: 'score-plan', tier: 'flagship', providerId: 'deepseek-api', model: 'deepseek-chat', fallback: false, ok: true, ms: 100, tokens: 100 }),
    JSON.stringify({ ts: todayStr + 'T10:01:00.000Z', taskClass: 'score-plan', tier: 'flagship', providerId: 'deepseek-api', model: 'deepseek-chat', fallback: false, ok: true, ms: 100, tokens: 200 }),
    JSON.stringify({ ts: todayStr + 'T10:02:00.000Z', taskClass: 'summarize', tier: 'flagship', providerId: 'deepseek-api', model: 'deepseek-chat', fallback: false, ok: true, ms: 100, tokens: 150 }),
    JSON.stringify({ ts: todayStr + 'T10:03:00.000Z', taskClass: 'extract', tier: 'cheap', providerId: 'school-gateway', model: 'qwen', fallback: false, ok: true, ms: 100, tokens: 50 }),
    JSON.stringify({ ts: yester, taskClass: 'score-plan', tier: 'flagship', providerId: 'deepseek-api', model: 'deepseek-chat', fallback: false, ok: true, ms: 100, tokens: 999 }),
  ].join('\n') + '\n'
  const usagePathQ = join(WORK, 'usage-test.jsonl')
  writeFileSync(usagePathQ, rows)
  const s = usageStats({ path: usagePathQ })
  check('Q5 /usage 今日旗舰统计：calls=3 tokens=450', s.todayFlagship.calls === 3 && s.todayFlagship.tokens === 450, 'calls=' + s.todayFlagship.calls + ' tokens=' + s.todayFlagship.tokens)
  check('Q6 费用以区间表述（含 ¥ 与 –）', typeof s.todayFlagship.feeInterval === 'string' && /¥/.test(s.todayFlagship.feeInterval) && /–/.test(s.todayFlagship.feeInterval), s.todayFlagship.feeInterval)

  // ⑦ 公共配额静默函数可复用（覆盖所有 s31 探针 + 既有 probe-s26-real）
  const awaiter = makeQuotaSleeper({ sleep: () => Promise.resolve(), log: () => {} })
  const q = await awaiter(10)
  check('Q7 公共配额静默函数可调用并解析', q === true)

  // ⑧ extract 超时写审计行 extract-timeout（真实 coach.jsonl）
  const coachAudit = existsSync(AUDIT) ? readFileSync(AUDIT, 'utf8') : ''
  check('Q8 extract 超时写审计行 extract-timeout', coachAudit.includes('extract-timeout'))
} catch (e) {
  check('Q0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 240))
}

const pass = items.filter((i) => i.ok).length
const fail = items.length - pass
const out = { tool: 'accept-s31-quota', at: new Date().toISOString(), total: items.length, pass, fail, items }
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's31-quota-accept.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # accept-s31-quota: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 证据 -> data/logs/s31-quota-accept.json`)
process.exit(fail === 0 ? 0 : 1)
