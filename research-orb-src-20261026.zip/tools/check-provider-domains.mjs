// tools/check-provider-domains.mjs —— S61·P0-1 白名单护栏：换 provider 必须同步白名单
//
// 背景：S60 视觉档第一次真实调用被 E_DOMAIN_NOT_ALLOWED 拒 —— providers.json 加了
// open.bigmodel.cn，但 domains.json 白名单没人同步。本护栏把"providers 所有出网域名
// 必须在白名单里"变成 run-tests 前置，缺一个就 FAIL。
//
// 覆盖：providers.json 每段的 baseUrl（直接字段）/ baseUrlRef（claude-settings:*）/
//       authRef 指向的 secrets 段里的 baseUrl（如 deepseek.baseUrl）。
// 判定：复用 packages/core/src/net.mjs 的 isAllowedUrl（与运行时同源，避免双实现漂移）。
//
// 用法：node tools\check-provider-domains.mjs   （全部 allow → exit 0）

import { existsSync, readFileSync } from 'node:fs'
import { join, dirname, resolve } from 'node:path'
import { homedir } from 'node:os'
import { fileURLToPath } from 'node:url'
import { isAllowedUrl } from '../packages/core/src/net.mjs'

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}

function resolveRefValue(ref) {
  const [src, key] = String(ref || '').split(':')
  try {
    if (src === 'claude-settings') {
      const p = join(homedir(), '.claude', 'settings.json')
      if (!existsSync(p)) return null
      const doc = JSON.parse(readFileSync(p, 'utf8'))
      return (doc.env && doc.env[key]) || null
    }
    if (src === 'secrets') {
      const p = join(ROOT, 'data', 'secrets.json')
      if (!existsSync(p)) return null
      const doc = JSON.parse(readFileSync(p, 'utf8'))
      return (doc && doc[key]) ?? null
    }
  } catch { return null }
  return null
}

try {
  const providers = JSON.parse(readFileSync(join(ROOT, 'data', 'providers.json'), 'utf8'))
  const entries = [] // {name, baseUrl}
  /** 深度收集对象里所有形如 http(s):// 的字符串（含嵌套），name 前缀标注来源。 */
  const collectUrls = (obj, name) => {
    if (!obj || typeof obj !== 'object') return
    for (const [k, v] of Object.entries(obj)) {
      if (typeof v === 'string' && /^https?:\/\//.test(v)) entries.push({ name: `${name}.${k}`, baseUrl: v })
      else if (v && typeof v === 'object') collectUrls(v, `${name}.${k}`)
    }
  }
  for (const [name, p] of Object.entries(providers || {})) {
    if (!p || typeof p !== 'object') continue
    collectUrls(p, name)
    if (typeof p.baseUrlRef === 'string' && p.baseUrlRef) {
      const v = resolveRefValue(p.baseUrlRef)
      if (typeof v === 'string' && v) entries.push({ name: name + '(ref)', baseUrl: v })
      else check(`PD-${name}: baseUrlRef 可解析`, false, `${p.baseUrlRef} → null（外部文件缺失？）`)
    }
    // authRef 指向的 secrets 段可能自带 baseUrl（如 deepseek 段）
    if (typeof p.authRef === 'string' && p.authRef.startsWith('secrets:')) {
      const sec = resolveRefValue(p.authRef)
      if (sec && typeof sec === 'object') collectUrls(sec, name + '(secret)')
    }
  }
  check('PD-0 providers.json 至少解析出 1 个出网域名', entries.length >= 1, JSON.stringify(entries.map((e) => e.name)))
  for (const e of entries) {
    let host = '?'
    try { host = new URL(e.baseUrl).host } catch { /* 非法 URL 直接 FAIL */ }
    check(`PD-${e.name} → ${host} 在白名单`, /^https?:\/\//.test(e.baseUrl) && isAllowedUrl(e.baseUrl), e.baseUrl)
  }
} catch (e) {
  check('PD-0 读取 providers.json', false, String((e && e.message) || e).slice(0, 160))
}
const pass = items.filter((i) => i.ok).length
console.log(`  # check-provider-domains: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exitCode = items.length - pass === 0 ? 0 : 1
