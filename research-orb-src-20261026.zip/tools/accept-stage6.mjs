// tools/accept-stage6.mjs —— P-R6 总验收：顺序调用各子验收并汇总 stage6-summary.json
import { spawnSync } from 'node:child_process'
import { writeFileSync, readdirSync, existsSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const STEPS = [
  { id: '1-形态解耦与底座零学科词', test: 'tests/packs.test.mjs', desc: 'pack 清单/切换/命令隔离/数据隔离/每 pack 真实命令/shell+core 零学科词' },
  { id: '2-主题系统', test: 'tests/themes.test.mjs', desc: 'schema 校验/越界拒绝/对比度/几何 token 不覆盖/字体回退链' },
  { id: '3-企业版与演示', test: 'tests/enterprise-demo.test.mjs', desc: 'edition 双向/临时 profile 拒/L2L3L4 静态禁用/审计只增/数据不外发/演示隔离' },
  { id: '4-外观（真 electron）', script: 'tools/accept-stage6-appearance.mjs', desc: '三主题截图/字体生效与回退/图标三态/几何契约/托盘清晰' },
  { id: '5-演示剧本', script: 'tools/accept-stage6-demo.mjs', desc: '检索→卡片→引用校验→计时日报→skill 安装→换肤→摘要，真跑' },
  { id: '6-可分发产物', script: 'tools/pack.mjs', verify: true, desc: 'zip 可解压 + MANIFEST.sha256 逐条一致 + 不含密钥/缓存' },
  { id: '7-electron 冒烟', script: 'tools/accept-smoke-electron.mjs', desc: 'bridge-injected 无异常、ui.jsonl ping、settings 往返、GUI 截图' },
  { id: '8-隔离五查+外写扫描', script: 'tools/accept-stage5-isolation.mjs', desc: 'vendor/start 指纹、禁写目录归因、计划任务、残留进程、writes 越界' },
  { id: '9-冷跑全量单测', cold: true, desc: 'node --test --test-concurrency=1 tests/*.test.mjs（干净 shell 复跑口径）' },
]

const items = []
for (const s of STEPS) {
  process.stdout.write(`\n>>> ${s.id} …\n`)
  let r
  if (s.cold) {
    const testFiles = readdirSync(join(PROJECT_ROOT, 'tests')).filter((f) => f.endsWith('.test.mjs')).map((f) => `tests/${f}`)
    const full = spawnSync(process.execPath, ['--test', '--test-concurrency=1', ...testFiles], {
      cwd: PROJECT_ROOT, encoding: 'utf8', timeout: 600000, windowsHide: true, maxBuffer: 32 << 20,
    })
    const m = String(full.stdout || '').match(/# tests (\d+)[\s\S]*?# pass (\d+)[\s\S]*?# fail (\d+)/)
    const total = m ? Number(m[1]) : 0, passed = m ? Number(m[2]) : 0, failed = m ? Number(m[3]) : -1
    r = { ok: failed === 0 && total >= 460, pass: passed, fail: Math.max(failed, 0), tail: `tests=${total} pass=${passed} fail=${failed}` }
  } else if (s.test) {
    const t = spawnSync(process.execPath, ['--test', s.test], { cwd: PROJECT_ROOT, encoding: 'utf8', timeout: 300000, windowsHide: true, maxBuffer: 16 << 20 })
    const m = String(t.stdout || '').match(/# tests (\d+)[\s\S]*?# pass (\d+)[\s\S]*?# fail (\d+)/)
    r = { ok: t.status === 0, status: t.status, pass: m ? Number(m[2]) : 0, fail: m ? Number(m[3]) : -1, tail: String(t.stdout || '').split('\n').filter((l) => /# (tests|pass|fail)/.test(l)).join(' ') }
  } else {
    const args = s.verify ? [s.script, '--verify'] : [s.script]
    const t = spawnSync(process.execPath, args, { cwd: PROJECT_ROOT, encoding: 'utf8', timeout: 400000, windowsHide: true, maxBuffer: 32 << 20 })
    const out = `${t.stdout || ''}${t.stderr || ''}`
    const pass = (out.match(/^PASS/gm) || []).length
    const fail = (out.match(/^FAIL/gm) || []).length
    r = { ok: t.status === 0 && fail === 0, status: t.status, pass, fail: Math.max(fail, 0), tail: out.split('\n').filter((l) => /^(PASS|FAIL|打包|校验|===)/.test(l)).slice(-6).join(' | ') }
  }
  console.log(`    -> ok=${r.ok} pass=${r.pass} fail=${r.fail}`)
  items.push({ id: s.id, ok: r.ok, pass: r.pass, fail: r.fail, evidence: s.script || s.test, desc: s.desc })
}

const allOk = items.every((i) => i.ok)
const summary = {
  stage: 'P-R6',
  generatedAt: new Date().toISOString(),
  ok: allOk,
  coldRunCommand: 'node --test --test-concurrency=1 tests/*.test.mjs',
  evidenceFiles: [
    'data/logs/stage6-appearance.txt',
    'data/logs/stage6-demo.txt',
    'data/logs/stage5-isolation.txt',
    'data/logs/stage4-final-electron.txt',
    'data/logs/stage6-summary.json',
    'data/shots/stage6-theme-sky-blue.png',
    'data/shots/stage6-theme-warm-sand.png',
    'data/shots/stage6-theme-ink-dark.png',
    'data/shots/stage6-icon-ball.png',
    'data/shots/stage6-icon-ball-run-A.png',
    'data/shots/stage6-icon-tray.png',
    'data/shots/stage6-icon-tray-16.png',
    'dist-package/research-orb-0.4.0-phase4.2-win-x64.zip',
  ],
  items,
}
const out = join(PROJECT_ROOT, 'data', 'logs', 'stage6-summary.json')
writeFileSync(out, `${JSON.stringify(summary, null, 2)}\n`, 'utf8')
console.log(`\n=== P-R6 总验收：${allOk ? '全部通过' : '存在失败项'} ===`)
console.log(`summary -> ${out}`)
for (const i of items) console.log(`${i.ok ? 'OK  ' : 'FAIL'} ${i.id} (pass=${i.pass} fail=${i.fail})`)
process.exit(allOk ? 0 : 1)
