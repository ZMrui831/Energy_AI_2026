#!/usr/bin/env node
// tools/move-chromium-cache.mjs
//
// 阶段 3.1 卫生：把 Chromium/Electron 的 userData 产物从 data\ 顶层迁到 data\.chromium\，
// 让 data\ 顶层只剩领域目录（timer/projects/progress/reports/notes/exports/logs/...）。
//
// 用法：node tools/move-chromium-cache.mjs [--dry-run]
//
// 纪律：
//   · 白名单式迁移 —— 只搬【已知的 Chromium userData 产物】名单里的项，
//     名单外的一律不碰（data/index 是文献插件的 orama 索引，绝不是缓存）；
//   · 同分区 rename（data\ 内 -> data\.chromium\），不复制不删除，失败即中止并报告；
//   · 迁移前后各打印一次 data\ 顶层清单，结果写 data/logs/chromium-move.json 留痕；
//   · 运行中的 Electron 会占用这些文件：调用方需确认应用未在运行。

import { existsSync, mkdirSync, readdirSync, renameSync, statSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

const ROOT = resolveRoot()
const DATA_DIR = join(ROOT, 'data')
const CHROMIUM_DIR = join(DATA_DIR, '.chromium')

/**
 * Chromium userData 产物白名单（按名字精确匹配，不做模糊判断）。
 * 依据：.snapshots 最早快照的 data\ 顶层清单 —— 阶段 0 首次运行 Electron 后
 * 出现的项即 userData 产物；领域目录（notes/timer/index/...）从未出现在该清单里。
 * DIPS-wal 是 DIPS 的 journal（sqlite 附属文件），同属 Chromium。
 */
const CHROMIUM_ITEMS = [
  'Cache',
  'Code Cache',
  'DIPS',
  'DIPS-wal',
  'DawnGraphiteCache',
  'DawnWebGPUCache',
  'DevToolsActivePort',
  'Dictionaries',
  'GPUCache',
  'Local State',
  'Local Storage',
  'Network',
  'Preferences',
  'Session Storage',
  'Shared Dictionary',
  'blob_storage',
  'declarative_performance_observer.db',
  'declarative_performance_observer.db-journal',
]

function resolveRoot() {
  // 本工具只在 research-orb 仓库内运行；用 import.meta 推两级（tools/ -> 仓库根）
  const here = new URL('.', import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')
  return join(here, '..')
}

function topLevel() {
  return readdirSync(DATA_DIR).sort()
}

const DRY = process.argv.includes('--dry-run')

const before = topLevel()
console.log(`data\\ 顶层（迁移前，${before.length} 项）：`)
console.log('  ' + before.join('  '))

if (!existsSync(CHROMIUM_DIR)) {
  if (DRY) {
    console.log(`[dry-run] 将创建 ${CHROMIUM_DIR}`)
  } else {
    mkdirSync(CHROMIUM_DIR, { recursive: true })
    console.log(`已创建 ${CHROMIUM_DIR}`)
  }
}

const moved = []
const skipped = []
const missing = []
for (const name of CHROMIUM_ITEMS) {
  const from = join(DATA_DIR, name)
  const to = join(CHROMIUM_DIR, name)
  if (!existsSync(from)) {
    missing.push(name)
    continue
  }
  if (existsSync(to)) {
    skipped.push(`${name}（目标已存在，保留原样不动）`)
    continue
  }
  if (DRY) {
    console.log(`[dry-run] 将迁移 ${name}`)
    moved.push(name)
    continue
  }
  const isDir = statSync(from).isDirectory()
  renameSync(from, to)
  moved.push(name)
  console.log(`迁移 ${name}（${isDir ? '目录' : '文件'}）`)
}

const after = topLevel()
console.log(`\ndata\\ 顶层（迁移后，${after.length} 项）：`)
console.log('  ' + after.join('  '))

const report = {
  at: new Date().toISOString(),
  dryRun: DRY,
  moved,
  skipped,
  missing,
  dataTopBefore: before,
  dataTopAfter: after,
  chromiumDir: CHROMIUM_DIR,
}
if (!DRY) {
  const logPath = join(DATA_DIR, 'logs', 'chromium-move.json')
  mkdirSync(join(DATA_DIR, 'logs'), { recursive: true })
  writeFileSync(logPath, JSON.stringify(report, null, 2))
  console.log(`\n留痕：data/logs/chromium-move.json`)
}
console.log(`\n汇总：迁移 ${moved.length} 项，跳过 ${skipped.length} 项，不存在 ${missing.length} 项`)
