// tools/accept-stage4-block2.mjs
//
// 阶段 4 块 2（严谨性修正）验收取证器。
//
// 用例（与任务书/主管要求一一对应，全部真跑）：
//   ① 一段输出同屏三档 + 未验证断言区（块 2 验收口径）：走 /verify answer --file 命令路径，
//      proven 用真 PDF 夹具（真 unpdf 引文命中），inferred 一条，伪造 DOI 拒引降级一条。
//      另含块 2 两区：【数值与单位】/【元数据提示】与强度图例常显。
//   ② 数值与单位校验：/verify numbers 命令路径（真 unpdf 回溯）：
//      32 percent 命中 / 50 Hz 回溯失败 / 多功率基准量纲警告。
//   ③ 元数据完整性：/verify meta 三用例（真 net）：
//      a) 真实 DOI 完整题录（预印本=否、检索时间在、缺项无）；
//      b) arXiv URL（预印本=是、版本 v2、无 DOI 缺项显式列出）；
//      c) 伪造 DOI（拒引 + DOI 可解析性缺项显式提示）。
//   ④ fail-closed 回归（主管必修项）：直接调 renderVerifiedAnswer 传裸断言（未先校验）
//      → 绝不进结论区、绝不出 undefined、raw 断言带处理依据。
//   ⑤ 全量测试全绿（≥405：399 + rigor 23 插件 5 fail-closed 回归 1 - 重叠计数见 ⑤ 输出）。
//   ⑥ 真实 electron 冒烟：本阶段改过插件激活路径（/verify 三子命令 + 渲染 fail-closed）。
//   ⑦ 隔离复核：probe-isolation verify（stage32 基线）。
//
// 用法：node tools/accept-stage4-block2.mjs
// 产物：data/logs/stage42-*.txt / .json + data/logs/stage42-summary.json

import { spawn, spawnSync } from 'node:child_process'
import { existsSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'

import { createEngine } from '../packages/plugins/research-literature/index.mjs'
import { renderVerifiedAnswer } from '../packages/plugins/research-literature/lib/cite-verify.mjs'
import { createNet } from '../packages/core/src/net.mjs'
import { PROJECT_ROOT, safeWrite } from '../packages/core/src/safefs.mjs'
import {countOrbAll, killMarked, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-stage4-block2')

const LOGS = join(PROJECT_ROOT, 'data', 'logs')
const APP_LOG = join(LOGS, 'app.jsonl')
const RENDERER_LOG = join(LOGS, 'renderer.jsonl')
const NET_LOG = join(LOGS, 'stage42-net.jsonl')
const FIXTURE_PDF = join(PROJECT_ROOT, 'data', 'fixtures', 'sample-paper.pdf')
const ELECTRON_EXE = ORB_ELECTRON
const RESULTS = []

// 真实 DOI（2026-10-15 实测 Crossref 200；断言与线上记录一致，实时解析如实反映）
const REAL_DOI = '10.1109/lcsys.2020.3044551'
const FAKE_DOI = '10.9999/fake.doi.12345'
const ARXIV_URL = 'https://arxiv.org/abs/1706.03762v2' // 2026-10-15 实测 200：[1706.03762v2] Attention Is All You Need

const startedAt = new Date().toISOString()

function evidence(name, text) {
  safeWrite(join(LOGS, name), text)
  return `data/logs/${name}`
}
function jsonEvidence(name, obj) {
  return evidence(name, JSON.stringify(obj, null, 2))
}
function record(id, title, ok, detail, files = []) {
  RESULTS.push({ id, title, ok: !!ok, detail, files })
  process.stdout.write(`[${ok ? 'PASS' : 'FAIL'}] ${id} ${title}\n        ${String(detail).replace(/\n/g, '\n        ')}\n`)
  if (files.length > 0) process.stdout.write(`        证据：${files.join('  ')}\n`)
}
async function step(id, title, fn) {
  try {
    return await fn()
  } catch (err) {
    record(id, title, false, `异常：${(err && err.message) || err}`, [])
    return null
  }
}
function runNode(args, { env = null } = {}) {
  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  if (env) Object.assign(childEnv, env)
  const r = spawnSync(process.execPath, args, { cwd: PROJECT_ROOT, encoding: 'utf8', env: childEnv })
  return { status: r.status, stdout: String(r.stdout || ''), stderr: String(r.stderr || '') }
}
function existsSyncSafe(p) {
  try {
    return existsSync(p)
  } catch {
    return false
  }
}
function killOwnElectron() { return killMarked(MARK) }

// ---------------------------------------------------------------------------
// 引擎（真 net；scopes 用最小桩——/verify 不落盘，createEngine 传了 scopes 就不会碰 ctx.fs）
// ---------------------------------------------------------------------------

safeWrite(NET_LOG, '') // 截断而非删除，便于逐行断言本次出网
const net = createNet({ logFile: NET_LOG })
const ctx = { log: { info() {}, warn() {}, error() {}, debug() {} }, net }
const engine = createEngine(ctx, {
  scopes: { notes: { name: 'stub' }, pdf: { name: 'stub' }, index: { name: 'stub' }, exports: { name: 'stub' } },
  secretsLoader: () => ({}),
})

/** 本次 net 审计里命中白名单域名的行（证明出网仍只走白名单）。 */
function netAuditLines() {
  if (!existsSyncSafe(NET_LOG)) return []
  return readFileSync(NET_LOG, 'utf8')
    .split('\n')
    .filter((l) => l.trim())
    .map((l) => {
      try {
        return JSON.parse(l)
      } catch {
        return null
      }
    })
    .filter(Boolean)
}

// ---------------------------------------------------------------------------
// ① 一段输出同屏三档 + 未验证断言区（/verify answer --file 命令路径）
// ---------------------------------------------------------------------------

let answerTmp = null

await step('①', '一段输出同屏三档 + 未验证断言区 + 严谨性两区（/verify answer 命令路径）', async () => {
  answerTmp = join(tmpdir(), `stage42-answer-${process.pid}-${Date.now()}.json`)
  writeFileSync(
    answerTmp,
    JSON.stringify({
      lead: '问题：构网型逆变器能否支撑低惯量系统频率稳定？',
      assertions: [
        {
          text: '构网型控制可改善频率最低点（仿真显示 32 percent）。',
          strength: 'proven',
          sources: [{ kind: 'pdf', ref: FIXTURE_PDF, locator: { quote: 'Simulations on a modified IEEE 9-bus system show improved frequency nadir by 32 percent.' } }],
        },
        { text: '惯量支撑策略或可推广至含储能的综合能源系统。', strength: 'inferred' },
        {
          text: '某结论称频率最低点改善 90 percent，但以一篇不存在的文献为依据',
          strength: 'proven',
          sources: [{ kind: 'doi', ref: FAKE_DOI, claim: { title: 'Fabricated Paper' } }],
        },
      ],
    }),
  )
  const r = await engine.verify(`answer --file "${answerTmp}"`)
  const out = r.text

  const conclusion = out.slice(out.indexOf('【结论】'), out.indexOf('【来源清单】'))
  const checks = {
    '强度图例常显（三档枚举同屏）': /强度口径：已证实（有原文出处且通过引用校验）｜推断（模型推理，无原文出处）｜待验证（无来源或校验未通过，不得作为结论）/.test(out),
    '结论区 proven 断言带 [1] 角标与「已证实」': /- 构网型控制可改善频率最低点（仿真显示 32 percent）。 \[1\] —— 已证实/.test(conclusion),
    '结论区 inferred 断言显式标注「推断」': /- 惯量支撑策略或可推广至含储能的综合能源系统。 —— 推断/.test(conclusion),
    'unverified 断言不进结论区（伪造 DOI 降级）': !conclusion.includes('不存在的文献') && !conclusion.includes('90 percent'),
    '未验证断言区带降级原因': /- 某结论称频率最低点改善 90 percent，但以一篇不存在的文献为依据 —— 待验证（全部 1 个来源校验失败）/.test(out),
    '拒引区列出伪造 DOI 且带「引用校验失败（原因）」': /拒引｜DOI 10\.9999\/fake\.doi\.12345｜引用校验失败（DOI 无法解析：Crossref 与 OpenAlex 均未收录该 DOI/.test(out),
    '【数值与单位】区列出无法回溯提示': /【数值与单位】（严谨性校验，由校验器追加）/.test(out) && /未提供原文，1 个数值无法回溯/.test(out),
    '【元数据提示】区列出 PDF 无 DOI 缺项与 DOI 拒引缺项': /【元数据提示】（由校验器追加）/.test(out) && /缺项｜PDF .*：无 DOI/.test(out) && /缺项｜DOI 10\.9999\/fake\.doi\.12345：DOI 可解析性校验未通过（拒引）/.test(out),
    '整段输出无 undefined': !out.includes('undefined'),
  }
  const audit = netAuditLines()
  const txt = [
    '=== ① 一段输出同屏三档 + 未验证断言区（块 2 验收口径，/verify answer 命令路径）===',
    `命令：/verify answer --file（断言 JSON：proven=PDF 引文命中 / inferred=无源推理 / proven=伪造 DOI 拒引降级）`,
    '',
    out,
    '',
    '=== 逐项检查 ===',
    ...Object.entries(checks).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`),
    '',
    `出网审计：${audit.length} 行，域名 ${[...new Set(audit.map((l) => l.host).filter(Boolean))].join(', ') || '（无）'}`,
  ].join('\n')
  const rel = evidence('stage42-01-answer.txt', txt)
  const jsonRel = jsonEvidence('stage42-01-answer.json', { at: new Date().toISOString(), checks, ok: r.ok, uiAssertions: r.ui && r.ui.assertions })
  const ok = Object.values(checks).every(Boolean)
  record('①', '一段输出同屏三档 + 未验证断言区 + 严谨性两区', ok, `${Object.values(checks).filter(Boolean).length}/${Object.keys(checks).length} 项在位${ok ? '' : '（见证据文件）'}`, [rel, jsonRel])
  return r
})

// ---------------------------------------------------------------------------
// ② 数值与单位校验（/verify numbers 命令路径，真 unpdf）
// ---------------------------------------------------------------------------

await step('②', '数值与单位校验：回溯原文（命中/失败）+ 量纲警告（真 PDF 夹具）', async () => {
  const hit = await engine.verify(`numbers Simulations show improved frequency nadir by 32 percent, and the grid runs at 50 Hz. --pdf ${FIXTURE_PDF}`)
  const warn = await engine.verify('numbers All values are on a 100 MVA base, later converted to the 50 MVA base.')

  const checks = {
    '回溯原文声明已提供（本地 PDF + 字符数）': /回溯原文：已提供（.*sample-paper\.pdf，\d+ 字符）/.test(hit.text),
    '32 % 已回溯命中（匹配形态 32percent）': /32 %｜已回溯命中（32percent）/.test(hit.text),
    '50 Hz 回溯失败（原文中未找到该数值+单位）': /50 Hz｜回溯失败（来源中未找到该数值\+单位）/.test(hit.text),
    '结尾结论：1 个数值未回溯，含它的结论不得作为已证实': /→ 1 个数值未能在来源中回溯：含这些数值的结论不得作为「已证实」/.test(hit.text),
    '命令 ok=false（存在回溯失败）': hit.ok === false,
    '量纲警告：检测到多个功率基准（100 MVA / 50 MVA）': /检测到多个功率基准（100 MVA \/ 50 MVA）：p\.u\. 值跨基准不可直接比较/.test(warn.text),
    '量纲警告只提示不影响 ok': warn.ok === true,
  }
  const txt = [
    '=== ② 数值与单位校验（/verify numbers 命令路径，真 unpdf 抽取回溯）===',
    '',
    '--- 用例 a：32 percent 命中 + 50 Hz 回溯失败 ---',
    hit.text,
    '',
    '--- 用例 b：多功率基准量纲警告 ---',
    warn.text,
    '',
    '=== 逐项检查 ===',
    ...Object.entries(checks).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`),
  ].join('\n')
  const rel = evidence('stage42-02-numbers.txt', txt)
  const jsonRel = jsonEvidence('stage42-02-numbers.json', { at: new Date().toISOString(), checks, hitUi: hit.ui, warnUi: warn.ui })
  const ok = Object.values(checks).every(Boolean)
  record('②', '数值与单位校验（回溯命中/失败 + 量纲警告）', ok, `${Object.values(checks).filter(Boolean).length}/${Object.keys(checks).length} 项在位`, [rel, jsonRel])
})

// ---------------------------------------------------------------------------
// ③ 元数据完整性（/verify meta 命令路径，真 net）
// ---------------------------------------------------------------------------

await step('③', '元数据完整性：真实 DOI / arXiv 预印本 / 伪造 DOI 三用例（真 net）', async () => {
  const a = await engine.verify(`meta ${REAL_DOI}`)
  const b = await engine.verify(`meta ${ARXIV_URL}`)
  const c = await engine.verify(`meta ${FAKE_DOI} --title "某篇不存在的论文"`)

  const checks = {
    'a 真实 DOI：预印本=否、DOI=有、检索时间在、缺项无':
      /预印本：否/.test(a.text) && /DOI：有/.test(a.text) && /检索时间：20\d\d-/.test(a.text) && /缺项：无。/.test(a.text),
    'a 真实 DOI：引用校验通过': /引用校验通过/.test(a.text),
    'b arXiv URL：预印本=是（arXiv 1706.03762v2）': /预印本：是（arXiv 1706\.03762v2）/.test(b.text),
    'b arXiv URL：版本 v2 识别': /版本：v2/.test(b.text),
    'b arXiv URL：无 DOI 缺项显式列出 + 未经同行评审提示':
      /缺项｜无 DOI：无法经 Crossref\/OpenAlex 独立核验题录/.test(b.text) && /未经同行评审/.test(b.text),
    'c 伪造 DOI：拒引 + DOI 可解析性缺项显式提示':
      /引用校验失败（DOI 无法解析：Crossref 与 OpenAlex 均未收录该 DOI/.test(c.text) && /缺项｜DOI 可解析性校验未通过（拒引）/.test(c.text),
    '三用例出网仍只走白名单域名': netAuditLines().every((l) => !l.host || /crossref|openalex|arxiv\.org/.test(l.host)),
  }
  const txt = [
    '=== ③ 元数据完整性（/verify meta 命令路径，真 net 出网）===',
    '',
    '--- 用例 a：真实 DOI（10.1109/lcsys.2020.3044551）---',
    a.text,
    '',
    '--- 用例 b：arXiv URL（' + ARXIV_URL + '，2026-10-15 实测 200）---',
    b.text,
    '',
    '--- 用例 c：伪造 DOI（' + FAKE_DOI + '）---',
    c.text,
    '',
    '=== 逐项检查 ===',
    ...Object.entries(checks).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`),
  ].join('\n')
  const rel = evidence('stage42-03-meta.txt', txt)
  const jsonRel = jsonEvidence('stage42-03-meta.json', {
    at: new Date().toISOString(),
    checks,
    aUi: a.ui && a.ui.completeness,
    bUi: b.ui && b.ui.completeness,
    cUi: c.ui && c.ui.completeness,
  })
  const ok = Object.values(checks).every(Boolean)
  record('③', '元数据完整性（预印本/版本/检索时间/DOI 可解析性缺项）', ok, `${Object.values(checks).filter(Boolean).length}/${Object.keys(checks).length} 项在位`, [rel, jsonRel])
})

// ---------------------------------------------------------------------------
// ④ fail-closed 回归（主管必修项：忘记先校验的裸断言）
// ---------------------------------------------------------------------------

await step('④', 'fail-closed 回归：裸断言（未先 verifyAssertions）绝不进结论区、绝无 undefined', async () => {
  const out = renderVerifiedAnswer({
    assertions: [
      { text: '带来源但没先校验的断言', sources: [{ kind: 'doi', ref: '10.1109/x' }], verified: [], rejected: [], unverifiable: [] },
      { text: '完全裸的无源断言' },
      null,
    ],
  })
  const conclusion = out.split(/【来源清单】|【引用校验失败】|【未验证断言】/)[0]
  const checks = {
    '整段输出无 undefined': !out.includes('undefined'),
    '两条裸断言都不在结论区': !conclusion.includes('带来源但没先校验的断言') && !conclusion.includes('完全裸的无源断言'),
    '裸断言进未验证区并写明处理依据':
      /- 带来源但没先校验的断言 —— 待验证（未先经 verifyAssertions 校验，按待验证处理）/.test(out) &&
      /- 完全裸的无源断言 —— 待验证（未先经 verifyAssertions 校验，按待验证处理）/.test(out),
    'null 断言不崩、被按待验证处理': (out.match(/未先经 verifyAssertions 校验/g) || []).length >= 2,
  }
  const txt = [
    '=== ④ fail-closed 回归（主管核验反馈必修项）===',
    '场景：直接调 renderVerifiedAnswer、没有先跑 verifyAssertions（断言无 effective 字段）。',
    '要求：缺 effective 一律按 unverified 处理进「未验证断言」专区；任何字段缺失都兜底为可读文案。',
    '',
    out,
    '',
    '=== 逐项检查 ===',
    ...Object.entries(checks).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`),
  ].join('\n')
  const rel = evidence('stage42-04-failclosed.txt', txt)
  const jsonRel = jsonEvidence('stage42-04-failclosed.json', { at: new Date().toISOString(), checks })
  const ok = Object.values(checks).every(Boolean)
  record('④', 'fail-closed 回归（裸断言不进结论区 / 无 undefined）', ok, `${Object.values(checks).filter(Boolean).length}/${Object.keys(checks).length} 项在位`, [rel, jsonRel])
})

// ---------------------------------------------------------------------------
// ⑤ 全量测试
// ---------------------------------------------------------------------------

await step('⑤', 'node --test 全量（≥407 条全绿）', async () => {
  const files = readdirSync(join(PROJECT_ROOT, 'tests')).filter((f) => f.endsWith('.test.mjs')).map((f) => join('tests', f))
  const r = runNode(['--test', '--test-concurrency=1', ...files])
  const out = r.stdout + r.stderr
  const passM = out.match(/# pass (\d+)/)
  const failM = out.match(/# fail (\d+)/)
  const pass = passM ? Number(passM[1]) : 0
  const fail = failM ? Number(failM[1]) : -1
  const rel = evidence('stage42-05-tests.txt', out)
  const jsonRel = jsonEvidence('stage42-05-tests.json', { at: new Date().toISOString(), total: pass + (fail > 0 ? fail : 0), pass, fail, files: files.length })
  record('⑤', '全量测试全绿（≥407）', fail === 0 && pass >= 407 && r.status === 0, `${pass} 通过，失败 ${fail}`, [rel, jsonRel])
})

// ---------------------------------------------------------------------------
// ⑥ 真实 electron 冒烟（本阶段改过插件激活路径）
// ---------------------------------------------------------------------------

await step('⑥', '真实 electron 冒烟：bridge-injected 且 renderer 无 Uncaught', async () => {
  // S74c·P0-1：这块是**只读**预检（fail-closed），用 _orb-proc 的 countOrbAll 统一口径，
  // 不在本文件内嵌按 app 路径匹配的 PowerShell 串。
  const running = countOrbAll()
  if (Number.isFinite(running) && running > 0) {
    record('⑥', '真实 electron 冒烟', false, `已有 ${running} 个 research-orb 进程在运行，先退出再验收（fail-closed）`, [])
    return null
  }

  const appBefore = existsSyncSafe(APP_LOG) ? readFileSync(APP_LOG, 'utf8').length : 0
  const renBefore = existsSyncSafe(RENDERER_LOG) ? readFileSync(RENDERER_LOG, 'utf8').length : 0

  const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs'), '--no-sandbox'], {
    cwd: PROJECT_ROOT,
    env: (() => { const e = { ...process.env }; delete e.ELECTRON_RUN_AS_NODE; return e })(),
    stdio: 'ignore',
    detached: false,
  })

  const seen = { start: null, coreReady: null, windowReady: null, bridgeInjected: null, bridgeFailed: null, panelFailed: null, rendererGone: null }
  const deadline = Date.now() + 60_000
  while (Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, 1000))
    const appNow = existsSyncSafe(APP_LOG) ? readFileSync(APP_LOG, 'utf8') : ''
    for (const line of appNow.slice(appBefore).split('\n')) {
      if (!line.trim()) continue
      try {
        const j = JSON.parse(line)
        if (j.type === 'start') seen.start = j
        if (j.type === 'core-ready') seen.coreReady = j
        if (j.type === 'window-ready') seen.windowReady = j
        if (j.type === 'bridge-injected') seen.bridgeInjected = j
        if (j.type === 'bridge-inject-failed') seen.bridgeFailed = j
        if (j.type === 'panel-load-failed') seen.panelFailed = j
        if (j.type === 'renderer-gone') seen.rendererGone = j
      } catch {
        /* 半行跳过 */
      }
    }
    if (seen.bridgeInjected || seen.bridgeFailed) break
    if (child.exitCode !== null) break
  }
  if (seen.bridgeInjected) await new Promise((r) => setTimeout(r, 3000))
  try { child.kill('SIGKILL') } catch { /* 已退出 */ }
  await new Promise((r) => setTimeout(r, 1500))
  killOwnElectron()

  const renNow = existsSyncSafe(RENDERER_LOG) ? readFileSync(RENDERER_LOG, 'utf8') : ''
  const newRendererLines = renNow.slice(renBefore).split('\n').filter((l) => l.trim()).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
  const uncaught = newRendererLines.filter((r) => /Uncaught/i.test(String(r.message || '')))

  const injectedOk = !!seen.bridgeInjected
  const ok = injectedOk && !seen.bridgeFailed && !seen.panelFailed && uncaught.length === 0
  const txt = [
    '=== electron 冒烟（--no-sandbox；agent shell 环境既定变通）===',
    '本阶段改动：/verify 新增 numbers/meta/answer 三子命令；渲染层 fail-closed 修复；版本 0.4.0-phase4.2。',
    '',
    JSON.stringify(seen, null, 2),
    '',
    `Uncaught 行数：${uncaught.length}`,
    `bridge-injected：${injectedOk ? '有' : '无'}；inject-failed：${seen.bridgeFailed ? '有（回归！）' : '无'}`,
    '',
    '（render-process-gone 为本机已知 GPU 环境问题，只记录不判负，见 STAGE-LOG。）',
  ].join('\n')
  const rel = evidence('stage42-06-smoke.txt', txt)
  const jsonRel = jsonEvidence('stage42-06-smoke.json', { at: new Date().toISOString(), seen, uncaught, ok })
  record('⑥', '真实 electron 冒烟（新子命令注册不破坏注入）', ok,
    `bridge-injected=${injectedOk ? 'OK' : 'FAIL'} Uncaught=${uncaught.length}`, [rel, jsonRel])
})

// ---------------------------------------------------------------------------
// ⑦ 隔离复核（对最新基线）
// ---------------------------------------------------------------------------

await step('⑦', '隔离复核：probe-isolation verify（对 stage32 基线，本阶段零越界）', async () => {
  const r = runNode([join('tools', 'probe-isolation.mjs'), 'verify', '--tag', 'stage32'])
  const rel = evidence('stage42-07-iso-verify.txt', r.stdout + r.stderr)
  let verify = null
  try { verify = JSON.parse(readFileSync(join(PROJECT_ROOT, 'data', 'shots', 'stage32-iso-verify.json'), 'utf8')) } catch { verify = null }
  const ok = r.status === 0 && !!verify
  record('⑦', 'probe-isolation verify（stage32 基线）：orb 哈希/计划任务/writes 越界 0', ok,
    `exit=${r.status}；结论=${verify ? JSON.stringify(verify.conclusion || verify).slice(0, 300) : '(无)'}`, [rel])
})

// ---------------------------------------------------------------------------
// 汇总
// ---------------------------------------------------------------------------

if (answerTmp) {
  try { rmSync(answerTmp, { force: true }) } catch { /* 忽略 */ }
}

const summary = {
  stage: '4-block2',
  startedAt,
  finishedAt: new Date().toISOString(),
  results: RESULTS,
  allPass: RESULTS.every((r) => r.ok),
}
safeWrite(join(LOGS, 'stage42-summary.json'), JSON.stringify(summary, null, 2))
process.stdout.write(`\n汇总：${RESULTS.filter((r) => r.ok).length}/${RESULTS.length} 通过 -> data/logs/stage42-summary.json\n`)
process.exit(summary.allPass ? 0 : 1)
