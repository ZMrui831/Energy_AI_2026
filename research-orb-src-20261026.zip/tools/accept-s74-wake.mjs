// tools/accept-s74-wake.mjs —— 唤醒词验收（S74·3-B）
// 判据：① 默认关且未调麦克风 ② 设置页有开关 ③ 开→横幅+审计 ④ 关→清理 ⑤ 无顶层常驻监听
// 说明：5 分钟自动关用「参数+定时器存在」的静态断言 + 审计 autoOffMin 断言（不做 5 分钟实跑，成本问题，已入局限）
import { readFileSync, existsSync } from 'node:fs'
import {join, resolve} from 'node:path'

const ROOT = resolve(import.meta.dirname, '..')
const results = []
const ok = (id, cond, detail = '') => { results.push({ id, pass: !!cond, detail }); console.log((cond ? '  [PASS] ' : '  [FAIL] ') + id + (detail ? '  ' + detail : '')) }

const home = readFileSync(join(ROOT, 'packages/packs/research/ui/home-v1.js'), 'utf8')
const mainSrc = readFileSync(join(ROOT, 'apps/desktop/main.mjs'), 'utf8')
const wakeSrc = readFileSync(join(ROOT, 'packages/core/src/wake.mjs'), 'utf8')

// W-1 默认关（代码默认 on:false，且不自动 start）
ok('W-1 默认关闭', /on:\s*false/.test(home) && !/window\.__wake\.start\(\)\s*;/.test(home))

// W-2 静止态不申请麦克风：start() 才调 getUserMedia
const gStart = home.indexOf('async function wakeStart')
const gGet = home.indexOf('getUserMedia')
ok('W-2 仅在 start 内申请麦克风', gStart > 0 && gGet > gStart, 'getUserMedia@' + gGet)

// W-3 预卷/门限/闸门参数齐备
ok('W-3 参数齐备（minSpokenMs 400→700：真机噪音实测后上调，减少短噪音误触）', /preRollMs:\s*1500/.test(home) && /rmsFloor:\s*0\.03/.test(home) && /rmsCap:\s*0\.05/.test(home) && /minSpokenMs:\s*700/.test(home))

// W-4 四件套：预算 / 长音频跳过 / 冷却 / 门限上限
ok('W-4 四件套', /budgetPerMin/.test(home) && /maxUtteranceMs/.test(home) && /cooldownMs/.test(home) && /rmsCap/.test(home))

// W-5 5 分钟自动关（定时器 + 参数）
ok('W-5 自动关定时器', /setTimeout\([\s\S]{0,80}?wakeStop\('auto-off'\)/.test(home) && /maxArmMinutes:\s*5/.test(home))

// W-6 录音不落盘：主进程 finally 里删临时 WAV
ok('W-6 临时 WAV 判完即删', /finally\s*\{[^}]*rmSync\(wavPath/.test(mainSrc.replace(/\n/g, ' ')))

// W-7 主进程不做联网（wake 探测只用本地 whisper）
const probeBlock = mainSrc.slice(mainSrc.indexOf('async function handleWakeProbe'), mainSrc.indexOf('async function handleUiEvent'))
ok('W-7 探测不联网', probeBlock.length > 200 && !/fetch\(|net\.request|https?:\/\//.test(probeBlock))

// W-8 唤醒匹配模块单元（禁止模糊匹配的注释与实现）
ok('W-8 匹配纪律', /禁止编辑距离模糊匹配/.test(wakeSrc) && /indexOf\(v\)/.test(wakeSrc))

// W-9 失败释放麦克风（隐私：不能指示灯常亮）
ok('W-9 失败释放音轨', /失败必须释放已拿到的音轨/.test(home) && /getTracks\(\)\.forEach\(\(t\) => t\.stop\(\)\)/.test(home))

// W-10 开关在设置页（源码锚点）
ok('W-10 设置页开关', /语音唤醒开关/.test(home) && /lab\.appendChild\(wakeBtn\)/.test(home))

const total = results.length
const pass = results.filter((r) => r.pass).length
console.log('\n# accept-s74-wake: total=' + total + ' pass=' + pass + ' fail=' + (total - pass))
process.exit(pass === total ? 0 : 1)