// tools/pack.mjs
//
// P-R6 块 C：可分发产物打包 → dist-package\research-orb-<version>-win-x64.zip
//
// 硬边界（SAFETY.md）：
//   · **不下载** electron / 打包器 / 任何二进制 —— 只用本机已有的文件；
//   · 产物 = 应用源码 + start.cmd + README-QUICKSTART.md + MANIFEST.sha256；
//   · 不包含 data\secrets.json、data\.chromium\、data\browser-profile\、.venv\、.snapshots\
//     （密钥/缓存/快照一律不进包）；
//   · 只写项目内的 dist-package\。
//
// 用法：
//   node tools\pack.mjs                打包当前版本
//   node tools\pack.mjs --verify       校验已生成的 zip（解压 + MANIFEST.sha256 逐条比对）

import { createHash } from 'node:crypto'
import {
  existsSync, mkdirSync, readFileSync, readdirSync, writeFileSync, statSync, rmSync, copyFileSync,
} from 'node:fs'
import { join, relative, sep } from 'node:path'
import { execFileSync, spawnSync } from 'node:child_process'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { APP_VERSION } from '../packages/core/src/version.mjs'

const DIST_DIR = join(PROJECT_ROOT, 'dist-package')

/** 一律排除（密钥 / 缓存 / 快照 / 临时 / 虚拟环境 / node_modules / 证据数据）。 */
const EXCLUDE_DIRS = new Set([
  'node_modules', '.venv', '.snapshots', '.git', 'dist-package', 'data', '__pycache__',
])
/** data\ 下允许进包的白名单（配置模板与只读资源；**不含** secrets/sessions/logs/browser-profile）。 */
const DATA_INCLUDE = new Set(['secrets.example.json', 'themes', 'fonts', 'fixtures', 'demo'])
const DATA_EXCLUDE_FILES = new Set(['secrets.json', 'config.json'])

function walk(dir, base = dir, out = []) {
  let names = []
  try {
    names = readdirSync(dir, { withFileTypes: true })
  } catch {
    return out
  }
  for (const n of names) {
    if (n.name.startsWith('.')) continue
    const p = join(dir, n.name)
    if (n.isDirectory()) {
      if (EXCLUDE_DIRS.has(n.name)) continue
      walk(p, base, out)
    } else {
      out.push(p)
    }
  }
  return out
}

function sha256File(p) {
  return createHash('sha256').update(readFileSync(p)).digest('hex')
}

function relPosix(p) {
  return relative(PROJECT_ROOT, p).split(sep).join('/')
}

/** 收集要打包的文件（含 data\ 的白名单子集）。 */
function collectFiles() {
  const files = []
  // 顶层与 packages/apps/tests/tools/docs/vendor/start*.cmd
  for (const dir of readdirSync(PROJECT_ROOT)) {
    if (dir.startsWith('.')) continue
    if (EXCLUDE_DIRS.has(dir)) continue
    const p = join(PROJECT_ROOT, dir)
    const st = statSync(p)
    if (st.isDirectory()) {
      if (dir === 'data') {
        // data\ 只收白名单
        for (const sub of readdirSync(p)) {
          if (!DATA_INCLUDE.has(sub)) continue
          const sp = join(p, sub)
          if (statSync(sp).isDirectory()) walk(sp, sp, files)
          else if (!DATA_EXCLUDE_FILES.has(sub)) files.push(sp)
        }
      } else {
        walk(p, p, files)
      }
    } else if (/\.(mjs|cjs|js|json|md|cmd|txt|html|css|svg|png|py)$/i.test(dir)) {
      files.push(p)
    }
  }
  return files.sort((a, b) => relPosix(a).localeCompare(relPosix(b)))
}

const QUICKSTART = `# research-orb 快速上手（${APP_VERSION}）

## 运行环境
- Windows 10/11 x64
- Node.js 22+（https://nodejs.org 自行安装；本包不内置也不下载任何二进制）
- 一个本机已安装的 Edge 或 Chrome（无头浏览器复用本机浏览器，**不会**下载浏览器）
- 可选：Python 3.13 + \`.venv\`（仅 Word 导出需要；见下）

## 启动
1. 解压 zip 到任意目录（路径中不要有特殊字符）。
2. 双击 \`start.cmd\`（或 \`start-dev.cmd\` 看详细日志）。
3. 首次启动会创建 \`data\\\`（配置/主题/笔记/日志）。

## 配置
- 模型密钥：把 \`data\\secrets.example.json\` 复制为 \`data\\secrets.json\`，填入 \`deepseek.apiKey\`。
- 形态切换：面板里发 \`/pack list\` → \`/pack use <id>\`（research / general / health / eldercare）。
- 换肤：\`/theme list\` → \`/theme use sky-blue\`（备选 warm-sand / ink-dark）。

## 自检
\`\`\`
node apps\\desktop\\main.mjs --selftest
\`\`\`

## 卸载
直接删除整个解压目录即可。本应用：
- 不写注册表、不建计划任务、不做自动更新；
- 唯一写入范围是解压目录下的 \`data\\\`；
- 不安装全局 npm / pip 包。

## 可选：Word(.docx) 导出
\`\`\`
py -3.13 -m venv .venv
.venv\\Scripts\\pip install python-docx
\`\`\`
（不使用 Word 导出则完全不需要 Python。）

## 校验
\`\`\`
node tools\\pack.mjs --verify
\`\`\`
会重新计算每个文件的 sha256 并与 \`MANIFEST.sha256\` 比对，任何改动都会报出来。
`

function build() {
  const version = APP_VERSION
  const name = `research-orb-${version}-win-x64`
  const staging = join(DIST_DIR, `.staging-${name}`)
  if (existsSync(staging)) rmSync(staging, { recursive: true, force: true })
  mkdirSync(staging, { recursive: true })

  const files = collectFiles()
  const manifest = []
  for (const f of files) {
    const rel = relPosix(f)
    const dest = join(staging, rel)
    mkdirSync(join(dest, '..'), { recursive: true })
    copyFileSync(f, dest)
    manifest.push({ path: rel, bytes: statSync(f).size, sha256: sha256File(f) })
  }

  // README-QUICKSTART.md
  writeFileSync(join(staging, 'README-QUICKSTART.md'), QUICKSTART, 'utf8')
  manifest.push({
    path: 'README-QUICKSTART.md',
    bytes: Buffer.byteLength(QUICKSTART),
    sha256: createHash('sha256').update(QUICKSTART).digest('hex'),
  })

  // MANIFEST.sha256（标准 sha256sum 格式：<hex>  <path>）
  manifest.sort((a, b) => a.path.localeCompare(b.path))
  const manifestText = `${manifest.map((m) => `${m.sha256}  ${m.path}`).join('\n')}\n`
  writeFileSync(join(staging, 'MANIFEST.sha256'), manifestText, 'utf8')
  writeFileSync(
    join(staging, 'MANIFEST.json'),
    `${JSON.stringify({ name, version, platform: 'win-x64', generatedAt: new Date().toISOString(), files: manifest.length }, null, 2)}\n`,
    'utf8'
  )

  // 打包成 zip（用 PowerShell 的 Compress-Archive，本机已有，不下载任何打包器）
  const zipPath = join(DIST_DIR, `${name}.zip`)
  if (existsSync(zipPath)) rmSync(zipPath)
  const r = spawnSync(
    'powershell.exe',
    ['-NoProfile', '-NonInteractive', '-Command',
      `$ErrorActionPreference='Stop'; Compress-Archive -Path '${staging}\\*' -DestinationPath '${zipPath}' -CompressionLevel Optimal; 'zipped'`],
    { encoding: 'utf8', timeout: 300000, windowsHide: true },
  )
  if (!existsSync(zipPath)) {
    throw new Error(`打包失败：${`${r.stdout || ''}${r.stderr || ''}`.slice(0, 400)}`)
  }
  rmSync(staging, { recursive: true, force: true })

  console.log(`打包完成：${relPosix(zipPath)}`)
  console.log(`  文件数：${manifest.length}（+ MANIFEST.sha256 / MANIFEST.json）`)
  console.log(`  zip 大小：${(statSync(zipPath).size / 1024).toFixed(1)} KB`)
  console.log(`  校验：node tools\\pack.mjs --verify`)
  return { zipPath, manifest }
}

function verify() {
  const zips = readdirSync(DIST_DIR).filter((f) => /^research-orb-.*-win-x64\.zip$/.test(f)).sort()
  if (zips.length === 0) throw new Error(`dist-package\\ 下没有 zip（先跑 node tools\\pack.mjs）`)
  const zip = zips[zips.length - 1]
  const zipPath = join(DIST_DIR, zip)
  const extractDir = join(DIST_DIR, `.verify-${zip.replace(/\.zip$/, '')}`)
  if (existsSync(extractDir)) rmSync(extractDir, { recursive: true, force: true })

  const r = spawnSync(
    'powershell.exe',
    ['-NoProfile', '-NonInteractive', '-Command',
      `$ErrorActionPreference='Stop'; Expand-Archive -Path '${zipPath}' -DestinationPath '${extractDir}' -Force; 'ok'`],
    { encoding: 'utf8', timeout: 300000, windowsHide: true },
  )
  if (!existsSync(join(extractDir, 'MANIFEST.sha256'))) {
    throw new Error(`解压失败：${`${r.stdout || ''}${r.stderr || ''}`.slice(0, 300)}`)
  }

  const lines = readFileSync(join(extractDir, 'MANIFEST.sha256'), 'utf8').split('\n').filter(Boolean)
  let ok = 0
  const bad = []
  for (const line of lines) {
    const m = /^([0-9a-f]{64})\s\s(.+)$/.exec(line.trim())
    if (!m) { bad.push(`无法解析：${line}`); continue }
    const [, want, rel] = m
    const p = join(extractDir, rel)
    if (!existsSync(p)) { bad.push(`缺失：${rel}`); continue }
    const got = sha256File(p)
    if (got === want) ok += 1
    else bad.push(`不一致：${rel}`)
  }
  console.log(`校验 ${zip}：${ok}/${lines.length} 通过`)
  if (bad.length) {
    for (const b of bad.slice(0, 20)) console.log(`  FAIL ${b}`)
    throw new Error(`${bad.length} 个文件校验失败`)
  }
  console.log('全部通过：zip 可解压、MANIFEST.sha256 逐条一致。')
  console.log(`解压目录：${extractDir}`)
  rmSync(extractDir, { recursive: true, force: true })
}

if (!existsSync(DIST_DIR)) mkdirSync(DIST_DIR, { recursive: true })
if (process.argv.includes('--verify')) verify()
else build()
