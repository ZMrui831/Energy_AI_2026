// tools/accept-stage2.mjs
//
// 阶段 2 验收取证器（① ~ ⑦ 项，⑧ 隔离复核见 tools/probe-isolation.mjs）。
//
// 为什么要有这个文件而不是手工点界面：
//   1) 验收证据要可复查、可重跑。"我当时点了界面，看起来是对的"不是证据；
//   2) 每条证据都要连同**当时的环境事实**一起留档 —— 问的是哪个源、命中几条、
//      net.jsonl 里出现了哪些主机、bib 自检解析出几条。这些只有程序化采集才拿得全；
//   3) 验收本身要经得住失败：单步失败不许中断，必须如实记录 failed 并继续后面的步骤。
//
// 用法：
//   node tools/accept-stage2.mjs            # 真实网络（走 core net 白名单）
//   node tools/accept-stage2.mjs --no-llm   # 跳过模型调用（省 token）
//
// 产物：data/logs/stage2-*.txt / .json（文本证据）+ data/logs/stage2-summary.json（总表）

import { existsSync, readFileSync, statSync } from 'node:fs'
import { join } from 'node:path'

import { createCoreHost } from '../apps/desktop/core-host.mjs'
import { ALLOWED_DOMAINS, DEFAULT_NET_LOG } from '../packages/core/src/net.mjs'
import { PROJECT_ROOT, safeWrite } from '../packages/core/src/safefs.mjs'

const NO_LLM = process.argv.includes('--no-llm')
const LOGS = join(PROJECT_ROOT, 'data', 'logs')
const FIXTURE_PDF = join(PROJECT_ROOT, 'data', 'fixtures', 'sample-paper.pdf')

const results = []
const startedAt = new Date().toISOString()

function evidence(name, text) {
  const rel = `data/logs/${name}`
  safeWrite(join(LOGS, name), text)
  return rel
}

function jsonEvidence(name, obj) {
  return evidence(name, JSON.stringify(obj, null, 2))
}

function netSlice(fromLine) {
  if (!existsSync(DEFAULT_NET_LOG)) return []
  const lines = readFileSync(DEFAULT_NET_LOG, 'utf8').split('\n').filter((l) => l.trim())
  return lines.slice(fromLine).map((l) => JSON.parse(l))
}

function netLines() {
  if (!existsSync(DEFAULT_NET_LOG)) return 0
  return readFileSync(DEFAULT_NET_LOG, 'utf8').split('\n').filter((l) => l.trim()).length
}

function record(id, title, ok, detail, files = []) {
  results.push({ id, title, ok: !!ok, detail, files })
  const mark = ok ? 'PASS' : 'FAIL'
  process.stdout.write(`[${mark}] ${id} ${title}\n        ${String(detail).replace(/\n/g, '\n        ')}\n`)
  if (files.length > 0) process.stdout.write(`        证据：${files.join('  ')}\n`)
}

async function step(id, title, fn) {
  try {
    const r = await fn()
    return r
  } catch (err) {
    record(id, title, false, `异常：${(err && err.message) || err}`, [])
    return null
  }
}

// ---------------------------------------------------------------------------

const host = createCoreHost()
const reg = host.registry
const enabled = await reg.enableAll()
process.stdout.write(`插件启用：${enabled.map((e) => `${e.id}:${e.enabled ? 'on' : 'off(' + (e.error || '') + ')'}`).join('  ')}\n\n`)

const hostStatus = host.status()
process.stdout.write(
  `provider：${hostStatus.providers
    .map((p) => {
      const ready = p.config && p.config.ready
      const key = (p.config && p.config.key) || '***'
      return `${p.id}(${ready ? 'ready' : 'no-key'} ${key}, ${p.defaultModel})`
    })
    .join(' / ')}\n\n`,
)

// --- ① /find -----------------------------------------------------------------
await step('①', '/find 四源检索', async () => {
  const before = netLines()
  const r = await reg.runCommand('find', 'grid-forming inverter inertia support')
  const slice = netSlice(before)
  const hosts = [...new Set(slice.map((l) => l.host))].sort()
  const badHosts = slice.filter((l) => l.host && !ALLOWED_DOMAINS.includes(l.host))
  const cands = (r.value && r.value.ui && r.value.ui.candidates) || []
  const hasFields = cands.every(
    (c) => 'title' in c && 'authors' in c && 'venue' in c && 'year' in c && 'doi' in c && 'source' in c,
  )
  const txt = [
    `命令：/find grid-forming inverter inertia support`,
    `结果：ok=${r.ok}  候选=${cands.length} 条`,
    `字段完整性（title/authors/venue/year/doi/source）：${hasFields ? '全部具备' : '有缺失'}`,
    ``,
    `--- 命令输出 ---`,
    (r.value && r.value.text) || '(无)',
    ``,
    `--- 本次窗口 net.jsonl（${slice.length} 行）---`,
    ...slice.map((l) => `${l.decision} ${l.host} ${l.url} status=${l.status} bucket=${l.bucketKey} queued=${l.queued}`),
    ``,
    `出现的主机：${hosts.join(', ')}`,
    `白名单：${ALLOWED_DOMAINS.join(', ')}`,
    `越界主机数：${badHosts.length}`,
    ``,
    `--- 源状态 ---`,
    JSON.stringify((r.value && r.value.ui && r.value.ui.sources) || [], null, 2),
    ``,
    `--- 候选明细（前 12）---`,
    ...cands.slice(0, 12).map((c, i) => `${i + 1}. [${c.score}] ${c.year || '?'} ${c.citations ?? '?'}引用 ${(c.sources || []).join('/')} | ${c.title} | doi=${c.doi || '(无)'} | ${c.venue}`),
  ].join('\n')
  const rel = evidence('stage2-01-find.txt', txt)
  const jsonRel = jsonEvidence('stage2-01-find.json', {
    at: new Date().toISOString(),
    ok: r.ok,
    query: 'grid-forming inverter inertia support',
    candidateCount: cands.length,
    candidates: cands,
    sources: (r.value && r.value.ui && r.value.ui.sources) || [],
    stats: (r.value && r.value.ui && r.value.ui.stats) || null,
    netHosts: hosts,
    netLines: slice.length,
    allowedDomains: [...ALLOWED_DOMAINS],
    outOfAllowlist: badHosts.length,
  })
  const ok = r.ok && cands.length >= 5 && hasFields && badHosts.length === 0 && slice.length > 0
  record('①', '/find 返回 ≥5 篇候选且 net.jsonl 仅白名单域名', ok, `候选 ${cands.length} 条；net 窗口 ${slice.length} 行；出现主机 ${hosts.join('/')}；越界 ${badHosts.length}`, [rel, jsonRel])
  return cands
})

// --- ② /card（本地 PDF） ------------------------------------------------------
let firstCardRel = null
await step('②', '/card 对本地 PDF 生成结构化卡片', async () => {
  const before = netLines()
  const r = await reg.runCommand('card', `${FIXTURE_PDF} --topic gfm --heuristic`)
  const ui = (r.value && r.value.ui) || {}
  const card = ui.card || null
  const fields = card ? Object.keys(card) : []
  const expected = ['title', 'authors', 'venue', 'year', 'doi', 'url', 'pdf', 'tags', '问题', '方法', '数据与算例', '结论与局限', '可复用点', '待验证点', '与我课题的关系', '读数（0-5）']
  const missing = expected.filter((f) => !fields.includes(f))
  const mdPath = ui.rel ? join(PROJECT_ROOT, ui.rel.replace(/\//g, '\\')) : null
  const mdExists = mdPath ? existsSync(mdPath) : false
  firstCardRel = ui.rel || null
  const txt = [
    `命令：/card ${FIXTURE_PDF} --topic gfm --heuristic`,
    `结果：ok=${r.ok}  code=${(r.value && r.value.code) || '-'}`,
    '',
    '--- 命令输出 ---',
    (r.value && r.value.text) || '(无)',
    '',
    `写入文件：${ui.rel || '(无)'}  存在=${mdExists}`,
    `字段数：${fields.length}  缺字段：${missing.length === 0 ? '无' : missing.join(', ')}`,
    `书目来源：${ui.biblioVia || '-'}  解释性字段来源：${ui.generatedBy || '-'}`,
    `抽取文本：${ui.pdfRel || '-'}`,
    `索引条数：${ui.indexCount}`,
    '',
    '--- 卡片 front-matter + 正文（前 60 行）---',
    mdExists ? readFileSync(mdPath, 'utf8').split('\n').slice(0, 60).join('\n') : '(文件不存在)',
    '',
    `本次窗口 net.jsonl 行数：${netLines() - before}（PDF 路径若含可识别 DOI 会反查元数据，这里允许有）`,
  ].join('\n')
  const rel = evidence('stage2-02-card.txt', txt)
  const jsonRel = jsonEvidence('stage2-02-card.json', {
    at: new Date().toISOString(),
    ok: r.ok,
    target: FIXTURE_PDF,
    mode: 'heuristic',
    cardRel: ui.rel || null,
    card,
    fieldCount: fields.length,
    missingFields: missing,
    generatedBy: ui.generatedBy || null,
    biblioVia: ui.biblioVia || null,
    pdfRel: ui.pdfRel || null,
    indexCount: ui.indexCount,
  })
  const ok = !!r.ok && !!card && missing.length === 0 && mdExists
  record('②', '/card 生成字段齐全的卡片并写入 data/notes', ok, `${ui.rel || '未写入'}；字段 ${fields.length}/16；缺 ${missing.length}`, [rel, jsonRel])
  return card
})

// --- ② b（真实模型路径，不阻断验收） -----------------------------------------
if (!NO_LLM) {
  await step('②b', '/card 走真实模型生成解释性字段', async () => {
    const r = await reg.runCommand('card', `${FIXTURE_PDF} --topic gfm`)
    const ui = (r.value && r.value.ui) || {}
    const txt = [
      `命令：/card ${FIXTURE_PDF} --topic gfm（走模型，默认 deepseek-chat）`,
      `结果：ok=${r.ok}  code=${(r.value && r.value.code) || '-'}`,
      '',
      (r.value && r.value.text) || '(无)',
      '',
      `generatedBy=${ui.generatedBy || '-'}  fieldsFromLlm=${JSON.stringify(ui.fieldsFromLlm || [])}`,
    ].join('\n')
    const rel = evidence('stage2-02b-card-llm.txt', txt)
    record('②b', '/card 走真实模型（附加证据，不阻断）', !!r.ok, `ok=${r.ok} generatedBy=${ui.generatedBy || '-'} fieldsFromLlm=${(ui.fieldsFromLlm || []).length}/7`, [rel])
    return r
  })
}

// --- ② c 批量归档（让 ③④⑤ 的证据来自多张卡片，而不是孤例） ----------------------
await step('②c', '/card --find 批量归档候选', async () => {
  const r = await reg.runCommand('card', '--find 1,2,3,4,5 --topic gfm --heuristic')
  const ui = (r.value && r.value.ui) || {}
  const okCount = (ui.results || []).filter((x) => x.ok).length
  const txt = [
    `命令：/card --find 1,2,3,4,5 --topic gfm --heuristic`,
    `结果：ok=${r.ok}  成功 ${okCount}/${(ui.results || []).length}  索引 ${ui.indexCount} 条`,
    '',
    (r.value && r.value.text) || '(无)',
    '',
    '--- 写入卡片 ---',
    ...(ui.results || []).map((x) => `${x.ok ? 'OK ' : 'FAIL'} ${x.rel || ''} | ${x.title} | generatedBy=${x.generatedBy || '-'}`),
  ].join('\n')
  const rel = evidence('stage2-02c-card-batch.txt', txt)
  const jsonRel = jsonEvidence('stage2-02c-card-batch.json', { at: new Date().toISOString(), ok: r.ok, okCount, total: (ui.results || []).length, indexCount: ui.indexCount, results: (ui.results || []).map((x) => ({ ok: x.ok, rel: x.rel, title: x.title, generatedBy: x.generatedBy, code: x.code || null })) })
  record('②c', '批量从候选生成卡片（让后续检索证据来自多张卡片）', !!r.ok && okCount >= 3, `成功 ${okCount}/${(ui.results || []).length}；索引 ${ui.indexCount} 条`, [rel, jsonRel])
  return ui
})

// --- ③ 索引召回 ---------------------------------------------------------------
await step('③', 'Orama hybrid 检索召回已归档卡片', async () => {
  const r = await reg.runCommand('recall', 'grid-forming inverter inertia support --top 5')
  const ui = (r.value && r.value.ui) || {}
  const txt = [
    `命令：/recall grid-forming inverter inertia support --top 5`,
    `结果：ok=${r.ok}  命中 ${ui.hitCount} 张  检索模式 ${ui.searchMode}  索引 ${ui.indexCount} 条`,
    '',
    '--- 命令输出 ---',
    (r.value && r.value.text) || '(无)',
  ].join('\n')
  const rel = evidence('stage2-03-recall-index.txt', txt)
  const jsonRel = jsonEvidence('stage2-03-recall-index.json', {
    at: new Date().toISOString(),
    ok: r.ok,
    hitCount: ui.hitCount,
    searchMode: ui.searchMode,
    indexCount: ui.indexCount,
    citations: ui.citations,
    mode: ui.mode,
  })
  const ok = !!r.ok && ui.hitCount >= 1 && Number(ui.indexCount) >= 3
  record('③', 'Orama hybrid 检索能召回已归档卡片', ok, `命中 ${ui.hitCount}；模式 ${ui.searchMode}；索引 ${ui.indexCount} 条`, [rel, jsonRel])
  return ui
})

// --- ④ /bib ------------------------------------------------------------------
await step('④', '/bib 导出并用 citation-js 自检', async () => {
  const r = await reg.runCommand('bib', 'gfm')
  const ui = (r.value && r.value.ui) || {}
  const check = ui.check || {}
  const bibPath = ui.file ? join(PROJECT_ROOT, 'data', 'exports', ui.file) : null
  const bibText = bibPath && existsSync(bibPath) ? readFileSync(bibPath, 'utf8') : '(未生成)'
  const txt = [
    `命令：/bib gfm`,
    `结果：ok=${r.ok}  文件=data/exports/${ui.file || '(无)'}  条数=${ui.count}`,
    `citation-js 自检：ok=${check.ok}  解析 ${check.parsed}/${check.expected}  丢失 DOI=[${(check.missingDoi || []).join(', ')}]`,
    '',
    '--- 命令输出 ---',
    (r.value && r.value.text) || '(无)',
    '',
    '--- 导出文件全文 ---',
    bibText,
    '',
    '--- citation-js 回读结果（解析出的标题与 DOI）---',
    JSON.stringify({ titles: check.titles, parsedDois: check.dois && check.dois.parsed }, null, 2),
  ].join('\n')
  const rel = evidence('stage2-04-bib.txt', txt)
  const jsonRel = jsonEvidence('stage2-04-bib.json', {
    at: new Date().toISOString(),
    ok: r.ok,
    file: ui.file,
    count: ui.count,
    bytes: ui.bytes,
    keys: ui.keys,
    check,
  })
  const ok = !!r.ok && !!check.ok && check.parsed === check.expected && check.parsed >= 3
  record('④', '/bib 导出能被 citation-js 正确解析', ok, `解析 ${check.parsed}/${check.expected}；丢失 DOI ${(check.missingDoi || []).length} 条`, [rel, jsonRel])
  return ui
})

// --- ⑤ /recall 带出处 ---------------------------------------------------------
await step('⑤', '/recall 答案带卡片出处', async () => {
  const r = await reg.runCommand('recall', '构网型逆变器的惯量支撑有哪些实现路径')
  const ui = (r.value && r.value.ui) || {}
  const text = (r.value && r.value.text) || ''
  const footerIdx = text.indexOf('出处（由检索层生成')
  const footer = footerIdx >= 0 ? text.slice(footerIdx) : '(未找到出处表)'
  const txt = [
    `命令：/recall 构网型逆变器的惯量支撑有哪些实现路径`,
    `结果：ok=${r.ok}  模式=${ui.mode}  命中=${ui.hitCount}  检索式扩展=${ui.expansion ? ui.expansion.query : '无'}`,
    `模型引用标记：citedByModel=${ui.citedByModel}  越界引用=${JSON.stringify(ui.invalidCitations || [])}`,
    '',
    '--- 完整输出 ---',
    text,
    '',
    '--- 出处表（由检索层生成，非模型输出）---',
    footer,
    '',
    '--- 结构化出处 ---',
    JSON.stringify(ui.citations || [], null, 2),
  ].join('\n')
  const rel = evidence('stage2-05-recall-cite.txt', txt)
  const jsonRel = jsonEvidence('stage2-05-recall-cite.json', {
    at: new Date().toISOString(),
    ok: r.ok,
    mode: ui.mode,
    hitCount: ui.hitCount,
    expansion: ui.expansion || null,
    citations: ui.citations || [],
    citedByModel: ui.citedByModel,
    answer: ui.answer || null,
  })
  const hasCite = /\[\d+\]/.test(footer) && (ui.citations || []).length >= 1
  const ok = !!r.ok && hasCite
  record('⑤', '/recall 的答案带卡片出处', ok, `模式 ${ui.mode}；出处 ${(ui.citations || []).length} 条；模型引用=${ui.citedByModel}`, [rel, jsonRel])
  return ui
})

// --- ⑥ 依赖 ------------------------------------------------------------------
await step('⑥', 'DEPS.md 与 npm ls 输出', async () => {
  const depsPath = join(PROJECT_ROOT, 'docs', 'DEPS.md')
  const depsDoc = existsSync(depsPath) ? readFileSync(depsPath, 'utf8') : ''
  const lock = JSON.parse(readFileSync(join(PROJECT_ROOT, 'package-lock.json'), 'utf8'))
  const rows = Object.entries(lock.packages || {})
    .filter(([p]) => p.startsWith('node_modules/'))
    .map(([p, m]) => ({
      name: p.slice('node_modules/'.length),
      version: m.version,
      license: m.license || '(lock 未标注)',
      hasInstallScript: !!(m.hasInstallScript || (m.scripts && (m.scripts.postinstall || m.scripts.preinstall))),
    }))
    .sort((a, b) => a.name.localeCompare(b.name))
  const missingInDoc = rows.filter((r) => !depsDoc.includes(r.name) || !depsDoc.includes(r.version))
  const pkg = JSON.parse(readFileSync(join(PROJECT_ROOT, 'package.json'), 'utf8'))
  const txt = [
    `docs/DEPS.md 存在：${existsSync(depsPath)}（${depsDoc.length} 字节）`,
    `package.json dependencies：${JSON.stringify(pkg.dependencies, null, 2)}`,
    `锁定的依赖总数（含传递）：${rows.length}`,
    `DEPS.md 未收录的包：${missingInDoc.length === 0 ? '无' : missingInDoc.map((r) => r.name).join(', ')}`,
    `带安装期脚本的包：${rows.filter((r) => r.hasInstallScript).length} 个${rows.filter((r) => r.hasInstallScript).length ? ' -> ' + rows.filter((r) => r.hasInstallScript).map((r) => r.name).join(', ') : ''}`,
    '',
    '--- 全量依赖（包名 | 版本 | license）---',
    ...rows.map((r) => `${r.name} | ${r.version} | ${r.license}`),
  ].join('\n')
  const rel = evidence('stage2-06-deps.txt', txt)
  const jsonRel = jsonEvidence('stage2-06-deps.json', { at: new Date().toISOString(), direct: pkg.dependencies, all: rows, missingInDoc: missingInDoc.map((r) => r.name), installScripts: rows.filter((r) => r.hasInstallScript).map((r) => r.name) })
  const ok = depsDoc.length > 1000 && missingInDoc.length === 0 && rows.every((r) => !r.hasInstallScript) && rows.length >= 19
  record('⑥', 'docs/DEPS.md 收录每个依赖的版本与 license', ok, `${rows.length} 个包；未收录 ${missingInDoc.length}；安装期脚本 ${rows.filter((r) => r.hasInstallScript).length}`, [rel, jsonRel])
  return rows
})

// --- ⑦ 测试 ------------------------------------------------------------------
await step('⑦', 'node --test 全绿', async () => {
  const { spawnSync } = await import('node:child_process')
  // 子进程环境要显式清掉 ELECTRON_RUN_AS_NODE：agent shell 里它会让 Electron 退化成纯 node，
  // 而这里用的就是 node，留着它会污染测试子进程的行为（阶段 1 踩过的坑）。
  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  const r = spawnSync(process.execPath, ['--test', 'tests/connectors.test.mjs', 'tests/pdf.test.mjs', 'tests/cards.test.mjs', 'tests/index.test.mjs', 'tests/bib.test.mjs', 'tests/literature-plugin.test.mjs', 'tests/plugins.test.mjs', 'tests/isolation.test.mjs', 'tests/net.test.mjs', 'tests/providers.test.mjs', 'tests/agent.test.mjs', 'tests/ratelimit.test.mjs'], {
    cwd: PROJECT_ROOT,
    encoding: 'utf8',
    env: childEnv,
  })
  const out = String(r.stdout || '') + String(r.stderr || '')
  const m = /# tests (\d+)[\s\S]*?# pass (\d+)[\s\S]*?# fail (\d+)/.exec(out)
  const total = m ? Number(m[1]) : 0
  const pass = m ? Number(m[2]) : 0
  const fail = m ? Number(m[3]) : 0
  const rel = evidence('stage2-07-tests.txt', out)
  const jsonRel = jsonEvidence('stage2-07-tests.json', { at: new Date().toISOString(), total, pass, fail, perFile: [...out.matchAll(/^ok \d+ - /gm)].length })
  const ok = fail === 0 && total >= 90 && r.status === 0
  record('⑦', 'node --test 全绿（不少于 90 条）', ok, `${pass}/${total} 通过，失败 ${fail}`, [rel, jsonRel])
  return { total, pass, fail }
})

// --- 汇总 --------------------------------------------------------------------
const summary = {
  startedAt,
  finishedAt: new Date().toISOString(),
  results,
  allPass: results.every((r) => r.ok),
}
safeWrite(join(LOGS, 'stage2-summary.json'), JSON.stringify(summary, null, 2))
process.stdout.write(`\n汇总：${results.filter((r) => r.ok).length}/${results.length} 通过 -> data/logs/stage2-summary.json\n`)
await host.dispose()
process.exit(summary.allPass ? 0 : 1)
