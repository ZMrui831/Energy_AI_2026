// tools/accept-s74-scope.mjs —— S74·1-B Q6 时间作用域验收（ASTRA 方案，全采纳）
// 单行复跑：node tools\accept-s74-scope.mjs
import './_accept-isolate.mjs' // 必须第一个 import：隔离 ORB_DATA_DIR（daily 流水线会写审计/记忆）
import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { parseQueryScope, bjDayStart, bjDayLabel, bjHm } from '../packages/core/src/query-scope.mjs'
import { parseTimeRange, retrieveEvents, buildRecallAnswer } from '../packages/plugins/coach/confusion.mjs'

const items = []
const check = (id, ok, detail = '') => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300) }); console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's74-scope')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(WORK, { recursive: true })
const TRAJ = join(WORK, 'trajectory.jsonl')
const INC = join(WORK, 'incremental.jsonl')

// ── 夹具：跨午夜场景。referenceTime 固定在"次日 00:05"（北京时间），昨天的 4 条 + 今天的 3 条。
//   机器本机就是 +08:00，但断言一律走 query-scope 的北京时间口径（不依赖本机时区）。
const NOW = Date.now()
const D0 = bjDayStart(NOW)                 // 今日 00:00（北京）
const REF = D0 + 5 * 60e3                  // 次日 00:05（北京）→ 对 query 而言"今天"= D0 这一天
const iso = (ms) => new Date(ms).toISOString()
const rows = [
  { ms: D0 - 22 * 3600e3, w: 'Word 昨日早', id: 'fr-y0900' },   // 昨天 02:00
  { ms: D0 - 20 * 3600e3, w: 'Zotero 昨日', id: 'fr-y1100' },   // 昨天 04:00
  { ms: D0 - 8 * 3600e3, w: 'Code 昨晚', id: 'fr-y2100' },      // 昨天 18:00
  { ms: D0 - 60e3, w: 'Edge 昨夜尾', id: 'fr-y2359' },          // 昨天 23:59（距 REF 仅 6 分钟 —— 跨午夜关键样本）
  { ms: D0 + 1 * 60e3, w: 'Word 今晨', id: 'fr-t0001' },        // 今天 00:01
  { ms: D0 + 3 * 60e3, w: 'Zotero 今晨', id: 'fr-t0003' },      // 今天 00:03
  { ms: REF - 60e3, w: 'Code 今晨2', id: 'fr-t0004' },          // 今天 00:04
]
writeFileSync(TRAJ, rows.map((r) => JSON.stringify({ ts: iso(r.ms), window: r.w, process: 'proc.exe', intent: '任务', structuredIntent: '工作', evidence: { frameId: r.id, textSha256: 's-' + r.id } })).join('\n') + '\n')
writeFileSync(INC, '')

const q = (text) => parseQueryScope(text, { nowMs: REF })
const run = (text, limit = 50) => {
  const query = q(text)
  const events = retrieveEvents({ trajectoryFile: TRAJ, incrementalFile: INC, range: query, limit })
  return { query, events, text: buildRecallAnswer(events, query, {}) }
}

try {
  // ① "刚刚" → today 且 30 分钟窗
  const a = run('刚刚')
  check('S-1 刚刚 → scope=today 且 30 分钟窗', a.query.scope === 'today' && Date.parse(a.query.end) - Date.parse(a.query.start) === 30 * 60e3,
    `scope=${a.query.scope} label=${a.query.label}`)
  // ② "今天" → 当日 00:00–now
  const b = run('今天')
  check('S-2 今天 → scope=today，起点=当日 00:00', b.query.scope === 'today' && Date.parse(b.query.start) === D0 && Date.parse(b.query.end) === REF,
    `label=${b.query.label}`)
  // ③ "昨天" → relative_day(-1)，条目带日期 + archived:true
  const c = run('昨天')
  const cOk = c.query.scope === 'relative_day' && c.query.includeArchive === true && c.events.length === 4
    && c.events.every((e) => e.archived === true) && c.text.split('\n').slice(1).every((l) => /^\d{2}-\d{2} \d{2}:\d{2} /.test(l))
  check('S-3 昨天 → relative_day(-1) 含归档，条目带日期（MM-DD HH:MM）', cOk, `label=${c.query.label} n=${c.events.length}`)
  // ④ 跨午夜：referenceTime=次日 00:05，"刚刚"= 30 分钟窗 → 含昨日 23:59（窗口内）但**必须**被
  //    today 作用域纪律剔除（今日只到 23:59 之前不会混进"今天"的答案）。
  const d = run('刚刚')
  const dIds = d.events.map((e) => e.evidence.frameId)
  check('S-4 跨午夜：referenceTime=00:05 的"刚刚"不混昨日 23:59（即使窗口覆盖它）',
    d.events.length === 3 && dIds.every((x) => /^fr-t/.test(x)) && !dIds.includes('fr-y2359'), `n=${d.events.length} ids=${dIds.join(',')}`)
  // ⑤ today 答案禁止出现非今日条目
  const e5 = run('今天')
  const bad = e5.events.filter((ev) => ev.archived === true)
  const stampRe = /^\d{2}-\d{2} /
  check('S-5 today 答案无昨日条目（archived 全 false、条目不带 MM-DD 日期前缀）',
    bad.length === 0 && e5.events.length === 3 && !e5.text.split('\n').slice(1).some((l) => stampRe.test(l)),
    `n=${e5.events.length} archived=${bad.length}`)
  // ⑥ 顶部含范围与条数
  check('S-6 顶部 = 实际范围 + 条数', /（今天 \d{2}:\d{2}–\d{2}:\d{2} · 3 条）/.test(e5.text), e5.text.split('\n')[0])
  // ⑦ "昨天"条目全部标 archived:true 且不进 today 作用域
  check('S-7 归档条目必须显式标注 〔归档〕', c.text.split('\n').slice(1).every((l) => l.includes('〔归档〕')), c.text.split('\n')[1] || '')
  // ⑧ 解析器只产 scope —— 取数逻辑不看字符串（同窗口不同说法结果一致）
  const f1 = retrieveEvents({ trajectoryFile: TRAJ, incrementalFile: INC, range: { from: D0, to: REF } })
  const f2 = retrieveEvents({ trajectoryFile: TRAJ, incrementalFile: INC, query: q('今天') })
  check('S-8 同窗口下"裸 range"与"query"取数一致（取数不看字符串）',
    JSON.stringify(f1.map((x) => x.evidence.frameId)) === JSON.stringify(f2.map((x) => x.evidence.frameId)), `n1=${f1.length} n2=${f2.length}`)
  // ⑨ 昨天 → relative_day 不含今日条目（窗口 00:00–24:00 开区间）
  check('S-9 昨天 00:00–24:00 不含今日 00:00 之后的行', c.events.every((ev) => Date.parse(ev.ts) < D0), `max=${c.events.length ? bjHm(Date.parse(c.events[0].ts)) : '-'}`)
  // ⑩ 日报基数（spec ⑦）：真实跑一遍 daily 流水线（stub router/extractor），
  //    断言：归档行与非今日行**都不**进评分基数，日报正文带 archive_reference。
  let pipeN = 0
  const { createDailyPipeline } = await import('../packages/plugins/coach/daily.mjs')
  const NOW2 = Date.now()
  const D0r = bjDayStart(NOW2)
  const pipe = createDailyPipeline({
    dir: WORK,
    router: { run: async () => ({ ok: true, text: '（非 JSON，走 unavailable 分支）' }) },
    extractor: { extract: async ({ imagePath }) => ({ ok: true, frameId: 'fr-pipe' + (pipeN++), text: '今日工作文本', textSha256: 'sha-' + Date.now() + '-' + Math.random(), source: 'stub', structured: { intent: '工作', app: 'Word' } }) },
    now: () => NOW2,
  })
  const trajPipe = join(WORK, 'trajectory.jsonl')
  writeFileSync(trajPipe, [
    JSON.stringify({ ts: iso(NOW2 - 4 * 60e3), window: 'Word 今1', process: 'winword.exe', intent: 'a', structuredIntent: '工作', line: 'work', evidence: { frameId: 'fr-keep1', textSha256: 'k1' } }),
    JSON.stringify({ ts: iso(NOW2 - 2 * 60e3), window: 'Code 今2', process: 'code.exe', intent: 'b', structuredIntent: '工作', line: 'work', evidence: { frameId: 'fr-keep2', textSha256: 'k2' } }),
    JSON.stringify({ ts: iso(D0r + 60e3), window: 'Zotero 今早', process: 'zotero.exe', intent: 'c', structuredIntent: '工作', line: 'work', evidence: { frameId: 'fr-keep3', textSha256: 'k3' } }),
    JSON.stringify({ ts: iso(D0r - 3600e3), window: '昨日归档', process: 'old.exe', intent: 'd', line: 'work', archive: true, evidence: { frameId: 'fr-arch1', textSha256: 'a1' } }),
    JSON.stringify({ ts: iso(D0r - 7200e3), window: '昨日未标', process: 'old2.exe', intent: 'e', line: 'work', evidence: { frameId: 'fr-old2', textSha256: 'a2' } }),
  ].join('\n') + '\n')
  const framePath = join(WORK, 'frame.png')
  writeFileSync(framePath, Buffer.alloc(2048, 7))
  const r10 = await pipe.run({ consentActive: true, frames: [{ imagePath: framePath, window: 'Edge', process: 'msedge.exe', source: 'perception' }] })
  const report10 = r10 && r10.reportPath && (await import('node:fs')).existsSync(r10.reportPath) ? readFileSync(r10.reportPath, 'utf8') : ''
  const nKeep = 3 + 1 // 3 条今日已入账 + 本轮 1 帧新入账
  check('S-10 评分基数：归档/非今日行不计入（trajectoryCount=4，archive_reference=2）',
    r10 && r10.trajectoryCount === nKeep && r10.archiveReference === 2,
    `count=${r10 && r10.trajectoryCount} archRef=${r10 && r10.archiveReference} reportHas=${report10.includes('archive_reference')}`)
  check('S-11 日报正文含 archive_reference 字段且不计分说明', report10.includes('archive_reference：') && report10.includes('不参与当日评分基数'), (report10.split('\n').find((l) => l.includes('archive_reference')) || '').slice(0, 90))
} catch (err) {
  check('S-0 验收脚本崩溃', false, String((err && err.stack) || err).slice(0, 300))
}

const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s74-scope: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(items.every((i) => i.ok) ? 0 : 1)
