// tools/accept-s69-evidence.mjs —— S69·1B 证据卫生验收（命令帧隔离 / 空帧拦截 / 触发器回包 / 死代码）
// 单行复跑：node tools\accept-s69-evidence.mjs
import { mkdirSync, readFileSync, rmSync, writeFileSync, existsSync, statSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createDailyPipeline } from '../packages/plugins/coach/daily.mjs'
import { frameBytesGuard } from '../packages/plugins/coach/extract.mjs'

const items = []
const check = (id, ok, detail = '') => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300) }); console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's69-ev')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(join(WORK, 'coach'), { recursive: true })
const COACH_DIR = join(WORK, 'coach')
const COACH_LOG = join(PROJECT_ROOT, 'data', 'logs', 'coach.jsonl')
const fsize = (p) => { try { return statSync(p).size } catch { return 0 } }

const T0 = Date.parse('2026-10-25T18:00:00+08:00')
const now = () => T0
const stubExtractor = {
  async extract() { return { ok: true, cached: false, frameId: 'fr-cmd1', textSha256: 'sha-cmd1', text: '命令触发帧内容', structured: { intent: '工作' }, source: 'stub' } },
}
const stubRouter = {
  async run(tc) { if (tc === 'summarize') return { ok: true, text: '["x"]' }; if (tc === 'score-plan') return { ok: true, text: '{"score":70,"advice":[]}' }; return { ok: true, text: 'stub' } },
}

try {
  const cmdPng = join(WORK, 'cmd.png'); writeFileSync(cmdPng, Buffer.alloc(2048, 7))
  const smallPng = join(WORK, 'small.png'); writeFileSync(smallPng, Buffer.alloc(15, 1))

  // ① 命令帧不进轨迹 + ② 日报有「工具触发帧 N 条」行
  const p = createDailyPipeline({ dir: COACH_DIR, router: stubRouter, extractor: stubExtractor, now })
  const r1 = await p.run({ consentActive: true, goal: 'g', frames: [{ imagePath: cmdPng, window: '（命令触发）', process: '（命令触发）', source: 'command' }] })
  const trajPath = join(COACH_DIR, 'trajectory.jsonl')
  const trajRows = existsSync(trajPath) ? readFileSync(trajPath, 'utf8').trim().split('\n').filter(Boolean) : []
  check('EV-1 命令触发帧不进轨迹（toolFrames=1，trajectory 0 行）', r1.ok === true && r1.toolFrames === 1 && trajRows.length === 0, `toolFrames=${r1.toolFrames} traj=${trajRows.length}`)
  const report = existsSync(r1.reportPath) ? readFileSync(r1.reportPath, 'utf8') : ''
  check('EV-2 日报含「（本轮工具触发帧 1 条，未计入轨迹）」', report.includes('工具触发帧 1 条，未计入轨迹'), report.match(/工具触发帧[^\n]*/)?.[0] || '(无)')

  // ③ 空帧拦截：frameBytesGuard(15B)=false + 走 perception 路径被拒且审计
  const g = frameBytesGuard(smallPng)
  check('EV-3a 空帧守卫：15 字节 → ok=false（<1024）', g.ok === false && g.bytes === 15, JSON.stringify(g))
  await p.run({ consentActive: true, goal: 'g', frames: [{ imagePath: smallPng, window: '（自动捕获）', process: '（自动捕获）', source: 'perception' }] })
  // 取日志尾部若干行（用行尾而非字节偏移——coach.jsonl 含中文，字节≠字符）
  const tail = (() => { try { return readFileSync(COACH_LOG, 'utf8').split('\n').filter(Boolean).slice(-8).join('\n') } catch { return '' } })()
  const audited = /skipped-empty-frame/.test(tail) && /"bytes":15/.test(tail)
  const trajAfter = existsSync(trajPath) ? readFileSync(trajPath, 'utf8').trim().split('\n').filter(Boolean).length : 0
  check('EV-3b 空帧（perception <1024）不送模 + 审计 skipped-empty-frame', audited && trajAfter === 0, `audit=${audited} traj=${trajAfter}`)

  // ④ captureOne 失败留痕（源码断言：index.mjs 有 daily-capture-failed 审计）
  const idx = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'index.mjs'), 'utf8')
  check('EV-4 captureOne 重试耗尽留痕 daily-capture-failed（源码）', /kind:\s*'daily-capture-failed'/.test(idx), '')

  // ⑤ coach-trigger 回包校验（源码断言：coach 以 coach.jsonl 为准，不再把 perception 增量当已处理；ok:false 打印 code/message）
  const trig = readFileSync(join(PROJECT_ROOT, 'tools', 'coach-trigger.mjs'), 'utf8')
  const trigOk = /isCoach\s*\?/.test(trig) && /fileSize\(coachLog\)/.test(trig) && /ok === false/.test(trig) && /message:/.test(trig)
  check('EV-5 coach-trigger 以 coach.jsonl/回包为准 + ok:false 打印 code/message（源码）', trigOk, `isCoach=${/isCoach/.test(trig)} okFalse=${/ok === false/.test(trig)}`)

  // ⑥ 第二处 run-daily 已删（源码断言：只 1 处）
  const runDailyCount = (idx.match(/if \(sub === 'run-daily'\)/g) || []).length
  check('EV-6 死代码已删：run-daily 分支仅 1 处', runDailyCount === 1, `count=${runDailyCount}`)
} catch (e) {
  check('EV-0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 300))
}

const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s69-evidence: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(items.every((i) => i.ok) ? 0 : 1)
