// tools/accept-s69-ask.mjs —— S70·P0-2 重写：**走命令层**（activate + commands['coach'].run('ask ...')）
// 禁止直接调 confusion.ask({query}) 作假绿（S69 的教训：断言通过≠用户能用）。
// 单行复跑：node tools\accept-s69-ask.mjs
import { appendFileSync, existsSync, readFileSync, writeFileSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { activate } from '../packages/plugins/coach/index.mjs'
import { createConfusionCoach } from '../packages/plugins/coach/confusion.mjs'

const items = []
const check = (id, ok, detail = '') => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300) }); console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`) }
const COACH_DIR = join(PROJECT_ROOT, 'data', 'coach')
const INC = join(COACH_DIR, 'incremental.jsonl')
const STATE = join(COACH_DIR, 'confusion-state.json')
const COACH_LOG = join(PROJECT_ROOT, 'data', 'logs', 'coach.jsonl')
const NOW = Date.now()
const FRAME = 'fr-cafe701' // 必须全 hex（召回含 frameId 断言用 /fr-[0-9a-f]+/）
const hhmm = (ms) => { const d = new Date(ms); const p = (n) => String(n).padStart(2, '0'); return `${p(d.getHours())}:${p(d.getMinutes())}` }

// 种子：一条 2 分钟前的 canary 增量行（证明命令层 → 召回 → 读到 incremental）
const CANARY = JSON.stringify({ ts: new Date(NOW - 2 * 60e3).toISOString(), window: 'Word', process: 'winword.exe', frameId: FRAME, textSha256: 'sha-canary', text: '写论文草稿', structured: { intent: '工作' } })
const stripCanary = () => { try { if (!existsSync(INC)) return; const keep = readFileSync(INC, 'utf8').split('\n').filter((l) => l && !l.includes(FRAME)); writeFileSync(INC, keep.length ? keep.join('\n') + '\n' : '') } catch { /* noop */ } }
stripCanary()
try { appendFileSync(INC, CANARY + '\n') } catch { /* noop */ }
// 重置冷却/防抖状态（否则激活后首个手动 ask 可能被判防抖）
try { rmSync(STATE, { force: true }) } catch { /* noop */ }

let res = null
try {
  const commands = {}
  const mockCtx = {
    log: { info() {}, warn() {}, error() {} },
    ui: { registerCommand: (c) => { commands[c.name] = c }, registerCard() {}, notify() {} },
    net: null,
    core: { screen: { captureScreen: async () => ({ ok: false }) } },
    globalShortcut: null,
  }
  res = await activate(mockCtx)
  const cmd = commands['coach']
  if (!cmd) throw new Error('coach 命令未注册（activate 失败？code=' + (res && res.code) + '）')

  // ⑤ 先测空问题（此时 lastAskAt 未设，避免 debounce 污染）：不走召回；无 consent → 屏幕路径被同意闸拦（正确行为）
  const e = await cmd.run('ask')
  const eText = String((e && e.text) || '')
  const notRecall = !/记录到|最近 30 分钟/.test(eText)
  const idxSrc = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'index.mjs'), 'utf8')
  const screenPath = ['E_NO_CONSENT', 'E_NO_FRAME', 'E_ASK_FAILED', undefined].includes(e && e.code)
  check('ASK-5 「/coach ask」空问题 → 不走召回 + 走屏幕/同意闸（成功文本含"未指定问题，基于当前屏幕"）',
    !!e && notRecall && screenPath && idxSrc.includes('（未指定问题，基于当前屏幕）'),
    `code=${e && e.code} notRecall=${notRecall} text=${eText.slice(0, 30)}`)

  // ① 命令层传入 query → 召回（答案含 canary frameId + 顶部"范围 · 条数"头）
  // S74·1-B：范围头从旧文案「最近 30 分钟」改为统一的 `今天 HH:MM–HH:MM · N 条`（spec ⑥）。
  // 断言强度不变：canary 仍在 + 头部必须同时含范围与条数（比旧的正则更严：新增条数断言）。
  const a1 = await cmd.run('ask 我刚刚干了啥')
  const t1 = String((a1 && a1.text) || '')
  check('ASK-1 命令层 query 到达 → 召回答案（含 canary frameId + 顶部范围·条数头）',
    a1 && a1.ok === true && t1.includes(FRAME) && /（今天 \d{2}:\d{2}–\d{2}:\d{2} · \d+ 条）/.test(t1), `ok=${a1 && a1.ok} text=${t1.slice(0, 60)}`)

  // ② 手动连问第二次 → 防抖（不是 24h 冷却）
  const a2 = await cmd.run('ask 我刚刚干了啥')
  check('ASK-2 手动连问第二次 → 防抖 E_ASK_DEBOUNCE（非 24h 冷却）', a2 && a2.code === 'E_ASK_DEBOUNCE', `code=${a2 && a2.code}`)

  // ③ 审计 coach-ask.query 非空（证明命令层把问题带到了内部）
  const logTxt = (() => { try { return readFileSync(COACH_LOG, 'utf8') } catch { return '' } })()
  const askRows = logTxt.split('\n').filter((l) => l.includes('"kind":"coach-ask"')).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
  const hit = askRows.slice().reverse().find((r) => r.recall === true)
  check('ASK-3 审计 coach-ask.query 非空（命令层传到内部）', hit && typeof hit.query === 'string' && hit.query.includes('干了啥'), `query=${hit && hit.query}`)

  // ④ 答案时间戳在范围内 + 含 frameId
  const stamps = t1.match(/\b\d{2}:\d{2}\b/g) || []
  const inRange = stamps.filter((s) => s === hhmm(NOW - 2 * 60e3))
  check('ASK-4 答案时间戳在范围内且含 frameId', inRange.length >= 1 && /fr-[0-9a-f]+/.test(t1), `stamps=${stamps.join(',')} 期望含=${hhmm(NOW - 2 * 60e3)}`)

  // ③(自动) auto-dwell 仍受 24h 冷却（confusion 自动路径，无用户命令）：lastAskAt 刚被手动 ask 置为 now → 冷却中
  const stubE = { async extract() { return { ok: true, frameId: 'x', text: '', source: 'stub' } } }
  const stubR = { async run() { return { ok: true, text: '' } } }
  const autoCoach = createConfusionCoach({ dir: COACH_DIR, router: stubR, extractor: stubE, now: () => Date.now() })
  const auto = await autoCoach.ask({ imagePath: 'x.png', trigger: 'auto-dwell', consentActive: true })
  check('ASK-6 自动问询（auto-dwell）仍受 24h 冷却', auto && auto.cooledDown === true, `cooledDown=${auto && auto.cooledDown}`)
} catch (e) {
  check('ASK-0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  try { if (res && typeof res.deactivate === 'function') res.deactivate() } catch { /* noop */ }
  stripCanary() // 清掉 canary，不污染真实增量账
}

const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s69-ask: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(items.every((i) => i.ok) ? 0 : 1)
