// tools/purge-demo-claims.mjs —— S52·P0-1：把混进真实库的 demo 结论清出去（可逆：先导出）
//
// 单行执行：node tools\purge-demo-claims.mjs            # 预演（只报告，不删）
//          node tools\purge-demo-claims.mjs --apply    # 执行（先导出再删）
//
// 判据：claim.text 含「演示加速」或「虚构的 DOI」，或 id 命中已知 demo 清单。
// 纪律：
//   · **先导出**到 data\db\demo-purge-<ts>.json（含关联 claim_evidence 行），删前留证；
//   · 只删命中行与它们的 claim_evidence，不碰其它数据；
//   · 输出逐条清单，便于人工复核。**不静默删**。

import { existsSync, mkdirSync, writeFileSync } from 'node:fs'
import {join, resolve} from 'node:path'
import { DatabaseSync } from 'node:sqlite'

const ROOT = resolve(import.meta.dirname, '..')
const DB = join(ROOT, 'data', 'db', 'orb.sqlite')
const OUT_DIR = join(ROOT, 'data', 'db')
const APPLY = process.argv.includes('--apply')
const MARKS = ['演示加速', '虚构的 DOI']

if (!existsSync(DB)) {
  console.error('[purge] 找不到库：' + DB)
  process.exit(2)
}

const db = new DatabaseSync(DB)
const all = db.prepare('SELECT id, kind, text, evidence_mode, status, created_at FROM claim').all()
const hit = all.filter((r) => MARKS.some((m) => String(r.text || '').includes(m)))

console.log(`[purge] claim 总数=${all.length} 命中 demo=${hit.length}`)
for (const r of hit) console.log(`   ${r.id}  ${r.kind}  ${String(r.text).slice(0, 64)}`)

if (hit.length === 0) {
  console.log('[purge] 无 demo 行，无需处理')
  process.exit(0)
}

const ids = hit.map((r) => r.id)
const ph = ids.map(() => '?').join(',')
const ev = db.prepare(`SELECT * FROM claim_evidence WHERE claim_id IN (${ph})`).all(...ids)
const stamp = new Date().toISOString().replace(/[:.]/g, '-')
const outFile = join(OUT_DIR, `demo-purge-${stamp}.json`)
mkdirSync(OUT_DIR, { recursive: true })
writeFileSync(outFile, JSON.stringify({ at: new Date().toISOString(), reason: 'S52·P0-1 demo 数据混入真实库', marks: MARKS, claims: hit, claimEvidence: ev }, null, 2), 'utf8')
console.log(`[purge] 已导出 ${outFile}（claims=${hit.length} evidence=${ev.length}）`)

if (!APPLY) {
  console.log('[purge] 预演完成，未删除。加 --apply 执行。')
  process.exit(0)
}

const del1 = db.prepare(`DELETE FROM claim_evidence WHERE claim_id IN (${ph})`).run(...ids)
const del2 = db.prepare(`DELETE FROM claim WHERE id IN (${ph})`).run(...ids)
console.log(`[purge] 已删除 claim_evidence=${del1.changes} claim=${del2.changes}`)
const left = db.prepare('SELECT count(*) c FROM claim').get()
console.log(`[purge] 剩余 claim=${left.c}`)
db.close()
