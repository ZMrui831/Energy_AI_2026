#!/usr/bin/env node
// tools/demo-claim-2.mjs —— S14：现场产出 2 条已发布结论（脚本化验收）
//
// 设计纪律：
//   - 真实 CDP 驱动真实 electron（--no-sandbox --remote-debugging-port），与 record-demo 同启动参数；
//   - 结论操作一律走渲染层 IPC：window.__ro.send('ui',{type:'plugin:command',name:'claim',args})
//     （这正是面板按钮调用的同一条上行通道），不 import / 不直接调 packages/core 的内部函数；
//   - 前提数据（今日 ready 原图 + 学习片段）由公开学习主线 demo-script.mjs 产生；
//   - 结果回读读的是应用自己落盘的审计与导出物（data/logs/timeline.jsonl、data/exports/），不是内部状态；
//   - 失败分类（blocked:CLAIM_EVIDENCE_REQUIRED / E_NO_FRAME / exportError / envError），不吞错。
//
// 单行复跑：node tools/demo-claim-2.mjs
//   默认：起学习主线 → 起应用 → 两条 claim 发布+导出 → 关应用（残留进程 0）。

import { spawn, spawnSync } from 'node:child_process'
import { readFileSync, writeFileSync, existsSync, readdirSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { createHash } from 'node:crypto'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('demo-claim-2')

const PORT = Number(process.argv.includes('--port') ? process.argv[process.argv.indexOf('--port') + 1] : 9361)
const ELECTRON_EXE = ORB_ELECTRON
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const AUDIT = join(PROJECT_ROOT, 'data', 'logs', 'timeline.jsonl')
const EXPORTS = join(PROJECT_ROOT, 'data', 'exports')
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const sha256File = (p) => createHash('sha256').update(readFileSync(p)).digest('hex')

const results = []
const failures = []
function fail(code, claimId, reason) {
  failures.push({ code, claimId: claimId || null, reason })
  console.error('  [FAIL][' + code + '] ' + (claimId || '') + ' ' + reason)
}

// ---------- 审计回读（读应用自己写的 jsonl，不触碰内部函数） ----------
function auditCount() {
  return existsSync(AUDIT) ? readFileSync(AUDIT, 'utf8').split(/\r?\n/).filter(Boolean).length : 0
}
function readNewAudit(after) {
  if (!existsSync(AUDIT)) return []
  return readFileSync(AUDIT, 'utf8').split(/\r?\n/).filter(Boolean).slice(after)
    .map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
}
async function pollAudit(after, pred, timeoutMs = 15000) {
  const t0 = Date.now()
  while (Date.now() - t0 < timeoutMs) {
    const hit = readNewAudit(after).find(pred)
    if (hit) return hit
    await sleep(400)
  }
  return null
}

// ---------- 前提：跑学习主线，产生今日 ready 原图 + 学习片段 ----------
console.log('[setup] 运行学习主线 demo-script.mjs（fast/35s，产生今日原图与片段）...')
const ds = spawnSync(process.execPath,
  ['tools/demo-script.mjs', '--fast', '--dwell', '35', '--grant-consent', '--reset-cooldown'],
  { cwd: PROJECT_ROOT, encoding: 'utf8', timeout: 90000 })
if (ds.status !== 0) {
  console.error('[setup] 学习主线退出码=' + ds.status + '（环境/抓屏失败），后续无法挂证据。')
  console.error(String(ds.stdout || '').split('\n').slice(-15).join('\n'))
  process.exit(2)
}
// 找最新片段 id（path b 用）
function newestSegId() {
  const dir = join(PROJECT_ROOT, 'data', 'timeline')
  if (!existsSync(dir)) return null
  const files = readdirSync(dir).filter((f) => /^segments-.*\.jsonl$/.test(f)).sort()
  if (!files.length) return null
  const lines = readFileSync(join(dir, files[files.length - 1]), 'utf8').split(/\r?\n/).filter(Boolean)
  if (!lines.length) return null
  try { return JSON.parse(lines[lines.length - 1]).id } catch { return null }
}
const segId = newestSegId()
console.log('[setup] 最新学习片段 segId=' + segId)

// ---------- 起 electron（CDP） ----------
let child = null
try {
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN_MJS],
    { cwd: PROJECT_ROOT, stdio: 'ignore', detached: true, env })
  child.unref()
  console.log('[app] electron pid=' + child.pid + '，等待 CDP...')
} catch (e) {
  fail('envError', null, '无法启动 electron：' + String((e && e.message) || e))
  process.exit(2)
}

async function cdpTarget(timeoutMs = 30000) {
  const t0 = Date.now()
  while (Date.now() - t0 < timeoutMs) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await r.json()
      const t = list.find((x) => x.type === 'page' && x.webSocketDebuggerUrl && /floating\.html/i.test(x.url))
      if (t) return t
    } catch { /* 未起 */ }
    await sleep(500)
  }
  throw new Error('CDP 目标未找到（port ' + PORT + '）——可能无交互式桌面/窗口未创建')
}

let ws = null
let seq = 0
const pending = new Map()
const sendCdp = (method, params = {}) => new Promise((res, rej) => {
  const id = ++seq
  pending.set(id, (m) => (m.error ? rej(new Error(method + ': ' + m.error.message)) : res(m.result)))
  ws.send(JSON.stringify({ id, method, params }))
})
const evalJs = async (expr) => {
  const r = await sendCdp('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true })
  return r.result ? r.result.value : undefined
}

try {
  const target = await cdpTarget()
  ws = new WebSocket(target.webSocketDebuggerUrl)
  await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', () => rej(new Error('CDP 连接失败'))) })
  ws.addEventListener('message', (ev) => {
    const m = JSON.parse(ev.data)
    if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id) }
  })
  await sendCdp('Page.enable'); await sendCdp('Runtime.enable')

  // 等 __ro.send 与 __s5 就绪
  const t0 = Date.now()
  let ready = false
  while (Date.now() - t0 < 20000) {
    ready = await evalJs('!!(window.__ro && window.__ro.send && window.__s5)')
    if (ready) break
    await sleep(400)
  }
  if (!ready) throw new Error('渲染层 __ro/__s5 未就绪')
  console.log('[app] CDP 已连，命令通道就绪。')

  const auditBase = auditCount()

  // ---- path a：会话消息 → 建结论 → 挂今日原图 → 发布 → 导出 ----
  console.log('\n[path-a] 从会话消息建结论...')
  let off = auditCount()
  const textA = '今日文献检索经 Crossref/OpenAlex 双源核对后，虚构的 DOI 被行内标记拦截（会话结论）'
  await evalJs(`window.__ro.send('ui',{type:'plugin:command',name:'claim',args:${JSON.stringify('new session ' + textA)}})`)
  const createdA = await pollAudit(off, (r) => r.kind === 'claim-created' && r.source === 'session')
  if (!createdA) { fail('envError', null, 'path-a: 未捕获 claim-created(session)，IPC 无响应') }
  const idA = createdA && createdA.claimId
  console.log('[path-a] 草稿 ' + idA + '（evidenceMode=' + createdA.evidenceMode + '）')
  if (idA) {
    off = auditCount()
    await evalJs(`window.__ro.send('ui',{type:'plugin:command',name:'claim',args:${JSON.stringify('attach ' + idA + ' frame')}})`)
    const attA = await pollAudit(off, (r) => r.kind === 'claim-evidence-attached' && r.claimId === idA)
    if (!attA || attA.attached < 1) fail('E_NO_FRAME', idA, 'path-a: 挂今日原图失败（无 ready 原图）')
    else console.log('[path-a] 已挂证据 ' + attA.attached + ' 条')
    off = auditCount()
    await evalJs(`window.__ro.send('ui',{type:'plugin:command',name:'claim',args:${JSON.stringify('publish ' + idA)}})`)
    const pubA = await pollAudit(off, (r) => r.kind === 'claim-publish-attempt' && r.claimId === idA)
    if (!pubA) fail('envError', idA, 'path-a: 未捕获 publish-attempt')
    else if (!pubA.ok) fail('blocked:' + (pubA.code || 'CLAIM_EVIDENCE_REQUIRED'), idA, 'path-a: 发布被拒 code=' + pubA.code)
    else console.log('[path-a] 已发布')
    off = auditCount()
    await evalJs(`window.__ro.send('ui',{type:'plugin:command',name:'claim',args:${JSON.stringify('export ' + idA)}})`)
    const expA = await pollAudit(off, (r) => r.kind === 'claim-exported' && r.claimId === idA)
    if (!expA) fail('exportError', idA, 'path-a: 未捕获 claim-exported')
    else console.log('[path-a] 导出 ' + (expA.md || '').split('\\').pop() + ' (+docx)，证据 ' + expA.evidence + ' 条')
    results.push(await buildResult(idA, expA, attA))
  }

  // ---- path b：学习片段 → 建结论（自带片段原图证据）→ 发布 → 导出 ----
  console.log('\n[path-b] 从学习片段建结论...')
  if (!segId) {
    fail('envError', null, 'path-b: 无最新学习片段，无法 new seg')
  } else {
    off = auditCount()
    await evalJs(`window.__ro.send('ui',{type:'plugin:command',name:'claim',args:${JSON.stringify('new seg ' + segId)}})`)
    const createdB = await pollAudit(off, (r) => r.kind === 'claim-created' && r.source === 'seg')
    if (!createdB) fail('envError', null, 'path-b: 未捕获 claim-created(seg)')
    const idB = createdB && createdB.claimId
    console.log('[path-b] 草稿 ' + idB + '（evidenceMode=' + createdB.evidenceMode + '，自带片段证据 ' + createdB.evidenceCount + '）')
    if (idB) {
      off = auditCount()
      await evalJs(`window.__ro.send('ui',{type:'plugin:command',name:'claim',args:${JSON.stringify('publish ' + idB)}})`)
      const pubB = await pollAudit(off, (r) => r.kind === 'claim-publish-attempt' && r.claimId === idB)
      if (!pubB) fail('envError', idB, 'path-b: 未捕获 publish-attempt')
      else if (!pubB.ok) fail('blocked:' + (pubB.code || 'CLAIM_EVIDENCE_REQUIRED'), idB, 'path-b: 发布被拒 code=' + pubB.code)
      else console.log('[path-b] 已发布')
      off = auditCount()
      await evalJs(`window.__ro.send('ui',{type:'plugin:command',name:'claim',args:${JSON.stringify('export ' + idB)}})`)
      const expB = await pollAudit(off, (r) => r.kind === 'claim-exported' && r.claimId === idB)
      if (!expB) fail('exportError', idB, 'path-b: 未捕获 claim-exported')
      else console.log('[path-b] 导出 ' + (expB.md || '').split('\\').pop() + ' (+docx)，证据 ' + expB.evidence + ' 条')
      results.push(await buildResult(idB, expB, null))
    }
  }
} catch (e) {
  fail('envError', null, String((e && e.message) || e))
} finally {
  try { if (ws) ws.close() } catch { /* ignore */ }
}

// ---------- 关应用 ----------
try {
  if (child) { try { spawnSync('taskkill', ['/pid', String(child.pid), '/T', '/F'], { stdio: 'ignore' }) } catch { /* ignore */ } }
} catch { /* ignore */ }
await sleep(800)
// 残留判定：只数"本次脚本起的 research-orb 主进程"，按命令行精确匹配；
// 同二进制路径下还有 DSH 宿主自己的 helper（父进程是 DeepSeek Harness），绝不能误杀宿主。
const residual = String(countOrbAll())
console.log('[cleanup] 残留 research-orb electron 进程=' + (residual || '0'))

// ---------- 落 JSON ----------
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
const out = join(PROJECT_ROOT, 'data', 'logs', 's14-demo-claims.json')
writeFileSync(out, JSON.stringify({
  ranAt: new Date().toISOString(),
  ok: failures.length === 0 && results.length === 2,
  claims: results,
  failures,
  residualElectron: Number(residual || 0),
}, null, 2), 'utf8')
console.log('\n[output] ' + out)
console.log('[summary] claims=' + results.length + '/2，failures=' + failures.length)
process.exit(failures.length === 0 && results.length === 2 ? 0 : 1)

async function buildResult(claimId, expRec, attRec) {
  let md = null, mdSha256 = null, docx = null, docxSha256 = null
  const evidenceIds = []
  if (expRec) {
    md = expRec.md || null
    docx = expRec.docx || null
    try { if (md && existsSync(md)) mdSha256 = sha256File(md) } catch { /* ignore */ }
    try { if (docx && existsSync(docx)) docxSha256 = sha256File(docx) } catch { /* ignore */ }
    // 从导出 md 的证据清单表回读 evidence_id（读应用自己的产物，不查内部库）
    try {
      if (md && existsSync(md)) {
        const txt = readFileSync(md, 'utf8')
        const re = /\|\s*\d+\s*\|\s*([A-Za-z0-9_-]+)\s*\|\s*raw_frame\s*\|/g
        let m; while ((m = re.exec(txt))) evidenceIds.push(m[1])
      }
    } catch { /* ignore */ }
  }
  return {
    claimId,
    evidenceIds,
    publishedAt: new Date().toISOString(),
    exportPath: md,
    mdSha256,
    docxPath: docx,
    docxSha256,
  }
}
