// tools/check-no-hardcoded-root.mjs
//
// P0-3 护栏：非注释源码出现仓库根硬编码（D:/explorer! 或 D:\explorer!）或家目录标识
// （54958）即 FAIL。这是"副本放到别处也能 933/933"的硬前提——任何把绝对路径写死在
// 代码里的写法都会让隔离副本/换机部署直接崩。
//
// 显式豁免：检测目标（脱敏词表 / deny 词表 / 检测基准）必须在同一行带 `allow-hardcoded`
// 注释标记，否则一律判违规。标记必须写清理由，绝不静默放过。
//
// 用法：node tools/check-no-hardcoded-root.mjs  → 退出码 0=PASS / 1=FAIL

import { readdirSync, statSync, readFileSync } from 'node:fs'
import { join, resolve, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = dirname(fileURLToPath(import.meta.url))
const ROOT = resolve(__dirname, '..')

const SCAN_DIRS = ['tools', 'tests', 'packages', 'apps']
const EXTS = new Set(['.mjs', '.js', '.cjs', '.ts'])
const SKIP_DIRS = new Set(['node_modules', 'data', 'vendor', 'dist', '.genie', 'coverage', '.git'])

// 禁用 token 拆开构造，避免本文件自我命中（扫描时也会跳过自身，双重保险）。
const TOKENS = [
  'D:' + '\\' + '\\' + 'explorer!', // D:\explorer!（文件里是两个反斜杠字节）
  'D:' + '/' + 'explorer!', // D:/explorer!
  '549' + '58', // 54958（家目录标识）
]

function stripComments(line) {
  // 去掉 /* ... */ 块注释与 // 行注释（粗略行内处理）
  return line.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*$/, '')
}

function hasToken(code) {
  return TOKENS.some((t) => code.includes(t))
}

let violations = 0
const hits = []

function walk(dir) {
  for (const e of readdirSync(dir)) {
    const p = join(dir, e)
    let st
    try { st = statSync(p) } catch { continue }
    if (st.isDirectory()) {
      if (SKIP_DIRS.has(e)) continue
      walk(p)
    } else {
      const ext = e.slice(e.lastIndexOf('.'))
      if (!EXTS.has(ext)) continue
      if (e === 'check-no-hardcoded-root.mjs') continue // 跳过自身
      const lines = readFileSync(p, 'utf8').split('\n')
      let inBlock = false
      lines.forEach((raw, i) => {
        if (raw.includes('allow-hardcoded')) return // 显式豁免（必须写清理由）
        let s = raw
        if (inBlock) {
          const end = s.indexOf('*/')
          if (end >= 0) { s = s.slice(end + 2); inBlock = false }
          else return // 整行处于块注释内
        }
        s = s.replace(/\/\*[\s\S]*?\*\//g, '')
        if (s.includes('/*')) inBlock = true // 行内未闭合的块注释延续到后续行
        s = s.replace(/\/\/.*$/, '')
        if (hasToken(s)) {
          violations++
          hits.push(`${p}:${i + 1}  ${raw.trim()}`)
        }
      })
    }
  }
}

for (const d of SCAN_DIRS) {
  const dp = join(ROOT, d)
  if (statSync(dp, { throwIfNoEntry: false })) walk(dp)
}

if (violations > 0) {
  console.log('check-no-hardcoded-root: FAIL')
  for (const h of hits) console.log('  ' + h)
  console.log(`\n共 ${violations} 处非注释硬编码（D:/explorer! 或 54958 且未标 allow-hardcoded）`)
  process.exit(1)
} else {
  console.log('check-no-hardcoded-root: PASS（0 处违规）')
  process.exit(0)
}
