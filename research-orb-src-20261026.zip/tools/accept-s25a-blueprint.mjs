// tools/accept-s25a-blueprint.mjs —— S25·1A 目标与蓝图验收。
// 单行复跑：node tools\accept-s25a-blueprint.mjs
// 证据：data\logs\s25a-blueprint-accept.json。纪律：目录注入 data/tmp（隔离）；不动 data/config.json。
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync, unlinkSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { setGoal, readGoal, readBlueprint, writeBlueprint, regenBlueprint } from '../packages/plugins/coach/engine.mjs'
import { readCoachSystemContext, estimateTokens, COACH_DIGEST_MAX_TOKENS } from '../packages/core/src/coach-context.mjs'
import { composeSystemPrompt } from '../packages/core/src/profile-context.mjs'
import { activate as coachActivate } from '../packages/plugins/coach/index.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 240), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's25a-blueprint')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(join(WORK, 'data', 'coach'), { recursive: true })
const C = join(WORK, 'data', 'coach')

try {
  // ① goal
  const rec = setGoal('两周内完成微电网综述初稿并挂齐证据', { dir: C })
  check('B1 /coach goal set 写 goal.json 并可读回', readGoal(C).goal === rec.goal && !!rec.updatedAt)
  let threw = false
  try { setGoal('  ', { dir: C }) } catch (e) { threw = e.code === 'E_EMPTY_GOAL' }
  check('B2 空目标 → E_EMPTY_GOAL', threw)

  // ② blueprint：edit 写入 + 外部编辑即时生效
  writeBlueprint('1. 定范围\n2. 找文献（✓双源优先）', { dir: C, source: 'command' })
  check('B3 blueprint edit 写 blueprint.md', /✓双源/.test(readBlueprint(C)))
  writeFileSync(join(C, 'blueprint.md'), '外部编辑后的蓝图 v2\n3. 立结论挂证据', 'utf8')
  check('B4 外部可编辑：直接改文件后 show 即时生效', readBlueprint(C).includes('外部编辑后的蓝图 v2'))

  // ③ regen：LLM 成功 / 失败回落模板
  const okRouter = { run: async () => ({ ok: true, text: '1. 拆子问题\n2. /find 检索挂证据\n3. 立结论\n4. /chart 出图', providerId: 'deepseek-api', model: 'deepseek-chat', fallback: false }) }
  const r1 = await regenBlueprint({ router: okRouter, dir: C })
  check('B5 blueprint regen（LLM 成功）→ source=llm 且写盘', r1.source === 'llm' && /\/find 检索/.test(readBlueprint(C)))
  const badRouter = { run: async () => ({ ok: false, tier: 'flagship', error: { code: 'E_HTTP_500', message: 'down' } }) }
  const r2 = await regenBlueprint({ router: badRouter, dir: C })
  check('B6 regen LLM 失败 → 回落模板（source=template，诚实标注）', r2.source === 'template' && r2.fallback === true && /研究蓝图（模板/.test(readBlueprint(C)))

  // ④ digest 注入：画像+目标+蓝图三段、≤700 token
  writeFileSync(join(WORK, 'data', 'profile.json'), JSON.stringify({ personalization: true }), 'utf8')
  writeFileSync(join(WORK, 'data', 'profile-digest.txt'), '研二学生，方向智能电网综合能源系统', 'utf8')
  const sys = readCoachSystemContext({ root: WORK })
  check('B7 digest 含 画像/目标/蓝图 三段', /【用户画像】/.test(sys) && /【用户目标】/.test(sys) && /【研究蓝图（摘要）】/.test(sys))
  check(`B8 digest 总量 ≤${COACH_DIGEST_MAX_TOKENS} token（实测 ${estimateTokens(sys)}）`, estimateTokens(sys) <= COACH_DIGEST_MAX_TOKENS)
  check('B9 digest 含 goal 文本（画像增 goal）', sys.includes('两周内完成微电网综述初稿并挂齐证据'))

  // ⑤ 宿主拼装：composeSystemPrompt(DEFAULT, coachSys)
  const composed = composeSystemPrompt('DEFAULT_PROMPT', sys)
  check('B10 宿主拼装：system = 默认 + \\n + 教练摘要', composed.startsWith('DEFAULT_PROMPT\n') && composed.includes('【研究蓝图（摘要）】'))

  // ⑥ 降级路径：未开个性化 → 无画像段但保留目标/蓝图；空库 → ''
  writeFileSync(join(WORK, 'data', 'profile.json'), JSON.stringify({ personalization: false }), 'utf8')
  const sys2 = readCoachSystemContext({ root: WORK })
  check('B11 未开个性化：无画像段，仍注入目标/蓝图', !/研二学生/.test(sys2) && /【用户目标】/.test(sys2))
  const sys3 = readCoachSystemContext({ root: join(WORK, 'empty-root') })
  check('B12 空库 → 不注入（返回空串）', sys3 === '')

  // ⑦ 真实命令注册与执行（fake ctx，离线；goal set 走真实 data\coach —— 先备份后还原，D21/D22 纪律）
  const cmds = {}
  // activate 会真起调度器（写 data/coach/scheduler.json）——D21/D22：记录事前状态，finally 复位
  var SCHED = join(PROJECT_ROOT, 'data', 'coach', 'scheduler.json')
  var schedBefore = existsSync(SCHED) ? readFileSync(SCHED, 'utf8') : null
  await coachActivate({ net: { available: false }, ui: { registerCommand: (s) => { cmds[s.name] = s.run }, registerCard: () => {} }, log: console })
  var realGoal = join(PROJECT_ROOT, 'data', 'coach', 'goal.json')
  var goalBefore = existsSync(realGoal) ? readFileSync(realGoal, 'utf8') : null
  const g = await cmds.coach('goal set 两周内完成微电网综述初稿并挂齐证据')
  const gShow = await cmds.coach('goal show')
  check('B13 /coach goal set+show（真实命令，真实 data\\coach）回显目标', g.ok === true && gShow.ok === true && gShow.text.includes('两周内完成微电网综述初稿'), gShow.text.slice(0, 60))
  const b = await cmds.coach('blueprint show')
  check('B14 /coach blueprint show（真实命令）回显蓝图', b.ok === true && String(b.text).length > 10)

  // ⑧ 审计
  const auditPath = join(PROJECT_ROOT, 'data', 'logs', 'coach.jsonl')
  const auditText = existsSync(auditPath) ? readFileSync(auditPath, 'utf8') : ''
  check('B15 coach.jsonl 审计留痕（goal-set/blueprint-write）', auditText.includes('goal-set') && auditText.includes('blueprint-write'))
} catch (e) {
  check('B0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 240))
} finally {
  // 还原真实 data\coach\goal.json（D21/D22：动过共享状态必须复位）
  try {
    if (goalBefore === null) {
      if (existsSync(realGoal)) rmSync(realGoal, { force: true })
    } else {
      writeFileSync(realGoal, goalBefore, 'utf8')
    }
  } catch { /* 尽力 */ }
  try { if (schedBefore === null) { if (existsSync(SCHED)) unlinkSync(SCHED) } else { writeFileSync(SCHED, schedBefore, 'utf8') } } catch { /* 尽力 */ }
  rmSync(WORK, { recursive: true, force: true })
}

const pass = items.filter((i) => i.ok).length
const fail = items.length - pass
const out = { tool: 'accept-s25a-blueprint', at: new Date().toISOString(), total: items.length, pass, fail, items }
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's25a-blueprint-accept.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # accept-s25a-blueprint: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 证据 -> data/logs/s25a-blueprint-accept.json`)
process.exit(fail === 0 ? 0 : 1)
