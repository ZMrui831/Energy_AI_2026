@echo off
rem ============================================================
rem  research-orb desktop entry (single .bat: click = start,
rem  click again = stop). Pure ASCII: cmd codepage corruption on
rem  non-ASCII batch content is a known trap, so all logic lives
rem  in launcher.ps1 (UTF-8, testable); this file is a thin wrapper.
rem  Safety: NEVER kill by image name; target selection is ONLY
rem  "command line contains: research-orb".
rem ============================================================
set "ELECTRON_RUN_AS_NODE="
powershell -NoProfile -ExecutionPolicy Bypass -File "D:\explorer!\research-orb\tools\launcher.ps1"
echo.
pause
exit /b 0
