// tools/accept-s39-redteam.mjs —— S39·F2 红队面板验收（≥6 项）。
// 单行复跑：node tools\accept-s39-redteam.mjs
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync, mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'

process.env.ORB_LOG_DIR = join(tmpdir(), 's39-rt-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's39-rt-data-' + Date.now())
const { dataPath, PROJECT_ROOT } = await import('../packages/core/src/safefs.mjs')
const { parseRedteamOutput, runRedteamPanel, renderRedteamPanel } = await import('../packages/plugins/coach/redteam-panel.mjs')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

try {
  // R-1 一键复跑（真实调 redteam-demo.mjs）：5 行攻击结果
  const r = runRedteamPanel()
  check('R-1 一键复跑真实脚本（5 行攻击）', r.rows.length >= 5 && r.exit === 0,
    `rows=${r.rows.length} exit=${r.exit}`, {})

  // R-2 结果 5/5 防住
  check('R-2 结果 5/5 防住', r.defended === 5 && r.breached === 0 && r.allPass === true,
    `defended=${r.defended} breached=${r.breached}`, {})

  // R-3 面板表：攻击→结果→防线 三列
  const md = renderRedteamPanel(r)
  const tableOk = md.includes('| 攻击 | 结果 | 防线 |') && (md.match(/\| A\d[^\n]*\|/g) || []).length >= 5
  check('R-3 面板三列表', tableOk, `tableRows=${(md.match(/\| A\d[^\n]*\|/g) || []).length}`, {})

  // R-4 最近运行时间 + 5/5 展示
  check('R-4 最近运行时间+5/5', md.includes('最近复跑：') && /\d{4}-\d{2}-\d{2}T/.test(md) && md.includes('5/5'),
    `ranAt+5/5 在`, {})

  // R-5 失败显示真实失败项（解析器对"失守"输出如实呈现）
  const fake = parseRedteamOutput('[防住] A1 x\n[失守] A2 y\n[防住] A3 z')
  check('R-5 失败项如实呈现', fake.breached === 1 && fake.rows[1].result === '失守' && fake.allPass === false,
    `breached=${fake.breached}`, {})

  // R-6 一键复跑 = 同一脚本（面板记录复跑命令；审计留行）
  const auditPath = join(process.env.ORB_LOG_DIR, 'coach.jsonl')
  let auditHit = false
  try {
    if (existsSync(auditPath)) auditHit = readFileSync(auditPath, 'utf8').includes('redteam-run')
  } catch { /* 尽力 */ }
  check('R-6 同一脚本复跑+审计行', md.includes('node tools\\redteam-demo.mjs') && auditHit,
    `audit=${auditHit}`, {})

  // R-7 SHOT-REDTEAM 静态断言在（供他人拍）
  check('R-7 SHOT-REDTEAM 存在', existsSync(join(PROJECT_ROOT, 'docs', 'SHOT-REDTEAM.md')),
    `docs/SHOT-REDTEAM.md`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's39-redteam-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s39-redteam: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
