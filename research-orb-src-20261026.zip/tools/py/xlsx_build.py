# tools/py/xlsx_build.py —— doc.xlsx 的执行体（由 packages/core/src/tools/impl/doc.mjs 调用）
#
# 用法：python -X utf8 tools/py/xlsx_build.py <spec.json>
#   spec.json = {"path":"...","sheet":"Sheet1","header":["列1","列2"],"rows":[["a","b"]]}
#
# 【P-R7】本机 .venv 已装 openpyxl==3.1.5（tools/setup-venv.mjs 一键可重建），
# 所以这里**不降级**——产出的是真 .xlsx，不是改名的 CSV。若库缺失，如实报错
# （E_NO_OPENPYXL）并由上层把降级路径告诉用户，绝不偷偷生成假 xlsx。

import json
import os
import sys
import hashlib

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, Alignment
    from openpyxl.utils import get_column_letter
except Exception as exc:
    sys.stdout.write(json.dumps({"ok": False, "code": "E_NO_OPENPYXL", "message": "openpyxl 不可用：" + str(exc)}, ensure_ascii=False) + "\n")
    sys.exit(2)


def emit(obj):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def fail(code, message):
    emit({"ok": False, "code": code, "message": message})
    sys.exit(1)


def main():
    if len(sys.argv) < 2:
        fail("E_ARGS", "缺少 spec.json 路径")
    spec_path = sys.argv[1]
    if not os.path.exists(spec_path):
        fail("E_NO_SPEC", "spec 文件不存在：" + spec_path)
    with open(spec_path, "r", encoding="utf-8") as f:
        spec = json.load(f)

    out_path = spec.get("path")
    if not out_path:
        fail("E_NO_PATH", "spec 缺少 path")

    wb = Workbook()
    ws = wb.active
    ws.title = str(spec.get("sheet") or "Sheet1")[:31]

    header = spec.get("header") or []
    rows = spec.get("rows") or []

    start_row = 1
    if header:
        for c, name in enumerate(header, start=1):
            cell = ws.cell(row=1, column=c, value=name)
            cell.font = Font(bold=True)
            cell.alignment = Alignment(vertical="center")
        start_row = 2

    for r, row in enumerate(rows, start=start_row):
        if not isinstance(row, (list, tuple)):
            row = [row]
        for c, val in enumerate(row, start=1):
            ws.cell(row=r, column=c, value=val)

    # 列宽自适应（按最长单元格估算，中文按 2 个字符宽）
    widths = {}
    def consider(col_idx, text):
        s = str(text) if text is not None else ""
        w = sum(2 if ord(ch) > 127 else 1 for ch in s)
        widths[col_idx] = max(widths.get(col_idx, 8), min(60, w + 2))

    if header:
        for c, name in enumerate(header, start=1):
            consider(c, name)
    for row in rows:
        for c, val in enumerate(row if isinstance(row, (list, tuple)) else [row], start=1):
            consider(c, val)
    for col_idx, w in widths.items():
        ws.column_dimensions[get_column_letter(col_idx)].width = w

    out_dir = os.path.dirname(out_path)
    if out_dir and not os.path.isdir(out_dir):
        os.makedirs(out_dir, exist_ok=True)
    wb.save(out_path)

    with open(out_path, "rb") as f:
        data = f.read()

    emit({
        "ok": True,
        "path": out_path,
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "sheet": ws.title,
        "rows": len(rows) + (1 if header else 0),
        "degraded": False,
    })


if __name__ == "__main__":
    main()
