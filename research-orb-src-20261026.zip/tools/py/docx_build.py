# tools/py/docx_build.py —— doc.docx 的执行体（由 packages/core/src/tools/impl/doc.mjs 调用）
#
# 用法：python -X utf8 tools/py/docx_build.py <spec.json>
#   spec.json = {"path": "...", "title": "...", "paragraphs": ["..."],
#                "sections":[{"heading":"","paragraphs":[""],"bullets":[""]}]}
#
# 字体纪律（主管指定）：**正文宋体（SimSun 系列里的"宋体"）、标题楷体（KaiTi）**。
# python-docx 只设 run.font.name 对中文不生效 —— 中文字形取的是 w:eastAsia，
# 必须单独设 rFonts 的 eastAsia 属性，否则中文会退回默认字体、与指定字体不符。
#
# 输出：结果 JSON 打在**最后一行**（{"ok":true,"path":...,"bytes":N,"sha256":"..."}）；
#       Node 侧只解析最后一行，前面的中文提示不会污染解析。

import json
import os
import sys
import hashlib

BODY_FONT = "宋体"
HEAD_FONT = "楷体"

try:
    from docx import Document
    from docx.shared import Pt
    from docx.oxml.ns import qn
    from docx.enum.text import WD_ALIGN_PARAGRAPH
except Exception as exc:  # 缺库就明说，绝不退化成"写个假 docx"
    sys.stdout.write(json.dumps({"ok": False, "code": "E_NO_DOCX", "message": "python-docx 不可用：" + str(exc)}, ensure_ascii=False) + "\n")
    sys.exit(2)


def emit(obj):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def fail(code, message):
    emit({"ok": False, "code": code, "message": message})
    sys.exit(1)


def set_run_font(run, name, size_pt=None, bold=False):
    """同时设 ascii/hAnsi/eastAsia —— 中文生效的关键在 eastAsia。"""
    run.font.name = name
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.get_or_add_rFonts()
    rfonts.set(qn("w:ascii"), name)
    rfonts.set(qn("w:hAnsi"), name)
    rfonts.set(qn("w:eastAsia"), name)
    if size_pt is not None:
        run.font.size = Pt(size_pt)
    run.bold = bool(bold)


def add_body(doc, text, size=12):
    p = doc.add_paragraph()
    set_run_font(p.add_run(str(text)), BODY_FONT, size)
    return p


def main():
    if len(sys.argv) < 2:
        fail("E_ARGS", "缺少 spec.json 路径")

    spec_path = sys.argv[1]
    if not os.path.exists(spec_path):
        fail("E_NO_SPEC", "spec 文件不存在：" + spec_path)

    with open(spec_path, "r", encoding="utf-8") as f:
        spec = json.load(f)

    out_path = spec.get("path")
    if not out_path:
        fail("E_NO_PATH", "spec 缺少 path")

    doc = Document()

    # 默认样式：正文宋体小四（12pt）
    style = doc.styles["Normal"]
    style.font.name = BODY_FONT
    style.font.size = Pt(12)
    if style.element.rPr is not None and style.element.rPr.rFonts is not None:
        style.element.rPr.rFonts.set(qn("w:eastAsia"), BODY_FONT)

    title = str(spec.get("title") or "未命名文档")
    tp = doc.add_paragraph()
    tp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_run_font(tp.add_run(title), HEAD_FONT, 20, bold=True)

    top_paragraphs = spec.get("paragraphs") or []
    for para in top_paragraphs:
        add_body(doc, para)

    sections = spec.get("sections") or []
    if not sections and not top_paragraphs:
        # 只有标题的文档也允许，但补一句实话，避免交出一个"看起来像文档的空白文件"
        add_body(doc, "（正文待补充）")

    for sec in sections:
        heading = sec.get("heading")
        if heading:
            hp = doc.add_paragraph()
            set_run_font(hp.add_run(str(heading)), HEAD_FONT, 15, bold=True)
        for para in sec.get("paragraphs") or []:
            add_body(doc, para)
        for item in sec.get("bullets") or []:
            bp = doc.add_paragraph(style="List Bullet")
            set_run_font(bp.add_run(str(item)), BODY_FONT, 12)

    out_dir = os.path.dirname(out_path)
    if out_dir and not os.path.isdir(out_dir):
        os.makedirs(out_dir, exist_ok=True)

    doc.save(out_path)

    with open(out_path, "rb") as f:
        data = f.read()

    emit({
        "ok": True,
        "path": out_path,
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "fonts": {"body": BODY_FONT, "heading": HEAD_FONT},
        "sections": len(sections),
    })


if __name__ == "__main__":
    main()
