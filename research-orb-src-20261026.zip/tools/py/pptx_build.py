# tools/py/pptx_build.py —— doc.pptx 的执行体（由 packages/core/src/tools/impl/doc.mjs 调用）
#
# 用法：python -X utf8 tools/py/pptx_build.py <spec.json>
#   spec.json = {"path":"...","title":"...","subtitle":"...",
#                "slides":[{"title":"...","bullets":["..."],"notes":"..."}]}
#
# 【P-R7】本机 .venv 已装 python-pptx==1.0.2（tools/setup-venv.mjs 一键可重建），
# 产出真 .pptx。库缺失时如实报错（E_NO_PPTX），不偷偷生成"改名的 HTML"。

import json
import os
import sys
import hashlib

try:
    from pptx import Presentation
    from pptx.util import Pt
except Exception as exc:
    sys.stdout.write(json.dumps({"ok": False, "code": "E_NO_PPTX", "message": "python-pptx 不可用：" + str(exc)}, ensure_ascii=False) + "\n")
    sys.exit(2)


def emit(obj):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def fail(code, message):
    emit({"ok": False, "code": code, "message": message})
    sys.exit(1)


def main():
    if len(sys.argv) < 2:
        fail("E_ARGS", "缺少 spec.json 路径")
    spec_path = sys.argv[1]
    if not os.path.exists(spec_path):
        fail("E_NO_SPEC", "spec 文件不存在：" + spec_path)
    with open(spec_path, "r", encoding="utf-8") as f:
        spec = json.load(f)

    out_path = spec.get("path")
    if not out_path:
        fail("E_NO_PATH", "spec 缺少 path")

    prs = Presentation()
    # 版式：0 = 标题页，1 = 标题+内容，5 = 仅标题，6 = 空白
    title_layout = prs.slide_layouts[0]
    bullet_layout = prs.slide_layouts[1]
    blank_layout = prs.slide_layouts[6]

    title_slide = prs.slides.add_slide(title_layout)
    title_slide.shapes.title.text = str(spec.get("title") or "未命名演示文稿")
    subtitle = str(spec.get("subtitle") or "")
    if subtitle and len(title_slide.placeholders) > 1:
        title_slide.placeholders[1].text = subtitle

    slides = spec.get("slides") or []
    if not slides:
        s = prs.slides.add_slide(blank_layout)
        s.shapes.add_textbox(Pt(72), Pt(240), Pt(800), Pt(80)).text_frame.text = "（正文待补充）"

    for item in slides:
        slide = prs.slides.add_slide(bullet_layout)
        slide.shapes.title.text = str(item.get("title") or "")
        body = slide.placeholders[1]
        tf = body.text_frame
        tf.word_wrap = True
        bullets = item.get("bullets") or []
        if not bullets:
            bullets = [str(item.get("text") or "")]
        for i, b in enumerate(bullets):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.text = str(b)
            p.level = 0
        notes = item.get("notes")
        if notes:
            slide.notes_slide.notes_text_frame.text = str(notes)

    out_dir = os.path.dirname(out_path)
    if out_dir and not os.path.isdir(out_dir):
        os.makedirs(out_dir, exist_ok=True)
    prs.save(out_path)

    with open(out_path, "rb") as f:
        data = f.read()

    emit({
        "ok": True,
        "path": out_path,
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "slides": len(prs.slides._sldIdLst),
        "degraded": False,
    })


if __name__ == "__main__":
    main()
