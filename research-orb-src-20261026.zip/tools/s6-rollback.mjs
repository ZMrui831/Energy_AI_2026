// tools/s6-rollback.mjs —— S6 迁移回滚（运维路径；CONTRACT §7 沙箱内已验证）。
// 用法：node tools/s6-rollback.mjs --db <path> [--yes]
// 行为：事务内 drop 本片 4 只触发器 + 3 张表 + 迁移账本登记；幂等（不存在即跳过）。
// 警告：会丢弃全部 claim/claim_evidence/summary_evidence 数据——生产使用前先备份。

import { createStore } from '../packages/core/src/db.mjs'
import { rollbackS6 } from '../packages/core/src/lifecycle/publish.mjs'

const argv = process.argv.slice(2)
const arg = (k, d = null) => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : d }
const dbPath = arg('--db')
const yes = argv.includes('--yes')
if (!dbPath) { console.error('用法: node tools/s6-rollback.mjs --db <path> [--yes]'); process.exit(2) }
if (!yes) {
  console.error('警告：将丢弃 claim/claim_evidence/summary_evidence 全部数据。确认加 --yes（生产前先备份）。')
  process.exit(3)
}

const store = await createStore({ driver: 'sqlite', dbPath, dataDir: dbPath.replace(/[^/\\]*$/, '') })
const r = rollbackS6(store)
store.close()
console.log(JSON.stringify(r))
process.exit(r.ok ? 0 : 1)
