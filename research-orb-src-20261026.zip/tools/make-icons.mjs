// tools/make-icons.mjs
//
// S11 · 角色造型资产：程序化生成 球（收起态）/ 球（运行·角标态）/ 托盘 三类图标。
//
// 纪律（不下载任何图标包/二进制/转换器）：
//   · 图形全部用内联 SVG + 零依赖 PNG 光栅（tools/lib/orb-raster.mjs）。
//   · 三套候选各出一组，便于对比选型；docs/THEMES.md 记录最终选择与理由。
//
// S11 变更：主色切到青绿（与 data/themes/teal.theme.json 的 ballFrom/ballTo/face 对齐）；
//          新增「四态表情」资产（idle/thinking/need-help/error）；新增候选/表情 montage。
//
// 注意：TEAL_PALETTE / FACE_COLOR 与 data/themes/teal.theme.json 的 ballFrom/ballTo/face
//       保持一致——换主题时同步改这两处（或后续改为运行时读取主题）。

import { writeFileSync, existsSync, mkdirSync, copyFileSync } from 'node:fs'
import { join } from 'node:path'

import {
  encodePng, rasterBallRgba, downscale, FACE_SVGS, faceSvg, drawFace,
  compositeExpression, makeTray, makeBallPng, hexToRgb,
} from './lib/orb-raster.mjs'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const OUT_DIR = join(PROJECT_ROOT, 'apps', 'desktop', 'assets', 'icons')
const ASSETS_DIR = join(PROJECT_ROOT, 'apps', 'desktop', 'assets')

// 青绿品牌色（镜像 teal.theme.json：ballFrom/ballTo/face）
const TEAL_PALETTE = { from: '#5eead4', to: '#0d9488' }
const FACE_COLOR = '#eafffb'

// ---------------------------------------------------------------------------
const CANDIDATES = {
  A: { label: '轨道球（现行视觉语言延续，辨识度已验证）', motif: 'orbit' },
  B: { label: '同心圆环（极简、低视觉噪音）', motif: 'rings' },
  C: { label: '菱形宝石（高辨识度、边缘锐利）', motif: 'gem' },
}
const FACE_MOODS = ['idle', 'thinking', 'need-help', 'error']

function montage(imgs, gap = 12) {
  const h = Math.max(...imgs.map((i) => i.height))
  const w = imgs.reduce((s, i) => s + i.width, 0) + gap * (imgs.length - 1)
  const out = new Uint8Array(w * h * 4)
  let ox = 0
  for (const im of imgs) {
    for (let y = 0; y < im.height; y += 1) {
      for (let x = 0; x < im.width; x += 1) {
        const si = (y * im.width + x) * 4
        if (im.data[si + 3] === 0) continue
        const di = (y * w + (ox + x)) * 4
        out[di] = im.data[si]
        out[di + 1] = im.data[si + 1]
        out[di + 2] = im.data[si + 2]
        out[di + 3] = im.data[si + 3]
      }
    }
    ox += im.width + gap
  }
  return { data: out, width: w, height: h }
}

function main() {
  if (!existsSync(OUT_DIR)) mkdirSync(OUT_DIR, { recursive: true })
  const made = []

  // ---- 1. 三套候选（A/B/C）球/托盘/运行态，全部青绿 ----
  for (const [key, cand] of Object.entries(CANDIDATES)) {
    const jobs = [
      [`ball-${key}.svg`, ballSvg(TEAL_PALETTE.from, TEAL_PALETTE.to, cand.motif, false)],
      [`ball-run-${key}.svg`, ballSvg(TEAL_PALETTE.from, TEAL_PALETTE.to, cand.motif, true)],
      [`tray-${key}.svg`, traySvg(TEAL_PALETTE.from, TEAL_PALETTE.to, cand.motif)],
    ]
    for (const [file, svg] of jobs) {
      writeFileSync(join(OUT_DIR, file), svg, 'utf8')
      made.push({ file, kind: 'svg', candidate: key, label: cand.label })
    }
    const pngs = [
      [`ball-${key}.png`, 96, { ...TEAL_PALETTE, motif: cand.motif, running: false }],
      [`ball-run-${key}.png`, 96, { ...TEAL_PALETTE, motif: cand.motif, running: true }],
      [`tray-${key}.png`, 32, { ...TEAL_PALETTE, motif: cand.motif, running: false }],
    ]
    for (const [file, size, opt] of pngs) {
      const buf = makeBallPng(opt, { motif: opt.motif, running: opt.running, size })
      writeFileSync(join(OUT_DIR, file), buf)
      made.push({ file, kind: 'png', bytes: buf.length, candidate: key, label: cand.label })
      console.log(`made ${file} (${buf.length} B)`)
    }
    const t32 = rasterBallRgba(32, { ...TEAL_PALETTE, motif: cand.motif, running: false })
    const t16 = downscale(t32, 2)
    const t16buf = encodePng(t16.data, t16.width, t16.height)
    writeFileSync(join(OUT_DIR, `tray-${key}-16.png`), t16buf)
    made.push({ file: `tray-${key}-16.png`, kind: 'png', bytes: t16buf.length, candidate: key, label: cand.label, path: '32px→2:1面积平均' })
    console.log(`made tray-${key}-16.png (${t16buf.length} B, 32px→2:1)`)
  }

  // ---- 2. 四态表情资产（idle/thinking/need-help/error）----
  for (const mood of FACE_MOODS) {
    // 矢量 SVG（分辨率无关，文档/截图用）
    writeFileSync(join(OUT_DIR, `face-${mood}.svg`), faceSvg(mood, FACE_COLOR), 'utf8')
    made.push({ file: `face-${mood}.svg`, kind: 'svg', mood })
    // 贴在青绿球上的表情 PNG（截图用）
    const exp = compositeExpression(mood, { ...TEAL_PALETTE, motif: 'orbit', faceColor: FACE_COLOR, size: 96 })
    const expBuf = encodePng(exp.data, 96, 96)
    writeFileSync(join(OUT_DIR, `ball-face-${mood}.png`), expBuf)
    made.push({ file: `ball-face-${mood}.png`, kind: 'png', bytes: expBuf.length, mood })
    console.log(`made ball-face-${mood}.png (${expBuf.length} B)`)
  }

  // ---- 3. montage（候选对比 + 表情对比）----
  const candImgs = Object.keys(CANDIDATES).map((k) => rasterBallRgba(96, { ...TEAL_PALETTE, motif: CANDIDATES[k].motif, running: false }))
  const candSheet = montage(candImgs, 16)
  const candBuf = encodePng(candSheet.data, candSheet.width, candSheet.height)
  writeFileSync(join(OUT_DIR, 'candidates-sheet.png'), candBuf)
  made.push({ file: 'candidates-sheet.png', kind: 'png', bytes: candBuf.length, note: 'A/B/C 三候选并排' })
  console.log(`made candidates-sheet.png (${candBuf.length} B)`)

  const faceImgs = FACE_MOODS.map((m) => compositeExpression(m, { ...TEAL_PALETTE, motif: 'orbit', faceColor: FACE_COLOR, size: 96 }))
  const faceSheet = montage(faceImgs, 16)
  const faceBuf = encodePng(faceSheet.data, faceSheet.width, faceSheet.height)
  writeFileSync(join(OUT_DIR, 'expressions-sheet.png'), faceBuf)
  made.push({ file: 'expressions-sheet.png', kind: 'png', bytes: faceBuf.length, note: '四态表情并排' })
  console.log(`made expressions-sheet.png (${faceBuf.length} B)`)

  // ---- 4. 选定 A（轨道球）：与 vendor 底座现行视觉语言一致，改动最小、辨识度已验证。----
  // B / C 的 SVG+PNG 全部保留，随时可切（见 docs/THEMES.md）。
  for (const [src, dst] of [
    ['ball-A.svg', 'ball.svg'],
    ['ball-run-A.svg', 'ball-run.svg'],
    ['tray-A.svg', 'tray.svg'],
    ['ball-A.png', 'ball.png'],
    ['ball-run-A.png', 'ball-run.png'],
    ['tray-A.png', 'tray.png'],
    ['tray-A-16.png', 'tray-16.png'],
  ]) {
    copyFileSync(join(OUT_DIR, src), join(OUT_DIR, dst))
  }
  copyFileSync(join(OUT_DIR, 'tray.png'), join(ASSETS_DIR, 'tray.png'))

  writeFileSync(
    join(OUT_DIR, 'MANIFEST.json'),
    `${JSON.stringify({
      selected: 'A',
      reason: '轨道球与 vendor/orb-base 现行视觉语言一致（阶段 0 起的内联 SVG 就是轨道球），改动最小且辨识度已验证；B（同心圆环）/ C（菱形宝石）作为备选完整保留，可一键切换。',
      palette: TEAL_PALETTE,
      faceColor: FACE_COLOR,
      sizes: { ball: 96, tray: [16, 32] },
      candidates: Object.fromEntries(Object.entries(CANDIDATES).map(([k, v]) => [k, v.label])),
      expressions: FACE_MOODS,
      made,
    }, null, 2)}\n`,
  )
  console.log('\n选定 A（青绿轨道球）→ assets/icons/{ball,ball-run,tray,tray-16}.{svg,png}；assets/tray.png 已更新')
  console.log(`产物目录：${OUT_DIR}`)
}

function ballSvg(from, to, motif, running = false) {
  const badge = running
    ? '<circle cx="32" cy="32" r="28" fill="none" stroke="#7dd3fc" stroke-width="2.6" stroke-dasharray="12 7" stroke-linecap="round"/>'
    : ''
  const core =
    motif === 'orbit'
      ? '<g fill="none" stroke="#e0f2fe" stroke-width="2.2" opacity="0.85"><ellipse cx="32" cy="32" rx="20" ry="7.5"/><ellipse cx="32" cy="32" rx="20" ry="7.5" transform="rotate(60 32 32)"/><ellipse cx="32" cy="32" rx="20" ry="7.5" transform="rotate(-60 32 32)"/></g><circle cx="32" cy="32" r="3.6" fill="#f8fafc"/>'
      : motif === 'rings'
        ? '<g fill="none" stroke="#e0f2fe" stroke-width="2" opacity="0.88"><circle cx="32" cy="32" r="20"/><circle cx="32" cy="32" r="13"/><circle cx="32" cy="32" r="5" fill="#f8fafc" stroke="none"/></g>'
        : '<path d="M32 13 L49 32 L32 51 L15 32 Z" fill="none" stroke="#e0f2fe" stroke-width="2.2" opacity="0.88"/><circle cx="32" cy="32" r="4.2" fill="#f8fafc"/>'
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" width="64" height="64">\n<defs><radialGradient id="g" cx="35%" cy="28%" r="78%"><stop offset="0" stop-color="${from}"/><stop offset="1" stop-color="${to}"/></radialGradient></defs>\n<circle cx="32" cy="32" r="31" fill="url(#g)"/>\n${core}\n${badge}\n</svg>\n`
}

function traySvg(from, to, motif) {
  const core =
    motif === 'orbit'
      ? '<g fill="none" stroke="#e0f2fe" stroke-width="2.4" opacity="0.85"><ellipse cx="16" cy="16" rx="10" ry="3.8"/><ellipse cx="16" cy="16" rx="10" ry="3.8" transform="rotate(60 16 16)"/><ellipse cx="16" cy="16" rx="10" ry="3.8" transform="rotate(-60 16 16)"/></g>'
      : motif === 'rings'
        ? '<g fill="none" stroke="#e0f2fe" stroke-width="2" opacity="0.88"><circle cx="16" cy="16" r="10"/><circle cx="16" cy="16" r="5.5"/></g>'
        : '<path d="M16 7 L25 16 L16 25 L7 16 Z" fill="none" stroke="#e0f2fe" stroke-width="2" opacity="0.88"/>'
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" width="32" height="32">\n<defs><radialGradient id="t" cx="35%" cy="28%" r="78%"><stop offset="0" stop-color="${from}"/><stop offset="1" stop-color="${to}"/></radialGradient></defs>\n<circle cx="16" cy="16" r="15" fill="url(#t)"/>\n${core}\n</svg>\n`
}

main()
