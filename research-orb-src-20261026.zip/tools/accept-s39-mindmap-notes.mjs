// tools/accept-s39-mindmap-notes.mjs —— S39·F5 思维导图关联笔记验收（≥5 项）。
// 单行复跑：node tools\accept-s39-mindmap-notes.mjs
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync, readdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

process.env.ORB_LOG_DIR = join(tmpdir(), 's39-mn-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's39-mn-data-' + Date.now())
const { dataPath, PROJECT_ROOT } = await import('../packages/core/src/safefs.mjs')
const { renderMindmap, saveToNotes, buildMindmapData, mapNodesToNotes } = await import('../packages/plugins/coach/mindmap.mjs')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

try {
  // 播种：goal/blueprint/memory/trajectory + 一条笔记（命中"虚拟电厂"叶子）
  const coach = dataPath('coach')
  mkdirSync(coach, { recursive: true })
  mkdirSync(dataPath('memory', 'project'), { recursive: true })
  const notesDir = dataPath('notes')
  mkdirSync(join(notesDir, '研究导图'), { recursive: true })
  writeFileSync(join(coach, 'goal.json'), JSON.stringify({ goal: '两周内完成微电网综述的初稿与文献表', updatedAt: new Date().toISOString(), source: 'seed' }))
  writeFileSync(join(coach, 'blueprint.md'), '# 蓝图\n1. 定范围：拆成 3 个可核验子问题\n2. 找文献：优先双源\n')
  writeFileSync(dataPath('memory', 'project', 'longterm.md'), [
    JSON.stringify({ id: 'f1', ts: 1792700000000, layer: 1, text: '综述优先覆盖虚拟电厂与需求响应两个章节' }),
    JSON.stringify({ id: 'f2', ts: 1792700001000, layer: 1, text: '用户每周可投入约 10 小时推进综述写作' }),
    '', ].join('\n'))
  writeFileSync(join(coach, 'trajectory.jsonl'), [
    JSON.stringify({ ts: new Date().toISOString(), window: 'VSCode', process: 'code.exe', intent: '撰写论文方法章节' }), '',
  ].join('\n'))
  // 一条真实笔记：正文包含"虚拟电厂与需求响应"（导图叶子命中它）
  writeFileSync(join(notesDir, '微电网综述大纲.md'), '# 大纲\n第二章 虚拟电厂与需求响应：聚合商机制……\n', 'utf8')

  const r = await renderMindmap({ query: '研究 方向 综述' })

  // N-1 sidecar 存在（mindmap-*.json）
  check('N-1 sidecar mindmap-*.json 存在', existsSync(r.sidecarPath), `sidecar=${r.sidecarPath.split(/[\\/]/).pop()}`, {})

  // N-2 映射条目齐：每个叶子一条 {nodePath,text,source,noteFile}
  const sidecar = JSON.parse(readFileSync(r.sidecarPath, 'utf8'))
  const leafCount = r.data.themes.reduce((a, t) => a + (t.leaves || []).length, 0)
  check('N-2 映射条目齐（每叶一条）', Array.isArray(sidecar.nodes) && sidecar.nodes.length === leafCount && sidecar.nodes.every((n) => n.nodePath && n.text && n.source),
    `nodes=${sidecar.nodes.length} leaves=${leafCount}`, {})

  // N-3 命中笔记：含"虚拟电厂"的叶子 → 跳到大纲笔记
  const hit = sidecar.nodes.find((n) => (n.text || '').includes('虚拟电厂'))
  check('N-3 命中笔记跳转', hit && hit.noteFile && readFileSync(hit.noteFile, 'utf8').includes('虚拟电厂'),
    `noteFile=${hit && hit.noteFile ? hit.noteFile.split(/[\\/]/).pop() : 'null'}`, {})

  // N-4 未命中如实标注 noteFile:null（可点但无目标，不编造）
  const miss = sidecar.nodes.find((n) => !(n.text || '').includes('虚拟电厂'))
  check('N-4 未命中 noteFile:null', !!miss && miss.noteFile === null,
    `miss text=${(miss && miss.text || '').slice(0, 20)}`, {})

  // N-5 存笔记库后 sidecar 与 png 同目录同基名（可点跳转随图走）
  const saved = saveToNotes(r)
  const sidecarCopied = existsSync(join(dataPath('notes', '研究导图'), r.sidecarPath.split(/[\\/]/).pop()))
  check('N-5 sidecar 随图入笔记库', existsSync(saved.pngDst) && sidecarCopied,
    `png+json 同存=${sidecarCopied}`, {})

  // N-6 nodePath 结构可定位（themes[i]/title/leaves[j]）
  check('N-6 nodePath 可定位', sidecar.nodes.every((n) => /^themes\[\d+\]\//.test(n.nodePath) && /leaves\[\d+\]$/.test(n.nodePath)),
    `path 格式统一`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's39-mindmap-notes-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s39-mindmap-notes: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
