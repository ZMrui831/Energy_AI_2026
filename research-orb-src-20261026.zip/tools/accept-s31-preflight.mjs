// tools/accept-s31-preflight.mjs —— S31·B3 审计完整性巡检验收（≥5 项）。
// 单行复跑：node tools\accept-s31-preflight.mjs
// 证据：data\logs\s31-preflight-accept.json
//
// 覆盖：一致放行 / 人为删行拒绝 / 恢复放行 / 基线缺失报错 / 额外字段不影响判定。
// 全程在临时 WORK 根跑，不触碰工程真实日志。
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { auditPreflight } from '../packages/plugins/coach/audit-preflight.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 240), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's31-preflight')
rmSync(WORK, { recursive: true, force: true })
const LOGS = join(WORK, 'data', 'logs')
mkdirSync(LOGS, { recursive: true })
const coachLog = join(LOGS, 'coach.jsonl')
const writesLog = join(LOGS, 'writes.jsonl')
const usageLog = join(LOGS, 'usage.jsonl')
const bp = join(LOGS, 's25-audit-preflight.json')

function seed() {
  writeFileSync(writesLog, 'a\nb\nc\n')        // 3 行
  writeFileSync(coachLog, 'x\ny\n')           // 2 行
  writeFileSync(usageLog, 'z\n')              // 1 行
  writeFileSync(bp, JSON.stringify({ at: '2026-10-23T00:00:00Z', note: 'S25 baseline', 'writes.jsonl': 3, 'coach.jsonl': 2, 'usage.jsonl': 1 }))
}

try {
  // ① 一致放行：当前行数均 >= 基线
  seed()
  let r1 = null
  try { r1 = auditPreflight({ root: WORK, baselinePath: bp }) } catch (e) { r1 = { error: e } }
  check('P1 一致放行（当前行数均 >= 基线）', r1 && r1.ok === true && r1.results.every((x) => x.ok), r1 && r1.ok ? 'files=' + r1.results.map((x) => x.file + ':' + x.current + '/' + x.baseline).join(' ') : 'fail: ' + (r1.error && r1.error.message))

  // ② 人为删行拒绝：coach.jsonl 删到 1 行（< 基线 2）
  writeFileSync(coachLog, 'x\n')
  let r2Err = null
  try { auditPreflight({ root: WORK, baselinePath: bp }) } catch (e) { r2Err = e }
  check('P2 人为删行拒绝（coach.jsonl 1<2 → E_AUDIT_LOSS）', r2Err && r2Err.code === 'E_AUDIT_LOSS', r2Err ? r2Err.code + ' ' + r2Err.message : '未抛错')

  // ③ 恢复放行：coach.jsonl 还原 2 行
  writeFileSync(coachLog, 'x\ny\n')
  let r3 = null
  try { r3 = auditPreflight({ root: WORK, baselinePath: bp }) } catch (e) { r3 = { error: e } }
  check('P3 恢复放行（还原后通过）', r3 && r3.ok === true, r3 && r3.ok ? 'ok' : 'fail')

  // ④ 基线缺失报错
  rmSync(bp)
  let r4Err = null
  try { auditPreflight({ root: WORK, baselinePath: bp }) } catch (e) { r4Err = e }
  check('P4 基线缺失报错（E_NO_BASELINE）', r4Err && r4Err.code === 'E_NO_BASELINE', r4Err ? r4Err.code : '未抛错')

  // ⑤ 额外字段不影响判定（还原基线 + 加无关数值字段）
  writeFileSync(bp, JSON.stringify({ at: '2026-10-23T00:00:00Z', note: 'S25 baseline', 'writes.jsonl': 3, 'coach.jsonl': 2, 'usage.jsonl': 1, unrelated_metric: 999 }))
  let r5 = null
  try { r5 = auditPreflight({ root: WORK, baselinePath: bp }) } catch (e) { r5 = { error: e } }
  check('P5 额外字段不影响判定（unrelated_metric 被忽略）', r5 && r5.ok === true, r5 && r5.ok ? 'ok' : 'fail')
} catch (e) {
  check('P0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 240))
} finally {
  rmSync(WORK, { recursive: true, force: true })
}

const pass = items.filter((i) => i.ok).length
const fail = items.length - pass
const out = { tool: 'accept-s31-preflight', at: new Date().toISOString(), total: items.length, pass, fail, items }
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's31-preflight-accept.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # accept-s31-preflight: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 证据 -> data/logs/s31-preflight-accept.json`)
process.exit(fail === 0 ? 0 : 1)
