// tools/diag-t5-card.mjs —— S54·D1 感知状态卡渲染链路验证（隔离实例）
//
// 验证：perception today 审计统计 → timeline status 回包 perceptionCard → home-v1 渲染。
// 断言：卡存在、7 行、感知默认关（隔离实例无同意）、数字与审计一致、缺数据显示 —。
// 用法：node tools\diag-t5-card.mjs   （需应用退出；fail-closed）

import { mkdtempSync, rmSync, cpSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import { spawn, spawnSync } from 'node:child_process'
import {killMarked, countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('diag-t5-card')

const ELECTRON = ORB_ELECTRON
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9343
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const countProcs = () => countOrbAll()
const killOwn = () => killMarked(MARK)

async function findTarget(t = 40000) {
  const d = Date.now() + t
  while (Date.now() < d) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const l = await r.json()
      const p = l.find((x) => x.type === 'page' && x.webSocketDebuggerUrl && /floating\.html/i.test(String(x.url || '')))
      if (p) return p
    } catch { /* 等 */ }
    await sleep(350)
  }
  return null
}
function cdpConnect(wsUrl) {
  const ws = new WebSocket(wsUrl)
  let seq = 0
  const pending = new Map()
  const ready = new Promise((res, rej) => { ws.addEventListener('open', () => res()); ws.addEventListener('error', () => rej(new Error('ws'))) })
  ws.addEventListener('message', (ev) => {
    let m = null
    try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
    if (!m || !m.id) return
    const p = pending.get(m.id); if (!p) return
    pending.delete(m.id)
    if (m.error) p.rej(new Error(JSON.stringify(m.error))); else p.res(m.result)
  })
  const send = (method, params) => new Promise((res, rej) => { const id = ++seq; pending.set(id, { res, rej }); ws.send(JSON.stringify({ id, method, params })) })
  return { ready, send, close: () => { try { ws.close() } catch { /* noop */ } } }
}
async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r && r.exceptionDetails) throw new Error('ev: ' + JSON.stringify(r.exceptionDetails).slice(0, 300))
  return r && r.result ? r.result.value : undefined
}

const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-t5-card-'))
let child = null
let cdp = null
try {
  if (countProcs() > 0) { console.log('PREFLIGHT-FAIL: 已有实例在跑'); process.exit(2) }
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  delete env.ORB_LOG_DIR
  env.ORB_DATA_DIR = join(tmpRoot, 'data')
  try { cpSync(join(PROJECT_ROOT, 'data', 'themes'), join(env.ORB_DATA_DIR, 'themes'), { recursive: true }) } catch { /* 就算了 */ }
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], { cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] })
  const target = await findTarget()
  if (!target) { console.log('NO-TARGET'); process.exit(3) }
  cdp = cdpConnect(target.webSocketDebuggerUrl)
  await cdp.ready
  await cdp.send('Runtime.enable')
  let bridge = false
  const dl = Date.now() + 30000
  while (Date.now() < dl) {
    try { bridge = await ev(cdp, 'typeof globalThis.__s5 === "object" && typeof globalThis.researchOrb === "object"'); if (bridge) break } catch { /* 等 */ }
    await sleep(400)
  }
  if (!bridge) { console.log('NO-BRIDGE'); process.exit(3) }
  await ev(cdp, 'globalThis.researchOrb.send("window", { action: "expand" })')
  await sleep(2000)

  // 首页感知卡 DOM
  const card = JSON.parse(await ev(cdp, `(() => {
    const c = document.getElementById('ro-percep-card')
    if (!c) return JSON.stringify({ missing: true })
    const rows = [...c.querySelectorAll('.ro-percep-row')].map((r) => {
      const k = r.querySelector('.ro-percep-k'), v = r.querySelector('.ro-percep-v')
      return [k ? k.textContent : '', v ? v.textContent : '']
    })
    const strip = document.querySelector('#s5-home .s5-status')
    return JSON.stringify({ title: (c.querySelector('.ro-percep-title') || {}).textContent || '', rows, n: rows.length,
      stripChips: strip ? [...strip.querySelectorAll('.s5-chip')].map((x) => x.textContent) : null,
      frozen: document.body.classList.contains('ro-frozen') })
  })()`))
  console.log('[卡] ' + JSON.stringify(card))
  // 若卡空：主动触发一次 status 拉取（模拟轮询/进入首页），等回包后重读
  if (card.n === 0) {
    console.log('[重试] 主动 sendCmd ui status，等 2.5s 后重读')
    await ev(cdp, '(() => { const b = document.querySelector("#ro-ds-nav .ds-nav-btn[data-page=\\"notes\\"]"); if (b) b.click(); return "ok" })()')
    await sleep(600)
    await ev(cdp, '(() => { const b = document.querySelector("#ro-ds-nav .ds-nav-btn[data-page=\\"home\\"]"); if (b) b.click(); return "ok" })()')
    await sleep(2500)
    const card2 = JSON.parse(await ev(cdp, `(() => {
      const c = document.getElementById('ro-percep-card')
      const rows = [...(c ? c.querySelectorAll('.ro-percep-row') : [])].map((r) => {
        const k = r.querySelector('.ro-percep-k'), v = r.querySelector('.ro-percep-v')
        return [k ? k.textContent : '', v ? v.textContent : '']
      })
      const strip = document.querySelector('#s5-home .s5-status')
      return JSON.stringify({ n: rows.length, rows, stripChips: strip ? [...strip.querySelectorAll('.s5-chip')].map((x) => x.textContent) : null })
    })()`))
    console.log('[重试后] ' + JSON.stringify(card2))
    card.rows = card2.rows
    card.n = card2.n
    card.stripChips = card2.stripChips
    card._retry = true
  }
  check('T5-1 感知卡存在且有标题', !card.missing && card.title === '感知与记录', card.title || 'missing')
  check('T5-2 七行指标齐全', card.n === 7, 'rows=' + card.n)
  const kv = Object.fromEntries(card.rows || [])
  check('T5-3 感知默认关（隔离实例无同意）', kv['感知'] === '○ 关', '感知=' + kv['感知'])
  // 干净隔离实例：审计无今日事件 → 0 是真实统计（非缺数据）
  // S56 口径：已压缩送模（主指标，括号内是省 MB）+ 原图已删（灰副标）
  check('T5-4 计数行真实为 0（非缺数据）', kv['今日采样'] === '0 次' && /^0 张/.test(String(kv['已压缩送模'])) && kv['原图已删'] === '0 张' && kv['今日片段'] === '0 条', JSON.stringify(kv))
  check('T5-5 最近采样无数据显示 —', kv['最近采样'] === '—', '最近采样=' + kv['最近采样'])
  check('T5-6 省 MB 已并入主指标（0 张时不显示括号，且不再单列"省出空间"行）', !('省出空间' in kv) && !/[（(]省/.test(String(kv['已压缩送模'])), JSON.stringify({ sent: kv['已压缩送模'], hasOldRow: '省出空间' in kv }))
} catch (e) {
  console.log('DIAG-ERROR: ' + String((e && e.stack) || e).slice(0, 400))
} finally {
  try { if (cdp) cdp.close() } catch { /* noop */ }
  killOwn()
  await sleep(1200)
  // 保留临时目录便于取证（读主进程 app.jsonl 的命令结果）：console 输出路径
  console.log('[保留取证目录] ' + tmpRoot)
  // try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}
const pass = items.filter((i) => i.ok).length
console.log(`  # diag-t5-card: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exitCode = items.length - pass === 0 ? 0 : 1
