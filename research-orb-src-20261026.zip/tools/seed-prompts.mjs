// tools/seed-prompts.mjs —— S74·1-A：把"代码常量里的提示词种子"落进仓库 data\prompts\
//
// 用法：
//   node tools\seed-prompts.mjs            # 写入（缺则补；已存在则校验漂移）
//   node tools\seed-prompts.mjs --check    # 只校验：仓库种子文件 == 代码常量（供门禁用）
//
// 纪律：
//   · **唯一真源是代码常量**：本工具只做"导出"，不在这里另写一份文案；
//   · 不覆盖：文件已存在且与常量一致 → 跳过；不一致 → **报错（漂移）**，由人决定是否更新种子；
//   · --check 非零退出 = 漂移（提示词改了但种子没同步），门禁应红。

import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import {join, resolve} from 'node:path'
import { promptsDir, seedContent, seedFileName, DEV_PROMPT_KINDS, SEED_VERSION_ID } from '../packages/plugins/coach/dev-cmd.mjs'

const CHECK = process.argv.includes('--check')
const sha = (s) => createHash('sha256').update(Buffer.from(String(s), 'utf8')).digest('hex')

// 仓库 data\prompts\ 是**真实数据目录**（ORB_DATA_DIR 未设时）；本工具只服务仓库本身，
// 不跟随 ORB_DATA_DIR（隔离验收靠 ensureSeeded() 运行时自补）。
const ROOT = resolve(import.meta.dirname, '..')
const DIR = join(ROOT, 'data', 'prompts')

function main() {
  if (!CHECK) mkdirSync(DIR, { recursive: true })
  const rows = []
  let drift = 0
  let created = 0
  const versions = {}
  for (const kind of DEV_PROMPT_KINDS) {
    const want = seedContent(kind)
    const file = seedFileName(kind)
    const p = join(DIR, file)
    const wantSha = sha(want)
    let status = ''
    let chars = want.length
    if (!CHECK && !existsSync(p)) { writeFileSync(p, want, 'utf8'); status = 'created'; created++ }
    else if (!existsSync(p)) { status = 'MISSING'; drift++ }
    else {
      const got = readFileSync(p, 'utf8')
      chars = got.length
      if (sha(got) === wantSha) status = 'in-sync'
      else {
        status = 'DRIFT'
        drift++
        if (!CHECK) { writeFileSync(p, want, 'utf8'); status = 'DRIFT→rewritten' }
      }
    }
    versions[kind] = {
      id: SEED_VERSION_ID[kind],
      file,
      chars,
      sha256: wantSha,
      note: 'v1 种子（由代码常量导出，与运行时逐字一致）',
      createdAt: (() => { try { return existsSync(p) ? '' : '' } catch { return '' } })(),
    }
    rows.push({ kind, file, chars, sha256: wantSha.slice(0, 12), status })
  }
  console.table(rows)
  if (!CHECK) {
    // index.json：按 kind 分桶（schema 1）
    const idxPath = join(DIR, 'index.json')
    let idx = { schema: 1, kinds: [] }
    try { if (existsSync(idxPath)) idx = JSON.parse(readFileSync(idxPath, 'utf8')) } catch { /* 重建 */ }
    const old = Array.isArray(idx.kinds) ? idx.kinds : []
    idx.schema = 1
    idx.updatedAt = new Date().toISOString()
    idx.kinds = DEV_PROMPT_KINDS.map((kind) => {
      const prev = old.find((k) => k.kind === kind) || {}
      const prevVersions = Array.isArray(prev.versions) ? prev.versions : []
      // v1 条目由常量定死（chars/sha256/note），其余版本保留
      const seedV = versions[kind]
      const rest = prevVersions.filter((v) => v.id !== seedV.id)
      const seedMeta = prevVersions.find((v) => v.id === seedV.id)
      return {
        kind,
        activeVersion: prev.activeVersion || SEED_VERSION_ID[kind],
        versions: [seedMeta ? { ...seedMeta, ...seedV, createdAt: seedMeta.createdAt || new Date().toISOString() } : { ...seedV, createdAt: new Date().toISOString() }, ...rest],
      }
    })
    writeFileSync(idxPath, JSON.stringify(idx, null, 2), 'utf8')
    console.log('[seed-prompts] index.json 已更新：' + idx.kinds.map((k) => `${k.kind}=${k.activeVersion}(${k.versions.length})`).join(' '))
  }
  if (CHECK) {
    if (drift) { console.error(`[seed-prompts] 漂移 ${drift} 处：仓库种子与代码常量不一致（跑 node tools\\seed-prompts.mjs 同步）`); process.exit(1) }
    console.log('[seed-prompts] 校验通过：仓库种子与代码常量逐字一致')
  } else {
    console.log(`[seed-prompts] 完成：新建 ${created} 个，漂移重写 ${rows.filter((r) => r.status.startsWith('DRIFT')).length} 个`)
  }
}

main()
