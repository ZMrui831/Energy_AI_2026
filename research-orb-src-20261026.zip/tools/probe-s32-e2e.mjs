// tools/probe-s32-e2e.mjs —— S32 端到端真跑（命令接线验证）。
// 单行复跑：node tools\probe-s32-e2e.mjs
// 证据：data\logs\s32-e2e.json
//
// 目的：不是单测模块，而是经真实 activate(ctx) 挂起后，调用真实命令入口：
//   /coach weekly（周报+趋势图，写真实 data/coach + data/artifacts）
//   /coach plans add|list|done|drop（真实 plans.jsonl）
//   /privacy（注入临时生命周期库，验证只读仪表盘命令） / /privacy export
// 断言：命令已注册、返回 ok、产物落盘、plans 勾销生效。
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createStore } from '../packages/core/src/db.mjs'
import { activate } from '../packages/plugins/coach/index.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's32-e2e')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(WORK, { recursive: true })

try {
  // 注入一个临时生命周期库，供 /privacy 使用（不碰真实库）
  const store = await createStore({ driver: 'sqlite', dbPath: join(WORK, 'orb.sqlite'), dataDir: WORK })
  store.initMigrations()
  store.insertRawFrame({ id: 'rf-e2e', file_path: join(WORK, 'x.png'), sha256: 'a'.repeat(64), sensitivity: 'normal', created_at: new Date().toISOString(), expires_at: new Date(Date.now() + 3600000).toISOString() })

  const cmds = {}
  const ctx = {
    log: { info() {}, warn() {}, error() {} },
    ui: { registerCard() {}, registerCommand(spec) { cmds[spec.name] = spec } },
    core: { lifecycle: store, screen: { captureScreen: async () => ({ ok: false }) } },
  }
  const handle = await activate(ctx)
  check('E1', handle && handle.ok === true && !!cmds.coach && !!cmds.privacy, `coach=${!!cmds.coach} privacy=${!!cmds.privacy}`, { ok: handle && handle.ok })

  // /coach weekly
  const wk = await cmds.coach.run('weekly')
  const weekFile = (wk.text || '').match(/weekly-\d{4}-W\d{2}\.md/)
  check('E2', wk.ok === true && /周报（\d{4}-W\d{2}/.test(wk.text) && !!weekFile,
    (wk.text || '').split('\n')[0], { text: (wk.text || '').slice(0, 200) })

  // /coach plans add → list → done
  const addR = await cmds.coach.run('plans add E2E临时计划 --due 2026-10-30')
  const idMatch = (addR.text || '').match(/pl-[a-z0-9-]+/)
  const planId = idMatch && idMatch[0]
  const listR = await cmds.coach.run('plans list')
  const doneR = planId ? await cmds.coach.run('plans done ' + planId) : { ok: false, text: '' }
  check('E3', addR.ok && !!planId && /pending/.test(listR.text) && doneR.ok && /已完成|勾销/.test(doneR.text),
    `add=${!!planId} listPending=${/pending/.test(listR.text)} done=${doneR.ok}`, { planId })

  // /privacy + export
  const pv = await cmds.privacy.run('')
  check('E4', pv.ok === true && /隐私仪表盘/.test(pv.text) && /保留矩阵现状/.test(pv.text) && pv.text.includes('项目:/'),
    (pv.text || '').split('\n')[0], { head: (pv.text || '').slice(0, 120) })
  const pvEx = await cmds.privacy.run('export')
  check('E5', pvEx.ok === true && /privacy-\d{8}\.md/.test(pvEx.text), pvEx.text, {})

  try { handle.deactivate && handle.deactivate() } catch { /* 尽力 */ }
  try { store.close && store.close() } catch { /* 尽力 */ }
  check('E6', true, '命令接线全部跑通（weekly/plans/privacy）', {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(join(PROJECT_ROOT, 'data', 'logs', 's32-e2e.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # probe-s32-e2e: total=${items.length} pass=${pass} fail=${items.length - pass}`)
console.log('  # 证据 -> data/logs/s32-e2e.json')
process.exit(pass === items.length ? 0 : 1)
