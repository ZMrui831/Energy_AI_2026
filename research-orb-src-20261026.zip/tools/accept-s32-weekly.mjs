// tools/accept-s32-weekly.mjs —— S32·1 周报聚合 + 评分趋势图验收（≥8 项）。
// 单行复跑：node tools\accept-s32-weekly.mjs
// 证据：data\logs\s32-weekly-accept.json
//
// 覆盖：7 天聚合(轨迹/专注/娱乐/评分) / 缺日不报错 / 周报文件名按 ISO 周 / 逐日表+3 趋势 /
//      按周幂等(cached) / 趋势图 PNG 尺寸 / 图内来源标注 / 审计行 weekly-report / 趋势判断数据驱动。
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { aggregateWeek, writeWeeklyReport, buildWeeklyTrendChart, localDayKey, isoWeekKey } from '../packages/plugins/coach/weekly.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's32-weekly')
rmSync(WORK, { recursive: true, force: true })
const COACH = join(WORK, 'coach')
const ART = join(WORK, 'artifacts')
mkdirSync(join(COACH, 'daily'), { recursive: true })
mkdirSync(ART, { recursive: true })

const now = Date.parse('2026-10-23T10:00:00Z')
const iso = (ms) => new Date(ms).toISOString()
const pad = (n) => String(n).padStart(2, '0')

// 种子：近 7 天，第 i=3 天（2026-10-20）故意缺数据（缺日不报错）
const DAY = 86400000
const traj = []
const health = []
for (let i = 6; i >= 0; i--) {
  if (i === 3) continue
  const ms = now - i * DAY
  const n = (i % 3) + 1
  for (let k = 0; k < n; k++) traj.push(JSON.stringify({ ts: iso(ms + k * 60000), window: 'w', process: 'code.exe', intent: 'i', level: 'direct', evidence: { frameId: 'fr' + i + k, textSha256: 's' + i + k } }))
  health.push(JSON.stringify({ ts: iso(ms), kind: 'window', category: 'work', dwellMin: 30 }))
  health.push(JSON.stringify({ ts: iso(ms + 3600000), kind: 'window', category: 'entertainment', dwellMin: 10 }))
}
writeFileSync(join(COACH, 'trajectory.jsonl'), traj.join('\n') + '\n', 'utf8')
writeFileSync(join(COACH, 'health.jsonl'), health.join('\n') + '\n', 'utf8')
for (const [i, sc] of [[6, 60], [5, 70], [4, 80], [1, 90]]) {
  const d = new Date(now - i * DAY)
  const ymd = '' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate())
  writeFileSync(join(COACH, 'daily', `daily-${ymd}.md`), `# 日报\n\n- 评分：${sc} / 100（score-plan）\n`, 'utf8')
}

let auditRows = []
const auditFn = (r) => auditRows.push(r)

try {
  const agg = aggregateWeek({ dir: COACH, now })

  // W1：7 天聚合数值正确
  const expTraj = traj.length
  const expFocus = 6 * 30
  const expEnt = 6 * 10
  const expAvg = Math.round((60 + 70 + 80 + 90) / 4)
  check('W1', agg.days.length === 7 && agg.totals.trajectory === expTraj && agg.totals.focusMin === expFocus && agg.totals.entertainmentMin === expEnt && agg.totals.avgScore === expAvg,
    `days=${agg.days.length} traj=${agg.totals.trajectory}/${expTraj} focus=${agg.totals.focusMin}/${expFocus} ent=${agg.totals.entertainmentMin}/${expEnt} avg=${agg.totals.avgScore}/${expAvg}`,
    { totals: agg.totals })

  // W2：缺日不报错（10-20 轨迹 0、评分 null，且 day 存在）
  const missDay = agg.days.find((d) => d.date === '2026-10-20')
  check('W2', !!missDay && missDay.trajectory === 0 && missDay.score === null && missDay.focusMin === 0,
    `缺日 2026-10-20 exists=${!!missDay} traj=${missDay && missDay.trajectory} score=${missDay && missDay.score}`,
    { missDay })

  // W3：周报文件名按 ISO 周
  const w = writeWeeklyReport({ dir: COACH, now, auditFn })
  const expectWeek = isoWeekKey(now)
  const fname = w.path.split(/[\\/]/).pop()
  check('W3', fname === `weekly-${expectWeek}.md` && existsSync(w.path),
    `file=${fname} expect=weekly-${expectWeek}.md`, { path: w.path })

  // W4：逐日表 + 3 条趋势判断
  const md = readFileSync(w.path, 'utf8')
  const trendLines = (md.match(/^\d+\. /gm) || []).length
  check('W4', md.includes('## 汇总') && md.includes('## 逐日') && md.includes('## 3 条趋势判断') && trendLines === 3,
    `汇总=${md.includes('## 汇总')} 逐日=${md.includes('## 逐日')} 趋势行=${trendLines}`, { head: md.slice(0, 120) })

  // W5：按周幂等（同 now 再写一次 → cached，不改内容）
  const w2 = writeWeeklyReport({ dir: COACH, now, auditFn })
  check('W5', w2.cached === true, `cached=${w2.cached}`, { cached: w2.cached })

  // W6：趋势图 PNG（weekly-*.png ≥ 1600×1000）
  const c = await buildWeeklyTrendChart({ agg: w.agg, outDir: ART, now })
  const pngOk = existsSync(c.pngPath) && c.size.width === 1600 && c.size.height === 1000
  check('W6', pngOk && c.pngPath.includes('weekly-'),
    `png=${c.pngPath.split(/[\\/]/).pop()} ${c.size.width}x${c.size.height} bytes=${readFileSync(c.pngPath).length}`,
    { size: c.size })

  // W7：图内来源标注（drawn.json 记录 annotation 含"来源"）
  const drawn = JSON.parse(readFileSync(c.pngPath + '.drawn.json', 'utf8'))
  const annHasSource = (drawn.annotationLines || []).join(' ').includes('来源')
  check('W7', drawn.kind === 'line' && annHasSource && Array.isArray(drawn.lineValues),
    `kind=${drawn.kind} 来源=${annHasSource} lineValues=${JSON.stringify(drawn.lineValues)}`, { drawn: { kind: drawn.kind, annotationLines: drawn.annotationLines } })

  // W8：审计行 weekly-report
  const hasAudit = auditRows.some((r) => r.kind === 'weekly-report' && r.week === expectWeek)
  check('W8', hasAudit, `auditRows=${auditRows.length} weekly-report=${auditRows.filter((r) => r.kind === 'weekly-report').length}`, { audit: auditRows.slice(-2) })

  // W9：3 条趋势判断数据驱动（含数字，非空）
  const dataDriven = agg.trends.length === 3 && agg.trends.every((t) => t && /\d/.test(t))
  check('W9', dataDriven, agg.trends.join(' | '), { trends: agg.trends })
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(join(PROJECT_ROOT, 'data', 'logs', 's32-weekly-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s32-weekly: total=${items.length} pass=${pass} fail=${items.length - pass}`)
console.log('  # 证据 -> data/logs/s32-weekly-accept.json')
process.exit(pass === items.length ? 0 : 1)
