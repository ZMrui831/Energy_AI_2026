// tools/_probe-logdir-writer.mjs —— S33·C 辅助：在 ORB_LOG_DIR 下写 N 行日志，供验收子进程调用。
import { logPath, appendJsonl, LOG_DIR, WRITES_LOG } from '../packages/core/src/safefs.mjs'

const n = Math.max(1, Number(process.argv[2]) || 5)
const file = logPath('probe-logdir.jsonl')
for (let i = 0; i < n; i++) appendJsonl(file, { ts: new Date().toISOString(), i })
console.log(JSON.stringify({ LOG_DIR, WRITES_LOG, file, wrote: n }))
