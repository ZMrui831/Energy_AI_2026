// tools/accept-stage3-2.mjs
//
// 阶段 3.2 验收取证器（P-R3.2：面板注入回归 + 版本单一来源）。
// 主管核验 P-R3.1 时发现两个必现缺陷：
//   1. 🔴 ui-bridge 注入体 TDZ 回归 → renderer "Cannot access 'state' before
//      initialization" → bridge-inject-failed → UI 全废（静态契约断言抓不到）；
//   2. 🟡 main.mjs 硬编码旧版本号 → 托盘菜单显示错版本。
// 本阶段修复 + 双保险回归：tests/ui-bridge.test.mjs（离线 vm 执行 + 版本表达式求值）
// 与本工具的真实 electron 冒烟（注入体在真实 renderer 里不抛异常）。
//
// 验收项：
//   ① 真实 electron 冒烟（--no-sandbox，agent shell 环境既定变通）：app.jsonl 出现
//      bridge-injected 且无 bridge-inject-failed；renderer.jsonl 新增行无 Uncaught；
//      附带记录 core-ready / window-ready（render-process-gone 为已知环境问题，只记录不判负）。
//   ② 版本单一来源：main.mjs 的 APP_VERSION 表达式求值 == package.json.version
//      == research-timer 的 TIMER_VERSION == plugin.json.version；且 main.mjs 无第二处版本字面量。
//   ③ 全量测试 ≥338 条全绿（阶段 3.1 的 334 + ui-bridge 回归 4 条）。
//   ④ 隔离复核：probe-isolation verify（对 stage31 基线）+ baseline 留档（stage32）。
//
// 用法：node tools/accept-stage3-2.mjs
// 产物：data/logs/stage32-*.txt / .json + data/logs/stage32-summary.json

import { spawn, spawnSync } from 'node:child_process'
import { existsSync, readdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT, safeWrite } from '../packages/core/src/safefs.mjs'
import { TIMER_VERSION } from '../packages/plugins/research-timer/index.mjs'
import {countOrbAll, killMarked, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-stage3-2')

const LOGS = join(PROJECT_ROOT, 'data', 'logs')
const APP_LOG = join(LOGS, 'app.jsonl')
const RENDERER_LOG = join(LOGS, 'renderer.jsonl')
const MAIN_PATH = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const RESULTS = []

function evidence(name, text) {
  safeWrite(join(LOGS, name), text)
  return `data/logs/${name}`
}
function jsonEvidence(name, obj) {
  return evidence(name, JSON.stringify(obj, null, 2))
}
function record(id, title, ok, detail, files = []) {
  RESULTS.push({ id, title, ok: !!ok, detail, files })
  process.stdout.write(`[${ok ? 'PASS' : 'FAIL'}] ${id} ${title}\n        ${String(detail).replace(/\n/g, '\n        ')}\n`)
  if (files.length > 0) process.stdout.write(`        证据：${files.join('  ')}\n`)
}
async function step(id, title, fn) {
  try {
    return await fn()
  } catch (err) {
    record(id, title, false, `异常：${(err && err.message) || err}`, [])
    return null
  }
}
function runNode(args, { env = null } = {}) {
  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  if (env) Object.assign(childEnv, env)
  const r = spawnSync(process.execPath, args, { cwd: PROJECT_ROOT, encoding: 'utf8', env: childEnv })
  return { status: r.status, stdout: String(r.stdout || ''), stderr: String(r.stderr || '') }
}
function killOwnElectron() { return killMarked(MARK) }

// ---------------------------------------------------------------------------
// ① 真实 electron 冒烟：注入体在真实 renderer 中不抛异常（bridge-injected）
// ---------------------------------------------------------------------------

await step('①', '真实 electron 冒烟：bridge-injected 且 renderer 无 Uncaught（TDZ 回归的运行时保险）', async () => {
  // 前置：已有 research-orb 在跑会抢单实例锁，冒烟必须独占
  // S74c·P0-1：这块是**只读**预检（fail-closed），用 _orb-proc 的 countOrbAll 统一口径，
  // 不在本文件内嵌按 app 路径匹配的 PowerShell 串。
  const running = countOrbAll()
  if (Number.isFinite(running) && running > 0) {
    record('①', '真实 electron 冒烟', false, `已有 ${running} 个 research-orb 进程在运行，先退出再验收（fail-closed）`, [])
    return null
  }

  const appBefore = existsSyncSafe(APP_LOG) ? readFileSync(APP_LOG, 'utf8').length : 0
  const renBefore = existsSyncSafe(RENDERER_LOG) ? readFileSync(RENDERER_LOG, 'utf8').length : 0

  const child = spawn(ORB_ELECTRON,
    [`--user-data-dir=${orbUdata(MARK)}`, join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs'), '--no-sandbox'],
    {
      cwd: PROJECT_ROOT,
      env: (() => { const e = { ...process.env }; delete e.ELECTRON_RUN_AS_NODE; return e })(),
      stdio: 'ignore',
      detached: false,
    })

  const seen = { start: null, coreReady: null, windowReady: null, bridgeInjected: null, bridgeFailed: null, panelFailed: null, rendererGone: null }
  const deadline = Date.now() + 60_000
  while (Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, 1000))
    const appNow = existsSyncSafe(APP_LOG) ? readFileSync(APP_LOG, 'utf8') : ''
    for (const line of appNow.slice(appBefore).split('\n')) {
      if (!line.trim()) continue
      try {
        const j = JSON.parse(line)
        if (j.type === 'start') seen.start = j
        if (j.type === 'core-ready') seen.coreReady = j
        if (j.type === 'window-ready') seen.windowReady = j
        if (j.type === 'bridge-injected') seen.bridgeInjected = j
        if (j.type === 'bridge-inject-failed') seen.bridgeFailed = j
        if (j.type === 'panel-load-failed') seen.panelFailed = j
        if (j.type === 'renderer-gone') seen.rendererGone = j
      } catch { /* 半行跳过 */ }
    }
    if (seen.bridgeInjected || seen.bridgeFailed) break
    if (child.exitCode !== null) break
  }
  // 注入成功后再观察 3 秒，让注入后的异步 console 错误有机会落盘
  if (seen.bridgeInjected) await new Promise((r) => setTimeout(r, 3000))

  try { child.kill('SIGKILL') } catch { /* 已退出 */ }
  await new Promise((r) => setTimeout(r, 1500))
  killOwnElectron()

  const renNow = existsSyncSafe(RENDERER_LOG) ? readFileSync(RENDERER_LOG, 'utf8') : ''
  const newRendererLines = renNow.slice(renBefore).split('\n').filter((l) => l.trim()).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
  const uncaught = newRendererLines.filter((r) => /Uncaught/i.test(String(r.message || '')))

  const injectedOk = !!seen.bridgeInjected
  const failedAbsent = !seen.bridgeFailed
  const noPanelFail = !seen.panelFailed
  const noUncaught = uncaught.length === 0
  const ok = injectedOk && failedAbsent && noPanelFail && noUncaught

  const txt = [
    '=== electron 冒烟（--no-sandbox；agent shell 环境既定变通，见 STAGE-LOG P-R0 环境坑）===',
    `启动参数：main.mjs --no-sandbox（pid ${child.pid}）`,
    '',
    '=== app.jsonl 本次新增关键行 ===',
    JSON.stringify(seen, null, 2),
    '',
    '=== renderer.jsonl 本次新增行（含 Uncaught 判定）===',
    ...newRendererLines.map((r) => `  [${r.level}] ${r.message}（${r.source}:${r.line}）`),
    `Uncaught 行数：${uncaught.length}`,
    '',
    `bridge-injected：${injectedOk ? '有' : '无'}`,
    `bridge-inject-failed：${failedAbsent ? '无' : '有（回归复现！）'}`,
    `panel-load-failed：${noPanelFail ? '无' : '有'}`,
    `renderer 无 Uncaught：${noUncaught ? '是' : '否'}`,
    '',
    '（附：render-process-gone 为本机已知 GPU 环境问题——三次对照实验证明与 userData 分层无关，',
    ' 主进程 core-ready 后注入体已执行完毕；此处只记录不判负。若 injection 本身失败才会判负。）',
  ].join('\n')
  const rel = evidence('stage32-01-smoke.txt', txt)
  const jsonRel = jsonEvidence('stage32-01-smoke.json', { at: new Date().toISOString(), seen, uncaught, ok })
  record('①', '真实 electron 冒烟：bridge-injected 且 renderer 无 Uncaught（TDZ 回归的运行时保险）', ok,
    `bridge-injected=${injectedOk ? 'OK' : 'FAIL'} inject-failed=${failedAbsent ? '无' : '有'} panel-load=${noPanelFail ? 'OK' : 'FAIL'} renderer 无 Uncaught=${noUncaught ? 'OK' : 'FAIL'}`,
    [rel, jsonRel])
  return seen
})

function existsSyncSafe(p) {
  try { return existsSync(p) } catch { return false }
}

// ---------------------------------------------------------------------------
// ② 版本单一来源（四方一致 + 无第二处字面量）
// ---------------------------------------------------------------------------

await step('②', '版本单一来源：APP_VERSION 表达式求值 == package.json == TIMER_VERSION == plugin.json', async () => {
  const main = readFileSync(MAIN_PATH, 'utf8')
  const m = main.match(/^const APP_VERSION = (.+)$/m)
  const checks = {}
  let appVersion = null
  if (m) {
    const evaluate = new Function('readFileSync', 'join', 'ROOT', `return (${m[1]})`)
    appVersion = evaluate(readFileSync, join, PROJECT_ROOT)
  }
  const pkg = JSON.parse(readFileSync(join(PROJECT_ROOT, 'package.json'), 'utf8'))
  const manifest = JSON.parse(readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'research-timer', 'plugin.json'), 'utf8'))
  checks['main.mjs APP_VERSION 表达式存在'] = !!m
  checks['APP_VERSION == package.json.version'] = appVersion === pkg.version
  checks['TIMER_VERSION == package.json.version'] = TIMER_VERSION === pkg.version
  checks['plugin.json.version == package.json.version'] = manifest.version === pkg.version
  const withoutVersionLine = main.replace(/^const APP_VERSION = .+$/m, '')
  const literals = withoutVersionLine.match(/['"]\d+\.\d+\.\d+[^'"]*['"]/g) || []
  checks['main.mjs 无第二处版本字面量'] = literals.length === 0
  checks['tray 菜单版本取自 APP_VERSION'] = /label: '版本 ' \+ APP_VERSION/.test(main)

  const lines = Object.entries(checks).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`)
  lines.push('', `package.json.version = ${pkg.version}`, `main.mjs APP_VERSION 求值 = ${appVersion}`, `TIMER_VERSION = ${TIMER_VERSION}`, `plugin.json.version = ${manifest.version}`)
  const rel = evidence('stage32-02-version.txt', lines.join('\n') + '\n')
  const jsonRel = jsonEvidence('stage32-02-version.json', { at: new Date().toISOString(), checks, versions: { pkg: pkg.version, appVersion, timer: TIMER_VERSION, manifest: manifest.version } })
  const ok = Object.values(checks).every(Boolean)
  record('②', '版本单一来源：APP_VERSION 表达式求值 == package.json == TIMER_VERSION == plugin.json', ok,
    `版本=${pkg.version}；${Object.values(checks).filter(Boolean).length}/${Object.keys(checks).length} 项在位`, [rel, jsonRel])
})

// ---------------------------------------------------------------------------
// ③ 全量测试（≥338：334 + ui-bridge 回归 4 条）
// ---------------------------------------------------------------------------

await step('③', 'node --test 全量（≥338 条全绿，含注入回归 4 条）', async () => {
  const files = readdirSyncSafe().filter((f) => f.endsWith('.test.mjs')).map((f) => join('tests', f))
  const r = runNode(['--test', '--test-concurrency=1', ...files])
  const out = r.stdout + r.stderr
  const passM = out.match(/# pass (\d+)/)
  const failM = out.match(/# fail (\d+)/)
  const pass = passM ? Number(passM[1]) : 0
  const fail = failM ? Number(failM[1]) : -1
  const rel = evidence('stage32-03-tests.txt', out)
  const jsonRel = jsonEvidence('stage32-03-tests.json', { at: new Date().toISOString(), pass, fail })
  record('③', 'node --test 全量（≥338 条全绿，含注入回归 4 条）', fail === 0 && pass >= 338, `${pass}/${pass + fail} 通过，失败 ${fail}`, [rel, jsonRel])
})

function readdirSyncSafe() {
  try { return readdirSync(join(PROJECT_ROOT, 'tests')) } catch { return [] }
}

// ---------------------------------------------------------------------------
// ④ 隔离复核：verify（stage31 基线）+ baseline 留档（stage32）
// ---------------------------------------------------------------------------

await step('④', '隔离复核：probe-isolation verify（stage31 基线）+ stage32 基线留档', async () => {
  const v = runNode([join('tools', 'probe-isolation.mjs'), 'verify', '--tag', 'stage31'])
  const vTxt = v.stdout + v.stderr
  const vOk = v.status === 0
  const relV = evidence('stage32-04-iso-verify.txt', vTxt)
  const b = runNode([join('tools', 'probe-isolation.mjs'), 'baseline', '--tag', 'stage32'])
  const bTxt = b.stdout + b.stderr
  const bOk = b.status === 0
  const relB = evidence('stage32-05-iso-baseline.txt', bTxt)
  record('④', '隔离复核：probe-isolation verify（stage31 基线）+ stage32 基线留档', vOk && bOk,
    `verify exit=${v.status}；baseline exit=${b.status}`, [relV, relB])
})

// ---------------------------------------------------------------------------
// 汇总
// ---------------------------------------------------------------------------

const allPass = RESULTS.every((r) => r.ok)
const summary = {
  stage: '3.2',
  startedAt: new Date().toISOString(),
  finishedAt: new Date().toISOString(),
  results: RESULTS,
  allPass,
}
jsonEvidence('stage32-summary.json', summary)
process.stdout.write(`\n汇总：${RESULTS.filter((r) => r.ok).length}/${RESULTS.length} 通过 -> data/logs/stage32-summary.json\n`)
process.exit(allPass ? 0 : 1)
