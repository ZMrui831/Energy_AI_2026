// tools/accept-s32-privacy.mjs —— S32·3 隐私仪表盘验收（≥8 项）。
// 单行复跑：node tools\accept-s32-privacy.mjs
// 证据：data\logs\s32-privacy-accept.json
//
// 覆盖：原图状态统计(ready/deleted/missing/broken 真实查询) / 保留矩阵 / 最近 10 条已删可回指(sha256 前缀) /
//      data 占用 / 一键导出 / 路径脱敏(项目:/) / 只读不改状态 / 数字来自真实查询(增删即变) / 导出无盘符路径。
import './_accept-isolate.mjs' // S67·3-A：先于产品模块求值，把 data/logs 指到临时目录
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createStore } from '../packages/core/src/db.mjs'
import { attachEvidence } from '../packages/core/src/lifecycle/publish.mjs'
import { buildPrivacyDashboard, renderPrivacyMarkdown, exportPrivacy, DATA_LEVELS } from '../packages/plugins/coach/privacy.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's32-privacy')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(WORK, { recursive: true })
const ART = join(WORK, 'artifacts')

try {
  const store = await createStore({ driver: 'sqlite', dbPath: join(WORK, 'orb.sqlite'), dataDir: WORK })
  store.initMigrations()
  const sha = (c) => c.repeat(64)
  const iso = () => new Date().toISOString()
  const exp = () => new Date(Date.now() + 3600000).toISOString()
  const readyFile = join(WORK, 'ready.png')
  writeFileSync(readyFile, 'x')

  store.insertRawFrame({ id: 'rf-ready', file_path: readyFile, sha256: sha('a'), sensitivity: 'normal', created_at: iso(), expires_at: exp() })
  store.insertRawFrame({ id: 'rf-missing', file_path: join(WORK, 'gone.png'), sha256: sha('b'), sensitivity: 'normal', created_at: iso(), expires_at: exp() }) // ready 但文件不存在 → missing
  store.insertRawFrame({ id: 'rf-del', file_path: join(WORK, 'del.png'), sha256: sha('c'), sensitivity: 'normal', created_at: iso(), expires_at: exp() })
  store.setRawFrameStatus('rf-del', 'deleted')
  store.insertRawFrame({ id: 'rf-err', file_path: join(WORK, 'err.png'), sha256: sha('d'), sensitivity: 'normal', created_at: iso(), expires_at: exp() })
  store.setRawFrameStatus('rf-err', 'error', 'boom')

  store._db.prepare("INSERT INTO claim(id,kind,text,evidence_mode,status,created_at) VALUES('c1','manual','x','direct','draft',?)").run(iso())
  attachEvidence(store, { claimId: 'c1', evidenceId: 'rf-del', layer: 'raw_frame', relation: 'direct', sha256: sha('c') })
  attachEvidence(store, { claimId: 'c1', evidenceId: 'rf-missing', layer: 'raw_frame', relation: 'direct', sha256: sha('b') })
  attachEvidence(store, { claimId: 'c1', evidenceId: 'rf-ready', layer: 'raw_frame', relation: 'direct', sha256: sha('a') })

  const before = store._db.prepare('SELECT status, COUNT(*) n FROM raw_frame GROUP BY status ORDER BY status').all()
  const p = buildPrivacyDashboard({ store })
  const after = store._db.prepare('SELECT status, COUNT(*) n FROM raw_frame GROUP BY status ORDER BY status').all()

  // R1：状态统计正确（ready/deleted/missing/broken 各 1，total 4）
  const s = p.statusStats
  check('R1', s.ready === 1 && s.deleted === 1 && s.missing === 1 && s.broken === 1 && s.total === 4,
    `ready=${s.ready} deleted=${s.deleted} missing=${s.missing} broken=${s.broken} total=${s.total}`, { s })

  // R2：保留矩阵（6h / 20min / 永不落盘 / 7 天 / 90 天）
  const rmap = Object.fromEntries(p.retention.map((r) => [r.key, r.value]))
  check('R2', rmap.rawFrameNormalHours === '6 小时' && rmap.rawFrameLearningMinutes === '20 分钟' && rmap.rawFrameSensitive === '永不落盘' && rmap.observationDays === '7 天' && rmap.summaryDays === '90 天',
    JSON.stringify(rmap), { retention: rmap })

  // R3：最近 10 条已删/缺失可回指（sha256 前缀 12 + claimId）
  const refs = p.deletedRefs
  const hasPrefix = refs.length > 0 && refs.every((d) => d.sha256Prefix && d.sha256Prefix.length === 12 && d.claimId)
  const hasBoth = refs.some((d) => d.status === 'deleted') && refs.some((d) => d.status === 'missing')
  check('R3', refs.length <= 10 && hasPrefix && hasBoth,
    `refs=${JSON.stringify(refs)}`, { refs })

  // R4：data/ 各级占用（覆盖所有层级，占用为真实扫描）
  const usageOk = p.usage.length === DATA_LEVELS.length && p.usage.every((u) => Number.isFinite(u.bytes) && typeof u.human === 'string' && u.human.length > 0) && p.usage.some((u) => u.files > 0)
  check('R4', usageOk, `levels=${p.usage.length} sample=${JSON.stringify(p.usage.find((u) => u.files > 0) || p.usage[0])}`, { usage: p.usage.map((u) => ({ rel: u.rel, files: u.files, human: u.human })) })

  // R7：只读（前后 raw_frame 状态不变）
  check('R7', JSON.stringify(before) === JSON.stringify(after), `before=${JSON.stringify(before)} after=${JSON.stringify(after)}`, {})

  // R5：一键导出 privacy-YYYYMMDD.md
  const ex = exportPrivacy({ store, outDir: ART })
  const exName = ex.path.split(/[\\/]/).pop()
  check('R5', existsSync(ex.path) && /^privacy-\d{8}\.md$/.test(exName), `file=${exName}`, { path: ex.path })

  // R6：路径脱敏（含 项目:/，不含项目根绝对路径）
  const md = readFileSync(ex.path, 'utf8')
  check('R6', md.includes('项目:/') && !md.includes(PROJECT_ROOT) && !md.includes('D:'),
    `has项目:/=${md.includes('项目:/')} 含根=${md.includes(PROJECT_ROOT)} 含盘符=${md.includes('D:')}`, { head: md.slice(0, 140) })

  // R9：导出文件无任何盘符绝对路径
  check('R9', !/[A-Za-z]:\\/.test(md), `drivePath=${/[A-Za-z]:\\/.test(md)}`, {})

  // R8：数字来自真实查询（新增一张 deleted → deleted 计数 +1，其余不变）
  store.insertRawFrame({ id: 'rf-del2', file_path: join(WORK, 'del2.png'), sha256: sha('e'), sensitivity: 'normal', created_at: iso(), expires_at: exp() })
  store.setRawFrameStatus('rf-del2', 'deleted')
  const p2 = buildPrivacyDashboard({ store })
  check('R8', p2.statusStats.deleted === s.deleted + 1 && p2.statusStats.total === s.total + 1 && p2.statusStats.ready === s.ready,
    `deleted ${s.deleted}→${p2.statusStats.deleted} total ${s.total}→${p2.statusStats.total}`, { before: s, after: p2.statusStats })

  store.close && store.close()
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(join(PROJECT_ROOT, 'data', 'logs', 's32-privacy-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s32-privacy: total=${items.length} pass=${pass} fail=${items.length - pass}`)
console.log('  # 证据 -> data/logs/s32-privacy-accept.json')
process.exit(pass === items.length ? 0 : 1)
