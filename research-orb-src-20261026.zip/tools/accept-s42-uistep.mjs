// tools/accept-s42-uistep.mjs —— S42·B1 computer use（方案 B）验收（≥14 项）。自包含实测。
// 单行复跑：node tools\accept-s42-uistep.mjs
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync, mkdtempSync, readdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'
import { setTimeout as wait } from 'node:timers/promises'

process.env.ORB_LOG_DIR = join(tmpdir(), 's42-ui-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's42-ui-data-' + Date.now())
const { dataPath, PROJECT_ROOT } = await import('../packages/core/src/safefs.mjs')
const { uiStep, checkWhitelist, uiList, loadWhitelist } = await import('../tools/ui-step/ui-step.mjs')
const { uia } = await import('../tools/ui-step/uia.mjs')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const auditRows = () => {
  const f = join(process.env.ORB_LOG_DIR, 'ui-step.jsonl')
  try { return readFileSync(f, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)) } catch { return [] }
}

try {
  // 播种白名单到隔离数据树（与真实 data/ui-whitelist.json 同契约）
  const realWl = JSON.parse(readFileSync(join(PROJECT_ROOT, 'data', 'ui-whitelist.json'), 'utf8'))
  mkdirSync(dataPath(), { recursive: true })
  writeFileSync(dataPath('ui-whitelist.json'), JSON.stringify(realWl, null, 2), 'utf8')

  // U-1 桥可用：窗口枚举 ≥10（真实桌面）
  const lw = uiList()
  check('U-1 UIA 桥可用（窗口枚举 ≥10）', lw.ok === true && lw.count >= 10, `count=${lw.count}`, {})

  // U-2 白名单契约
  const wl = loadWhitelist()
  check('U-2 白名单契约', (wl.windows || []).length >= 2 && (wl.denyPatterns || []).length >= 7 && (wl.allowOnDialog || []).length >= 3,
    `windows=${wl.windows.length} deny=${wl.denyPatterns.length}`, {})

  // U-3 ①前台一致性（注入 fake uia → E_UI_NOT_FOREGROUND 零截图）
  const fake = (cmd) => (cmd === 'foreground' ? { ok: true, isForeground: false, fgPid: 1, wantPid: 2 } : { ok: true })
  const r3 = uiStep({ action: 'invoke', windowRegex: 'Notepad', controlName: '文件', confirmGranted: true }, { _uia: fake })
  check('U-3 ①前台不一致拒', r3.ok === false && r3.code === 'E_UI_NOT_FOREGROUND' && r3.audit.shots.length === 0,
    `code=${r3.code} shots=${r3.audit.shots.length}`, {})

  // U-4 ③白名单外窗口拒（ChatGPT，真实）
  const r4 = uiStep({ action: 'invoke', windowRegex: 'ChatGPT', controlName: '任意控件', confirmGranted: true })
  check('U-4 ③白名单外窗口拒（ChatGPT 实测零动作）', r4.ok === false && r4.code === 'E_UI_NOT_WHITELISTED' && r4.audit.result === 'refused',
    `code=${r4.code}`, {})

  // U-5 ③拒绝模式：保存 → E_UI_DENIED_PATTERN（白名单内窗口）
  const r5 = checkWhitelist({ windowRegex: '记事本', controlName: '保存(S)', wl })
  check('U-5 ③拒绝模式（保存 一律拒）', r5.ok === false && r5.code === 'E_UI_DENIED_PATTERN', `code=${r5.code}`, {})

  // U-6 ⑤未确认拒 + 确认卡
  const r6 = uiStep({ action: 'invoke', windowRegex: 'Notepad', controlName: '文件' })
  check('U-6 ⑤未确认拒+确认卡', r6.ok === false && r6.code === 'E_UI_NOT_CONFIRMED' && /前台一致性/.test(r6.describe || ''),
    `code=${r6.code}`, {})

  // U-7/U-8/U-9/U-10：真实 GUI 六步（安全顺序）。带文件启动记事本 → 标题含唯一文件名 → 精确定位，用户标签零风险。
  const demoFile = dataPath('tmp', `ui-demo-${Date.now()}.txt`)
  mkdirSync(dataPath('tmp'), { recursive: true })
  writeFileSync(demoFile, '', 'utf8')
  spawnSync('cmd', ['/c', 'start', 'notepad', demoFile], { shell: false, detached: true, stdio: 'ignore' })
  await wait(3000)
  const NP = {}

  // 前台重试：Windows 安全中心等系统窗口偶发抢占前台 → SetActive 重试最多 3 次
  const fgRetry = (fn, tries = 3) => (async () => {
    for (let i = 0; i < tries; i++) {
      const r = await fn()
      if (!(r && r.code === 'E_UI_NOT_FOREGROUND')) return r
      await wait(1500)
    }
    return null
  })()

  // U-7 ①菜单步：invoke 文件 → executed（弹出即成功，不选项）→ Esc 收起
  const r7 = await fgRetry(() => uiStep({ action: 'invoke', windowRegex: 'Notepad', controlName: '文件', confirmGranted: true })) || { ok: false, code: 'E_UI_NOT_FOREGROUND', audit: { shots: [], result: 'refused' } }
  check('U-7 ①菜单步 executed（真实窗口）', r7.ok === true && r7.audit.result === 'executed' && (r7.shots || []).length >= 2,
    `pattern=${r7.pattern || '-'} shots=${(r7.shots || []).length} code=${r7.code || '-'} reason=${(r7.reason || '').slice(0, 60)}`, {})
  if (r7.ok) { uiStep({ action: 'sendKeys', windowRegex: 'ui-demo', text: '{Esc}', confirmGranted: true }); await wait(600) }

  // U-8 ②写入步：Ctrl+N 新窗口（脱离会话恢复标签，保护用户内容）→ 键盘输入 → getValue 回读
  // S66 对账修复（原脚本两处回归）：① 漏发 Ctrl+N——SHOT-UISTEP.md 记载的六步顺序第一步
  // （"Ctrl+N 新窗口 → 输入 → 关标签 → 不保存"）在脚本里不存在，②组瞄准的「无标题」窗口从未被创建；
  // ② windowRegex「无标题」不在白名单（checkWhitelist 按正则串匹配，非实时窗口标题），必然
  // E_UI_NOT_WHITELISTED。修复：先 {Ctrl}n 建新标签（标题「无标题 - Notepad」），再以白名单内的
  // 「Notepad」为目标；Win11 记事本的保存对话框是主窗口的子弹出层（按钮 保存/不保存/取消 在
  // 主窗口控件树 depth≤2），invoke 沿窗口树可达，无需顶层枚举。
  const SUMMARY = 'S42A1一键成结论：虚拟电厂收益机制三类，聚合商与电网两级结算。'
  const rNP = await fgRetry(() => uiStep({ action: 'sendKeys', windowRegex: 'ui-demo', text: '{Ctrl}n', confirmGranted: true })) || { ok: false }
  await wait(1200)
  uiStep({ action: 'invoke', windowRegex: 'Notepad', controlName: '文本编辑器', confirmGranted: true })
  await wait(500)
  const r8 = await fgRetry(() => uiStep({ action: 'sendKeys', windowRegex: 'Notepad', text: SUMMARY, confirmGranted: true })) || { ok: false }
  const g8 = await fgRetry(() => uiStep({ action: 'getValue', windowRegex: 'Notepad', controlName: '文本编辑器', confirmGranted: true })) || { ok: false }
  check('U-8 ②写入步（真实键盘输入+回读一致）', r8.ok === true && g8.ok === true && String(g8.value || '').includes('一键成结论'),
    `newTab=${rNP.ok} 回读=${String(g8.value || '').slice(0, 20)}…`, {})

  // U-9 ②关标签 → 保存对话框（主窗口子弹出层）→ 点取消（对话框仍开）→ 点不保存（丢弃本验收文本）
  uiStep({ action: 'sendKeys', windowRegex: 'Notepad', text: '{Ctrl}w', confirmGranted: true })
  await wait(1500)
  const dlgProbe = await fgRetry(() => uiStep({ action: 'invoke', windowRegex: 'Notepad', controlName: '取消', confirmGranted: true, dialog: true })) || { ok: false, code: 'E_UI' }
  const dlgStayed = dlgProbe.ok === true
  check('U-9 ②对话框点取消 executed', dlgStayed, `code=${dlgProbe.code || 'ok'}`, {})
  // 不保存：丢弃本验收文本（对话框可能已被取消关闭 → 若控件不存在则用 Ctrl+W→不保存 二段式）
  let discarded = false
  const d1 = await fgRetry(() => uiStep({ action: 'invoke', windowRegex: 'Notepad', controlName: '不保存', confirmGranted: true, dialog: true })) || { ok: false }
  if (d1.ok) discarded = true
  else {
    uiStep({ action: 'sendKeys', windowRegex: 'Notepad', text: '{Ctrl}w', confirmGranted: true })
    await wait(1200)
    const d2 = await fgRetry(() => uiStep({ action: 'invoke', windowRegex: 'Notepad', controlName: '不保存', confirmGranted: true, dialog: true })) || { ok: false }
    discarded = d2.ok
  }
  check('U-10 ②不保存（丢弃验收文本，用户文件零影响）', discarded, `discarded=${discarded}`, {})

  // U-11 ②地址栏步：setText+Enter（资源管理器，真实执行）
  spawnSync('cmd', ['/c', 'start', 'explorer.exe'], { shell: false, detached: true, stdio: 'ignore' })
  await wait(3000)
  const r11a = await fgRetry(() => uiStep({ action: 'setText', windowRegex: '文件资源管理器', controlName: '地址栏', text: join(PROJECT_ROOT, 'data', 'artifacts'), confirmGranted: true }), 2) || { ok: false }
  const r11b = uiStep({ action: 'sendKeys', windowRegex: '文件资源管理器', text: '{Enter}', confirmGranted: true })
  check('U-11 ②地址栏选中+跳转 executed', r11a.ok === true && r11b.ok === true,
    `setText=${r11a.ok} enter=${r11b.ok}`, {})

  // U-12 ⑥审计字段齐
  const audits = auditRows()
  const fieldOk = audits.length > 0 && audits.every((r) => 'ts' in r && 'window' in r && 'control' in r && 'action' in r && 'result' in r && 'errorCode' in r && Array.isArray(r.shots) && 'durationMs' in r)
  check('U-12 ⑥审计字段齐（每步一行）', fieldOk && audits.length >= 6, `rows=${audits.length}`, {})

  // U-13 ④超时注入 → E_UI_TIMEOUT 中止不重试（前台放行，invoke 超时）
  const fakeTimeout = (cmd) => (cmd === 'foreground' ? { ok: true, isForeground: true } : { ok: false, code: 'E_UI_TIMEOUT', reason: 'UIA 调用超时（>10000ms）：中止不重试' })
  const r13 = uiStep({ action: 'invoke', windowRegex: 'Notepad', controlName: '文件', confirmGranted: true }, { _uia: fakeTimeout })
  check('U-13 ④超时中止不重试', r13.ok === false && r13.code === 'E_UI_TIMEOUT' && r13.audit.result === 'timeout',
    `code=${r13.code}`, {})

  // U-14 截图落盘
  const shotsDir = dataPath('screens', 'ui-step')
  let pngCount = 0
  if (existsSync(shotsDir)) pngCount = readdirSync(shotsDir).filter((f) => f.endsWith('.png')).length
  check('U-14 截图落盘（before/after 成对）', pngCount >= 4, `png=${pngCount}`, {})

  // U-15 文档 + SHOT 存在
  check('U-15 COMPUTER-USE-B + SHOT-UISTEP 存在', existsSync(join(PROJECT_ROOT, 'docs', 'COMPUTER-USE-B.md')) && existsSync(join(PROJECT_ROOT, 'docs', 'SHOT-UISTEP.md')),
    `docs ok`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e) + ' @ ' + String(e && e.stack ? e.stack.split('\n')[1] : '').slice(0, 120))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's42-uistep-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s42-uistep: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
