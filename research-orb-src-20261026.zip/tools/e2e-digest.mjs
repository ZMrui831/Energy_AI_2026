// tools/e2e-digest.mjs —— S56·六 一键导出本次会话审计摘要（真实端到端配套）
//
// 作用：给 P2 真实端到端的执行者一条命令 —— 把这次会话的**真实数字**从审计里汇总出来，
// 不需要手抄卡片数字。全部读文件（审计 = 唯一真相源），不读内存、不估算。
//
// 用法：
//   node tools\e2e-digest.mjs                      # 今天 + 最近一次会话
//   node tools\e2e-digest.mjs --day 20261024       # 指定日期
//   node tools\e2e-digest.mjs --session sess-xxx   # 指定会话
//
// 产出：data\reports\e2e-digest-<ts>.md（同时打印到 stdout）

import { existsSync, readFileSync, readdirSync, statSync, mkdirSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = dirname(fileURLToPath(import.meta.url))
const ROOT = join(__dirname, '..')
const DATA = join(ROOT, 'data')
const LOGS = join(DATA, 'logs')

const argv = process.argv.slice(2)
const arg = (name, def = null) => {
  const i = argv.indexOf(name)
  return i >= 0 && argv[i + 1] ? argv[i + 1] : def
}
const dayArg = arg('--day')
const now = new Date()
const dayStamp = dayArg || `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`
const d0 = dayArg
  ? new Date(Number(dayArg.slice(0, 4)), Number(dayArg.slice(4, 6)) - 1, Number(dayArg.slice(6, 8))).getTime()
  : (() => { const x = new Date(); x.setHours(0, 0, 0, 0); return x.getTime() })()
const d1 = d0 + 86400000

const readJsonl = (path) => {
  if (!existsSync(path)) return []
  const out = []
  for (const line of readFileSync(path, 'utf8').split('\n')) {
    const s = line.trim()
    if (!s) continue
    try { out.push(JSON.parse(s)) } catch { /* 半行跳过 */ }
  }
  return out
}

// ---------- 感知审计 ----------
const perc = readJsonl(join(LOGS, 'perception.jsonl')).filter((r) => {
  const t = typeof r.ts === 'number' ? r.ts : Date.parse(r.ts || '')
  return Number.isFinite(t) && t >= d0 && t < d1
})
const count = (kind) => perc.filter((r) => r.kind === kind).length
let sentN = 0, bytesBefore = 0, bytesAfter = 0
for (const r of perc) {
  if (r.kind !== 'sent-to-model') continue
  sentN += 1
  bytesBefore += Number(r.bytesBefore) || 0
  bytesAfter += Number(r.bytesAfter) || 0
}

// ---------- 清理审计 ----------
const life = readJsonl(join(LOGS, 'lifecycle.jsonl')).filter((r) => {
  const t = typeof r.ts === 'number' ? r.ts : Date.parse(r.ts || '')
  return Number.isFinite(t) && t >= d0 && t < d1
})
const deleted = life.filter((r) => r.kind === 'frame-deleted').length
const trashExpired = life.filter((r) => r.kind === 'trash-expired').length

// ---------- 轨迹片段 ----------
let segments = 0
const segFile = join(DATA, 'timeline', `segments-${dayStamp}.jsonl`)
if (existsSync(segFile)) {
  const ids = new Set()
  for (const r of readJsonl(segFile)) if (r && r.id) ids.add(r.id)
  segments = ids.size
}

// ---------- 会话（默认最近一次） ----------
const sessionsDir = join(DATA, 'sessions')
let sessFile = null
const sessArg = arg('--session')
if (sessArg) {
  const p = join(sessionsDir, `${sessArg}.jsonl`)
  if (existsSync(p)) sessFile = p
} else if (existsSync(sessionsDir)) {
  const files = readdirSync(sessionsDir).filter((f) => f.endsWith('.jsonl'))
    .map((f) => ({ f: join(sessionsDir, f), m: statSync(join(sessionsDir, f)).mtimeMs }))
    .sort((a, b) => b.m - a.m)
  if (files[0]) sessFile = files[0].f
}
let sessInfo = { id: null, turns: 0, bytes: 0, mtime: null }
if (sessFile) {
  const rows = readJsonl(sessFile)
  const turns = rows.filter((r) => r.type === 'user' || r.type === 'assistant').length
  const st = statSync(sessFile)
  sessInfo = { id: sessFile.split(/[\\/]/).pop().replace(/\.jsonl$/, ''), turns, bytes: st.size, mtime: new Date(st.mtimeMs).toISOString() }
}

// ---------- 导出（最新 md） ----------
let exportInfo = { file: null, sha256: null, bytes: 0 }
const expDir = join(DATA, 'exports')
if (existsSync(expDir)) {
  const files = readdirSync(expDir).filter((f) => /\.(md|docx)$/i.test(f))
    .map((f) => ({ f: join(expDir, f), m: statSync(join(expDir, f)).mtimeMs }))
    .sort((a, b) => b.m - a.m)
  const md = files.find((x) => x.f.endsWith('.md'))
  if (md) {
    const buf = readFileSync(md.f)
    exportInfo = { file: md.f.split(/[\\/]/).pop(), sha256: createHash('sha256').update(buf).digest('hex').slice(0, 16), bytes: buf.length }
  }
}

// ---------- usage（tokens） ----------
let tokens = 0
const usagePath = join(LOGS, 'usage.jsonl')
if (existsSync(usagePath)) {
  for (const r of readJsonl(usagePath)) {
    const t = typeof r.ts === 'number' ? r.ts : Date.parse(r.ts || '')
    if (Number.isFinite(t) && t >= d0 && t < d1) tokens += Number(r.tokens || r.total_tokens || 0)
  }
}

const mb = (b) => (b / 1048576).toFixed(2)
const md = [
  `# 会话审计摘要 ${dayStamp}`,
  '',
  `> 生成时间：${new Date().toISOString()}（全部数字读自 data/logs 审计与 data/ 文件）`,
  '',
  '| 指标 | 值 | 来源 |',
  '| --- | --- | --- |',
  `| 感知采样（frame-registered） | ${count('frame-registered')} 次 | perception.jsonl |`,
  `| 压缩送模（sent-to-model） | ${sentN} 张 | perception.jsonl |`,
  `| 原图已删（frame-deleted + trash-expired） | ${deleted + trashExpired} 张 | lifecycle.jsonl |`,
  `| 省流量（Σ bytesBefore−bytesAfter） | ${mb(bytesBefore - bytesAfter)} MB（原 ${mb(bytesBefore)} → 送 ${mb(bytesAfter)}） | perception.jsonl |`,
  `| 轨迹片段 | ${segments} 条 | data/timeline/segments-${dayStamp}.jsonl |`,
  `| 会话 | ${sessInfo.id || '（无）'} / ${sessInfo.turns} 轮 / ${sessInfo.bytes} B | data/sessions/ |`,
  `| 最新导出 | ${exportInfo.file || '（无）'}${exportInfo.sha256 ? ` / sha256:${exportInfo.sha256}` : ''} | data/exports/ |`,
  `| tokens | ${tokens} | usage.jsonl |`,
  '',
  '## 原始审计行（各一条示例）',
  '```',
  ...['frame-registered', 'sent-to-model', 'frame-deleted', 'trash-expired']
    .map((k) => { const r = perc.find((x) => x.kind === k) || life.find((x) => x.kind === k); return r ? JSON.stringify(r) : `（今日无 ${k}）` }),
  '```',
].join('\n')

const outDir = join(DATA, 'reports')
try {
  mkdirSync(outDir, { recursive: true })
  const out = join(outDir, `e2e-digest-${dayStamp}-${Date.now()}.md`)
  writeFileSync(out, md, 'utf8')
  console.log('[e2e-digest] 已写入 ' + out)
} catch (e) {
  console.log('[e2e-digest] 写文件失败（仅打印）：' + String((e && e.message) || e))
}
console.log(md)
