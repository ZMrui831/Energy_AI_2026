// tools/accept-s25a-sched.mjs —— S25·2A 调度器验收。
// 单行复跑：node tools\accept-s25a-sched.mjs
// 证据：data\logs\s25a-sched-accept.json。纪律：目录注入 data/tmp；不动 data/perception-config.json。
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createScheduler, SCHED_DEFAULTS } from '../packages/plugins/coach/scheduler.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 240), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's25a-sched')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(WORK, { recursive: true })

function vclock(start = 1000000) { const s = { t: start }; return { now: () => s.t, advance: (ms) => { s.t += ms } } }

try {
  const cfgPath = join(WORK, 'scheduler.json')

  // ① 三触发源各自独立启停
  const c1 = vclock()
  const s1 = createScheduler({ dir: join(WORK, 'a'), now: c1.now, overrides: { intervalMs: 1000, idleDwellMs: 3000, entertainmentCapMin: 45, thresholdCooldownMs: 24 * 3600 * 1000 } })
  s1.start()
  check('S1 interval：未到不触发 / 到点触发一次 / 重新起算', (await s1.tickInterval()) === false && c1.advance(1001) === undefined && (await s1.tickInterval()) === true && (await s1.tickInterval()) === false)
  check('S2 idle-dwell：越线触发一次、持续停留不重复、退回后重新武装', (await s1.feed({ idleMs: 3500 })).length === 1 && (await s1.feed({ idleMs: 5000 })).length === 0 && (await s1.feed({ idleMs: 500 })).length === 0 && (await s1.feed({ idleMs: 3500 })).length === 1)
  check('S3 threshold：超阈触发、24h 冷却内不重复', (await s1.feed({ entertainmentMin: 50 })).length === 1 && c1.advance(3600 * 1000) === undefined && (await s1.feed({ entertainmentMin: 60 })).length === 0)

  // ② 暂停/恢复
  s1.pause()
  c1.advance(2000)
  const pausedTick = await s1.tickInterval()
  const pausedFeed = await s1.feed({ idleMs: 9999, entertainmentMin: 99 })
  check('S4 暂停后三源都不触发（interval/idle/threshold）', pausedTick === false && pausedFeed.length === 0 && s1.paused === true)
  s1.resume()
  check('S5 resume 后恢复触发', (await s1.tickInterval()) === true && s1.paused === false)

  // ③ 单例
  const c1b = vclock()
  let dup = ''
  try {
    const s2 = createScheduler({ dir: join(WORK, 'a'), now: c1b.now, isAlive: (pid) => pid === process.pid })
    s2.start()
    dup = '未拒绝'
  } catch (e) { dup = e.code || String(e) }
  check('S6 单例：存活实例存在时第二实例（构造即拒）E_ALREADY_RUNNING', dup === 'E_ALREADY_RUNNING', dup)

  // ④ 崩溃自恢复（接管 + lastTrigger 保留，不重复触发）
  const c2 = vclock()
  const d2 = join(WORK, 'b')
  const a = createScheduler({ dir: d2, now: c2.now, overrides: { intervalMs: 1000 }, isAlive: () => false })
  a.start()
  c2.advance(500)
  await a.tickInterval() // 未到；lastInterval=启动时刻
  a.stop()               // 模拟崩溃退出
  c2.advance(600)        // 累计 ≥ interval
  const b = createScheduler({ dir: d2, now: c2.now, overrides: { intervalMs: 1000 }, isAlive: () => false })
  b.start()
  check('S7 崩溃自恢复：接管实例沿用 lastInterval，恰触发一次不重复', (await b.tickInterval()) === true && (await b.tickInterval()) === false && b.state().counters.interval === 1)

  // ⑤ 持久化（s1 的 store 在 WORK\a\scheduler.json）
  const st = JSON.parse(readFileSync(join(WORK, 'a', 'scheduler.json'), 'utf8'))
  check('S8 scheduler.json 持久化字段齐（running/paused/pid/lastInterval/lastThreshold/idleArmed/counters）', ['running', 'paused', 'pid', 'lastInterval', 'lastThreshold', 'idleArmed', 'counters'].every((k) => k in st))

  // ⑥ 不动 perception 默认阈值
  const pCfg = join(PROJECT_ROOT, 'data', 'perception-config.json')
  let pOk = true; let pNote = '文件不存在（默认阈值生效，未被创建/修改）'
  if (existsSync(pCfg)) {
    const doc = JSON.parse(readFileSync(pCfg, 'utf8'))
    // 有 thresholds 段时必须与 SCHED_DEFAULTS 无关（调度器参数不得写入此文件）
    pOk = !('intervalMs' in doc) && !('idleDwellMs' in doc) && !('entertainmentCapMin' in doc)
    pNote = '存在且不含调度器参数'
  }
  check('S9 不动 perception：perception-config.json 无调度器参数（阈值默认值不变）', pOk, pNote)
  check('S10 调度器自有默认值齐（interval 30min / dwell 3min / cap 45min / 冷却 24h）', SCHED_DEFAULTS.intervalMs === 30 * 60 * 1000 && SCHED_DEFAULTS.idleDwellMs === 3 * 60 * 1000 && SCHED_DEFAULTS.entertainmentCapMin === 45 && SCHED_DEFAULTS.thresholdCooldownMs === 24 * 3600 * 1000)

  // ⑦ firedLog 可观测
  const fired = s1.firedLog()
  check('S11 触发可观测（firedLog 记录 kind/at）', fired.length >= 2 && fired.every((f) => f.kind && f.at))
} catch (e) {
  check('S0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 240))
} finally {
  rmSync(WORK, { recursive: true, force: true })
}

const pass = items.filter((i) => i.ok).length
const fail = items.length - pass
const out = { tool: 'accept-s25a-sched', at: new Date().toISOString(), total: items.length, pass, fail, items }
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's25a-sched-accept.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # accept-s25a-sched: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 证据 -> data/logs/s25a-sched-accept.json`)
process.exit(fail === 0 ? 0 : 1)
