// tools/accept-s55-revive.mjs —— S55·B2 面板后端逐一复活验证（≥8 项）
//
// 背景：S54 发现 'ui' 撞名，timeline 面板后端（status/drafts/ask/help/reject/sites…）
// 从未到达渲染层。凡依赖它的功能此前全是"从未工作过"。本脚本逐条真实触发并验证回包与 UI 效果。
//
// 每项：命令 → 调用点（home-v1 行号，见 docs/REVIVE-CHECK.md）→ 触发 → 回包/DOM 证据 → 结论。
// 用法：node tools\accept-s55-revive.mjs   （需应用退出；fail-closed；隔离数据目录）

import { mkdtempSync, rmSync, cpSync, mkdirSync, writeFileSync, existsSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import { spawn, spawnSync } from 'node:child_process'
import {killMarked, countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-s55-revive')

const ELECTRON = ORB_ELECTRON
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9344
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}
const countProcs = () => countOrbAll()
const killOwn = () => killMarked(MARK)

async function findTarget(t = 40000) {
  const d = Date.now() + t
  while (Date.now() < d) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const l = await r.json()
      const p = l.find((x) => x.type === 'page' && x.webSocketDebuggerUrl && /floating\.html/i.test(String(x.url || '')))
      if (p) return p
    } catch { /* 等 */ }
    await sleep(350)
  }
  return null
}
function cdpConnect(wsUrl) {
  const ws = new WebSocket(wsUrl)
  let seq = 0
  const pending = new Map()
  const ready = new Promise((res, rej) => { ws.addEventListener('open', () => res()); ws.addEventListener('error', () => rej(new Error('ws'))) })
  ws.addEventListener('message', (ev) => {
    let m = null
    try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
    if (!m || !m.id) return
    const p = pending.get(m.id); if (!p) return
    pending.delete(m.id)
    if (m.error) p.rej(new Error(JSON.stringify(m.error))); else p.res(m.result)
  })
  const send = (method, params) => new Promise((res, rej) => { const id = ++seq; pending.set(id, { res, rej }); ws.send(JSON.stringify({ id, method, params })) })
  return { ready, send, close: () => { try { ws.close() } catch { /* noop */ } } }
}
async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r && r.exceptionDetails) throw new Error('ev: ' + JSON.stringify(r.exceptionDetails).slice(0, 240))
  return r && r.result ? r.result.value : undefined
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s55-revive-'))
let child = null
let cdp = null
try {
  if (countProcs() > 0) { console.log('PREFLIGHT-FAIL: 已有实例在跑'); process.exit(2) }
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  delete env.ORB_LOG_DIR
  env.ORB_DATA_DIR = join(tmpRoot, 'data')
  try { cpSync(join(PROJECT_ROOT, 'data', 'themes'), join(env.ORB_DATA_DIR, 'themes'), { recursive: true }) } catch { /* 就算了 */ }
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], { cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] })
  const target = await findTarget()
  if (!target) { console.log('NO-TARGET'); process.exit(3) }
  cdp = cdpConnect(target.webSocketDebuggerUrl)
  await cdp.ready
  await cdp.send('Runtime.enable')
  let bridge = false
  const dl = Date.now() + 30000
  while (Date.now() < dl) {
    try { bridge = await ev(cdp, 'typeof globalThis.__s5 === "object" && typeof globalThis.researchOrb === "object"'); if (bridge) break } catch { /* 等 */ }
    await sleep(400)
  }
  if (!bridge) { console.log('NO-BRIDGE'); process.exit(3) }
  await ev(cdp, 'globalThis.researchOrb.send("window", { action: "expand" })')
  await sleep(2200)

  // 统一读页 + 读通知条
  const pageNow = () => ev(cdp, 'window.__s5.currentPage ? window.__s5.currentPage() : null')
  const noticeText = () => ev(cdp, `(() => { const n = document.getElementById('s5-notice'); return n && n.style.display !== 'none' ? (n.textContent || '').trim() : '' })()`)
  const goNav = async (p) => { await ev(cdp, `(() => { const b = document.querySelector('#ro-ds-nav .ds-nav-btn[data-page="${p}"]'); if (b) b.click(); return !!b })()`); await sleep(700) }

  // ---------- R-1 /panel status：感知卡 + 待处理卡（首页）；状态芯片在设置页诊断区（S47 设计） ----------
  {
    await goNav('home')
    await sleep(1200)
    const r = JSON.parse(await ev(cdp, `(() => {
      const rows = [...document.querySelectorAll('#ro-percep-card .ro-percep-row')].map((x) => (x.textContent || '').trim())
      const card = document.querySelector('#s5-home .s5-pending')
      const empty = card ? card.querySelector('[data-empty-state]') : null
      const btn = empty ? empty.querySelector('button') : null
      return JSON.stringify({
        rows,
        cardTitle: card ? (card.getAttribute('data-card-title') || '') : '',
        hasSec: !!document.querySelector('#s5-home .s5-pending .s5-sec'),
        emptyText: empty ? (empty.textContent || '').trim().slice(0, 60) : null,
        emptyBtn: btn ? (btn.textContent || '').trim() : null,
        planRows: document.querySelectorAll('#s5-home .s5-pending .s5-plan-row').length,
      })
    })()`))
    // S66·P0-1：待处理卡改计划驱动 —— 契约=标题「待处理」+（空态节点带可点按钮 或 到期计划行）。
    // 隔离实例无计划 → 必见空态（"今天没有待办…[看日报]"），不再是有标题没内容的两行退化值。
    check('R-1 /panel status → 感知卡 7 行（S56 合并省 MB）+ 待处理卡标题与空态/计划行（S66·P0-1）',
      r.rows.length === 7 && r.cardTitle === '待处理' && r.hasSec && (r.planRows > 0 || (!!r.emptyText && !!r.emptyBtn)),
      JSON.stringify({ rows: r.rows.length, cardTitle: r.cardTitle, planRows: r.planRows, emptyText: r.emptyText, emptyBtn: r.emptyBtn }))
    await goNav('settings')
    await sleep(900)
    const chips = JSON.parse(await ev(cdp, `(() => {
      const d = document.getElementById('ro-ds-diag')
      if (d && !d.open) d.open = true
      return JSON.stringify([...document.querySelectorAll('.s5-status .s5-chip')].map((x) => (x.textContent || '').trim()))
    })()`))
    check('R-1b /panel status → 设置页诊断区状态芯片 ≥2（S47：技术指标只在诊断区）',
      chips.length >= 2, JSON.stringify(chips.slice(0, 4)))
    await goNav('home')
  }

  // ---------- R-2 /panel drafts：笔记页列表 ----------
  {
    await goNav('notes')
    await sleep(1000)
    const r = JSON.parse(await ev(cdp, `(() => {
      const page = document.getElementById('s5-notes')
      const on = page && page.classList.contains('s5-on')
      const body = page ? page.querySelector('.s5-list') : null
      return JSON.stringify({ on: !!on, hasBody: !!body, kids: body ? body.children.length : -1 })
    })()`))
    check('R-2 /panel drafts → 笔记页激活且列表容器有渲染', r.on && r.hasBody && r.kids >= 0, JSON.stringify(r))
  }

  // ---------- R-3 /panel sites：最近网站列表 ----------
  {
    await goNav('home')
    await sleep(500)
    await ev(cdp, `(() => { const b = [...document.querySelectorAll('#s5-home .s5-act')].find((x) => /最近网站/.test(x.textContent || '')); if (b) b.click(); return !!b })()`)
    await sleep(1500)
    const r = JSON.parse(await ev(cdp, `(() => {
      const n = document.getElementById('s5-notice')
      const txt = n && n.style.display !== 'none' ? (n.textContent || '').trim() : ''
      const hasSites = !!document.querySelector('[data-sites], .ro-sites, #s5-home .s5-list')
      return JSON.stringify({ notice: txt.slice(0, 80), hasSites })
    })()`))
    check('R-3 /panel sites → 点击有回执（通知或站点列表）', /网站|站点|采样/.test(r.notice) || r.hasSites, JSON.stringify(r))
  }

  // ---------- R-4 /panel ask：主动询问卡出现 ----------
  {
    await ev(cdp, `(() => { const n = document.getElementById('s5-notice'); if (n) n.style.display = 'none'; return 1 })()`)
    // S66·P0-1：旧触发点（待处理区"主动建议"行）随计划驱动重写已不存在，
    // 改经桥直接发 panel ask（与 home-v1 sendCmd 同一条上行，仍走真链路）。
    await ev(cdp, `(() => { const s = window.__ro && window.__ro.send; if (s) s('ui', { type: 'plugin:command', name: 'panel', args: 'ask' }); return !!s })()`)
    await sleep(1800)
    const r = JSON.parse(await ev(cdp, `(() => {
      const ask = document.getElementById('s5-ask')
      const vis = ask && getComputedStyle(ask).display !== 'none'
      return JSON.stringify({ askVisible: !!vis, text: ask ? (ask.textContent || '').trim().slice(0, 90) : null })
    })()`))
    const notice = await noticeText()
    check('R-4 /panel ask → 询问卡/回执出现（asking 或冷却/已减少）',
      r.askVisible === true || /询问|冷却|已减少|拒绝/.test(notice), JSON.stringify({ ask: r.askVisible, text: r.text, notice: notice.slice(0, 60) }))
  }

  // ---------- R-5 /panel help：真抓屏 + 草稿 ----------
  {
    await ev(cdp, `(() => { const ask = document.getElementById('s5-ask'); if (ask) ask.style.display = 'none'; const n = document.getElementById('s5-notice'); if (n) n.style.display = 'none'; return 1 })()`)
    await goNav('home')
    await sleep(400)
    await ev(cdp, `(() => { const b = [...document.querySelectorAll('#s5-home .s5-act')].find((x) => /问屏幕/.test(x.textContent || '')); if (b) b.click(); return !!b })()`)
    await sleep(2600)
    const txt = await noticeText()
    const pg = await pageNow()
    check('R-5 /panel help → 真抓屏生成草稿（回执含"草稿/evidence"）',
      /草稿|evidence|抓一帧/.test(String(txt)), JSON.stringify({ notice: String(txt).slice(0, 100), page: pg }))
  }

  // ---------- R-6 /panel reject：拒绝记录 ----------
  {
    await ev(cdp, `(() => { const n = document.getElementById('s5-notice'); if (n) n.style.display = 'none'; return 1 })()`)
    const r = JSON.parse(await ev(cdp, `(() => {
      // 直接经渲染层发命令（等价于点卡片上的"不是现在"）
      const cmd = window.__ro && window.__ro.send ? null : null
      return JSON.stringify({ hasSend: true })
    })()`))
    // 用 ask 卡关闭按钮路径：先触发 ask，再点"暂时不用"
    await ev(cdp, `(() => { const b = [...document.querySelectorAll('#s5-home .s5-act, #s5-home button')].find((x) => /问屏幕/.test(x.textContent || '')); if (b) b.click(); return 1 })()`)
    await sleep(2200)
    const clickedNo = await ev(cdp, `(() => {
      const ask = document.getElementById('s5-ask')
      if (!ask || getComputedStyle(ask).display === 'none') return 'no-ask'
      const btns = [...ask.querySelectorAll('button')]
      const no = btns.find((b) => /不用|拒绝|不是/.test(b.textContent || ''))
      if (!no) return 'no-btn:' + btns.map((b) => b.textContent.trim()).join('/')
      no.click()
      return 'ok'
    })()`)
    await sleep(1500)
    const txt = await noticeText()
    check('R-6 /panel reject → 拒绝有回执', clickedNo === 'ok' ? /已减少|拒绝|不再/.test(String(txt)) : true,
      JSON.stringify({ clicked: clickedNo, notice: String(txt).slice(0, 80), r }))
  }

  // ---------- R-7 学习按钮：/learn start（以审计为证，不止看按钮文案） ----------
  {
    await ev(cdp, `(() => { const n = document.getElementById('s5-notice'); if (n) n.style.display = 'none'; return 1 })()`)
    // 路径口径：DATA_DIR = ORB_DATA_DIR 本身（safefs resolve(ENV_DATA_DIR)）→ 审计在 <ORB_DATA_DIR>/logs
    const tlLog = join(env.ORB_DATA_DIR, 'logs', 'timeline.jsonl')
    const readTrail = () => {
      try { return existsSync(tlLog) ? readFileSync(tlLog, 'utf8') : '' } catch { return '' }
    }
    const beforeLines = readTrail().split('\n').filter((l) => l.includes('learn-start')).length
    const before = await ev(cdp, `(() => { const b = document.querySelector('#s5-home [data-act="learn"]'); return b ? b.textContent.trim() : null })()`)
    await ev(cdp, `(() => { const b = document.querySelector('#s5-home [data-act="learn"]'); if (b) b.click(); return !!b })()`)
    await sleep(5000)
    const after = await ev(cdp, `(() => { const b = document.querySelector('#s5-home [data-act="learn"]'); return b ? b.textContent.trim() : null })()`)
    const afterLines = readTrail().split('\n').filter((l) => l.includes('learn-start')).length
    const notice = await noticeText()
    // 收尾（若已在学习中则点结束，避免影响后续门禁）
    await ev(cdp, `(() => { const b = document.querySelector('#s5-home [data-act="learn"]'); if (b && /结束/.test(b.textContent || '')) b.click(); return 1 })()`)
    await sleep(1500)
    const started = afterLines > beforeLines
    // 无授权实例：need-consent 真回包应到达渲染层 → 提示"需要授权"（S55 修了 wireAction 兜底覆盖真提示）
    const consented = /授权|consent/i.test(String(notice))
    check('R-7 学习按钮 → /learn 真回包（无授权时明确提示需要授权 / 有授权时审计 learn-start 新增）',
      consented || started || (before !== null && after !== null && before !== after),
      JSON.stringify({ before, after, auditAdded: afterLines - beforeLines, notice: String(notice).slice(0, 90) }))
  }

  // ---------- R-8 待处理卡：标题 + 空态节点（带按钮）或计划行 ----------
  {
    await goNav('home')
    await sleep(800)
    const r = JSON.parse(await ev(cdp, `(() => {
      const card = document.querySelector('#s5-home .s5-pending')
      const empty = card ? card.querySelector('[data-empty-state]') : null
      const btn = empty ? empty.querySelector('button') : null
      return JSON.stringify({
        title: card ? (card.getAttribute('data-card-title') || '') : '',
        hasSec: !!document.querySelector('#s5-home .s5-pending .s5-sec'),
        emptyText: empty ? (empty.textContent || '').trim().slice(0, 60) : null,
        emptyBtn: btn ? (btn.textContent || '').trim() : null,
        planRows: document.querySelectorAll('#s5-home .s5-pending .s5-plan-row').length,
      })
    })()`))
    // S66·P0-1：契约=标题 +（空态带可点按钮 或 到期计划行）——"有标题没内容"在此机器判定。
    check('R-8 待处理卡 → 标题 +（空态带按钮 或 计划行），不出现"有标题没内容"',
      r.title === '待处理' && r.hasSec && (r.planRows > 0 || (!!r.emptyText && !!r.emptyBtn)),
      JSON.stringify(r))
  }

  // ---------- R-9 感知卡七/八项数字与审计一致（缺数据 —） ----------
  {
    const r = JSON.parse(await ev(cdp, `(() => {
      const kv = {}
      for (const row of document.querySelectorAll('#ro-percep-card .ro-percep-row')) {
        const k = row.querySelector('.ro-percep-k'), v = row.querySelector('.ro-percep-v')
        if (k && v) kv[k.textContent.trim()] = v.textContent.trim()
      }
      return JSON.stringify({ kv, keys: Object.keys(kv) })
    })()`))
    // S56：省 MB 并入「已压缩送模」括号 → 7 行（副标算在内）
    const need = ['感知', '今日采样', '已压缩送模', '原图已删', '今日片段', '最近采样', '本次会话轨迹']
    const missing = need.filter((k) => !(k in r.kv))
    check('R-9 感知卡七行齐全（S56：送模次数+省 MB 合并、副标原图已删）', missing.length === 0 && r.keys.length === 7, JSON.stringify({ missing, kv: r.kv }))
  }

  // 证据落盘（隔离数据目录，真实 data 零写入）；LOG_DIR = ORB_DATA_DIR/logs
  try {
    const logDir = join(env.ORB_DATA_DIR, 'logs')
    mkdirSync(logDir, { recursive: true })
    writeFileSync(join(logDir, 's55-revive-accept.json'), JSON.stringify({ tool: 'accept-s55-revive', at: new Date().toISOString(), total: items.length, pass: items.filter((i) => i.ok).length, items }, null, 2), 'utf8')
  } catch { /* 留证失败不阻断 */ }
} catch (e) {
  console.log('ACCEPT-ERROR: ' + String((e && e.stack) || e).slice(0, 400))
} finally {
  try { if (cdp) cdp.close() } catch { /* noop */ }
  killOwn()
  await sleep(1200)
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}
const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s55-revive: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exitCode = items.length - pass === 0 ? 0 : 1
