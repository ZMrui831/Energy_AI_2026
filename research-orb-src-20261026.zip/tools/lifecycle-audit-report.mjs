#!/usr/bin/env node
// tools/lifecycle-audit-report.mjs
//
// S3 数据生命周期 —— 审计统一只读报告。
// 只读操作：读 data/logs/writes.jsonl 与 data/logs 下各 *.jsonl 的行数/字节，
// 绝不改写任何现有文件。默认输出 JSON 到 stdout；--out <path> 可选落盘
// （相对路径默认落到 logsDir 内；落盘走 safefs 且关闭级联审计，避免给
// writes.jsonl 再添一行噪声）。
//
// 用法：
//   node tools/lifecycle-audit-report.mjs
//   node tools/lifecycle-audit-report.mjs --logs-dir <path> --out <path>

import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs'
import { isAbsolute, join, resolve } from 'node:path'
import { PROJECT_ROOT, safeWrite } from '../packages/core/src/safefs.mjs'

function parseArgs(argv) {
  const args = { logsDir: null, out: null }
  for (let i = 2; i < argv.length; i++) {
    if (argv[i] === '--logs-dir') args.logsDir = argv[++i] ?? null
    else if (argv[i] === '--out') args.out = argv[++i] ?? null
  }
  return args
}

const DRIVE_RE = /^[A-Za-z]:[\\/]/

/** 历史写入记录里的相对路径（不含盘符 X:\、非 UNC、非 POSIX 绝对路径）。 */
function isRelativeRecordPath(p) {
  if (typeof p !== 'string' || p === '') return false
  return !DRIVE_RE.test(p) && !p.startsWith('\\\\') && !p.startsWith('/')
}

function readLines(path) {
  const text = readFileSync(path, 'utf8')
  if (text === '') return []
  const lines = text.split('\n')
  if (lines[lines.length - 1] === '') lines.pop()
  return lines
}

const args = parseArgs(process.argv)
const logsDir = resolve(args.logsDir ?? join(PROJECT_ROOT, 'data', 'logs'))

// ---- 1) writes.jsonl：总行数 + 相对路径记录统计（只读，不改写）
const writesPath = join(logsDir, 'writes.jsonl')
const writes = {
  exists: existsSync(writesPath),
  totalLines: 0,
  unparseableLines: 0,
  relativePathCount: 0,
  absolutePathCount: 0,
  relativeSamples: [], // 历史（最新）6 条相对路径记录，仅展示，不改写
}
if (writes.exists) {
  const lines = readLines(writesPath)
  writes.totalLines = lines.length
  for (const line of lines) {
    let rec = null
    try {
      rec = JSON.parse(line)
    } catch {
      writes.unparseableLines++
      continue
    }
    if (isRelativeRecordPath(rec?.path)) {
      writes.relativePathCount++
      writes.relativeSamples.push({ ts: rec.ts ?? null, path: rec.path })
    } else {
      writes.absolutePathCount++
    }
  }
  writes.relativeSamples = writes.relativeSamples.slice(-6)
}

// ---- 2) data/logs 下各 jsonl：行数与字节（显式清单）
const jsonlFiles = []
if (existsSync(logsDir) && statSync(logsDir).isDirectory()) {
  for (const name of readdirSync(logsDir).filter((n) => n.endsWith('.jsonl')).sort()) {
    const p = join(logsDir, name)
    if (!statSync(p).isFile()) continue
    jsonlFiles.push({ name, lines: readLines(p).length, bytes: statSync(p).size })
  }
}

const report = {
  generatedAt: new Date().toISOString(),
  logsDir,
  note: '只读报告：未改写任何现有文件',
  writesJsonl: writes,
  jsonlFiles,
  totalJsonlFiles: jsonlFiles.length,
  totalJsonlBytes: jsonlFiles.reduce((s, f) => s + f.bytes, 0),
}

const json = JSON.stringify(report, null, 2)
process.stdout.write(json + '\n')

if (args.out) {
  // 相对路径 → 落到 logsDir 内；落盘关闭级联审计（本报告本身是审计产物）
  const outPath = isAbsolute(args.out) ? resolve(args.out) : join(logsDir, args.out)
  const res = safeWrite(outPath, json + '\n', { audit: false })
  process.stdout.write(`[lifecycle-audit-report] written: ${res.path} (${res.bytes} bytes)\n`)
}
