// tools/accept-s56-sent.mjs —— S56·二 感知卡"名实"验收（≥3 项）
//
// 判据（主管指定）：制造真实 extract → 送模数 +1、省 MB 增加，且**读审计**（perception.jsonl），不看内存。
// 做法：真图（复制现有真实截图）→ createExtractor.extract() → 内部 shrinkForModel（GDI+ 640/JPEG70）
//       → 送模那一刻写 {"kind":"sent-to-model","frameId","bytesBefore","bytesAfter","ts"}。
// 隔离：ORB_DATA_DIR 指临时目录（safefs 在模块加载时读 env，故先设 env 再动态 import）。
//
// 用法：node tools\accept-s56-sent.mjs

import { mkdtempSync, rmSync, mkdirSync, copyFileSync, readFileSync, existsSync, readdirSync, statSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'

const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 320) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s56-sent-'))
process.env.ORB_DATA_DIR = join(tmpRoot, 'data')
process.env.CODEBUDDY_SAFE_DELETE_ENABLED = '0'
mkdirSync(join(tmpRoot, 'data', 'logs'), { recursive: true })
mkdirSync(join(tmpRoot, 'data', 'coach'), { recursive: true })
mkdirSync(join(tmpRoot, 'data', 'trash'), { recursive: true })
mkdirSync(join(tmpRoot, 'data', 'tmp'), { recursive: true })

const readSent = () => {
  const p = join(tmpRoot, 'data', 'logs', 'perception.jsonl')
  if (!existsSync(p)) return []
  const out = []
  for (const line of readFileSync(p, 'utf8').split('\n')) {
    const s = line.trim()
    if (!s) continue
    try { const r = JSON.parse(s); if (r && r.kind === 'sent-to-model') out.push(r) } catch { /* 半行 */ }
  }
  return out
}
const sumSaved = (rows) => rows.reduce((s, r) => s + Math.max(0, (Number(r.bytesBefore) || 0) - (Number(r.bytesAfter) || 0)), 0)

try {
  // 1) 找一张真实截图做输入（真图 → 真压缩 → 真字节差）
  const shotsDir = join(PROJECT_ROOT, 'data', 'perception', 'shots')
  let src = null
  if (existsSync(shotsDir)) {
    const f = readdirSync(shotsDir).filter((n) => n.endsWith('.png')).sort((a, b) => statSync(join(shotsDir, b)).size - statSync(join(shotsDir, a)).size)[0]
    if (f) src = join(shotsDir, f)
  }
  if (!src) {
    // 没有现成截图时生成一张（GDI+，确保尺寸够大以体现压缩收益）
    const gen = join(tmpRoot, 'gen.png')
    const ps = [
      'Add-Type -AssemblyName System.Drawing',
      '$bmp=New-Object System.Drawing.Bitmap 1600,1000',
      '$g=[System.Drawing.Graphics]::FromImage($bmp)',
      '$g.Clear([System.Drawing.Color]::White)',
      '$f=New-Object System.Drawing.Font "Consolas",28',
      '$br=New-Object System.Drawing.SolidBrush([System.Drawing.Color]::Black)',
      'for($i=0;$i -lt 30;$i++){ $g.DrawString("line "+$i+" the quick brown fox jumps over the lazy dog",$f,$br,10,(10+$i*30)) }',
      '$bmp.Save($env:GEN_OUT,[System.Drawing.Imaging.ImageFormat]::Png)',
      '$g.Dispose();$bmp.Dispose()',
    ].join('\n')
    const r = (await import('node:child_process')).spawnSync('powershell.exe', ['-NoProfile', '-Command', ps], { env: { ...process.env, GEN_OUT: gen }, timeout: 30000, encoding: 'utf8' })
    if (existsSync(gen)) src = gen
    else throw new Error('无法准备输入图：' + String(r.stderr || '').slice(0, 200))
  }
  console.log('[输入图] ' + src + ' (' + statSync(src).size + ' B)')

  // 2) 真 extract（stub router：不联网、不写缓存语义；压缩与审计是真实路径）
  const { createExtractor } = await import('../packages/plugins/coach/extract.mjs')
  const ex = createExtractor({
    dir: join(tmpRoot, 'data', 'coach'),
    trashDir: join(tmpRoot, 'data', 'trash'),
    router: { run: async () => ({ ok: true, text: '这是一段用于验收的转录文本，覆盖二十个字以上的长度要求。' }) },
  })

  const img1 = join(tmpRoot, 'frame1.png')
  copyFileSync(src, img1)
  const r1 = await ex.extract({ imagePath: img1 })
  const rows1 = readSent()
  const last1 = rows1[rows1.length - 1] || null
  check('S-1 真实 extract 写出 sent-to-model 审计（frameId/bytesBefore/bytesAfter/ts 齐全）',
    r1.ok === true && rows1.length === 1 && !!last1 && typeof last1.ts === 'number' && /^fr-/.test(String(last1.frameId)) && Number.isFinite(last1.bytesBefore) && Number.isFinite(last1.bytesAfter),
    JSON.stringify({ ok: r1.ok, n: rows1.length, last: last1 }))
  check('S-2 压缩真实发生（bytesAfter < bytesBefore，640 宽 JPEG70 与 GDI+ 实跑）',
    !!last1 && last1.bytesAfter > 0 && last1.bytesAfter < last1.bytesBefore,
    JSON.stringify({ before: last1 && last1.bytesBefore, after: last1 && last1.bytesAfter, savedKB: last1 && ((last1.bytesBefore - last1.bytesAfter) / 1024).toFixed(0) }))

  // 3) 再 extract 一张（不同图片 → 不同 frameId，不被去重短路）→ 送模数 +1、Σ 省 MB 增加
  const img2 = join(tmpRoot, 'frame2.png')
  copyFileSync(src, img2)
  // 改一个字节换取不同哈希（末尾追加字节不影响 PNG 解码，但改变 sha256 → 绕过去重）
  const buf = readFileSync(img2)
  const alt = Buffer.concat([buf, Buffer.from('x')])
  const fsMod = await import('node:fs')
  fsMod.writeFileSync(img2, alt)
  const r2 = await ex.extract({ imagePath: img2 })
  const rows2 = readSent()
  check('S-3 第二次 extract → 送模数 +1、Σ 省字节增加（读审计非内存）',
    r2.ok === true && rows2.length === 2 && sumSaved(rows2) > sumSaved(rows1),
    JSON.stringify({ n1: rows1.length, n2: rows2.length, saved1: sumSaved(rows1), saved2: sumSaved(rows2) }))
} catch (e) {
  check('S-0 验收执行异常', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}
const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s56-sent: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exitCode = items.length - pass === 0 ? 0 : 1
