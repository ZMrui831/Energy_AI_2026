// tools/probe-reasoner-queue.mjs
//
// 验收 ② 的真机取证：对 deepseek-reasoner 连发 12 次真实请求，
// 证明"严格 10 次/分钟，第 11 次起排队而不是直发，且不崩"。
//
// 跑法：node tools\probe-reasoner-queue.mjs
// 产物：data\shots\stage1-acceptance-reasoner.json（含每次调用的耗时与排队标记）
//
// 说明：这个脚本会真的调用 DeepSeek API（12 次），因此不做进单元测试；
// 单元测试用的是虚拟时钟（tests/ratelimit.test.mjs），逻辑等价但零成本。

import { writeFileSync } from 'node:fs'
import { join } from 'node:path'

import { createProviders, collectStream } from '../packages/core/src/providers/index.mjs'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const OUT = join(PROJECT_ROOT, 'data', 'shots', 'stage1-acceptance-reasoner.json')
const N = 12
const QUESTION = '只回答一个阿拉伯数字，不要任何解释：1+1 等于几？'

const providers = createProviders({})
const provider = providers.byId('deepseek-api')
if (!provider) throw new Error('deepseek-api provider 未注册')

const cfg = provider.describeConfig()
process.stdout.write(`provider=${provider.id} model=deepseek-reasoner key=${cfg.key} base=${cfg.baseUrl}\n`)
process.stdout.write(`要点：reasoner 严格 10 次/分钟；第 11 次必须排队（等窗口），不能直发、不能崩\n\n`)

const rows = []
for (let i = 1; i <= N; i += 1) {
  const t0 = Date.now()
  let text = ''
  let code = null
  try {
    const r = await collectStream(
      provider.chat({ messages: [{ role: 'user', content: QUESTION }], model: 'deepseek-reasoner' }),
    )
    text = (r.text || '').trim().slice(0, 20)
    code = r.errors.length > 0 ? r.errors[0].code : null
  } catch (err) {
    code = 'THREW:' + (err && err.message)
  }
  const ms = Date.now() - t0
  const q = provider.net.queueState()
  rows.push({ i, ms, code, text, windowUsed: q.reasonerWindowUsed, waiting: q.waiting })
  process.stdout.write(`#${String(i).padStart(2)}  ${String(ms).padStart(6)} ms  window=${q.reasonerWindowUsed}/10  text=${JSON.stringify(text)}${code ? '  code=' + code : ''}\n`)
}

// 从 net.jsonl 里把本次 reasoner 调用的审计行摘出来（排队标记只在这里）
const audit = (await import('node:fs')).readFileSync(provider.net.logFile, 'utf8')
  .split('\n')
  .filter((l) => l.trim())
  .map((l) => JSON.parse(l))
  .filter((r) => r.model === 'deepseek-reasoner' && r.decision === 'allow')
  .slice(-N)

const queuedIdx = audit.map((r, idx) => (r.reasonerQueued ? idx + 1 : null)).filter(Boolean)
const okAll = rows.every((r) => !r.code && r.ms > 0)
const queueState = provider.net.queueState()

const evidence = {
  ts: new Date().toISOString(),
  provider: provider.id,
  model: 'deepseek-reasoner',
  requested: N,
  allSucceeded: okAll,
  failures: rows.filter((r) => r.code),
  reasonerQueuedAt: queuedIdx,
  maxMs: Math.max(...rows.map((r) => r.ms)),
  totalMs: rows.reduce((a, r) => a + r.ms, 0),
  queueState: {
    waiting: queueState.waiting,
    limited: queueState.limited,
    requests: queueState.requests,
    retried: queueState.retried,
    denied: queueState.denied,
    exhausted: queueState.exhausted,
    reasonerWindowUsed: queueState.reasonerWindowUsed,
    reasonerLimitPerMinute: queueState.reasonerLimitPerMinute,
  },
  audit: audit.map((r) => ({ status: r.status, ms: r.ms, queued: !!r.queued, reasonerQueued: !!r.reasonerQueued, bucketKey: r.bucketKey })),
  rows,
}

writeFileSync(OUT, JSON.stringify(evidence, null, 2))
process.stdout.write(`\n排队次数=${queuedIdx.length} 发生在第 ${JSON.stringify(queuedIdx)} 次\n`)
process.stdout.write(`全部成功=${okAll}  总耗时=${evidence.totalMs} ms  单次最大=${evidence.maxMs} ms\n`)
process.stdout.write(`queueState=${JSON.stringify(evidence.queueState)}\n`)
process.stdout.write(`evidence -> ${OUT}\n`)
process.exit(okAll ? 0 : 1)
