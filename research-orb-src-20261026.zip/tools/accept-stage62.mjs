// tools/accept-stage62.mjs —— P-R6.2 总验收：顺序调用各子验收并汇总 stage62-summary.json
import { spawnSync } from 'node:child_process'
import { writeFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const STEPS = [
  { id: '1-拖动数学（纯函数 ≥12 例）', test: 'tests/geom.test.mjs', desc: 'dpi 1.0/1.25/1.5、左右上右下、多屏负坐标、move 禁钳制/end 钳制、异常 bounds、圆命中、防正反馈' },
  { id: '2-拖动/穿透（真 electron）', script: 'tools/accept-stage62-drag.mjs', desc: '源码断言 + hit-test 双值 + 真实光标拖动钳制 + drag-start/end 审计' },
  { id: '3-屏幕感知（真 electron）', script: 'tools/accept-stage62-screen.mjs', desc: 'desktopCapturer 抓屏/PNG 落盘/writes 审计/覆盖层三态/降级话术/隐私' },
  { id: '4-说明折叠（真 electron）', script: 'tools/accept-stage62-collapse.mjs', desc: '默认折叠一行/点击展开/重启保持/几何契约 420×620' },
  { id: '5-折叠接线与语义', test: 'tests/collapse.test.mjs', desc: '控件接线/localStorage 持久化语义/领域行纳入折叠区' },
  { id: '6-企业版清单修订', test: 'tests/enterprise-demo.test.mjs', desc: 'L2/L3/L4 静态禁用（desktopCapturer 移出禁用清单：读像素≠注入输入）' },
  { id: '7-electron 冒烟', script: 'tools/accept-smoke-electron.mjs', desc: 'bridge-injected 无异常、ui.jsonl ping、settings 往返' },
  { id: '8-隔离五查', script: 'tools/accept-stage5-isolation.mjs', desc: 'vendor/start 指纹、计划任务 0、残留 0、writes 越界 0' },
  { id: '9-冷跑全量单测', cold: true, desc: 'node --test --test-concurrency=1 tests/*.test.mjs' },
]

const items = []
for (const s of STEPS) {
  process.stdout.write(`\n>>> ${s.id} …\n`)
  let r
  if (s.cold) {
    const testFiles = readdirSync(join(PROJECT_ROOT, 'tests')).filter((f) => f.endsWith('.test.mjs')).map((f) => `tests/${f}`)
    const full = spawnSync(process.execPath, ['--test', '--test-concurrency=1', ...testFiles], { cwd: PROJECT_ROOT, encoding: 'utf8', timeout: 600000, windowsHide: true, maxBuffer: 32 << 20 })
    const m = String(full.stdout || '').match(/# tests (\d+)[\s\S]*?# pass (\d+)[\s\S]*?# fail (\d+)/)
    r = { ok: !!m && Number(m[3]) === 0 && Number(m[1]) >= 518, pass: m ? Number(m[2]) : 0, fail: m ? Number(m[3]) : -1, tail: `tests=${m && m[1]} pass=${m && m[2]} fail=${m && m[3]}` }
  } else if (s.test) {
    const t = spawnSync(process.execPath, ['--test', s.test], { cwd: PROJECT_ROOT, encoding: 'utf8', timeout: 300000, windowsHide: true, maxBuffer: 16 << 20 })
    const m = String(t.stdout || '').match(/# tests (\d+)[\s\S]*?# pass (\d+)[\s\S]*?# fail (\d+)/)
    r = { ok: t.status === 0, pass: m ? Number(m[2]) : 0, fail: m ? Number(m[3]) : -1, tail: String(t.stdout || '').split('\n').filter((l) => /# (tests|pass|fail)/.test(l)).join(' ') }
  } else {
    const t = spawnSync(process.execPath, [s.script], { cwd: PROJECT_ROOT, encoding: 'utf8', timeout: 400000, windowsHide: true, maxBuffer: 32 << 20 })
    const out = `${t.stdout || ''}${t.stderr || ''}`
    r = { ok: t.status === 0, pass: (out.match(/^PASS/gm) || []).length, fail: (out.match(/^FAIL/gm) || []).length, tail: out.split('\n').filter((l) => /^(PASS|FAIL|===)/.test(l)).slice(-4).join(' | ') }
  }
  console.log(`    -> ok=${r.ok} pass=${r.pass} fail=${r.fail}`)
  items.push({ id: s.id, ok: r.ok, pass: r.pass, fail: r.fail, evidence: s.script || s.test, desc: s.desc })
}

const allOk = items.every((i) => i.ok)
const summary = {
  stage: 'P-R6.2',
  generatedAt: new Date().toISOString(),
  ok: allOk,
  coldRunCommand: 'node --test --test-concurrency=1 tests/*.test.mjs',
  manualItems: [
    '0.4 跟手拖动手感（跟手/不反向）——需真人拖动',
    '0.5 拖到底部钳制的视觉确认（自动证据：drag-end.final 落 workArea 内）',
    '0.6/8.1 覆盖层与球透明区旁点击桌面图标正常（自动证据：setIgnoreMouseEvents + click-through 日志）',
    '10.2 「我屏幕上现在是什么」的诚实降级话术体验',
  ],
  evidenceFiles: [
    'data/logs/stage62-drag.txt',
    'data/logs/stage62-screen.txt',
    'data/logs/stage62-collapse.txt',
    'data/logs/stage62-summary.json',
    'data/logs/launcher.log',
    'data/shots/stage62-collapse-closed.png',
    'data/shots/stage62-collapse-open.png',
    'data/shots/stage62-collapse-reload.png',
    'data/shots/capture-*.png',
  ],
  items,
}
writeFileSync(join(PROJECT_ROOT, 'data', 'logs', 'stage62-summary.json'), `${JSON.stringify(summary, null, 2)}\n`, 'utf8')
console.log(`\n=== P-R6.2 总验收：${allOk ? '全部通过' : '存在失败项'} ===`)
for (const i of items) console.log(`${i.ok ? 'OK  ' : 'FAIL'} ${i.id} (pass=${i.pass} fail=${i.fail})`)
process.exit(allOk ? 0 : 1)