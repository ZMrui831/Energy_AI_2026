// tools/accept-s37-mindmap.mjs —— S37·B 思维导图验收（≥8 项）。
// 单行复跑：node tools\accept-s37-mindmap.mjs
// 证据：data\logs\s37-mindmap-accept.json
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync, statSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'

// 验收隔离：先设 ORB_LOG_DIR/ORB_DATA_DIR 再动态 import（safefs 在 import 时定格目录）
process.env.ORB_LOG_DIR = join(tmpdir(), 's37-mm-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's37-mm-data-' + Date.now())
const { dataPath, PROJECT_ROOT } = await import('../packages/core/src/safefs.mjs')
const { renderMindmap, saveToNotes, buildMindmapData, mindmapToMermaid, MindmapError } = await import('../packages/plugins/coach/mindmap.mjs')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

// 播种：goal + blueprint + memory facts + trajectory intents（隔离树）
function seed() {
  const coach = dataPath('coach')
  mkdirSync(coach, { recursive: true })
  mkdirSync(dataPath('memory', 'project'), { recursive: true })
  writeFileSync(join(coach, 'goal.json'), JSON.stringify({ goal: '两周内完成微电网综述的初稿与文献表', updatedAt: new Date().toISOString(), source: 'seed' }))
  writeFileSync(join(coach, 'blueprint.md'), '# 蓝图\n1. 定范围：拆成 3 个可核验子问题\n2. 找文献：优先双源\n3. 立结论：证据不足停草稿\n')
  writeFileSync(dataPath('memory', 'project', 'longterm.md'), [
    JSON.stringify({ id: 'f1', ts: 1792700000000, layer: 1, text: '用户的研究方向是智能电网综合能源系统的 AI 应用' }),
    JSON.stringify({ id: 'f2', ts: 1792700001000, layer: 1, text: '综述优先覆盖虚拟电厂与需求响应两个章节' }),
    '', ].join('\n'))
  writeFileSync(join(coach, 'trajectory.jsonl'), [
    JSON.stringify({ ts: new Date().toISOString(), window: 'VSCode', process: 'code.exe', intent: '撰写论文方法章节' }),
    JSON.stringify({ ts: new Date().toISOString(), window: 'Word', process: 'winword.exe', intent: '整理文献表' }),
    '', ].join('\n'))
}

try {
  seed()
  const t1 = Date.now()
  const r1 = await renderMindmap({ query: '研究 方向 综述', now: new Date(t1) })

  // M-1 层级 ≥3：root → themes（≥2 类来源）→ leaves（>0）
  const drawn1 = JSON.parse(readFileSync(r1.drawnPath, 'utf8'))
  check('M-1 层级 ≥3（root/themes/leaves）', drawn1.themes.length >= 2 && drawn1.leafTotal > 0 && !!drawn1.root,
    `themes=${drawn1.themes.length} leaves=${drawn1.leafTotal}`, {})

  // M-2 PNG 尺寸合规（≥1600×1000）
  check('M-2 PNG 尺寸合规', r1.size.width >= 1600 && r1.size.height >= 1000, `${r1.size.width}x${r1.size.height}`, {})

  // M-3 来源在图内（sidecar sourcesLine 含三类来源 + 时间 + 版本）
  const sl = drawn1.sourcesLine
  check('M-3 来源标注在图内', /memory \d+ 条/.test(sl) && /blueprint \d+ 步/.test(sl) && /trajectory \d+ 条/.test(sl) && /\d{4}-\d{2}-\d{2}/.test(sl) && /v0\.7\.0/.test(sl),
    `sourcesLine=${sl.slice(0, 70)}`, {})

  // M-4 存笔记成功（notes/研究导图/ 下 png+md 都在）
  const saved = saveToNotes(r1)
  check('M-4 存笔记（研究导图/）', existsSync(saved.pngDst) && existsSync(saved.mdDst) && saved.pngDst.includes('研究导图'),
    `png=${saved.pngDst.split(/[\\/]/).pop()}`, {})

  // M-5 内容哈希幂等：同内容第二次渲染 → cached=true、同路径、mtime 不变
  const mtime1 = statSync(r1.pngPath).mtimeMs
  const r2 = await renderMindmap({ query: '研究 方向 综述', now: new Date(t1 + 60000) })
  const mtime2 = statSync(r2.pngPath).mtimeMs
  check('M-5 内容哈希幂等', r2.cached === true && r2.pngPath === r1.pngPath && r2.contentHash === r1.contentHash && mtime1 === mtime2,
    `cached=${r2.cached} samePath=${r2.pngPath === r1.pngPath} mtimeSame=${mtime1 === mtime2}`, {})

  // M-6 mermaid 文本合法（mindmap 语法 + 缩进层级）
  const mdText = readFileSync(r1.mermaidPath, 'utf8')
  check('M-6 mermaid mindmap 文本', /^mindmap$/m.test(mdText) && mdText.includes('((') && /\s{6,}\S/.test(mdText),
    `mermaid 行数=${mdText.split('\n').length}`, {})

  // M-7 轨迹来源接入（trajectory intents 成为主题）
  check('M-7 轨迹来源接入', r1.data.counts.trajectory >= 2 && r1.data.themes.some((t) => t.source === 'trajectory'),
    `trajectory=${r1.data.counts.trajectory}`, {})

  // M-8 空记忆提示不崩（独立子进程 + 全新空数据树 → E_EMPTY_MINDMAP 且文案含建议）
  const emptyData = join(tmpdir(), 's37-mm-empty-' + Date.now())
  const probe = spawnSync(process.execPath, ['--input-type=module', '-e', `
    import { pathToFileURL } from 'node:url'
    process.env.ORB_DATA_DIR = ${JSON.stringify(emptyData)}
    process.env.ORB_LOG_DIR = ${JSON.stringify(join(tmpdir(), 's37-mm-empty-logs-' + Date.now()))}
    const { renderMindmap } = await import(pathToFileURL(${JSON.stringify(join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'mindmap.mjs'))}).href)
    try { await renderMindmap({ query: '任何词' }); console.log('NO_ERROR') }
    catch (e) { console.log('CODE:' + (e.code || '?') + '|' + String(e.message || e).slice(0, 80)) }
  `], { cwd: PROJECT_ROOT, encoding: 'utf8' })
  const outLine = String(probe.stdout || '').trim().split('\n').pop() || ''
  check('M-8 空记忆提示不崩', outLine.startsWith('CODE:E_EMPTY_MINDMAP') && outLine.includes('不编造节点') && outLine.includes('goal set'),
    `out=${outLine.slice(0, 80)}`, {})

  // M-9 --out 自定义目录（在可写根内的自定义位置）
  const customDir = dataPath('tmp', 's37-mm-custom-' + Date.now())
  const r3 = await renderMindmap({ query: '研究 方向 综述', outDir: customDir, now: new Date(t1 + 120000) })
  check('M-9 --out 自定义目录', existsSync(r3.pngPath) && r3.pngPath.startsWith(customDir),
    `out=${r3.pngPath.split(/[\\/]/).pop()}`, {})

  // M-10 contentHash 稳定（同内容两次 build → 同哈希；改内容 → 哈希变）
  const dA = buildMindmapData({ query: '研究 方向 综述', now: new Date(t1) })
  const dB = buildMindmapData({ query: '研究 方向 综述', now: new Date(t1 + 3600000) })
  check('M-10 contentHash 稳定', dA.contentHash === dB.contentHash,
    `hash=${dA.contentHash.slice(0, 12)}`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's37-mindmap-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s37-mindmap: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
