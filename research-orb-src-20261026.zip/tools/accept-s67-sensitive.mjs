// tools/accept-s67-sensitive.mjs
//
// S67·1-C 验收：敏感判定 fail-open → 启发式拒截 + 审计 skipped-sensitive{why,matched}
//
// 纪律：绝不假绿；自报数字需在干净 shell 复跑得到。
// 隔离：ORB_DATA_DIR / ORB_LOG_DIR 整体挪到临时目录，真实 data 零写入。
//
// 用法：node tools/accept-s67-sensitive.mjs

import { mkdtempSync, existsSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

// 隔离必须在静态 import 之前设定（safefs 在加载时解析 DATA_DIR）。
const TEST_DATA = mkdtempSync(join(tmpdir(), 'orb-s67-sensitive-'))
process.env.ORB_DATA_DIR = TEST_DATA
process.env.ORB_LOG_DIR = join(TEST_DATA, 'logs')

const items = []
const addItem = (id, ok, detail = '', evidence = {}) => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300), evidence })
  console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`)
  return ok
}

function readJsonl(p) {
  if (!existsSync(p)) return []
  return readFileSync(p, 'utf8')
    .split('\n')
    .map((s) => s.trim())
    .filter(Boolean)
    .map((l) => {
      try { return JSON.parse(l) } catch { return null }
    })
    .filter(Boolean)
}

async function main() {
  const { isSensitive, sensitiveMatched } = await import('../packages/plugins/perception/sampler.mjs')
  const { PerceptionController } = await import('../packages/plugins/perception/index.mjs')
  const { grant, FOUR_HOURS } = await import('../packages/plugins/perception/consent.mjs')
  const { logPath } = await import('../packages/core/src/safefs.mjs')

  // C1：扩展名单（S67·1-C 新增关键词）全部命中
  const newHits = [
    ['cmd.exe', 'cmd.exe'],
    ['powershell', 'powershell'],
    ['终端', 'x'],
    ['ssh 会话', 'x'],
    ['id_rsa 私钥', 'x'],
    ['门诊病历', 'x'],
    ['处方笺', 'x'],
    ['LastPass Vault', 'x'],
  ]
  const newMiss = newHits.filter(([t, p]) => !isSensitive(t, p))
  addItem('C1 扩展名单新增关键词命中', newMiss.length === 0,
    `未命中=${newMiss.map(([t]) => t).join(' / ') || '无'}`)

  // C2：既有名单回归仍命中（不得因扩展而漏判既有）
  const legacyHits = [
    ['1Password - vault', '1password'],
    ['KeePass', 'x'],
    ['我的密码', 'x'],
    ['网上银行登录', 'chrome'],
    ['网银转账', 'x'],
    ['支付宝支付', 'x'],
    ['医疗报告', 'x'],
    ['My Health App', 'health.exe'],
    ['My Bank', 'bank.exe'],
    ['Login Data', 'chrome'],
  ]
  const legacyMiss = legacyHits.filter(([t, p]) => !isSensitive(t, p))
  addItem('C2 既有名单回归仍命中', legacyMiss.length === 0,
    `未命中=${legacyMiss.map(([t]) => t).join(' / ') || '无'}`)

  // C3：普通窗口不误杀（false-positive 必须为零）
  const safe = [['VS Code', 'code'], ['计算器', 'calculator'], ['普通网页', 'chrome'], ['文档.docx', 'winword']]
  const safeHit = safe.filter(([t, p]) => isSensitive(t, p))
  addItem('C3 普通窗口不误杀', safeHit.length === 0,
    `误杀=${safeHit.map(([t]) => t).join(' / ') || '无'}`)

  // C4：sensitiveMatched 返回命中关键词，非敏感返回 null（审计 matched 字段来源）
  const m1 = sensitiveMatched('网上银行登录', 'chrome')
  const m2 = sensitiveMatched('cmd.exe', 'cmd.exe')
  const m3 = sensitiveMatched('VS Code', 'code')
  addItem('C4 matched 命中词正确且非敏感为 null',
    m1 === '银行' && m2 === 'cmd.exe' && m3 === null,
    `网上银行→${JSON.stringify(m1)} cmd.exe→${JSON.stringify(m2)} VS Code→${JSON.stringify(m3)}`)

  // C5：集成——PerceptionController 对敏感样本写 skipped-sensitive{why,matched}
  const t0 = Date.now()
  const cfg = { blacklist: undefined, coldStartCaptureDisabled: false }
  cfg.consent = grant('session', { now: Date.now(), ttl: FOUR_HOURS })
  const ctrl = new PerceptionController({ log: { info() {}, warn() {} } }, cfg)
  ctrl.processStartedAt = Date.now() - 5000
  ctrl._onSample({ ts: Date.now(), hwnd: 1, pid: 1, process: 'chrome', title: '网上银行登录', idleMs: 0, isFullscreen: false })
  const audit = readJsonl(logPath('perception.jsonl')).filter((r) => Number(r.ts) >= t0)
  const skipped = audit.find((r) => r.kind === 'skipped-sensitive')
  addItem('C5 集成审计 skipped-sensitive{why,matched}',
    !!skipped && skipped.why === 'sensitive-window-heuristic' && typeof skipped.matched === 'string' && skipped.matched.length > 0,
    `kind=${skipped && skipped.kind} why=${skipped && skipped.why} matched=${skipped && JSON.stringify(skipped.matched)}`)

  // C6：fail-closed——即使截图被禁用（idle 态 capture.enabled=false），敏感窗口仍拒采，
  // 证明拒采分支位于 `if (!cap.enabled) return` 之前，不会被截图开关绕过。
  const cfg2 = { blacklist: undefined, coldStartCaptureDisabled: false }
  cfg2.consent = grant('session', { now: Date.now(), ttl: FOUR_HOURS })
  const ctrl2 = new PerceptionController({ log: { info() {}, warn() {} } }, cfg2)
  ctrl2.processStartedAt = Date.now() - 5000
  ctrl2.state = 'idle' // idle 态不开启截图
  ctrl2._onSample({ ts: Date.now(), hwnd: 2, pid: 2, process: 'powershell', title: 'powershell', idleMs: 0, isFullscreen: false })
  const audit2 = readJsonl(logPath('perception.jsonl')).filter((r) => Number(r.ts) >= t0)
  const skipped2 = audit2.find((r) => r.kind === 'skipped-sensitive' && /powershell/.test(String(r.matched || '')))
  addItem('C6 截图禁用态敏感窗口仍拒采(fail-closed)',
    !!skipped2, `powershell 命中 skip=${!!skipped2} matched=${skipped2 && JSON.stringify(skipped2.matched)}`)

  // 清理临时目录
  try { rmSync(TEST_DATA, { recursive: true, force: true }) } catch { /* ignore */ }

  const pass = items.every((i) => i.ok)
  console.log(`\n[S67·1-C sensitive] ${items.filter((i) => i.ok).length}/${items.length} 通过 ${pass ? 'OK' : 'FAILED'}`)
  process.exit(pass ? 0 : 1)
}

main().catch((e) => { console.error('[accept-s67-sensitive] 异常:', e); process.exit(2) })
