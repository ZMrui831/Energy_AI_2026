// tools/export-evidence.mjs —— S67·3-A 证据导出 + 测试残留清理（先导出，后清理）
//
// 用法：
//   node tools/export-evidence.mjs                          # 仅导出全量证据快照 → data/exports/
//   node tools/export-evidence.mjs --purge-test             # 导出 + dry-run 列出将删的测试残留
//   node tools/export-evidence.mjs --purge-test --apply     # 导出 + 真正删除（留档先落盘）
//
// 安全：无论是否 --apply，**先写导出快照**；删除前打印清单；只删测试强特征行。
import { DatabaseSync } from 'node:sqlite'
import { mkdirSync, writeFileSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const DB = join(ROOT, 'data', 'db', 'orb.sqlite')
const OUT = join(ROOT, 'data', 'exports')

const argv = process.argv.slice(2)
const purge = argv.includes('--purge-test')
const apply = argv.includes('--apply')

// 与 check-evidence-purity 对齐的强特征（claim 用宽，raw_frame 用强）
const CLAIM_MARK = /验收|测试|fixture|stub|rf-s\d+-setup/i
const RAWFRAME_MARK = /rf-s\d+-setup|accept-s\d+/i

const db = new DatabaseSync(DB)
let claim = [], ce = [], rf = []
try { claim = db.prepare('SELECT * FROM claim').all() } catch (e) { console.log('claim read err:', e.message) }
try { ce = db.prepare('SELECT * FROM claim_evidence').all() } catch (e) { console.log('claim_evidence read err:', e.message) }
try { rf = db.prepare('SELECT * FROM raw_frame').all() } catch (e) { console.log('raw_frame read err:', e.message) }

mkdirSync(OUT, { recursive: true })
const stamp = new Date().toISOString().replace(/[:.]/g, '-')
const file = join(OUT, `evidence-${stamp}.json`)
writeFileSync(file, JSON.stringify({ exportedAt: new Date().toISOString(), db: DB, claim, claim_evidence: ce, raw_frame: rf }, null, 2), 'utf8')
console.log('[export-evidence] 已导出 → ' + file + ` （claim ${claim.length} / claim_evidence ${ce.length} / raw_frame ${rf.length}）`)

// G4：导出时复查完整性——published 但无证据的结论必须告警（不得静默带出）
try {
  const broken = db.prepare(
    `SELECT c.id FROM claim c
     WHERE c.status = 'published'
       AND (SELECT COUNT(*) FROM claim_evidence ce WHERE ce.claim_id = c.id AND ce.relation <> 'none') = 0`,
  ).all()
  if (broken.length) console.log('[export-evidence] ⚠ G4 完整性告警：已发布但无证据的 claim → ' + broken.map((b) => b.id).join(', '))
  else console.log('[export-evidence] G4 完整性：published claim 均有证据 ✓')
} catch { /* 老库无 claim 表 */ }

if (purge) {
  const badClaim = claim.filter((c) => CLAIM_MARK.test(String(c.text || ''))).map((c) => c.id)
  const badRf = rf.filter((r) => RAWFRAME_MARK.test(String(r.id))).map((r) => r.id)
  console.log('[export-evidence] 测试残留：claim ' + badClaim.length + ' 条' + (badRf.length ? ' / raw_frame ' + badRf.length + ' 条' : ''))
  for (const id of badClaim) console.log('  - claim ' + id)
  for (const id of badRf) console.log('  - raw_frame ' + id)
  if (!apply) {
    console.log('[export-evidence] dry-run（加 --apply 才真正删除）')
    db.close()
    process.exit(0)
  }
  let n = 0
  const stmtCE1 = db.prepare('DELETE FROM claim_evidence WHERE claim_id = ?')
  const stmtCE2 = db.prepare('DELETE FROM claim_evidence WHERE evidence_id = ?')
  const stmtC = db.prepare('DELETE FROM claim WHERE id = ?')
  const stmtRF = db.prepare('DELETE FROM raw_frame WHERE id = ?')
  for (const cid of badClaim) { n += (stmtCE1.run(cid).changes || 0) + (stmtC.run(cid).changes || 0) }
  for (const rid of badRf) { n += (stmtCE2.run(rid).changes || 0) + (stmtRF.run(rid).changes || 0) }
  console.log('[export-evidence] 已删除 ' + n + ' 行（留档见上）')
}
db.close()
