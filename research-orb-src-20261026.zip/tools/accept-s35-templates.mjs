// tools/accept-s35-templates.mjs —— S35·A2 健康提醒三档文案验收（≥6 项）。
// 单行复跑：node tools\accept-s35-templates.mjs
// 证据：data\logs\s35-templates-accept.json
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

// S35 验收隔离：先设 ORB_LOG_DIR/ORB_DATA_DIR 再动态 import（safefs 在 import 时定格目录）
process.env.ORB_LOG_DIR = join(tmpdir(), 's35-tpl-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's35-tpl-data-' + Date.now())
const { dataPath } = await import('../packages/core/src/safefs.mjs')
const { createHealthLedger, HEALTH_TEMPLATES } = await import('../packages/plugins/coach/health.mjs')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

const DAY = 24 * 60 * 60 * 1000
let clock = Date.now()
const now = () => clock
const reminderLog = (dir) => {
  const f = join(dir, 'health.jsonl')
  try { return readFileSync(f, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)).filter((r) => r.kind === 'reminder') } catch { return [] }
}

try {
  const mkTmp = (prefix) => { const d = join(dataPath('tmp'), prefix + '-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6)); mkdirSync(d, { recursive: true }); return d }
  // 1) 三档各一次：rest（久坐 50）/ walk（娱乐 90）/ pomodoro（25 专注块）
  const c1 = mkTmp('s35-hl')
  const seen = []
  const h1 = createHealthLedger({ dir: c1, now, remind: async (i) => seen.push(i) })
  await h1.feed({ process: 'code.exe', title: 'VSCode', dwellMin: 55 })
  await h1.feed({ process: 'steam.exe', title: '游戏', dwellMin: 95 })
  await h1.pomodoroComplete(25)
  const rows1 = reminderLog(c1)
  const levels = new Set(rows1.map((r) => r.level))
  check('A2-1 三档各一次', levels.has('rest') && levels.has('walk') && levels.has('pomodoro') && rows1.length === 3,
    `levels=${[...levels].join(',')} rows=${rows1.length}`, {})

  // 2) 字段齐：{ts,kind,level,templateId,message} 逐行齐备
  const fieldsOk = rows1.every((r) => r.ts && r.kind === 'reminder' && r.level && r.templateId && typeof r.message === 'string' && r.message.length > 5)
  check('A2-2 字段齐 ts/kind/level/templateId/message', fieldsOk, `rows=${rows1.length} allFields=${fieldsOk}`, {})

  // 3) 未超阈零打扰：work 20 分钟 → 无提醒
  const c3 = mkTmp('s35-hl')
  const h3 = createHealthLedger({ dir: c3, now, remind: async () => {} })
  await h3.feed({ process: 'code.exe', title: 'VSCode', dwellMin: 20 })
  check('A2-3 未超阈零打扰', reminderLog(c3).length === 0, `reminders=${reminderLog(c3).length}`, {})

  // 4) 冷却生效：先触发一次 rest，24h 内第二次到阈 → 不重复提醒
  clock += 60 * 60 * 1000 // 推进 1h
  await h3.feed({ process: 'code.exe', title: 'VSCode', dwellMin: 55 }) // 首次到阈 → rest 提醒
  const firstCount = reminderLog(c3).length
  clock += 60 * 60 * 1000 // 再推进 1h（仍在 24h 冷却内）
  await h3.feed({ process: 'code.exe', title: 'VSCode', dwellMin: 60 })
  const rows4 = reminderLog(c3)
  check('A2-4 冷却生效（24h 内同档不重复）', firstCount === 1 && rows4.length === 1, `first=${firstCount} after=${rows4.length}`, {})

  // 5) 文案不重复：同档跨冷却两次 → templateId/message 均不同（轮换）
  clock += DAY + 60 * 60 * 1000 // 推进 25h（冷却已过）
  await h3.feed({ process: 'code.exe', title: 'VSCode', dwellMin: 60 })
  clock += DAY + 60 * 60 * 1000
  await h3.feed({ process: 'code.exe', title: 'VSCode', dwellMin: 60 })
  const rest5 = reminderLog(c3).filter((r) => r.level === 'rest')
  const uniq = new Set(rest5.map((r) => r.templateId))
  check('A2-5 同档文案轮换不重复', rest5.length >= 2 && uniq.size === rest5.length,
    `rest 提醒=${rest5.length} 唯一 templateId=${uniq.size}`, {})

  // 6) 建议语气（禁命令式）：内置模板不以命令动词开头（必须/立即/马上/赶紧）
  const allMsg = Object.values(HEALTH_TEMPLATES).flat().join('|')
  const commandish = /(^[，。]|必须|立即|马上|赶紧|不许|不得)/.test(allMsg.replace(/^你|^这边|^连续|^娱乐|^这一枚|^专注|^25/gm, ''))
  check('A2-6 建议语气（无命令式字眼）', !commandish, `commandish=${commandish}`, {})

  // 7) 模板可配（opts.templates 注入 → 自定义文案生效）
  const c7 = mkTmp('s35-hl')
  const h7 = createHealthLedger({ dir: c7, now, templates: { rest: ['自定义休息文案：请喝口水，stretch 一下。'] }, remind: async () => {} })
  await h7.feed({ process: 'code.exe', title: 'VSCode', dwellMin: 55 })
  const r7 = reminderLog(c7)[0]
  check('A2-7 模板可配（opts 注入）', r7 && r7.message.includes('自定义休息文案') && r7.templateId === 'rest-1',
    `templateId=${r7 && r7.templateId}`, {})

  // 8) 模板可配（health-templates.json 文件配置生效）
  const c8 = mkTmp('s35-hl')
  writeFileSync(join(c8, 'health-templates.json'), JSON.stringify({ walk: ['自定义出门文案：外面天气不错。'] }), 'utf8')
  const h8 = createHealthLedger({ dir: c8, now, remind: async () => {} })
  await h8.feed({ process: 'steam.exe', title: '游戏', dwellMin: 95 })
  const r8 = reminderLog(c8)[0]
  check('A2-8 模板可配（health-templates.json）', r8 && r8.message.includes('自定义出门文案'), `templateId=${r8 && r8.templateId}`, {})

  // 9) 恢复严格记录：超阈娱乐后离开 → recovery 行
  const c9 = mkTmp('s35-hl')
  const h9 = createHealthLedger({ dir: c9, now, remind: async () => {} })
  await h9.feed({ process: 'steam.exe', title: '游戏', dwellMin: 95 })
  await h9.feed({ process: 'code.exe', title: 'VSCode', dwellMin: 5 })
  const f9 = join(c9, 'health.jsonl')
  const recovery = readFileSync(f9, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)).some((r) => r.kind === 'recovery')
  check('A2-9 恢复严格记录（recovery 行）', recovery, `recovery=${recovery}`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

try { rmSync(process.env.ORB_LOG_DIR, { recursive: true, force: true }); rmSync(process.env.ORB_DATA_DIR, { recursive: true, force: true }) } catch { /* 尽力 */ }
const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's35-templates-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s35-templates: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
