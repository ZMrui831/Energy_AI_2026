// tools/accept-s60-glm.mjs —— S60 视觉档（智谱 GLM-5.3-Flash）验收（≥8 项）
//
// 判据：真图返回含"红" · maxTokens 下限 512 · reasoning_content 兜底（审计标记）·
//      length 只重试一次 · zhipu 失败回退网关且审计 route-fallback · 超时 ≥60s ·
//      sent-to-model 仍写入 · 令牌桶 10/min 仍生效。
// 做法：makeInvoke（coach 导出）+ stub globalThis.fetch 拦截（可断言请求体与响应路径），
//      另跑一次真调（真 key 真网络）。数据目录隔离，真实 data 只读。
//
// 用法：node tools\accept-s60-glm.mjs

import { mkdtempSync, rmSync, mkdirSync, readFileSync, existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'

const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 320) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s60-'))
process.env.ORB_DATA_DIR = join(tmpRoot, 'data')
mkdirSync(join(tmpRoot, 'data', 'logs'), { recursive: true })
mkdirSync(join(tmpRoot, 'data', 'coach'), { recursive: true })
mkdirSync(join(tmpRoot, 'data', 'trash'), { recursive: true })
// 只读复制真实配置到隔离目录（不改原文件）：secrets 提供 zhipu key，providers 提供 vision 段
try {
  const { copyFileSync } = await import('node:fs')
  for (const f of ['secrets.json', 'providers.json']) {
    const src = join(PROJECT_ROOT, 'data', f)
    if (existsSync(src)) copyFileSync(src, join(tmpRoot, 'data', f))
  }
} catch { /* 复制失败后续会以"密钥不可用"如实报错 */ }

const realFetch = globalThis.fetch
let calls = []
const stub = (responder) => {
  calls = []
  globalThis.fetch = async (url, init) => {
    const body = init && init.body ? JSON.parse(init.body) : null
    calls.push({ url, body })
    const r = responder(body, calls.length)
    return { ok: r.status ? r.status < 400 : true, status: r.status || 200, json: async () => r.doc, text: async () => JSON.stringify(r.doc || {}) }
  }
}

try {
  const { makeInvoke, VISION_TIMEOUT_MS, VISION_MIN_TOKENS } = await import('../packages/plugins/coach/index.mjs')
  const { createRouter, createRateLimiter } = await import('../packages/core/src/router.mjs')
  const { createExtractor } = await import('../packages/plugins/coach/extract.mjs')
  const { readFileSync: rf } = await import('node:fs')

  const visionProvider = {
    providerId: 'zhipu', protocol: 'openai/v1',
    baseUrl: 'https://open.bigmodel.cn/api/paas/v4',
    model: 'glm-5.3-flash', authRef: 'secrets:zhipu',
  }
  const invoke = makeInvoke(null) // net 不可用 → 走 fetch（被 stub 拦截）

  // ---------- S-1 真图（96×96 红）→ 返回含"红"（真调，走真 router → usage 落 ok:true 行） ----------
  // 生成 96×96 纯红 PNG（PowerShell GDI+），走真网络真 key
  let realText = ''
  let realMs = null
  try {
    const pngPath = join(tmpRoot, 'red96.png')
    const ps = [
      'Add-Type -AssemblyName System.Drawing',
      '$bmp=New-Object System.Drawing.Bitmap 96,96',
      '$g=[System.Drawing.Graphics]::FromImage($bmp)',
      '$g.Clear([System.Drawing.Color]::FromArgb(255,220,20,20))',
      '$g.Dispose()',
      '$bmp.Save($env:RED_OUT,[System.Drawing.Imaging.ImageFormat]::Png)',
      '$bmp.Dispose()',
    ].join('\n')
    const { spawnSync } = await import('node:child_process')
    spawnSync('powershell.exe', ['-NoProfile', '-Command', ps], { env: { ...process.env, RED_OUT: pngPath }, timeout: 30000, encoding: 'utf8' })
    const b64 = readFileSync(pngPath).toString('base64')
    // S61：走真 router（而不是裸 invoke）→ usage.jsonl 必须出现 tier=vision/ok=true 的成功行
    const routerReal = createRouter({
      providers: { vision: visionProvider, cheap: { providerId: 'school-gateway', model: 'qwen' }, flagship: { providerId: 'deepseek-api', model: 'deepseek-chat' } },
      invoke,
      audit: () => {},
      usagePath: join(tmpRoot, 'data', 'logs', 'usage.jsonl'),
    })
    const t0 = Date.now()
    const r = await routerReal.run('extract', {
      messages: [{ role: 'user', content: [{ type: 'image_url', image_url: { url: 'data:image/png;base64,' + b64 } }, { type: 'text', text: '这张图片主要是什么颜色？只回答颜色名。' }] }],
    })
    realMs = Date.now() - t0
    realText = String(r && r.text || '')
    const usageTxt = rf(join(tmpRoot, 'data', 'logs', 'usage.jsonl'), 'utf8')
    const okRow = usageTxt.split('\n').map((l) => { try { return JSON.parse(l) } catch { return null } }).find((x) => x && x.tier === 'vision' && x.ok === true)
    check('S-1 真图（96×96 红）→ zhipu 返回含"红"的文本，且 usage 落 ok:true 成功行',
      /红/.test(realText) && !!okRow && okRow.providerId === 'zhipu',
      JSON.stringify({ text: realText.slice(0, 40), ms: realMs, usageRow: okRow }))
  } catch (e) {
    check('S-1 真图 → zhipu 返回含"红"的文本', false, 'real-call-failed: ' + String((e && e.message) || e).slice(0, 160))
  }

  // ---------- S-9 白名单前置护栏（S61：换 provider 必须同步 domains.json） ----------
  {
    const domainSrc = readFileSync(join(PROJECT_ROOT, 'packages', 'core', 'src', 'domains.json'), 'utf8')
    const domains = JSON.parse(domainSrc)
    const { isAllowedUrl } = await import('../packages/core/src/net.mjs')
    const listed = Array.isArray(domains.allowedDomains) && domains.allowedDomains.includes('open.bigmodel.cn')
    const allow = isAllowedUrl('https://open.bigmodel.cn/api/paas/v4/chat/completions')
    check('S-9 open.bigmodel.cn 必须在 domains.json 白名单且 net 判 allow（否则换 provider 必须同步白名单）',
      listed === true && allow === true,
      JSON.stringify({ listed, allow, count: (domains.allowedDomains || []).length }))
  }

  // ---------- S-2 maxTokens 下限 512 ----------
  stub(() => ({ doc: { choices: [{ message: { content: '红色' }, finish_reason: 'stop' }], usage: { total_tokens: 90 } } }))
  await invoke({ tier: 'vision', provider: visionProvider, taskClass: 'extract', payload: { messages: [{ role: 'user', content: 'x' }], maxTokens: 32 } })
  check('S-2 maxTokens<512 自动抬到 512（请求体实测）',
    calls.length === 1 && calls[0].body.max_tokens === VISION_MIN_TOKENS && VISION_MIN_TOKENS >= 512,
    JSON.stringify({ sent: calls[0] && calls[0].body && calls[0].body.max_tokens, min: VISION_MIN_TOKENS }))

  // ---------- S-3 content 空 + reasoning_content 有 → 兜底 + meta 标记 ----------
  stub(() => ({ doc: { choices: [{ message: { content: '', reasoning_content: '图片是红色的' }, finish_reason: 'stop' }] } }))
  const r3 = await invoke({ tier: 'vision', provider: visionProvider, taskClass: 'extract', payload: { messages: [{ role: 'user', content: 'x' }] } })
  check('S-3 content 空时用 reasoning_content 兜底并标注 usedReasoningFallback',
    /红色/.test(String(r3.text)) && r3.meta && r3.meta.usedReasoningFallback === true,
    JSON.stringify({ text: r3.text, meta: r3.meta }))

  // ---------- S-4 finish=length → 只调用 1 次（S62：加倍重试分支已移除，如实返回 + reasoning 兜底） ----------
  stub(() => ({ doc: { choices: [{ message: { content: '', reasoning_content: '思考…红色' }, finish_reason: 'length' }] } }))
  const r4 = await invoke({ tier: 'vision', provider: visionProvider, taskClass: 'extract', payload: { messages: [{ role: 'user', content: 'x' }], maxTokens: 512 } })
  check('S-4 finish_reason=length → 恰好 1 次请求（不重试）、reasoning 兜底生效、meta.finish 如实标 length',
    calls.length === 1 && r4.meta && r4.meta.finish === 'length' && r4.meta.usedReasoningFallback === true && /红色/.test(String(r4.text)),
    JSON.stringify({ calls: calls.length, meta: r4.meta, text: String(r4.text).slice(0, 30) }))

  // ---------- S-5 zhipu 抛错 → 回退网关 + 审计 route-fallback ----------
  const auditRows = []
  const router5 = createRouter({
    providers: { vision: visionProvider, cheap: { providerId: 'school-gateway', model: 'qwen' }, flagship: { providerId: 'deepseek-api', model: 'deepseek-chat' } },
    invoke: async ({ tier }) => {
      if (tier === 'vision') throw Object.assign(new Error('HTTP 500: boom'), { code: 'E_HTTP_500' })
      return { text: '网关兜底文本', tokens: 10 }
    },
    audit: (rec) => auditRows.push(rec),
    usagePath: join(tmpRoot, 'data', 'logs', 'usage.jsonl'),
  })
  const r5 = await router5.run('extract', { messages: [{ role: 'user', content: 'x' }] })
  const fb = auditRows.find((r) => r.kind === 'route-fallback')
  check('S-5 zhipu 失败 → 回退 school-gateway 且审计 route-fallback{from:zhipu,to:gateway}',
    r5.ok === true && r5.fallback === true && r5.tier === 'cheap' && !!fb && fb.from === 'zhipu' && fb.to === 'gateway',
    JSON.stringify({ ok: r5.ok, tier: r5.tier, fallback: r5.fallback, audit: fb && { from: fb.from, to: fb.to } }))

  // ---------- S-6 超时 ≥60s（视觉档 90s；extract 90s） ----------
  const { EXTRACT_TIMEOUT_MS } = await import('../packages/plugins/coach/extract.mjs')
  check('S-6 超时 ≥60s（VISION_TIMEOUT_MS=90s、extract=90s）',
    VISION_TIMEOUT_MS >= 60000 && EXTRACT_TIMEOUT_MS >= 60000,
    JSON.stringify({ vision: VISION_TIMEOUT_MS, extract: EXTRACT_TIMEOUT_MS }))

  // ---------- S-7 走 vision 后 sent-to-model 审计仍写入 + usage 记 tier=vision ----------
  stub(() => ({ doc: { choices: [{ message: { content: '转录文本：这是一段足够长的验收文本内容。' }, finish_reason: 'stop' }], usage: { total_tokens: 120 } } }))
  // 用真实 router（stub fetch 已在 invoke 内部生效）
  const router7 = createRouter({
    providers: { vision: visionProvider, cheap: { providerId: 'school-gateway', model: 'qwen' }, flagship: { providerId: 'deepseek-api', model: 'deepseek-chat' } },
    invoke,
    audit: () => {},
    usagePath: join(tmpRoot, 'data', 'logs', 'usage.jsonl'),
  })
  const ex7 = createExtractor({ dir: join(tmpRoot, 'data', 'coach'), trashDir: join(tmpRoot, 'data', 'trash'), router: router7 })
  // 造一张真 PNG（供 extract 读取）
  const srcPng = join(PROJECT_ROOT, 'data', 'perception', 'shots')
  let img = null
  try {
    const { readdirSync, statSync } = await import('node:fs')
    const f = readdirSync(srcPng).filter((n) => n.endsWith('.png')).map((n) => ({ n, s: statSync(join(srcPng, n)).size })).sort((a, b) => a.s - b.s)[0]
    if (f) { img = join(tmpRoot, 'frame.png'); (await import('node:fs')).copyFileSync(join(srcPng, f.n), img) }
  } catch { /* 没有现成截图 */ }
  let sentOk = false
  if (img) {
    await ex7.extract({ imagePath: img })
    const per = join(tmpRoot, 'data', 'logs', 'perception.jsonl')
    sentOk = existsSync(per) && /"kind":"sent-to-model"/.test(rf(per, 'utf8'))
  }
  const usageTxt = rf(join(tmpRoot, 'data', 'logs', 'usage.jsonl'), 'utf8')
  const visionUsage = /"tier":"vision"/.test(usageTxt)
  check('S-7 视觉档真实走通时 sent-to-model 审计仍写 + usage 记 tier=vision',
    sentOk && visionUsage, JSON.stringify({ sentOk, visionUsage }))

  // ---------- S-8 令牌桶仍生效（10 req/min） ----------
  let waits = 0
  const lim = createRateLimiter({ capPerMin: 10, now: () => 1000, sleep: async (ms) => { waits += ms } })
  for (let i = 0; i < 12; i++) await lim.acquire()
  check('S-8 令牌桶仍生效（10/min：第 11 次开始排队，配额不绕过）', waits > 0, JSON.stringify({ waits }))
} catch (e) {
  check('S-0 验收异常', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  globalThis.fetch = realFetch
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}
const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s60-glm: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exitCode = items.length - pass === 0 ? 0 : 1
