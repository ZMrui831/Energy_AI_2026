// tools/accept-s61-incremental.mjs —— S61·P0-2 方案A 验收（帧增量抽取，4 项）
//
// 判据：增量轮只入账不调旗舰 → 日报轮合并 incremental.jsonl 统一归纳 → 合并后清空不重复 →
//      同帧同文本不重复入 trajectory → 限流 5 分钟。
// 用法：node tools\accept-s61-incremental.mjs

import { mkdtempSync, rmSync, mkdirSync, writeFileSync, readFileSync, existsSync, copyFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'

const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s61-inc-'))
process.env.ORB_DATA_DIR = join(tmpRoot, 'data')
mkdirSync(join(tmpRoot, 'data', 'logs'), { recursive: true })
const coachDir = join(tmpRoot, 'data', 'coach')
mkdirSync(coachDir, { recursive: true })
mkdirSync(join(tmpRoot, 'data', 'trash'), { recursive: true })

try {
  const { createDailyPipeline } = await import('../packages/plugins/coach/daily.mjs')
  const INC = join(coachDir, 'incremental.jsonl')

  // 增量暂存账：2 行（一帧一文本，textSha256 不同）
  writeFileSync(INC, [
    JSON.stringify({ ts: '2026-10-24T12:00:00.000Z', window: '（增量抽取）', process: '（增量抽取）', frameId: 'fr-inc1', textSha256: 'aaa1', text: '增量观测一：正在写论文方法章节', source: 'vision' }),
    JSON.stringify({ ts: '2026-10-24T12:05:00.000Z', window: '（增量抽取）', process: '（增量抽取）', frameId: 'fr-inc2', textSha256: 'bbb2', text: '增量观测二：检索 2024 光伏预测文献', source: 'vision' }),
  ].join('\n'), 'utf8')

  let extractCalls = 0
  const daily = createDailyPipeline({
    dir: coachDir,
    router: { run: async (taskClass) => {
      if (taskClass === 'summarize') return { ok: true, text: JSON.stringify(['写论文', '查文献']) }
      if (taskClass === 'score-plan') return { ok: true, text: JSON.stringify({ score: 42, advice: ['继续写方法章节'] }) }
      return { ok: true, text: '' }
    } },
    extractor: { extract: async () => { extractCalls += 1; return { frameId: 'fr-live', text: '实时抓屏文本', textSha256: 'ccc3', source: 'vision' } } },
  })

  // 一张真图（供 frames 路径走通；extractor 是 stub 不真读）
  const srcPng = join(PROJECT_ROOT, 'data', 'perception', 'shots')
  let img = null
  try {
    const { readdirSync } = await import('node:fs')
    const f = readdirSync(srcPng).find((n) => n.endsWith('.png'))
    if (f) { img = join(tmpRoot, 'frame.png'); copyFileSync(join(srcPng, f), img) }
  } catch { /* 无现成截图 */ }
  const frames = img ? [{ imagePath: img, window: '（自动捕获）', process: '（自动捕获）' }] : []

  const r1 = await daily.run({ consentActive: true, frames, goal: '科研' })
  const traj = readFileSync(join(coachDir, 'trajectory.jsonl'), 'utf8').split('\n').filter((l) => l.trim()).map((l) => JSON.parse(l))

  check('I-1 增量行被合并进轨迹（2 条增量 + 1 条实时帧 = 3 条，intent 已归纳）',
    r1.ok === true && traj.length === 3 && traj.filter((t) => String(t.intent || '').length > 0).length >= 2,
    JSON.stringify({ ok: r1.ok, count: traj.length, intents: traj.map((t) => t.intent) }))
  check('I-2 增量行不重复送模（extractor 只为实时帧调用 1 次）', extractCalls === 1, JSON.stringify({ extractCalls }))
  check('I-3 合并后 incremental.jsonl 清空（下轮不重复合并）', !existsSync(INC), String(existsSync(INC)))

  // 再跑一轮（frames 同图 → 同 frameId/textSha256）→ 不重复入账（evidenceKey 去重）
  if (img) {
    await daily.run({ consentActive: true, frames, goal: '科研' })
    const traj2 = readFileSync(join(coachDir, 'trajectory.jsonl'), 'utf8').split('\n').filter((l) => l.trim()).map((l) => JSON.parse(l))
    check('I-4 同帧同文本不重复入 trajectory（evidenceKey 去重）', traj2.length === 3, JSON.stringify({ before: traj.length, after: traj2.length }))
  } else {
    check('I-4 同帧同文本不重复入 trajectory', true, 'skipped：无现成截图（本机 data/perception/shots 为空）')
  }

  // 限流常量（源码断言 5 分钟）
  const src = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'index.mjs'), 'utf8')
  check('I-5 增量轮限流 5 分钟（INCREMENTAL_MIN_INTERVAL_MS = 5×60×1000，轮询 60s）',
    /INCREMENTAL_MIN_INTERVAL_MS = 5 \* 60 \* 1000/.test(src) && /setInterval\(async \(\) => \{[\s\S]{0,1200}incrementalBusy/.test(src), 'yes')
} catch (e) {
  check('I-0 验收异常', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}
const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s61-incremental: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exitCode = items.length - pass === 0 ? 0 : 1
