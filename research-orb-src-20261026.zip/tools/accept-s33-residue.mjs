// tools/accept-s33-residue.mjs —— S33·D 残留清理自动化验收（≥4 项）。
// 单行复跑：node tools\accept-s33-residue.mjs
// 证据：data\logs\s33-residue-accept.json
//
// 覆盖：清理 test-b4-* 与 .retired/test-b4-* 与 data/tmp 的 test-/probe-/s2* /
//      清后不存在 / 非测试目录保留 / 二次运行幂等 / 测试文件接线（after() + 断言；run-tests 调用）。
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { cleanResidue } from './clean-test-residue.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

function seed(root) {
  const mk = (p, body = 'x') => { mkdirSync(p, { recursive: true }); writeFileSync(join(p, 'f.txt'), body) }
  mk(join(root, 'packages', 'plugins', 'test-b4-a'))
  mk(join(root, 'packages', 'plugins', '.retired', 'test-b4-b'))
  mk(join(root, 'data', 'tmp', 'test-old'))
  mk(join(root, 'data', 'tmp', 'probe-x'))
  mk(join(root, 'data', 'tmp', 's25-y'))
  mk(join(root, 'data', 'tmp', 'keep-me'))
}

try {
  const root = mkdtempSync(join(tmpdir(), 'orb-residue-'))
  try {
    seed(root)
    const r1 = cleanResidue({ root })

    // D1：清理了全部 residue（before 有、after=0）
    check('D1', r1.before > 0 && r1.after === 0, `before=${r1.before} after=${r1.after} removed=${r1.removed.length}`, { removed: r1.removed })

    // D2：目标目录确实不存在
    const gone = [
      !existsSync(join(root, 'packages', 'plugins', 'test-b4-a')),
      !existsSync(join(root, 'packages', 'plugins', '.retired', 'test-b4-b')),
      !existsSync(join(root, 'data', 'tmp', 'test-old')),
      !existsSync(join(root, 'data', 'tmp', 'probe-x')),
      !existsSync(join(root, 'data', 'tmp', 's25-y')),
    ].every(Boolean)
    check('D2', gone, `test-b4-a/.retired-b/test-old/probe-x/s25-y 均已不存在=${gone}`, {})

    // D3：非测试目录保留（keep-me 不动）
    check('D3', existsSync(join(root, 'data', 'tmp', 'keep-me', 'f.txt')), `keep-me 保留=${existsSync(join(root, 'data', 'tmp', 'keep-me', 'f.txt'))}`, {})

    // D4：二次运行幂等（before=0、removed=0）
    const r2 = cleanResidue({ root })
    check('D4', r2.before === 0 && r2.removed.length === 0, `second before=${r2.before} removed=${r2.removed.length}`, {})
  } finally {
    try { rmSync(root, { recursive: true, force: true }) } catch { /* 尽力 */ }
  }

  // D5：测试文件接线（skill-installer 有 after() + 断言；run-tests 调 cleanResidue）
  const si = readFileSync(join(PROJECT_ROOT, 'tests', 'skill-installer.test.mjs'), 'utf8')
  const rt = readFileSync(join(PROJECT_ROOT, 'tools', 'run-tests.mjs'), 'utf8')
  const siAfter = /after\s*\(/.test(si) && /startsWith\('test-b4-'\)/.test(si) && /测试残留必须清空/.test(si)
  const rtHas = /cleanResidue\s*\(/.test(rt)
  check('D5', siAfter && rtHas, `skill-after=${siAfter} run-tests-clean=${rtHas}`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(join(PROJECT_ROOT, 'data', 'logs', 's33-residue-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s33-residue: total=${items.length} pass=${pass} fail=${items.length - pass}`)
console.log('  # 证据 -> data/logs/s33-residue-accept.json')
process.exit(pass === items.length ? 0 : 1)
