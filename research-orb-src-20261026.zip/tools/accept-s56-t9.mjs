// tools/accept-s56-t9.mjs —— S56·四 T9 可发现：会话回声检测/清理/备份（≥3 项）
//
// 判据：启动检测能数出待清理项 → 清理时先导出备份再删 → 清理后计数为 0 → 不静默（结果可回读）。
// 做法：造一个临时 sqlite（含 2 条回声 + 1 条正常行）→ scanSessionEcho / purgeSessionEcho 真跑。
// 用法：node tools\accept-s56-t9.mjs

import './_accept-isolate.mjs' // S67·3-A：先于产品模块求值，把 data/logs 指到临时目录
import { mkdtempSync, rmSync, existsSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import { DatabaseSync } from 'node:sqlite'

const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s56-t9-'))
const dbPath = join(tmpRoot, 'orb.sqlite')
const backupDir = join(tmpRoot, 'db')

try {
  // 造库：session_turn(text) 里有 2 条回声 + 1 条正常
  const db = new DatabaseSync(dbPath)
  db.exec('CREATE TABLE session_turn (id TEXT, text TEXT)')
  const ins = db.prepare('INSERT INTO session_turn (id, text) VALUES (?, ?)')
  ins.run('t1', '轨迹（20261024）：今天还没有片段。')
  ins.run('t2', '今天还没有片段')
  ins.run('t3', '这是一条正常的学习记录，不该被删。')
  db.close()

  const { scanSessionEcho, purgeSessionEcho } = await import('../packages/core/src/lifecycle/session-echo.mjs')

  const s1 = scanSessionEcho(dbPath)
  check('T9-1 启动检测能数出待清理项（只读，不动库）', s1.ok === true && s1.count === 2,
    JSON.stringify({ ok: s1.ok, count: s1.count, sample: s1.plan && s1.plan[0] && s1.plan[0].text }))

  const p = purgeSessionEcho(dbPath, backupDir)
  check('T9-2 清理先导出备份再删（backupPath 存在且含 plan）',
    p.ok === true && p.purged === 2 && !!p.backupPath && existsSync(p.backupPath) &&
    JSON.parse(readFileSync(p.backupPath, 'utf8')).count === 2,
    JSON.stringify({ ok: p.ok, purged: p.purged, backup: p.backupPath && p.backupPath.split('\\').pop() }))

  const s2 = scanSessionEcho(dbPath)
  // 正常行必须还在（只删命中行）
  const db2 = new DatabaseSync(dbPath)
  const left = db2.prepare('SELECT id FROM session_turn').all().map((r) => r.id)
  db2.close()
  check('T9-3 清理后回声归零、正常行完好（不静默删数据）',
    s2.ok === true && s2.count === 0 && left.length === 1 && left[0] === 't3',
    JSON.stringify({ count: s2.count, left }))
} catch (e) {
  check('T9-0 验收异常', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}
const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s56-t9: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exitCode = items.length - pass === 0 ? 0 : 1
