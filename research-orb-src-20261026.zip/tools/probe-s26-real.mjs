// tools/probe-s26-real.mjs —— S26·P0 实机验收：真 Electron 跑一轮教练流水线。
// 单行复跑：node tools\probe-s26-real.mjs （已有本应用实例在跑则先 node tools\stop-app.mjs）
//
// 取证口径（与 probe-s23-real 同款）：
//   · 命令走渲染层 IPC：api.send('ui',{type:'plugin:command',...})（面板按钮同一条上行通道）；
//   · 结果回读读应用自己落盘：trajectory.jsonl / daily-*.md / coach.jsonl / usage.jsonl；
//   · consent 临时置 metadata-only + summary 20s（跑完 finally 原样还原）；goal.json 同样备份还原；
//   · 结束只杀自己起的进程树；证据落 data/logs/s26-real.json。
import { spawn, spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync, statSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { makeQuotaSleeper } from './_quota-sleep.mjs'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('probe-s26-real')

const ELECTRON_EXE = ORB_ELECTRON
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9348
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const awaitQuotaWindow = makeQuotaSleeper({ sleep })
const CFG = join(PROJECT_ROOT, 'data', 'perception-config.json')
const GOAL_FILE = join(PROJECT_ROOT, 'data', 'coach', 'goal.json')
const COACH_DIR = join(PROJECT_ROOT, 'data', 'coach')
const SHOTS = join(PROJECT_ROOT, 'data', 'shots')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 240), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

let cdp = null
async function findTarget(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await res.json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(t.url))
      if (page) return page
    } catch { /* 还没起来 */ }
    await sleep(300)
  }
  throw new Error(`CDP 目标未找到（port ${PORT}）`)
}
function connect(url) {
  return new Promise((res, rej) => {
    const ws = new WebSocket(url)
    let seq = 0
    const pending = new Map()
    ws.addEventListener('open', () => res({
      send(method, params = {}) {
        const id = ++seq
        return new Promise((ok, no) => {
          const timer = setTimeout(() => { if (pending.has(id)) { pending.delete(id); no(new Error(`CDP 超时 ${method}`)) } }, 30000)
          pending.set(id, { ok: (v) => { clearTimeout(timer); ok(v) }, no: (e) => { clearTimeout(timer); no(e) } })
          ws.send(JSON.stringify({ id, method, params }))
        })
      },
      close: () => ws.close(),
    }))
    ws.addEventListener('error', (e) => rej(new Error('ws error: ' + (e && e.message))))
    ws.addEventListener('message', (ev) => {
      let msg = null
      try { msg = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
      const p = pending.get(msg.id)
      if (!p) return
      pending.delete(msg.id)
      if (msg.error) p.no(new Error(JSON.stringify(msg.error)))
      else p.ok(msg.result)
    })
  })
}
async function evalJs(body) {
  if (!cdp) throw new Error('CDP 未连接')
  const r = await cdp.send('Runtime.evaluate', { expression: `(async function(){ ${body} })()`, awaitPromise: true, returnByValue: true })
  if (r && r.exceptionDetails) throw new Error('renderer 异常：' + JSON.stringify((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails))
  return r && r.result ? r.result.value : undefined
}

function trajectoryCount() {
  try {
    const f = join(COACH_DIR, 'trajectory.jsonl')
    if (!existsSync(f)) return 0
    return readFileSync(f, 'utf8').split('\n').filter((l) => l.trim()).length
  } catch { return 0 }
}
function dayStamp(ts) {
  const d = new Date(ts)
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}`
}
function runningOwnApp() {
  try {
const out = countOrbAll()
    return Number(String(out).trim()) > 0
  } catch { return true }
}
function execFileSyncPs(cmd) {
  return spawnSync('powershell.exe', ['-NoProfile', '-Command', cmd], { encoding: 'utf8' }).stdout || ''
}

async function sendCommand(name, args) {
  return evalJs(`globalThis.researchOrb.send('ui', { type: 'plugin:command', name: ${JSON.stringify(name)}, args: ${JSON.stringify(args)}, at: Date.now() }); return true`)
}
async function setupCapture() {
  await evalJs(`
    globalThis.__s26cap = []
    globalThis.__s26un = globalThis.researchOrb.on((msg) => {
      try {
        if (msg && (msg.type === 'chat:done' || msg.type === 'chat:delta')) globalThis.__s26cap.push({ text: String(msg.text || ''), at: Date.now() })
        if (msg && msg.type === 'chat:notice') globalThis.__s26cap.push({ text: String(msg.message || ''), at: Date.now() })
      } catch (e) {}
    })
    return true
  `)
}
async function waitChat(marker, sinceMs, timeoutMs = 20000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const caps = await evalJs(`return (globalThis.__s26cap || []).filter(x => x.at >= ${sinceMs}).map(x => x.text)`)
      const hit = (caps || []).find((t) => t.includes(marker))
      if (hit) return hit
    } catch { /* 重试 */ }
    await sleep(500)
  }
  return null
}

async function main() {
  console.log('# S26·P0 实机验收（真 Electron 跑一轮教练流水线）')
  if (runningOwnApp()) { check('P-pre fail-closed', false, '已有本应用实例在跑：先 stop-app'); throw new Error('fail-closed') }
  check('P-pre 无残留本应用实例（fail-closed）', true, '未发现运行中的本应用实例')

  // S31·B2：配额静默期——两次探针连跑时，上一轮 9 请求可能仍占 10/min 令牌窗；
  // 静默 45s 让配额窗过去，避免本轮请求全部排队（否则单轮被桶拖到 20s+）。
  // 现统一走 tools/_quota-sleep.mjs（覆盖所有 s31 探针 + 既有 probe-s26-real）。
  await awaitQuotaWindow()

  const cfgBefore = existsSync(CFG) ? readFileSync(CFG, 'utf8') : null
  const goalBefore = existsSync(GOAL_FILE) ? readFileSync(GOAL_FILE, 'utf8') : null
  let cfgObj = {}
  try { cfgObj = cfgBefore ? JSON.parse(cfgBefore) : {} } catch { cfgObj = {} }
  cfgObj.consent = { ...(cfgObj.consent || {}), mode: 'metadata-only', grantedAt: Date.now(), expiresAt: null }
  cfgObj.summary = { ...(cfgObj.summary || {}), intervalMs: 20000 }
  writeFileSync(CFG, JSON.stringify(cfgObj, null, 2), 'utf8')

  const launchTs = Date.now()
  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN_MJS], { cwd: PROJECT_ROOT, env: childEnv, stdio: 'ignore' })
  let killed = false
  const killOwn = () => { if (killed) return; killed = true; try { spawnSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore' }) } catch {} }

  try {
    const target = await findTarget()
    cdp = await connect(target.webSocketDebuggerUrl)
    await cdp.send('Page.enable'); await cdp.send('Runtime.enable')
    const bridgeOk = await (async () => {
      const dl = Date.now() + 25000
      while (Date.now() < dl) {
        try { if (await evalJs(`return typeof globalThis.researchOrb === 'object' && !!globalThis.researchOrb`)) return true } catch {}
        await sleep(500)
      }
      return false
    })()
    check('P1 真实应用启动 + researchOrb 桥注入', bridgeOk, `port=${PORT}`)
    await setupCapture()
    await evalJs(`globalThis.researchOrb.send('window', { action: 'expand' }); return true`)
    await sleep(800)

    // ② 调度器宿主接线：/coach status 显示运行中
    const t0 = Date.now()
    await sendCommand('coach', 'status')
    const st = await waitChat('全能教练状态', t0)
    check('P2 宿主接线：调度器运行中（启动即挂）', !!st && /调度器：运行中/.test(st), (st || '').split('\n')[2] || '')

    // ③ 设目标（真实命令；带本次运行唯一后缀——否则开机恢复的同一界面会让第 1 轮抓屏与上一次探针的帧相同而被去重）
    const runTag = 'S27-' + String(Date.now() % 1000000)
    await sendCommand('coach', 'goal set 两天内完成微电网综述第二章并补齐证据链（' + runTag + '）')
    const goalSet = await waitChat('目标已设定', t0)
    check('P3 /coach goal set（真 UI 通道）', !!goalSet)

    // ④ 三轮 run-daily：每轮换屏幕内容（/usage 计数逐轮不同 → 保证帧内容相异、不被去重）
    // 对齐口径：轮询 trajectory.jsonl 行数增量（比 chat 文本可靠；第 1 轮冷启动+全屏视觉可到 ~2 分钟）
    const trajBase = trajectoryCount()
    let completed = 0
    for (let i = 0; i < 3; i++) {
      await sendCommand('usage', '') // 屏幕内容随累计计数变化 → 各轮抓屏相异
      await sleep(1200)
      const before = trajectoryCount()
      const tr = Date.now()
      await sendCommand('coach', 'run-daily 1')
      const dl = Date.now() + 200000
      let grew = false
      while (Date.now() < dl) {
        if (trajectoryCount() > before) { grew = true; break }
        await sleep(1000)
      }
      if (grew) completed += 1
      const done = await waitChat('本轮流水线完成', tr, 5000)
      check(`P4.${i + 1} 第 ${i + 1} 轮 run-daily 完成（真实抓屏→extract→轨迹→日报）`, grew, grew ? `轨迹 ${before}→${trajectoryCount()} 行${done ? '' : '（回执迟到）'}` : '200s 内轨迹未增长')
      await sleep(6000) // 轮间隔 6s：错开令牌桶补充节奏
    }

    // ⑤ 断言：本轮轨迹净增 ≥3 行（相对轮前基线）
    const tc = trajectoryCount() - trajBase
    check('P5 trajectory.jsonl 本轮净增 ≥3 行（实机真轨迹）', tc >= 3, `净增 ${tc} 行（基线 ${trajBase} → ${trajectoryCount()}）`)

    // ⑥ 日报可追溯
    const reportPath = join(COACH_DIR, 'daily', `daily-${dayStamp(Date.now())}.md`)
    let reportOk = false
    let reportDetail = ''
    if (existsSync(reportPath)) {
      const md = readFileSync(reportPath, 'utf8')
      const rows = md.split('\n').filter((l) => l.startsWith('| 2026-'))
      const trajRows = existsSync(join(COACH_DIR, 'trajectory.jsonl'))
        ? readFileSync(join(COACH_DIR, 'trajectory.jsonl'), 'utf8').split('\n').filter((l) => l.trim()).map((l) => JSON.parse(l))
        : []
      const last3 = trajRows.slice(-3)
      reportOk = rows.length >= 3 && last3.every((t) => md.includes(t.evidence.frameId) && md.includes(t.evidence.textSha256.slice(0, 16)))
      reportDetail = `日报行数=${rows.length}，每条可回指=${reportOk}`
    }
    check('P6 日报生成且每行带 frameId+textSha256（可追溯）', reportOk, reportDetail || reportPath)

    // ⑦ 原图已删 + 审计
    const auditText = existsSync(join(PROJECT_ROOT, 'data', 'logs', 'coach.jsonl')) ? readFileSync(join(PROJECT_ROOT, 'data', 'logs', 'coach.jsonl'), 'utf8') : ''
    const frameRows = auditText.split('\n').filter((l) => l.includes('frame-processed')).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean).filter((r) => Date.parse(r.ts) >= launchTs)
    check('P7 coach.jsonl 有 frame-processed（原图已删，审计齐）', frameRows.length >= 3 && frameRows.every((r) => r.ok === true && r.deletedAt && r.textSha256), `本轮 ${frameRows.length} 行`)

    // ⑧ usage 新增 taskClass 行
    const usageRows = (() => {
      try { return readFileSync(join(PROJECT_ROOT, 'data', 'logs', 'usage.jsonl'), 'utf8').split('\n').filter((l) => l.trim()).map((l) => JSON.parse(l)) } catch { return [] }
    })().filter((r) => Date.parse(r.ts) >= launchTs)
    const classes = new Set(usageRows.map((r) => r.taskClass))
    check('P8 usage.jsonl 新增行含 extract/summarize/score-plan', usageRows.length >= 6 && classes.has('extract') && classes.has('summarize') && classes.has('score-plan'), `新增 ${usageRows.length} 行，档位=${[...classes].join(',')}`)

    // ⑨ 实机截图取证
    const shot = await cdp.send('Page.captureScreenshot', { format: 'png' })
    const pngPath = join(SHOTS, 's26-real-daily.png')
    mkdirSync(SHOTS, { recursive: true })
    writeFileSync(pngPath, Buffer.from(shot.data, 'base64'))
    check('P9 实机截图取证（data/shots/s26-real-daily.png）', existsSync(pngPath) && statSync(pngPath).size > 1000, `bytes=${statSync(pngPath).size}`)

    // ⑩ 降级实测：consent 还原 denied → 再触发 → 拒绝 + 审计
    writeFileSync(CFG, cfgBefore === null ? JSON.stringify({ version: 1 }, null, 2) : cfgBefore, 'utf8')
    const cfgAfter = existsSync(CFG) ? readFileSync(CFG, 'utf8') : ''
    check('P10 consent 已还原为原值（denied）', cfgBefore !== null ? cfgAfter === cfgBefore : true, 'perception-config.json 字节级一致')
    const td = Date.now()
    await sendCommand('coach', 'run-daily 1')
    await sleep(3000)
    const auditNow = (existsSync(join(PROJECT_ROOT, 'data', 'logs', 'coach.jsonl')) ? readFileSync(join(PROJECT_ROOT, 'data', 'logs', 'coach.jsonl'), 'utf8') : '')
    const skipAudit = auditNow.includes('"kind":"skipped-no-consent"') && auditNow.includes('"why":"coach-run-daily"')
    const notice = await waitChat('未执行', td, 15000)
    // 审计为硬证据（任务书口径：跳过+审计）；UI 回执为佐证（迟到不判负）
    check('P11 降级实测：denied 下 run-daily 被拒 + 审计 skipped-no-consent', skipAudit, skipAudit ? (notice ? notice.slice(0, 70) : '审计行已见（UI 回执迟到，不影响判定）') : '审计缺失')
  } catch (e) {
    check('P0 探针异常', false, String((e && e.stack) || e).slice(0, 240))
  } finally {
    killOwn()
    await sleep(1200)
    // 还原 consent + goal（D21/D22 + 任务书 finally 还原要求）
    try { writeFileSync(CFG, cfgBefore === null ? JSON.stringify({ version: 1 }, null, 2) : cfgBefore, 'utf8') } catch {}
    try {
      if (goalBefore === null) { if (existsSync(GOAL_FILE)) spawnSync('cmd', ['/c', 'del', '/f', GOAL_FILE], { stdio: 'ignore' }) } else { writeFileSync(GOAL_FILE, goalBefore, 'utf8') }
    } catch {}
    const cfgFinal = existsSync(CFG) ? readFileSync(CFG, 'utf8') : ''
    check('P12 finally 还原：consent 与 goal 均已复位', cfgBefore !== null ? cfgFinal === cfgBefore : true)
  }

  const pass = items.filter((i) => i.ok).length
  const fail = items.length - pass
  const out = { tool: 'probe-s26-real', at: new Date().toISOString(), total: items.length, pass, fail, items }
  const outPath = join(PROJECT_ROOT, 'data', 'logs', 's26-real.json')
  mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
  writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
  console.log(`\n  # probe-s26-real: total=${items.length} pass=${pass} fail=${fail}`)
  console.log(`  # 证据 -> data/logs/s26-real.json`)
  process.exit(fail === 0 ? 0 : 1)
}

main().catch((e) => { console.error('FATAL', (e && e.message) || e); process.exit(1) })
