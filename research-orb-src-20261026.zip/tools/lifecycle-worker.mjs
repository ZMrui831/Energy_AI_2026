#!/usr/bin/env node
// tools/lifecycle-worker.mjs —— S3 清理状态机的可复跑 CLI 入口（判据 1/2/5 验收工具）。
//
// 用法（node:sqlite 需要 Node>=23.4，请用 D:\node.exe 运行；Node 22 探测失败时
// store 自动降级 jsonl——判据 7 场景，功能等价）：
//   D:\node.exe tools\lifecycle-worker.mjs --once          跑一轮清理，打印一行 JSON 汇总后退出
//   D:\node.exe tools\lifecycle-worker.mjs --loop          60s 间隔循环，Ctrl-C 干净退出
//   D:\node.exe tools\lifecycle-worker.mjs --stats         各表计数 + shots/db 磁盘字节（JSON）
//   D:\node.exe tools\lifecycle-worker.mjs --audit-report  只读：统计 data/logs/writes.jsonl 里
//                                                          path 不以盘符开头的记录条数并打印明细（不改写）
// 可注入参数（验收在隔离夹具跑，不污染真实 data）：
//   --db <path> --shots-dir <path> --trash-dir <path> --config <path>
//
// 退出码：0 正常；清理中未处理异常 1。
// 本 worker 的运行审计只 append 单行 JSON 到 data/logs/lifecycle.jsonl
// （B 路的轮转记录也写它，双方都只 append，不重写整文件）。

import { appendJsonl, PROJECT_ROOT, WRITES_LOG } from '../packages/core/src/safefs.mjs'
import { createStore, DEFAULT_LIFECYCLE_CONFIG, mergeLifecycleConfig } from '../packages/core/src/db.mjs'
import { runCleanup } from '../packages/core/src/lifecycle/cleaner.mjs'
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { dirname, isAbsolute, join, resolve } from 'node:path'

const LOOP_INTERVAL_MS = 60_000
const AUDIT_REPORT_DETAIL_CAP = 1000

function parseArgs(argv) {
  const flags = new Set()
  const opts = {}
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]
    if (a === '--once' || a === '--loop' || a === '--stats' || a === '--audit-report') {
      flags.add(a)
    } else if (a === '--db' || a === '--shots-dir' || a === '--trash-dir' || a === '--config') {
      const v = argv[++i]
      if (v === undefined) throw new Error(`参数 ${a} 缺少值`)
      opts[a.slice(2)] = v
    } else {
      throw new Error(`未知参数：${a}`)
    }
  }
  return { flags, opts }
}

/** 加载生命周期配置：--config 优先；否则 data/lifecycle-config.json 存在则用之；再否则默认值。 */
function loadConfig(explicitPath) {
  if (explicitPath) {
    if (!existsSync(explicitPath)) throw new Error(`--config 指定的文件不存在：${explicitPath}`)
    return mergeLifecycleConfig(JSON.parse(readFileSync(explicitPath, 'utf8')))
  }
  const p = join(PROJECT_ROOT, 'data', 'lifecycle-config.json')
  if (existsSync(p)) {
    return mergeLifecycleConfig(JSON.parse(readFileSync(p, 'utf8')))
  }
  return mergeLifecycleConfig(DEFAULT_LIFECYCLE_CONFIG)
}

/** 目录字节总量（递归）。 */
function dirBytes(dir) {
  if (!dir || !existsSync(dir)) return 0
  let total = 0
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, e.name)
    if (e.isDirectory()) total += dirBytes(p)
    else {
      try { total += statSync(p).size } catch { /* 竞态删除容忍 */ }
    }
  }
  return total
}

async function cmdStats({ dbPath, shotsDir }) {
  const store = await createStore({ driver: 'auto', dbPath, dataDir: dirname(dbPath) })
  store.initMigrations() // 幂等：fresh db 也要先建表才能 counts
  const counts = store.counts()
  const out = {
    driver: store.driver,
    counts,
    disk: {
      dbBytes: dirBytes(dirname(dbPath)),
      shotsBytes: dirBytes(shotsDir),
    },
  }
  store.close()
  return out
}

/** 只读审计报告：writes.jsonl 里 path 不以盘符开头的行 = 相对路径写入（历史上游不明）。 */
function cmdAuditReport() {
  const file = WRITES_LOG
  if (!existsSync(file)) {
    return { file, exists: false, totalLines: 0, relativeCount: 0, relative: [], truncated: false }
  }
  const text = readFileSync(file, 'utf8')
  const relative = []
  let totalLines = 0
  for (const line of text.split('\n')) {
    const s = line.trim()
    if (!s) continue
    totalLines += 1
    let rec
    try { rec = JSON.parse(s) } catch { continue }
    if (rec && typeof rec.path === 'string' && !isAbsolute(rec.path) && !/^[a-zA-Z]:[\\/]/.test(rec.path)) {
      relative.push({ ts: rec.ts ?? null, path: rec.path, bytes: rec.bytes ?? null })
    }
  }
  const truncated = relative.length > AUDIT_REPORT_DETAIL_CAP
  return {
    file,
    exists: true,
    totalLines,
    relativeCount: relative.length,
    relative: truncated ? relative.slice(0, AUDIT_REPORT_DETAIL_CAP) : relative,
    truncated,
  }
}

async function main() {
  const { flags, opts } = parseArgs(process.argv.slice(2))
  if (flags.size === 0) {
    process.stdout.write('用法：lifecycle-worker --once | --loop | --stats | --audit-report [--db path] [--shots-dir path] [--trash-dir path] [--config path]\n')
    return
  }
  const dbPath = resolve(opts.db ?? join(PROJECT_ROOT, 'data', 'db', 'orb.sqlite'))
  const shotsDir = resolve(opts['shots-dir'] ?? join(PROJECT_ROOT, 'data', 'shots'))
  const trashDir = resolve(opts['trash-dir'] ?? join(PROJECT_ROOT, 'data', 'trash'))
  const config = loadConfig(opts.config)

  if (flags.has('--stats')) {
    process.stdout.write(JSON.stringify(await cmdStats({ dbPath, shotsDir })) + '\n')
    return
  }
  if (flags.has('--audit-report')) {
    process.stdout.write(JSON.stringify(cmdAuditReport()) + '\n')
    return
  }

  const store = await createStore({ driver: 'auto', dbPath, dataDir: dirname(dbPath), config })
  store.initMigrations()
  try {
    appendJsonl(join(PROJECT_ROOT, 'data', 'logs', 'lifecycle.jsonl'), {
      ts: new Date().toISOString(),
      kind: 'lifecycle-worker-start',
      driver: store.driver,
      mode: flags.has('--loop') ? 'loop' : 'once',
      db_path: dbPath,
    })
  } catch { /* 审计失败不阻塞清理 */ }

  if (flags.has('--loop')) {
    let stopping = false
    const stop = () => { stopping = true }
    process.on('SIGINT', stop)
    process.on('SIGTERM', stop)
    process.stdout.write(`lifecycle-worker: loop 模式（${LOOP_INTERVAL_MS / 1000}s 间隔，Ctrl-C 退出），driver=${store.driver}\n`)
    while (!stopping) {
      try {
        const r = await runCleanup({ store, config, shotsDir, trashDir })
        process.stdout.write(JSON.stringify({ ...r, driver: store.driver }) + '\n')
      } catch (e) {
        process.stderr.write(`lifecycle-worker: 本轮清理失败：${e && e.message}\n`)
      }
      if (stopping) break
      await new Promise((ok) => setTimeout(ok, LOOP_INTERVAL_MS))
    }
    store.close()
    process.stdout.write('lifecycle-worker: 干净退出\n')
    return
  }

  // --once
  const result = await runCleanup({ store, config, shotsDir, trashDir })
  process.stdout.write(JSON.stringify({ ...result, driver: store.driver }) + '\n')
  store.close()
}

main().catch((e) => {
  process.stderr.write(`lifecycle-worker: ${e && e.stack ? e.stack : e}\n`)
  process.exit(1)
})
