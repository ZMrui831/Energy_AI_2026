// tools/accept-smoke-electron.mjs —— P-R4 总验收 item 6：真实 electron 冒烟 + GUI 截图
//
// 验证目标（逐条取证，落 data/logs/stage4-final-electron.txt）：
//   1) bridge-injected 无异常（renderer console 无 Uncaught；含 "bridge-injected" 字样）
//   2) ui.jsonl 有 ping（或至少一条 GUI 上行事件）
//   3) settings 往返：expand → 权限按钮 → ro-settings.ro-open 为真
//   4) 截图：设置页版本 / 文献卡 / 计时卡 → data/shots/stage4-final-*.png
//
// 纪律：fail-closed（已有 research-orb electron 在跑则退出）；结束时只杀自己起的进程。

import { spawn, spawnSync } from 'node:child_process'
import { existsSync, readFileSync, writeFileSync, appendFileSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT, safeWrite } from '../packages/core/src/safefs.mjs'
import {killMarked, countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-smoke-electron')

const ELECTRON_EXE = ORB_ELECTRON
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const SHOTS = join(PROJECT_ROOT, 'data', 'shots')
const LOG = join(PROJECT_ROOT, 'data', 'logs', 'stage4-final-electron.txt')
const PORT = 9333
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const OUT = []
const log = (s) => { OUT.push(s); console.log(s) }

// --- CDP 最小客户端 ---
async function findTarget(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await res.json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(t.url))
      if (page) return page
    } catch { /* 还没起来 */ }
    await sleep(300)
  }
  throw new Error(`CDP 目标未找到（port ${PORT}）`)
}
let cdp = null
let consoleEvents = []
async function connectCdp() {
  const target = await findTarget()
  const c = await connect(target.webSocketDebuggerUrl)
  await c.send('Page.enable')
  await c.send('Runtime.enable')
  c.ws.addEventListener('message', (ev) => {
    try {
      const m = JSON.parse(ev.data)
      if (m.method === 'Runtime.consoleAPICalled') {
        const text = (m.params.args || []).map((a) => a.value ?? (a.description || '')).join(' ')
        consoleEvents.push({ type: m.params.type, text })
      }
    } catch { /* ignore */ }
  })
  return c
}
async function ensureCdp() {
  if (cdp) {
    try { await cdp.send('Runtime.evaluate', { expression: '1', returnByValue: true }); return cdp }
    catch { try { cdp.close() } catch {} cdp = null }
  }
  cdp = await connectCdp()
  return cdp
}
async function evalJs(body) {
  const c = await ensureCdp()
  let r
  try {
    r = await c.send('Runtime.evaluate', { expression: `(async function(){ ${body} })()`, awaitPromise: true, returnByValue: true })
  } catch (err) {
    try { cdp.close() } catch {}
    cdp = null
    const c2 = await ensureCdp()
    r = await c2.send('Runtime.evaluate', { expression: `(async function(){ ${body} })()`, awaitPromise: true, returnByValue: true })
  }
  if (r && r.exceptionDetails) throw new Error('renderer 异常：' + JSON.stringify((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails))
  return r && r.result ? r.result.value : undefined
}
function connect(url) {
  return new Promise((res, rej) => {
    const ws = new WebSocket(url)
    let seq = 0
    const pending = new Map()
    ws.addEventListener('open', () => res({
      get ws() { return ws },
      send(method, params = {}) {
        const id = ++seq
        return new Promise((ok, no) => {
          const timer = setTimeout(() => { if (pending.has(id)) { pending.delete(id); no(new Error(`CDP 超时 ${method}`)) } }, 30000)
          pending.set(id, { ok: (v) => { clearTimeout(timer); ok(v) }, no: (e) => { clearTimeout(timer); no(e) } })
          ws.send(JSON.stringify({ id, method, params }))
        })
      },
      close: () => ws.close(),
    }))
    ws.addEventListener('error', (e) => rej(new Error(`ws error: ${e && e.message}`)))
    ws.addEventListener('message', (ev) => {
      let msg = null
      try { msg = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
      const p = pending.get(msg.id)
      if (!p) return
      pending.delete(msg.id)
      if (msg.error) p.no(new Error(JSON.stringify(msg.error)))
      else p.ok(msg.result)
    })
  })
}
const sendWindow = (action) => evalJs(`globalThis.researchOrb.send('window', { action: ${JSON.stringify(action)} })`)
const sendCommand = (name, args) => evalJs(`globalThis.researchOrb.send('ui', { type: 'plugin:command', name: ${JSON.stringify(name)}, args: ${JSON.stringify(args || '')} })`)
async function shot(name) {
  const c = await ensureCdp()
  const s = await c.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
  if (!s || !s.data) throw new Error('截图失败')
  const abs = join(SHOTS, name)
  writeFileSync(abs, Buffer.from(s.data, 'base64'))
  log(`shot: data/shots/${name} (${Buffer.from(s.data, 'base64').length} bytes)`)
  return `data/shots/${name}`
}
function killOwnElectron() { return killMarked(MARK) }

const RESULT = { at: new Date().toISOString(), bridgeInjected: false, uncaught: [], uiPing: false, settingsRoundTrip: false, shots: [] }

try {

  if (countOrbAll()> 0) { RESULT.error = '已有 research-orb electron 在运行（fail-closed）'; throw new Error(RESULT.error) }

  const childEnv = { ...process.env, RESEARCH_ORB_TIME_SCALE: '2' }
  delete childEnv.ELECTRON_RUN_AS_NODE
  const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN_MJS], { cwd: PROJECT_ROOT, env: childEnv, stdio: 'ignore' })
  log(`electron pid=${child.pid}`)

  await ensureCdp()
  const bridgeReady = await (async () => {
    const deadline = Date.now() + 25000
    while (Date.now() < deadline) {
      try { if (await evalJs(`return typeof globalThis.researchOrb === 'object' && !!globalThis.researchOrb`)) return true } catch {}
      await sleep(500)
    }
    return false
  })()
  if (!bridgeReady) throw new Error('researchOrb 桥未注入（25s）')
  log('bridge 就绪')

  await sleep(6000) // 让 ping 产生

  // 1) bridge-injected + 无 Uncaught
  //
  // 【P-R5 修正】判据来源：main.mjs 的 injectUiBridge() 用 appLog() 把事件写进
  // data\logs\app.jsonl（**文件**），并不会出现在 renderer console 里。旧断言去 grep
  // consoleEvents，因此在桥**确实注入成功**时也会报 false（假阴性）。
  // 现改为以 app.jsonl 为准，并辅以桥自身的可观测性（globalThis.researchOrb 已在上面验证就绪）。
  const appLogPath = join(PROJECT_ROOT, 'data', 'logs', 'app.jsonl')
  let appBridgeInjected = false
  let appBridgeBytes = 0
  let appBridgeFailed = 0
  if (existsSync(appLogPath)) {
    const appLines = readFileSync(appLogPath, 'utf8').split('\n').filter(Boolean).slice(-300)
    for (const l of appLines) {
      let o = null
      try { o = JSON.parse(l) } catch { continue }
      if (o.type === 'bridge-injected') { appBridgeInjected = true; appBridgeBytes = Number(o.bytes) || 0 }
      if (o.type === 'bridge-inject-failed') appBridgeFailed += 1
    }
  }
  RESULT.bridgeInjected = appBridgeInjected
  RESULT.bridgeBytes = appBridgeBytes
  RESULT.bridgeInjectFailed = appBridgeFailed
  // console 里若恰好也有（未来实现可能双写），不冲突
  if (consoleEvents.some((e) => /bridge-injected/i.test(e.text))) RESULT.bridgeInjected = true
  RESULT.uncaught = consoleEvents.filter((e) => e.type === 'error' || /uncaught|exception/i.test(e.text)).map((e) => e.text)
  log(`bridge-injected=${RESULT.bridgeInjected} bytes=${appBridgeBytes} inject-failed=${appBridgeFailed} uncaught=${RESULT.uncaught.length}`)

  // 2) ui.jsonl 有 ping
  const uiLog = join(PROJECT_ROOT, 'data', 'logs', 'ui.jsonl')
  if (existsSync(uiLog)) {
    const lines = readFileSync(uiLog, 'utf8').trim().split('\n').filter(Boolean).slice(-200)
    RESULT.uiPing = lines.some((l) => /ping/i.test(l))
    RESULT.uiLines = lines.length
    log(`ui.jsonl 行数=${RESULT.uiLines} 含ping=${RESULT.uiPing}`)
  }

  // 3) settings 往返 + 截图：设置页版本
  // S67·4-E：旧判据依赖已废弃的 #ro-settings.ro-open（那是文学面板/deprecated timeline 的选择器），
  // 当前设置页是 #s5-settings.s5-on（home-v1）。**判据不删**，只把选择器改到真实 DOM。
  await sendWindow('expand')
  await sleep(1000)
  await evalJs(`(()=>{ const b=document.querySelector('#ro-ds-nav .ds-nav-btn[data-page="settings"]'); if (b) b.click(); })()`)
  await sleep(1200)
  RESULT.settingsRoundTrip = await evalJs(`const s=document.getElementById('s5-settings'); return !!(s && s.classList.contains('s5-on'))`)
  await evalJs(`(()=>{ const s=document.getElementById('s5-settings'); if (s) s.scrollTop = s.scrollHeight })()`)
  await sleep(600)
  const verMatch = await evalJs(`const m=document.body.textContent.match(/research-orb v\\d+\\.\\d+\\.\\d+(-[\\w.]+)?/g); return m ? [...new Set(m)] : []`)
  RESULT.settingsVersion = verMatch
  RESULT.shots.push(await shot('stage4-final-settings-version.png'))
  log(`settings 往返=${RESULT.settingsRoundTrip} 版本=${JSON.stringify(verMatch)}`)
  await evalJs(`(()=>{ const b=document.querySelector('#ro-ds-nav .ds-nav-btn[data-page="home"]'); if (b) b.click(); })()`)
  await sleep(600)

  // 4) 文献卡截图：打开文献面板（plugin:command card 触发卡片展示）
  await sendCommand('card', '')
  await sleep(1500)
  RESULT.shots.push(await shot('stage4-final-literature-card.png'))
  log('文献卡截图完成')

  // 5) 计时卡截图：展开 + 起一个计时会话看计时卡片
  await sendCommand('project', 'new 总验收演示')
  await sleep(600)
  await sendCommand('project', 'add-stage 总验收演示 写作')
  await sleep(600)
  await sendCommand('start', '60 总验收演示 写作')
  await sleep(1500)
  RESULT.shots.push(await shot('stage4-final-timer-card.png'))
  log('计时卡截图完成')
  await sendCommand('stop', '')
  await sleep(800)
} catch (err) {
  RESULT.error = String((err && err.message) || err)
  log('ERROR: ' + RESULT.error)
} finally {
  try { if (cdp) cdp.close() } catch {}
  killOwnElectron()
  await sleep(2000)

  RESULT.electronLeft = countOrbAll()
  log(`残留 electron=${RESULT.electronLeft}`)
  safeWrite(LOG, OUT.join('\n') + '\n')
  writeFileSync(LOG.replace('.txt', '.json'), JSON.stringify(RESULT, null, 2))
  log('证据已落 ' + LOG)
}
