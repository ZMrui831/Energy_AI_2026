// tools/accept-s71-recall-text.mjs —— S71·P0-1 召回文案与占位符清理验收
// 单行复跑：node tools\accept-s71-recall-text.mjs
import { mkdirSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { parseTimeRange, retrieveEvents, buildRecallAnswer } from '../packages/plugins/coach/confusion.mjs'

const items = []
const check = (id, ok, detail = '') => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300) }); console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's71-recall')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(WORK, { recursive: true })
const TRAJ = join(WORK, 'trajectory.jsonl')
const INC = join(WORK, 'incremental.jsonl')
const NOW = Date.now()
const iso = (ms) => new Date(ms).toISOString()

// 正常行 + 占位行(placeholder:true) + 命令帧(source:command) + incremental 正常行
writeFileSync(TRAJ, [
  JSON.stringify({ ts: iso(NOW - 10 * 60e3), window: 'Word', process: 'winword.exe', intent: '写论文草稿', structuredIntent: '工作', evidence: { frameId: 'fr-norm1', textSha256: 's1' } }),
  JSON.stringify({ ts: iso(NOW - 5 * 60e3), window: '（增量抽取）', process: '（增量抽取）', intent: 'x', evidence: { frameId: 'fr-ph001', textSha256: 's2' }, placeholder: true }),
  JSON.stringify({ ts: iso(NOW - 3 * 60e3), window: 'Code', process: 'code.exe', intent: 'y', evidence: { frameId: 'fr-cmd01', textSha256: 's3' }, source: 'command' }),
].join('\n') + '\n')
writeFileSync(INC, JSON.stringify({ ts: iso(NOW - 1 * 60e3), window: 'Zotero', process: 'zotero.exe', frameId: 'fr-inc01', textSha256: 's4', text: '读文献', structured: { intent: '工作', app: 'Zotero' } }) + '\n')

try {
  const range = parseTimeRange('刚刚', NOW)
  const events = retrieveEvents({ trajectoryFile: TRAJ, incrementalFile: INC, range, limit: 20 })
  const text = buildRecallAnswer(events, range, {})
  const lines = text.split('\n').slice(1) // 去掉首行范围头

  check('R-1 答案不含"键"字', !text.includes('键'), text.split('\n').slice(1)[0] || '')
  const PH = /（增量抽取）|（命令触发）|（手动捕获）|（自动捕获）/
  check('R-2 不含任何占位串（增量抽取/命令触发/手动捕获/自动捕获）', !PH.test(text), '')
  check('R-3 每条含 HH:MM + fr- 编号', lines.length >= 2 && lines.every((l) => /^\d{2}:\d{2} .*（fr-[a-z0-9]+）$/.test(l)), lines.join(' | ').slice(0, 100))
  const stamps = (lines.join('\n').match(/\b\d{2}:\d{2}\b/g) || [])
  // S74·1-B：答案顶部新增"范围 · 条数"头（含 HH:MM）——那是**范围声明**不是条目时间戳，
  // 所以这里只对**条目行**（lines，已去掉首行头）做时间戳断言。断言强度不变（条目时间仍须全在范围内）。
  const hh = (ms) => { const d = new Date(ms); const p = (n) => String(n).padStart(2, '0'); return `${p(d.getHours())}:${p(d.getMinutes())}` }
  const allowed = new Set([hh(NOW - 10 * 60e3), hh(NOW - 1 * 60e3)])
  check('R-4 条目时间戳全在范围内（首行范围头不计）', stamps.length >= 2 && stamps.every((s) => allowed.has(s)), `stamps=${stamps.join(',')}`)
  // S74·1-B：顶部必须同时含范围与条数
  check('R-7 顶部含实际范围与条数', /（.+\d{2}:\d{2}–\d{2}:\d{2} · \d+ 条）/.test(text.split('\n')[0]), text.split('\n')[0])

  // 占位行/命令帧不出现
  check('R-5 命令帧(fr-cmd01)与占位行(fr-ph001)不出现', text.includes('fr-norm1') && text.includes('fr-inc01') && !text.includes('fr-cmd01') && !text.includes('fr-ph001'), '')

  // 无数据 → "没有记录"
  const emptyRange = { from: NOW - 1, to: NOW + 1, label: '测试空范围' }
  const emptyText = buildRecallAnswer(retrieveEvents({ trajectoryFile: TRAJ, incrementalFile: INC, range: emptyRange }), emptyRange, {})
  check('R-6 范围无数据 → "没有记录" 句式', /没有记录/.test(emptyText), emptyText.slice(0, 40))

  // 展示句式抽样（供汇报）
  console.log('  [样例] ' + lines[0])
} catch (e) {
  check('R-0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 300))
}

const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s71-recall-text: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(items.every((i) => i.ok) ? 0 : 1)
