// tools/record-mask.js —— 录屏用匿名遮罩（由 record-demo.mjs 注入到页面）
// 目的：录屏/截图时不暴露真实路径、用户名、微信目录等（比赛硬性要求：不得出现校名/姓名等可识别信息）
(function () {
  var RULES = [
    [/[A-Za-z]:\\[^\s"'<>|]+/g, function (m) {
      if (/research-orb/i.test(m)) return '项目:/…';
      if (/Desktop|桌面/i.test(m)) return '桌面:/…';
      return '路径:/…';
    }],
    [/wxid_[A-Za-z0-9_]+/g, '…'],
    [/explorer!/g, '…'],
    [/\b54958\b/g, '用户'], /* allow-hardcoded: 脱敏检测词表/基准，非路径引用 */
    // Windows 用户目录第二段（C:\Users\<name> 已被上面路径规则整体覆盖，这里兜底斜杠变体）
    [/(Users|用户)[\\/][^\s"'<>\\/]+/gi, '$1/用户'],
    // 学校网关域名：凡 http(s) URL 一律中性化，避免漏出学校/API 主机名
    [/https?:\/\/[^\s"'<>)\]]+/gi, '学校网关'],
    // 其它应用窗口标题（会渲染在感知/轨迹页）→ 中性应用名
    [/Visual Studio Code|Code\.exe/g, '编辑器'],
    [/微信|WeChat/gi, '通讯软件'],
    [/Microsoft.*Edge|msedge|Chrome|Firefox/gi, '浏览器'],
    [/DeepSeek Harness/gi, '编辑器'],
    [/WorkBuddy/gi, '工具A'],
    // 产品/助手代号若残留在 DOM 文本里，统一中性化（不得出现 贾维斯/萌源/dsh-orb）
    [/贾维斯|萌源|dsh-orb/gi, '研究助手']
  ];
  function maskText(t) {
    var s = String(t);
    for (var i = 0; i < RULES.length; i++) s = s.replace(RULES[i][0], RULES[i][1]);
    return s;
  }
  function walk(node) {
    if (!node) return;
    if (node.nodeType === 3) {
      var v = node.nodeValue;
      var m = maskText(v);
      if (m !== v) node.nodeValue = m;
      return;
    }
    if (node.nodeType !== 1) return;
    var tag = node.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') {
      if (node.value) node.value = maskText(node.value);
      if (node.placeholder) node.placeholder = maskText(node.placeholder);
      return;
    }
    for (var c = node.firstChild; c; c = c.nextSibling) walk(c);
  }
  walk(document.body);
  try {
    new MutationObserver(function (list) {
      for (var i = 0; i < list.length; i++) {
        var r = list[i];
        if (r.type === 'characterData') {
          var v = r.target.nodeValue;
          var m = maskText(v);
          if (m !== v) r.target.nodeValue = m;
        } else if (r.addedNodes) {
          for (var j = 0; j < r.addedNodes.length; j++) walk(r.addedNodes[j]);
        }
      }
    }).observe(document.body, { subtree: true, childList: true, characterData: true });
  } catch (e) { /* 遮罩失败不阻断录制 */ }
  window.__recordMask = { installed: true, maskText: maskText };
  return 'mask-installed';
})();