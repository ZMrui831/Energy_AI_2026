// tools/build-submission.mjs —— 组装可提交的提交包（dist-submission\）
// 用法：
//   node tools/build-submission.mjs                       自动在常见位置找四项素材
//   node tools/build-submission.mjs --pdf <文件> --video <文件> [--statement <md>] [--limits <md>] [--srt <srt>]
//   node tools/build-submission.mjs --out dist-submission 指定出包目录（默认 dist-submission\）
//
// 包内容（4 项 + 清单）：
//   案例正文.pdf / 演示视频.mp4 / AI-使用声明.md / 局限清单.md / manifest.json（sha256 + 时间 + 版本）
//
// 纪律：
//   · **只复制不改源**（源文件哈希写入清单，复制后复算比对，不一致就 FAIL）；
//   · 同名文件先备份到 dist-submission\.prev\<名字>.<时间戳>，绝不静默覆盖；
//   · 出包前先跑 tools\check-anonymity.mjs（文本项），命中即拒绝出包并打印命中行；
//   · 缺素材 → 打印"缺什么 + 去哪拿 + 怎么生成"，exit 1，**不产半成品包**；
//   · 零新增依赖；只写项目根。
//
// 单行复跑：node tools/build-submission.mjs

import { existsSync, statSync, readFileSync, readdirSync, mkdirSync, writeFileSync, copyFileSync, renameSync } from 'node:fs'
import { join, basename, extname, relative } from 'node:path'
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const arg = (k, d = null) => { const i = process.argv.indexOf(k); return i >= 0 ? process.argv[i + 1] : d }
const outRel = arg('--out', 'dist-submission')
const OUT_DIR = join(PROJECT_ROOT, outRel)
const PREV_DIR = join(OUT_DIR, '.prev')

// 每项：names=精确文件名；keywords=改名兜底的**必须包含**词（防止把根目录别的 .md 当成局限清单）
const ITEMS = [
  { key: 'pdf', argName: '--pdf', target: '案例正文.pdf', exts: ['.pdf'], names: ['案例正文.pdf'], keywords: ['案例', '正文'], where: 'docs\\案例正文-初稿.md 导出为 PDF 后放到 dist-submission\\ 或项目根' },
  { key: 'video', argName: '--video', target: '演示视频.mp4', exts: ['.mp4'], names: ['演示视频.mp4'], keywords: ['演示', '视频'], where: '录屏软件导出（只裁应用窗口区域）后放到 dist-submission\\ 或项目根' },
  { key: 'statement', argName: '--statement', target: 'AI-使用声明.md', exts: ['.md'], names: ['AI-使用声明.md'], keywords: ['AI', '声明'], where: 'docs\\AI-使用声明.md（仓库已有）' },
  { key: 'limits', argName: '--limits', target: '局限清单.md', exts: ['.md'], names: ['局限清单.md'], keywords: ['局限'], where: 'docs\\局限清单.md（如未写：从 docs\\SHOT-CHART.md 已知局限 + docs\\DEBT-orb.md 汇总成一份 md）' },
  // 可选项：字幕不在提交包必需项里，但带上便于评委核对；找不到就跳过（不判缺失）
  { key: 'srt', argName: '--srt', target: '演示字幕.srt', exts: ['.srt'], names: ['演示字幕.srt', 'record-demo.srt'], keywords: [], optional: true, where: 'data\\reports\\record-demo.srt（record-demo 生成）' },
]
const SEARCH_DIRS = [OUT_DIR, PROJECT_ROOT, join(PROJECT_ROOT, 'docs'), join(PROJECT_ROOT, 'data', 'reports'), join(PROJECT_ROOT, 'data', 'submission')]

const sha256 = (p) => createHash('sha256').update(readFileSync(p)).digest('hex')
const kb = (n) => (n / 1024).toFixed(1) + 'KB'
// 匿名纪律：manifest 里只记项目内相对路径；项目外的素材只记文件名
const relOf = (p) => (p.startsWith(PROJECT_ROOT) ? p.slice(PROJECT_ROOT.length + 1) : basename(p))

function findSource(item) {
  const explicit = arg(item.argName, null)
  if (explicit) {
    const abs = explicit.includes(':') || explicit.startsWith('\\\\') ? explicit : join(PROJECT_ROOT, explicit)
    return existsSync(abs) ? abs : { missing: explicit }
  }
  for (const dir of SEARCH_DIRS) {
    if (!existsSync(dir)) continue
    for (const name of item.names) { const p = join(dir, name); if (existsSync(p)) return p }
  }
  // 退一步：只在出包目录/字幕目录里按"扩展名 + 关键词"找（避免改名后找不到，也避免把无关同名后缀文件当成素材）
  const looseDirs = item.key === 'srt' ? [OUT_DIR, join(PROJECT_ROOT, 'data', 'reports')] : [OUT_DIR]
  for (const dir of looseDirs) {
    if (!existsSync(dir)) continue
    const hit = readdirSync(dir).find((n) => {
      if (n.startsWith('.') || !item.exts.includes(extname(n).toLowerCase())) return false
      return item.keywords.length === 0 || item.keywords.some((k) => n.includes(k))
    })
    if (hit) return join(dir, hit)
  }
  return null
}

console.log('=== build-submission：组装提交包 | 案例：问源——面向科研场景的可验证 AI 悬浮球 ===')
console.log('  出包目录：' + outRel + '\\')
console.log('')

// ---- 1. 解析素材 -------------------------------------------------------
const resolved = []
for (const item of ITEMS) {
  const p = findSource(item)
  if (p && typeof p === 'object' && p.missing) { console.log('  [缺失] ' + item.target + '：--' + item.key + ' 指定的路径不存在 → ' + p.missing); resolved.push(null); continue }
  if (!p) {
    if (item.optional) { console.log('  [跳过] ' + item.target + '（可选项，未找到：' + item.where + '）'); resolved.push(null); continue }
    console.log('  [缺失] ' + item.target + '（去哪拿：' + item.where + '）'); resolved.push(null); continue
  }
  console.log('  [找到] ' + item.target + ' ← ' + relOf(p))
  resolved.push({ item, src: p })
}
const missing = ITEMS.filter((it, i) => !resolved[i] && !it.optional)
if (missing.length) {
  console.log('\n' + '='.repeat(60))
  console.log(' # build-submission: 素材不齐（' + missing.length + ' 项），未出包 → 补齐后复跑')
  console.log(' 补法：')
  for (const m of missing) console.log('   · ' + m.target + ' → ' + m.where)
  process.exit(1)
}

// ---- 2. 匿名检查（文本项）---------------------------------------------
const textItems = resolved.filter((r) => ['.md', '.srt', '.txt'].includes(extname(r.src).toLowerCase()))
if (textItems.length) {
  console.log('\n[匿名检查] 文本项 → tools\\check-anonymity.mjs')
  const outside = textItems.filter((t) => !t.src.startsWith(PROJECT_ROOT))
  if (outside.length) console.log('  [警告] 以下素材在项目根之外，匿名检查扫不到，请自行确认：' + outside.map((t) => basename(t.src)).join('，'))
  const inside = textItems.filter((t) => t.src.startsWith(PROJECT_ROOT))
  // 关键：check-anonymity 会把入参 join 到项目根，**必须传相对路径**（传绝对路径会被拼成非法路径 → 目标数 0 等于没检查）
  const relTargets = inside.map((t) => relative(PROJECT_ROOT, t.src))
  const r = spawnSync(process.execPath, [join(PROJECT_ROOT, 'tools', 'check-anonymity.mjs'), ...relTargets], { cwd: PROJECT_ROOT, encoding: 'utf8' })
  const out = ((r.stdout || '') + (r.stderr || '')).trim()
  if (r.status !== 0) {
    console.log(out)
    console.log('\n' + '='.repeat(60))
    console.log(' # build-submission: 匿名检查命中 → **拒绝出包**（上面是命中行，改干净再跑）')
    process.exit(1)
  }
  console.log(out.split('\n').map((l) => '   ' + l).join('\n'))
  console.log('   → 干净，放行')
}

// ---- 3. 出包（同名先备份）---------------------------------------------
mkdirSync(OUT_DIR, { recursive: true })
const manifestItems = []
let backed = 0
for (const r of resolved) {
  const dst = join(OUT_DIR, r.item.target)
  const sameAsSource = r.src === dst // 素材本身就在包里（复跑时自动找到上次成果）→ 只登记，不再复制
  if (sameAsSource) {
    const sha = sha256(r.src); const size = statSync(r.src).size
    console.log('  [已在包内] ' + r.item.target + '  ' + kb(size) + '  sha256=' + sha.slice(0, 16) + '…')
    manifestItems.push({ name: r.item.target, bytes: size, sha256: sha, source: relOf(r.src) })
    continue
  }
  if (existsSync(dst)) {
    mkdirSync(PREV_DIR, { recursive: true })
    const stamp = new Date().toISOString().replace(/[:.]/g, '-')
    renameSync(dst, join(PREV_DIR, basename(r.item.target).replace(/(\.[^.]+)$/, '.' + stamp + '$1')))
    backed++
    console.log('  [备份] 已存在的 ' + r.item.target + ' → .prev\\')
  }
  const srcSha = sha256(r.src)
  const srcSize = statSync(r.src).size
  copyFileSync(r.src, dst)
  const dstSha = sha256(dst)
  if (srcSha !== dstSha) { console.log('  [FAIL] 复制后哈希不一致：' + r.item.target); process.exit(1) }
  console.log('  [复制] ' + r.item.target + '  ' + kb(srcSize) + '  sha256=' + srcSha.slice(0, 16) + '…')
  manifestItems.push({
    name: r.item.target,
    bytes: srcSize,
    sha256: srcSha,
    source: relOf(r.src), // 只记项目内相对路径（匿名纪律：不写绝对路径）
  })
}

// ---- 4. manifest.json ---------------------------------------------------
let version = '0.0.0'
try { version = JSON.parse(readFileSync(join(PROJECT_ROOT, 'package.json'), 'utf8')).version || version } catch { /* 取不到就留 0.0.0 */ }
const manifest = {
  tool: 'build-submission',
  project: '问源——面向科研场景的可验证 AI 悬浮球',
  version,
  generatedAt: new Date().toISOString(),
  outDir: outRel,
  items: manifestItems,
  note: 'sha256 为源文件与包内文件双向复算一致后的值；source 为项目内相对路径（提交包不得含绝对路径）。',
}
const manifestPath = join(OUT_DIR, 'manifest.json')
if (existsSync(manifestPath)) {
  mkdirSync(PREV_DIR, { recursive: true })
  renameSync(manifestPath, join(PREV_DIR, 'manifest.' + new Date().toISOString().replace(/[:.]/g, '-') + '.json'))
  backed++
}
writeFileSync(manifestPath, JSON.stringify(manifest, null, 2), 'utf8')
console.log('  [清单] manifest.json（' + manifestItems.length + ' 项，版本 ' + version + '，' + new Date().toISOString() + '）')

console.log('\n' + '='.repeat(60))
console.log(' # build-submission: 出包完成 ' + manifestItems.length + ' 项 + manifest.json' + (backed ? '（同名备份 ' + backed + ' 份到 .prev\\）' : ''))
console.log(' 目录 -> ' + outRel + '\\')
console.log(' 下一步：node tools\\check-submission.mjs   （自动在该目录里找视频/PDF/字幕逐项核对）')
process.exit(0)
