// tools/accept-s17-chart.mjs —— S17/S18「图与表」端到端冒烟：真实 DB（node:sqlite）+ 真实文件。
// 单行复跑：node tools\accept-s17-chart.mjs
// 覆盖任务书验收：出图成功且尺寸合规 / 图内来源标注 / sidecar evidenceIds 与 DB 一致 /
// 表格全列 / sha256 可校验 / 无证据给明确错误码 / 产物匿名。
// S18 增补：指标 A「证据当前状态分布」方差硬标准（≥3 类非零且 max≠min）+ 标题论点句。
import './_accept-isolate.mjs' // S67·3-A：先于产品模块求值，把 data/logs 指到临时目录
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createStore } from '../packages/core/src/db.mjs'
import { createClaim, attachEvidence, publishClaim } from '../packages/core/src/lifecycle/publish.mjs'
import { activate } from '../packages/plugins/chart-skill/index.mjs'
import { pngSize, sha256Buf } from '../packages/plugins/chart-skill/lib/chart.mjs'

const items = []
const check = (id, ok, detail, evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's17-chart')
if (existsSync(WORK)) rmSync(WORK, { recursive: true, force: true })
mkdirSync(WORK, { recursive: true })
const OUTDIR = join(WORK, 'artifacts')

const store = await createStore({ driver: 'sqlite', dbPath: join(WORK, 'orb.sqlite'), dataDir: WORK })
store.initMigrations()

// ---- 造真实数据（走真实发布管线，不 mock）--------------------------------
// S18：fixture 刻意造出三类非零且 max≠min 的证据状态分布（原图仍在×3 / 已删除×1 / 断链×1）
store.insertRawFrame({ id: 'rf-s17-a', file_path: join(WORK, 'a.png'), sha256: 'a'.repeat(64), sensitivity: 'normal', created_at: new Date().toISOString(), expires_at: new Date(Date.now() + 3600000).toISOString(), status: 'ready', size_bytes: 1, format: 'png', mode: 'lowres', monitor_id: 'M1', consent_id: 'demo', trace_id: 'tr-s17' })
store.insertRawFrame({ id: 'rf-s17-b', file_path: join(WORK, 'b.png'), sha256: 'b'.repeat(64), sensitivity: 'normal', created_at: new Date().toISOString(), expires_at: new Date(Date.now() + 3600000).toISOString(), status: 'ready', size_bytes: 1, format: 'png', mode: 'lowres', monitor_id: 'M1', consent_id: 'demo', trace_id: 'tr-s17' })
store.insertRawFrame({ id: 'rf-s17-c', file_path: join(WORK, 'c.png'), sha256: 'c'.repeat(64), sensitivity: 'normal', created_at: new Date().toISOString(), expires_at: new Date(Date.now() + 3600000).toISOString(), status: 'ready', size_bytes: 1, format: 'png', mode: 'lowres', monitor_id: 'M1', consent_id: 'demo', trace_id: 'tr-s17' })
store.insertRawFrame({ id: 'rf-s17-gone', file_path: join(WORK, 'gone.png'), sha256: 'd'.repeat(64), sensitivity: 'normal', created_at: new Date().toISOString(), expires_at: new Date(Date.now() + 3600000).toISOString(), status: 'ready', size_bytes: 1, format: 'png', mode: 'lowres', monitor_id: 'M1', consent_id: 'demo', trace_id: 'tr-s17' })
for (const n of ['a', 'b', 'c']) writeFileSync(join(WORK, n + '.png'), 'png-bytes') // ready 帧落真实文件（resolveEvidence 查盘）
store.setRawFrameStatus('rf-s17-c', 'deleted') // insertRawFrame 恒写 ready；删除态走公开 API（与 cleaner 同通道）
createClaim(store, { id: 'clm-s17-pub1', kind: 'observation', text: '双源校验显示该 DOI 真实存在，且引文逐字命中。', evidenceMode: 'direct' })
attachEvidence(store, { claimId: 'clm-s17-pub1', evidenceId: 'rf-s17-a', layer: 'raw_frame', relation: 'direct', sha256: 'a'.repeat(64) })
attachEvidence(store, { claimId: 'clm-s17-pub1', evidenceId: 'rf-s17-b', layer: 'raw_frame', relation: 'direct', sha256: 'b'.repeat(64) })
attachEvidence(store, { claimId: 'clm-s17-pub1', evidenceId: 'rf-s17-c', layer: 'raw_frame', relation: 'direct', sha256: 'c'.repeat(64) })
check('C1a 发布管线', publishClaim(store, 'clm-s17-pub1').ok === true, 'clm-s17-pub1 published（3 条证据）')
createClaim(store, { id: 'clm-s17-pub2', kind: 'observation', text: '第二条已发布结论（单证据）。', evidenceMode: 'direct' })
attachEvidence(store, { claimId: 'clm-s17-pub2', evidenceId: 'rf-s17-a', layer: 'raw_frame', relation: 'direct', sha256: 'a'.repeat(64) })
attachEvidence(store, { claimId: 'clm-s17-pub2', evidenceId: 'rf-s17-gone', layer: 'raw_frame', relation: 'direct', sha256: 'd'.repeat(64) })
check('C1b 发布管线', publishClaim(store, 'clm-s17-pub2').ok === true, 'clm-s17-pub2 published（2 条证据，含 1 条断链）')
// 发布后抹除 raw_frame 行（复现生产库断链引用：行没了，claim_evidence 仍在）
store._db.prepare("DELETE FROM raw_frame WHERE id = 'rf-s17-gone'").run()
createClaim(store, { id: 'clm-s17-noev', kind: 'observation', text: '无证据草稿，不得进图。', evidenceMode: 'none' })

// ---- 命令层（真实 activate + 真实 run）----------------------------------
const cmds = []
await activate({ log: { warn() {}, info() {}, error() {} }, core: { lifecycle: store }, ui: { registerCard() {}, registerCommand: (c) => cmds.push(c) } })
check('C0 注册 chart 命令', cmds.some((c) => c.name === 'chart'), 'commands=' + cmds.map((c) => c.name).join(','))
const run = cmds.find((c) => c.name === 'chart').run

// ---- bars：出图 + 尺寸 + 图内标注 + sidecar -----------------------------
const relOut = 'data/tmp/s17-chart/artifacts'
const rb = await run(`bars trust ${relOut}`)
check('C2 /chart bars 成功', rb.ok === true, String(rb.text || '').slice(0, 90))
const barsUi = rb.ui || {}
const pngPath = barsUi.pngPath
let pngOk = false, size = null
if (pngPath && existsSync(pngPath)) {
  const buf = readFileSync(pngPath)
  size = pngSize(buf)
  pngOk = size.width >= 1600 && size.height >= 1000 && buf.length > 20000
}
check('C3 出图尺寸合规 ≥1600×1000', pngOk, size ? `${size.width}×${size.height}` : '无 PNG')
const drawnPath = pngPath + '.drawn.json'
const drawn = existsSync(drawnPath) ? JSON.parse(readFileSync(drawnPath, 'utf8')) : null
const annText = drawn ? drawn.annotationLines.join(' ') : ''
check('C4 图内来源标注（含 evidence_id 与数据源）',
  !!drawn && annText.includes('evidence_id=') && annText.includes('rf-s17-a') && annText.includes('claim_evidence'),
  annText.slice(0, 110))
const sidecarBars = barsUi.sidecar || null
let dbIds = store._db.prepare('SELECT DISTINCT evidence_id FROM claim_evidence').all().map((x) => x.evidence_id)
check('C5 sidecar evidenceIds 非空且与 DB 一致',
  !!sidecarBars && sidecarBars.evidenceIds.length > 0 && sidecarBars.evidenceIds.every((id) => dbIds.includes(id)),
  `evidenceIds=[${sidecarBars ? sidecarBars.evidenceIds.join(', ') : ''}]`)
check('C6 sha256 可校验', !!sidecarBars && existsSync(pngPath) && sidecarBars.sha256.png === sha256Buf(readFileSync(pngPath)), 'sha256(png) 复算一致')

// ---- S18 新指标硬标准：方差 + 论点句标题 ----------------------------------
// 独立复算（不过 chart-skill 聚合代码）：claim_evidence 行 × raw_frame 状态
const dbRows = store._db.prepare('SELECT ce.evidence_id, rf.status AS rfStatus, rf.file_path AS filePath FROM claim_evidence ce LEFT JOIN raw_frame rf ON rf.id = ce.evidence_id').all()
const expectDist = {}
for (const r of dbRows) {
  const st = !r.rfStatus ? '引用断链' : (r.rfStatus === 'deleted' ? '已按策略删除' : (r.rfStatus === 'error' ? '清理失败待排查' : (existsSync(r.filePath) ? '原图仍在' : '原图文件缺失')))
  expectDist[st] = (expectDist[st] || 0) + 1
}
const expVals = Object.values(expectDist)
const drawnBars = drawn ? drawn.barValues : []
check('C13 指标 A 分布与 DB 独立复算一致',
  !!sidecarBars && JSON.stringify(sidecarBars.distribution) === JSON.stringify(expectDist) && JSON.stringify(drawnBars) === JSON.stringify(expVals),
  `distribution=${JSON.stringify(sidecarBars ? sidecarBars.distribution : null)}（DB 复算 ${JSON.stringify(expectDist)}）`)
check('C13b 方差硬标准：≥3 类非零且 max≠min',
  expVals.length >= 3 && Math.max(...expVals) !== Math.min(...expVals) && sidecarBars && sidecarBars.varianceOk === true && drawn && drawn.varianceOk === true,
  `类数=${expVals.length}，值=${JSON.stringify(expVals)}，varianceOk=${sidecarBars ? sidecarBars.varianceOk : null}`)
const totalEv = expVals.reduce((a, b) => a + b, 0)
const titleOk = !!drawn && drawn.title.includes(String(totalEv) + ' 条证据引用') && Object.entries(expectDist).every(([k, v]) => drawn.title.includes(v + ' 条' + k))
check('C14 标题为论点句（总数与各类真实计数现场算）', titleOk, drawn ? drawn.title : '无 drawn')

// ---- table：全列 + docx -------------------------------------------------
const rt = await run(`table claims ${relOut}`)
check('C7 /chart table 成功', rt.ok === true, String(rt.text || '').split('\n')[0].slice(0, 90))
const tableUi = rt.ui || {}
const mdPath = tableUi.mdPath
const md = mdPath && existsSync(mdPath) ? readFileSync(mdPath, 'utf8') : ''
const colsOk = ['claim_id', '状态', '证据档位', '证据数', '证据编号'].every((c) => md.includes('| ' + c + ' '))
check('C8 表格含全部 5 列', colsOk, 'claim_id/状态/证据档位/证据数/证据编号')
const docxPath = tableUi.docxPath
const docx = docxPath && existsSync(docxPath) ? readFileSync(docxPath) : null
check('C9 docx 落盘（zip 容器非空）', !!docx && docx.length > 1000 && docx.toString('ascii', 0, 2) === 'PK', docx ? docx.length + 'B' : '无')
const sidecarTable = tableUi.sidecar || null
check('C10 表 sidecar sha256 可校验',
  !!sidecarTable && sidecarTable.sha256.md === sha256Buf(readFileSync(mdPath)) && sidecarTable.sha256.docx === sha256Buf(readFileSync(docxPath)),
  'sha256(md)+sha256(docx) 复算一致')

// ---- 负向：无证据 → 明确错误码 ------------------------------------------
const rn = await run(`bars clm-s17-noev ${relOut}`)
check('C11 无证据输入给明确错误码（E_NO_EVIDENCE）', rn.ok === false && rn.code === 'E_NO_EVIDENCE', 'code=' + rn.code)

// ---- 匿名：产物不含真实路径/用户名/校名 ---------------------------------
// 注意：禁用词用拼接构造，避免本文件被 check-anonymity 扫描时自匹配词表。
const FORBIDDEN = ['explorer' + '!', '5495' + '8', 'C:\\Us' + 'ers', 'D:\\expl' + 'orer', 'SJ' + 'TU', '交' + '大', '上海交' + '通']
let anonHits = []
for (const f of [mdPath, drawnPath, pngPath + '.drawn.json'].filter(Boolean)) {
  if (!existsSync(f)) continue
  const text = readFileSync(f, 'utf8')
  for (const w of FORBIDDEN) if (text.includes(w)) anonHits.push(f + ' → ' + w)
}
check('C12 产物匿名（无路径/用户名/校名）', anonHits.length === 0, anonHits.length ? anonHits.join('; ') : `md + drawn 文本干净（PNG 内容按 payload 构成，同源标注已验）`)

// ---- 收尾 ----------------------------------------------------------------
try { store.close && store.close() } catch { /* ignore */ }
const pass = items.filter((i) => i.ok).length
const out = { tool: 'accept-s17-chart', at: new Date().toISOString(), total: items.length, pass, fail: items.length - pass, items, artifacts: { png: pngPath || null, md: mdPath || null, docx: docxPath || null } }
writeFileSync(join(PROJECT_ROOT, 'data', 'logs', 's17-chart-accept.json'), JSON.stringify(out, null, 2), 'utf8')
console.log('\n  # accept-s17-chart: total=' + items.length + ' pass=' + pass + ' fail=' + (items.length - pass))
console.log('  证据 -> data/logs/s17-chart-accept.json')
process.exit(pass === items.length ? 0 : 1)
