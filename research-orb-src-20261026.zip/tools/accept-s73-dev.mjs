// tools/accept-s73-dev.mjs —— S73 开发者 Agent 接口验收（起隔离应用 → 逐条跑 dev-agent CLI）
// 单行复跑：node tools\accept-s73-dev.mjs   （含真实 GLM：ask/bench，约 3-5 分钟）
import { spawn, spawnSync } from 'node:child_process'
import { appendFileSync, cpSync, existsSync, mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-s73-dev')

const ELECTRON = ORB_ELECTRON
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9341
const CLI = join(PROJECT_ROOT, 'tools', 'dev-agent.mjs')
const FIXTURE = join(PROJECT_ROOT, 'tests', 'fixtures', 'vision', 'dsh-split-screen.png')
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const items = []
const check = (id, ok, detail = '') => {
  const d = String(detail).slice(0, 300)
  items.push({ id, ok: !!ok, detail: d })
  console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${d}`)
  // S73 调试：失败项把完整 CLI 输出落到独立文件（不被 300 字截断），便于定位
  try {
    if (!ok) {
      const dbg = '【' + id + '】' + d + '\n【CLI 完整输出】' + _lastCli + '\n\n'
      appendFileSync(join(PROJECT_ROOT, 'data', 'tmp', 's73-debug.log'), dbg)
    }
  } catch { /* noop */ }
}

const countProcs = () => countOrbAll()

let child = null
let tmpRoot = null
let DEV_ENV = null

/** 跑一次 dev-agent CLI（继承隔离 ORB_DATA_DIR），解析 stdout JSON。 */
let _lastCli = ''
const runCli = (args, timeout = 240000) => {
  // CLI 默认连 9336 —— 隔离应用在 PORT(9341)，必须显式传 --port（CLI 会把它从参数里剔掉）
  const r = spawnSync(process.execPath, [CLI, '--port=' + PORT, ...args], { cwd: PROJECT_ROOT, encoding: 'utf8', timeout, env: DEV_ENV })
  let json = null
  try { json = JSON.parse(String(r.stdout || '').trim()) } catch { /* 非 JSON */ }
  _lastCli = ('stdout=' + String(r.stdout || '').slice(0, 400) + ' ｜stderr=' + String(r.stderr || '').slice(0, 200))
  return { json, stdout: String(r.stdout || ''), status: r.status }
}
const logFile = (name) => join(DEV_ENV.ORB_DATA_DIR, 'logs', name + '.jsonl')
const logHas = (name, needle) => { try { return existsSync(logFile(name)) && readFileSync(logFile(name), 'utf8').includes(needle) } catch { return false } }

try {
  if (countProcs() > 0) { check('D-0 预检', false, '已有 research-orb 实例在跑'); throw new Error('preflight') }
  if (!existsSync(FIXTURE)) { check('D-0 预检', false, '夹具缺失'); throw new Error('fixture') }
  tmpRoot = mkdtempSync(join(tmpdir(), 's73-dev-'))
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  delete env.ORB_LOG_DIR
  env.ORB_DATA_DIR = join(tmpRoot, 'data')
  try { cpSync(join(PROJECT_ROOT, 'data', 'themes'), join(env.ORB_DATA_DIR, 'themes'), { recursive: true }) } catch { /* noop */ }
  try { cpSync(join(PROJECT_ROOT, 'data', 'providers.json'), join(env.ORB_DATA_DIR, 'providers.json')) } catch { /* noop */ }
  try { cpSync(join(PROJECT_ROOT, 'data', 'vision-context.json'), join(env.ORB_DATA_DIR, 'vision-context.json')) } catch { /* noop */ }
  DEV_ENV = env
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], { cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] })
  const errTail = []
  child.stdout.resume()
  child.stderr.on('data', (b) => { errTail.push(String(b)); if (errTail.length > 30) errTail.shift() })
  child.on('exit', (code) => { try { console.log('  [info] 应用进程退出 code=' + code + ' stderr=' + errTail.join('').slice(-200)) } catch { /* noop */ } })

  // 等应用起来（CDP /json/list）+ 桥注入（app.jsonl 的 bridge-injected）
  let page = null
  const dl0 = Date.now() + 90000
  while (Date.now() < dl0 && !page) {
    try {
      const list = await new Promise((res, rej) => {
        import('node:http').then(({ default: http }) => {
          http.get(`http://127.0.0.1:${PORT}/json/list`, (r) => { let b = ''; r.on('data', (c) => { b += c }); r.on('end', () => { try { res(JSON.parse(b)) } catch (e2) { rej(e2) } }) }).on('error', rej)
        }).catch(rej)
      })
      page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl) || null
    } catch { /* 未起 → 等 */ }
    if (!page) await sleep(800)
  }
  if (!page) { check('D-0 启动', false, '90s 内 CDP 未就绪'); throw new Error('no-cdp') }
  const appLogPath = join(DEV_ENV.ORB_DATA_DIR, 'logs', 'app.jsonl')
  const dl1 = Date.now() + 45000
  let bridgeReady = false
  while (Date.now() < dl1 && !bridgeReady) {
    try { if (existsSync(appLogPath) && readFileSync(appLogPath, 'utf8').includes('bridge-injected')) bridgeReady = true } catch { /* noop */ }
    if (!bridgeReady) await sleep(800)
  }
  if (!bridgeReady) { check('D-0 启动', false, '45s 内桥未注入'); throw new Error('no-bridge') }
  await sleep(1500) // 等插件命令注册完成

  // ① shot：PNG 合理 + 审计有行
  const s1 = runCli(['shot', '--label', 't1'])
  check('D-1 shot 产出 PNG（尺寸/字节合理）+ 审计 dev-shot', s1.json && s1.json.ok === true && existsSync(s1.json.pngPath) && s1.json.bytes > 1000 && s1.json.width > 0 && s1.json.height > 0 && logHas('coach', 'dev-shot'), `png=${s1.json && s1.json.pngPath ? join('', '').slice(0, 0) + s1.json.pngPath.split(/[\\/]/).pop() : '-'} bytes=${s1.json && s1.json.bytes} ${s1.json && s1.json.width}x${s1.json && s1.json.height}`)
  // ② label 进文件名
  const s2 = runCli(['shot', '--label', 'x2'])
  check('D-2 shot --label x2 文件名含 label', s2.json && s2.json.ok === true && /x2/.test(String(s2.json.pngPath || '')), s2.json && s2.json.pngPath ? s2.json.pngPath.split(/[\\/]/).pop() : '-')

  // ③ ask(auto) → 召回 + 答案落盘
  const a1 = runCli(['ask', '我刚刚干了啥'])
  const sid = a1.json && a1.json.sessionId
  const sessPath = sid ? join(DEV_ENV.ORB_DATA_DIR, 'sessions', sid + '.jsonl') : null
  const sessOk = sessPath && existsSync(sessPath) && /"type":"assistant"/.test(readFileSync(sessPath, 'utf8')) && /"source":"recall"/.test(readFileSync(sessPath, 'utf8'))
  check('D-3 ask(auto) 返回 text/source/ms 且答案已落盘（assistant+source:recall）',
    a1.json && a1.json.ok === true && a1.json.text && a1.json.source && Number.isFinite(a1.json.ms) && a1.json.persisted === true && sessOk,
    `source=${a1.json && a1.json.source} persisted=${a1.json && a1.json.persisted} text=${String(a1.json && a1.json.text).slice(0, 40)}`)

  // ④ 空回答 → emptyReply:true 且 text 非空（stub 单元：机制证明）
  const unitCode = `
    const { createDevHandler } = await import(process.env.DEV_CMD_URL)
    const h = createDevHandler({ ctx: { core: {} }, router: { run: async () => ({ ok: true, text: '' }) }, confusion: { ask: async () => ({ ok: true, question: '' }) }, auditRouter: () => {} })
    const r = await h.run('ask 测试空回答 --mode chat')
    console.log(JSON.stringify({ emptyReply: r.emptyReply === true, text: r.text }))
  `
  const u = spawnSync(process.execPath, ['--input-type=module', '-e', unitCode], { encoding: 'utf8', timeout: 60000, env: { ...DEV_ENV, DEV_CMD_URL: 'file:///' + join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'dev-cmd.mjs').replace(/\\/g, '/') } })
  let u4 = null
  try { u4 = JSON.parse(String(u.stdout || '').trim().split('\n').pop()) } catch { /* noop */ }
  check('D-4 空回答 → emptyReply:true 且 text 非空（错误文案）', u4 && u4.emptyReply === true && !!u4.text, `text=${u4 && u4.text}`)

  // ⑤ prompt get
  const g = runCli(['prompt', 'get', '--kind', 'vision'])
  check('D-5 prompt get 返回版本 id 与内容', g.json && g.json.ok === true && typeof g.json.id === 'string' && typeof g.json.content === 'string', `id=${g.json && g.json.id} chars=${g.json && g.json.chars}`)

  // ⑥ set 干跑不生效
  const pA = join(tmpRoot, 'promptA.txt')
  writeFileSync(pA, 'S73 测试提示词 A：' + Date.now())
  const d6 = runCli(['prompt', 'set', '--kind', 'vision', '--file', pA])
  const activeFile = join(DEV_ENV.ORB_DATA_DIR, 'prompts', 'vision-active.txt')
  check('D-6 set 干跑不生效（applied:false、无 active 文件）', d6.json && d6.json.ok === true && d6.json.applied === false && !existsSync(activeFile), `applied=${d6.json && d6.json.applied}`)

  // ⑦ set --apply ×2 + rollback
  // S74·1-A 语义变更：vision-v1 现在是**种子版本**（全新目录会自动 seed），所以
  // set --apply 产出的版本从 v2 起。rollback 目标改为**set 实际产出的那个版本**——
  // 断言强度不变（rollback 必须把生效内容复原成"指定版本的真实内容"），不是放宽。
  const sA = runCli(['prompt', 'set', '--kind', 'vision', '--file', pA, '--apply'])
  const pB = join(tmpRoot, 'promptB.txt')
  writeFileSync(pB, 'S73 测试提示词 B：' + Date.now())
  const sB = runCli(['prompt', 'set', '--kind', 'vision', '--file', pB, '--apply'])
  const rb = runCli(['prompt', 'rollback', '--id', (sA.json && sA.json.to) || ''])
  const g2 = runCli(['prompt', 'get', '--kind', 'vision'])
  check('D-7 set --apply 生效（版本递增 + 审计）；rollback 复原到 A',
    sA.json && sA.json.applied === true && sB.json && sB.json.applied === true && logHas('coach', 'prompt-set') && rb.json && rb.json.ok === true && /提示词 A/.test(String(g2.json && g2.json.content)), `to=${sB.json && sB.json.to} rb=${rb.json && rb.json.to}`)

  // ⑧ log tail/grep
  const l1 = runCli(['log', 'tail', '--file', 'coach', '--n', '5'])
  const l2 = runCli(['log', 'grep', '--pattern', 'dev-agent'])
  check('D-8 log tail/grep 返回结构化 JSON（grep 命中 dev-agent）', l1.json && l1.json.ok === true && Array.isArray(l1.json.items) && l2.json && l2.json.ok === true && Array.isArray(l2.json.items) && l2.json.items.length >= 1, `tail=${l1.json && l1.json.items && l1.json.items.length} grep=${l2.json && l2.json.items && l2.json.items.length}`)

  // ⑨ bench 3 case —— S73 修订：**放到最后**（bench 连续 3 次真调 GLM，耗时且可能拖垮渲染层，
  //    之前放在中间会让后续 CLI 调用因应用失联而全挂）

  // ⑩ devApi=false → E_DEV_DISABLED（改隔离 config，测完恢复）
  const cfgPath = join(DEV_ENV.ORB_DATA_DIR, 'config.json')
  const cfg0 = existsSync(cfgPath) ? readFileSync(cfgPath, 'utf8') : '{}'
  let cfg = {}
  try { cfg = JSON.parse(cfg0) } catch { /* noop */ }
  cfg.devApi = false
  writeFileSync(cfgPath, JSON.stringify(cfg))
  const dz = runCli(['shot', '--label', 'dz'])
  writeFileSync(cfgPath, cfg0)
  check('D-10 settings.devApi=false → E_DEV_DISABLED', dz.json && dz.json.code === 'E_DEV_DISABLED', `code=${dz.json && dz.json.code}`)

  // ⑪ 源码断言：CLI 无 fetch( / writeFileSync(
  const cliSrc = readFileSync(CLI, 'utf8')
  const cmdSrc = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'dev-cmd.mjs'), 'utf8')
  const clean = (s) => !/fetch\(/.test(s) && !/writeFileSync\(/.test(s)
  check('D-11 不绕护栏：dev-agent 与 dev-cmd 均无 fetch(/writeFileSync(', clean(cliSrc) && clean(cmdSrc), '')

  // ⑨ bench 3 case（最后跑：连续 3 次真调 GLM）
  const suite = {
    name: 's73-basic',
    cases: [
      { id: 'dsh-split', shot: FIXTURE, expect: { tool: 'DeepSeek Harness' } },
      { id: 'dense-1', shot: join(PROJECT_ROOT, 'tests', 'fixtures', 'vision', 'text-dense-1280x800.png') },
      { id: 'dsh-split-2', shot: FIXTURE, expect: { tool: 'DeepSeek Harness' } },
    ],
  }
  const suitePath = join(tmpRoot, 'suite.json')
  writeFileSync(suitePath, JSON.stringify(suite))
  const b = runCli(['bench', '--suite', suitePath, '--repeat', '1'], 420000)
  const bOk = b.json && b.json.ok === true && Array.isArray(b.json.results) && b.json.results.length === 3 && Number.isFinite(b.json.passRate) && b.json.results.every((x) => typeof x.raw === 'string' && x.raw.length > 0)
  check('D-9 bench 3 case 输出 passRate + raw 完整', bOk, `passRate=${b.json && b.json.passRate} tools=${b.json && b.json.tools ? b.json.tools.join('|') : '-'} results=${b.json && b.json.results && b.json.results.length}`)
} catch (e) {
  check('D-0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  try { if (child) { child.kill(); await sleep(1500) } } catch { /* noop */ }
  try { if (tmpRoot) rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}

const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s73-dev: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(items.every((i) => i.ok) ? 0 : 1)
