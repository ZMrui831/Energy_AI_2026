// tools/diag-b2-nav.mjs —— S54·D5 B2「点其它页被拽回轨迹」定位（独立 P0）
//
// 方法（主管任务书 D5）：go() 内 patch 记录调用栈（home-v1.js 已带 window.__navTrail 审计），
// 隔离实例按 home→chat→trajectory→notes→publish→settings 切 3 轮，直接看"谁在调 go('trajectory')"。
// 注：任务书原文写 privacy，但 S52 起第 6 导航项=设置（隐私已并入设置页），按实际导航执行。
//
// 判定：
//   PASS = 3 轮 0 次被动回轨迹（__navTrail 中不存在"非用户点击发起的 to=trajectory"），
//          且轨迹页停留 10 秒不回退（E-17 依据）。
//   FAIL = 捕获到被动 go('trajectory')，stack 即真凶。
//
// 审计落盘：<隔离 ORB_DATA_DIR>/data/logs/nav-calls.jsonl（真实 data 保持零写入，S47 I-8 纪律）。
// 用法：node tools\diag-b2-nav.mjs   （需应用退出；fail-closed，不杀用户进程）

import { mkdtempSync, rmSync, cpSync, writeFileSync, mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import { spawn, spawnSync } from 'node:child_process'
import {killMarked, countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('diag-b2-nav')

const ELECTRON = ORB_ELECTRON
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9342
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const countProcs = () => countOrbAll()
const killOwn = () => killMarked(MARK)

async function findTarget(t = 40000) {
  const d = Date.now() + t
  while (Date.now() < d) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const l = await r.json()
      const p = l.find((x) => x.type === 'page' && x.webSocketDebuggerUrl && /floating\.html/i.test(String(x.url || '')))
      if (p) return p
    } catch { /* 等 */ }
    await sleep(350)
  }
  return null
}
function cdpConnect(wsUrl) {
  const ws = new WebSocket(wsUrl)
  let seq = 0
  const pending = new Map()
  const ready = new Promise((res, rej) => { ws.addEventListener('open', () => res()); ws.addEventListener('error', () => rej(new Error('ws'))) })
  ws.addEventListener('message', (ev) => {
    let m = null
    try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
    if (!m || !m.id) return
    const p = pending.get(m.id); if (!p) return
    pending.delete(m.id)
    if (m.error) p.rej(new Error(JSON.stringify(m.error))); else p.res(m.result)
  })
  const send = (method, params) => new Promise((res, rej) => { const id = ++seq; pending.set(id, { res, rej }); ws.send(JSON.stringify({ id, method, params })) })
  return { ready, send, close: () => { try { ws.close() } catch { /* noop */ } } }
}
async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r && r.exceptionDetails) throw new Error('ev: ' + JSON.stringify(r.exceptionDetails).slice(0, 300))
  return r && r.result ? r.result.value : undefined
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-b2-diag-'))
let child = null
let cdp = null
try {
  if (countProcs() > 0) { console.log('PREFLIGHT-FAIL: 已有 research-orb 实例在跑，退出（fail-closed）'); process.exit(2) }
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  delete env.ORB_LOG_DIR
  env.ORB_DATA_DIR = join(tmpRoot, 'data')
  try { cpSync(join(PROJECT_ROOT, 'data', 'themes'), join(env.ORB_DATA_DIR, 'themes'), { recursive: true }) } catch { /* 无 themes 就算了 */ }
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], { cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] })
  const tail = []
  const push = (b) => { tail.push(String(b)); while (tail.length > 20) tail.shift() }
  if (child.stdout) child.stdout.on('data', push)
  if (child.stderr) child.stderr.on('data', push)

  const target = await findTarget()
  if (!target) { console.log('NO-TARGET: ' + tail.join('').slice(-300)); process.exit(3) }
  cdp = cdpConnect(target.webSocketDebuggerUrl)
  await cdp.ready
  await cdp.send('Runtime.enable')
  let bridge = false
  const dl = Date.now() + 30000
  while (Date.now() < dl) {
    try { bridge = await ev(cdp, 'typeof globalThis.__s5 === "object" && typeof globalThis.researchOrb === "object"'); if (bridge) break } catch { /* 等 */ }
    await sleep(400)
  }
  if (!bridge) { console.log('NO-BRIDGE: 30s 未就绪'); process.exit(3) }
  await ev(cdp, 'globalThis.researchOrb.send("window", { action: "expand" })')
  await sleep(1800)

  // 用户点击真实导航按钮（不是直调 __s5.page，那样 stack 不真实）
  const NAV = ['home', 'chat', 'trajectory', 'notes', 'publish', 'settings']
  const clickNav = (p) => ev(cdp, `(() => { const b = document.querySelector('#ro-ds-nav .ds-nav-btn[data-page="${p}"]'); if (!b) return 'missing'; b.click(); return 'ok' })()`)

  // patch 起点基线
  const t0 = await ev(cdp, 'JSON.stringify({ trail: (globalThis.__navTrail || []).length, page: window.__s5.currentPage ? window.__s5.currentPage() : null })')
  console.log('[基线] ' + t0)

  // ---------- 3 轮 × 6 页切换（每页停 800ms，轨迹页停 1200ms 再走） ----------
  for (let round = 1; round <= 3; round++) {
    for (const p of NAV) {
      await clickNav(p)
      await sleep(p === 'trajectory' ? 1200 : 800)
    }
    const pg = await ev(cdp, 'window.__s5.currentPage ? window.__s5.currentPage() : null')
    console.log(`[第 ${round} 轮] 6 页切完，落在: ${pg}` + (pg !== 'settings' ? '  <-- 异常：应在 settings' : ''))
  }

  // ---------- 轨迹页停留 10 秒（E-17 依据） ----------
  await clickNav('trajectory')
  await sleep(10000)
  const after10s = await ev(cdp, 'window.__s5.currentPage ? window.__s5.currentPage() : null')
  console.log(`[10 秒停留] 进轨迹后停 10 秒，当前页: ${after10s}` + (after10s === 'trajectory' ? '  (不回退 ✓)' : '  <-- B2 复现：被拽回 ' + after10s))

  // ---------- 读审计并分析 ----------
  const trail = JSON.parse(await ev(cdp, 'JSON.stringify(globalThis.__navTrail || [])'))
  console.log(`[审计] __navTrail 共 ${trail.length} 条`)
  // 分类：
  //   自激重入   = from===to==='trajectory' 且 stack 含 dispatchPanel（回包驱动重渲染）→ 守卫后应为 0
  //   B2 本体   = from!=='trajectory' 且 to==='trajectory' 且 stack 含 dispatchPanel → S51 守卫后应为 0
  //   其余       = 用户导航点击 / Esc / 动作后跳转（ask helped→notes、claim created→publish 等，合法）
  const reentry = trail.filter((e) => e.from === e.to && e.from === 'trajectory' && /dispatchPanel/.test(e.stack || ''))
  const b2body = trail.filter((e) => e.from !== 'trajectory' && e.to === 'trajectory' && /dispatchPanel/.test(e.stack || ''))
  console.log(`[分析] 自激重入（trajectory→trajectory 回包驱动）: ${reentry.length} 条`)
  console.log(`[分析] 被动拽回（非轨迹页→轨迹，回包驱动）: ${b2body.length} 条`)
  for (const e of [...b2body, ...reentry].slice(0, 8)) {
    console.log(`  [可疑] ${e.from} -> ${e.to}  stack: ${String(e.stack).slice(0, 200)}`)
  }

  // 落 nav-calls.jsonl（隔离数据目录 logs；真实 data 零写入）
  try {
    const logDir = join(env.ORB_DATA_DIR, 'data', 'logs')
    mkdirSync(logDir, { recursive: true })
    writeFileSync(join(logDir, 'nav-calls.jsonl'), trail.map((e) => JSON.stringify(e)).join('\n') + '\n', 'utf8')
    console.log('[落盘] ' + join(logDir, 'nav-calls.jsonl'))
  } catch (e) { console.log('[落盘失败] ' + String(e)) }

  // ---------- 结论 ----------
  const ok = after10s === 'trajectory' && reentry.length === 0 && b2body.length === 0
  console.log(ok ? 'B2-RESULT: PASS —— 3 轮 0 次被动回轨迹，0 次自激重入，10 秒停留不回退'
    : 'B2-RESULT: FAIL —— 见上方可疑明细（stack 即真凶）')
} catch (e) {
  console.log('DIAG-ERROR: ' + String((e && e.stack) || e).slice(0, 500))
} finally {
  try { if (cdp) cdp.close() } catch { /* noop */ }
  killOwn()
  await sleep(1200)
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}
