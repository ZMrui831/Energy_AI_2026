// tools/dev-agent.mjs —— S73 开发者 Agent 接口（CLI）
//
// 与 /dev 插件命令（packages\plugins\coach\dev-cmd.mjs）**共享同一实现**：
// CLI 只是把参数经同一条 plugin:command IPC 送进应用（不绕护栏），然后轮询
// data\dev\last-result.json 取回完整 JSON，并等 `answer-persisted` 审计确认落盘。
//
// 纪律：本文件**无 fetch 调用 / 无 writeFileSync 调用**（验收 ⑪ 源码断言）；读日志/结果一律走 safefs 的 logPath/dataPath。
// 用法：
//   node tools\dev-agent.mjs shot [--label x]
//   node tools\dev-agent.mjs ask "<问题>" [--mode auto|chat|recall]
//   node tools\dev-agent.mjs prompt get|set|history|rollback ...
//   node tools\dev-agent.mjs log tail --file coach --n 20 ｜ log grep --pattern re
//   node tools\dev-agent.mjs bench --suite <path.json> [--repeat 3] [--out <path.json>]
//   node tools\dev-agent.mjs --port=9336 ...   （应用 CDP 端口，默认 9336）
import { existsSync, readFileSync, statSync } from 'node:fs'
import http from 'node:http'
import { devResultFile } from '../packages/plugins/coach/dev-cmd.mjs'
import { logPath } from '../packages/core/src/safefs.mjs'

const PORT = Number((process.argv.find((a) => a.startsWith('--port=')) || '').split('=')[1]) || 9336
const argv = process.argv.slice(2).filter((a) => !a.startsWith('--port='))
const TIMEOUT = 420000
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const fileSig = (p) => (existsSync(p) ? `${statSync(p).size}:${statSync(p).mtimeMs}` : '')

function httpGetJson(url) {
  return new Promise((res, rej) => {
    http.get(url, (r) => { let b = ''; r.on('data', (c) => { b += c }); r.on('end', () => { try { res(JSON.parse(b)) } catch (e) { rej(e) } }) }).on('error', rej)
  })
}

async function findTarget(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const list = await httpGetJson(`http://127.0.0.1:${PORT}/json/list`)
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(String(t.url || '')))
      if (page) return page
    } catch { /* 应用未起/端口未开 → 继续等 */ }
    await sleep(400)
  }
  return null
}

function cdpConnect(url) {
  const WebSocket = globalThis.WebSocket || null
  if (!WebSocket) throw new Error('本 Node 无内置 WebSocket（需 ≥22）')
  const ws = new WebSocket(url)
  let id = 0
  const pending = new Map()
  ws.addEventListener('message', (m) => {
    try { const msg = JSON.parse(String(m.data)); if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id) } } catch { /* 非 JSON 忽略 */ }
  })
  const ready = new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', () => rej(new Error('CDP WebSocket 连接失败'))) })
  const send = (method, params = {}) => new Promise((res, rej) => {
    const mid = ++id
    pending.set(mid, (m) => (m.error ? rej(new Error(m.error.message)) : res(m.result)))
    ws.send(JSON.stringify({ id: mid, method, params }))
    setTimeout(() => { if (pending.has(mid)) { pending.delete(mid); rej(new Error('CDP 响应超时：' + method)) } }, 30000)
  })
  return { ready, send, close: () => { try { ws.close() } catch { /* noop */ } } }
}

const ev = async (cdp, expression) => {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r && r.exceptionDetails) throw new Error('evaluate: ' + JSON.stringify(r.exceptionDetails).slice(0, 200))
  return r && r.result ? r.result.value : undefined
}

async function main() {
  const argsStr = argv.join(' ')
  if (!argsStr.trim()) {
    console.log(JSON.stringify({ ok: false, code: 'E_USAGE', text: '用法：node tools\\dev-agent.mjs shot|ask|prompt|log|bench ...（详见 docs\\DEV-API.md）' }, null, 2))
    process.exit(2)
  }
  const rf = devResultFile()
  const sig0 = fileSig(rf)
  const startedAt = new Date().toISOString()

  const target = await findTarget(30000)
  if (!target) { console.error('[dev-agent] ✗ 未找到 research-orb 面板（应用未启动，或 --port 不对）'); process.exit(1) }
  const cdp = cdpConnect(target.webSocketDebuggerUrl)
  await cdp.ready
  await ev(cdp, `globalThis.researchOrb.send('ui', { type: 'plugin:command', name: 'dev', args: ${JSON.stringify(argsStr)} })`)

  // 轮询结果文件（/dev 命令写 last-result.json，带 args 回显——按参数精确匹配，慢命令不串台）
  const deadline = Date.now() + TIMEOUT
  let payload = null
  while (Date.now() < deadline) {
    await sleep(500)
    if (existsSync(rf) && fileSig(rf) !== sig0) {
      try { const j = JSON.parse(readFileSync(rf, 'utf8')); if (j && j.result && j.args === argsStr) { payload = j; break } } catch { /* 半截文件继续等 */ }
    }
  }
  if (!payload) { console.error('[dev-agent] ✗ ' + TIMEOUT / 1000 + 's 内未收到 /dev 结果'); process.exit(1) }

  let out = payload.result
  // ask：等答案落盘（app.jsonl 的 answer-persisted 审计）
  if (payload.sub === 'ask') {
    const apLog = logPath('app.jsonl')
    const d2 = Date.now() + 20000
    while (Date.now() < d2) {
      await sleep(500)
      try {
        if (existsSync(apLog)) {
          const rows = readFileSync(apLog, 'utf8').split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
          const hit = rows.filter((r) => r.type === 'answer-persisted' && String(r.ts || '') >= startedAt).pop()
          if (hit) { out = { ...out, persisted: true, sessionId: hit.sessionId, persistedChars: hit.chars, persistedSource: hit.source }; break }
        }
      } catch { /* 继续等 */ }
    }
    if (!out.persisted) {
      // 诊断：帮验收定位落盘审计为何未出现
      let dbg = { appLogExists: existsSync(apLog) }
      try {
        const rows = readFileSync(apLog, 'utf8').split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
        dbg.lastTypes = rows.slice(-8).map((r) => r.type || r.kind || '?')
      } catch { /* noop */ }
      out = { ...out, persisted: false, debug: dbg }
    }
  }
  console.log(JSON.stringify(out, null, 2))
  cdp.close()
  process.exit(out && out.ok !== false ? 0 : 1)
}

main().catch((e) => { console.error('[dev-agent] ✗ ' + String((e && e.message) || e)); process.exit(1) })
