// tools/accept-s39-chain.mjs —— S39·F1 证据链可视化验收（≥8 项）。
// 单行复跑：node tools\accept-s39-chain.mjs
// 证据：data\logs\s39-chain-accept.json
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'

process.env.ORB_LOG_DIR = join(tmpdir(), 's39-chain-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's39-chain-data-' + Date.now())
const { dataPath, PROJECT_ROOT } = await import('../packages/core/src/safefs.mjs')
const { buildEvidenceChain, renderChainMd, noEvidenceText } = await import('../packages/plugins/coach/chain.mjs')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

// 桩 store：真实 SQL 形状；raw_frame 2 条（1 ready 1 deleted）+ observation 1 + summary 1 + claim 1
function makeStubStore() {
  const writes = { insert: 0, delete: 0, update: 0 }
  const rawRows = [
    { id: 'rf-ok-1', sha256: 'a'.repeat(64), status: 'ready', created_at: '2026-10-23T10:00:00Z' },
    { id: 'rf-del-1', sha256: 'b'.repeat(64), status: 'deleted', created_at: '2026-10-23T10:05:00Z' },
  ]
  const obsRow = { id: 'ob-1', created_at: '2026-10-23T10:06:00Z' }
  const sumRow = { id: 'sum-1', created_at: '2026-10-23T10:07:00Z' }
  const claimRow = { id: 'claim-1', text: '微电网并网稳定性受控制策略影响', status: 'published', created_at: '2026-10-23T10:08:00Z' }
  const db = {
    prepare(sql) {
      if (/FROM claim WHERE id/.test(sql)) return { get: (id) => (id === 'claim-1' ? claimRow : null) }
      if (/FROM claim_evidence/.test(sql)) return { all: () => [
        { evidenceId: 'rf-ok-1', layer: 'raw_frame', ceSha: 'a'.repeat(64), relation: 'direct' },
        { evidenceId: 'rf-del-1', layer: 'raw_frame', ceSha: 'b'.repeat(64), relation: 'direct' },
        { evidenceId: 'ob-1', layer: 'observation', ceSha: '', relation: 'derived' },
        { evidenceId: 'sum-1', layer: 'summary', ceSha: '', relation: 'derived' },
      ] }
      if (/FROM observation WHERE/.test(sql)) return { get: () => obsRow }
      if (/FROM summary WHERE/.test(sql)) return { get: () => sumRow }
      return { get: () => null, all: () => [] }
    },
  }
  const store = {
    _db: db,
    getRawFrame(id) { return rawRows.find((r) => r.id === id) || null },
    getObservation(id) { return id === 'ob-1' ? obsRow : null },
    insertRawFrame() { writes.insert += 1; return { id: 'x' } },
    deleteRawFrame() { writes.delete += 1; return true },
    purgeExpired() { writes.delete += 1; return true },
  }
  return { store, writes, rawRows, obsRow, sumRow, claimRow }
}

try {
  const { store, writes, rawRows } = makeStubStore()
  const chain = buildEvidenceChain({ claimId: 'claim-1', store })
  const md = renderChainMd(chain)

  // C-1 节点数与 DB 一致（4 条引用 + claim 本体）
  check('C-1 节点数与 DB 一致', chain.ok && chain.nodes.length === 5 && chain.evidenceCount === 4,
    `nodes=${chain.nodes.length} evidence=${chain.evidenceCount}`, {})

  // C-2 点节点取 id（每节点块展示完整 id）
  const allIds = ['rf-ok-1', 'rf-del-1', 'ob-1', 'sum-1', 'claim-1'].every((id) => md.includes('id: ' + id))
  check('C-2 节点可点开取 id', allIds, `ids 全在=${allIds}`, {})

  // C-3 已删原图灰显 + 固定降级文案
  check('C-3 已删灰显+固定降级文案', md.includes('灰显') && md.includes('原图已按保留策略删除；保留时间、窗口、摘要与内容哈希，无法恢复画面'),
    `灰显标记+降级文案在`, {})

  // C-4 各节点字段齐（ts/sha256 前缀/availability）
  const fieldsOk = chain.nodes.every((n) => 'id' in n && 'ts' in n && 'sha256Prefix' in n && 'availability' in n)
  check('C-4 节点字段齐（id/ts/sha256/availability）', fieldsOk, `fields=${fieldsOk}`, {})

  // C-5 无证据提示（不空白）
  const empty = buildEvidenceChain({ claimId: 'claim-none', store })
  check('C-5 未找到结论不空白', empty.empty === true && /未找到结论/.test(empty.text || ''), `text=${(empty.text || '').slice(0, 30)}`, {})

  // C-6 该结论无证据：claim 存在但无引用行
  const db2 = store._db
  const origPrepare = db2.prepare.bind(db2)
  db2.prepare = (sql) => { if (/FROM claim_evidence/.test(sql)) return { all: () => [] }; return origPrepare(sql) }
  const noEv = buildEvidenceChain({ claimId: 'claim-1', store })
  const noEvText = noEvidenceText('claim-1')
  db2.prepare = origPrepare
  check('C-6 该结论无证据提示', noEv.evidenceCount === 0 && noEvText.includes('该结论无证据'),
    `evidence=0 提示文案在`, {})

  // C-7 只读零写入（spy 全程零调用）
  check('C-7 只读零写入', writes.insert === 0 && writes.delete === 0 && writes.update === 0,
    `insert=${writes.insert} delete=${writes.delete}`, {})

  // C-8 匿名 PASS（导出面板 md 过 check-anonymity）
  const outDir = mkdtempSync(join(tmpdir(), 's39-chain-'))
  const mdPath = join(outDir, 'chain.md')
  writeFileSync(mdPath, md, 'utf8')
  const anon = spawnSync(process.execPath, ['tools/check-anonymity.mjs', mdPath], { encoding: 'utf8', cwd: PROJECT_ROOT })
  check('C-8 导出面板匿名 PASS', anon.status === 0 || /PASS/.test(anon.stdout || ''), `exit=${anon.status}`, {})
  try { rmSync(outDir, { recursive: true, force: true }) } catch { /* 尽力 */ }

  // C-9 /coach chain 命令接线（静态断言）
  const idx = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'index.mjs'), 'utf8')
  check('C-9 /coach chain 接线', idx.includes("sub === 'chain'") && idx.includes('resolveLifecycleStore(ctx)'), `wired=true`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's39-chain-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s39-chain: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
