// tools/accept-stage5.mjs —— P-R5 收尾总验收：顺序调用 6 个子验收并汇总 stage5-summary.json
import { spawnSync } from 'node:child_process'
import { writeFileSync, existsSync, readFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const STEPS = [
  { id: '1-进程纪律静态', script: null, test: 'tests/process-discipline.test.mjs', desc: 'killTree 仅按 PID 树；无 /IM 批量杀；判据 classifyBrowserProcess；自检只读' },
  { id: '2-让路真实验证', script: 'tools/accept-stage5-yield.mjs', desc: '用户活动→等待/放弃；停止→恢复；SetCursorPos 合成输入；未抢占前台' },
  { id: '3-profile 持久化/隔离', script: 'tools/accept-stage5-profile.mjs', desc: '持久 profile 复用；临时模式集合比较证明不写 browser-profile' },
  { id: '4-合规自检', script: 'tools/accept-stage5-compliance.mjs', desc: '静态无伪装/绕鉴权/伪造头/清日志/批量；运行白名单外拒/限速/robots/审计字段' },
  { id: '5-隔离五查+外写扫描', script: 'tools/accept-stage5-isolation.mjs', desc: 'vendor/start 指纹、禁写目录归因、计划任务、残留进程、writes 越界' },
  { id: '6-electron 冒烟', script: 'tools/accept-smoke-electron.mjs', desc: 'bridge-injected 无异常、ui.jsonl ping、settings 往返、GUI 截图' },
  { id: '7-冷跑全量单测', script: null, cold: true, desc: 'node --test --test-concurrency=1 tests/*.test.mjs（干净 shell 复跑口径）' },
]

const run = (script) => {
  const r = spawnSync(process.execPath, [script], { cwd: PROJECT_ROOT, encoding: 'utf8', timeout: 400000, windowsHide: true, maxBuffer: 16 << 20 })
  const out = `${r.stdout || ''}${r.stderr || ''}`
  const pass = (out.match(/^PASS/gm) || []).length
  const fail = (out.match(/^FAIL/gm) || []).length
  return { ok: r.status === 0 && fail === 0, status: r.status, pass, fail, tail: out.split('\n').filter((l) => /^(PASS|FAIL|===|bridge|ui\.jsonl|settings|残留)/.test(l)).slice(-14).join(' | ') }
}

const items = []
for (const s of STEPS) {
  process.stdout.write(`\n>>> ${s.id} …\n`)
  let r
  if (s.cold) {
    // 冷跑：干净 shell 复跑同一命令，逐个列出 tests/*.test.mjs
    const testFiles = readdirSync(join(PROJECT_ROOT, 'tests')).filter((f) => f.endsWith('.test.mjs')).map((f) => `tests/${f}`)
    const full = spawnSync(process.execPath, ['--test', '--test-concurrency=1', ...testFiles], {
      cwd: PROJECT_ROOT, encoding: 'utf8', timeout: 500000, windowsHide: true, maxBuffer: 16 << 20,
    })
    const m = String(full.stdout || '').match(/# tests (\d+)[\s\S]*?# pass (\d+)[\s\S]*?# fail (\d+)/)
    const total = m ? Number(m[1]) : 0, passed = m ? Number(m[2]) : 0, failed = m ? Number(m[3]) : -1
    r = { ok: failed === 0 && total >= 453, status: full.status, pass: passed, fail: Math.max(failed, 0), tail: `tests=${total} pass=${passed} fail=${failed}` }
  } else if (s.test) {
    const t = spawnSync(process.execPath, ['--test', s.test], { cwd: PROJECT_ROOT, encoding: 'utf8', timeout: 200000, windowsHide: true })
    const m = String(t.stdout || '').match(/# tests (\d+)[\s\S]*?# pass (\d+)[\s\S]*?# fail (\d+)/)
    r = { ok: t.status === 0, status: t.status, pass: m ? Number(m[2]) : 0, fail: m ? Number(m[3]) : -1, tail: String(t.stdout || '').split('\n').filter((l) => /# (tests|pass|fail)/.test(l)).join(' ') }
  } else {
    r = run(s.script)
  }
  console.log(`    -> ok=${r.ok} pass=${r.pass} fail=${r.fail}`)
  items.push({ id: s.id, ok: r.ok, pass: r.pass, fail: r.fail, evidence: s.script || s.test, desc: s.desc })
}

const allOk = items.every((i) => i.ok)
const summary = {
  stage: 'P-R5',
  generatedAt: new Date().toISOString(),
  ok: allOk,
  coldRunCommand: 'node --test --test-concurrency=1 tests/*.test.mjs',
  evidenceFiles: [
    'data/logs/browser.jsonl',
    'data/logs/stage5-yield-evidence.json',
    'data/logs/stage5-isolation.txt',
    'data/logs/stage4-final-electron.txt',
    'data/shots/stage5-settings-version.png',
    'data/browser/arxiv.org/',
  ],
  items,
}
const out = join(PROJECT_ROOT, 'data', 'logs', 'stage5-summary.json')
writeFileSync(out, JSON.stringify(summary, null, 2), 'utf8')
console.log(`\n=== P-R5 总验收：${allOk ? '全部通过' : '存在失败项'} ===`)
console.log(`summary -> ${out}`)
for (const i of items) console.log(`${i.ok ? 'OK  ' : 'FAIL'} ${i.id} (pass=${i.pass} fail=${i.fail})`)
process.exit(allOk ? 0 : 1)