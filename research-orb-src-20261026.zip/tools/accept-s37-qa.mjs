// tools/accept-s37-qa.mjs —— S37·A 问答入笔记验收（≥8 项）。
// 单行复跑：node tools\accept-s37-qa.mjs
// 证据：data\logs\s37-qa-accept.json
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync, readdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

// 验收隔离：先设 ORB_LOG_DIR/ORB_DATA_DIR 再动态 import（safefs 在 import 时定格目录）
process.env.ORB_LOG_DIR = join(tmpdir(), 's37-qa-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's37-qa-data-' + Date.now())
const { dataPath } = await import('../packages/core/src/safefs.mjs')
const { appendQaTurn, isQaWorthy, listQa, searchQa, readQaLog, QA_MAX_DIGEST } = await import('../packages/plugins/coach/qa-log.mjs')
const { PROJECT_ROOT } = await import('../packages/core/src/safefs.mjs')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

const routerOk = { run: async () => ({ ok: true, text: '摘要：虚拟电厂需要先明确聚合商与电网的两级接口，再谈收益分成。' }) }
const routerFail = { run: async () => { throw new Error('gateway down') } }
const routerBad = { run: async () => ({ ok: false, error: { code: 'E_INVOKE' } }) }

try {
  const dir = dataPath('coach')
  mkdirSync(dir, { recursive: true })

  // Q-1 写入：正常问答 → qa.jsonl 一行，字段齐
  const r1 = await appendQaTurn({ question: '虚拟电厂的收益机制一般怎么设计？', answer: '通常分容量补偿、电量收益与辅助服务三类，聚合商与电网两级结算……'.repeat(3), sessionId: 's1', evidenceIds: ['rf-1'], router: routerOk, dir })
  const rows = readQaLog(dir)
  const row = rows[0]
  const fieldsOk = row && row.ts && row.question && row.answerDigest && row.source === 'qa' && 'sessionId' in row && Array.isArray(row.evidenceIds)
  check('Q-1 写入+字段齐', r1.written === true && rows.length === 1 && fieldsOk,
    `written=${r1.written} fields=${fieldsOk}`, {})

  // Q-2 摘要 ≤200
  check('Q-2 摘要 ≤200 字', row.answerDigest.length <= QA_MAX_DIGEST, `digestChars=${row.answerDigest.length}`, {})

  // Q-3 独立类型：不写 claim/不标 published/evidenceIds 弱引用可为空
  const src = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'qa-log.mjs'), 'utf8')
  const noClaim = !/insertRawFrame|claim_evidence|published|claimId/.test(src.replace(/不写 claim|不标 published/g, ''))
  const r3 = await appendQaTurn({ question: '无引用的问题也可以留痕吗？', answer: '可以，弱引用为空数组。', router: { run: async () => ({ ok: true, text: '弱引用为空也可以留痕，摘要各不相同。' }) }, dir })
  const row3 = readQaLog(dir)[0]
  check('Q-3 独立类型（无 claim/published；弱引用可空）', noClaim && r3.written === true && Array.isArray(row3.evidenceIds) && row3.evidenceIds.length === 0 && !('status' in row3),
    `srcClean=${noClaim} evidenceIds=[]`, {})

  // Q-4 寒暄/纯回执不入库
  const p1 = await appendQaTurn({ question: '谢谢', answer: '不客气', router: routerOk, dir })
  const p2 = await appendQaTurn({ question: '好的', answer: '嗯', router: routerOk, dir })
  check('Q-4 寒暄/纯回执不入库', p1.skipped === 'not-qa-worthy' && p2.skipped === 'not-qa-worthy' && readQaLog(dir).length === 2,
    `skipped=${p1.skipped}/${p2.skipped} rows=${readQaLog(dir).length}`, {})

  // Q-5 工具型请求不入库
  const p5 = await appendQaTurn({ question: '帮我打开刚才导出的文件', answer: '已打开', router: routerOk, dir })
  check('Q-5 工具型请求不入库', p5.skipped === 'not-qa-worthy', `skipped=${p5.skipped}`, {})

  // Q-6 失败静默：router 抛异常 → 不崩、不写
  const p6 = await appendQaTurn({ question: '这个报错栈说明什么？', answer: '长回答……', router: routerFail, dir })
  check('Q-6 失败静默（router 抛异常）', p6.ok === true && p6.written === false && readQaLog(dir).length === 2,
    `ok=${p6.ok} written=${p6.written} rows=2`, {})

  // Q-7 digest-unavailable：router 返回失败 → 静默跳过
  const p7 = await appendQaTurn({ question: '旗舰不可用时问答还留痕吗？', answer: '……', router: routerBad, dir })
  check('Q-7 摘要不可得 → 静默跳过', p7.skipped === 'digest-unavailable' && readQaLog(dir).length === 2,
    `skipped=${p7.skipped}`, {})

  // Q-8 list：时间戳 + 问题原文 + 摘要
  const l = listQa({ limit: 10, dir })
  const listBody = l.text.split('\n').filter((x) => /^\d+\. \[/.test(x))
  check('Q-8 list 输出（ts+问题+摘要）', l.ok && l.rows.length === 2 && listBody.length === 2 && listBody.every((x) => x.includes('问：')) && l.text.includes('摘要：'),
    `rows=${l.rows.length} bodyLines=${listBody.length}`, {})

  // Q-9 search：命中 + 未命中（'聚合商' 只出现在 row A 的摘要里，stub 各行摘要不同才可判命中数）
  const s1 = searchQa('聚合商', { dir })
  const s2 = searchQa('不存在的关键词xyz', { dir })
  check('Q-9 search 命中/未命中', s1.ok && s1.rows.length === 1 && s2.ok && s2.rows.length === 0 && s2.text.includes('未命中'),
    `hit=${s1.rows.length} miss=${s2.rows.length === 0}`, {})

  // Q-10 /coach qa 命令接线（静态断言）
  const idx = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'index.mjs'), 'utf8')
  check('Q-10 /coach qa list|search 接线', idx.includes("sub === 'qa'") && idx.includes("qaRest.startsWith('list')") && idx.includes("qaRest.startsWith('search')"),
    `wired=true`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's37-qa-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s37-qa: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
