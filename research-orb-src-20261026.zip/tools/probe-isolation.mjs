// tools/probe-isolation.mjs
//
// 验收 ⑧ 取证：证明本应用没有碰过 dsh-orb 的部署副本与 .dsh 下的运行时数据。
//
// 用法：
//   node tools\probe-isolation.mjs baseline [--tag stage2]   # 记基线（含 6 个关键文件哈希）
//   node tools\probe-isolation.mjs verify   [--tag stage2]   # 与基线对比，输出结论
//
// --tag 用于给不同阶段的现场分开留档（默认 stage1，兼容阶段 1 的既有证据不被覆盖）。
//
// 只读：全程不写除 data\shots\ 之外的任何路径。

import { createHash } from 'node:crypto'
import { existsSync, readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const DSH_ORB = `${process.env.USERPROFILE}\\.dsh\\profiles\\desktop\\node_modules\\dsh-orb`
const HELPER_DATA = `${process.env.USERPROFILE}\\.dsh\\dsh-orb\\helper-data`
const tagIdx = process.argv.indexOf('--tag')
const TAG = tagIdx >= 0 && process.argv[tagIdx + 1] ? String(process.argv[tagIdx + 1]).replace(/[^a-z0-9_-]/gi, '') : 'stage1'
const BASELINE = join(PROJECT_ROOT, 'data', 'shots', `${TAG}-iso-baseline.json`)
const VERIFY = join(PROJECT_ROOT, 'data', 'shots', `${TAG}-iso-verify.json`)

/** STAGE-LOG 里记录的 6 个关键文件与它们的哈希前缀（阶段 0 主管实测值）。 */
const KEY_FILES = {
  'dist/helper/lib/main.js': '9302492CBF888F0D',
  'dist/helper/assets/shell.js': 'AAD8FF97C0B12EBF',
  'dist/helper/preload.cjs': 'CF1B7AA4069F1804',
  'dist/helper/assets/floating.html': null,
  'dist/helper/assets/floating.css': null,
  'dist/host/index.js': '1A396A240E538B59',
}

function walk(dir, out = []) {
  if (!existsSync(dir)) return out
  for (const name of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, name.name)
    if (name.isDirectory()) walk(p, out)
    else if (name.isFile()) out.push(p)
  }
  return out
}

function fingerprint(dir) {
  const files = walk(dir).sort()
  const h = createHash('sha256')
  let totalBytes = 0
  let newest = null
  const listing = []
  for (const f of files) {
    const st = statSync(f)
    const rel = f.slice(dir.length + 1)
    // 被运行中的 helper 独占的文件读不到内容：退回 size+mtime 指纹（仍能发现改写）
    let contentHash
    try {
      contentHash = createHash('sha256').update(readFileSync(f)).digest('hex')
    } catch (err) {
      contentHash = `${err.code}:${st.size}:${Math.round(st.mtimeMs)}`
    }
    h.update(rel + '\u0000' + st.size + '\u0000' + contentHash + '\n')
    totalBytes += st.size
    const mtime = new Date(st.mtimeMs).toISOString()
    if (!newest || mtime > newest.mtime) newest = { rel, mtime }
    listing.push({ rel, size: st.size, mtime })
  }
  return { exists: existsSync(dir), files: files.length, totalBytes, digest: h.digest('hex'), newest, listing }
}

function keyHashes() {
  const out = {}
  for (const rel of Object.keys(KEY_FILES)) {
    const abs = join(DSH_ORB, ...rel.split('/'))
    if (!existsSync(abs)) {
      out[rel] = { exists: false }
      continue
    }
    const sha = createHash('sha256').update(readFileSync(abs)).digest('hex').toUpperCase()
    out[rel] = {
      exists: true,
      sha256: sha,
      prefix: sha.slice(0, 16),
      recorded: KEY_FILES[rel],
      matchesRecorded: KEY_FILES[rel] ? sha.slice(0, 16) === KEY_FILES[rel] : null,
    }
  }
  return out
}

const mode = process.argv[2] || 'verify'

const snapshot = {
  ts: new Date().toISOString(),
  mode,
  dshOrb: fingerprint(DSH_ORB),
  helperData: fingerprint(HELPER_DATA),
  keyFiles: keyHashes(),
}

if (mode === 'baseline') {
  writeFileSync(BASELINE, JSON.stringify(snapshot, null, 2))
  process.stdout.write(`baseline: dsh-orb digest=${snapshot.dshOrb.digest.slice(0, 24)}… files=${snapshot.dshOrb.files}\n`)
  process.stdout.write(`baseline: helper-data digest=${snapshot.helperData.digest.slice(0, 24)}… files=${snapshot.helperData.files}\n`)
  process.stdout.write(`baseline: helper-data newest=${snapshot.helperData.newest ? snapshot.helperData.newest.rel + ' @ ' + snapshot.helperData.newest.mtime : 'n/a'}\n`)
  for (const [rel, info] of Object.entries(snapshot.keyFiles)) {
    process.stdout.write(`  key ${rel}: ${info.exists ? info.prefix + (info.matchesRecorded === false ? '  (与 STAGE-LOG 不符!)' : '  (与 STAGE-LOG 一致)') : 'MISSING'}\n`)
  }
  process.stdout.write(`baseline -> ${BASELINE}\n`)
  process.exit(0)
}

if (!existsSync(BASELINE)) {
  process.stderr.write('缺少基线，请先跑 baseline\n')
  process.exit(2)
}

const base = JSON.parse(readFileSync(BASELINE, 'utf8'))
const beforeList = new Set(base.helperData.listing.map((f) => f.rel))
const nowList = new Set(snapshot.helperData.listing.map((f) => f.rel))
const added = [...nowList].filter((r) => !beforeList.has(r))
const removed = [...beforeList].filter((r) => !nowList.has(r))

// 与我们无关的天然变化：orb 自己的日志/workers 会自己写
const ORB_OWN = /^dsh-orb-(helper\.log|workers\.json)$/
const oursLike = added.filter((r) => !ORB_OWN.test(r))

const verdict = {
  dshOrbDigestUnchanged: base.dshOrb.digest === snapshot.dshOrb.digest,
  dshOrbFileCountUnchanged: base.dshOrb.files === snapshot.dshOrb.files,
  helperDataDigestUnchanged: base.helperData.digest === snapshot.helperData.digest,
  helperDataAdded: added,
  helperDataRemoved: removed,
  helperDataAddedByUs: oursLike,
  keyFilesMatchStage0: Object.values(snapshot.keyFiles).every((k) => k.matchesRecorded !== false && k.exists),
  windowMs: Date.parse(snapshot.ts) - Date.parse(base.ts),
}

const out = { ...snapshot, baselineTs: base.ts, verdict }
writeFileSync(VERIFY, JSON.stringify(out, null, 2))

process.stdout.write(`观察窗：${(verdict.windowMs / 1000).toFixed(1)} s\n`)
process.stdout.write(`dsh-orb 目录：digest ${verdict.dshOrbDigestUnchanged ? 'UNCHANGED' : 'CHANGED!'}  files ${verdict.dshOrbFileCountUnchanged ? '不变' : '数量变化!'} (${snapshot.dshOrb.files})\n`)
process.stdout.write(`helper-data：digest ${verdict.helperDataDigestUnchanged ? 'UNCHANGED' : 'CHANGED'}  新增 ${added.length} 个 ${JSON.stringify(added.slice(0, 8))}\n`)
process.stdout.write(`我方新增：${oursLike.length} 个 ${JSON.stringify(oursLike.slice(0, 8))}\n`)
process.stdout.write(`6 个关键文件与阶段 0 记录：${verdict.keyFilesMatchStage0 ? '一致' : '不一致!'}\n`)
process.stdout.write(`verify -> ${VERIFY}\n`)

const ok = verdict.dshOrbDigestUnchanged && verdict.dshOrbFileCountUnchanged && oursLike.length === 0 && verdict.keyFilesMatchStage0
process.stdout.write(ok ? 'ISOLATION PROBE OK\n' : 'ISOLATION PROBE FAILED\n')
process.exit(ok ? 0 : 1)
