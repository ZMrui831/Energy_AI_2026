#!/usr/bin/env node
// tools/quarantine-chromium-leftovers.mjs
//
// 阶段 3.1 卫生（收尾）：把 GPU 对照实验期间（2026-10-15 19:47，userData 被临时指回
// data\）重新生成的 Chromium userData 产物，从 data\ 顶层隔离搬迁到
// data/logs/chromium-experiment-leftovers-<日期>/ 留证，恢复「data\ 顶层只有领域目录」。
//
// 与 move-chromium-cache.mjs 的关系：后者负责一次性迁移（data\ -> data\.chromium\）；
// 本工具处理「迁移后又复现」的残渣——此时 .chromium\ 下同名目标已存在，不能直接 rename
// 覆盖，故改为隔离区留证（不删除、不覆盖、可回溯）。
//
// 纪律（与 move-chromium-cache.mjs 一致）：
//   · 白名单式搬迁 —— 只搬【已知的 Chromium userData 产物】名单里的项，名单外一律不碰；
//   · 同分区 rename，不复制不删除，失败即中止并报告；
//   · 运行中的 Electron 会占用这些文件：启动前自动检查 research-orb 进程，有则中止；
//   · 结果写 data/logs/chromium-leftovers-quarantine.json 留痕。
//
// 用法：node tools/quarantine-chromium-leftovers.mjs [--dry-run]

import { existsSync, mkdirSync, readdirSync, renameSync, statSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'
import { countOrbAllEx } from './_orb-proc.mjs'

const ROOT = resolveRoot()
const DATA_DIR = join(ROOT, 'data')
const LOGS_DIR = join(DATA_DIR, 'logs')

// 与 tools/move-chromium-cache.mjs 同一份白名单（Chromium userData 产物，按名精确匹配）
const CHROMIUM_ITEMS = [
  'Cache',
  'Code Cache',
  'DIPS',
  'DIPS-wal',
  'DawnGraphiteCache',
  'DawnWebGPUCache',
  'DevToolsActivePort',
  'Dictionaries',
  'GPUCache',
  'Local State',
  'Local Storage',
  'Network',
  'Preferences',
  'Session Storage',
  'Shared Dictionary',
  'blob_storage',
  'declarative_performance_observer.db',
  'declarative_performance_observer.db-journal',
]

function resolveRoot() {
  const here = new URL('.', import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1')
  return join(here, '..')
}

function topLevel() {
  return readdirSync(DATA_DIR).sort()
}

function walkStats(p) {
  let files = 0
  let bytes = 0
  const stack = [p]
  while (stack.length) {
    const cur = stack.pop()
    const st = statSync(cur)
    if (st.isDirectory()) {
      for (const name of readdirSync(cur)) stack.push(join(cur, name))
    } else {
      files += 1
      bytes += st.size
    }
  }
  return { files, bytes }
}

const DRY = process.argv.includes('--dry-run')

// 前置检查：research-orb 的 electron 不能在跑（会占用这些文件）。fail-closed。
// S74c·P0-1：只读计数统一走 _orb-proc。**保留原 fail-closed 强度**（查询失败也要中止），
// 所以用带 ok 标志的 countOrbAllEx —— 若用 countOrbAll，查询失败会被折成 0 从而放行，属于放宽。
const probe = countOrbAllEx()
if (!probe.ok) {
  console.error(`中止：无法确认 research-orb 进程状态（powershell 查询失败：${probe.stderr.slice(0, 120)}）—— fail-closed，未动任何文件`)
  process.exit(1)
}
const running = probe.count
if (Number.isFinite(running) && running > 0) {
  console.error(`中止：检测到 ${running} 个 research-orb electron 进程正在运行，先退出应用再搬（fail-closed）`)
  process.exit(1)
}
console.log('进程检查：research-orb electron 运行中 0 个，可以搬迁')

const before = topLevel()
console.log(`data\\ 顶层（隔离前，${before.length} 项）：`)
console.log('  ' + before.join('  '))

const QUARANTINE = join(LOGS_DIR, 'chromium-experiment-leftovers-20261015')
if (!DRY && !existsSync(QUARANTINE)) {
  mkdirSync(QUARANTINE, { recursive: true })
  console.log(`已创建隔离区 ${QUARANTINE}`)
}

const quarantined = []
const missing = []
for (const name of CHROMIUM_ITEMS) {
  const from = join(DATA_DIR, name)
  if (!existsSync(from)) {
    missing.push(name)
    continue
  }
  const st = statSync(from)
  const stats = st.isDirectory() ? walkStats(from) : { files: 1, bytes: st.size }
  if (DRY) {
    console.log(`[dry-run] 将隔离 ${name}（${st.isDirectory() ? '目录' : '文件'}，${stats.files} 个文件，${stats.bytes} B）`)
    quarantined.push({ name, ...stats })
    continue
  }
  const to = join(QUARANTINE, name)
  if (existsSync(to)) {
    console.error(`中止：隔离区已存在 ${name}，避免覆盖——请先人工确认 ${QUARANTINE}`)
    process.exit(1)
  }
  renameSync(from, to)
  quarantined.push({ name, ...stats })
  console.log(`隔离 ${name}（${st.isDirectory() ? '目录' : '文件'}，${stats.files} 个文件，${stats.bytes} B）`)
}

const after = topLevel()
console.log(`\ndata\\ 顶层（隔离后，${after.length} 项）：`)
console.log('  ' + after.join('  '))

if (!DRY) {
  const report = {
    at: new Date().toISOString(),
    reason: 'GPU 对照实验（userData 临时指回 data\\）于 2026-10-15 19:47 复现的 Chromium userData 产物；现行 userData 为 data\\.chromium\\，这些为残渣，隔离留证不删除',
    quarantined,
    missing,
    dataTopBefore: before,
    dataTopAfter: after,
    quarantineDir: QUARANTINE,
  }
  mkdirSync(LOGS_DIR, { recursive: true })
  const logPath = join(LOGS_DIR, 'chromium-leftovers-quarantine.json')
  writeFileSync(logPath, JSON.stringify(report, null, 2))
  console.log(`\n留痕：data/logs/chromium-leftovers-quarantine.json`)
}
console.log(`\n汇总：隔离 ${quarantined.length} 项，不存在 ${missing.length} 项`)
