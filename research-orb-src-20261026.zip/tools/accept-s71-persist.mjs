// tools/accept-s71-persist.mjs —— S71·P0-2 回答落盘验收
// 单行复跑：node tools\accept-s71-persist.mjs
import { readFileSync, rmSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import * as sessions from '../packages/core/src/session.mjs'
import { shouldPersistAnswer, persistCommandAnswer } from '../packages/core/src/answer-persist.mjs'

const items = []
const check = (id, ok, detail = '') => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300) }); console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`) }

let sid = null
try {
  // ① 召回答案落盘：assistant 行含 source:'recall' + text + frameIds，且 readSession 可重读
  const s = sessions.createSession({ title: 'S71持久化测试' })
  sid = s.id
  const result = { ok: true, recall: true, text: '（最近 30 分钟）记录到 1 条：\n18:00 在「Word」——写论文（fr-test001）' }
  const pr = persistCommandAnswer({ sessions, sessionId: sid, result })
  const rd = sessions.readSession(sid)
  const asst = (rd.turns || []).filter((t) => t.type === 'assistant')
  const a = asst[asst.length - 1] || {}
  check('S-1 召回答案落盘（assistant 行含 source:recall + text + frameIds），重开可读', pr.persisted === true && asst.length >= 1 && a.source === 'recall' && /fr-test001/.test(String(a.text || '')) && Array.isArray(a.frameIds) && a.frameIds.includes('fr-test001'), `persisted=${pr.persisted} source=${a.source}`)

  // ② 空答案不写
  check('S-2 空答案不写（shouldPersist=false）', shouldPersistAnswer({ ok: true, text: '' }) === false)
  // ③ 失败不写
  check('S-3 失败结果不写（ok:false）', shouldPersistAnswer({ ok: false, text: 'x' }) === false)
  // ④ 普通内部命令（无 recall/persist）不写 —— 防 status 轮询污染会话
  check('S-4 普通命令（如"状态已刷新"）不写（无 recall/persist）', shouldPersistAnswer({ ok: true, text: '状态已刷新。' }) === false)
  // ⑤ 主进程接线：tryCommand 带 source/frameIds；plugin:command 调 persistCommandAnswer
  const main = readFileSync(join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs'), 'utf8')
  const wired = main.includes('persistCommandAnswer(') && /source:\s*_src/.test(main) && /frameIds:\s*String\(_ansText/.test(main) && /answer-persisted/.test(main)
  check('S-5 主进程接线（tryCommand 带 source/frameIds + plugin:command 落盘 + audit answer-persisted）', wired)
} catch (e) {
  check('S-0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  // 清理测试会话文件，不污染真实会话
  try { if (sid) { const p = sessions.sessionPath(sid); if (existsSync(p)) rmSync(p, { force: true }) } } catch { /* noop */ }
}

const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s71-persist: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(items.every((i) => i.ok) ? 0 : 1)
