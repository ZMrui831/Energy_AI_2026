// tools/accept-s47-ui-consistency.mjs —— S47·P1 面板视觉一致性验收（8 项）
//
// 单行复跑：node tools\accept-s47-ui-consistency.mjs
//
// 全部断言都在真 Electron + CDP 里读 **computedStyle**，不看源码字符串 ——
// DESIGN-UI §10 的四条（alpha / 字阶 / 圆角 / 空态）只有算出来的值才算数。
//
// 隔离：启动时把 ORB_DATA_DIR 指到临时目录（顺带复验 P0），真实 data 不碰。

import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import { spawn, spawnSync } from 'node:child_process'
import {killMarked, countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-s47-ui-consistency')

const ELECTRON = ORB_ELECTRON
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9334
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 340) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}

function countProcs() { return countOrbAll() }
function killOwn() { return killMarked(MARK) }

async function findTarget(timeoutMs = 40000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await res.json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(String(t.url || '')))
      if (page) return page
    } catch {
      /* 还没起来 */
    }
    await sleep(350)
  }
  return null
}

function cdpConnect(wsUrl) {
  const ws = new WebSocket(wsUrl)
  let seq = 0
  const pending = new Map()
  const ready = new Promise((resolve, reject) => {
    ws.addEventListener('open', () => resolve())
    ws.addEventListener('error', (e) => reject(new Error('ws error')))
  })
  ws.addEventListener('message', (ev) => {
    let m = null
    try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
    if (!m || !m.id) return
    const p = pending.get(m.id)
    if (!p) return
    pending.delete(m.id)
    if (m.error) p.rej(new Error(JSON.stringify(m.error)))
    else p.res(m.result)
  })
  const send = (method, params) => new Promise((res, rej) => {
    const id = ++seq
    pending.set(id, { res, rej })
    ws.send(JSON.stringify({ id, method, params }))
  })
  return { ready, send, close: () => { try { ws.close() } catch { /* noop */ } } }
}

async function evaluate(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r && r.exceptionDetails) throw new Error('evaluate 异常：' + JSON.stringify(r.exceptionDetails).slice(0, 300))
  return r && r.result ? r.result.value : undefined
}

/** 页内探针：一次性把所有视觉事实取回来（避免多次往返时状态漂移）。 */
const PROBE = `(() => {
  const panel = document.getElementById('panel')
  if (!panel) return JSON.stringify({ error: 'no-panel' })
  const pcs = getComputedStyle(panel)
  const sizes = new Set(), radii = new Set(), weights = new Set()
  for (const el of panel.querySelectorAll('*')) {
    const r = el.getBoundingClientRect()
    if (r.width < 1 || r.height < 1) continue
    const cs = getComputedStyle(el)
    if (cs.visibility === 'hidden' || cs.display === 'none' || cs.opacity === '0') continue
    sizes.add(cs.fontSize)
    if (cs.borderRadius && cs.borderRadius !== '0px') radii.add(cs.borderRadius.split(' ')[0])
    weights.add(cs.fontWeight)
  }
  const navBtns = Array.from(document.querySelectorAll('#ro-ds-nav .ds-nav-btn'))
  const labels = navBtns.map((b) => b.getAttribute('aria-label') || b.title || '')
  const emptyNodes = Array.from(panel.querySelectorAll('[data-empty-state]'))
  const empties = emptyNodes.map((n) => {
    const t = n.querySelector('.ds-empty-text')
    const btn = n.querySelector('button')
    return { text: (t && t.textContent || '').trim(), hasBtn: !!btn, visible: !n.hidden }
  })
  const visibleLists = Array.from(panel.querySelectorAll('.s5-list')).filter((n) => n.offsetParent !== null)
  const listsWithEmpty = visibleLists.filter((n) => {
    const sib = n.nextElementSibling
    return !!(sib && sib.hasAttribute('data-empty-state'))
  }).length
  const text = document.body.innerText || ''
  const ball = document.getElementById('ball')
  const br = ball ? ball.getBoundingClientRect() : { left: 0, top: 0, right: 0, bottom: 0, width: 0, height: 0 }
  const pr = panel.getBoundingClientRect()
  const intersect = !(br.right <= pr.left || br.left >= pr.right || br.bottom <= pr.top || br.top >= pr.bottom)
  const dot = document.querySelector('#ro-s5-topbar .ds-dot')
  const foot = document.getElementById('ro-ds-foot')
  const diag = document.getElementById('ro-ds-diag')
  // 技术词定位器：把含禁词的**最小元素**抓出来（只报可见的），便于直接改文案而不是猜
  const BAN = /reasoner|rpm|sk-|降级/
  const hits = []
  for (const el of panel.querySelectorAll('*')) {
    if (el.children.length > 0) continue
    const t = (el.textContent || '').trim()
    if (!t || !BAN.test(t)) continue
    const r = el.getBoundingClientRect()
    hits.push({ tag: el.tagName, id: el.id || '', cls: String(el.className || '').slice(0, 40), vis: r.width > 0 && r.height > 0, t: t.slice(0, 90) })
  }
  const fr = foot ? foot.getBoundingClientRect() : null
  const footInfo = foot ? { fs: getComputedStyle(foot).fontSize, display: getComputedStyle(foot).display, w: Math.round(fr.width), h: Math.round(fr.height), text: (foot.textContent || '').trim() } : null
  return JSON.stringify({
    bg: pcs.backgroundColor,
    backdrop: pcs.backdropFilter || pcs.webkitBackdropFilter || '',
    sizes: Array.from(sizes).sort(),
    radii: Array.from(radii).sort(),
    navCount: navBtns.length,
    labels,
    empties,
    visibleListCount: visibleLists.length,
    listsWithEmpty,
    text: text.slice(0, 6000),
    intersect,
    ball: { x: Math.round(br.left), y: Math.round(br.top), w: Math.round(br.width), h: Math.round(br.height), right: Math.round(br.right), bottom: Math.round(br.bottom) },
    panel: { x: Math.round(pr.left), y: Math.round(pr.top), w: Math.round(pr.width), h: Math.round(pr.height), right: Math.round(pr.right), bottom: Math.round(pr.bottom) },
    dotState: dot ? dot.getAttribute('data-state') : null,
    footText: foot ? (foot.textContent || '').trim() : null,
    footInfo,
    banHits: hits.slice(0, 8),
    diagOpen: diag ? !!diag.open : null,
    page: (window.__s5 && window.__s5.currentPage) ? window.__s5.currentPage() : null,
  })
})()`

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s47-ui-'))
const tmpData = join(tmpRoot, 'data')
let child = null
let cdp = null

try {
  if (countProcs() > 0) {
    check('U-0 预检（已有实例在跑则退出）', false, '请先关闭 research-orb 再复跑')
    throw new Error('preflight')
  }

  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  delete env.ORB_LOG_DIR
  env.ORB_DATA_DIR = tmpData
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], { cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] })
  const tail = []
  const push = (b) => { tail.push(String(b)); while (tail.length > 30) tail.shift() }
  if (child.stdout) child.stdout.on('data', push)
  if (child.stderr) child.stderr.on('data', push)

  const target = await findTarget()
  if (!target) {
    check('U-0 应用启动（CDP 出现 floating.html）', false, '未起来：' + tail.join('').slice(-600))
    throw new Error('no-target')
  }
  cdp = cdpConnect(target.webSocketDebuggerUrl)
  await cdp.ready
  await cdp.send('Runtime.enable')
  await cdp.send('Page.enable')

  // 等桥注入，再展开面板
  let bridge = false
  const deadline = Date.now() + 30000
  while (Date.now() < deadline) {
    try {
      bridge = await evaluate(cdp, 'typeof globalThis.researchOrb === "object" && !!globalThis.researchOrb')
      if (bridge) break
    } catch { /* 还没好 */ }
    await sleep(400)
  }
  check('U-1 桥注入（researchOrb 可用）', bridge === true, bridge ? '已注入' : '30s 未注入')

  await evaluate(cdp, 'globalThis.researchOrb && globalThis.researchOrb.send("window", { action: "expand" })')
  await sleep(1400) // 面板开合 160ms + 领域首屏渲染

  let probe = null
  try {
    probe = JSON.parse(await evaluate(cdp, PROBE))
  } catch (e) {
    check('U-2 页内探针', false, String((e && e.message) || e).slice(0, 200))
    throw e
  }
  if (probe.error) {
    check('U-2 页内探针', false, JSON.stringify(probe))
    throw new Error(probe.error)
  }
  console.log('  [INFO] 探针：' + JSON.stringify({ bg: probe.bg, sizes: probe.sizes, radii: probe.radii, nav: probe.navCount, page: probe.page, dot: probe.dotState, foot: probe.footText, diagOpen: probe.diagOpen }))
  console.log('  [INFO] 底栏：' + JSON.stringify(probe.footInfo) + ' 禁词命中：' + JSON.stringify(probe.banHits))

  // ① 面板不透明度 alpha ≥ 0.92
  const m = /rgba?\(([^)]+)\)/.exec(probe.bg || '')
  let alpha = 1
  if (m) {
    const parts = m[1].split(',').map((x) => Number(String(x).trim()))
    alpha = parts.length >= 4 ? parts[3] : 1
  }
  check('U-1 面板 bg alpha ≥ 0.92（壁纸不得透字）', alpha >= 0.92 && /blur/.test(String(probe.backdrop)), `bg=${probe.bg} alpha=${alpha} backdrop=${probe.backdrop}`)

  // ② 字阶 ⊆ {11,12,13,14} 且 ≥4 档在用
  const ALLOW_FS = ['11px', '12px', '13px', '14px']
  const badFs = (probe.sizes || []).filter((s) => !ALLOW_FS.includes(s))
  check('U-2 字阶 ⊆ {11,12,13,14} 且 ≥4 档在用', badFs.length === 0 && (probe.sizes || []).length >= 4, `在用=${JSON.stringify(probe.sizes)} 越界=${JSON.stringify(badFs)}`)

  // ③ 圆角 ⊆ {8,10,14,999}
  const ALLOW_R = ['8px', '10px', '14px', '999px']
  const badR = (probe.radii || []).filter((r) => !ALLOW_R.includes(r))
  check('U-3 圆角 ⊆ {8,10,14,999}', badR.length === 0, `在用=${JSON.stringify(probe.radii)} 越界=${JSON.stringify(badR)}`)

  // ④ 左侧导航 6 项且 label 无重复
  const labels = probe.labels || []
  const uniq = new Set(labels)
  check('U-4 左侧导航=6 且 label 无重复', probe.navCount === 6 && uniq.size === 6 && labels.every((x) => x), `count=${probe.navCount} labels=${JSON.stringify(labels)}`)

  // ⑤ 每个可见列表都有空态节点
  check('U-5 每个列表都有 [data-empty-state]', probe.visibleListCount > 0 && probe.listsWithEmpty === probe.visibleListCount, `可见列表=${probe.visibleListCount} 带空态=${probe.listsWithEmpty} 空态节点=${(probe.empties || []).length}`)

  // ⑥ 可见文本不含技术指标 / 明文路径
  const text = String(probe.text || '')
  const hasMs = /\bms\b/.test(text) || /\d\s*ms\b/.test(text)
  const bannedWords = ['reasoner', 'rpm', 'sk-', '降级']
  const hitWords = bannedWords.filter((w) => text.includes(w))
  const hasDrive = /[A-Za-z]:\\/.test(text)
  check('U-6 默认态不露技术指标（ms/reasoner/rpm/降级/sk-/盘符）', !hasMs && hitWords.length === 0 && !hasDrive, `ms=${hasMs} 命中=${JSON.stringify(hitWords)} 盘符=${hasDrive} 诊断折叠=${probe.diagOpen === false}`)

  // ⑦ 球位于面板内（S51 回退后球嵌在面板标题行内 —— 旧断言「不相交」是球悬浮面板外时代的几何）
  const b7 = probe.ball, p7 = probe.panel
  const ballInside = b7.w > 0 && b7.x >= p7.x && b7.right <= p7.right && b7.y >= p7.y && b7.bottom <= p7.bottom
  check('U-7 球完全位于面板内（S51 契约：球嵌标题行）', ballInside, `球=${JSON.stringify(probe.ball)} 面板=${JSON.stringify(probe.panel)} 在内=${ballInside}`)

  // ⑧ 空态文案 ≤40 字且含主按钮
  const empties = (probe.empties || []).filter((e) => e.visible)
  const longOnes = empties.filter((e) => e.text.length > 40)
  const noBtn = empties.filter((e) => !e.hasBtn)
  check('U-8 空态文案 ≤40 字且含主按钮', empties.length > 0 && longOnes.length === 0 && noBtn.length === 0, `可见空态=${empties.length} 超 40 字=${longOnes.length} 缺按钮=${noBtn.length} 例="${(empties[0] && empties[0].text) || ''}"`)
} catch (e) {
  if (String((e && e.message) || e) !== 'preflight' && String((e && e.message) || e) !== 'no-target' && String((e && e.message) || e) !== 'no-panel') {
    check('U-0 验收脚本异常', false, String((e && e.stack) || e).slice(0, 300))
  }
} finally {
  try { if (cdp) cdp.close() } catch { /* noop */ }
  killOwn()
  await sleep(1500)
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}

const total = items.length
const passed = items.filter((i) => i.ok).length
const failed = total - passed
console.log(`  # accept-s47-ui-consistency: total=${total} pass=${passed} fail=${failed}`)
process.exitCode = failed === 0 ? 0 : 1
