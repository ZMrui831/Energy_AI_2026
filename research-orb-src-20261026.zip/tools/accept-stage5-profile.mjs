// tools/accept-stage5-profile.mjs
//
// P-R5 必做 3：持久化登录态 + 「临时 profile 不落 cookie」。
//
// 三项证据：
//   A) data\browser-profile\ 内容清单 + **profile 被复用**的演示（两次持久浏览后
//      profile 内文件 mtime/数量发生变化 → 证明是同一个 profile 被反复使用，
//      而不是每次新建）。
//   B) 临时 profile 模式**不写入** data\browser-profile\：递归集合比较（不是顺序比较），
//      要求 (路径集合, 大小, mtime 精度到秒) 三元组在临时浏览前后完全一致。
//   C) 临时 profile 自身建在 data\tmp\ 下并在结束后被清理（best-effort），
//      且其证据文件标注 usedTempProfile=true。

import { readdirSync, statSync, existsSync, readFileSync, rmSync } from 'node:fs'
import { join, relative, sep } from 'node:path'

import { createBrowserEngine } from '../packages/plugins/research-browser/lib/engine.mjs'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const URL = 'https://arxiv.org/abs/2301.00001'
const PERSIST = join(PROJECT_ROOT, 'data', 'browser-profile')

let failures = 0
const check = (cond, label, extra = {}) => {
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${label}`)
  if (!cond) failures += 1
  return { ok: !!cond, label, ...extra }
}

/** 递归快照：path -> {size, mtimeSec}，返回**排序后的集合数组**（顺序无关的可比较形式）。 */
function snapshotTree(root) {
  const rows = []
  const walk = (dir) => {
    let names = []
    try { names = readdirSync(dir) } catch { return }
    for (const n of names) {
      const p = join(dir, n)
      let st
      try { st = statSync(p) } catch { continue }
      if (st.isDirectory()) { walk(p); continue }
      rows.push(`${relative(root, p)}|${st.size}|${Math.floor(st.mtimeMs / 1000)}`)
    }
  }
  walk(root)
  return rows.sort()
}

async function main() {
  console.log('=== P-R5 必做 3：持久化登录态 / 临时 profile 不落 cookie ===')

  const engine = createBrowserEngine({})

  // --- A) 持久 profile 清单 + 复用演示 ---
  const listing = []
  const walkTop = (dir, depth = 0) => {
    for (const n of readdirSync(dir)) {
      const p = join(dir, n)
      let st
      try { st = statSync(p) } catch { continue }
      listing.push(`${'  '.repeat(depth)}${n}${st.isDirectory() ? '/' : ''}`)
      if (depth === 0 && st.isDirectory() && ['Default', 'Crashpad'].includes(n)) walkTop(p, depth + 1)
    }
  }
  if (existsSync(PERSIST)) walkTop(PERSIST)
  console.log(`--- data/browser-profile 清单（${listing.length} 项，节选 30）---`)
  listing.slice(0, 30).forEach((l) => console.log('  ' + l))
  for (const key of ['Default/Preferences', 'Default/Login Data', 'Default/History', 'Local State']) {
    check(existsSync(join(PERSIST, ...key.split('/'))), `持久 profile 含 ${key}（登录态可持久化，需人工登录一次）`)
  }

  const beforeFirst = snapshotTree(PERSIST)
  const r1 = await engine.browse({ url: URL }) // 持久模式（第 1 次）
  await new Promise((r) => setTimeout(r, 1500)) // 等落盘
  const afterFirst = snapshotTree(PERSIST)
  const r2 = await engine.browse({ url: URL }) // 持久模式（第 2 次，复用同一 profile）
  await new Promise((r) => setTimeout(r, 1500))
  const afterSecond = snapshotTree(PERSIST)
  check(r1.ok && r2.ok, '两次持久模式浏览均成功')
  check(afterFirst.length >= beforeFirst.length, '持久 profile 被复用并继续增长（同一 profile，非每次新建）')
  const grewOnSecond = afterSecond.length >= afterFirst.length
  check(grewOnSecond, `第二次持久浏览沿用同一 profile（条目 ${beforeFirst.length} → ${afterFirst.length} → ${afterSecond.length}）`)
  console.log(`  复用证据：条目数 ${beforeFirst.length} → ${afterFirst.length} → ${afterSecond.length}`)

  // --- B) 临时 profile 不写持久 profile（递归集合比较）---
  const t0 = snapshotTree(PERSIST)
  const rt = await engine.browse({ url: URL, opts: { temp: true } })
  await new Promise((r) => setTimeout(r, 800))
  const t1 = snapshotTree(PERSIST)
  check(rt.ok, `临时 profile 浏览成功（${rt.ok ? rt.path : rt.code}）`)
  check(rt.ok && rt.data.usedTempProfile === true, '证据标注 usedTempProfile=true')

  const added = t1.filter((x) => !t0.includes(x))
  const removed = t0.filter((x) => !t1.includes(x))
  const changed = t1.filter((x) => t0.includes(x) && x !== t0.find((y) => y.split('|')[0] === x.split('|')[0]))
  console.log(`  临时浏览前后持久 profile：条目 ${t0.length} → ${t1.length}；新增 ${added.length}，删除 ${removed.length}，变更 ${changed.length}`)
  if (added.length) console.log('  新增: ' + added.slice(0, 5).join(' | '))
  if (changed.length) console.log('  变更: ' + changed.slice(0, 5).join(' | '))
  check(added.length === 0, '临时 profile 模式未向 data/browser-profile 新增任何文件（集合比较）')
  check(removed.length === 0, '临时 profile 模式未删除持久 profile 任何文件')
  check(changed.length === 0, '临时 profile 模式未改写持久 profile 任何文件（大小/mtime 未变）')

  // --- C) 临时 profile 建在 data/tmp 下并 best-effort 清理 ---
  const tmpRoot = join(PROJECT_ROOT, 'data', 'tmp')
  const leftovers = readdirSync(tmpRoot).filter((n) => n.startsWith('browser-profile-'))
  console.log(`  data/tmp 残留 browser-profile-* 目录：${leftovers.length} 个${leftovers.length ? '（' + leftovers.join(', ') + '）' : ''}`)
  check(leftovers.length === 0, '临时 profile 用后已清理（data/tmp 下无 browser-profile-* 残留）')

  console.log(`\n=== 结果：${failures === 0 ? '全部通过' : failures + ' 项失败'} ===`)
  process.exit(failures === 0 ? 0 : 1)
}

main().catch((e) => { console.error('profile 验收异常:', e); process.exit(2) })