// tools/accept-s67-dual-live.mjs
//
// S67·2-A 验收：双维评分真的出数字（关键词扩表 + 多类取多 + 真实 daily 产物校验）
//
// 纪律：绝不假绿；双维归不到就是 null，写清原因，绝不硬造分数。
// 用法：node tools/accept-s67-dual-live.mjs

import { existsSync, readFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { classifyLine, LINE_KEYWORDS } from '../packages/plugins/longterm-memory/lines.mjs'

const items = []
const addItem = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 320) })
  console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`)
  return ok
}

// D-1：work 命中（工作/科研类窗口）
const w1 = classifyLine('Windows Terminal 编译 文档')
addItem('D-1 work 命中', w1 === 'work', `"Windows Terminal 编译 文档" -> ${w1}`)

// D-2：life 命中（娱乐/生活类）
const l1 = classifyLine('哔哩哔哩 抖音 视频 动漫')
addItem('D-2 life 命中', l1 === 'life', `"哔哩哔哩 抖音 视频 动漫" -> ${l1}`)

// D-3：多类命中 → 取出现次数多的一类（work 严格多 / life 严格多）
const moreWork = classifyLine('deepseek 编译 bilibili') // work: deepseek+编译=2, life: bilibili=1
const moreLife = classifyLine('bilibili 抖音 terminal') // life: bilibili+抖音=2, work: terminal=1
addItem('D-3 多类取多（出现次数多者优先）',
  moreWork === 'work' && moreLife === 'life',
  `work多→${moreWork}(应work) life多→${moreLife}(应life)`)

// D-4：都不命中 → null（不猜）
const none = classifyLine('今天在客厅整理了书架')
addItem('D-4 都不中→null（不猜）', none === null, `"今天在客厅整理了书架" -> ${none}`)

// D-5：多类平票 → null（不猜）
const tie = classifyLine('python bilibili') // work:python=1, life:bilibili=1
addItem('D-5 平票→null（不猜）', tie === null, `"python bilibili" -> ${tie}`)

// D-6：真实 daily 产物——至少一维是数字，或含明确"未归类原因"
const dailyDir = join(PROJECT_ROOT, 'data', 'coach', 'daily')
let latest = null
try {
  const files = readdirSync(dailyDir).filter((f) => /^daily-\d{8}\.md$/.test(f)).sort()
  latest = files.length ? join(dailyDir, files[files.length - 1]) : null
} catch { /* 目录不存在 */ }
let d6ok = false
let d6detail = '缺日报文件'
if (latest && existsSync(latest)) {
  const md = readFileSync(latest, 'utf8')
  const mw = md.match(/workScore：\s*(\d+)/)
  const ml = md.match(/lifeScore：\s*(\d+)/)
  const workNum = mw ? Number(mw[1]) : null
  const lifeNum = ml ? Number(ml[1]) : null
  const hasReason = /未归类[：:]\s*\d+\s*条/.test(md) && /不猜/.test(md)
  if (workNum != null || lifeNum != null) {
    d6ok = true
    d6detail = `${latest.split(/[\\/]/).pop()}：work=${workNum != null ? workNum : 'n/a'} life=${lifeNum != null ? lifeNum : 'n/a'}`
  } else if (hasReason) {
    d6ok = true // 归不到就是 null，但必须有明确原因（任务允许的诚实降级）
    d6detail = `${latest.split(/[\\/]/).pop()}：双维 n/a，但含明确未归类原因（诚实降级）`
  } else {
    d6detail = `${latest.split(/[\\/]/).pop()}：双维 n/a 且无明确原因`
  }
} else {
  d6detail = `未找到 ${dailyDir} 下 daily-YYYYMMDD.md`
}
addItem('D-6 真实 daily 双维有数字或有明确原因', d6ok, d6detail)

// 附注：关键词表扩表自检（确保必需词在表内，避免静默回退）
const needWork = ['deepseek', 'zotero', 'endnote', 'overleaf', 'terminal', '代码', '编译', '文档', '日报', 'doi']
const needLife = ['哔哩', '聊天', '视频', '动漫', '游戏', '抖音']
const missW = needWork.filter((k) => !LINE_KEYWORDS.work.includes(k))
const missL = needLife.filter((k) => !LINE_KEYWORDS.life.includes(k))
addItem('D-7 扩表关键词齐全', missW.length === 0 && missL.length === 0,
  missW.length || missL.length ? `缺 work[${missW}] life[${missL}]` : `work ${LINE_KEYWORDS.work.length} 词 / life ${LINE_KEYWORDS.life.length} 词`)

const pass = items.every((i) => i.ok)
console.log(`\n[S67·2-A dual-live] ${items.filter((i) => i.ok).length}/${items.length} 通过 ${pass ? 'OK' : 'FAILED'}`)
process.exit(pass ? 0 : 1)
