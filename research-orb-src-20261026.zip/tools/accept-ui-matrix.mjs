// tools/accept-ui-matrix.mjs
//
// S5 UI 状态矩阵验收：真 electron + CDP。
//   ① 12 态截图落 data/shots/ui-matrix/（经 /ui state <name> 确定性触发）
//   ② 关键页面 SSIM ≥0.99 基线（首跑建基线，次跑比对）
//   ③ 设计检查报告：间距(4/8) / 字号(12/14/16/20) / 点击目标(≥32，关键≥40) / 对比度(≥4.5)
//   ④ 页面记忆（B）：首页→对话→收起→展开 → 仍停在对话页
//   ⑤ 几何契约（H）：96×96 / 420×620 / 右下锚点 + 无抢前台（源码无 focus() 调用）
//
// 纪律：fail-closed（已有 research-orb electron 在跑则退出）；只杀自己起的进程（按 PID 树）。

import { spawn, spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { inflateSync } from 'node:zlib'
import { join } from 'node:path'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { UI_STATES } from '../packages/plugins/timeline/logic.mjs'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-ui-matrix')

// S11：--refreeze 重冻基线（主题切青绿 + 四态表情后 UI 已变），
// 重冻前先取旧基线 sha256，重冻后记录 old→new 逐态哈希映射（§8 变更追认）。
const REFREEZE = process.argv.includes('--refreeze')
const sha256File = (p) => createHash('sha256').update(readFileSync(p)).digest('hex')

const ELECTRON_EXE = ORB_ELECTRON
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const SHOTS = join(PROJECT_ROOT, 'data', 'shots', 'ui-matrix')
const BASELINE = join(SHOTS, 'baseline')
const LOG = join(PROJECT_ROOT, 'data', 'logs', 'ui-matrix.txt')
const PORT = 9345

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const OUT = []
const log = (s) => { OUT.push(s); console.log(s) }
const results = []
const check = (cond, label, extra = '') => {
  log(`${cond ? 'PASS' : 'FAIL'}  ${label}${extra ? '  ' + extra : ''}`)
  results.push({ ok: !!cond, label, extra })
  return !!cond
}

// ---------------------------------------------------------------------------
// PNG 解码（无依赖：zlib inflate + 反滤波）→ {width,height,rgba}
// ---------------------------------------------------------------------------
function decodePng(buf) {
  let off = 8
  let width = 0, height = 0, bitDepth = 8, colorType = 6
  const idat = []
  while (off < buf.length) {
    const len = buf.readUInt32BE(off)
    const type = buf.toString('ascii', off + 4, off + 8)
    const data = buf.subarray(off + 8, off + 8 + len)
    if (type === 'IHDR') {
      width = data.readUInt32BE(0)
      height = data.readUInt32BE(4)
      bitDepth = data[8]
      colorType = data[9]
    } else if (type === 'IDAT') idat.push(data)
    off += 12 + len
  }
  if (bitDepth !== 8 || (colorType !== 6 && colorType !== 2)) throw new Error(`不支持的 PNG（bitDepth=${bitDepth}, colorType=${colorType}）`)
  const channels = colorType === 6 ? 4 : 3
  const raw = inflateSync(Buffer.concat(idat))
  const stride = width * channels
  const out = Buffer.alloc(height * stride)
  let prev = Buffer.alloc(stride)
  for (let y = 0; y < height; y++) {
    const filter = raw[y * (stride + 1)]
    const line = raw.subarray(y * (stride + 1) + 1, y * (stride + 1) + 1 + stride)
    const cur = out.subarray(y * stride, (y + 1) * stride)
    for (let x = 0; x < stride; x++) {
      const a = x >= channels ? cur[x - channels] : 0
      const b = prev[x]
      const c = x >= channels ? prev[x - channels] : 0
      let v = line[x]
      if (filter === 1) v = (v + a) & 0xff
      else if (filter === 2) v = (v + b) & 0xff
      else if (filter === 3) v = (v + ((a + b) >> 1)) & 0xff
      else if (filter === 4) {
        const p = a + b - c
        const pa = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c)
        v = (v + (pa <= pb && pa <= pc ? a : pb <= pc ? b : c)) & 0xff
      }
      cur[x] = v
    }
    prev = cur
  }
  return { width, height, channels, data: out }
}

function grayLuma(img) {
  const g = new Float64Array(img.width * img.height)
  for (let i = 0; i < g.length; i++) {
    const o = i * img.channels
    g[i] = 0.299 * img.data[o] + 0.587 * img.data[o + 1] + 0.114 * img.data[o + 2]
  }
  return g
}

/** 标准 SSIM（8×8 窗、C1/C2 稳定常数），返回全图均值。 */
function ssim(a, b) {
  if (a.width !== b.width || a.height !== b.height) return -1
  const ga = grayLuma(a), gb = grayLuma(b)
  const W = 8, C1 = (0.01 * 255) ** 2, C2 = (0.03 * 255) ** 2
  let total = 0, n = 0
  for (let y = 0; y + W <= a.height; y += W) {
    for (let x = 0; x + W <= a.width; x += W) {
      let sa = 0, sb = 0, saa = 0, sbb = 0, sab = 0
      for (let dy = 0; dy < W; dy++) {
        for (let dx = 0; dx < W; dx++) {
          const i = (y + dy) * a.width + (x + dx)
          const va = ga[i], vb = gb[i]
          sa += va; sb += vb; saa += va * va; sbb += vb * vb; sab += va * vb
        }
      }
      const N = W * W
      const ma = sa / N, mb = sb / N
      const cov = sab / N - ma * mb
      const ssimVal = ((2 * ma * mb + C1) * (2 * cov + C2)) / ((ma * ma + mb * mb + C1) * (saa / N - ma * ma + sbb / N - mb * mb + C2))
      total += ssimVal; n += 1
    }
  }
  return n > 0 ? total / n : -1
}

// ---------------------------------------------------------------------------
// CDP 最小客户端（同 stage6-appearance 口径）
// ---------------------------------------------------------------------------
async function findTarget(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await res.json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(t.url))
      if (page) return page
    } catch { /* 还没起来 */ }
    await sleep(300)
  }
  throw new Error(`CDP 目标未找到（port ${PORT}）`)
}

let cdp = null
async function connectCdp() {
  const target = await findTarget()
  const ws = new WebSocket(target.webSocketDebuggerUrl)
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve)
    ws.addEventListener('error', () => reject(new Error('CDP WebSocket 连接失败')))
  })
  const session = { ws, _id: 0, _pending: new Map() }
  ws.addEventListener('message', (ev) => {
    let m
    try { m = JSON.parse(ev.data) } catch { return }
    if (m.id !== undefined && session._pending.has(m.id)) {
      const p = session._pending.get(m.id)
      session._pending.delete(m.id)
      if (m.error) p.reject(new Error(m.error.message))
      else p.resolve(m.result)
    }
  })
  cdp = {
    send: (method, params = {}) => new Promise((resolve, reject) => {
      const id = ++session._id
      session._pending.set(id, { resolve, reject })
      session.ws.send(JSON.stringify({ id, method, params }))
    }),
    evaluate: async (expression) => {
      const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true })
      return r && r.result ? r.result.value : undefined
    },
  }
  await cdp.send('Page.enable')
  await cdp.send('Runtime.enable')
  return cdp
}

async function shot(name) {
  const s = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
  if (!s || !s.data) throw new Error('截图失败')
  const abs = join(SHOTS, name)
  writeFileSync(abs, Buffer.from(s.data, 'base64'))
  return abs
}

async function cmd(name, args) {
  return cdp.evaluate(`window.researchOrb && window.researchOrb.send('ui', { type: 'plugin:command', name: ${JSON.stringify(name)}, args: ${JSON.stringify(args)} })`)
}

// ---------------------------------------------------------------------------
// 设计探针（渲染进程内实测）
// ---------------------------------------------------------------------------
const PROBE_JS = `(() => {
  const root = document.getElementById('ro-s5')
  if (!root) return { ok: false, reason: 'no-ro-s5' }
  const out = { ok: true, fonts: [], paddings: [], gaps: [], targets: [], contrasts: [] }
  const px = (v) => { const m = /(-?[\\d.]+)px/.exec(v || ''); return m ? Number(m[1]) : null }
  const parseRgb = (s) => {
    const m = /rgba?\\((\\d+),\\s*(\\d+),\\s*(\\d+)(?:,\\s*([\\d.]+))?/.exec(s || '')
    if (!m) return null
    if (m[4] !== undefined && Number(m[4]) === 0) return null // 全透明不当背景
    return [Number(m[1]), Number(m[2]), Number(m[3])]
  }
  const lum = (c) => { const f = (x) => { x /= 255; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4) }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]) }
  const bgOf = (el) => { let n = el; while (n && n !== document.body) { const c = getComputedStyle(n).backgroundColor; const p = parseRgb(c); if (p) return p; n = n.parentElement } return [255, 255, 255] }
  const contrast = (el) => { const fg = parseRgb(getComputedStyle(el).color); const bg = bgOf(el); if (!fg) return null; const l1 = lum(fg), l2 = lum(bg); const hi = Math.max(l1, l2), lo = Math.min(l1, l2); return (hi + 0.05) / (lo + 0.05) }
  const walk = (el) => {
    const cs = getComputedStyle(el)
    if (el !== root) {
      const fs = px(cs.fontSize); if (fs) out.fonts.push(fs)
      const p = px(cs.padding); if (p != null) out.paddings.push(p)
      const m = px(cs.marginBottom); if (m != null) out.paddings.push(m)
      const g = px(cs.gap); if (g != null) out.gaps.push(g)
      if (el.tagName === 'BUTTON') { const r = el.getBoundingClientRect(); out.targets.push({ text: (el.textContent || '').slice(0, 8), w: Math.round(r.width), h: Math.round(r.height), key: /开始学习|结束学习|需要帮助|不用了/.test(el.textContent || '') }) }
      if (el.textContent && el.children.length === 0) { const c = contrast(el); if (c != null) out.contrasts.push(c) }
    }
    for (const ch of el.children) walk(ch)
  }
  walk(root)
  return out
})()`

async function main() {
  mkdirSync(SHOTS, { recursive: true })
  mkdirSync(BASELINE, { recursive: true })

  // fail-closed：已有 research-orb electron 在跑则退出

  if (countOrbAll() > 0) throw new Error('已有 research-orb electron 在运行（fail-closed）')

  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN_MJS], { cwd: PROJECT_ROOT, env: childEnv, stdio: 'ignore' })
  log(`electron pid=${child.pid}`)

  try {
    await connectCdp()
    await sleep(6000)
    await cdp.evaluate(`window.researchOrb.send('window', { action: 'expand' })`)
    await sleep(2500)

    // ---- F：12 态截图（D3：先冻结易变内容——状态条/通知条打桩，保证基线可比）----
    await cdp.evaluate(`window.__s5 ? window.__s5.freeze() : false`)
    await sleep(600)
    const prevBaseline = existsSync(join(BASELINE, 'default.png'))
    const firstBaseline = !prevBaseline || REFREEZE
    // 重冻前取证：旧基线逐态 sha256（§8 变更追认）
    const oldHashes = {}
    for (const st of UI_STATES) {
      const bp = join(BASELINE, `${st}.png`)
      oldHashes[st] = existsSync(bp) ? sha256File(bp) : null
    }
    for (const st of UI_STATES) {
      await cmd('ui', `state ${st}`)
      await sleep(700)
      const p = await shot(`${st}.png`)
      const bytes = readFileSync(p).length
      if (firstBaseline) writeFileSync(join(BASELINE, `${st}.png`), readFileSync(p))
      log(`shot: data/shots/ui-matrix/${st}.png (${bytes} bytes)${firstBaseline ? ' [基线]' : ''}`)
    }
    await cmd('ui', 'state default')
    await sleep(500)

    // S11：old→new 逐态哈希映射（重冻/首跑时落盘，供 §8 追认复核）
    if (REFREEZE || firstBaseline) {
      const states = {}
      let changed = 0
      for (const st of UI_STATES) {
        const bp = join(BASELINE, `${st}.png`)
        const nh = existsSync(bp) ? sha256File(bp) : null
        states[st] = { old: oldHashes[st], new: nh }
        if (oldHashes[st] && nh && oldHashes[st] !== nh) changed += 1
      }
      const mig = {
        generatedAt: new Date().toISOString(),
        reason: 'S11 外观变更（teal 默认 + 四态表情 + 球体动画）→ UI 基线重冻',
        contract: 'CONTRACT §8 变更追认',
        refreeze: REFREEZE,
        statesChanged: changed,
        states,
      }
      writeFileSync(join(SHOTS, 'baseline-s11-migration.json'), JSON.stringify(mig, null, 2) + '\n')
      log(`baseline-migration -> data/shots/ui-matrix/baseline-s11-migration.json（${changed}/${UI_STATES.length} 态哈希变化）`)
    }

    // ---- B：页面记忆（首页→对话→收起→展开 → 仍停对话页）----
    await cmd('ui', 'home')
    await sleep(400)
    await cdp.evaluate(`window.__s5 && window.__s5.page('chat')`)
    await sleep(600)
    const p1 = await shot('page-memory-chat-1.png')
    await cdp.evaluate(`window.researchOrb.send('window', { action: 'collapse' })`)
    await sleep(900)
    await cdp.evaluate(`window.researchOrb.send('window', { action: 'expand' })`)
    await sleep(1200)
    const pageAfter = await cdp.evaluate(`window.__s5 ? window.__s5.currentPage() : 'no-debug'`)
    const p2 = await shot('page-memory-chat-2.png')
    check(pageAfter === 'chat', '页面记忆：收起再展开仍停在对话页', `currentPage=${pageAfter}`)
    log(`page-memory shots: ${p1} / ${p2}`)

    // ---- SSIM（关键页面对基线）----
    if (!firstBaseline) {
      let worst = 1, worstName = ''
      for (const st of UI_STATES) {
        const a = join(SHOTS, `${st}.png`), b = join(BASELINE, `${st}.png`)
        if (!existsSync(a) || !existsSync(b)) continue
        const v = ssim(decodePng(readFileSync(a)), decodePng(readFileSync(b)))
        if (v < worst) { worst = v; worstName = st }
      }
      check(worst >= 0.99, '关键页面 SSIM ≥0.99 基线', `最差 ${worstName}=${worst.toFixed(4)}`)
    } else {
      log('INFO  首跑：基线已建立（data/shots/ui-matrix/baseline/），SSIM 比留给复跑')
    }

    // ---- G：设计检查（间距/字号/点击目标/对比度）----
    await cmd('ui', 'home')
    await sleep(800)
    // 冻结态下探针（状态条为打桩值；设计 token 实测不受影响）
    // 询问卡按钮要可测：先清冷却（调试行为，报告中注明）再触发一次 ask
    try {
      const ps = join(PROJECT_ROOT, 'data', 'timeline', 'proactive-state.json')
      if (existsSync(ps)) writeFileSync(ps, JSON.stringify({ intent: null, lastRejectedAt: null, nextAllowedAt: 0 }, null, 2))
    } catch { /* noop */ }
    await cmd('ui', 'ask')
    await sleep(900)
    const probe = await cdp.evaluate(PROBE_JS)
    if (!probe || !probe.ok) {
      check(false, '设计探针可执行', probe && probe.reason ? probe.reason : 'probe failed')
    } else {
      const badFonts = [...new Set(probe.fonts)].filter((f) => ![12, 14, 16, 20].includes(f))
      check(badFonts.length === 0, '字号阶梯 12/14/16/20', `实测 ${JSON.stringify([...new Set(probe.fonts)].sort((a, b) => a - b))}${badFonts.length ? ' 越界:' + badFonts : ''}`)
      const badSpace = [...new Set([...probe.paddings, ...probe.gaps])].filter((v) => v % 4 !== 0)
      check(badSpace.length === 0, '间距为 4/8 的倍数（4px 栅格）', `实测 ${JSON.stringify([...new Set([...probe.paddings, ...probe.gaps])].sort((a, b) => a - b))}${badSpace.length ? ' 越界:' + badSpace : ''}`)
      const badTargets = probe.targets.filter((t) => t.key ? (t.w < 40 || t.h < 40) : (t.w < 32 || t.h < 32))
      check(badTargets.length === 0, '点击目标 ≥32px（关键 ≥40px）', `实测 ${JSON.stringify(probe.targets)}${badTargets.length ? ' 越界:' + JSON.stringify(badTargets) : ''}`)
      const badContrast = probe.contrasts.filter((c) => c < 4.5)
      check(badContrast.length === 0, '正文对比度 ≥4.5:1', `实测 ${probe.contrasts.length} 处，最低 ${probe.contrasts.length ? Math.min(...probe.contrasts).toFixed(2) : 'n/a'}${badContrast.length ? ' 越界:' + badContrast.map((c) => c.toFixed(2)) : ''}`)
    }

    // ---- H：几何契约 + 无抢前台 ----
    const mainSrc = readFileSync(MAIN_MJS, 'utf8')
    check(/COLLAPSED_SIZE = \{ width: 96, height: 96 \}/.test(mainSrc), '几何契约：球 96×96 常量未变')
    check(/EXPANDED_SIZE = \{ width: 420, height: 620 \}/.test(mainSrc), '几何契约：展开 420×620 常量未变')
    check(!/\.focus\(\)/.test(mainSrc), '无抢前台：main.mjs 无 .focus() 调用')
    const appLines = existsSync(join(PROJECT_ROOT, 'data', 'logs', 'app.jsonl'))
      ? readFileSync(join(PROJECT_ROOT, 'data', 'logs', 'app.jsonl'), 'utf8').split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
      : []
    const expandedEvt = [...appLines].reverse().find((e) => e.type === 'panel-state' && e.expanded === true && e.bounds)
    check(!!expandedEvt && expandedEvt.bounds.width >= 420 && expandedEvt.bounds.width <= 428 && expandedEvt.bounds.height >= 620 && expandedEvt.bounds.height <= 628,
      '几何契约：展开实测 = 420×620 + 平台边框容差', expandedEvt ? `${expandedEvt.bounds.width}x${expandedEvt.bounds.height}` : 'n/a')
    check(/win\.showInactive\(\)/.test(mainSrc), '无抢前台：面板走 showInactive')

    // ---- E 降级文案（原图已删态）----
    await cmd('ui', 'state deleted')
    await sleep(700)
    const delText = await cdp.evaluate(`(() => { const ns = document.querySelectorAll('#s5-home .s5-note'); return Array.from(ns).map((n) => n.textContent).join(' ') })()`)
    check(/原图已按保留策略删除；保留时间、窗口、摘要与内容哈希，无法恢复画面/.test(delText || ''), 'E 降级文案：固定文案出现', (delText || '').slice(0, 50))
    await shot('state-deleted-check.png')
    await cmd('ui', 'state default')
  } finally {
    try { spawnSync('taskkill', ['/pid', String(child.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true }) } catch { /* noop */ }
    await sleep(800)

    check(countOrbAll()=== 0, '进程收尾：我方 electron 残留 = 0', String(countOrbAll()))
  }

  const failed = results.filter((r) => !r.ok).length
  writeFileSync(LOG, `=== S5 UI 矩阵验收 (${new Date().toISOString()}) ===\n${OUT.join('\n')}\n\n=== ${failed === 0 ? '全部通过' : failed + ' 项失败'}（共 ${results.length} 项）===\n`, 'utf8')
  log(`\nevidence -> ${LOG}`)
  log(`=== 结果：${failed === 0 ? '全部通过' : failed + ' 项失败'}（共 ${results.length} 项）===`)
  process.exit(failed === 0 ? 0 : 1)
}

main().catch((e) => { console.error('UI 矩阵验收异常:', e); process.exit(2) })
