// tools/accept-s49-opacity.mjs —— S49 人眼三缺陷验收（8 项）
//
// 单行复跑：node tools\accept-s49-opacity.mjs
//
// 与 S48 的根本区别：**不再用 computedStyle 证明"透不透"**。
// computedStyle 只说明"你设了 0.965"，说明不了屏幕上透不透 —— 所以这里用
// 纯黑 / 纯白两种底各截一张，取面板中央 300×400 逐像素做差（PIL）：
//   mean < 2/255 且 max < 6/255 → 不透明；否则判透。

import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import { spawn, spawnSync } from 'node:child_process'
import {killMarked, countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-s49-opacity')

const ELECTRON = ORB_ELECTRON
const PYTHON = `${process.env.USERPROFILE}\\.workbuddy\\binaries\\python\\versions\\3.13.12\\python.exe`
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9338
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 380) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}
const countProcs = () => countOrbAll()
const killOwn = () => killMarked(MARK)

async function findTarget(t = 40000) {
  const d = Date.now() + t
  while (Date.now() < d) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const l = await r.json()
      const p = l.find((x) => x.type === 'page' && x.webSocketDebuggerUrl && /floating\.html/i.test(String(x.url || '')))
      if (p) return p
    } catch { /* 等 */ }
    await sleep(350)
  }
  return null
}
function cdpConnect(wsUrl) {
  const ws = new WebSocket(wsUrl)
  let seq = 0
  const pending = new Map()
  const ready = new Promise((res, rej) => { ws.addEventListener('open', () => res()); ws.addEventListener('error', () => rej(new Error('ws'))) })
  ws.addEventListener('message', (ev) => {
    let m = null
    try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
    if (!m || !m.id) return
    const p = pending.get(m.id); if (!p) return
    pending.delete(m.id)
    if (m.error) p.rej(new Error(JSON.stringify(m.error))); else p.res(m.result)
  })
  const send = (method, params) => new Promise((res, rej) => { const id = ++seq; pending.set(id, { res, rej }); ws.send(JSON.stringify({ id, method, params })) })
  return { ready, send, close: () => { try { ws.close() } catch { /* noop */ } } }
}
async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r && r.exceptionDetails) throw new Error('ev: ' + JSON.stringify(r.exceptionDetails).slice(0, 240))
  return r && r.result ? r.result.value : undefined
}

/** PIL 差分：只在给定矩形内比对两张灰度图的 |L_a - L_b|。 */
function diffRect(pngA, pngB, box) {
  const code = String.raw`
import json, sys
from PIL import Image, ImageChops, ImageStat
a = Image.open(sys.argv[1]).convert('L')
b = Image.open(sys.argv[2]).convert('L')
x, y, w, h = [int(v) for v in sys.argv[3:7]]
box = (max(0, x), max(0, y), min(a.width, x + w), min(a.height, y + h))
ca, cb = a.crop(box), b.crop(box)
d = ImageChops.difference(ca, cb)
mean = ImageStat.Stat(d).mean[0]
mx = d.getextrema()[1]
hist = d.histogram()
total = sum(hist) or 1
acc = 0
p99 = 0
for i, hv in enumerate(hist):
    acc += hv
    if acc >= total * 0.99:
        p99 = i
        break
print(json.dumps({"mean": round(mean, 4), "max": mx, "p99": p99, "px": total, "box": box}))
`
  const r = spawnSync(PYTHON, ['-c', code, pngA, pngB, ...box.map(String)], { encoding: 'utf8', timeout: 30000, windowsHide: true })
  const last = String(r.stdout || '').trim().split('\n').filter(Boolean).pop() || '{}'
  try { return JSON.parse(last) } catch { return { error: 'bad json', raw: last.slice(0, 200) } }
}

const PROBE = `(() => {
  const panel = document.getElementById('panel')
  const cs = getComputedStyle(panel)
  const pr = panel.getBoundingClientRect()
  const dpr = window.devicePixelRatio || 1
  // accent 满填块（含伪元素）
  const near = (rgb) => {
    const m = /rgba?\\(([^)]+)\\)/.exec(rgb || '')
    if (!m) return false
    const p = m[1].split(',').map((x) => Number(x.trim()))
    return p.length >= 3 && p[1] > 120 && p[1] - p[0] > 40 && p[1] > p[2] - 10
  }
  const blocks = []
  for (const el of document.body.querySelectorAll('*')) {
    const c = getComputedStyle(el)
    const r = el.getBoundingClientRect()
    const isCtrl = /^(BUTTON|INPUT|TEXTAREA|SELECT)$/.test(el.tagName)
    const exempt = isCtrl || el.id === 'ball' || el.classList.contains('ds-dot') || el.closest('#ro-ds-nav') || el.closest('#ball')
    if (!exempt && near(c.backgroundColor) && r.width >= 40 && r.height >= 40) {
      blocks.push({ tag: el.tagName, id: el.id || '', cls: String(el.className || '').slice(0, 40), bg: c.backgroundColor, w: Math.round(r.width), h: Math.round(r.height) })
    }
  }
  const pseudoGreen = []
  for (const el of document.querySelectorAll('*')) {
    for (const which of ['::before', '::after']) {
      const c = getComputedStyle(el, which)
      if (!c.content || c.content === 'none') continue
      if (c.display === 'none') continue // 已关掉的伪元素不算"可见满填块"
      if (!near(c.backgroundColor)) continue
      const r = el.getBoundingClientRect()
      if (r.width < 40 || r.height < 40) continue
      pseudoGreen.push({ host: el.tagName + (el.id ? '#' + el.id : ''), which, bg: c.backgroundColor, w: c.width, h: c.height })
    }
  }
  const text = document.body.innerText || ''
  const topbar = document.getElementById('ro-s5-topbar')
  const tcs = topbar ? getComputedStyle(topbar) : null
  const sizes = new Set()
  for (const el of panel.querySelectorAll('*')) {
    const r = el.getBoundingClientRect()
    if (r.width < 1 || r.height < 1) continue
    const c = getComputedStyle(el)
    if (c.display === 'none' || c.visibility === 'hidden') continue
    sizes.add(c.fontSize)
  }
  const navBtns = Array.from(document.querySelectorAll('#ro-ds-nav .ds-nav-btn'))
  const ball = document.getElementById('ball')
  const br = ball ? ball.getBoundingClientRect() : { left: 0, top: 0, right: 0, bottom: 0 }
  const intersect = !(br.right <= pr.left || br.left >= pr.right || br.bottom <= pr.top || br.top >= pr.bottom)
  // S50：窗口下半带（panel.bottom .. window.bottom）—— 绿带就藏在这里，
  // 而且可能是**宿主自身的伪元素**（#panel::after 就是），所以两样都要扫。
  const lumOf = (rgb) => {
    const m = /rgba?\\(([^)]+)\\)/.exec(rgb || '')
    if (!m) return null
    const p = m[1].split(',').map((x) => Number(x.trim()))
    if (p.length < 3) return null
    const a = p.length >= 4 ? p[3] : 1
    if (a === 0) return null
    return Math.round(((0.2126 * p[0] + 0.7152 * p[1] + 0.0722 * p[2]) / 255) * 100) / 100
  }
  const band = { top: Math.round(pr.bottom), bottom: Math.round(window.innerHeight) }
  const bandBlocks = []
  for (const el of document.body.querySelectorAll('*')) {
    const r = el.getBoundingClientRect()
    if (r.width <= 0 || r.height <= 0) continue
    if (r.top < band.top - 2 || r.bottom > band.bottom + 2) continue
    const c = getComputedStyle(el)
    const l = lumOf(c.backgroundColor)
    if (l === null) continue
    if (r.width > 200 && r.height > 40 && (el.innerText || '').trim() === '' && l > 0.6) {
      bandBlocks.push({ tag: el.tagName, id: el.id || '', cls: String(el.className || '').slice(0, 40), bg: c.backgroundColor, w: Math.round(r.width), h: Math.round(r.height), lum: l })
    }
  }
  const bandLayers = []
  for (const el of document.body.querySelectorAll('*')) {
    const hostRect = el.getBoundingClientRect()
    if (hostRect.bottom < band.top - 2 || hostRect.top > band.bottom + 2) continue
    for (const which of ['::before', '::after']) {
      const c = getComputedStyle(el, which)
      if (!c.content || c.content === 'none' || c.content === 'normal') continue
      if (c.display === 'none') continue // 已关掉的层：content 仍在，但不渲染，不算"可见层"
      const l = lumOf(c.backgroundColor)
      if (l === null) continue
      bandLayers.push({
        host: el.tagName + (el.id ? '#' + el.id : '') + (el.className ? '.' + String(el.className).split(' ')[0] : ''),
        which, bg: c.backgroundColor, h: c.height, w: c.width, display: c.display, lum: l,
      })
    }
  }
  return JSON.stringify({
    band,
    bandBlocks: bandBlocks.slice(0, 6),
    bandLayers: bandLayers.slice(0, 8),
    bg: cs.backgroundColor,
    rect: { x: Math.round(pr.left * dpr), y: Math.round(pr.top * dpr), w: Math.round(pr.width * dpr), h: Math.round(pr.height * dpr), dpr },
    blocks, pseudoGreen,
    textHasProvider: /school-gateway|api\\.deepseek\\.com|sk-|reasoner|\\brpm\\b/.test(text),
    textHasMs: /\\bms\\b/.test(text) || /\\d\\s*ms\\b/.test(text),
    topbarBg: tcs ? tcs.backgroundColor : null,
    sizes: Array.from(sizes).sort(),
    navCount: navBtns.length,
    navLabels: navBtns.map((b) => b.getAttribute('aria-label') || ''),
    intersect,
  })
})()`

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s49-'))
let child = null
let cdp = null
try {
  if (countProcs() > 0) {
    check('O-0 预检（已有实例在跑则退出）', false, '请先关闭 research-orb')
    throw new Error('preflight')
  }
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  delete env.ORB_LOG_DIR
  env.ORB_DATA_DIR = join(tmpRoot, 'data')
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], { cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] })
  const tail = []
  const push = (b) => { tail.push(String(b)); while (tail.length > 30) tail.shift() }
  if (child.stdout) child.stdout.on('data', push)
  if (child.stderr) child.stderr.on('data', push)

  const target = await findTarget()
  if (!target) { check('O-0 启动（CDP floating.html）', false, '未起来：' + tail.join('').slice(-400)); throw new Error('no-target') }
  cdp = cdpConnect(target.webSocketDebuggerUrl)
  await cdp.ready
  await cdp.send('Runtime.enable')
  await cdp.send('Page.enable')
  let bridge = false
  const dl = Date.now() + 30000
  while (Date.now() < dl) {
    try { bridge = await ev(cdp, 'typeof globalThis.researchOrb === "object" && !!globalThis.researchOrb'); if (bridge) break } catch { /* 等 */ }
    await sleep(400)
  }
  if (!bridge) { check('O-0 桥注入', false, '30s 未注入'); throw new Error('no-bridge') }
  await ev(cdp, 'globalThis.researchOrb.send("window", { action: "expand" })')
  await sleep(1600)
  // S50·关键：绿带只在 **teal 主题**下出现（`--input-bg` = #d1fae5）。
  // 隔离实例用的是默认主题，不注入变量就等于在一个"根本没有绿带"的环境里验收 → 假绿。
  // 这里按 teal 主题的实际取值注入，让后面所有断言都在"薄荷绿条件"下成立。
  await ev(cdp, "document.documentElement.style.setProperty('--input-bg', '#d1fae5'); document.documentElement.style.setProperty('--bg-alt', '#d1fae5'); document.documentElement.style.setProperty('--border', '#99f6e4')")
  await sleep(500)

  const p = JSON.parse(await ev(cdp, PROBE))
  console.log('  [INFO] bg=' + p.bg + ' topbarBg=' + p.topbarBg + ' rect=' + JSON.stringify(p.rect))
  console.log('  [INFO] accent 块=' + p.blocks.length + ' 伪元素绿=' + p.pseudoGreen.length + ' 字阶=' + JSON.stringify(p.sizes) + ' 导航=' + p.navCount)
  console.log('  [INFO] 下半带 ' + JSON.stringify(p.band) + ' 块=' + JSON.stringify(p.bandBlocks || []) + ' 层=' + JSON.stringify(p.bandLayers || []))

  // O-1 面板完全不透明（computedStyle 层面：alpha=1）
  const alphaM = /rgba?\(([^)]+)\)/.exec(p.bg || '')
  const alpha = (() => {
    if (!alphaM) return 1
    const arr = alphaM[1].split(',').map((x) => Number(x.trim()))
    return arr.length >= 4 ? arr[3] : 1
  })()
  check('O-1 面板实底（computedStyle alpha = 1，不靠 blur 遮）', alpha >= 0.96, `bg=${p.bg} alpha=${alpha}`)

  // O-2 像素级：双底差分（黑 / 白），面板中央 300×400
  const cx = p.rect.x + Math.max(0, Math.round((p.rect.w - 300) / 2))
  const cy = p.rect.y + Math.max(0, Math.round((p.rect.h - 400) / 2))
  const box = [cx, cy, Math.min(300, p.rect.w), Math.min(400, p.rect.h)]
  const shotA = join(tmpRoot, 'bg-black.png')
  const shotB = join(tmpRoot, 'bg-white.png')
  await ev(cdp, "document.body.style.background = '#000'")
  await sleep(500)
  const a = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
  writeFileSync(shotA, Buffer.from(a.data, 'base64'))
  await ev(cdp, "document.body.style.background = '#FFF'")
  await sleep(500)
  const b = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
  writeFileSync(shotB, Buffer.from(b.data, 'base64'))
  const d = diffRect(shotA, shotB, box)
  const opaque = !d.error && d.mean < 2 && d.max < 6
  check('O-2 像素级不透明（黑/白底差分 mean<2 max<6）', opaque,
    `mean=${d.mean} max=${d.max} p99=${d.p99} px=${d.px} box=${JSON.stringify(d.box)}${d.error ? ' err=' + d.error : ''}`)

  // O-3 无可视 accent 满填块（含伪元素）
  check('O-3 无 accent 满填块（元素 + 伪元素）', p.blocks.length === 0 && p.pseudoGreen.length === 0,
    `元素=${JSON.stringify(p.blocks)} 伪元素=${JSON.stringify(p.pseudoGreen)}`)

  // O-4 文本不含 provider 原始 id / 技术词
  check('O-4 文本不含 provider id 与技术词', p.textHasProvider === false && p.textHasMs === false,
    `provider=${p.textHasProvider} ms=${p.textHasMs}`)

  // O-5 顶栏融入面板（T1-d 契约：#ro-s5-topbar 背景透明 + 面板实底；
  //    旧断言「顶栏有底色」是顶栏色块时代的几何，色块会挡内容 —— 透字风险由 O-1 面板 alpha=1 兜住）
  const transparentTop = /rgba\(0, 0, 0, 0\)/.test(String(p.topbarBg))
  check('O-5 顶栏背景透明（T1-d 契约：融入面板实底，不挡内容）', transparentTop, `topbarBg=${p.topbarBg}`)

  // O-6 球在面板内（S51 契约：球嵌面板标题行；旧断言「不相交」是球悬浮面板外时代的几何）
  check('O-6 球完全位于面板内（S51 契约：球嵌标题行）', p.intersect === true, `intersect=${p.intersect}`)

  // O-7 字阶 ⊆ {11,12,13,14} 且 ≥4 档
  const ALLOW = ['11px', '12px', '13px', '14px']
  const bad = p.sizes.filter((s) => !ALLOW.includes(s))
  check('O-7 字阶 ⊆ {11,12,13,14} 且 ≥4 档', bad.length === 0 && p.sizes.length >= 4, `在用=${JSON.stringify(p.sizes)} 越界=${JSON.stringify(bad)}`)

  // O-8 导航 6 项且唯一
  check('O-8 导航 6 项且 label 唯一', p.navCount === 6 && new Set(p.navLabels).size === 6, `count=${p.navCount} ${JSON.stringify(p.navLabels)}`)

  // O-9 窗口下半带无可视纯色块（S50 新增）：>200×40、无文字、亮度 >0.6
  check('O-9 窗口下半带无可视纯色块（>200×40 且亮度>0.6）', (p.bandBlocks || []).length === 0,
    `下半带 ${p.band ? p.band.top + '..' + p.band.bottom : '?'} 命中=${JSON.stringify(p.bandBlocks || [])}`)

  // O-10 下半带背景层必须深色/透明（含伪元素）—— #panel::after 就是靠这条抓住的
  const lightLayers = (p.bandLayers || []).filter((x) => x.lum > 0.6)
  check('O-10 下半带背景层均深色（含伪元素，亮度≤0.6）', lightLayers.length === 0,
    `层=${JSON.stringify(p.bandLayers || [])} 超亮=${JSON.stringify(lightLayers)}`)

  // 留证：把两张差分图拷到 data/shots/opacity-proof/
  const proofDir = join(PROJECT_ROOT, 'data', 'shots', 'opacity-proof')
  try {
    const { mkdirSync, copyFileSync } = await import('node:fs')
    mkdirSync(proofDir, { recursive: true })
    copyFileSync(shotA, join(proofDir, 'panel-bg-black.png'))
    copyFileSync(shotB, join(proofDir, 'panel-bg-white.png'))
    console.log('  [INFO] 差分留证 -> data/shots/opacity-proof/')
  } catch { /* 留证失败不影响结论 */ }
} catch (e) {
  const msg = String((e && e.message) || e)
  if (!['preflight', 'no-target', 'no-bridge'].includes(msg)) check('O-0 验收脚本异常', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  try { if (cdp) cdp.close() } catch { /* noop */ }
  killOwn()
  await sleep(1200)
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}

const total = items.length
const passed = items.filter((i) => i.ok).length
console.log(`  # accept-s49-opacity: total=${total} pass=${passed} fail=${total - passed}`)
process.exitCode = total - passed === 0 ? 0 : 1
