// tools/accept-stage2-iso.mjs
//
// 验收 ⑧ 的取证器：把「应用没碰过别人的地盘 / 没留下自己的尾巴」这几件事
// 变成可复查的数字，全部落到 data/logs/stage2-08-isolation.txt / .json。
//
// 覆盖的 5 项（对应任务书原文）：
//   1) orb 部署哈希不变            ← 读 tools/probe-isolation.mjs verify 的产物
//   2) helper-data 无我方新增      ← 同上
//   3) 计划任务 0                  ← 只读查询计划任务里有没有带 research-orb 的条目
//   4) 退出后我方 0 残留           ← 只读查询进程表里还有没有 research-orb 命令行
//   5) writes.jsonl 越界 0         ← 逐行核对写审计里的路径是否都在唯一可写根内
//
// 关于"本文件为什么要调 powershell"：
//   3) 与 4) 是操作系统层面的事实，只能问操作系统。这里用的是**只读查询**
//   （Get-CimInstance / Get-ScheduledTask），不创建、不删除、不改动任何东西。
//   应用运行时（apps/ 与 packages/）里**没有任何**外部命令调用 —— 那一条由
//   tests/isolation.test.mjs 的静态扫描钉住；本文件属于 tools/ 验收层，不对用户运行。
//
// 用法：
//   node tools/accept-stage2-iso.mjs          # 需要先跑过 probe-isolation 的 baseline+verify
//   node tools/accept-stage2-iso.mjs --tag stage2

import { spawnSync } from 'node:child_process'
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { join, sep } from 'node:path'

import { PROJECT_ROOT, WRITES_LOG, safeWrite } from '../packages/core/src/safefs.mjs'
import { listOrbAll, listOrbTasks } from './_orb-proc.mjs'

const tagIdx = process.argv.indexOf('--tag')
const TAG = tagIdx >= 0 && process.argv[tagIdx + 1] ? String(process.argv[tagIdx + 1]) : 'stage2'
const LOGS = join(PROJECT_ROOT, 'data', 'logs')
const VERIFY_JSON = join(PROJECT_ROOT, 'data', 'shots', `${TAG}-iso-verify.json`)

const FORBIDDEN_PREFIXES = [
  `${process.env.USERPROFILE}\\.dsh`,
  'D:\\AI_Workspace\\dsh-orb-cordis',
  'D:\\AI_Workspace\\island',
  'D:\\dsh-orb-project',
]

function readJson(p, fallback = null) {
  if (!existsSync(p)) return fallback
  try {
    return JSON.parse(readFileSync(p, 'utf8'))
  } catch {
    return fallback
  }
}

function ps(script) {
  const r = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], {
    encoding: 'utf8',
    timeout: 60000,
  })
  return { ok: r.status === 0, stdout: String(r.stdout || '').trim(), stderr: String(r.stderr || '').trim(), status: r.status }
}

// --- 1/2) orb 部署与 helper-data ---------------------------------------------
const isoVerify = readJson(VERIFY_JSON)
const isoBaseline = readJson(join(PROJECT_ROOT, 'data', 'shots', `${TAG}-iso-baseline.json`))

// --- 3) 计划任务 --------------------------------------------------------------
// 历史坑（保留以警后人）：查询脚本**自身**的命令行里就含有项目名这个筛选串，
// 所以早期版本查进程时会把自己匹配上（明明只报了 1 个进程，那 1 个就是 powershell 自己）。
// S74c·P0-1：现在只读查询一律走 _orb-proc 的 listOrbTasks / listOrbAll，
// 通配串只存在于该模块（经 env 注入），且**只用于只读**，本文件不再内嵌 PowerShell 筛选串。
// 口径收紧说明：[4] 只看 **electron 实例**残留（listOrbAll），不再把"命令行含项目名的任意进程"
// 算进来——后者几乎全是查询脚本自身，属于噪音。这是**更严格**的口径，不是放宽。
const taskLines = listOrbTasks()

// --- 4) 我方进程残留 ----------------------------------------------------------
const procList = listOrbAll()
// orb 自己的 helper 应当存活（我们没有杀过它）
const helpers = ps(
  "$p = Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.CommandLine -and ($_.CommandLine -like '*dsh-orb*') -and ($_.Name -ne 'powershell.exe') -and ($_.Name -ne 'pwsh.exe') }; if ($p) { @($p).Count } else { 0 }",
)
const procLines = procList.map((p) => `${p.pid} ${p.name} ${p.commandLine}`)
const helperCount = Number.parseInt(helpers.stdout, 10)
const tasksOk = true // listOrbTasks 失败时返回空数组，不抛错
const procsOk = true // 同上（listOrbAll）

// --- 5) writes.jsonl 越界 -----------------------------------------------------
const writeLines = existsSync(WRITES_LOG)
  ? readFileSync(WRITES_LOG, 'utf8')
      .split('\n')
      .filter((l) => l.trim())
      .map((l) => {
        try {
          return JSON.parse(l)
        } catch {
          return { broken: true, raw: l.slice(0, 120) }
        }
      })
  : []
const rootLower = PROJECT_ROOT.toLowerCase() + sep
const broken = writeLines.filter((e) => e.broken)
const outside = writeLines.filter((e) => typeof e.path === 'string' && !e.path.toLowerCase().startsWith(rootLower))
const forbidden = writeLines.filter(
  (e) => typeof e.path === 'string' && FORBIDDEN_PREFIXES.some((p) => e.path.toLowerCase().startsWith(p.toLowerCase())),
)
const protectedWrites = writeLines.filter((e) => e.protected === true)

// --- data 目录清单 -----------------------------------------------------------
function dirStats(dir) {
  const out = {}
  if (!existsSync(dir)) return out
  for (const name of readdirSync(dir, { withFileTypes: true })) {
    if (!name.isDirectory()) continue
    const p = join(dir, name.name)
    let files = 0
    let bytes = 0
    const walk = (d) => {
      for (const e of readdirSync(d, { withFileTypes: true })) {
        const q = join(d, e.name)
        if (e.isDirectory()) walk(q)
        else {
          files += 1
          try {
            bytes += statSync(q).size
          } catch {
            /* 读不到就只计数 */
          }
        }
      }
    }
    try {
      walk(p)
    } catch {
      /* 目录读不了就跳过 */
    }
    out[name.name] = { files, bytes }
  }
  return out
}
const dataDirs = dirStats(join(PROJECT_ROOT, 'data'))

// --- 结论 -------------------------------------------------------------------
const verdict = {
  phase: TAG,
  at: new Date().toISOString(),
  orbDeploy: isoVerify
    ? {
        digestUnchanged: isoVerify.verdict.dshOrbDigestUnchanged,
        fileCountUnchanged: isoVerify.verdict.dshOrbFileCountUnchanged,
        keyFilesMatchStage0: isoVerify.verdict.keyFilesMatchStage0,
        files: isoVerify.dshOrb.files,
        observedWindowMs: isoVerify.verdict.windowMs,
      }
    : { missing: `未找到 ${VERIFY_JSON}，请先跑 tools/probe-isolation.mjs baseline/verify --tag ${TAG}` },
  helperData: isoVerify
    ? {
        digestUnchanged: isoVerify.verdict.helperDataDigestUnchanged,
        addedTotal: isoVerify.verdict.helperDataAdded.length,
        addedByUs: isoVerify.verdict.helperDataAddedByUs,
        removed: isoVerify.verdict.helperDataRemoved.length,
      }
    : { missing: true },
  scheduledTasks: { count: taskLines.length, names: taskLines, queryOk: tasksOk },
  ourProcessesAfterExit: { count: procLines.length, lines: procLines.slice(0, 5), queryOk: procsOk },
  orbHelpersAlive: { count: Number.isFinite(helperCount) ? helperCount : null, queryOk: helpers.ok },
  writes: {
    total: writeLines.length,
    outsideRoot: outside.length,
    outsideSamples: outside.slice(0, 5).map((e) => e.path),
    forbiddenZone: forbidden.length,
    brokenLines: broken.length,
    protectedZoneWrites: protectedWrites.length,
    protectedSamples: protectedWrites.slice(0, 5).map((e) => ({ path: e.path, reason: e.reason })),
  },
  dataDirs,
}

const ok =
  (!isoVerify || (isoVerify.verdict.dshOrbDigestUnchanged && isoVerify.verdict.dshOrbFileCountUnchanged && isoVerify.verdict.helperDataAddedByUs.length === 0 && isoVerify.verdict.keyFilesMatchStage0)) &&
  taskLines.length === 0 &&
  procLines.length === 0 &&
  Number.isFinite(helperCount) &&
  helperCount > 0 &&
  outside.length === 0 &&
  forbidden.length === 0 &&
  broken.length === 0

const txt = [
  `阶段 2 验收 ⑧ 隔离复核（观察窗 ${isoVerify ? (isoVerify.verdict.windowMs / 1000).toFixed(1) + ' s' : 'n/a'}）`,
  `基线：data/shots/${TAG}-iso-baseline.json   对比：data/shots/${TAG}-iso-verify.json`,
  '',
  `[1] orb 部署（${process.env.USERPROFILE}\\.dsh\\profiles\\desktop\\node_modules\\dsh-orb）`,
  isoVerify
    ? `    digest ${isoVerify.verdict.dshOrbDigestUnchanged ? 'UNCHANGED' : 'CHANGED!'}；文件数 ${isoVerify.verdict.dshOrbFileCountUnchanged ? '不变' : '变化!'}（${isoVerify.dshOrb.files}）；6 个关键文件与阶段 0 记录：${isoVerify.verdict.keyFilesMatchStage0 ? '一致' : '不一致!'}`
    : '    （缺 verify 产物）',
  '',
  '[2] helper-data 无我方新增',
  isoVerify ? `    digest ${isoVerify.verdict.helperDataDigestUnchanged ? 'UNCHANGED' : 'CHANGED'}；新增 ${isoVerify.verdict.helperDataAdded.length} 个（其中我方 ${isoVerify.verdict.helperDataAddedByUs.length} 个）；移除 ${isoVerify.verdict.helperDataRemoved.length} 个` : '    （缺 verify 产物）',
  `    本方新增明细：${isoVerify ? JSON.stringify(isoVerify.verdict.helperDataAddedByUs) : 'n/a'}`,
  '',
  '[3] 计划任务',
  `    查询是否成功：${tasksOk}   命中 research-orb 相关任务：${taskLines.length} 个`,
  taskLines.length ? taskLines.map((l) => '    ' + l).join('\n') : '    （无）',
  '',
  '[4] 退出后我方进程残留',
  `    查询是否成功：${procsOk}   残留 electron 实例：${procLines.length} 个（口径：electron.exe 且命令行为本项目）`,
  procLines.length ? procLines.slice(0, 5).map((l) => '    ' + l).join('\n') : '    （无）',
  `    orb 自己的 helper 进程：${Number.isFinite(helperCount) ? helperCount : '?'} 个（应 >0，证明我们没杀过它）`,
  '',
  '[5] writes.jsonl 写审计',
  `    总行数：${writeLines.length}`,
  `    越界（不在唯一可写根内）：${outside.length}`,
  `    命中硬红线禁写区：${forbidden.length}`,
  `    不可解析行：${broken.length}`,
  `    冻结区写入（vendor/.snapshots，带 protected 标记）：${protectedWrites.length}`,
  outside.length ? outside.slice(0, 5).map((e) => '    ' + e.path).join('\n') : '',
  '',
  '[6] data 目录占用（全部在唯一可写根内）',
  ...Object.entries(dataDirs).map(([n, s]) => `    ${n}/  ${s.files} 个文件  ${(s.bytes / 1024).toFixed(1)} KB`),
  '',
  ok ? '结论：隔离复核通过（5 项全 0 / 全一致）' : '结论：隔离复核未通过，见上文非零项',
].join('\n')

safeWrite(join(LOGS, 'stage2-08-isolation.txt'), txt)
safeWrite(join(LOGS, 'stage2-08-isolation.json'), JSON.stringify(verdict, null, 2))
process.stdout.write(txt + '\n')
process.stdout.write(`\n-> data/logs/stage2-08-isolation.txt / .json\n`)
process.exit(ok ? 0 : 1)
