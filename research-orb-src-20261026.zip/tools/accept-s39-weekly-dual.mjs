// tools/accept-s39-weekly-dual.mjs —— S39·F3 周报双维趋势图验收（≥6 项）。
// 单行复跑：node tools\accept-s39-weekly-dual.mjs
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync, readdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

process.env.ORB_LOG_DIR = join(tmpdir(), 's39-wk-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's39-wk-data-' + Date.now())
const { dataPath, PROJECT_ROOT } = await import('../packages/core/src/safefs.mjs')
const { buildWeeklyDualTrendArtifact, collectDailyDualScores } = await import('../packages/plugins/chart-skill/lib/weekly.mjs')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

try {
  // 造 7 天真实形状的日报（含双维投入三行）
  const dailyDir = dataPath('coach', 'daily')
  mkdirSync(dailyDir, { recursive: true })
  const days = []
  for (let i = 6; i >= 0; i--) {
    const d = new Date(Date.now() - i * 86400000)
    const ds = d.toISOString().slice(0, 10).replace(/-/g, '')
    const work = 2 + (i % 3)
    const life = i % 2
    writeFileSync(join(dailyDir, `daily-${ds}.md`), [
      `# 教练日报 ${ds}`, '',
      `- 评分：70 / 100`, '',
      '## 双维投入（work/life 加权）', '',
      `- workScore：${work} 条（工作/科研线）`,
      `- lifeScore：${life} 条（生活/娱乐线）`,
      `- total：50 / 100（权重 0.7 / 0.3，待用户确认）`, '',
    ].join('\n'), 'utf8')
    days.push({ date: d.toISOString().slice(0, 10), work, life })
  }

  // W-1 日报解析（真实查询 daily-*.md）
  const got = collectDailyDualScores(dailyDir)
  check('W-1 日报双维解析（7 天）', got.length === 7 && got.every((d) => Number.isFinite(d.work) && Number.isFinite(d.life)),
    `days=${got.length}`, {})

  // W-2 双维曲线渲染（work+life+avg 三序列）
  const agg = { weekKey: days[0].date.slice(0, 7), start: days[0].date, end: days[6].date, days }
  const outDir = dataPath('artifacts', 'weekly-dual')
  const r = await buildWeeklyDualTrendArtifact({ agg, outDir })
  check('W-2 双维曲线渲染 PNG', existsSync(r.pngPath) && r.size.width >= 1600 && r.size.height >= 1000,
    `${r.size.width}x${r.size.height}`, {})

  // W-3 图内来源标注（sidecar sources + payload annotation 同源）
  const sidecar = r.sidecar
  check('W-3 图内来源标注', sidecar.source.includes('data/coach/daily/*.md') && sidecar.source.includes('双维投入三行') && sidecar.days.length === 7,
    `source=${sidecar.source.slice(0, 50)}`, {})

  // W-4 sidecar 记录双维数值 + 平均线
  check('W-4 sidecar 双维数值+平均', Array.isArray(sidecar.workValues) && Array.isArray(sidecar.lifeValues) && Number.isFinite(sidecar.avg),
    `avg=${sidecar.avg}`, {})

  // W-5 md 产物（来源可回指）
  const mdPath = r.pngPath.replace(/\.png$/, '.md')
  writeFileSync(mdPath, [`# 周报双维趋势（${agg.start}~${agg.end}）`, '', `- PNG：${r.pngPath}`, `- 来源：${sidecar.source}`, '- 平均线为虚线；缺维不连点', ''].join('\n'), 'utf8')
  check('W-5 md 产物+复跑说明', existsSync(mdPath), `md=${mdPath.split(/[\\/]/).pop()}`, {})

  // W-6 缺全部评分 → 拒绝编数据（E_NO_WEEKLY_SCORE）
  let errCode = ''
  try {
    await buildWeeklyDualTrendArtifact({ agg: { weekKey: 'x', start: 'd1', end: 'd7', days: days.map((d) => ({ date: d.date, work: null, life: null })) }, outDir })
  } catch (e) { errCode = e.code || '' }
  check('W-6 缺数据拒绝编造', errCode === 'E_NO_WEEKLY_SCORE', `code=${errCode}`, {})

  // W-7 PNG IHDR 合法（尺寸解析不引依赖）
  const pngBuf = readFileSync(r.pngPath)
  check('W-7 PNG IHDR 合法', pngBuf.toString('ascii', 12, 16) === 'IHDR', `magic=${pngBuf.toString('ascii', 12, 16)}`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's39-weekly-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s39-weekly-dual: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
