// tools/accept-s25b-health.mjs —— S25·2D 健康账验收。
// 单行复跑：node tools\accept-s25b-health.mjs
// 证据：data\logs\s25b-health-accept.json
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { classifyWindow, createHealthLedger, HEALTH_DEFAULTS } from '../packages/plugins/coach/health.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 240), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's25b-health')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(WORK, { recursive: true })

let t = 1000000
const now = () => t

try {
  // ① 分类规则：娱乐 / 工作 / unknown（不确定不猜）
  check('H1 娱乐类：youtube/bilibili/steam/mpv/抖音 命中 entertainment', ['YouTube - 视频', 'bilibili.html', 'Steam 大厅', 'mpv 播放器', '抖音网页版'].every((x) => classifyWindow('app.exe', x) === 'entertainment' || classifyWindow(x + '.exe', '') === 'entertainment'))
  check('H2 工作类：Code/IDEA/Typora/WPS/Python/PDF 命中 work', classifyWindow('Code.exe', '') === 'work' && classifyWindow('idea64.exe', '') === 'work' && classifyWindow('Typora.exe', '论文') === 'work' && classifyWindow('python.exe', '') === 'work' && classifyWindow('SumatraPDF.exe', 'paper.pdf') === 'work')
  const unk1 = classifyWindow('WeChat.exe', '和朋友聊天')
  const unk2 = classifyWindow('', '')
  check('H3 不确定 → unknown（不猜）', unk1 === 'unknown' && unk2 === 'unknown')

  // ② 未超阈零打扰
  const reminders = []
  const led = createHealthLedger({ dir: WORK, now, capMin: 90, remind: async (info) => reminders.push(info) })
  for (let i = 0; i < 5; i++) { t += 60000; await led.feed({ process: 'mpv.exe', title: '电影', dwellMin: 10 }) } // 累计 50 分钟
  check('H4 未超阈（50<90 分钟）→ 零提醒', reminders.length === 0 && led.state().consecutiveMin === 50)

  // ③ 超阈触发 + 24h 冷却
  t += 60000 * 40 // 累计 90 分钟
  const r1 = await led.feed({ process: 'mpv.exe', title: '电影', dwellMin: 40 })
  check('H5 连续娱乐达 90 分钟 → 触发提醒（reminded=true）', r1.reminded === true && reminders.length === 1 && reminders[0].consecutiveMin >= 90)
  t += 3600 * 1000 // 1 小时后（冷却内）
  const r2 = await led.feed({ process: 'mpv.exe', title: '电影', dwellMin: 60 })
  check('H6 同一超阈事件 24h 冷却内不重复提醒', r2.reminded === false && reminders.length === 1 && led.state().reminders === 1)
  t += 25 * 3600 * 1000 // 越过 24h
  const r3 = await led.feed({ process: 'mpv.exe', title: '电影', dwellMin: 30 })
  check('H7 冷却过后可再次提醒', r3.reminded === true && reminders.length === 2)

  // ④ 恢复记录：切回工作 → 清零 + recovery
  const r4 = await led.feed({ process: 'Code.exe', title: 'engine.mjs', dwellMin: 5 })
  check('H8 切回工作 → 连续娱乐清零并记 recovery', r4.recovered === true && r4.consecutiveMin === 0 && led.state().recoveries === 1)

  // ⑤ health.jsonl 行齐
  const rows = readFileSync(led._healthFile, 'utf8').trim().split('\n').map((l) => JSON.parse(l))
  check('H9 health.jsonl 记录 window/reminder/recovery 三类且字段齐', rows.some((r) => r.kind === 'window' && r.category) && rows.some((r) => r.kind === 'reminder' && r.consecutiveMin >= 90) && rows.some((r) => r.kind === 'recovery'))

  // ⑥ unknown 不计入娱乐（不猜）
  const led2 = createHealthLedger({ dir: join(WORK, 'b'), now, capMin: 90 })
  for (let i = 0; i < 20; i++) await led2.feed({ process: 'WeChat.exe', title: '聊天', dwellMin: 30 }) // 600 分钟 unknown
  check('H10 unknown 长时间不计入娱乐（不触发提醒）', led2.state().consecutiveMin === 0 && led2.state().reminders === 0)

  // ⑦ cap 可配（默认 90）
  check('H11 默认 cap=90min/冷却 24h（可配）', HEALTH_DEFAULTS.entertainmentCapMin === 90 && HEALTH_DEFAULTS.reminderCooldownMs === 24 * 3600 * 1000)
  const led3 = createHealthLedger({ dir: join(WORK, 'c'), now, capMin: 10, remind: async (i) => reminders.push(i) })
  const r5 = await led3.feed({ process: 'steam.exe', title: '', dwellMin: 10 })
  check('H12 cap 可配（10 分钟档即刻触发）', r5.reminded === true)
} catch (e) {
  check('H0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 240))
} finally {
  rmSync(WORK, { recursive: true, force: true })
}

const pass = items.filter((i) => i.ok).length
const fail = items.length - pass
const out = { tool: 'accept-s25b-health', at: new Date().toISOString(), total: items.length, pass, fail, items }
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's25b-health-accept.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # accept-s25b-health: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 证据 -> data/logs/s25b-health-accept.json`)
process.exit(fail === 0 ? 0 : 1)
