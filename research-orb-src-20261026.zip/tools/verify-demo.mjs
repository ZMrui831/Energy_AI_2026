// tools/verify-demo.mjs —— 录屏用「现场证伪」脚本（证据闸四连；全部真实调用/SQL）
// 用法：node tools/verify-demo.mjs [--pause]
import { mkdirSync, rmSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createStore } from '../packages/core/src/db.mjs'
import {
  createClaim, attachEvidence, publishClaim, resolveEvidence, countPublishableEvidence, DEGRADED_EVIDENCE_COPY
} from '../packages/core/src/lifecycle/publish.mjs'

const pause = process.argv.includes('--pause')
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const W = 74
const line = (ch = '=') => ch.repeat(W)
function box(title, rows, verdict) {
  const tag = verdict === 'pass' ? '通过' : verdict === 'reject' ? '拒绝' : '信息'
  console.log('\n' + line())
  console.log(' [' + tag + ']  ' + title)
  console.log(line('-'))
  for (const r of rows) console.log('  ' + r)
  console.log(line())
}
async function step(title, rows, verdict) { box(title, rows, verdict); if (pause) await sleep(1000) }

const WORK = join(PROJECT_ROOT, 'data', 'tmp', 'record-verify')
if (existsSync(WORK)) rmSync(WORK, { recursive: true, force: true })
mkdirSync(WORK, { recursive: true })
const dir = WORK
const store = await createStore({ driver: 'sqlite', dbPath: join(dir, 'orb.sqlite'), dataDir: dir })
store.initMigrations()
await step('准备：一次干净的证据库（不碰生产库）', ['库: data/tmp/record-verify/orb.sqlite', '表: claim / claim_evidence / summary_evidence / 4 个触发器'], 'info')

// ① 无证据 → 裸 SQL 直接发布（绕过所有应用层）
let d1 = '未触发拒绝'
try { store._db.exec("INSERT INTO claim(id, kind, text, evidence_mode, status, created_at) VALUES ('clm-1','observation','构网型逆变器可提供惯量支撑','direct','draft','" + new Date().toISOString() + "')") } catch (e) { d1 = 'insert: ' + (e.code || e.message) }
let msg1 = '居然成功了'
try { store._db.exec("UPDATE claim SET status='published' WHERE id='clm-1'") } catch (e) { msg1 = String((e && e.message) || e) }
const st1 = store._db.prepare("SELECT status FROM claim WHERE id='clm-1'").get().status
await step('① 无证据的结论 → 用裸 SQL 强行发布', ['动作: UPDATE claim SET status=published（不经过任何应用代码）', '数据库返回: ' + msg1.slice(0, 90), '当前状态: ' + st1], msg1.includes('CLAIM_EVIDENCE_REQUIRED') && st1 === 'draft' ? 'reject' : 'pass')

// ② none（只有假设）→ 走发布 API
createClaim(store, { id: 'clm-2', kind: 'observation', text: '它可能是瓶颈（仅为假设）', evidenceMode: 'none' })
const r2 = publishClaim(store, 'clm-2')
await step('② 只有假设（none）的结论 → 走发布 API', ['动作: publishClaim(clm-2)', '返回: ' + JSON.stringify(r2).slice(0, 100), '结论: 无直接证据不得作为结论发布'], r2 && r2.ok === false ? 'reject' : 'pass')

// ③ 补一条直接证据 → 再发布
store.insertRawFrame({ id: 'rf-demo', file_path: join(dir, 'demo.png'), sha256: 'a'.repeat(64), sensitivity: 'normal', created_at: new Date().toISOString(), expires_at: new Date(Date.now() + 3600000).toISOString(), status: 'ready', size_bytes: 1, format: 'png', mode: 'lowres', monitor_id: 'M1', consent_id: 'demo', trace_id: 'tr-demo' })
createClaim(store, { id: 'clm-3', kind: 'observation', text: '该机组惯量支撑有限（有直接证据）', evidenceMode: 'direct' })
attachEvidence(store, { claimId: 'clm-3', evidenceId: 'rf-demo', layer: 'raw_frame', relation: 'direct', sha256: 'a'.repeat(64) })
const cnt = countPublishableEvidence(store, 'clm-3')
const r3 = publishClaim(store, 'clm-3')
await step('③ 挂上一条直接证据 → 再发布', ['动作: attachEvidence(rf-demo, direct) → publishClaim(clm-3)', '可发布证据数: ' + cnt, '返回: ' + JSON.stringify(r3).slice(0, 100)], r3 && r3.ok ? 'pass' : 'reject')

// ④ 原图被清理后 → 结论仍可解释
store._db.exec("UPDATE raw_frame SET status='deleted' WHERE id='rf-demo'")
const ev = resolveEvidence(store, 'rf-demo', 'raw_frame')
await step('④ 原图被清理后 → 结论还能回指吗', ['动作: raw_frame.status=deleted → resolveEvidence(rf-demo)', '返回: ' + JSON.stringify(ev).slice(0, 120), '固定文案: ' + DEGRADED_EVIDENCE_COPY.slice(0, 40) + '…'], ev && (ev.status === 'deleted' || ev.degraded) ? 'pass' : 'reject')

console.log('\n' + line('#') + '\n  四步全部为真实判定；可在现场用同一条命令重跑\n' + line('#'))
try { store.close && store.close() } catch { /* ignore */ }
process.exit(0)