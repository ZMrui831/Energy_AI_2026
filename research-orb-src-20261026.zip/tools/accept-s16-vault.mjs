// tools/accept-s16-vault.mjs —— 任务1 笔记库（Obsidian 目录）端到端冒烟：真实 DB + 真实文件。
// 单行复跑：node tools\accept-s16-vault.mjs
import './_accept-isolate.mjs' // S67·3-A：先于产品模块求值，把 data/logs 指到临时目录
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { createHash } from 'node:crypto'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createStore } from '../packages/core/src/db.mjs'
import { createClaim, attachEvidence, publishClaim } from '../packages/core/src/lifecycle/publish.mjs'
import { writeClaimToVault, readVaultNote, listVaultNotes, resolveVaultRoot, activate } from '../packages/plugins/vault-notes/index.mjs'

const items = []
const check = (id, ok, detail, evidence = {}) => { items.push({ id, ok: !!ok, detail, evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's16-vault')
if (existsSync(WORK)) rmSync(WORK, { recursive: true, force: true })
mkdirSync(WORK, { recursive: true })
const vaultRoot = 'data/tmp/s16-vault/myvault'

const store = await createStore({ driver: 'sqlite', dbPath: join(WORK, 'orb.sqlite'), dataDir: WORK })
store.initMigrations()

// 造一条真实已发布结论（走真实 API，不用 mock）
store.insertRawFrame({ id: 'rf-s16', file_path: join(WORK, 'shot.png'), sha256: 'a'.repeat(64), sensitivity: 'normal', created_at: new Date().toISOString(), expires_at: new Date(Date.now() + 3600000).toISOString(), status: 'ready', size_bytes: 1, format: 'png', mode: 'lowres', monitor_id: 'M1', consent_id: 'demo', trace_id: 'tr-s16' })
createClaim(store, { id: 'clm-s16-pub', kind: 'observation', text: '双源校验显示该 DOI 真实存在，且引文逐字命中。', evidenceMode: 'direct' })
attachEvidence(store, { claimId: 'clm-s16-pub', evidenceId: 'rf-s16', layer: 'raw_frame', relation: 'direct', sha256: 'a'.repeat(64) })
const pub = publishClaim(store, 'clm-s16-pub')
check('V1 前置：结论已发布', pub && pub.ok, 'publishClaim ok=' + (pub && pub.ok))

// ① 写库
const w = writeClaimToVault({ store, claimId: 'clm-s16-pub', vaultRoot })
check('V2 写入笔记文件', existsSync(w.path), w.path.replace(PROJECT_ROOT, ''), { bytes: w.bytes })
const raw = readFileSync(w.path, 'utf8')
check('V3 front-matter 含 evidence_id 与 status', /evidence_ids:\s*\[rf-s16\]/.test(raw) && /status:\s*published/.test(raw), '含 evidence_ids=[rf-s16] / status=published')
check('V4 正文含结论原文', raw.includes('双源校验显示该 DOI 真实存在'), '正文命中')

// ② 读回（供问答引用）
const rd = readVaultNote({ claimId: 'clm-s16-pub', vaultRoot })
check('V5 读回并可解析 front-matter', rd.frontMatter.claim_id === 'clm-s16-pub' && rd.frontMatter.evidence_ids.includes('rf-s16'), 'claim_id=' + rd.frontMatter.claim_id)
check('V6 引用内容非空', String(rd.text).length > 10, 'text 长度=' + String(rd.text).length)

// ③ 负向：草稿不得外发
createClaim(store, { id: 'clm-s16-draft', kind: 'observation', text: '未核验的猜测', evidenceMode: 'none' })
let denied = null
try { writeClaimToVault({ store, claimId: 'clm-s16-draft', vaultRoot }) } catch (e) { denied = e }
check('V7 草稿被拒（E_NOT_PUBLISHED）', !!(denied && denied.code === 'E_NOT_PUBLISHED'), 'code=' + (denied && denied.code))
check('V8 草稿未产生文件', !existsSync(join(resolveVaultRoot({ vaultRoot }), '研究结论', 'clm-s16-draft.md')), '文件不存在')

// ④ 命令层（真实 activate + 真实 run）
const cmds = []
await activate({ log: { warn() {}, info() {}, error() {} }, core: { lifecycle: store }, ui: { registerCard() {}, registerCommand: (c) => cmds.push(c) } })
check('V9 注册了 vault 命令', cmds.some((c) => c.name === 'vault'), 'commands=' + cmds.map((c) => c.name).join(','))
const run = cmds.find((c) => c.name === 'vault').run
const r1 = await run('write clm-s16-pub')
check('V10 /vault write 成功', r1.ok === true, String(r1.text).slice(0, 80))
const r2 = await run('read clm-s16-pub')
check('V11 /vault read 成功', r2.ok === true && String(r2.text).length > 10, '长度=' + String(r2.text).length)
const r3 = await run('list')
check('V12 /vault list 含笔记', r3.ok === true && r3.text.includes('clm-s16-pub'), String(r3.text).split('\n').length + ' 条')

// ⑤ 证据落盘
const pass = items.filter((i) => i.ok).length
const out = { at: new Date().toISOString(), vaultRoot, total: items.length, pass, fail: items.length - pass, items }
writeFileSync(join(PROJECT_ROOT, 'data', 'logs', 's16-vault-accept.json'), JSON.stringify(out, null, 2), 'utf8')
console.log('\n  # accept-s16-vault: total=' + items.length + ' pass=' + pass + ' fail=' + (items.length - pass))
try { store.close && store.close() } catch { /* ignore */ }
process.exit(pass === items.length ? 0 : 1)