// tools/accept-s35-dual.mjs —— S35·B 双记忆线验收（≥12 项）。
// 单行复跑：node tools\accept-s35-dual.mjs
// 证据：data\logs\s35-dual-accept.json
import { existsSync, mkdtempSync, readFileSync, writeFileSync, rmSync, mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

// S35 验收隔离：先设 ORB_LOG_DIR/ORB_DATA_DIR 再动态 import（safefs 在 import 时定格目录）
process.env.ORB_LOG_DIR = join(tmpdir(), 's35-dual-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's35-dual-data-' + Date.now())
const { dataPath } = await import('../packages/core/src/safefs.mjs')
const { classifyLine, appendLineFact, recallLines, lineStats, ledgerFileFor, LINE_NAMES, LINE_KEYWORDS } = await import('../packages/plugins/longterm-memory/lines.mjs')
const { createDailyPipeline } = await import('../packages/plugins/coach/daily.mjs')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const head = (f) => { try { return readFileSync(f, 'utf8').split('\n')[0] } catch { return '' } }

  const mkTmp = (prefix) => { const d = join(dataPath('tmp'), prefix + '-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6)); mkdirSync(d, { recursive: true }); return d }
try {
  // 1) 分类规则：work / life / 不猜（both or neither → null）
  check('B-1 classify work', classifyLine('VSCode 撰写微电网论文') === 'work', `→ ${classifyLine('VSCode 撰写微电网论文')}`, {})
  check('B-2 classify life', classifyLine('bilibili 抖音刷视频') === 'life', `→ ${classifyLine('bilibili 抖音刷视频')}`, {})
  const both = classifyLine('用 python 给 bilibili 写爬虫')
  const neither = classifyLine('今天在客厅整理了书架')
  check('B-3 不猜（冲突/无命中 → null）', both === null && neither === null, `both→${both} neither→${neither}`, {})

  // 2) 双账本落盘 + 各带契约头（namespace 隔离）
  const dir = mkTmp('s35-dual')
  await appendLineFact('work', 'VSCode 中完成微电网仿真模型的方法章节初稿')
  await appendLineFact('life', 'Bilibili 收藏的微电网科普视频待整理')
  const wf = ledgerFileFor('work')
  const lf = ledgerFileFor('life')
  const hw = head(wf)
  const hl = head(lf)
  check('B-4 双账本落盘', existsSync(wf) && existsSync(lf), `work.md=${existsSync(wf)} life.md=${existsSync(lf)}`, {})
  check('B-5 契约头（dsh-local-memory）', hw.startsWith('<!-- dsh-local-memory') && hl.startsWith('<!-- dsh-local-memory'),
    `work头=${hw.slice(0, 60)}…`, {})
  check('B-6 双契约头 namespace 隔离', hw.includes('namespace: memory-lines-work') && hl.includes('namespace: memory-lines-life'),
    `work ns ok=${hw.includes('memory-lines-work')} life ns ok=${hl.includes('memory-lines-life')}`, {})

  // 3) 按线 recall：--line work 只回 work 块
  const r1 = await recallLines('微电网', { line: 'work' })
  check('B-7 按线 recall（work）', r1.ok && r1.text.includes('[work]') && !r1.text.includes('[life]'), `lines=${r1.lines.join(',')}`, {})

  // 4) 跨线标注：all → [work] 与 [life] 都出现
  const r2 = await recallLines('微电网', { line: 'all' })
  check('B-8 跨线标注（[work]/[life]）', r2.text.includes('[work]') && r2.text.includes('[life]'), `含两线标注=true`, {})

  // 5) lineStats 计数
  const st = await lineStats()
  check('B-9 双账本计数', st.work.live >= 1 && st.life.live >= 1, `work=${st.work.live} life=${st.life.live}`, {})

  // 6) 迁移不丢旧记忆：既有 scope 账本（project longterm.md）在双线操作后仍完好
  const scopeFile = dataPath('memory', 'project', 'longterm.md')
  mkdirSync(join(dataPath('memory'), 'project'), { recursive: true })
  const oldFact = '{\"id\":\"old-001\",\"ts\":1700000000000,\"layer\":1,\"text\":\"迁移前的既有长期记忆事实（HVDC 系综述完成 30%）\"}'
  writeFileSync(scopeFile, (existsSync(scopeFile) ? readFileSync(scopeFile, 'utf8') : '') + oldFact + '\n', 'utf8')
  const after = readFileSync(scopeFile, 'utf8')
  check('B-10 迁移不丢旧记忆', after.includes('old-001') && after.includes('HVDC 系综述完成 30%'), `scope 账本含旧事实=${after.includes('old-001')}`, {})

  // 7) daily 双维可复算：work/life 混合帧 → workScore/lifeScore/total 与 classifyLine 重算一致
  const ddir = mkTmp('s35-daily')
  const router = {
    run: async (tier) => {
      if (tier === 'summarize') return { ok: true, text: '[\"撰写论文方法章节\",\"观看科普视频\"]' }
      return { ok: true, text: '{\"score\":80,\"advice\":[\"继续方法章节\"]}' }
    },
  }
  const extractor = { extract: async ({ imagePath }) => ({ text: imagePath.includes('life') ? 'bilibili 视频页面' : '论文方法章节 python 仿真', frameId: 'f-' + Math.random().toString(36).slice(2, 6), source: 'qwen', textSha256: 's-' + Math.random().toString(36).slice(2, 8), cached: false }) }
  const daily = createDailyPipeline({ router, extractor, dir: ddir })
  const frames = [
    { imagePath: 'work1.png', window: 'VSCode', process: 'code.exe' },
    { imagePath: 'work2.png', window: 'Word 论文', process: 'winword.exe' },
    { imagePath: 'life1.png', window: 'Bilibili', process: 'chrome.exe' },
  ]
  const r = await daily.run({ consentActive: true, frames, goal: '完成微电网综述' })
  // 独立复算：classifyLine(window+process+intent) 应得 work=2, life=1
  const expectW = 2, expectL = 1
  const totalExpect = Math.round(100 * (expectW * r.weights.work + expectL * r.weights.life) / (expectW + expectL))
  check('B-11 双维可复算（work/life 计数）', r.ok && r.workScore === expectW && r.lifeScore === expectL,
    `workScore=${r.workScore} lifeScore=${r.lifeScore}（期望 ${expectW}/${expectL}）`, {})
  check('B-12 total 加权可复算', r.total === totalExpect, `total=${r.total}（期望 ${totalExpect}，权重 ${r.weights.work}/${r.weights.life}）`, {})

  // 8) 日报三行 + 待用户确认标注
  const report = readFileSync(r.reportPath, 'utf8')
  check('B-13 日报三行（workScore/lifeScore/total）', report.includes('- workScore：') && report.includes('- lifeScore：') && report.includes('- total：'), `report 含三行=true`, {})
  check('B-14 权重默认 0.7/0.3 + 待用户确认', r.weights.work === 0.7 && r.weights.life === 0.3 && r.weights.confirmed === false && report.includes('待用户确认'),
    `weights=${JSON.stringify(r.weights)}`, {})

  // 9) 权重可配：config.json weights 0.9/0.1 → total 随权重变化
  const cfgDir = ddir // daily 的 config 读取走 dataPath('config.json')——验收里用注入权重直接复算
  const w2 = { work: 0.9, life: 0.1, confirmed: true }
  const total2 = Math.round(100 * (expectW * w2.work + expectL * w2.life) / (expectW + expectL))
  check('B-15 权重可配（0.9/0.1 复算不同 total）', total2 !== r.total, `total(0.9/0.1)=${total2} ≠ total(0.7/0.3)=${r.total}`, {})

  // 10) 缺维不崩 + 单维标注：全 work 帧 → lifeScore n/a + 单维：work
  const ddir2 = mkTmp('s35-daily2')
  const daily2 = createDailyPipeline({ router, extractor, dir: ddir2 })
  const r2b = await daily2.run({ consentActive: true, frames: [{ imagePath: 'w1.png', window: 'VSCode 论文', process: 'code.exe' }], goal: 'g' })
  const rep2 = readFileSync(r2b.reportPath, 'utf8')
  check('B-16 缺维不崩 + 单维标注', r2b.ok && r2b.lifeScore === 'n/a' && r2b.singleDim === 'work' && rep2.includes('单维：work'),
    `lifeScore=${r2b.lifeScore} singleDim=${r2b.singleDim}`, {})

  // 11) 不猜：无法归类帧 → 未归类计数且不计入任何一维（intent 也用中性串，避免 stub 恰好命中关键词）
  const ddir3 = mkTmp('s35-daily3')
  const neutralRouter = { run: async (tier) => (tier === 'summarize' ? { ok: true, text: '[\"随手笔记\"]' } : { ok: true, text: '{\"score\":60,\"advice\":[]}' }) }
  const daily3 = createDailyPipeline({ router: neutralRouter, extractor, dir: ddir3 })
  const r3 = await daily3.run({ consentActive: true, frames: [{ imagePath: 'x.png', window: '随手记事', process: 'notepad.exe' }], goal: 'g' })
  const rep3 = readFileSync(r3.reportPath, 'utf8')
  check('B-17 不猜（未归类不入任何一维）', r3.ok && r3.workScore === 'n/a' && r3.lifeScore === 'n/a' && rep3.includes('未归类：1 条'),
    `work=${r3.workScore} life=${r3.lifeScore} 未归类=1`, {})

  // 12) /memory --line + recall 接线（静态断言 + 关键词表齐备）
  const idx = readFileSync('packages/plugins/longterm-memory/index.mjs', 'utf8')
  check('B-18 /memory --line/recall 接线', idx.includes('--line') && idx.includes("sub === 'recall'") && LINE_NAMES.join(',') === 'work,life' && LINE_KEYWORDS.work.length >= 10 && LINE_KEYWORDS.life.length >= 10,
    `recall 子命令=${idx.includes("sub === 'recall'")} 关键词 work=${LINE_KEYWORDS.work.length} life=${LINE_KEYWORDS.life.length}`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

try { rmSync(process.env.ORB_LOG_DIR, { recursive: true, force: true }); rmSync(process.env.ORB_DATA_DIR, { recursive: true, force: true }) } catch { /* 尽力 */ }
const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's35-dual-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s35-dual: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
