# voice_asr.py -- S37·C 语音最小闭环：faster_whisper 一次性转写（零常驻进程）。
#
# Input : argv[1] = wav 路径；argv[2] = 模型（默认 tiny，可 small/base）；argv[3] = device（auto|cpu|cuda）
# Output: stdout 一行 JSON {"ok":true,"text":"…","audioSec":12.3,"model":"tiny","device":"cpu"}
# 纪律：一次性进程（跑完即退，零残留）；异常打 JSON {"ok":false,"reason":"…"} 并 exit 1。

import json
import sys

# S67·4-D：强制 UTF-8 输出（防 Windows cp936 码页把中文写坏）；Node 侧也强制 PYTHONIOENCODING/-X utf8。
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="strict")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass


def emit(obj, code=0):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.exit(code)


def main():
    if len(sys.argv) < 2:
        emit({"ok": False, "reason": "缺少 wav 路径参数"}, 1)
    wav = sys.argv[1]
    model_size = sys.argv[2] if len(sys.argv) > 2 else "tiny"
    device = sys.argv[3] if len(sys.argv) > 3 else "auto"
    # S74·3-B：唤醒词实测 tiny 命中率仅 5%，按 dsh-orb 建议支持 beam 调优（默认 1 保持既有基线）
    beam = int(sys.argv[4]) if len(sys.argv) > 4 else 1
    try:
        from faster_whisper import WhisperModel
    except Exception as e:
        emit({"ok": False, "reason": "faster_whisper 不可用：" + str(e)[:120], "code": "E_VOICE_UNAVAILABLE"}, 1)
    try:
        import time
        t0 = time.time()
        model = WhisperModel(model_size, device=device, compute_type="auto")
        segments, info = model.transcribe(wav, language="zh", beam_size=beam)
        text = "".join(seg.text for seg in segments).strip()
        load_ms = int((time.time() - t0) * 1000)
        emit({
            "ok": True,
            "text": text,
            "audioSec": float(getattr(info, "duration", 0.0)),
            "model": model_size,
            "device": str(getattr(model, "device", device)),
            "loadMs": load_ms,
        })
    except Exception as e:
        emit({"ok": False, "reason": "转写失败：" + str(e)[:160]}, 1)


if __name__ == "__main__":
    main()
