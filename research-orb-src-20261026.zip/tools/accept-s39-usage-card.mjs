// tools/accept-s39-usage-card.mjs —— S39·F7 /usage 面板卡验收（≥4 项）。
// 单行复跑：node tools\accept-s39-usage-card.mjs
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

process.env.ORB_LOG_DIR = join(tmpdir(), 's39-us-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's39-us-data-' + Date.now())
const { dataPath } = await import('../packages/core/src/safefs.mjs')
const { buildUsageCard } = await import('../packages/plugins/coach/usage-card.mjs')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

try {
  // U-1 空数据显示"暂无调用"
  const empty = buildUsageCard({ usagePath: join(tmpdir(), 'no-such-usage-' + Date.now() + '.jsonl') })
  check('U-1 无数据显示暂无调用', empty.empty === true && empty.text.includes('暂无调用'), `text=${empty.text}`, {})

  // U-2 真实行统计：calls/ok/failed/fallback 与行一致
  const usagePath = join(dataPath('logs'), 'usage.jsonl')
  mkdirSync(dataPath('logs'), { recursive: true })
  const today = new Date().toISOString().slice(0, 10)
  const rows = [
    { ts: today + 'T01:00:00Z', taskClass: 'summarize', tier: 'flagship', providerId: 'deepseek-api', model: 'deepseek-chat', fallback: false, ok: true, ms: 900, tokens: 120 },
    { ts: today + 'T02:00:00Z', taskClass: 'score-plan', tier: 'flagship', providerId: 'deepseek-api', model: 'deepseek-chat', fallback: false, ok: true, ms: 1100, tokens: 80 },
    { ts: today + 'T03:00:00Z', taskClass: 'summarize', tier: 'flagship', providerId: 'deepseek-api', model: '', fallback: true, ok: false, ms: 30, error: { code: 'E_NO_AUTH', message: 'x' } },
  ]
  writeFileSync(usagePath, rows.map((r) => JSON.stringify(r)).join('\n') + '\n', 'utf8')
  const card = buildUsageCard({ usagePath })
  check('U-2 统计与行一致', card.calls === 3 && card.okCalls === 2 && card.failed === 1 && card.fallback === 1,
    `calls=${card.calls} ok=${card.okCalls} failed=${card.failed} fb=${card.fallback}`, {})

  // U-3 tokens 汇总 + 费用区间（200 tokens × 0.001~0.002/1k = ¥0.0002~0.0004，口径如面板）
  check('U-3 tokens+费用区间', card.tokens === 200 && card.costRange[0] === 0.0002 && card.costRange[1] === 0.0004,
    `tokens=${card.tokens} range=${card.costRange.join('~')}`, {})

  // U-4 面板文本字段齐（含"估算口径"防谎称账单）
  check('U-4 面板文本字段齐+口径', card.text.includes('/usage') && card.text.includes('tokens：200') && card.text.includes('估算口径'),
    `text 行数=${card.text.split('\n').length}`, {})

  // U-5 只认今天（昨天的行不计入）
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10)
  const rowsY = [...rows, { ts: yesterday + 'T09:00:00Z', taskClass: 'summarize', providerId: 'x', model: 'y', ok: true, tokens: 9999 }]
  writeFileSync(usagePath, rowsY.map((r) => JSON.stringify(r)).join('\n') + '\n', 'utf8')
  const card2 = buildUsageCard({ usagePath })
  check('U-5 只统计今天', card2.calls === 3 && card2.tokens === 200,
    `calls=${card2.calls} tokens=${card2.tokens}`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's39-usage-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s39-usage-card: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
