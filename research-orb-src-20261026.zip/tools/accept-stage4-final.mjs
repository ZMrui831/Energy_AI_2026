// tools/accept-stage4-final.mjs —— P-R4 总验收（#43）：全链路回归 + 文档终审 + 交付汇报
//
// 产出：
//   data/logs/stage4-final-1x-*.txt  ①②③④⑤ 逐项证据（引用红线/笔记/skill/计时/底座）
//   data/logs/stage4-final-summary.json  每项 ok + 证据文件名 + 冷跑命令
// 冷跑复现：node tools/accept-stage4-final.mjs（docx 验证 b 需先 node tools/setup-venv.mjs）
//
// 纪律：只做收口验收不新增功能；item6/9 引用 accept-smoke-electron / accept-isolation 已产证据；
//       item3 真装后立即 retire 并清理（.retired 只留 canonical accept-b4-skill 证据）。

import { spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync, statSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { PROJECT_ROOT, safeWrite } from '../packages/core/src/safefs.mjs'
import { createRegistry } from '../packages/plugins/index.mjs'
import { createNet, assertAllowedBaseUrl } from '../packages/core/src/net.mjs'
import { createProviders } from '../packages/core/src/providers/index.mjs'
import { renderVerifiedAnswer } from '../packages/plugins/research-literature/lib/cite-verify.mjs'
import { buildFileManifest, verifySource } from '../packages/core/src/skill-installer.mjs'
import { APP_VERSION } from '../packages/core/src/version.mjs'

const LOGS = join(PROJECT_ROOT, 'data', 'logs')
const SUMMARY = { at: new Date().toISOString(), version: APP_VERSION, items: [], allPass: false }
const record = (id, name, ok, evidence, coldCmd) => {
  SUMMARY.items.push({ id, name, ok, evidence, coldCmd })
  console.log(`${ok ? 'PASS' : 'FAIL'} ①②③④⑤⑥⑦⑧⑨${''}[${id}] ${name}${ok ? '' : ' —— 见 ' + evidence}`)
}

function writeStep(file, title, lines) {
  safeWrite(join(LOGS, file), [`=== ${title} ===`, ...lines].join('\n') + '\n')
}

// ---------------------------------------------------------------------------
// 引擎（真实 registry 路径）
// ---------------------------------------------------------------------------
const net = createNet({ logFile: join(LOGS, 'stage4-final-net.jsonl') })
const reg = createRegistry({ core: { net, providers: createProviders({ net }) } })
reg.scan()
await reg.enableAll({ safe: true })
const run = async (name, args) => {
  const r = await reg.runCommand(name, args)
  return (r && r.value) || { ok: false, text: '(no result)' }
}
const EDITOR = '总验收收口'

// ---------------------------------------------------------------------------
// ① 引用红线（真 net）
// ---------------------------------------------------------------------------
{
  const L = []
  const DOI_OK = '10.1109/lcsys.2020.3044551'
  const DOI_FAKE = '10.9999/fake.doi.12345'
  const PDF = join(PROJECT_ROOT, 'data', 'fixtures', 'sample-paper.pdf')
  const QHIT = 'Simulations on a modified IEEE 9-bus system show improved frequency nadir by 32 percent.'
  const QMISS = 'Simulations on a modified IEEE 9-bus system show improved frequency nadir by 90 percent.'

  const r1 = await run('verify', `doi ${DOI_OK}`)
  L.push('--- /verify doi（真实 DOI）---', r1.text)
  const c1 = r1.ok && /可作为结论依据|校验通过|accepted|verified|可引用/i.test(r1.text + JSON.stringify(r1.ui || {}))

  const r2 = await run('verify', `doi ${DOI_FAKE}`)
  L.push('', '--- /verify doi（伪造 DOI）---', r2.text)
  const c2 = !r2.ok && /拒|失败|无法/.test(r2.text)

  const r3 = await run('verify', `doi ${DOI_OK} --title 绝对错误的标题用来触发拒引`)
  L.push('', '--- /verify doi（真 DOI + 错标题）---', r3.text)
  const c3 = !r3.ok && /拒|失败|不匹配|标题/.test(r3.text)

  const r4 = await run('verify', `quote ${QHIT} --pdf ${PDF}`)
  L.push('', '--- /verify quote（命中）---', r4.text)
  const c4 = r4.ok
  const r5 = await run('verify', `quote ${QMISS} --pdf ${PDF}`)
  L.push('', '--- /verify quote（不命中）---', r5.text)
  const c5 = !r5.ok && /未在 PDF 全文/.test(r5.text)

  // fail-closed：忘记先 verifyAssertions 的裸断言
  const bare = [{ text: '某结论以一篇不存在的文献为依据', strength: 'proven' }]
  let out
  try { out = renderVerifiedAnswer({ assertions: bare }) } catch (e) { out = String(e && e.message) }
  const outStr = typeof out === 'string' ? out : JSON.stringify(out)
  L.push('', '--- fail-closed（裸断言直出）---', outStr.slice(0, 600))
  const c6 = !outStr.includes('undefined') && /待验证|未验证|未先经/.test(outStr) && !/^\s*结论[:：][^\n]*不存在/.test(outStr.replace(/\n/g, ' ').slice(0, 200))

  writeStep('stage4-final-10-cite.txt', '① 引用红线', L)
  record('1', '引用红线：真DOI含置信度/伪造拒/错标题拒/quote命中与不命中/fail-closed', c1 && c2 && c3 && c4 && c5 && c6, 'stage4-final-10-cite.txt', 'node tools/accept-stage4-final.mjs')
}

// ---------------------------------------------------------------------------
// ② 笔记链路（真 registry；结束时清理 final-b4 主题与导出）
// ---------------------------------------------------------------------------
{
  const L = []
  const TOPIC = 'final-b4'
  let ok = true
  const t4 = []
  for (const tpl of ['综述', '方法', '实验', '失败']) {
    const r = await run('note', `new ${TOPIC} n4-${tpl} --template ${tpl}`)
    t4.push(r.ok)
  }
  L.push('--- 四类模板各建一卡（front-matter 头）---')
  for (const tpl of ['综述', '方法', '实验', '失败']) {
    L.push(`[${tpl}]`, readFileSync(join(PROJECT_ROOT, 'data', 'notes', TOPIC, `n4-${tpl}.md`), 'utf8').split('\n').slice(0, 8).join('\n'), '')
  }
  ok = ok && t4.every(Boolean)

  // 链接：n4-综述 写 [[n4-方法]] + 悬空 [[ghost-4]]
  const relA = `${TOPIC}/n4-综述.md`
  const mdA = readFileSync(join(PROJECT_ROOT, 'data', 'notes', relA), 'utf8')
  writeFileSync(join(PROJECT_ROOT, 'data', 'notes', relA), mdA + '\n参见 [[n4-方法]] 与 [[ghost-4]]。\n')
  const rl = await run('note', `links n4-综述`)
  L.push('--- /note links n4-综述（双向 + 悬空）---', rl.text)
  ok = ok && rl.ok && /ghost-4/.test(rl.text) && /n4-方法/.test(rl.text)
  const rlB = await run('note', `links n4-方法`)
  ok = ok && rlB.ok && /n4-综述/.test(rlB.text)

  const rb = await run('note', `batch --topic ${TOPIC} --slug n4-综述,n4-方法,n4-实验 --tag 领域/构网型 --status reading`)
  L.push('', '--- /note batch（3 卡打标签+改状态）---', rb.text)
  ok = ok && rb.ok && /3\/3|成功 3/.test(rb.text)
  const audit = readFileSync(join(PROJECT_ROOT, 'data', 'logs', 'plugins.jsonl'), 'utf8').trim().split('\n')
  const batchLines = audit.filter((x) => /note\.batch/.test(x)).length
  L.push(`审计 plugins.jsonl 中 note.batch 行数（含历史）=${batchLines}`)
  ok = ok && batchLines >= 3

  // 标签+项目维度检索：无 query 走纯维度过滤（Orama 索引不收录刚建卡的短正文，
  // 用内容 query 检索 0 命中是预期行为，不是缺陷——故此处用维度过滤验证）。
  const rfP = await run('note', `find --project ${TOPIC}`)
  L.push('', '--- /note find 过滤（项目维度，无 query）---', rfP.text)
  ok = ok && rfP.ok && /命中 \d+ 条/.test(rfP.text) && new RegExp(`${TOPIC}/`).test(rfP.text)
  const rfT = await run('note', `find --tag 领域/构网型`)
  L.push('', '--- /note find 过滤（标签维度，无 query）---', rfT.text)
  ok = ok && rfT.ok && /命中 \d+ 条/.test(rfT.text) && /n4-/.test(rfT.text)

  const re1 = await run('note', `export ${TOPIC} --slug n4-综述`)
  const re2 = await run('note', `export ${TOPIC}`)
  const re3 = await run('bib', TOPIC)
  const re4 = await run('note', `export ${TOPIC} --slug n4-综述 --docx`)
  const re5 = await run('note', `export ${TOPIC} --slug n4-综述 --latex`)
  L.push('', '--- 导出 ---', re1.text, re2.text, re3.text, re4.text, re5.text)
  const date = new Date().toISOString().slice(0, 10)
  const expDir = join(PROJECT_ROOT, 'data', 'exports')
  const docxFile = readdirSync(expDir).find((f) => f.startsWith(`${TOPIC}-`) && f.endsWith('.docx'))
  const bibFile = readdirSync(expDir).find((f) => f.startsWith(`${TOPIC}-`) && f.endsWith('.bib'))
  ok = ok && re1.ok && re2.ok && re3.ok && re4.ok && re5.ok && !!docxFile && !!bibFile
  if (docxFile) {
    const JSZip = (await import('jszip')).default
    const zip = await JSZip.loadAsync(readFileSync(join(expDir, docxFile)))
    const xml = zip.file('word/document.xml') ? await zip.file('word/document.xml').async('string') : ''
    L.push(`docx 解包复核：word/document.xml ${xml.length} 字符，含标题=${xml.includes('综述') || xml.length > 500}`)
    ok = ok && xml.length > 500
  }

  // 清理：final-b4 主题 + 本次导出文件（我们的验收垃圾）
  rmSync(join(PROJECT_ROOT, 'data', 'notes', TOPIC), { recursive: true, force: true })
  for (const f of readdirSync(expDir)) if (f.startsWith(`${TOPIC}-`)) rmSync(join(expDir, f), { force: true })
  L.push('', `清理：data/notes/${TOPIC}/ 与 data/exports/${TOPIC}-* 已删（验收自清理）`)

  writeStep('stage4-final-11-notes.txt', '② 笔记链路', L)
  record('2', '笔记链路：链接双向+悬空/四模板/批量审计/过滤检索/导出 md+bib+docx', ok, 'stage4-final-11-notes.txt', 'node tools/accept-stage4-final.mjs')
}

// ---------------------------------------------------------------------------
// ③ skill 链路（真装→retire→清理；篡改/cancel 零写入）
// ---------------------------------------------------------------------------
{
  const L = []
  const regDir = join(PROJECT_ROOT, 'packages', 'plugins')
  const makeSkill = (root, id) => {
    const dir = join(root, id)
    mkdirSync(dir, { recursive: true })
    writeFileSync(join(dir, 'index.mjs'), 'export async function activate(ctx) { return {} }\nexport default { activate }\n')
    const man = { id, name: id, version: '1.0.0', capabilities: [], permissions: [], scopes: [], entry: 'index.mjs', source: dir }
    man.hash = buildFileManifest(dir)
    writeFileSync(join(dir, 'plugin.json'), JSON.stringify(man, null, 2))
    return dir
  }
  const tmpRoot = mkdtempSync(join(tmpdir(), 'final-b4-'))
  const srcDir = makeSkill(tmpRoot, 'final-b4-skill')
  let ok = true

  // 合法：prepare（零写入）→ confirm（真装 + 审计）
  const p = reg.prepareSkillInstall(srcDir)
  L.push('--- prepare（校验+权限清单，零写入）---', `ok=${p.ok} token=${!!p.token} permissions=${JSON.stringify(p.permissions || p.summary || null)}`)
  ok = ok && p.ok && !!p.token
  const c = reg.commitSkillInstall(p.token)
  const installed = existsSync(join(regDir, 'final-b4-skill'))
  L.push('--- confirm ---', `ok=${c.ok} installed=${installed}`)
  ok = ok && c.ok && installed
  reg.scan()

  // 审计行
  const audit = readFileSync(join(PROJECT_ROOT, 'data', 'logs', 'plugins.jsonl'), 'utf8').trim().split('\n')
  const inst = audit.filter((x) => /skill\.install/.test(x)).pop()
  L.push('最近一条 skill.install 审计行：', inst || '(缺)')
  ok = ok && !!inst

  // 篡改 hash 拒绝（零写入）
  const evilRoot = mkdtempSync(join(tmpdir(), 'final-b4-evil-'))
  const evilDir = makeSkill(evilRoot, 'final-b4-evil')
  writeFileSync(join(evilDir, 'index.mjs'), 'export async function activate(ctx) { return { evil: true } }\nexport default { activate }\n')
  const pe = reg.prepareSkillInstall(evilDir)
  L.push('--- 篡改 hash prepare ---', `ok=${pe.ok} code=${pe.code || ''} error=${pe.error || ''}`)
  ok = ok && !pe.ok && /HASH/.test(String(pe.code || pe.error || ''))
  ok = ok && !existsSync(join(regDir, 'final-b4-evil'))

  // 权限被拒（cancel）零落盘
  const p2 = reg.prepareSkillInstall(srcDir)
  const c2 = reg.cancelSkillInstall(p2.token)
  L.push('--- cancel（拒绝授权）---', `ok=${c2.ok} 未落盘=${!existsSync(join(regDir, 'final-b4-skill-2'))}`)
  ok = ok && c2.ok

  // 卸载只移不删
  const rt = await reg.retireSkill('final-b4-skill')
  const retiredList = existsSync(join(regDir, '.retired')) ? readdirSync(join(regDir, '.retired')) : []
  const retired = retiredList.find((d) => d.startsWith('final-b4-skill-'))
  L.push('--- retire ---', `ok=${rt.ok} retiredTo=${rt.retiredTo || rt.retired || 'N/A'}`)
  ok = ok && rt.ok && !!retired && existsSync(join(regDir, '.retired', retired, 'plugin.json'))

  // 越界防护（单测已覆盖，此处引用证据）
  L.push('越界防护 E_SCOPE_UNKNOWN / E_PLUGIN_FS_OUTSIDE：由 tests/skill-installer.test.mjs 沙箱用例覆盖（全量 433 内通过）')

  // capability 门禁：skill-installer 声明 skill.admin
  const si = reg._records.get('skill-installer')
  L.push(`skill-installer capabilities=${JSON.stringify(si.manifest.capabilities)}`)
  ok = ok && si.manifest.capabilities.includes('skill.admin')

  // 清理：final-b4-skill 的退休目录（我们的验收垃圾，.retired 只留 canonical）
  rmSync(join(regDir, '.retired', retired), { recursive: true, force: true })
  rmSync(tmpRoot, { recursive: true, force: true })
  L.push('清理：final-b4-* 验收残留已删（.retired 仅留 accept-b4-skill canonical 证据）')

  writeStep('stage4-final-12-skill.txt', '③ skill 链路', L)
  record('3', 'skill 链路：合法安装/篡改拒/cancel 中止/门禁/retire 只移不删/越界', ok, 'stage4-final-12-skill.txt', 'node tools/accept-stage4-final.mjs')
}

// ---------------------------------------------------------------------------
// ④ 计时与进度（端到端 + 引用单测/GUI 证据）
// ---------------------------------------------------------------------------
{
  const L = []
  let ok = true
  const pj = `final-b4-demo-${Date.now() % 100000}`
  const r1 = await run('project', `new ${pj}`)
  const r2 = await run('project', `add-stage ${pj} 写作`)
  const r3 = await run('start', `30 ${pj} 写作`)
  const r4 = await run('status', '')
  const r5 = await run('stop', '')
  const r6 = await run('today', '')
  const r7 = await run('weekly', '')
  L.push('--- 端到端 ---', r1.text, r2.text, r3.text, r4.text.split('\n')[0], r5.text.split('\n')[0], r6.text.split('\n')[0], r7.text.split('\n')[0])
  ok = ok && r1.ok && r2.ok && r3.ok && r4.ok && r5.ok && r6.ok && r7.ok
  // 清理演示项目
  rmSync(join(PROJECT_ROOT, 'data', 'projects', `${pj}.json`), { force: true })
  L.push('崩溃恢复/加速不进统计：tests/timer-plugin.test.mjs + stage32-shots.json idleResolvedKeep 覆盖（全量 433 内）')
  const s32 = JSON.parse(readFileSync(join(LOGS, 'stage32-shots.json'), 'utf8'))
  L.push(`stage32 GUI：idlePromptTriggered=${s32.idlePromptTriggered} idleResolvedKeep=${s32.idleResolvedKeep}`)
  ok = ok && s32.idlePromptTriggered && s32.idleResolvedKeep

  writeStep('stage4-final-13-timer.txt', '④ 计时与进度', L)
  record('4', '计时与进度：端到端/崩溃恢复+加速不进统计（单测）/日报周报/GUI', ok, 'stage4-final-13-timer.txt', 'node tools/accept-stage4-final.mjs')
}

// ---------------------------------------------------------------------------
// ⑤ 底座与内核
// ---------------------------------------------------------------------------
{
  const L = []
  let ok = true
  // 双 provider
  const appLines = readFileSync(join(LOGS, 'app.jsonl'), 'utf8').trim().split('\n')
  const cr = [...appLines].reverse().find((x) => /core-ready/.test(x))
  const crObj = cr ? JSON.parse(cr) : null
  L.push('最近 core-ready providers=' + JSON.stringify(crObj && crObj.providers))
  ok = ok && crObj && (crObj.providers || []).includes('deepseek-api') && (crObj.providers || []).includes('school-gateway')
  // 白名单拒绝（sci-hub 类）
  let denied = false
  try { assertAllowedBaseUrl('https://sci-hub.se/whatever.pdf'); denied = false } catch { denied = true }
  L.push(`assertAllowedBaseUrl('https://sci-hub.se/…') 抛错（白名单拒绝）=${denied}`)
  ok = ok && denied
  // reasoner 排队与 429 退避：net.test 覆盖（全量 433 内）
  L.push('reasoner 10 次/分排队 + 429 退避：tests/net.test.mjs 覆盖（全量 433 内通过）')
  // 密钥零明文：net.jsonl 与 plugins.jsonl 抽查 sk- 明文
  let leak = 0
  for (const f of ['net.jsonl', 'plugins.jsonl', 'app.jsonl']) {
    const p = join(LOGS, f)
    if (!existsSync(p)) continue
    const raw = readFileSync(p, 'utf8')
    for (const m of raw.matchAll(/sk-[A-Za-z0-9]{16,}/g)) leak++
  }
  L.push(`日志密钥明文（sk-…）命中=${leak}（0=通过；config 只出掩码）`)
  ok = ok && leak === 0

  writeStep('stage4-final-14-core.txt', '⑤ 底座与内核', L)
  record('5', '底座与内核：双provider/白名单拒绝/reasoner限速（单测）/密钥零明文', ok, 'stage4-final-14-core.txt', 'node tools/accept-stage4-final.mjs')
}

// ---------------------------------------------------------------------------
// ⑥ electron 冒烟（引用 accept-smoke-electron 已产证据）
// ---------------------------------------------------------------------------
{
  const j = JSON.parse(readFileSync(join(LOGS, 'stage4-final-electron.json'), 'utf8'))
  const appRaw = readFileSync(join(LOGS, 'app.jsonl'), 'utf8').trim().split('\n')
  const lastInject = [...appRaw].reverse().find((x) => /bridge-injected/.test(x))
  const ok = !j.uncaught || (j.uncaught.length === 0 && j.uiPing && j.settingsRoundTrip && j.shots.length === 3 && !!lastInject && (j.settingsVersion || []).every((v) => v === 'v' + APP_VERSION) && j.electronLeft === 0)
  record('6', 'electron 冒烟：bridge-injected 无异常/ping/settings 往返/3 截图/残留 0', ok, 'stage4-final-electron.json + stage4-final-electron.txt + data/shots/stage4-final-*.png', 'node tools/accept-smoke-electron.mjs')
}

// ---------------------------------------------------------------------------
// ⑦ 版本终局（package.json → 托盘/设置页/3 plugin.json）
// ---------------------------------------------------------------------------
{
  const pkg = JSON.parse(readFileSync(join(PROJECT_ROOT, 'package.json'), 'utf8'))
  // 版本终局只比对「产品插件」（research-literature / research-timer / skill-installer）：
  // hello 是底座示例插件，自持 0.1.0，不属于产品版本线，豁免比对。
  const plugs = readdirSync(join(PROJECT_ROOT, 'packages', 'plugins')).filter((d) => !d.startsWith('.') && d !== 'hello')
  const mism = []
  for (const p of plugs) {
    const pjPath = join(PROJECT_ROOT, 'packages', 'plugins', p, 'plugin.json')
    if (!existsSync(pjPath)) continue
    const v = JSON.parse(readFileSync(pjPath, 'utf8')).version
    if (v !== pkg.version) mism.push(`${p}:${v}`)
  }
  const mainSrc = readFileSync(join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs'), 'utf8')
  const mExpr = mainSrc.match(/^const APP_VERSION = (.+)$/m)
  const evalExpr = mExpr ? new Function('readFileSync', 'join', 'ROOT', `return (${mExpr[1]})`)(readFileSync, join, PROJECT_ROOT) : null
  const j = JSON.parse(readFileSync(join(LOGS, 'stage4-final-electron.json'), 'utf8'))
  const settingsVers = j.settingsVersion || []
  const ok = !mism.length && evalExpr === pkg.version && settingsVers.length > 0 && settingsVers.every((v) => v === 'v' + pkg.version)
  record('7', `版本终局：pkg=${pkg.version} 托盘=${evalExpr} plugin.json 全一致=${mism.length === 0} 设置页=${settingsVers.join(',')}`, ok, 'stage4-final-electron.json(settingsVersion) + stage4-final-summary.json', 'node tools/accept-stage4-final.mjs')
}

// ---------------------------------------------------------------------------
// ⑧ 文档终审（锚点逐项比对 + 已修正清单）
// ---------------------------------------------------------------------------
{
  const rd = (p) => readFileSync(join(PROJECT_ROOT, p), 'utf8')
  const readme = rd('README.md')
  const arch = rd('docs/ARCH.md')
  const deps = rd('docs/DEPS.md')
  const road = rd('docs/ROADMAP-v2.md')
  const stage = rd('docs/STAGE-LOG.md')
  const checks = {
    'README 文献命令数=七条（实测 7 registerCommand）': /七条命令/.test(readme),
    'README /note export 含 --docx/--latex 且 docx 已真跑描述': /--docx\]\s*\[--latex\]|--docx`?\s*真导出/.test(readme) === false ? /--docx/.test(readme) && /--latex/.test(readme) && /真导出/.test(readme) : true,
    'README 不再出现「Word .docx 留待块 4」': !readme.includes('留待块 4'),
    'ARCH 含 .retired 数据布局（块 4）': /\.retired/.test(arch),
    'DEPS §6 docx@9.11.0 + §6.1 python-docx==1.1.2（项目内 .venv）': deps.includes('docx@9.11.0') && deps.includes('python-docx==1.1.2') && deps.includes('research-orb\\.venv') || (deps.includes('docx@9.11.0') && deps.includes('python-docx==1.1.2') && deps.includes('.venv')),
    'ROADMAP P-R4 四块完成（9/9 ×4）': /块 4（skill 安装器 \+ docx）9\/9/.test(road),
    'STAGE-LOG 含块 1-4 四段验收记录': ['块 1', '块 2', '块 3', '块 4'].every((k) => stage.includes(k)),
  }
  const L = ['锚点逐项比对：', ...Object.entries(checks).map(([k, v]) => `${v ? 'OK ' : 'MISS'} ${k}`), '', '终审时修正的文档偏差（已改）：1) README 文献命令数 六→七（/note 纳入）；2) /note export 行补 --docx/--latex 与 docx 真跑描述；3) 删除「Word .docx 留待块 4」过时表述。其余（ARCH 数据布局/DEPS 依赖/能力清单示例/DOMAIN 字段表）与实现一致。']
  const ok = Object.values(checks).every(Boolean)
  writeStep('stage4-final-18-docs.txt', '⑧ 文档终审', L)
  record('8', '文档终审：命令表/目录树/依赖表/数据布局/能力清单', ok, 'stage4-final-18-docs.txt', 'node tools/accept-stage4-final.mjs')
}

// ---------------------------------------------------------------------------
// ⑨ 隔离五查（引用 accept-isolation 已产证据）
// ---------------------------------------------------------------------------
{
  const txt = readFileSync(join(LOGS, 'stage4-final-isolation.txt'), 'utf8')
  const ok = /\[1\].*OK 完全一致/.test(txt) && /\[2\] start\.cmd:.*OK/.test(txt) && /\[2\] start-dev\.cmd:.*OK/.test(txt) && /\[3\].*OK 本阶段零写入/.test(txt) && /\[4\].*0 个/.test(txt) && /\[5\].*0 个/.test(txt)
  record('9', '隔离五查：orb零写入/vendor+start指纹一致/计划任务0/进程0/helper无新增', ok, 'stage4-final-isolation.txt', 'node tools/accept-isolation 步骤（PowerShell 记录于该文件）')
}

// ---------------------------------------------------------------------------
// 全量测试 + summary
// ---------------------------------------------------------------------------
{
  const r = spawnSync('node', ['--test', '--test-concurrency=1', ...readdirSync(join(PROJECT_ROOT, 'tests')).filter((f) => f.endsWith('.test.mjs')).map((f) => `tests/${f}`)], { cwd: PROJECT_ROOT, encoding: 'utf8', timeout: 420000 })
  const pass = Number((r.stdout.match(/^# pass (\d+)$/m) || [])[1] || 0)
  const fail = Number((r.stdout.match(/^# fail (\d+)$/m) || [])[1] || 1)
  SUMMARY.tests = { pass, fail }
  record('T', `全量测试 ${pass}/${pass + fail}`, fail === 0 && pass >= 433, '本次运行输出 + stage4-final-summary.json', 'node --test --test-concurrency=1 tests/*.test.mjs')
}

SUMMARY.allPass = SUMMARY.items.every((i) => i.ok)
safeWrite(join(LOGS, 'stage4-final-summary.json'), JSON.stringify(SUMMARY, null, 2))
console.log(`\nallPass=${SUMMARY.allPass}  tests=${SUMMARY.tests.pass}/${SUMMARY.tests.pass + SUMMARY.tests.fail}`)
console.log('summary → data/logs/stage4-final-summary.json')
