// tools/accept-s34-datadir.mjs —— S34·P0 数据目录隔离验收（≥6 项）。
// 单行复跑：node tools\accept-s34-datadir.mjs
// 证据：data\logs\s34-datadir-accept.json
//
// 覆盖：子进程经 ORB_DATA_DIR 写（临时数据目录有内容）/ 真实 data\（除 logs）零新增零修改
//      （mtime+size 对比表）/ 二次运行幂等 / run-tests 接线 / audit-preflight 隔离期仍 PASS /
//      DATA_DIR 跟随 env / dataPath() 零参返回 DATA_DIR 本身。
import { spawnSync } from 'node:child_process'
import { existsSync, readdirSync, readFileSync, statSync, rmSync, writeFileSync, mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { pathToFileURL } from 'node:url'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { auditPreflight } from '../packages/plugins/coach/audit-preflight.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const REAL_DATA = join(PROJECT_ROOT, 'data')
const WRITER = join(PROJECT_ROOT, 'tools', '_probe-datadir-writer.mjs')
const RUN_TESTS = join(PROJECT_ROOT, 'tools', 'run-tests.mjs')

function snapshotData() {
  const map = new Map()
  const walk = (p, rel) => {
    let entries
    try { entries = readdirSync(p) } catch { return }
    for (const n of entries) {
      const fp = join(p, n)
      const r = rel ? rel + '/' + n : n
      let st
      try { st = statSync(fp) } catch { continue }
      if (st.isDirectory()) { if (n === 'node_modules') continue; walk(fp, r) }
      else map.set(r, { mtimeMs: Math.round(st.mtimeMs), size: st.size })
    }
  }
  walk(REAL_DATA, '')
  for (const k of [...map.keys()]) if (k.startsWith('logs/')) map.delete(k) // logs 归 S33 口径
  return map
}
function diffData(a, b) {
  const changed = []
  for (const k of new Set([...a.keys(), ...b.keys()])) {
    const x = a.get(k), y = b.get(k)
    if (!x && y) changed.push('+ ' + k)
    else if (x && !y) changed.push('- ' + k)
    else if (x.mtimeMs !== y.mtimeMs || x.size !== y.size) changed.push('~ ' + k)
  }
  return changed
}
function runWriter(envDataDir, n = 1) {
  return spawnSync(process.execPath, [WRITER], {
    cwd: PROJECT_ROOT,
    env: { ...process.env, ORB_DATA_DIR: envDataDir, ORB_LOG_DIR: join(tmpdir(), `orb-accept-datalog-${process.pid}`) },
    encoding: 'utf8',
  })
}

const isoData = join(tmpdir(), `orb-accept-data-${process.pid}`)
try {
  rmSync(isoData, { recursive: true, force: true })

  const before = snapshotData()
  let preOk = false
  try { preOk = auditPreflight().ok === true } catch { preOk = false }

  const c1 = runWriter(isoData)
  const after1 = snapshotData()
  const c2 = runWriter(isoData)
  const after2 = snapshotData()

  // D1：子进程按 ORB_DATA_DIR 写（stdout 的 DATA_DIR == isoData，exit 0）
  let meta = null
  try { meta = JSON.parse(String(c1.stdout || '').trim().split('\n').pop()) } catch { meta = null }
  check('D1', c1.status === 0 && !!meta && String(meta.DATA_DIR).toLowerCase() === isoData.toLowerCase(),
    `exit=${c1.status} child.DATA_DIR=${meta && meta.DATA_DIR}`, { stdout: String(c1.stdout || '').slice(0, 160) })

  // D2：临时数据目录有内容（config.json + notes/s34-probe.md）
  const cfgOk = existsSync(join(isoData, 'config.json'))
  const noteOk = existsSync(join(isoData, 'notes', 's34-probe.md'))
  check('D2', cfgOk && noteOk, `temp config.json=${cfgOk} notes/s34-probe.md=${noteOk}`, {})

  // D3：真实 data\（除 logs）零新增零修改——mtime/size 对比表
  const d1 = diffData(before, after1)
  check('D3', d1.length === 0, `真实 data 变化=${d1.length} ${d1.slice(0, 6).join(' | ')}`, { changed: d1 })

  // D4：二次运行幂等（真实 data 仍零变化）
  const d2 = diffData(before, after2)
  check('D4', d2.length === 0, `二次后真实 data 变化=${d2.length}`, { changed: d2 })

  // D5：run-tests 接线（设 ORB_DATA_DIR + 打印）
  const rt = readFileSync(RUN_TESTS, 'utf8')
  check('D5', /process\.env\.ORB_DATA_DIR\s*=/.test(rt) && /数据隔离/.test(rt), `setEnv=${/process\.env\.ORB_DATA_DIR\s*=/.test(rt)}`, {})

  // D6：隔离期 audit-preflight 仍 PASS（读的是真实 data/logs）
  let postOk = false
  try { postOk = auditPreflight().ok === true } catch { postOk = false }
  check('D6', preOk && postOk, `pre=${preOk} post=${postOk}`, {})

  // D7：dataPath() 零参返回 DATA_DIR 本身（子进程内已验证 WRITES_LOG/LOG_DIR 分离，这里验 DATA_DIR 语义）
  const safefsUrl = pathToFileURL(join(PROJECT_ROOT, 'packages', 'core', 'src', 'safefs.mjs')).href
  const probe = spawnSync(process.execPath, ['--input-type=module', '-e',
    `import(${JSON.stringify(safefsUrl)}).then(m=>console.log(JSON.stringify({same:m.DATA_DIR===m.dataPath()})))`],
    { cwd: PROJECT_ROOT, env: { ...process.env, ORB_DATA_DIR: isoData }, encoding: 'utf8' })
  let same = null
  try { same = JSON.parse(String(probe.stdout || '').trim().split('\n').pop()).same } catch { same = null }
  check('D7', same === true, `dataPath()===DATA_DIR → ${same}`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
} finally {
  try { rmSync(isoData, { recursive: true, force: true }) } catch { /* 尽力 */ }
}

const pass = items.filter((i) => i.ok).length
mkdirSync(join(REAL_DATA, 'logs'), { recursive: true })
writeFileSync(join(REAL_DATA, 'logs', 's34-datadir-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s34-datadir: total=${items.length} pass=${pass} fail=${items.length - pass}`)
console.log('  # 证据 -> data/logs/s34-datadir-accept.json')
process.exit(pass === items.length ? 0 : 1)
