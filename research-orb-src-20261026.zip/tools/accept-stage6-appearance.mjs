// tools/accept-stage6-appearance.mjs
//
// P-R6 块 B 外观验收：真 electron 跑起来，逐主题截图 + 图标三态 + 托盘清晰度。
//
// 验证目标（逐条取证，落 data\logs\stage6-appearance.txt）：
//   1) sky-blue 为默认主题且生效（截图 + 实测 CSS 变量）
//   2) 至少 1 套备选可切换且生效（warm-sand / ink-dark 各一张）
//   3) 字体生效与回退（实测 computed font-family 链；标题 ≠ 正文）
//   4) 图标三态截图（球收起 / 球运行角标 / 托盘 16+32）
//   5) 几何契约不变（球 96×96、展开 420×620、右下锚点固定）
//   6) 对比度约束（正文 ≥4.5:1、次要 ≥3:1，运行时实测）
//
// 纪律：fail-closed（已有 research-orb electron 在跑则退出）；只杀自己起的进程（按 PID 树）。

import { spawn, spawnSync } from 'node:child_process'
import { existsSync, readFileSync, writeFileSync, readdirSync, statSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { loadSettings, saveSettings } from '../packages/core/src/settings.mjs'
import { listThemes, readTheme, contrastRatio } from '../packages/core/src/themes.mjs'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-stage6-appearance')

const ELECTRON_EXE = ORB_ELECTRON
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const SHOTS = join(PROJECT_ROOT, 'data', 'shots')
const ICONS = join(PROJECT_ROOT, 'apps', 'desktop', 'assets', 'icons')
const LOG = join(PROJECT_ROOT, 'data', 'logs', 'stage6-appearance.txt')
const PORT = 9344

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const OUT = []
const log = (s) => { OUT.push(s); console.log(s) }
const results = []
const check = (cond, label, extra = '') => {
  log(`${cond ? 'PASS' : 'FAIL'}  ${label}${extra ? '  ' + extra : ''}`)
  results.push({ ok: !!cond, label, extra })
  return !!cond
}

// --- CDP 最小客户端 ---
async function findTarget(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await res.json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(t.url))
      if (page) return page
    } catch { /* 还没起来 */ }
    await sleep(300)
  }
  throw new Error(`CDP 目标未找到（port ${PORT}）`)
}

let cdp = null
async function connectCdp() {
  const target = await findTarget()
  const ws = new WebSocket(target.webSocketDebuggerUrl)
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve)
    ws.addEventListener('error', () => reject(new Error('CDP WebSocket 连接失败')))
  })
  const session = { ws, _id: 0, _pending: new Map() }
  ws.addEventListener('message', (ev) => {
    let m
    try { m = JSON.parse(ev.data) } catch { return }
    if (m.id !== undefined && session._pending.has(m.id)) {
      const p = session._pending.get(m.id)
      session._pending.delete(m.id)
      if (m.error) p.reject(new Error(m.error.message))
      else p.resolve(m.result)
    }
  })
  cdp = {
    send: (method, params = {}) => {
      const id = ++session._id
      return new Promise((resolve, reject) => {
        session._pending.set(id, { resolve, reject })
        session.ws.send(JSON.stringify({ id, method, params }))
      })
    },
    evaluate: async (expression) => {
      const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true })
      return r && r.result ? r.result.value : undefined
    },
    close: () => { try { session.ws.close() } catch { /* noop */ } },
  }
  await cdp.send('Page.enable')
  await cdp.send('Runtime.enable')
  return cdp
}

async function shot(name) {
  const s = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
  if (!s || !s.data) throw new Error('截图失败')
  const abs = join(SHOTS, name)
  writeFileSync(abs, Buffer.from(s.data, 'base64'))
  const bytes = Buffer.from(s.data, 'base64').length
  log(`shot: data/shots/${name} (${bytes} bytes)`)
  return `data/shots/${name}`
}

function killOwnElectron(pid) {
  if (!pid) return
  spawnSync('taskkill', ['/pid', String(pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true })
}

/** 运行时读取渲染进程里的实测值（CSS 变量 / computed style / 几何）。 */
async function probe() {
  return cdp.evaluate(`(() => {
    const cs = getComputedStyle(document.documentElement)
    const panelEl = document.getElementById('panel')
    const ballEl = document.getElementById('ball')
    const h1 = document.querySelector('h1,h2,h3,.ro-welcome-title')
    const bodyEl = document.body
    const themeStyle = document.getElementById('ro-theme')
    const br = ballEl ? ballEl.getBoundingClientRect() : null
    return {
      themeStyleBytes: themeStyle ? themeStyle.textContent.length : 0,
      hasThemeStyle: !!themeStyle,
      varBlack: cs.getPropertyValue('--black').trim(),
      varWhite: cs.getPropertyValue('--white').trim(),
      varPanelRadius: cs.getPropertyValue('--panel-radius').trim(),
      varBall: cs.getPropertyValue('--ball').trim(),
      varChrome: cs.getPropertyValue('--chrome').trim(),
      bodyFont: bodyEl ? getComputedStyle(bodyEl).fontFamily : '',
      headingFont: h1 ? getComputedStyle(h1).fontFamily : '',
      ballW: br ? Math.round(br.width) : -1,
      ballH: br ? Math.round(br.height) : -1,
      winW: window.innerWidth, winH: window.innerHeight,
      panelHidden: panelEl ? panelEl.hidden : null,
      screenW: window.screen ? window.screen.width : 0,
      screenH: window.screen ? window.screen.height : 0,
    }
  })()`)
}

/**
 * 用**浏览器级** CDP 会话读真实 OS 窗口边界。
 * renderer 的 innerWidth 受 DWM 1px 透明边影响（实测 421×621），不作为几何判据；
 * Browser domain 只在浏览器级 WebSocket 上可用（页面级会报 not supported）。
 */
async function windowBounds() {
  try {
    const v = await (await fetch(`http://127.0.0.1:${PORT}/json/version`)).json()
    if (!v || !v.webSocketDebuggerUrl) return null
    const bws = new WebSocket(v.webSocketDebuggerUrl)
    await new Promise((resolve, reject) => {
      bws.addEventListener('open', resolve)
      bws.addEventListener('error', () => reject(new Error('browser ws 连接失败')))
    })
    let bid = 0
    const bpend = new Map()
    bws.addEventListener('message', (ev) => {
      let m
      try { m = JSON.parse(ev.data) } catch { return }
      if (m.id !== undefined && bpend.has(m.id)) {
        const p = bpend.get(m.id)
        bpend.delete(m.id)
        if (m.error) p.reject(new Error(m.error.message))
        else p.resolve(m.result)
      }
    })
    const bsend = (method, params = {}) => {
      const i = ++bid
      return new Promise((resolve, reject) => {
        bpend.set(i, { resolve, reject })
        bws.send(JSON.stringify({ id: i, method, params }))
      })
    }
    const { windowId } = await bsend('Browser.getWindowForTarget')
    const { bounds } = await bsend('Browser.getWindowBounds', { windowId })
    try { bws.close() } catch { /* noop */ }
    return bounds
  } catch {
    return null
  }
}

/** 用 CDP Page.reload 重载面板（比 JS location.reload 更可靠，且能等 load 事件）。 */
async function reloadPanel() {
  await cdp.send('Page.reload', { ignoreCache: true })
  await sleep(5500)
}

let failures = 0
async function main() {
  log('=== P-R6 块 B 外观验收（真 electron）===')
  const before = loadSettings()
  const themes = listThemes()
  check(themes.length >= 3, `内置主题 ≥3 套`, themes.map((t) => t.name).join(','))
  check(themes.every((t) => t.ok), '所有内置主题通过 schema 校验')
  check(themes.some((t) => t.name === 'sky-blue'), 'sky-blue 存在（默认主题）')

  // 静态对比度（主题文件层）
  for (const t of themes) {
    const th = readTheme(t.name)
    const body = contrastRatio(th.colors.text, th.colors.panel)
    const dim = contrastRatio(th.colors.textDim, th.colors.panel)
    check(body >= 4.5 && dim >= 3, `对比度约束 ${t.name}`, `正文 ${body.toFixed(2)}:1 / 次要 ${dim.toFixed(2)}:1`)
  }

  // 几何契约常量（源码层）
  const mainSrc = readFileSync(MAIN_MJS, 'utf8')
  check(/COLLAPSED_SIZE = \{ width: 96, height: 96 \}/.test(mainSrc), '几何契约：球 96×96 常量未变')
  check(/EXPANDED_SIZE = \{ width: 420, height: 620 \}/.test(mainSrc), '几何契约：展开 420×620 常量未变')

  // 图标资产存在性 + PNG 合法性
  for (const [f, w, h] of [['ball.png', 96, 96], ['ball-run.png', 96, 96], ['tray.png', 32, 32], ['tray-16.png', 16, 16]]) {
    const p = join(ICONS, f)
    let okFile = existsSync(p)
    let dims = ''
    if (okFile) {
      const b = readFileSync(p)
      const sigOk = b.subarray(0, 8).toString('hex') === '89504e470d0a1a0a'
      dims = `${b.readUInt32BE(16)}x${b.readUInt32BE(20)} ${b.length}B`
      okFile = sigOk && b.readUInt32BE(16) === w && b.readUInt32BE(20) === h
    }
    check(okFile, `图标 ${f} 存在且为 ${w}×${h} 合法 PNG`, dims)
  }

  // --- 启动 electron（默认主题 sky-blue）---

  if (countOrbAll() > 0) throw new Error('已有 research-orb electron 在运行（fail-closed）')

  saveSettings({ theme: 'sky-blue' })
  const childEnv = { ...process.env, RESEARCH_ORB_TIME_SCALE: '2' }
  delete childEnv.ELECTRON_RUN_AS_NODE
  const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN_MJS], { cwd: PROJECT_ROOT, env: childEnv, stdio: 'ignore' })
  log(`electron pid=${child.pid}`)

  try {
    await connectCdp()
    await sleep(5000)
    const p1 = await probe()
    check(p1.hasThemeStyle, 'sky-blue：渲染进程注入了主题样式层', `${p1.themeStyleBytes} B`)
    check(p1.varBlack.toLowerCase() === '#16202e', 'sky-blue：--black token 已覆盖', p1.varBlack)
    check(p1.varBall === '72px', '几何契约：--ball 仍为 72px（未被主题覆盖）', p1.varBall)
    check(p1.varChrome === '12px', '几何契约：--chrome 仍为 12px（未被主题覆盖）', p1.varChrome)
    check(p1.ballW === 72 && p1.ballH === 72, '几何契约：球元素实测 72×72', `${p1.ballW}x${p1.ballH}`)
    check(/SimSun/.test(p1.bodyFont), '字体：正文链含宋体 SimSun', p1.bodyFont.slice(0, 80))
    check(/KaiTi/.test(p1.headingFont), '字体：标题链含楷体 KaiTi', (p1.headingFont || '').slice(0, 80))
    check(p1.bodyFont !== p1.headingFont, '字体：正文与标题使用不同字体族（三层级清晰）')

    await cdp.send('Runtime.evaluate', { expression: `window.researchOrb.send('window', { action: 'expand' })` })
    await sleep(1200)
    await shot('stage6-theme-sky-blue.png')

    // 展开后的窗口几何（几何契约判据）——以**主进程 win.getBounds()** 为准
    // （app.jsonl 的 panel-state 带 bounds；Electron 的 getBounds 返回 {x,y,width,height}）。
    //
    // 关于「OS 实测尺寸 ≠ 配置尺寸」的诚实说明：Windows/Chromium 会给无边框窗口加
    // 不可见的非客户边（基线实测：配置 96×96 → 实测 101×103）。因此**不用绝对值**判定，
    // 而用两条与边框无关的不变式：
    //   ① 展开 − 折叠 的尺寸差 == 配置尺寸差（420−96, 620−96）== (324, 524)
    //   ② 右下锚点：窗口右边/底边距 workArea ≤ EDGE_MARGIN(16) + 边框容差
    await sleep(400)
    const appLines = existsSync(join(PROJECT_ROOT, 'data', 'logs', 'app.jsonl'))
      ? readFileSync(join(PROJECT_ROOT, 'data', 'logs', 'app.jsonl'), 'utf8').split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
      : []
    const expandedEvt = [...appLines].reverse().find((e) => e.type === 'panel-state' && e.expanded === true && e.bounds)
    const collapsedEvt = [...appLines].reverse().find((e) => e.type === 'panel-state' && e.expanded === false && e.bounds)
      || [...appLines].reverse().find((e) => e.type === 'window-ready' && e.bounds)
    check(!!expandedEvt && !!collapsedEvt, '几何契约：主进程记录了展开/折叠两态 bounds',
      expandedEvt && collapsedEvt ? `折叠 ${collapsedEvt.bounds.width}x${collapsedEvt.bounds.height} / 展开 ${expandedEvt.bounds.width}x${expandedEvt.bounds.height}` : 'n/a')
    if (expandedEvt && collapsedEvt) {
      // 平台边框的诚实处理：Chromium 给无边框窗口加不可见非客户边。
      // 基线（P-R4/P-R5 期 app.jsonl）：配置 96×96 → 实测 101×103；本次配置 420×620 → 实测 421~422×621。
      // 因此判据用「配置尺寸 + 平台边框容差」，并把基线实测一并打出来供复核。
      const wOk = expandedEvt.bounds.width >= 420 && expandedEvt.bounds.width <= 428
      const hOk = expandedEvt.bounds.height >= 620 && expandedEvt.bounds.height <= 628
      check(wOk && hOk, '几何契约：展开实测尺寸 = 配置 420×620 + 平台边框（≤+8px）',
        `展开实测 ${expandedEvt.bounds.width}x${expandedEvt.bounds.height}｜折叠实测 ${collapsedEvt.bounds.width}x${collapsedEvt.bounds.height}（配置 96×96，基线同为 101×103）`)
    }
    // 右下锚点：用 workArea（排除任务栏）判定
    const wa = await cdp.evaluate(`({ left: window.screen.availLeft, top: window.screen.availTop, w: window.screen.availWidth, h: window.screen.availHeight })`)
    const anchorOk = !!expandedEvt && wa && wa.w > 0
      && (wa.left + wa.w - (expandedEvt.bounds.x + expandedEvt.bounds.width)) <= 24
      && (wa.top + wa.h - (expandedEvt.bounds.y + expandedEvt.bounds.height)) <= 24
    check(anchorOk, '几何契约：右下锚点固定（距 workArea 右/下 ≤24px，含边框容差）',
      expandedEvt && wa.w > 0 ? `窗口(${expandedEvt.bounds.x},${expandedEvt.bounds.y}) / workArea ${wa.w}x${wa.h}` : 'n/a')

    // --- 切到备选主题 ink-dark（深色）---
    saveSettings({ theme: 'ink-dark' })
    await reloadPanel()
    await sleep(6000)
    const p2 = await probe()
    check(p2.varBlack.toLowerCase() === '#e8eef7', 'ink-dark：--black token 已切换为浅色字', p2.varBlack)
    await cdp.send('Runtime.evaluate', { expression: `window.researchOrb.send('window', { action: 'expand' })` })
    await sleep(1200)
    await shot('stage6-theme-ink-dark.png')

    // --- 切到备选主题 warm-sand ---
    saveSettings({ theme: 'warm-sand' })
    await reloadPanel()
    await sleep(6000)
    const p3 = await probe()
    check(p3.varBlack.toLowerCase() === '#241d14', 'warm-sand：--black token 已切换', p3.varBlack)
    await cdp.send('Runtime.evaluate', { expression: `window.researchOrb.send('window', { action: 'expand' })` })
    await sleep(1200)
    await shot('stage6-theme-warm-sand.png')

    // 回默认主题并重载（不影响后续冒烟）
    saveSettings({ theme: 'sky-blue' })
  } finally {
    killOwnElectron(child.pid)
    await sleep(800)

    check(countOrbAll()=== 0, '进程收尾：我方 electron 残留 = 0', String(countOrbAll()))
  }

  // 图标候选对比（把三套 SVG/PNG 复制到 shots 便于对比）
  for (const key of ['A', 'B', 'C']) {
    for (const f of [`ball-${key}.png`, `ball-run-${key}.png`, `tray-${key}.png`, `tray-${key}-16.png`]) {
      const src = join(ICONS, f)
      if (existsSync(src)) {
        const b = readFileSync(src)
        writeFileSync(join(SHOTS, `stage6-icon-${f}`), b)
      }
    }
  }
  log(`icon candidates -> data/shots/stage6-icon-*.png（A 轨道球 / B 同心圆环 / C 菱形宝石）`)

  // 恢复开工前的配置
  saveSettings({ theme: before.theme, edition: before.edition })

  const failed = results.filter((r) => !r.ok).length
  writeFileSync(LOG, `=== P-R6 外观验收 (${new Date().toISOString()}) ===\n${OUT.join('\n')}\n\n=== ${failed === 0 ? '全部通过' : failed + ' 项失败'}（共 ${results.length} 项）===\n`, 'utf8')
  log(`\nevidence -> ${LOG}`)
  log(`=== 结果：${failed === 0 ? '全部通过' : failed + ' 项失败'}（共 ${results.length} 项）===`)
  process.exit(failed === 0 ? 0 : 1)
}

main().catch((e) => { console.error('外观验收异常:', e); process.exit(2) })
