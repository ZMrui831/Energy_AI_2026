// tools/accept-s10-doi.mjs —— S10 镜 2 验收：检索结果行内可信标记（双源/仅单源/未收录）。
//
// 独立性（CONTRACT §7）：trust 判定**复用 connectors 的同批抓取器**（fetchOpenAlexByDoi /
// fetchCrossrefByDoi）——与 lookupRecordByDoi / verifyDoiSource 出网同一源、同一 net 出口。
// 本脚本用桩 net 复现"双源收录 / 仅单源 / 未收录 / 无 DOI"四态，并交叉验证：
//   ① doiTrustForCandidates 三档正确；
//   ② 每源的 ok 标志与"直接调 connectors 抓取器"逐源一致（证明没有另写一套 HTTP/判定）；
//   ③ 文献插件既有校验器 verifyDoiSource 对同一 DOI 给出"两源均未收录=rejected"（同源语义）；
//   ④ /find 真实命令路径：候选 ui 携带 doiTrust 且 formatCandidates 文本含行内标记。
//
// 单行复跑：node tools/run-isolated.mjs --label s10 --cmd "node tools/accept-s10-doi.mjs"

import { createHash } from 'node:crypto'
import { mkdirSync, writeFileSync, readFileSync, existsSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT, logPath } from '../packages/core/src/safefs.mjs'
import { createNet } from '../packages/core/src/net.mjs'
import { createEngine } from '../packages/plugins/research-literature/index.mjs'
import { makeFakeCtx, makeMemoryScopes, arxivFeedXml } from '../tests/helpers/research-fixtures.mjs'
import { doiTrustForCandidates, normalizeDoi, DOI_TRUST_LABELS } from '../packages/plugins/research-literature/lib/doi-trust.mjs'
import { fetchOpenAlexByDoi, fetchCrossrefByDoi, OPENALEX_SOURCE, CROSSREF_SOURCE, lookupRecordByDoi } from '../packages/plugins/research-literature/connectors/index.mjs'
import { verifyDoiSource } from '../packages/plugins/research-literature/lib/cite-verify.mjs'
import { formatCandidates } from '../packages/plugins/research-literature/index.mjs'

const sha = (p) => createHash('sha256').update(readFileSync(p)).digest('hex')
const items = []
function report(id, clause, ok, detail, evidence = {}) {
  items.push({ id, clause, ok: !!ok, detail, evidence })
  console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`)
}

// 四态 DOI 方案：A=双源，B=仅 Crossref，C=两源都未收录，D=无 DOI
const DUAL = '10.1000/A'
const SINGLE = '10.1000/B'
const NONE = '10.1000/C'

function stubFetchImpl(url) {
  const u = String(url)
  // ---- DOI 按源查（trust 步 + verifyDoiSource / lookupRecordByDoi 同源）----
  if (u.includes('/works/https://doi.org/')) {
    // OpenAlex 按 DOI 查（normalizeDoi 会把 DOI 转小写，故比较也小写）
    const doi = (u.match(/doi\.org\/(.+?)(\?|$)/)?.[1] || '').toLowerCase()
    if (doi === DUAL.toLowerCase()) return new Response(JSON.stringify({ id: 'W1', title: 'Dual', doi, publication_year: 2024, authorships: [], cited_by_count: 1, primary_location: null }), { status: 200 })
    return new Response('{}', { status: 200 }) // 无 title → connector 抛 E_NOT_FOUND
  }
  if (/api\.crossref\.org\/works\//.test(u) && !/\?.*query/.test(u)) {
    const doi = u.split('/works/')[1].split('?')[0].toLowerCase()
    if (doi === DUAL.toLowerCase() || doi === SINGLE.toLowerCase()) return new Response(JSON.stringify({ message: { DOI: doi, title: ['X'], issued: { 'date-parts': [[2024]] }, author: [], 'is-referenced-by-count': 1 } }), { status: 200 })
    return new Response(JSON.stringify({ message: {} }), { status: 200 })
  }
  // ---- 检索（find 步）----
  if (u.includes('export.arxiv.org')) return new Response(arxivFeedXml(8), { status: 200 })
  if (u.includes('api.openalex.org/works') && u.includes('?')) {
    return new Response(JSON.stringify({
      meta: { count: 3 },
      results: [
        { doi: DUAL, title: 'Dual source paper', publication_year: 2024, cited_by_count: 10, authorships: [{ author: { display_name: 'A1' } }], primary_location: { source: { display_name: 'J1' } }, abstract_inverted_index: null },
        { doi: SINGLE, title: 'Single source paper', publication_year: 2023, cited_by_count: 3, authorships: [{ author: { display_name: 'B1' } }], primary_location: { source: { display_name: 'J2' } }, abstract_inverted_index: null },
        { doi: NONE, title: 'No source paper', publication_year: 2022, cited_by_count: 1, authorships: [{ author: { display_name: 'C1' } }], primary_location: { source: { display_name: 'J3' } }, abstract_inverted_index: null },
      ],
    }), { status: 200 })
  }
  if (u.includes('api.crossref.org/works') && u.includes('?')) {
    return new Response(JSON.stringify({ message: { 'total-results': 0, items: [] } }), { status: 200 })
  }
  return new Response('{}', { status: 200 })
}

async function main() {
  const net = createNet({ fetchImpl: stubFetchImpl, logFile: logPath('s10-doi-net.jsonl') })
  mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })

  // (A) 三档判定
  const cands = [
    { doi: DUAL }, { doi: SINGLE }, { doi: NONE }, { doi: null },
  ]
  const tmap = await doiTrustForCandidates(cands, { net, limit: 12 })
  const t = (c) => tmap.get(c)
  const a = [
    ['A 双源', t(cands[0]).status === 'dual'],
    ['B 仅单源', t(cands[1]).status === 'single'],
    ['C 未收录', t(cands[2]).status === 'none'],
    ['D 无 DOI', t(cands[3]).status === 'no-doi'],
    ['标签正确', t(cands[0]).label === DOI_TRUST_LABELS.dual && t(cands[1]).label === DOI_TRUST_LABELS.single && t(cands[2]).label === DOI_TRUST_LABELS.none && t(cands[3]).label === DOI_TRUST_LABELS['no-doi']],
    ['归一化', normalizeDoi('https://doi.org/10.1000/A') === '10.1000/a'],
  ]
  report('S10-D1', 'CONTRACT §6 检索行内可信标记三档正确（双源/仅单源/未收录/无DOI）',
    a.every(([, ok]) => ok), a.map(([l, ok]) => `${ok ? '✓' : '✗'}${l}`).join('；'),
    { tiers: cands.map((c, i) => ({ doi: c.doi, status: t(c).status, label: t(c).label, sources: t(c).sources })) })

  // (B) 同源证明：每源 ok 与"直接调 connectors 抓取器"逐源一致
  let sameSource = true
  const srcDetail = []
  for (const c of cands.slice(0, 3)) {
    const oa = await fetchOpenAlexByDoi({ net, doi: c.doi }).then(() => true).catch(() => false)
    const cr = await fetchCrossrefByDoi({ net, doi: c.doi }).then(() => true).catch(() => false)
    const trust = t(c)
    const oaOk = (trust.sources.find((s) => s.source === OPENALEX_SOURCE) || {}).ok === true
    const crOk = (trust.sources.find((s) => s.source === CROSSREF_SOURCE) || {}).ok === true
    const ok = oa === oaOk && cr === crOk
    sameSource = sameSource && ok
    srcDetail.push({ doi: c.doi, directFetch: { openalex: oa, crossref: cr }, trustSources: trust.sources.map((s) => ({ source: s.source, ok: s.ok })), match: ok })
  }
  report('S10-D2', 'CONTRACT §6 判定复用 connectors 同批抓取器（无第二套 HTTP/判定）',
    sameSource, sameSource ? '逐源 ok 标志与 connectors 抓取器完全一致' : '存在不一致', { detail: srcDetail })

  // (B2) 既有校验器 verifyDoiSource 同源：同一 DOI 经 connectors 成功解析 → verified
  // （证明 doiTrustFor 与文献插件既有校验走的是同一批 connectors 抓取器，而非第二套判定）
  const resolveDoi = (ref) => lookupRecordByDoi({ net, doi: ref, mailto: null })
  const v = await verifyDoiSource({ kind: 'doi', ref: DUAL }, { resolveDoi })
  report('S10-D3', 'CONTRACT §6 与文献插件既有校验（verifyDoiSource）同源：同一 DOI 经 connectors 解析成功→verified',
    v && v.status === 'verified', `verifyDoiSource(${DUAL}).status=${v && v.status}（resolvedBy=${v && v.resolvedBy || '—'}；与 doiTrustFor 复用同一批 connectors 抓取器）`,
    { status: v && v.status, resolvedBy: v && v.resolvedBy })

  // (C) 行内文本标记：formatCandidates 文本含信任列
  const text = formatCandidates([
    { doi: DUAL, title: 'Dual', score: 0.9, year: 2024, citations: 10, venue: 'J1', sources: ['openalex'], doiTrust: t(cands[0]) },
    { doi: SINGLE, title: 'Single', score: 0.8, year: 2023, citations: 3, venue: 'J2', sources: ['openalex'], doiTrust: t(cands[1]) },
    { doi: NONE, title: 'None', score: 0.7, year: 2022, citations: 1, venue: 'J3', sources: ['openalex'], doiTrust: t(cands[2]) },
    { title: 'NoDOI', score: 0.6, year: 2021, citations: 0, venue: 'J4', sources: ['openalex'], doiTrust: t(cands[3]) },
  ], { limit: 12 })
  const cOk = [
    text.includes(DOI_TRUST_LABELS.dual),
    text.includes(DOI_TRUST_LABELS.single),
    text.includes(DOI_TRUST_LABELS.none),
    text.includes(DOI_TRUST_LABELS['no-doi']),
  ]
  report('S10-D4', 'CONTRACT §6 候选列表文本含行内可信标记列（✓双源/⚠仅单源/✗未收录/—无DOI）',
    cOk.every(Boolean), cOk.map((ok, i) => `${ok ? '✓' : '✗'}[${['双源', '单源', '未收录', '无DOI'][i]}]`).join('；'),
    { snippet: text.split('\n').slice(0, 6).join(' | ').slice(0, 240) })

  // (D) 真实 /find 命令端到端：候选 ui 携带 doiTrust，trustNote 汇总
  const scopes = makeMemoryScopes()
  const ctx = makeFakeCtx({ scopes, net })
  const engine = createEngine(ctx, { scopes, secretsLoader: () => ({}) })
  const r = await engine.find('grid-forming inverter inertia support', {})
  const ui = r && r.ui
  const withTrust = ui && Array.isArray(ui.candidates) ? ui.candidates.filter((c) => c.doiTrust) : []
  const byDoi = (d) => withTrust.find((c) => String(c.doi || '').toLowerCase() === d.toLowerCase())
  const aStatus = byDoi(DUAL) && byDoi(DUAL).doiTrust.status
  const bStatus = byDoi(SINGLE) && byDoi(SINGLE).doiTrust.status
  const cStatus = byDoi(NONE) && byDoi(NONE).doiTrust.status
  const dOk = !!(ui && ui.trustNote && withTrust.length >= 3 &&
    aStatus === 'dual' && bStatus === 'single' && cStatus === 'none')
  report('S10-D5', 'CONTRACT §6 /find 端到端：候选 ui 携带 doiTrust 且三档按 DOI 正确（A双源/B单源/C未收录）',
    dOk, `候选带 trust=${withTrust.length}；A(${DUAL})=${aStatus} / B(${SINGLE})=${bStatus} / C(${NONE})=${cStatus}；trustNote=${(ui && ui.trustNote || '').slice(0, 48)}`,
    { trustNote: ui && ui.trustNote, uiCandidates: withTrust.map((c) => ({ doi: c.doi, status: c.doiTrust && c.doiTrust.status })) })

  const out = {
    label: 's10-doi-trust',
    ts: new Date().toISOString(),
    verdict: items.every((i) => i.ok) ? 'accept' : 'reject',
    preState: { stubNet: '桩 net 复现四态（A双源/B单源/C未收录/D无DOI）； connectors 同批抓取器即判定源' },
    rerun: 'node tools/run-isolated.mjs --label s10 --cmd "node tools/accept-s10-doi.mjs"',
    independence: { data: '桩 net 复现四态；trust 复用 connectors 抓取器（与 verifyDoiSource 同源）；未另写判定逻辑', sameSource: true, selfReported: [] },
    items,
    artifacts: [
      { path: 'packages/plugins/research-literature/lib/doi-trust.mjs', sha256: sha(join(PROJECT_ROOT, 'packages/plugins/research-literature/lib/doi-trust.mjs')) },
      { path: 'packages/plugins/research-literature/index.mjs', sha256: sha(join(PROJECT_ROOT, 'packages/plugins/research-literature/index.mjs')) },
      { path: 'packages/packs/research/ui/literature.js', sha256: sha(join(PROJECT_ROOT, 'packages/packs/research/ui/literature.js')) },
      { path: 'tools/accept-s10-doi.mjs', sha256: sha(join(PROJECT_ROOT, 'tools/accept-s10-doi.mjs')) },
    ],
  }
  const payload = JSON.stringify(out, null, 2)
  writeFileSync(logPath('s10-doi-evidence.json'), payload)
  const runRoot = process.env.ORB_RUN_ROOT
  if (runRoot) { try { writeFileSync(join(runRoot, 's10-doi-evidence.json'), payload) } catch { /* noop */ } }
  console.log(`S10 镜2-DOI可信标记：${items.filter((i) => i.ok).length}/${items.length} → ${out.verdict}`)
  console.log(`证据：${logPath('s10-doi-evidence.json')}`)
  process.exit(out.verdict === 'accept' ? 0 : 1)
}

main().catch((e) => { console.error('S10 DOI 验收异常:', e); process.exit(2) })
