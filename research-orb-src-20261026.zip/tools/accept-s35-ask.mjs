// tools/accept-s35-ask.mjs —— S35·A1 /coach ask 手动问询验收（≥8 项）。
// 单行复跑：node tools\accept-s35-ask.mjs
// 证据：data\logs\s35-ask-accept.json
import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

// S35 验收隔离：先设 ORB_LOG_DIR/ORB_DATA_DIR 再动态 import（safefs 在 import 时定格目录）
process.env.ORB_LOG_DIR = join(tmpdir(), 's35-ask-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's35-ask-data-' + Date.now())
const { PROJECT_ROOT, dataPath } = await import('../packages/core/src/safefs.mjs')
const { createConfusionCoach, ASK_COOLDOWN_MS_DEFAULT } = await import('../packages/plugins/coach/confusion.mjs')
const AUDIT_DIR = process.env.ORB_LOG_DIR

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

// 桩：router（旗舰问询）+ extractor（截屏抽取）+ consent 开关 + 轨迹文件
function mkTmp(prefix) { const d = join(dataPath('tmp'), prefix + '-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6)); mkdirSync(d, { recursive: true }); return d }
function makeCoach({ now, cooldownMs, trajectoryRows = [], extractorFail = false } = {}) {
  const dir = mkTmp('s35-ask')
  const traj = join(dir, 'trajectory.jsonl')
  if (trajectoryRows.length) writeFileSync(traj, trajectoryRows.map((r) => JSON.stringify(r)).join('\n') + '\n', 'utf8')
  const audits = []
  const router = { run: async (tier, p) => ({ ok: true, text: '观察到：' + String(JSON.stringify(p.messages[1].content)).slice(0, 40) + '…… 你卡在哪一步？', providerId: 'stub', model: 'stub' }) }
  const extractor = { extract: async () => { if (extractorFail) throw Object.assign(new Error('stub extract down'), { code: 'E_EXTRACT' }); return { text: '屏幕上显示：微电网仿真模型报错', frameId: 'f-' + Math.random().toString(36).slice(2, 6), source: 'qwen', textSha256: 'sha-' + Math.random().toString(36).slice(2, 8) } } }
  const coach = createConfusionCoach({ dir, router, extractor, trajectoryFile: traj, now: now || (() => Date.now()), ...(cooldownMs ? { cooldownMs } : {}), onAsk: async (info) => { audits.push({ kind: 'onAsk', ...info }) } })
  return { coach, dir, traj, audits }
}
const auditRows = () => {
  const f = join(AUDIT_DIR, 'coach.jsonl')
  try { return readFileSync(f, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)) } catch { return [] }
}

let clock = Date.now()
const now = () => clock
const DAY = 24 * 60 * 60 * 1000

try {
  // 1) 手动成功：consent 开 → 问询卡生成 + 审计 coach-ask
  const c1 = makeCoach({ now })
  const r1 = await c1.coach.ask({ imagePath: 'x.png', trigger: 'manual', consentActive: true })
  const a1 = auditRows().find((r) => r.kind === 'coach-ask' && r.trigger === 'manual')
  check('A1-1 手动成功+审计', r1.ok === true && typeof r1.question === 'string' && r1.question.length > 5 && !!a1 && a1.trigger === 'manual',
    `question=${r1.question && r1.question.slice(0, 24)}… audit=${!!a1}`, {})

  // 2/3) 冷却抑制 + 剩余分钟 + ask-cooldown 审计
  const r2 = await c1.coach.ask({ imagePath: 'x.png', trigger: 'manual', consentActive: true })
  const a2 = auditRows().filter((r) => r.kind === 'ask-cooldown').pop()
  check('A1-2 冷却抑制', r2.ok === false && r2.cooledDown === true, `reason=${r2.reason}`, {})
  check('A1-3 剩余分钟+审计', /剩余 \d+ 分钟/.test(r2.reason || '') && !!a2 && Number.isFinite(a2.remainingMin) && a2.remainingMin > 0 && a2.remainingMin <= 24 * 60,
    `reason=${r2.reason} audit.remainingMin=${a2 && a2.remainingMin}`, {})
  check('A1-4 共用冷却 24h 默认', ASK_COOLDOWN_MS_DEFAULT === 24 * 60 * 60 * 1000, `ASK_COOLDOWN_MS_DEFAULT=${ASK_COOLDOWN_MS_DEFAULT}`, {})

  // 4) 未同意拒绝 + 审计 skipped-no-consent{why:'coach-ask'}
  const c4 = makeCoach({ now })
  const r4 = await c4.coach.ask({ imagePath: 'x.png', trigger: 'manual', consentActive: false })
  const a4 = auditRows().find((r) => r.kind === 'skipped-no-consent' && r.why === 'coach-ask')
  check('A1-5 未同意拒绝+审计', r4.ok === false && r4.skipped === true && /同意/.test(r4.reason || '') && !!a4,
    `skipped=${r4.skipped} reason=${(r4.reason || '').slice(0, 30)} audit=${!!a4}`, {})

  // 5) 上下文含轨迹：轨迹 3 条 → 审计 recentTrajectory=3
  const rows = [1, 2, 3].map((i) => ({ ts: new Date(clock - i * 60000).toISOString(), window: `win${i}`, process: `proc${i}`, intent: `意图${i}`, level: 'direct', evidence: { frameId: 'f' + i, textSha256: 's' + i } }))
  const c5 = makeCoach({ now, trajectoryRows: rows })
  const r5 = await c5.coach.ask({ imagePath: 'x.png', trigger: 'manual', consentActive: true })
  const a5 = auditRows().filter((r) => r.kind === 'coach-ask').pop()
  check('A1-6 上下文含轨迹', r5.ok === true && a5 && a5.recentTrajectory === 3, `recentTrajectory=${a5 && a5.recentTrajectory}`, {})

  // 6) 无轨迹降级仍可问：空轨迹 → 仍成功（degraded 或 recent=0 均可，不崩）
  const c6 = makeCoach({ now, trajectoryRows: [], extractorFail: true })
  const r6 = await c6.coach.ask({ imagePath: 'x.png', trigger: 'manual', consentActive: true })
  const a6 = auditRows().filter((r) => r.kind === 'coach-ask').pop()
  check('A1-7 无轨迹/抽取失败降级仍可问', r6.ok === true && typeof r6.question === 'string' && r6.question.length > 5 && a6 && a6.degraded === true,
    `ok=${r6.ok} degraded=${a6 && a6.degraded}`, {})

  // 7) 与自动问询共用冷却键：手动后，auto-dwell 触发同样被冷却
  const c7 = makeCoach({ now })
  await c7.coach.ask({ imagePath: 'x.png', trigger: 'manual', consentActive: true })
  const r7 = await c7.coach.ask({ imagePath: 'x.png', trigger: 'auto-dwell', consentActive: true })
  check('A1-8 与自动问询共用冷却键', r7.ok === false && r7.cooledDown === true, `autoTrigger cooledDown=${r7.cooledDown}`, {})

  // 8) 冷却可配：注入 100ms 冷却 → 推进时钟后可再问
  clock = Date.now()
  const c8 = makeCoach({ now, cooldownMs: 100 })
  await c8.coach.ask({ imagePath: 'x.png', trigger: 'manual', consentActive: true })
  clock += 150
  const r8 = await c8.coach.ask({ imagePath: 'x.png', trigger: 'manual', consentActive: true })
  check('A1-9 冷却可配', r8.ok === true, `cooldownMs=100 推进 150ms 后再问 ok=${r8.ok}`, {})

  // 9) 手动入口与 idle-dwell 同路径：/coach ask（index.mjs manualAsk）复用 confusion.ask（静态断言接线）
  const idx = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'index.mjs'), 'utf8')
  const wired = /manualAsk/.test(idx) && /confusion\.ask/.test(idx) && /skipped-no-consent', why: 'coach-ask'/.test(idx)
  check('A1-10 /coach ask 命令接线（同一 confusion.ask 路径）', wired, `index.mjs manualAsk+confusion.ask+consent 审计=${wired}`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

try { rmSync(process.env.ORB_LOG_DIR, { recursive: true, force: true }); rmSync(process.env.ORB_DATA_DIR, { recursive: true, force: true }) } catch { /* 尽力 */ }
const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's35-ask-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s35-ask: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
