// tools/probe-lit-1-find.js
//
// 面板取证脚本 ①：展开面板 → 触发 /find → 等候选列表渲染出来。
//
// 由 tools/shot.mjs --script 注入 renderer，**已被包在 `(async function(){ ... })()` 里**，
// 所以这里写的是"函数体"：直接用 await 与 return，不要再自己套一层 IIFE
// （套了就不是被 await 的，返回值会丢）。
//
// 走 plugin:command 上行动作而不是往输入框塞文字再回车：面板按钮走的就是这条路径，
// 用它取证才等于验证「UI 真能驱动插件」。
const api = globalThis.researchOrb
// 注意：preload 的 send 动作名是白名单（ui / window / drag）。
// 面板内部那些 send('plugin:command', ...) 是 ui-bridge 自己的包装函数，
// 直接调 api.send 时必须显式写成 api.send('ui', { type: 'plugin:command', ... })。
const send = (type, detail) => api.send('ui', Object.assign({ type: type, at: Date.now() }, detail || {}))
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const lit = () => document.getElementById('ro-lit')

api.send('window', { action: 'expand' })
await sleep(500)
send('plugin:command', { name: 'find', args: 'grid-forming inverter inertia support' })

let rows = 0
for (let i = 0; i < 90; i += 1) {
  await sleep(400)
  const node = lit()
  rows = node ? node.querySelectorAll('.ro-cand').length : 0
  if (node && node.classList.contains('ro-open') && rows > 0) break
}
await sleep(700)
const node = lit()
const title = node && node.querySelector('.ro-cand-title')
const meta = node && node.querySelector('.ro-cand-meta')
return {
  litOpen: !!(node && node.classList.contains('ro-open')),
  candidateRows: rows,
  firstTitle: title ? title.textContent.slice(0, 70) : null,
  firstMeta: meta ? meta.textContent.slice(0, 120) : null,
  hasSearchBox: !!(node && node.querySelector('.ro-idxinput')),
  checkboxCount: node ? node.querySelectorAll('#ro-lit input[type=checkbox]').length : 0,
  buttons: node ? [...node.querySelectorAll('button')].map((b) => b.textContent).slice(0, 12) : [],
}
