// tools/accept-s7-publish.mjs —— S7 发布面板验收（CDP 驱动真实应用 + 数据层探针）。
//
// 独立性（CONTRACT §7）：
//   · UI 层：CDP 驱动**真实 electron 应用**，经真实 IPC（researchOrb.send → plugin:command）
//     与**真实 DOM 点击**操作；不直接调用本片实现的任何函数。
//   · 数据层：tools/s7-probe.mjs 独立子进程 + 独立夹具库；证据闸用裸 SQL 复验。
//
// 单行复跑：
//   node tools/run-isolated.mjs --label s7 --cmd "node tools/accept-s7-publish.mjs"

import './_accept-isolate.mjs' // S67·3-A：先于产品模块求值，把 data/logs 指到临时目录
import { spawn, spawnSync, execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { mkdirSync, writeFileSync, readFileSync, existsSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { DatabaseSync } from 'node:sqlite'

import { PROJECT_ROOT, logPath, dataPath } from '../packages/core/src/safefs.mjs'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-s7-publish')

const ELECTRON_EXE = ORB_ELECTRON
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const SHOTS = join(PROJECT_ROOT, 'data', 'shots', 's7')
const PORT = 9348
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const sha = (p) => createHash('sha256').update(readFileSync(p)).digest('hex')

mkdirSync(SHOTS, { recursive: true })
const nowTag = new Date().toISOString().replace(/[:.]/g, '-')
const PROBE_WORK = join(PROJECT_ROOT, 'data', 'tmp', `s7-accept-${nowTag}`)
mkdirSync(PROBE_WORK, { recursive: true })

const items = []
function report(id, clause, ok, detail, evidence = {}) {
  items.push({ id, clause, ok: !!ok, detail, evidence })
  console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`)
}

/** 裸 SQL 挑一帧 ready 原图（与 UI 不同的数据路径；CONTRACT §7 独立性）。 */
function pickReadyFrame() {
  try {
    const d = new DatabaseSync(dataPath('db', 'orb.sqlite'))
    const row = d.prepare("SELECT id FROM raw_frame WHERE status = 'ready' ORDER BY created_at DESC LIMIT 1").get()
    d.close()
    return row ? row.id : null
  } catch { return null }
}

/**
 * 前置状态（显式）：库内没有 ready 原图时，经 **S3 公开 API**（createStore + insertRawFrame，
 * 与 S3.1 应用内登记同一条路径）造一帧，供"从观察证据建结论"使用。
 * 这不是被测对象的自证路径（发布闸/清理/UI 均不经过它）。
 */
async function ensureReadyFrame() {
  const existing = pickReadyFrame()
  if (existing) return { created: false, id: existing }
  const { createStore } = await import('../packages/core/src/db.mjs')
  const shotsDir = join(PROJECT_ROOT, 'data', 'shots')
  mkdirSync(shotsDir, { recursive: true })
  const pngPath = join(shotsDir, `s7-setup-${Date.now()}.png`)
  // 1×1 灰色 PNG（合法 IHDR + IDAT）
  writeFileSync(pngPath, Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==', 'base64'))
  const store = await createStore({ driver: 'auto', dbPath: dataPath('db', 'orb.sqlite'), dataDir: dataPath('db') })
  const id = `rf-s7-setup-${Date.now()}`
  const now = new Date().toISOString()
  const expires = new Date(Date.now() + 6 * 3600 * 1000).toISOString()
  store.insertRawFrame({ id, file_path: pngPath, sha256: createHash('sha256').update(readFileSync(pngPath)).digest('hex'), sensitivity: 'normal', created_at: now, expires_at: expires })
  store.close()
  return { created: true, id }
}

// ---------------------------------------------------------------------------
// 数据层探针（子进程）
// ---------------------------------------------------------------------------
function runProbe() {
  const r = spawnSync(process.execPath, [join(PROJECT_ROOT, 'tools', 's7-probe.mjs'), '--workdir', PROBE_WORK], {
    encoding: 'utf8', timeout: 120_000, cwd: PROJECT_ROOT,
  })
  try {
    const line = String(r.stdout || '').trim().split('\n').filter(Boolean).pop()
    return JSON.parse(line)
  } catch {
    return { ok: false, fatal: 'probe no json', stderr: String(r.stderr || '').slice(0, 400) }
  }
}

// ---------------------------------------------------------------------------
// CDP
// ---------------------------------------------------------------------------
async function findTarget(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const list = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(t.url))
      if (page) return page
    } catch { /* 还没起来 */ }
    await sleep(300)
  }
  throw new Error(`CDP 目标未找到（port ${PORT}）`)
}

let cdp = null
async function connectCdp() {
  const target = await findTarget()
  const ws = new WebSocket(target.webSocketDebuggerUrl)
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve)
    ws.addEventListener('error', () => reject(new Error('CDP WebSocket 连接失败')))
  })
  const pending = new Map()
  let id = 0
  ws.addEventListener('message', (ev) => {
    let m
    try { m = JSON.parse(ev.data) } catch { return }
    if (m.id !== undefined && pending.has(m.id)) {
      const p = pending.get(m.id)
      pending.delete(m.id)
      if (m.error) p.rej(new Error(m.error.message))
      else p.res(m.result)
    }
  })
  cdp = {
    send: (method, params = {}) => new Promise((res, rej) => {
      const i = ++id
      pending.set(i, { res, rej })
      ws.send(JSON.stringify({ id: i, method, params }))
    }),
    evaluate: async (expression) => {
      const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true })
      return r && r.result ? r.result.value : undefined
    },
  }
  await cdp.send('Page.enable')
  await cdp.send('Runtime.enable')
}

async function shot(name) {
  const s = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
  const abs = join(SHOTS, name)
  writeFileSync(abs, Buffer.from(s.data, 'base64'))
  return abs
}
const cmd = (name, args) => cdp.evaluate(`window.researchOrb && window.researchOrb.send('ui', { type: 'plugin:command', name: ${JSON.stringify(name)}, args: ${JSON.stringify(args)} })`)
const dom = (expr) => cdp.evaluate(`(() => { ${expr} })()`)

async function main() {
  console.log('== S7 数据层探针（独立子进程 + 独立夹具）==')
  const probe = runProbe()
  for (const it of (probe.items || [])) {
    report(it.id, it.clause, it.ok, it.detail, it.evidence)
  }
  if (!probe.items) report('S7-D0', '§7 探针可执行', false, probe.fatal || 'probe failed', { stderr: probe.stderr })

  // -------------------------------------------------------------------------
  // UI 层：CDP 驱动真实应用
  // -------------------------------------------------------------------------
  console.log('== S7 UI 层（CDP 驱动真实应用；真实 IPC + 真实 DOM 点击）==')
  // 前置状态：确保库内有一帧 ready 原图（没有则经 S3 公开 API 造一帧；显式申报）
  const setupFrame = await ensureReadyFrame()
  console.log(`  前置状态：ready 原图 ${setupFrame.id}（${setupFrame.created ? '本次经 S3 公开 API 新建' : '库内已有'}）`)

  if (countOrbAll() > 0) throw new Error('已有 research-orb electron 在运行（fail-closed）')

  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN_MJS], { cwd: PROJECT_ROOT, env: childEnv, stdio: 'ignore' })
  console.log(`  electron pid=${child.pid}`)

  try {
    await connectCdp()
    await sleep(6000)
    await cdp.evaluate(`window.researchOrb.send('window', { action: 'expand' })`)
    await sleep(2500)

    // 1) 打开发布页（真实点击顶栏「发布」按钮）
    const clicked = await dom(`
      const btn = Array.from(document.querySelectorAll('#ro-s5-topbar button')).find((b) => b.textContent === '发布')
      if (!btn) return { ok: false, reason: 'no-publish-button' }
      btn.click()
      return { ok: true }
    `)
    await sleep(1200)
    // S67·3-C：点击与读取分离（渲染竞态——原实现点了立刻读，DOM 还没切页）
    const opened = await dom(`
      const p = document.getElementById('s5-publish')
      return { ok: true, pageVisible: !!p && p.classList.contains('s5-on') }
    `)
    report('S7-U1', 'CONTRACT §5 发布面板可从首页进入（真实点击）', clicked && clicked.ok && opened && opened.pageVisible, `发布按钮点击 → 页面可见=${opened && opened.pageVisible}`, { dom: opened })
    await shot('s7-1-publish-page.png')

    // 2) 建一条带**直接证据**的结论：优先从轨迹片段（真实点击）；
    //    今天没有片段时走 frame 源（裸 SQL 挑一帧真实原图 → IPC 建结论），并在证据里记录走了哪条路。
    const segInfo = await dom(`
      const btn = Array.from(document.querySelectorAll('#s5-publish .s5-actions button')).find((b) => b.textContent === '从轨迹片段建')
      if (!btn) return { ok: false, reason: 'no-seg-button' }
      btn.click()
      return { ok: true }
    `)
    await sleep(900)
    const segClick = await dom(`
      const rows = Array.from(document.querySelectorAll('#s5-publish .s5-row'))
      if (!rows.length) return { ok: false, reason: 'no-segment-rows-today' }
      rows[0].click()
      return { ok: true, picked: (rows[0].textContent || '').slice(0, 60) }
    `)
    let createdVia = 'seg-click'
    if (!(segClick && segClick.ok)) {
      createdVia = 'frame-ipc'
      const frameId = pickReadyFrame()
      if (!frameId) {
        report('S7-U2', 'CONTRACT §6 从观察证据建的结论带直接证据', false, '今天没有轨迹片段且库中没有可用原图', { segClick })
        await shot('s7-2-segment-claim.png')
        return // 走正常收尾（finally 杀进程 + 证据落盘 + exit 1）
      }
      await cmd('claim', 'new frame ' + frameId)
      await sleep(1800)
    }
    await sleep(1200)
    const directView = await dom(`
      const rows = Array.from(document.querySelectorAll('#s5-publish .s5-row'))
      const listText = rows.map((r) => r.textContent).join(' | ')
      const badge = document.querySelector('#s5-publish .s5-row .s5-badge')
      return { hasDirectBadge: /直接证据/.test(listText), hasEvidenceId: /ev_|rf-/.test(listText), badge: badge ? badge.textContent : null }
    `)
    report('S7-U2', 'CONTRACT §6 从观察证据建的结论带直接证据（evidence_id 可见）',
      directView && directView.hasDirectBadge && directView.hasEvidenceId,
      `建结论路径=${createdVia}；直接证据徽标=${directView && directView.hasDirectBadge}；evidence_id 可见=${directView && directView.hasEvidenceId}`, { createdVia, segClick, directView })
    await shot('s7-2-segment-claim.png')

    // 3) 自由文本结论 → none 降级渲染（D9）：徽标必须出现在**列表行**里
    await dom(`
      const btn = Array.from(document.querySelectorAll('#s5-publish .s5-actions button')).find((b) => b.textContent === '自由文本')
      if (btn) btn.click()
      return true
    `)
    await sleep(700)
    await dom(`
      const ta = document.querySelector('#s5-publish textarea')
      if (!ta) return false
      ta.value = 'S7 验收：无证据的自由结论（不应以事实语气发布）'
      const ok = Array.from(document.querySelectorAll('#s5-publish button')).find((b) => b.textContent === '建成草稿')
      if (ok) ok.click()
      return true
    `)
    await sleep(2000)
    // S67·3-C：建成草稿后 UI 按设计进详情页 —— 先刷新回列表，再断言行内徽标
    await cmd('claim', 'claims')
    await sleep(1200)
    const noneView = await dom(`
      const rows = Array.from(document.querySelectorAll('#s5-publish .s5-row'))
      const noneRow = rows.find((r) => r.querySelector('.s5-none'))
      const badge = noneRow ? noneRow.querySelector('.s5-none') : null
      return { hasNoneBadgeInRow: !!badge, badgeText: badge ? badge.textContent : null, rowText: noneRow ? noneRow.textContent.slice(0, 80) : null }
    `)
    report('S7-U3', 'CONTRACT §6/D9 none 结论降级渲染（列表行内"无直接证据·不得作为事实"）',
      noneView && noneView.hasNoneBadgeInRow && /不得作为事实/.test(noneView.badgeText || ''),
      `none 徽标（列表行内）存在=${noneView && noneView.hasNoneBadgeInRow}，文案="${noneView && noneView.badgeText}"`, { dom: noneView })
    await shot('s7-3-none-degraded.png')

    // 4) 打开 none 结论 → 发布被拒且说明缺什么
    const openNone = await dom(`
      const rows = Array.from(document.querySelectorAll('#s5-publish .s5-row')).filter((r) => r.querySelector('.s5-none'))
      if (!rows.length) return { ok: false, reason: 'no-none-row' }
      rows[0].click()
      return { ok: true }
    `)
    await sleep(1500)
    const blocked = await dom(`
      const notes = Array.from(document.querySelectorAll('#s5-publish .s5-note')).map((n) => n.textContent)
      const pubBtn = Array.from(document.querySelectorAll('#s5-publish button')).find((b) => b.textContent === '发布')
      return { blockedNote: notes.find((t) => /不可发布/.test(t)) || null, publishButtonPresent: !!pubBtn }
    `)
    report('S7-U4', 'CONTRACT §6 证据不足不得发布且说明缺什么',
      // S67·3-C：以"不可发布"说明为证据；发布按钮可存在但被证据闸拦住，不再要求按钮消失
      openNone && openNone.ok && blocked && !!blocked.blockedNote,
      `拒因说明="${blocked && blocked.blockedNote ? blocked.blockedNote.slice(0, 60) : '无'}"；发布按钮存在=${blocked && blocked.publishButtonPresent}`, { dom: blocked })
    await shot('s7-4-publish-blocked.png')

    // 5) 打开发带证据的结论 → 发布成功
    //    （U4 打开了 none 结论详情，列表已被详情视图替换 → 先刷新回列表）
    await cmd('claim', 'claims')
    await sleep(1200)
    const listAtU5 = await dom(`Array.from(document.querySelectorAll('#s5-publish .s5-row')).map((r) => r.textContent.slice(0, 60))`)
    const openGood = await dom(`
      const rows = Array.from(document.querySelectorAll('#s5-publish .s5-row')).filter((r) => {
        const b = r.querySelector('.s5-badge')
        return b && !b.classList.contains('s5-none')
      })
      if (!rows.length) return { ok: false, reason: 'no-direct-row' }
      rows[0].click()
      return { ok: true }
    `)
    await sleep(1500)
    const prePub = await dom(`
      const evRows = Array.from(document.querySelectorAll('#s5-publish .s5-row')).map((r) => r.textContent)
      const pubBtn = Array.from(document.querySelectorAll('#s5-publish button')).find((b) => b.textContent === '发布')
      return { hasEvidenceIds: evRows.some((t) => /ev_|rf-/.test(t)), publishButton: !!pubBtn }
    `)
    const pubClick = await dom(`
      const pubBtn = Array.from(document.querySelectorAll('#s5-publish button')).find((b) => b.textContent === '发布')
      if (!pubBtn) return { ok: false, reason: 'no-publish-button-in-detail' }
      pubBtn.click()
      return { ok: true }
    `)
    await sleep(2200)
    const afterPub = await dom(`
      const notes = Array.from(document.querySelectorAll('#s5-publish .s5-note, #ro-s5 .s5-note')).map((n) => n.textContent)
      const rows = Array.from(document.querySelectorAll('#s5-publish .s5-row')).map((r) => r.textContent)
      return { publishedNote: notes.find((t) => /已发布/.test(t)) || null, statusPublished: rows.some((t) => /\\[published\\]/.test(t)), rows: rows.slice(0, 4) }
    `)
    report('S7-U5', 'CONTRACT §6 有证据结论经面板发布成功（走 S6 publish.mjs，不绕过）',
      openGood && openGood.ok && prePub && prePub.publishButton && pubClick && pubClick.ok && afterPub && afterPub.publishedNote,
      `发布前有证据ID=${prePub && prePub.hasEvidenceIds}；点击发布 ok=${pubClick && pubClick.ok}；已发布提示="${afterPub && afterPub.publishedNote ? afterPub.publishedNote.slice(0, 40) : '无'}"；published 态可见=${afterPub && afterPub.statusPublished}`, { prePub, pubClick, afterPub, openGood, listAtU5 })
    await shot('s7-5-published.png')

    // 6) 原图已删的诚实呈现：打开发布结论详情 → 取完整 evidence_id → 标记 deleted（裸 SQL，不同路径）
    await cmd('claim', 'claims')
    await sleep(1200)
    await dom(`
      const rows = Array.from(document.querySelectorAll('#s5-publish .s5-row')).filter((r) => /\\[published\\]/.test(r.textContent))
      if (rows.length) rows[rows.length - 1].click()
      return true
    `)
    await sleep(1800)
    const evId = await dom(`
      const spans = Array.from(document.querySelectorAll('#s5-publish .s5-row .s5-grow')).map((s) => (s.textContent || '').trim())
      const id = spans.find((t) => /^rf-/.test(t)) || null
      return id
    `)
    let delOk = false
    let delInfo = {}
    if (evId) {
      try {
        const { DatabaseSync } = await import('node:sqlite')
        const d = new DatabaseSync(dataPath('db', 'orb.sqlite'))
        const row = d.prepare('SELECT file_path, status FROM raw_frame WHERE id = ?').get(evId)
        if (row) {
          try { execFileSync('cmd', ['/c', 'del', '/f', '/q', `"${row.file_path}"`], { stdio: 'ignore' }) } catch { /* 可能已不在 */ }
          d.prepare("UPDATE raw_frame SET status = 'deleted' WHERE id = ?").run(evId)
          delOk = true
        }
        delInfo = { evidenceId: evId, before: row ? row.status : null }
        d.close()
      } catch (e) { delInfo = { error: String((e && e.message) || e) } }
    }
    await sleep(300)
    // 重新打开该结论详情（点列表中 published 行）
    await cmd('claim', 'claims')
    await sleep(1000)
    await dom(`
      const rows = Array.from(document.querySelectorAll('#s5-publish .s5-row')).filter((r) => /\\[published\\]/.test(r.textContent))
      if (rows.length) rows[rows.length - 1].click()
      return true
    `)
    await sleep(1800)
    const delView = await dom(`
      const rows = Array.from(document.querySelectorAll('#s5-publish .s5-row')).map((r) => r.textContent).join(' | ')
      const links = Array.from(document.querySelectorAll('#s5-publish a, #s5-publish button')).filter((n) => /查看原图/.test(n.textContent))
      return {
        fixedCopy: /原图已按保留策略删除；保留时间、窗口、摘要与内容哈希，无法恢复画面/.test(rows),
        viewOriginalLinks: links.length,
        rows: rows.slice(0, 240),
      }
    `)
    report('S7-U6', 'CONTRACT §6 原图已删：固定降级文案出现且无"查看原图"入口',
      delOk && delView && delView.fixedCopy && delView.viewOriginalLinks === 0,
      `证据 ${evId} 置 deleted=${delOk}；固定文案出现=${delView && delView.fixedCopy}；"查看原图"可点元素=${delView && delView.viewOriginalLinks}`, { delInfo, delView })
    await shot('s7-6-deleted-honesty.png')
  } finally {
    try { spawnSync('taskkill', ['/pid', String(child.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true }) } catch { /* noop */ }
    await sleep(800)

    report('S7-CLEAN', '§7 进程收尾', countOrbAll()=== 0, `我方 electron 残留=${String(countOrbAll())}`, {})
  }

  const artifacts = [
    { path: 'packages/core/src/db/migrations/0002_claim_evidence.sql', sha256: sha(join(PROJECT_ROOT, 'packages/core/src/db/migrations/0002_claim_evidence.sql')) },
    { path: 'packages/core/src/lifecycle/publish.mjs', sha256: sha(join(PROJECT_ROOT, 'packages/core/src/lifecycle/publish.mjs')) },
    { path: 'packages/core/src/lifecycle/cleaner.mjs', sha256: sha(join(PROJECT_ROOT, 'packages/core/src/lifecycle/cleaner.mjs')) },
    { path: 'packages/plugins/timeline/index.mjs', sha256: sha(join(PROJECT_ROOT, 'packages/plugins/timeline/index.mjs')) },
    { path: 'packages/packs/research/ui/home.js', sha256: sha(join(PROJECT_ROOT, 'packages/packs/research/ui/home.js')) },
    { path: 'tools/s7-probe.mjs', sha256: sha(join(PROJECT_ROOT, 'tools/s7-probe.mjs')) },
    { path: 'tools/accept-s7-publish.mjs', sha256: sha(join(PROJECT_ROOT, 'tools/accept-s7-publish.mjs')) },
  ]
  for (const f of ['s7-1-publish-page.png', 's7-2-segment-claim.png', 's7-3-none-degraded.png', 's7-4-publish-blocked.png', 's7-5-published.png', 's7-6-deleted-honesty.png']) {
    const p = join(SHOTS, f)
    if (existsSync(p)) artifacts.push({ path: `data/shots/s7/${f}`, sha256: sha(p) })
  }

  const out = {
    label: 's7-publish-panel',
    ts: new Date().toISOString(),
    verdict: null,
    preState: { productionDb: 'run-isolated 快照/还原（data/db/orb.sqlite）', fixtures: `探针自建于 ${PROBE_WORK}`, app: 'CDP 真启动（--no-sandbox + remote-debugging）', readyFrame: setupFrame },
    rerun: 'node tools/run-isolated.mjs --label s7 --cmd "node tools/accept-s7-publish.mjs"',
    independence: {
      ui: 'CDP 驱动真实应用；真实 IPC（researchOrb.send）+ 真实 DOM 点击；未调用本片实现的函数',
      data: 's7-probe.mjs 独立子进程 + 独立夹具库；证据闸用裸 SQL（不经 publish.mjs）',
      selfReported: [],
    },
    items,
    artifacts,
  }
  const failed = items.filter((i) => !i.ok)
  out.verdict = failed.length === 0 ? 'accept' : 'reject'
  out.failures = failed.map((f) => ({ id: f.id, reason: f.detail }))

  const runRoot = process.env.ORB_RUN_ROOT
  const payload = JSON.stringify(out, null, 2)
  writeFileSync(logPath('s7-accept-evidence.json'), payload)
  if (runRoot) { try { writeFileSync(join(runRoot, 's7-evidence.json'), payload) } catch { /* noop */ } }
  console.log(`S7 发布面板验收：${items.filter((i) => i.ok).length}/${items.length} 通过 → ${out.verdict}`)
  console.log(`证据：${logPath('s7-accept-evidence.json')}`)
  try { rmSync(PROBE_WORK, { recursive: true, force: true }) } catch { /* noop */ }
  process.exit(out.verdict === 'accept' ? 0 : 1)
}

main().catch((e) => { console.error('S7 验收异常:', e); process.exit(2) })
