// tools/accept-s20-profile.mjs
// S20·A 验收：问卷→落盘→digest(≤300 token)→/profile show→reset；
// 并证明 未填画像不注入 / 关掉个性化后 prompt 不含 / profile.json 无身份字段。
import {
  activate, writeProfile, readProfile, resetProfile, buildDigest, estimateTokens, demoFields,
} from '../packages/plugins/profile/index.mjs'
import { readProfileSystemContext, composeSystemPrompt } from '../packages/core/src/profile-context.mjs'

let pass = 0
let fail = 0
function check(name, cond, extra = '') {
  if (cond) { pass++; console.log('  [PASS]', name) }
  else { fail++; console.log('  [FAIL]', name, extra) }
}

const IDENTITY_KEYS = ['name', 'studentid', 'school', 'affiliation', 'email', 'phone', 'id', 'realname', '姓名', '学号', '单位', '邮箱']
const DEF = '【默认 system 提示】你是科研助手。'

async function main() {
  // 1) 问卷→落盘（含自定义值）
  const prof = writeProfile({
    fields: { major: '计算机科学', direction: '信息检索', stage: '硕士', goal: '写基金本子' },
    localPerception: '关', personalization: true, source: 'questionnaire',
  })
  check('问卷落盘 profile.json', !!readProfile() && readProfile().fields.major === '计算机科学')

  // 2) digest ≤300 token
  const d = buildDigest(prof)
  check('digest ≤300 token', estimateTokens(d) <= 300, 'tokens=' + estimateTokens(d))
  check('digest 含专业维度', d.includes('计算机科学'))

  // 3) 命令路径：activate + run show
  let captured = null
  const fakeCtx = { log: console, ui: { registerCard() {}, registerCommand(c) { captured = c } } }
  await activate(fakeCtx)
  check('注册 /profile 命令', !!captured && captured.name === 'profile')
  const showRes = await captured.run('show')
  check('/profile show 返回画像', showRes.ok && /专业/.test(showRes.ui.message))

  // 4) 未填画像不注入
  resetProfile()
  check('未填画像→不注入', readProfileSystemContext() === '')
  check('未填画像 composeSystemPrompt 仅默认', composeSystemPrompt(DEF, readProfileSystemContext()) === DEF)

  // 5) 关掉个性化后 prompt 不含
  writeProfile({ fields: demoFields(), personalization: false })
  check('个性化关→不注入', readProfileSystemContext() === '')
  check('个性化关 composeSystemPrompt 仅默认', composeSystemPrompt(DEF, readProfileSystemContext()) === DEF)

  // 6) 开启个性化→注入
  writeProfile({ fields: demoFields(), personalization: true })
  const inj = readProfileSystemContext()
  check('个性化开→注入非空', inj.length > 0)
  check('注入含专业演示值', inj.includes('计算机科学'))

  // 7) profile.json 无身份字段
  const pj = readProfile()
  check('profile.json 无身份字段', !IDENTITY_KEYS.some((k) => k in (pj.fields || {})))

  // 8) /profile reset 清空
  const r = await captured.run('reset')
  check('/profile reset 清空', r.ok && !readProfile() && readProfileSystemContext() === '')

  // 收尾：不留持久状态
  resetProfile()
  console.log(`# accept-s20-profile: total=${pass + fail} pass=${pass} fail=${fail}`)
  process.exit(fail ? 1 : 0)
}

main().catch((e) => { console.error('FATAL', e); process.exit(1) })
