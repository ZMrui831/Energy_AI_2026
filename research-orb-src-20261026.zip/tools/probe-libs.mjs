// tools/probe-libs.mjs —— 阶段 2 依赖 API 精确签名探测（一次性，结果抄进 docs/DEPS.md 与代码注释）
//
// 只读探测：不写任何业务数据，只在 stdout 打结果。
// 用法：node tools/probe-libs.mjs

const out = {}

// ---- 1) @orama/orama ---------------------------------------------------------
{
  const mod = await import('@orama/orama')
  const names = Object.keys(mod).sort()
  out.orama = { exports: names.filter((n) => ['create', 'insert', 'insertMultiple', 'search', 'save', 'load', 'remove', 'count', 'update', 'getByID'].includes(n)) }
  const { create, insert, search, save, load, count, update, remove } = mod
  const schema = { id: 'string', title: 'string', tags: 'string', year: 'number', vector: 'vector[4]' }
  const db = create({ schema })
  await insert(db, { id: 'a', title: 'grid forming inverter inertia', tags: 'gfm grid', year: 2023, vector: [1, 0, 0, 0] })
  await insert(db, { id: 'b', title: 'microgrid islanding detection', tags: 'microgrid', year: 2021, vector: [0, 1, 0, 0] })
  out.orama.count = await count(db)
  const ft = await search(db, { term: 'inertia', mode: 'fulltext', limit: 5 })
  out.orama.fulltextHits = ft.hits.map((h) => h.document.id)
  const hy = await search(db, { term: 'inertia', mode: 'hybrid', vector: { value: [1, 0, 0, 0], property: 'vector' }, limit: 5 })
  out.orama.hybridHits = hy.hits.map((h) => h.document.id)
  out.orama.hitShape = Object.keys(hy.hits[0] || {})
  const raw = await save(db)
  out.orama.saveType = typeof raw
  out.orama.saveKeys = Object.keys(raw)
  out.orama.saveIsString = typeof raw === 'string'
  // load 的签名：load(raw) 还是 load(db, raw)
  try {
    const rawStr = JSON.stringify(raw)
    const restored = await load(JSON.parse(rawStr))
    out.orama.load1 = { ok: true, count: await count(restored), hits: (await search(restored, { term: 'inertia', limit: 5 })).hits.map((h) => h.document.id) }
  } catch (err) {
    out.orama.load1 = { ok: false, error: String(err && err.message) }
  }
  // update / remove
  try {
    await update(db, 'a', { year: 2024 })
    const g = await search(db, { term: 'grid', limit: 5 })
    out.orama.updateOk = g.hits.map((h) => `${h.document.id}:${h.document.year}`)
  } catch (err) {
    out.orama.updateOk = `ERR ${err && err.message}`
  }
  try {
    await remove(db, 'b')
    out.orama.afterRemove = await count(db)
  } catch (err) {
    out.orama.afterRemove = `ERR ${err && err.message}`
  }
}

// ---- 2) unpdf ---------------------------------------------------------------
{
  const { extractText, getDocumentProxy } = await import('unpdf')
  const { readFileSync } = await import('node:fs')
  const buf = readFileSync('data/fixtures/sample-paper.pdf')
  const pdf = await getDocumentProxy(new Uint8Array(buf))
  const r = await extractText(pdf, { mergePages: true })
  out.unpdf = { keys: Object.keys(r), totalPages: r.totalPages, textType: typeof r.text, chars: String(r.text).length }
}

// ---- 3) gray-matter ---------------------------------------------------------
{
  const gm = await import('gray-matter')
  const matter = gm.default || gm
  const doc = matter(['---', 'title: 测试', 'tags:', '  - a', '  - b', '读数: 4', '---', '', '正文'].join('\n'))
  out.grayMatter = { keys: Object.keys(doc), data: doc.data, content: doc.content }
  const str = matter.stringify('正文', { title: 'X', tags: ['p'] })
  out.grayMatter.stringifyHead = str.split('\n').slice(0, 5)
}

// ---- 4) citation-js ---------------------------------------------------------
{
  const core = await import('@citation-js/core')
  await import('@citation-js/plugin-bibtex')
  const Cite = core.Cite
  const cite = new Cite('@article{Doe2023Grid,\n  title={Grid-Forming Inverter Control for Inertia Support},\n  author={Doe, Jane and Roe, Richard},\n  journal={IEEE Transactions on Power Systems},\n  year={2023},\n  doi={10.1109/TPWRS.2023.1234567}\n}')
  const json = cite.get({ type: 'json' })
  out.citationJs = {
    count: json.length,
    title: json[0].title,
    doi: json[0].DOI,
    authorTypes: (json[0].author || []).map((a) => a.family || a.literal),
    roundTrip: cite.format('bibtex').slice(0, 120),
    canParseGarbage: (() => { try { return new Cite('not bibtex at all').get({ type: 'json' }).length } catch { return 'THREW' } })(),
  }
}

// ---- 5) node crypto（向量哈希 + pdf hash 都用它） ----------------------------
{
  const { createHash } = await import('node:crypto')
  out.nodeCrypto = { sha256EmptyHex: createHash('sha256').update('').digest('hex').slice(0, 16), hasCreateHash: typeof createHash === 'function' }
}

process.stdout.write(JSON.stringify(out, null, 2) + '\n')
