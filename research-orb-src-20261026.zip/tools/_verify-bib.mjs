import { Cite } from '@citation-js/core'
import '@citation-js/plugin-bibtex'
import { readFileSync } from 'node:fs'
const raw = readFileSync(process.argv[2], 'utf8')
const json = new Cite(raw).data
console.log('  条目数=' + json.length)
console.log('  含 DOI=' + json.filter((x) => (x.DOI || '').length > 0).length)
console.log('  作者完整条目=' + json.filter((x) => Array.isArray(x.author) && x.author.length > 0).length)
console.log('  首条: ' + (json[0]?.title || '(空)').slice(0, 55) + ' | ' + (json[0]?.DOI || '无DOI'))