# voice_cosy.py -- S37·C TTS 路线 A：CosyVoice2 一次性合成（跑完即退，零常驻进程）。
#
# Input : argv[1] = 文本；argv[2] = 输出 wav 路径
# Output: stdout 一行 JSON {"ok":true,"wav":"…","sec":2.1}
# 纪律：模型加载失败/缺失 → {"ok":false,"reason":"…"} exit 1（调用方走系统 TTS 兜底并如实标注）。
# 明确不做：本脚本不驻留、不起服务、不联网（模型全部本地）。

import json
import os
import sys

CANDIDATE_ROOTS = [
    r"D:\AI_Workspace\dsh-orb-cordis",
]


def emit(obj, code=0):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.exit(code)


def main():
    if len(sys.argv) < 3:
        emit({"ok": False, "reason": "缺少文本或输出路径"}, 1)
    text = sys.argv[1]
    out = sys.argv[2]
    root = next((r for r in CANDIDATE_ROOTS if os.path.exists(r)), None)
    if not root:
        emit({"ok": False, "reason": "dsh-orb-cordis 不在本机（CosyVoice2 模型缺失）", "code": "E_VOICE_UNAVAILABLE"}, 1)
    try:
        sys.path.insert(0, os.path.join(root, "vendor", "CosyVoice"))
        # 模型加载：CosyVoice2 从 models/cosyvoice2 载入（3.8G，首次 ~1-2 分钟）
        from cosyvoice.cli.cosyvoice import CosyVoice2  # noqa: E402
        model_dir = os.path.join(root, "models", "cosyvoice2", "CosyVoice-BlankEN")
        model = CosyVoice2(model_dir)
        for i, result in enumerate(model.inference_sft(text[:120], "中文女", stream=False)):
            audio = result["tts_audio"].numpy().tobytes()
            with open(out, "wb") as f:
                _write_wav(f, audio, 22050)
            break
        if not os.path.exists(out):
            emit({"ok": False, "reason": "合成未产出音频"}, 1)
        import wave
        with wave.open(out, "rb") as w:
            sec = w.getnframes() / float(w.getframerate())
        emit({"ok": True, "wav": out, "sec": round(sec, 2)})
    except Exception as e:
        emit({"ok": False, "reason": "CosyVoice2 不可用：" + str(e)[:160], "code": "E_VOICE_UNAVAILABLE"}, 1)


def _write_wav(f, pcm_bytes, rate):
    import wave
    with wave.open(f.name if hasattr(f, "name") else f, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm_bytes)


if __name__ == "__main__":
    main()
