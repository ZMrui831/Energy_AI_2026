// tools/gen-voice-test-wav.mjs —— 生成验收用语音 wav（Windows SAPI 真音频素材）。
// 用法：node tools\gen-voice-test-wav.mjs [输出.wav] [文本]
import { spawnSync } from 'node:child_process'
import { existsSync, statSync, writeFileSync, mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

const out = process.argv[2] || join(tmpdir(), 's37-voice-test.wav')
const text = process.argv[3] || '今天北京天气晴，适合出门散步，适合远程会议'
const dir = join(tmpdir(), 's37-voice')
mkdirSync(dir, { recursive: true })

const ps = [
  'Add-Type -AssemblyName System.Speech',
  '$s = New-Object System.Speech.Synthesis.SpeechSynthesizer',
  `$s.SetOutputToWaveFile('${out.replace(/'/g, "''")}')`,
  `$s.Speak('${text.replace(/'/g, "''")}')`,
  '$s.Dispose()',
].join('; ')
const r = spawnSync('powershell', ['-NoProfile', '-Command', ps], { encoding: 'utf8', timeout: 60000 })
console.log('exit:', r.status, String(r.stderr || '').slice(0, 150))
console.log('wav:', existsSync(out) ? statSync(out).size + 'B @ ' + out : 'MISSING')
writeFileSync(join(dir, 'gen.log'), `text=${text}\nout=${out}\nexit=${r.status}\n`, 'utf8')
