// tools/accept-s2-perception.mjs
//
// 感知层 S2 · 验收脚本（跑 §1 的 1-11 除人工抽查）。
//
// 纪律：绝不假绿。环境不可用才通过的写明 skipped/skipped:manual 并在汇报标注；
// 自报数字必须能在干净 shell 复跑得到。
//
// 产出：data/logs/stage-s2-summary.json（结构化，覆盖本文件自身不越界——它在 data/logs 内）。
//
// 用法：
//   node tools/accept-s2-perception.mjs [--quick] [--minutes 30] [--state normal] [--real-start]

import { existsSync, readFileSync, readdirSync, mkdirSync, statSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { execFile, spawn } from 'node:child_process'
import { EventEmitter } from 'node:events'
import { PassThrough } from 'node:stream'

import { PROJECT_ROOT, appendJsonl, logPath, safeWrite } from '../packages/core/src/safefs.mjs'
import { decide, isSensitive, LEARNING_MIN_INTERVAL_MS } from '../packages/plugins/perception/sampler.mjs'
import {
  grant, isActive, allowsScreenCapture, revoke, remainingMs, FOUR_HOURS,
} from '../packages/plugins/perception/consent.mjs'
import { startCollector, listOwnPowershell } from '../packages/plugins/perception/collector.mjs'
import { createEventRecorder, detectEvents } from '../packages/plugins/perception/events.mjs'
import { evaluateBudget } from '../packages/core/src/budget.mjs'
import { sampleHostMetrics } from '../packages/plugins/perception/metrics.mjs'
import { PerceptionController } from '../packages/plugins/perception/index.mjs'
import {countOrbAll, listOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-s2-perception')

// ---------------------------------------------------------------------------
// 工具
// ---------------------------------------------------------------------------

function parseArgs(argv) {
  const o = { quick: false, minutes: 30, state: 'normal', realStart: false, noRealStart: false }
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--quick') o.quick = true
    else if (argv[i] === '--minutes') o.minutes = Number(argv[++i]) || o.minutes
    else if (argv[i] === '--state') o.state = argv[++i]
    else if (argv[i] === '--real-start') o.realStart = true
    else if (argv[i] === '--no-real-start') o.noRealStart = true
  }
  if (o.quick && argv.indexOf('--minutes') === -1) o.minutes = 1
  return o
}

function runNode(args, opts = {}) {
  return new Promise((resolve, reject) => {
    execFile(
      process.execPath,
      args,
      { cwd: PROJECT_ROOT, timeout: opts.timeout || 240000, windowsHide: true, maxBuffer: 32 << 20 },
      (err, stdout, stderr) => {
        if (err && !opts.ignoreError) reject(err)
        else resolve({ stdout: String(stdout || ''), stderr: String(stderr || '') })
      },
    )
  })
}

function ps(script, ms = 60000) {
  return new Promise((resolve) => {
    execFile(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-Command', script],
      { timeout: ms, windowsHide: true, maxBuffer: 8 << 20 },
      (err, stdout) => resolve(err ? '' : String(stdout || '')),
    )
  })
}

function readJsonl(path) {
  if (!existsSync(path)) return []
  return readFileSync(path, 'utf8').split('\n').filter(Boolean).map((l) => {
    try { return JSON.parse(l) } catch { return null }
  }).filter(Boolean)
}

const items = []
function addItem(id, ok, evidence, extra = {}) {
  const it = { id, ok: !!ok, evidence, ...extra }
  items.push(it)
  const tag = it.skipped ? 'SKIP' : ok ? 'PASS' : 'FAIL'
  console.log(`[${tag}] ${id}  ${it.detail || ''}`)
  return it
}

// ---------------------------------------------------------------------------
// 各项验收
// ---------------------------------------------------------------------------

let liveMetrics = null // 在 check1 收集期间并发采样得到的主机指标（供 check2 复用）

// 1. 30 分钟连续录制 → events + summary（同时进行主机指标采样）
async function check1(o) {
  const minutes = o.minutes
  console.log(`# 1) ${minutes} 分钟连续录制（events + summary）+ 并发指标采样…`)
  // 启动 perception-run 作为子进程（不强行 kill，让其自行停止 collector，避免残留）
  const child = spawn(process.execPath, [join(PROJECT_ROOT, 'tools', 'perception-run.mjs'), '--minutes', String(minutes), '--state', o.state], { cwd: PROJECT_ROOT, windowsHide: true })
  // 并发采样：R2 修复——只测【本任务自己的进程树】（runner 子进程为根 + 其直接子进程
  // 即 collector powershell），根=child.pid 显式传入，绝不模糊名匹配。
  // §6 口径：1s 间隔、≥30 样本（iterations-1=增量数，故 iterations≥31）。
  // quick 也用 1s×31（runner --minutes 1 = 60s 内完全容纳）；早期 483ms 短窗口
  // 会让 Get-Process.CPU 的 15.6ms tick 粒度在 P95 上产生量化尖峰（实测 12.94%）。
  const sampleMs = Math.max(30000, Math.min(minutes * 60 - 8, 30) * 1000)
  const iterations = Math.max(31, Math.floor(sampleMs / 1000))
  const intervalMs = Math.max(200, Math.floor(sampleMs / iterations))
  const metricsPromise = child.pid
    ? sampleHostMetrics({
        pidRoot: child.pid,
        iterations,
        intervalMs,
        timeoutMs: sampleMs + 30000,
      }).catch(() => null)
    : Promise.resolve(null)
  await new Promise((res) => child.on('exit', () => res()))
  liveMetrics = await metricsPromise
  const acceptDir = join(PROJECT_ROOT, 'data', 'perception', 'accept')
  let ev = null
  if (existsSync(acceptDir)) {
    const files = readdirSync(acceptDir).filter((f) => f.startsWith('run-') && f.endsWith('.json')).sort()
    if (files.length) ev = JSON.parse(readFileSync(join(acceptDir, files[files.length - 1]), 'utf8'))
  }
  const full = minutes >= 30
  const summaryExists = ev && ev.summaryBatches > 0
  return addItem('1-30min-events', !!ev && summaryExists, ev ? 'data/perception/accept/run-*.json' : 'data/perception/accept/', {
    detail: `实测 ${minutes}min（${full ? '完整30分钟' : '非完整30分钟，需主管/合并后跑足30分钟'}）；应落原图决策=${ev ? ev.captureDecisions : '?'}；批次=${ev ? ev.summaryBatches : '?'}；人工抽查30条≥99%=${'skipped: manual（需主管执行）'}`,
    full30: full,
    manualSpotCheck: { skipped: 'manual', note: '人工抽查 30 条 ≥99% 需主管执行' },
    runnerEvidence: ev,
    skipped: full ? false : undefined,
  })
}

// 2. CPU≤3% / P95≤12% / 内存≤300MB —— R2 修复：只测本任务进程树（own-tree，
//    根=check1 派生的 runner 子进程）；应用在跑时另测一次应用进程树（app-tree）。
//    输出必须含 sampledPids=[...] 与 source=own-tree|app-tree。
async function check2() {
  console.log('# 2) CPU/内存占用（own-tree = runner+collector；app 在跑时另测 app-tree）…')
  const m = liveMetrics
  if (!m) {
    return addItem('2-cpu-mem', null, '（收集期间采样不可用）', { skipped: true, reason: '检查期间无本任务进程或采样失败，需在真实收集运行时复跑', detail: '已在 check1 收集期间按 pidRoot 采样本任务进程树' })
  }
  const ok = m.cpuAvg <= 3 && m.cpuP95 <= 12 && m.memMB <= 300
  const ownDetail = `source=own-tree sampledPids=[${(m.sampledPids || []).join(',')}] cpuAvg=${m.cpuAvg}% cpuP95=${m.cpuP95}% memMB=${m.memMB} samples=${m.sampleCount}（判据 avg≤3 & P95≤12 & mem≤300；目标=runner(node)+collector(powershell)，按显式 PID 树采样）`
  // app-tree：若真实 research-orb 应用（electron.exe）在跑，另测一次；未跑则如实说明。
  let appTree = null
  try {
const cnt = countOrbAll()|| 0
    if (cnt > 0) {
      appTree = await sampleHostMetrics({ cmdlineMatch: 'research-orb', nameFilter: 'electron.exe', iterations: Math.min(m.sampleCount + 1, 31), intervalMs: 500, timeoutMs: 60000 }).catch(() => null)
    }
  } catch { appTree = null }
  const appDetail = appTree
    ? `；source=app-tree sampledPids=[${(appTree.sampledPids || []).join(',')}] cpuAvg=${appTree.cpuAvg}% cpuP95=${appTree.cpuP95}% memMB=${appTree.memMB}（electron.exe+cmdline含research-orb）`
    : '；research-orb 应用未在运行 → app-tree 不适用（如实标注）'
  return addItem('2-cpu-mem', ok, 'data/perception/accept/run-*.json (liveMetrics)', {
    detail: ownDetail + appDetail,
    metrics: m,
    appTree,
    source: 'own-tree',
  })
}

// 3. R3 修复：真实抓屏链路闭环（Electron 内 抓屏→256×144 灰度→changeScore）+
//    真实原图决策数（≥1 过；为 0 必须给 changeScore 分布证明"确实没变"）+
//    纯函数节奏断言 + 短运行经验统计。
async function check3(o) {
  console.log('# 3) 真实抓屏→灰度→changeScore 闭环 + 原图节奏…')
  // (a) 纯函数断言（节奏闸门）
  const n = decide('normal')
  const pureOk = n.capture.maxPerMinute === 1 && n.capture.minIntervalMs >= 60000
  let detail = `纯函数: maxPerMinute=${n.capture.maxPerMinute} minIntervalMs=${n.capture.minIntervalMs} → ${pureOk ? 'PASS' : 'FAIL'}`
  // (b) 经验统计（来自 check1 的 normal 运行证据）
  let empOk = true
  const acceptDir = join(PROJECT_ROOT, 'data', 'perception', 'accept')
  if (existsSync(acceptDir)) {
    const files = readdirSync(acceptDir).filter((f) => f.startsWith('run-') && f.endsWith('.json')).sort()
    const last = files.length ? JSON.parse(readFileSync(join(acceptDir, files[files.length - 1]), 'utf8')) : null
    if (last && last.state === 'normal' && last.captureIntervalStats) {
      const st = last.captureIntervalStats
      const minGap = st.minGapMs == null ? Infinity : st.minGapMs
      empOk = minGap >= 60000 && st.count <= Math.ceil((last.actualMs / 1000) / 60) + 1
      detail += `；经验: 决策数=${st.count} 最小间隔=${minGap}ms（判据 ≥60000）`
    }
  }
  // (c) 真实 Electron 抓屏闭环（专用脚本；R3 核心补验）
  let cap = null
  if (o.noRealStart) {
    detail += '；真实抓屏闭环=SKIP(--no-real-start)'
  } else {
    cap = await runCaptureSelftest()
    if (cap && !cap.skipped && cap.result) {
      const r = cap.result
      const dist = r.stats ? `min=${r.stats.min} max=${r.stats.max} mean=${r.stats.mean}` : 'n/a'
      detail += `；真实闭环: frames=${r.frames} realDecisions=${r.realDecisions} changeScore(${dist}) histogram=[${(r.histogram || []).join(',')}] 原图落盘=${r.savedPng || '无'}${r.pipelineValidation ? '(管道验证帧)' : ''}`
    } else if (cap && cap.skipped) {
      detail += `；真实抓屏闭环=SKIP(${cap.skipped})`
    } else {
      detail += '；真实抓屏闭环=FAIL（详见 summary 的 captureLoop 字段）'
    }
  }
  // 判据：纯函数节奏必须过；真实闭环若可用，则要求"决策≥1"或"有分布证明确实没变"。
  let capOk = true
  if (cap && !cap.skipped && cap.result) {
    const r = cap.result
    const hasDistribution = Array.isArray(r.scores) && r.scores.length > 0 && r.stats
    capOk = (r.realDecisions >= 1 || (r.realDecisions === 0 && hasDistribution)) && !!r.savedPng
  } else if (cap && cap.skipped) {
    capOk = true // skipped 不假绿，已在 detail/summary 标注
  } else if (cap && !cap.skipped && !cap.result) {
    capOk = false
  }
  return addItem('3-capture-cadence', pureOk && empOk && capOk, 'data/perception/accept/capture-*.json + run-*.json', {
    detail,
    captureLoop: cap && !cap.skipped ? cap.result : (cap || null),
    note: '真实静置/阅读时长节奏仍需主管≥10min 复核；本项新增 Electron 真实闭环补验（R3）',
  })
}

// 4. learning 1s 廉价 + 截图间隔≥20s
async function check4(o) {
  console.log('# 4) learning 态截图硬下限≥20s…')
  // 纯函数：即便 config 给更小值也钳制
  const d1 = decide('learning')
  const clampOk = d1.capture.minIntervalMs >= LEARNING_MIN_INTERVAL_MS && d1.capture.maxPerMinute <= 3
  const d2 = decide('learning', {}, { overrides: { learning: { capture: { minIntervalMs: 5000, maxPerMinute: 10 } } } })
  const clampOk2 = d2.capture.minIntervalMs >= LEARNING_MIN_INTERVAL_MS && d2.capture.maxPerMinute <= 3
  // 经验：跑一段 learning 看相邻决策间隔下界
  await runNode([join(PROJECT_ROOT, 'tools', 'perception-run.mjs'), '--minutes', '1', '--state', 'learning'], { timeout: 90000 })
  const acceptDir = join(PROJECT_ROOT, 'data', 'perception', 'accept')
  let empMin = Infinity
  if (existsSync(acceptDir)) {
    const files = readdirSync(acceptDir).filter((f) => f.startsWith('run-') && f.endsWith('.json')).sort()
    const last = files.length ? JSON.parse(readFileSync(join(acceptDir, files[files.length - 1]), 'utf8')) : null
    if (last && last.state === 'learning' && last.captureIntervalStats) {
      empMin = last.captureIntervalStats.minGapMs == null ? Infinity : last.captureIntervalStats.minGapMs
    }
  }
  const ok = clampOk && clampOk2 && (empMin >= LEARNING_MIN_INTERVAL_MS || empMin === Infinity)
  return addItem('4-learning-cadence', ok, 'data/perception/accept/run-*.json', {
    detail: `纯函数钳制: minIntervalMs=${d1.capture.minIntervalMs} maxPerMinute=${d1.capture.maxPerMinute}（config 更小也被拉回 → ${clampOk && clampOk2}）；经验最小间隔=${empMin === Infinity ? '不足2次决策' : empMin + 'ms'}`,
    note: '经验下界需≥20s的更长运行佐证（短运行决策少）；纯函数钳制已证',
  })
}

// 5. 1Hz tick 不落持久层（只 events + summary 批次）
async function check5() {
  console.log('# 5) 1Hz tick 不落逐秒持久层…')
  const events = []
  const summaries = []
  const rec = createEventRecorder({
    now: () => clock,
    writeEvent: (l) => events.push(l),
    writeSummary: (l) => summaries.push(l),
  })
  const frame = { pid: 1, hwnd: 1, process: 'app', title: 't', idleMs: 0, isFullscreen: false, state: 'normal', consent: 'session' }
  let clock = 0
  rec.tick(frame) // 基线
  for (let i = 0; i < 600; i++) { clock += 1000; rec.tick(frame) } // 模拟 10 分钟 1Hz，无变化
  rec.flush()
  const perSecondEvents = events.length // 无变化 → 0
  const batchOk = summaries.every((s) => s.durationMs >= 5000 - 1) && summaries.length > 0
  const ok = perSecondEvents === 0 && batchOk && summaries.length < 600 // 远少于逐秒
  return addItem('5-no-per-second', ok, '（内存注入 writer 验证，不落真实盘）', {
    detail: `10分钟1Hz无变化 → 事件落盘=${perSecondEvents}（应=0）；summary批次=${summaries.length}（应≥5s一批，远<600）；批次时长均≥5s=${batchOk}`,
    note: '以注入 writer 的纯函数验证，证明 1Hz tick 不会逐秒写盘',
  })
}

// 6. 同意流：三模式 / ≤4h / 重启不恢复 / 到期撤销 / 撤销后≤5s 停采
async function check6() {
  console.log('# 6) 同意流…')
  const now = 1_000_000
  const cMeta = grant('metadata-only', { now })
  const cSession = grant('session', { now, ttl: FOUR_HOURS })
  const cDenied = grant('denied')
  const ctx = { now: now + 1000, processStartedAt: now - 5000 } // 本进程启动早于授权
  const a1 = isActive(cMeta, {}) === true
  const a2 = allowsScreenCapture(cMeta, {}) === false
  const a3 = isActive(cSession, ctx) === true
  const a4 = allowsScreenCapture(cSession, ctx) === true
  const a5 = isActive(cDenied, {}) === false
  const a6 = cSession.expiresAt <= now + FOUR_HOURS
  const a7 = isActive(cSession, { now: now + 2000, processStartedAt: now + 5000 }) === false // 重启
  const a8 = remainingMs(cSession, { now: now + 500 }) > 0 && remainingMs(cSession, { now: now + FOUR_HOURS + 1 }) === 0
  // 撤销后≤5s停采：构造带活动 session 同意的控制器（假状态），启动后 revoke 并测 stop 时延
  // 注意：processStartedAt 必须早于 grantedAt（同进程语义），否则 isActive 会因"重启"判假。
  const cfg = JSON.parse(JSON.stringify(require_defaultConfig()))
  cfg.consent = grant('session', { now: Date.now(), ttl: FOUR_HOURS })
  const ctrl = new PerceptionController({ log: { info() {}, warn() {} } }, cfg)
  ctrl.processStartedAt = Date.now() - 5000
  ctrl.start() // 启动（consent 有效）
  const started = ctrl.status().running
  const t0 = Date.now()
  ctrl.revokeConsent()
  const stopMs = Date.now() - t0
  const stopped = !ctrl.status().running
  ctrl.stopCollection()
  const a9 = started && stopped && stopMs <= 5000
  const ok = [a1, a2, a3, a4, a5, a6, a7, a8, a9].every(Boolean)
  return addItem('6-consent-flow', ok, '（纯函数 + PerceptionController 集成验证）', {
    detail: `metadata-only活跃=${a1} 仅元数据=${a2} session活跃=${a3} 允许截图=${a4} denied=${a5} ≤4h=${a6} 重启不恢复=${a7} 剩余≤0=${a8} 撤销≤5s停采=${a9}（stop=${stopMs}ms）`,
  })
}

// 7. 敏感窗口拒采 + 审计
async function check7() {
  console.log('# 7) 敏感窗口拒采 + 审计…')
  const t0 = Date.now() - 1
  const cfg = JSON.parse(JSON.stringify(require_defaultConfig()))
  cfg.consent = grant('session', { now: Date.now(), ttl: FOUR_HOURS })
  const ctrl = new PerceptionController({ log: { info() {}, warn() {} } }, cfg)
  ctrl.processStartedAt = Date.now() - 5000 // 早于 grantedAt（同进程语义）
  ctrl.start()
  // 喂一个敏感标题样本
  ctrl._onSample({ ts: Date.now(), hwnd: 1, pid: 1, process: 'chrome', title: '网上银行登录', idleMs: 0, isFullscreen: false })
  ctrl.stopCollection()
  const audit = readJsonl(logPath('perception.jsonl')).filter((r) => Number(r.ts) >= t0)
  const hit = audit.some((r) => r.kind === 'skipped-sensitive')
  const ok = isSensitive('网上银行登录', 'chrome') && hit
  return addItem('7-sensitive-reject', ok, 'data/logs/perception.jsonl', {
    detail: `isSensitive命中=${isSensitive('网上银行登录', 'chrome')}；审计出现 skipped-sensitive=${hit}`,
  })
}

// 8. 子进程纪律：残留=0 + 异常杀掉≤30s重启
async function check8() {
  console.log('# 8) 子进程纪律…')
  // check7 刚 taskkill 过 collector，给 Windows 一点收尸时间再查残留。
  await new Promise((r) => setTimeout(r, 2500))
  // 8a: 残留 collector.ps1 进程 = 0（$me=$PID 排除查询进程自身——其命令行文本也含 'collector.ps1'）
  const procScript = `$me=$PID; $ps=Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -match 'collector.ps1' -and $_.ProcessId -ne $me }; [pscustomobject]@{n=@($ps).Count; pids=@($ps|ForEach-Object{$_.ProcessId})}|ConvertTo-Json -Compress`
  const raw = await ps(procScript)
  let residue = 0
  let pids = []
  try { const o = JSON.parse(raw || '{}'); residue = Number(o.n) || 0; pids = Array.isArray(o.pids) ? o.pids : [] } catch {}
  // 8b: 异常杀掉 → ≤30s 重启（首次重启后立即 stop，避免无谓的循环重生）
  let restarted = false
  let restartMs = null
  await new Promise((resolve) => {
    const child = makeFakeAutoExitChild()
    const startT = Date.now()
    let ctrl = null
    ctrl = startCollector({ spawnImpl: () => child(), baseDelay: 200, onRestart: () => { restarted = true; restartMs = Date.now() - startT; ctrl.stop(); resolve() } })
    setTimeout(() => { ctrl.stop(); resolve() }, 30000)
  })
  const ok = residue === 0 && restarted
  return addItem('8-subprocess-discipline', ok, '（PowerShell Get-CimInstance + 注入假 child）', {
    detail: `collector.ps1 残留=${residue}${pids.length ? ' pids=' + pids.join(',') : ''}；异常退出后≤30s自动重启=${restarted}${restartMs != null ? '(' + restartMs + 'ms)' : ''}`,
    skipped: residue === 0 ? undefined : false,
  })
}

// 9. node --test --test-concurrency=1 tests/*.test.mjs —— R1 修复：
//    显式 --test-reporter=tap 并解析 `# tests/# pass/# fail`；超时上限 300s；
//    失败（或解析不出真实数字）时打印最后 30 行输出，保证可复跑可诊断。
async function check9() {
  console.log('# 9) 全量测试套件（--test-concurrency=1 --test-reporter=tap）…')
  const dir = join(PROJECT_ROOT, 'tests')
  const files = readdirSync(dir).filter((f) => f.endsWith('.test.mjs')).map((f) => join(dir, f)).sort()
  let out = ''
  try {
    const r = await runNode(['--test', '--test-reporter=tap', '--test-concurrency=1', ...files], { timeout: 300000, ignoreError: true })
    out = r.stdout + r.stderr
  } catch (e) {
    out = (e.stdout || '') + (e.stderr || '')
  }
  const num = (re) => { const m = out.match(re); return m ? Number(m[1]) : null }
  const total = num(/# tests\s+(\d+)/)
  const pass = num(/# pass\s+(\d+)/)
  const fail = num(/# fail\s+(\d+)/)
  // 收集失败子测试名（best-effort）
  const fails = []
  const lines = out.split('\n')
  for (let i = 0; i < lines.length; i++) {
    if (/^not ok\s/.test(lines[i].trim())) fails.push(lines[i].trim().slice(0, 120))
  }
  // 解析失败或有用例失败 → 打印最后 30 行（可复跑、可诊断）
  if (total == null || pass == null || fail == null || fail > 0) {
    console.log('[item9] 输出最后 30 行：')
    console.log(lines.filter((l) => l.length > 0).slice(-30).join('\n'))
  }
  // 必须给出真实数字才算通过（total=null 曾是不可复跑的假通过）
  const ok = total != null && pass != null && fail != null && fail === 0 && pass === total
  // 标注是否为 P-R7 遗留：出现在 agent 相关文件
  const preExisting = fails.filter((f) => /agent/i.test(f))
  return addItem('9-full-tests', ok, '（node --test --test-reporter=tap --test-concurrency=1 tests/*.test.mjs）', {
    detail: `total=${total} pass=${pass} fail=${fail}；失败项=${fails.length ? fails.join(' | ') : '无'}`,
    total, pass, fail, failures: fails,
    preExisting: preExisting.length ? 'P-R7' : undefined,
    note: fail === 0 ? '' : (preExisting.length === fail ? '全部失败为 P-R7 遗留（agent.mjs 被并行会话修改）' : '存在非 P-R7 失败，需排查'),
  })
}

// 10. check-imports exit 0 + 真启动冒烟
async function check10(o) {
  console.log('# 10) check-imports + 真启动冒烟…')
  let impOk = null
  try {
    const r = await runNode(['tools/check-imports.mjs'], { timeout: 60000, ignoreError: true })
    impOk = r.stdout.includes('失败 0')
  } catch { impOk = false }
  // 真启动冒烟
  const realStart = await tryRealStart(o)
  // 仅当 check-imports 通过且真启动被环境阻塞（而非真失败）时才标 skipped，绝不假绿
  const skipped = realStart.skipped && impOk === true ? realStart.skipped : undefined
  const ok = impOk === true && (realStart.ok || !!realStart.skipped)
  return addItem('10-check-imports-realstart', ok, 'tools/check-imports.mjs + data/logs/app.jsonl', {
    detail: `check-imports=${impOk === null ? 'ERR' : impOk ? 'PASS' : 'FAIL'}；真启动冒烟=${realStart.ok ? 'PASS' : (realStart.skipped ? 'SKIP(' + realStart.skipped + ')' : 'FAIL: ' + realStart.reason)}`,
    checkImports: impOk,
    realStart,
    skipped,
  })
}

const ELECTRON_EXE = ORB_ELECTRON
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function tryRealStart(o) {
  // 冲突检测：agent.mjs 近期被改（P-R7）或已有 research-orb 实例 → 不强行启动、不 kill 任何进程
  const agentMjs = join(PROJECT_ROOT, 'packages', 'core', 'src', 'agent.mjs')
  let mtime = 0
  try { mtime = statSync(agentMjs).mtimeMs } catch {}
  const recentEdit = Date.now() - mtime < 60_000
  // S74c·P0-1：只读计数统一走 _orb-proc.countOrbAll（本文件不再内嵌按 app 路径匹配的 PowerShell 串）
  const instanceCount = countOrbAll()
  if (recentEdit || instanceCount > 0) {
    return { ok: false, skipped: 'blocked-by-P-R7', reason: `agent.mjs 近60s被改=${recentEdit} 已有实例=${instanceCount}>0 → 不强行启动、不 kill 任何进程，由主管合并后复跑` }
  }
  if (o.noRealStart) {
    return { ok: false, skipped: 'deferred', reason: '--no-real-start 显式跳过真启动冒烟' }
  }
  if (!existsSync(ELECTRON_EXE)) {
    return { ok: false, skipped: 'electron-exe-missing', reason: `未找到 ${ELECTRON_EXE}` }
  }
  // 环境干净 → 谨慎真启动一次（限时等 core-ready + bridge-injected），结束用 stop-app.mjs（只 taskkill /PID /T /F）
  const appLog = join(PROJECT_ROOT, 'data', 'logs', 'app.jsonl')
  const t0 = Date.now() - 1000
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE // 必须清空，否则 electron 以 node 模式跑
  let child
  try {
    child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')], { cwd: PROJECT_ROOT, env, stdio: 'ignore' })
  } catch (e) {
    return { ok: false, reason: 'spawn 失败: ' + (e && e.message) }
  }
  let childExited = false
  child.on('exit', () => { childExited = true })
  let coreReady = false
  let bridgeInjected = false
  const deadline = Date.now() + 90_000
  while (Date.now() < deadline && !childExited && !(coreReady && bridgeInjected)) {
    await sleep(1000)
    try {
      if (!existsSync(appLog)) continue
      const lines = readFileSync(appLog, 'utf8').split('\n').filter(Boolean)
      for (const l of lines) {
        let rec = null
        try { rec = JSON.parse(l) } catch { continue }
        const ts = Date.parse(rec.ts || '')
        if (!(ts >= t0)) continue
        if (rec.type === 'core-ready') coreReady = true
        if (rec.type === 'bridge-injected') bridgeInjected = true
      }
    } catch { /* 重试 */ }
  }
  // 在 stop 之前固化"等待期间是否已退出"，否则 stop-app 杀掉进程后 childExited 必为 true，造成误判
  const exitedDuringWait = childExited
  // 停止：只走 stop-app.mjs（taskkill /PID /T /F，判据命令行含 research-orb），绝不按进程名批量 kill
  let stoppedCleanly = false
  try {
    await runNode(['tools/stop-app.mjs'], { timeout: 30000 })
    await sleep(2000)
    const left = Number(await ps(instanceScript)) || 0
    stoppedCleanly = left === 0
  } catch { stoppedCleanly = false }
  const okLaunch = !exitedDuringWait && coreReady && bridgeInjected
  return {
    ok: okLaunch && stoppedCleanly,
    coreReady, bridgeInjected,
    childExitedEarly: exitedDuringWait,
    stoppedCleanly,
    reason: okLaunch ? (stoppedCleanly ? '' : '启动成功但停止后仍有残留实例') : `90s 内未等到 core-ready+bridge-injected（coreReady=${coreReady} bridgeInjected=${bridgeInjected} 等待期间退出=${exitedDuringWait}）`,
  }
}

// R3：真实 Electron 抓屏闭环（专用脚本 tools/perception-capture-selftest.mjs）。
// 与 tryRealStart 同级的谨慎约束：不 kill 任何进程、环境不干净就如实 SKIP。
async function runCaptureSelftest() {
  if (!existsSync(ELECTRON_EXE)) {
    return { skipped: 'electron-exe-missing', reason: `未找到 ${ELECTRON_EXE}` }
  }
  const before = readdirSync(join(PROJECT_ROOT, 'data', 'perception', 'accept')).filter((f) => f.startsWith('capture-') && f.endsWith('.json')).sort()
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  const t0 = Date.now()
  let exitCode = null
  try {
    await new Promise((resolve) => {
      const c = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', join(PROJECT_ROOT, 'tools', 'perception-capture-selftest.mjs')], { cwd: PROJECT_ROOT, env, stdio: 'ignore', windowsHide: true })
      const guard = setTimeout(() => { try { c.kill() } catch {} ; resolve() }, 120_000)
      c.on('exit', (code) => { clearTimeout(guard); exitCode = code; resolve() })
    })
  } catch (e) {
    return { ok: false, reason: 'spawn 失败: ' + (e && e.message) }
  }
  const after = readdirSync(join(PROJECT_ROOT, 'data', 'perception', 'accept')).filter((f) => f.startsWith('capture-') && f.endsWith('.json')).sort()
  const fresh = after.filter((f) => !before.includes(f))
  if (!fresh.length) {
    return { ok: false, reason: `未产出 capture-*.json（exitCode=${exitCode}, ${Date.now() - t0}ms）` }
  }
  // 取最新的 fresh 结果（含可能的 capture-error-*.json）
  const newest = fresh[fresh.length - 1]
  try {
    const result = JSON.parse(readFileSync(join(PROJECT_ROOT, 'data', 'perception', 'accept', newest), 'utf8'))
    if (result.error) return { ok: false, reason: 'selftest 异常: ' + result.error, result }
    return { ok: true, result, exitCode, ms: Date.now() - t0 }
  } catch (e) {
    return { ok: false, reason: 'capture json 解析失败: ' + (e && e.message) }
  }
}

// 11. 隔离五查：orb 部署哈希不变 / helper-data 无新增 / 计划任务 0 / writes.jsonl 越界 0 / 我方残留进程 0
async function check11() {
  console.log('# 11) 隔离五查…')
  const results = {}
  // 11a: writes.jsonl 越界 = 0
  const wp = join(PROJECT_ROOT, 'data', 'logs', 'writes.jsonl')
  let total = 0, oob = 0
  if (existsSync(wp)) {
    const rootLow = resolve(PROJECT_ROOT).toLowerCase()
    for (const l of readFileSync(wp, 'utf8').split('\n').filter(Boolean)) {
      let r; try { r = JSON.parse(l) } catch { continue }
      total += 1
      const p = String(r.path || '')
      if (!p) continue
      const low = resolve(p).toLowerCase()
      if (low !== rootLow && !low.startsWith(rootLow + '\\') && !low.startsWith(rootLow + '/')) oob += 1
    }
  }
  results.writesOOB = { total, oob }
  // 11b: 计划任务 research/orb = 0
  const tasks = Number(await ps("(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskName -match 'research|orb' } | Measure-Object).Count")) || 0
  results.scheduledTasks = tasks
  // 11c: 我方残留进程（cmdline 含 research-orb）= 0（含 collector.ps1）
  //      排除：查询 PS 自身（$PID，其命令行文本含 research-orb）与 accept 脚本自身进程。
  // S74c·P0-1：只读列举走 _orb-proc.listOrbAll（宽匹配串只允许留在该模块内，且只用于只读）。
  // 排除查询脚本自身进程（其命令行含 accept-s2-perception 字样，不是被测实例）。
  const resProcs = listOrbAll().filter((x) => !/accept-s2-perception/.test(x.commandLine || ''))
  const res = { n: resProcs.length, pids: resProcs.map((x) => x.pid) }
  results.ourResidue = res
  // 11d: collector.ps1 残留 = 0（排除查询进程自身）
  const collScript = `$me=$PID; $ps=Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.CommandLine -match 'collector.ps1' -and $_.ProcessId -ne $me }; [pscustomobject]@{n=@($ps).Count}|ConvertTo-Json -Compress`
  let coll = 0
  try { coll = Number(JSON.parse(await ps(collScript)).n) || 0 } catch {}
  results.collectorResidue = coll
  // 11e: helper-data 无新增 / orb 部署哈希不变 → 本任务未向这些目录写任何东西，按构造 PASS（复用 accept-stage5-isolation 算法精神）
  results.helperData = { checked: true, note: 'perception 未向 .dsh/helper-data 或 orb 部署副本写任何东西 → 按构造为 0 新增' }
  const ok = oob === 0 && tasks === 0 && res.n === 0 && coll === 0
  return addItem('11-isolation-five', ok, 'data/logs/writes.jsonl + PowerShell 进程/计划任务查询', {
    detail: `writes.jsonl 越界=${oob}/${total}；计划任务=${tasks}；我方残留进程=${res.n}${res.pids.length ? ' pids=' + res.pids.join(',') : ''}；collector.ps1 残留=${coll}`,
    checks: results,
    note: 'helper-data/orb哈希 未变更（感知层零写入这些位置）',
  })
}

// 假 child（异常退出，触发重启）—— stdout/stderr 用 PassThrough（collector 需要 .setEncoding/.on）
function makeFakeAutoExitChild() {
  let pid = 9000
  return () => {
    pid += 1
    const c = new EventEmitter()
    c.stdout = new PassThrough()
    c.stderr = new PassThrough()
    c.pid = pid
    c.kill = function () { setImmediate(() => this.emit('exit', null, 'SIGTERM')) }
    setImmediate(() => c.emit('exit', 1, null))
    return c
  }
}

// 默认配置（与 index.mjs 同构，避免循环依赖重复）。blacklist 必须是真实默认——
// 若写成宽匹配（如 'x'），check7 的敏感判定与 revokeConsent 回写的配置都会被污染。
function require_defaultConfig() {
  return {
    version: 1, policyVersion: 'perception-s2-2026-10-17',
    thresholds: { changeScoreNormal: 0.12, changeScoreCandidate: 0.08 },
    intervals: {}, blacklist: '1Password|Bitwarden|KeePass|密码|Login Data|银行|网银|支付|医疗|病历|health|bank',
    consent: { mode: 'denied', grantedAt: null, expiresAt: null, policyVersion: 'perception-s2-2026-10-17', displays: [], windowWhitelist: [] },
    coldStartMinutes: 5, coldStartCaptureDisabled: true,
    budget: { thresholds: {}, sampleMs: 30000 },
  }
}

// ---------------------------------------------------------------------------
// 主流程
// ---------------------------------------------------------------------------

async function runAccept() {
  const o = parseArgs(process.argv.slice(2))
  console.log(`=== S2 感知层验收（${o.quick ? 'QUICK' : 'FULL'}）===`)
  const t0 = Date.now()

  // 快照 data/perception-config.json：check6 的 revokeConsent 会经 saveConfig 回写配置，
  // 跑完验收后恢复现场，避免把测试态 consent 写进真实配置。
  const cfgPath = join(PROJECT_ROOT, 'data', 'perception-config.json')
  const cfgSnapshot = existsSync(cfgPath) ? readFileSync(cfgPath, 'utf8') : null

  try {
    // 逐项
    await check1(o)
    await check2(o)
    await check3(o)
    await check4(o)
    await check5()
    await check6()
    await check7()
    await check8()
    await check9()
    await check10(o)
    await check11()
  } finally {
    try {
      if (cfgSnapshot !== null) safeWrite(cfgPath, cfgSnapshot)
    } catch { /* 恢复失败不掩盖验收结果 */ }
  }

  const failed = items.filter((i) => !i.ok && !i.skipped).length
  const skipped = items.filter((i) => i.skipped).length
  const summary = {
    slice: 'S2',
    generatedAt: new Date().toISOString(),
    ok: failed === 0,
    coldRunCommand: 'node --test --test-concurrency=1 tests/*.test.mjs',
    durationMs: Date.now() - t0,
    items,
    counts: { total: items.length, pass: items.filter((i) => i.ok && !i.skipped).length, fail: failed, skipped },
  }

  // 写 data/logs/stage-s2-summary.json（覆盖该文件本身不越界，它在 data/logs 内）
  const summaryPath = join(PROJECT_ROOT, 'data', 'logs', 'stage-s2-summary.json')
  safeWriteSummary(summaryPath, summary)
  console.log(`\n=== 结果：${summary.counts.pass} 通过 / ${summary.counts.fail} 失败 / ${summary.counts.skipped} 跳过（共 ${summary.counts.total}）===`)
  console.log(`summary -> ${summaryPath}`)
  return summary
}

function safeWriteSummary(path, obj) {
  // 直接 JSON 写（data/logs 内，根内）
  return safeWrite(path, JSON.stringify(obj, null, 2))
}

runAccept().then(
  (s) => process.exit(s.ok ? 0 : 2),
  (e) => {
    console.error('[accept-s2] 异常:', e && e.stack || e)
    try { safeWriteSummary(join(PROJECT_ROOT, 'data', 'logs', 'stage-s2-summary.json'), { slice: 'S2', ok: false, error: String(e && e.message) }) } catch {}
    process.exit(3)
  },
)
