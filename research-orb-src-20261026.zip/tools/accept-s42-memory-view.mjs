// tools/accept-s42-memory-view.mjs —— S42·A2 四层记忆视图验收（≥7 项）。
// 单行复跑：node tools\accept-s42-memory-view.mjs
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync, mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'

process.env.ORB_LOG_DIR = join(tmpdir(), 's42-mv-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's42-mv-data-' + Date.now())
const { dataPath, PROJECT_ROOT } = await import('../packages/core/src/safefs.mjs')
const { buildMemoryView, LAYER_BUDGETS } = await import('../packages/plugins/coach/memory-view.mjs')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

try {
  // 播种：摘要 + qa + 长期记忆 + 轨迹
  mkdirSync(dataPath('coach'), { recursive: true })
  mkdirSync(dataPath('memory', 'project'), { recursive: true })
  writeFileSync(dataPath('profile-digest.txt'), '用户是上海高校学生，研究方向为智能电网综合能源系统的 AI 应用，正在备赛。', 'utf8')
  writeFileSync(dataPath('coach', 'qa.jsonl'), [
    JSON.stringify({ ts: new Date().toISOString(), question: '虚拟电厂收益机制？', answerDigest: '三类：容量补偿/电量/辅助服务。', source: 'qa', sessionId: 's1', evidenceIds: [] }),
    '', ].join('\n'), 'utf8')
  writeFileSync(dataPath('memory', 'project', 'longterm.md'), [
    JSON.stringify({ id: 'f1', ts: 1792700000000, layer: 1, text: '用户的研究方向是智能电网综合能源系统的 AI 应用' }),
    '', ].join('\n'), 'utf8')
  writeFileSync(dataPath('coach', 'trajectory.jsonl'), [
    JSON.stringify({ ts: new Date().toISOString(), window: 'VSCode', process: 'code.exe', intent: '撰写综述' }),
    JSON.stringify({ ts: new Date().toISOString(), window: 'Word', process: 'winword.exe', intent: '整理文献' }),
    '', ].join('\n'), 'utf8')

  const v = buildMemoryView({})
  const by = Object.fromEntries(v.layers.map((l) => [l.key, l]))

  // M-1 四层齐全
  check('M-1 四层齐全', v.layers.length === 4 && ['digest', 'memory', 'longterm', 'trajectory'].every((k) => by[k]),
    `layers=${v.layers.map((l) => l.key).join(',')}`, {})

  // M-2 计数与真实文件行数一致（长期记忆 1 行 JSON；轨迹 2 行；qa 1 行）
  check('M-2 计数与文件一致', by.longterm.entries === 1 && by.memory.entries === 1 && by.trajectory.entries === 2,
    `longterm=${by.longterm.entries} qa=${by.memory.entries} traj=${by.trajectory.entries}`, {})

  // M-3 预算一致（≤ 各层上限；合计 ≤1400）
  const budgetsOk = by.digest.budget === 700 && by.longterm.budget === 300 && v.totalUsed <= LAYER_BUDGETS.total
  check('M-3 预算一致（700/300/300/≤1400）', budgetsOk && by.memory.budget === 300,
    `total=${v.totalUsed}/1400`, {})

  // M-4 每层一句人话说明 + 注入样例（≤20 行）
  const notesOk = v.layers.every((l) => l.note && l.note.length > 8)
  const sampleOk = by.trajectory.sample.length === 2 && by.trajectory.sample.length <= 20
  check('M-4 说明+样例（≤20 行）', notesOk && sampleOk, `notes=${notesOk} sample=${by.trajectory.sample.length} 行`, {})

  // M-5 空层提示（清空长期记忆 → 空层给"暂无+如何填充"）
  writeFileSync(dataPath('memory', 'project', 'longterm.md'), '', 'utf8')
  const v2 = buildMemoryView({})
  const lt2 = v2.layers.find((l) => l.key === 'longterm')
  check('M-5 空层提示', lt2.entries === 0 && /暂无/.test(lt2.emptyHint) && lt2.emptyHint.length > 12,
    `hint=${lt2.emptyHint.slice(0, 30)}`, {})

  // M-6 只读 spy（构建两次，所有源文件 mtime/size 不变）
  const before = ['profile-digest.txt', 'coach/qa.jsonl', 'memory/project/longterm.md', 'coach/trajectory.jsonl']
    .map((r) => { const p = dataPath(r); return existsSync(p) ? readFileSync(p).length : -1 })
  buildMemoryView({})
  const after = before.map((_, i) => {
    const p = dataPath(before.length ? ['profile-digest.txt', 'coach/qa.jsonl', 'memory/project/longterm.md', 'coach/trajectory.jsonl'][i] : '')
    return existsSync(p) ? readFileSync(p).length : -1
  })
  check('M-6 只读零写入', JSON.stringify(before) === JSON.stringify(after), `sizes 不变`, {})

  // M-7 渲染匿名 PASS
  const out = mkdtempSync(join(tmpdir(), 's42-mv-'))
  const mdPath = join(out, 'memory-view.md')
  writeFileSync(mdPath, v.text, 'utf8')
  const anon = spawnSync(process.execPath, ['tools/check-anonymity.mjs', mdPath], { encoding: 'utf8', cwd: PROJECT_ROOT })
  check('M-7 渲染匿名 PASS', anon.status === 0 || /PASS/.test(anon.stdout || ''), `exit=${anon.status}`, {})
  try { rmSync(out, { recursive: true, force: true }) } catch { /* 尽力 */ }

  // M-8 /coach memory view 接线
  const idx = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'index.mjs'), 'utf8')
  check('M-8 /coach memory view 接线', idx.includes("startsWith('view')"), `wired=true`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's42-memory-view-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s42-memory-view: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
