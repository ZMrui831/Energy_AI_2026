// tools/accept-s28-clean.mjs —— S29·阶段0 清账验收：data\coach 根目录白名单 + 日报唯一 + 无（评分-数字）命名。
// 单行复跑：node tools\accept-s28-clean.mjs
// 证据：data\logs\s28-clean-accept.json
import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 240), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const COACH = join(PROJECT_ROOT, 'data', 'coach')
// 0.2 白名单：根目录只允许这些项
// S67·3-B：confusion-state.json / plans.jsonl 为合法状态文件（按"明确白名单"保留在根）；
// archive/ 存历史日报副本（不删留痕）；日报只写 daily/，自动记忆只写 memory/。
// S69：incremental.jsonl（增量暂存账）与 score-history.jsonl（评分留痕）均为合法 coach 根状态文件
const ALLOW = ['trajectory.jsonl', 'daily-state.json', 'frames-index.json', 'scheduler.json', 'goal.json', 'confusion-state.json', 'plans.jsonl', 'incremental.jsonl', 'score-history.jsonl', 'memory', 'daily', 'archive']

try {
  const root = readdirSync(COACH)
  // safeWrite 的原子写会留 .bak-<ts> 备份（合法机制，不算越界散文件）
  const stray = root.filter((f) => !ALLOW.includes(f) && !/\.bak-/.test(f) && !/\.bak$/.test(f))
  check('C1 根目录仅含白名单项（轨迹/状态/索引/调度/目标/memory/daily）', stray.length === 0, stray.length ? '越界：' + stray.slice(0, 5).join(',') : `共 ${root.length} 项全部合规`)

  const strayMd = root.filter((f) => f.endsWith('.md'))
  check('C2 根目录无散落 .md（S29 前 44 个已清）', strayMd.length === 0, `散落 md=${strayMd.length}`)

  const scoreNamed = root.filter((f) => /（评分-/.test(f) || /\(评分-/.test(f))
  check('C3 无（评分-数字）命名的散落日报', scoreNamed.length === 0)

  const dailyDir = join(COACH, 'daily')
  const dailies = existsSync(dailyDir) ? readdirSync(dailyDir).filter((f) => f.endsWith('.md')) : []
  const perDay = {}
  for (const f of dailies) {
    const m = f.match(/^daily-(\d{8})\.md$/)
    if (!m) { perDay['__bad__'] = (perDay['__bad__'] || 0) + 1; continue }
    perDay[m[1]] = (perDay[m[1]] || 0) + 1
  }
  const bad = Object.entries(perDay).filter(([k, v]) => k === '__bad__' || v > 1)
  check('C4 daily\ 每日仅一个日报且命名合规（daily-YYYYMMDD.md）', bad.length === 0 && dailies.length >= 1, `日报 ${dailies.length} 个：${dailies.join(', ').slice(0, 80)}`)

  // C5：写入口径——memory.mjs 的 autoSaveFromDaily 不再产 plan 文件（静态断言：源码无 per-advice save）
  const memSrc = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'memory.mjs'), 'utf8')
  check('C5 写入源口径：autoSaveFromDaily 只 save 一条 daily（建议拼正文，无一建议一文件）', /kind: 'daily'/.test(memSrc) && !/for \(const a of advice/.test(memSrc))

  // C6：跑一轮真实 daily（临时目录）后根目录文件数不增
  const before = readdirSync(COACH).sort().join('|')
  const { createRouter } = await import('../packages/core/src/router.mjs')
  const { createExtractor } = await import('../packages/plugins/coach/extract.mjs')
  const { createDailyPipeline } = await import('../packages/plugins/coach/daily.mjs')
  const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's28-clean')
  rmSync(WORK, { recursive: true, force: true })
  mkdirSync(join(WORK, 'coach'), { recursive: true })
  const stub = createRouter({
    providers: { cheap: { providerId: 'school-gateway', model: 'qwen' }, flagship: { providerId: 'deepseek-api', model: 'deepseek-chat' } },
    invoke: async ({ taskClass }) => {
      if (taskClass === 'extract') return { text: '屏幕文字转录（桩）' }
      if (taskClass === 'summarize') return { text: JSON.stringify(['阅读综述']) }
      return { text: JSON.stringify({ score: 90, advice: ['建议甲', '建议乙', '建议丙'] }) }
    },
    usagePath: join(WORK, 'usage.jsonl'),
    audit: () => {},
  })
  const pipeline = createDailyPipeline({ dir: join(WORK, 'coach'), router: stub, extractor: createExtractor({ dir: join(WORK, 'coach'), router: stub, trashDir: join(WORK, 'trash'), ocr: () => ({ ok: true, text: '兜底' }) }) })
  writeFileSync(join(WORK, 'f.png'), Buffer.from('s28-clean frame'))
  await pipeline.run({ consentActive: true, goal: '测试目标', frames: [{ imagePath: join(WORK, 'f.png'), window: 'w', process: 'p' }] })
  const after = readdirSync(COACH).sort().join('|')
  check('C6 跑一轮 daily（含 3 条建议）后根目录文件数不增', before === after, before === after ? '根目录不变' : `差异：${before} → ${after}`)
  rmSync(WORK, { recursive: true, force: true })
} catch (e) {
  check('C0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 240))
}

const pass = items.filter((i) => i.ok).length
const fail = items.length - pass
const out = { tool: 'accept-s28-clean', at: new Date().toISOString(), total: items.length, pass, fail, items }
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's28-clean-accept.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # accept-s28-clean: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 证据 -> data/logs/s28-clean-accept.json`)
process.exit(fail === 0 ? 0 : 1)
