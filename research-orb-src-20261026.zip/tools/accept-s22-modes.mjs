// tools/accept-s22-modes.mjs
//
// S22·C 验收：每一项拿数字说话，证据落 data/logs/s22-modes-accept.json。
//   1. 大文件 lean 读 ≈64KB、standard 读更多，且返回含 "Found X of Y"
//   2. 200 条匹配 → lean 返回 Found 150 of 200
//   3. 本地 60KB HTML 走抓取（transport 注入，避免校园网代理干扰）→ lean 截到 webFetchMaxChars(48KB)
//   4. readonly 尝试 fs.write → E_MODE_READONLY 且审计；切回 standard → 同写入成功
//   5. 三次切换 → data/logs/mode.jsonl 增 3 行
//
// 纪律：全程用内存 fake-fs，不污染真实磁盘；唯一真实落盘是 modes.setMode 写
// data/config.json 的 mode 字段 + 追加 data/logs/mode.jsonl（后者有 try/catch 兜底），
// 结束时回填 standard，不留非默认状态。

import { existsSync, readFileSync } from 'node:fs'
import {join, resolve} from 'node:path'

import { createPathResolver } from '../packages/core/src/tools/paths.mjs'
import { createToolRegistry } from '../packages/core/src/tools/registry.mjs'
import { createPolicy, createGrantStore } from '../packages/core/src/tools/permissions.mjs'
import { createRollback } from '../packages/core/src/tools/rollback.mjs'
import { createToolExecutor } from '../packages/core/src/tools/executor.mjs'
import { registerFsTools } from '../packages/core/src/tools/impl/fs.mjs'
import { registerBridgeTools } from '../packages/core/src/tools/impl/bridge.mjs'
import { createFakeFs } from '../tests/helpers/fake-fs.mjs'
import * as modes from '../packages/core/src/modes.mjs'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const KB = 1024
const ROOT = resolve(import.meta.dirname, '..')
const MODE_LOG = join(PROJECT_ROOT, 'data', 'logs', 'mode.jsonl')

let pass = 0
let fail = 0
const evidence = {}
function check(name, cond, extra = '') {
  if (cond) { pass++; console.log('  [PASS]', name) }
  else { fail++; console.log('  [FAIL]', name, extra) }
  return cond
}

// fs.search 的 found 是字符串，fs.read 的 found 是数组；统一成字符串再做正则。
function foundToStr(f) {
  if (f == null) return ''
  return Array.isArray(f) ? f.join(' ') : String(f)
}

// ---- 内存文件准备 -------------------------------------------------------

// C.1：≥200KB / ≥5000 行 ASCII 大文件；每行较长，使「字节上限」先于「行数上限」触发，
// 于是 lean 档按 readMaxBytes(64KB) 封顶、standard 档按 200KB 封顶（满足判据「字节≈readMaxBytes」）。
const BIG_LINES = []
for (let i = 0; i < 5000; i++) BIG_LINES.push(`line-${String(i).padStart(5, '0')} ` + 'x'.repeat(180)) // 每行 ≈190 字节
const BIG = BIG_LINES.join('\n') // ≈ 5000 * 191 ≈ 955KB
const BIG_BYTES = Buffer.byteLength(BIG, 'utf8')

// C.3：60KB HTML（transport 注入，不走真实网络/代理）
const BIG_HTML = 'a'.repeat(60 * KB)

// ---- 执行器装配 ---------------------------------------------------------

const paths = createPathResolver({
  root: ROOT,
  home: process.env.USERPROFILE,
  env: { USERPROFILE: process.env.USERPROFILE },
  desktopReader: () => 'D:\\Desktop',
})

// 用解析器自身的输出作为 fake-fs 的键，保证存在性判定一致（避开反斜杠归一化差异）
const bigPath = paths.resolveInput('project:big.txt').path
const docDir = paths.resolveInput('project:doc').path
const outPath = paths.resolveInput('project:out.txt').path
const initial = { [bigPath]: BIG }
for (let i = 1; i <= 200; i++) initial[`${docDir}\\match-${String(i).padStart(3, '0')}.txt`] = `doc ${i}`

let auditRows = []
function buildExecutor(fakeFs) {
  auditRows = []
  const registry = createToolRegistry()
  registerFsTools(registry, { fs: fakeFs })
  registerBridgeTools(registry, {
    fs: fakeFs,
    host: { net: { request: async () => ({ ok: true, text: async () => BIG_HTML }) } },
  })
  const policy = createPolicy({ paths })
  const rollback = createRollback({ root: `${ROOT}\\data\\snapshots`, fs: fakeFs })
  const executor = createToolExecutor({
    registry,
    policy,
    grants: createGrantStore(),
    paths,
    rollback,
    fs: fakeFs,
    // 默认批准，便于 standard 档写盘成功（readonly 档在批准前就被模式闸门拦下）
    confirm: async () => ({ approved: true }),
    audit: (rec) => auditRows.push(rec),
  })
  return { registry, policy, executor }
}

function countModeLogLines() {
  if (!existsSync(MODE_LOG)) return 0
  return readFileSync(MODE_LOG, 'utf8').split('\n').filter((l) => l.trim().length > 0).length
}

async function main() {
  // ---------------- C.1 读文件封顶 ----------------
  console.log('# C.1 大文件读取：lean ≈64KB，standard 读更多，且含 Found X of Y')
  {
    const fakeFs = createFakeFs(initial)
    const { executor } = buildExecutor(fakeFs)

    modes.setMode('lean')
    const rLean = await executor.run({ toolId: 'fs.read', args: { path: 'project:big.txt' }, origin: 'accept' })
    const leanVal = rLean.value || {}
    const leanLen = leanVal.text ? leanVal.text.length : 0
    const leanFound = foundToStr(leanVal.found)
    check('lean 读取成功', rLean.ok === true && leanVal.isText === true)
    check('lean 返回字节≈64KB（≤66KB）', leanLen <= 66 * KB && leanLen >= 64 * KB - 500, `len=${leanLen}`)
    check('lean 返回含 Found X of Y', /Found .* of .* \(offset=0, next_offset=/.test(leanFound), leanFound)

    modes.setMode('standard')
    const rStd = await executor.run({ toolId: 'fs.read', args: { path: 'project:big.txt' }, origin: 'accept' })
    const stdVal = rStd.value || {}
    const stdLen = stdVal.text ? stdVal.text.length : 0
    const stdFound = foundToStr(stdVal.found)
    check('standard 读取成功', rStd.ok === true && stdVal.isText === true)
    check('standard 读得比 lean 多（>64KB）', stdLen > leanLen, `std=${stdLen} lean=${leanLen}`)
    check('standard 返回含 Found X of Y', /Found .* of .* \(offset=0, next_offset=/.test(stdFound), stdFound)
    check('standard 读上限=200KB', stdLen <= 204800 + 200 && stdLen >= 200 * KB - 500, `len=${stdLen}`)

    evidence.c1 = {
      fileBytes: BIG_BYTES,
      leanTextLen: leanLen,
      leanFound,
      standardTextLen: stdLen,
      standardFound: stdFound,
    }
  }

  // ---------------- C.2 检索封顶 ----------------
  console.log('# C.2 检索封顶：200 条匹配 → lean 返回 Found 150 of 200')
  {
    const fakeFs = createFakeFs(initial)
    const { executor } = buildExecutor(fakeFs)
    modes.setMode('lean')
    const r = await executor.run({ toolId: 'fs.search', args: { path: 'project:doc', pattern: 'match-*.txt' }, origin: 'accept' })
    const val = r.value || {}
    const found = foundToStr(val.found)
    check('检索成功', r.ok === true)
    check('总匹配=200', val.total === 200, `total=${val.total}`)
    check('lean 截到 150 条', val.count === 150, `count=${val.count}`)
    check('返回 Found 150 of 200', /Found 150 of 200/.test(found), found)
    evidence.c2 = { total: val.total, count: val.count, found }
  }

  // ---------------- C.3 网页抓取封顶 ----------------
  console.log('# C.3 网页抓取封顶：60KB HTML → lean 截到 webFetchMaxChars(48KB)')
  {
    const fakeFs = createFakeFs(initial)
    const { executor } = buildExecutor(fakeFs)
    modes.setMode('lean')
    const r = await executor.run({ toolId: 'net.fetch', args: { url: 'http://example.com/p.html' }, origin: 'accept' })
    const val = r.value || {}
    const len = val.text ? val.text.length : 0
    // 以模式实际封顶值为准（lean 的 webFetchMaxChars = 48000），而非 48*1024；截断后缀最多几十字符。
    const fetchCap = modes.capOf('webFetchMaxChars')
    check('抓取成功', r.ok === true)
    check('原始长度=60KB', val.bytes === 60 * KB, `bytes=${val.bytes}`)
    check('lean 截到 ≤ cap(≈48KB)', len <= fetchCap + 512 && len >= fetchCap - 500, `len=${len} cap=${fetchCap}`)
    check('标记 truncated', val.truncated === true)
    evidence.c3 = { rawBytes: val.bytes, truncatedLen: len, truncated: val.truncated, cap: fetchCap }
  }

  // ---------------- C.4 readonly 写盘被拒 + 审计 ----------------
  console.log('# C.4 readonly 写盘被拒且审计；切回 standard 写入成功')
  {
    const fakeFs = createFakeFs(initial)
    const { executor } = buildExecutor(fakeFs)

    modes.setMode('readonly')
    const rDeny = await executor.run({ toolId: 'fs.write', args: { path: 'project:out.txt', content: 'secret' }, origin: 'accept' })
    const readonlyNoWrite = !fakeFs.existsSync(outPath) // 在 standard 写入之前取值，作为只读档未落盘的真凭据
    check('readonly 写盘被拒', rDeny.ok === false && rDeny.denied === true, JSON.stringify(rDeny.error))
    check('拒绝码 = E_MODE_READONLY', rDeny.error && rDeny.error.code === 'E_MODE_READONLY', rDeny.error && rDeny.error.code)
    check('readonly 未真正落盘', readonlyNoWrite)
    check('拒绝已落审计（含 E_MODE_READONLY）', auditRows.some((a) => a.code === 'E_MODE_READONLY'), JSON.stringify(auditRows.map((a) => a.code)))

    modes.setMode('standard')
    const rOk = await executor.run({ toolId: 'fs.write', args: { path: 'project:out.txt', content: 'hello' }, origin: 'accept' })
    check('standard 写盘成功', rOk.ok === true, JSON.stringify(rOk.error || ''))
    check('standard 已落盘', fakeFs.existsSync(outPath) && fakeFs.readFileSync(outPath).toString('utf8') === 'hello')
    evidence.c4 = {
      readonlyDenied: rDeny.ok !== true,
      readonlyCode: rDeny.error && rDeny.error.code,
      readonlyNoWrite,
      standardWritten: rOk.ok === true && fakeFs.existsSync(outPath),
    }
  }

  // ---------------- C.5 切换审计 ----------------
  console.log('# C.5 三次切换 → data/logs/mode.jsonl 增 3 行')
  {
    const before = countModeLogLines()
    modes.setMode('lean')
    modes.setMode('readonly')
    modes.setMode('standard')
    const after = countModeLogLines()
    check('mode.jsonl 增 3 行', after - before === 3, `before=${before} after=${after}`)
    evidence.c5 = { before, after, delta: after - before }
  }

  // ---- 收尾：回填 standard，不留非默认状态 ----
  modes.setMode('standard')

  const out = { ok: fail === 0, pass, fail, evidence }
  const evidencePath = join(PROJECT_ROOT, 'data', 'logs', 's22-modes-accept.json')
  const { mkdirSync, writeFileSync } = await import('node:fs')
  mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
  writeFileSync(evidencePath, JSON.stringify(out, null, 2), 'utf8')
  console.log(`# accept-s22-modes: total=${pass + fail} pass=${pass} fail=${fail}`)
  console.log(`# 证据已落盘：${evidencePath}`)
  process.exit(fail ? 1 : 0)
}

main().catch((e) => { console.error('FATAL', e); process.exit(1) })
