// tools/check-demo-leak.mjs —— S52·P0-1 护栏：库里/交付物里不许再出现 demo 标记
//
// 单行执行：node tools\check-demo-leak.mjs
// 命中即退出码 1（可接进 run-tests 前置）。
//
// 为什么要有它：S52 发现 4 条 claim 全是 demo（文本自带「演示加速」「虚构的 DOI」），
// 用户会误以为是自己的学习成果、评委会直接质疑真实性。清库只解决当下，
// 护栏保证"以后谁再把 demo 写进真实库"能立刻被发现。

import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs'
import { join, dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { DatabaseSync } from 'node:sqlite'

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const DB = join(ROOT, 'data', 'db', 'orb.sqlite')
const MARKS = ['演示加速', '虚构的 DOI']
const hits = []

// 1) 数据库
if (existsSync(DB)) {
  try {
    const db = new DatabaseSync(DB, { readOnly: true })
    for (const r of db.prepare('SELECT id, text FROM claim').all()) {
      for (const m of MARKS) if (String(r.text || '').includes(m)) hits.push(`claim ${r.id} 含「${m}」`)
    }
    db.close()
  } catch (e) {
    console.error('[demo-leak] 库读取失败（可能应用正在运行）：' + (e && e.message))
  }
}

// 2) 交付到笔记库的 md（演示稿会进 vault）
const vault = join(ROOT, 'data', 'vault')
if (existsSync(vault)) {
  const walk = (d) => {
    for (const e of readdirSync(d, { withFileTypes: true })) {
      const p = join(d, e.name)
      if (e.isDirectory()) { walk(p); continue }
      if (!/\.md$/i.test(e.name)) continue
      try {
        const t = readFileSync(p, 'utf8')
        for (const m of MARKS) if (t.includes(m)) hits.push(`${p.replace(ROOT, '')} 含「${m}」`)
      } catch { /* 读不了就跳过 */ }
    }
  }
  walk(vault)
}

if (hits.length === 0) {
  console.log('[demo-leak] PASS：数据库与 vault 中均无 demo 标记')
  process.exit(0)
}
console.error('[demo-leak] FAIL：发现 ' + hits.length + ' 处 demo 混入')
for (const h of hits.slice(0, 20)) console.error('   ' + h)
process.exit(1)
