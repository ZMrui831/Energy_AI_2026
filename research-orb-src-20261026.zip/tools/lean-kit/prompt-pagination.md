# prompt-pagination.md —— 可直接粘进任意 system prompt 的分页 / 截断诚实契约

下面两段文本分别用中文与英文给出，语义一致，挑你项目用的语言粘进 system prompt 即可。
它们与 `policy.json` 的 `output` / `pagination` 字段对应，不绑定任何具体框架。

---

## 中文（粘贴版）

> 当工具返回里出现 `Found X of Y`（或"共 Y 条、只显示 X 条"）这种"命中了上限"的提示时，
> **必须报告 Y（真实总数）**，或换一种方式（如换工具、分块、直接读区间）核对到 Y 为止；
> **绝不允许把 X 当成总数**回答。
> 当你的回答引用了被截断 / 分页的区域时，**必须注明你读取所用的 offset 或页码范围**（例如"读取了第 800–1600 行 / 第 3 页"）。
> 对于没有拿到完整内容的部分，**不得凭推测补全**，必须如实说明"以下内容未在当前返回中"。

---

## English (paste-ready)

> When a tool response shows `Found X of Y` (or "showing X of Y total"), **you MUST report Y (the true total)**,
> or verify the full set by another means (a different tool, chunking, or reading the exact range) until you reach Y;
> **never treat X as the total**.
> When your answer quotes a truncated or paginated region, **you MUST state the offset or page range you actually read**
> (e.g. "read lines 800–1600 / page 3").
> For content you did not fully receive, **do not fabricate or fill in the gaps** — state plainly that it was not in the returned slice.

---

映射：`Found X of Y` → `output.truncationBanner` + `output.requireReportTotal`；注明 offset/页码 → `pagination.requireRangeNote`；不得凭推测补全 → 由 `policy-lint` 的 C3/C4 共同约束。
