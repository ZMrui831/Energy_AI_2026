# kit · 与框架无关的「省钱契约」套件

> 本套规则翻译自一份现成的 agent 配置模式包：它的封顶数字（64KB / grep 150 / web 48000 / 工具结果 16384）
> 正是本 kit 的灵感来源。但这里**不依赖那个模式包、不依赖任何 agent 框架**——规则用纯 JSON 表达，用零依赖的 Node 脚本判定。

## 这是什么

一套把"省钱 / 防踩坑"的**六条契约**变成**可判定件**的最小工具集：

1. 工具表受限（C1）—— 工具数量封顶，避免 prompt 被工具清单撑爆
2. 输出封顶（C2）—— 单工具返回字节 / 行数上限
3. 截断诚实（C3）—— 命中上限时**必须报真实总数**，不得把上限当答案
4. 分页契约（C4）—— 引用截断区必须注明 offset / 页码
5. 压缩阈值（C5）—— 上下文压缩的触发与保留比例
6. 子代理隔离（C6）—— 子代理只读、深度受限
7. 限流（C7）—— 每分钟请求数与突发
8. 遥测（C8）—— 必须采集的用量字段

外加一条**观测契约（E1）**：用真实调用日志验证"截断时是否真的报了总数"。

## 3 分钟上手

**第一步：写 `policy.json`**

直接复制 `policy.example.json`，按你的场景改数字。字段名照抄，别自创。

**第二步：跑 lint，看哪里不达标**

```bash
node kit/policy-lint.mjs --policy kit/policy.example.json
```

输出一张表：`ID | 契约 | 判定 | 证据 | 修复建议`。
`FAIL` 会明确告诉你**改哪个字段、改成什么**；`UNVERIFIED` 表示需要你再给 `--agent-config` 或 `--observed` 才能判定。

**第三步：按 FAIL 改，直到全绿**

```bash
# 核对真实工具数（C1）
node kit/policy-lint.mjs --policy p.json --agent-config agent.json
# 用真实调用日志验证截断诚实（E1）
node kit/policy-lint.mjs --policy p.json --observed calls.jsonl
```

可选：把 `kit/eval/summarize-calls.mjs` 喂一份 `calls.jsonl`，一键汇总截断率、上报率、token 成本代理。

## 与「模式包」的关系

语义同源，工具独立。模式包里那些"封顶数字"被原样搬进 `policy.example.json`；
但判定逻辑（`policy-lint.mjs`）只吃 JSON，不读任何框架的 schema，所以你用 OpenAI / Anthropic / LangChain / 自建 ReAct 都能跑。
怎么挂到具体框架，看 `portability.md`。

## 不适用场景

- 需要**精读大文件中段**且不能靠 offset 定向（那是另一类问题，本套件只保证"截断时诚实"，不保证"自动读全"）。
- 需要**多级子代理编排**（C6 只约束 depth=1 的浅层隔离；深树编排请用专门编排框架）。
- 需要把"省钱契约"写进训练 / 微调——本套件是**运行时判定**，不是训练数据。

## 文件清单

- `policy.schema.json` —— policy.json 的 JSON Schema（draft-07 子集）
- `policy.example.json` —— 示例（翻译自模式包封顶数字）
- `policy-lint.mjs` —— 核心：C1–C8 + E1 可判定器（零依赖）
- `prompt-pagination.md` —— 可直接粘进 system prompt 的中文 / 英文契约文本
- `portability.md` —— 8 个框架的挂载点对照表
- `eval/summarize-calls.mjs` + `eval/sample.jsonl` —— 观测日志汇总与样例
