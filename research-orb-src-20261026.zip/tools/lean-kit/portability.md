# portability.md —— 六条契约如何挂到主流框架

每一行给出：框架的**挂载点**、对应的 **policy 字段**、以及一行可粘贴片段（≤3 行）。
片段是伪代码，落到你的代码里替换变量名即可；所有片段都引用 `policy.json` 里的同名字段。

| 框架 | 挂载点 | 对应 policy 字段 | 一行可粘贴片段 |
|---|---|---|---|
| OpenAI（Responses/Assistants） | 构造请求时 | tools.maxTools, output.capBytes | `tools = pick(tools, policy.tools.maxTools); if (resp.truncated) emit(policy.output.truncationBanner)` |
| Anthropic（Messages） | 系统提示 + max_tokens | output.capBytes, telemetry | `system += PAGINATION_RULE; body.max_tokens = policy.output.capBytes` |
| LangChain | bindTools 之前 | tools.maxTools | `llm.bindTools(tools.slice(0, policy.tools.maxTools))` |
| LangGraph | subgraph 节点 | subagent.readonly, subagent.maxDepth | `subgraph(readonly=policy.subagent.readonly, depth<=policy.subagent.maxDepth)` |
| MCP | tools/list 过滤 | tools.denylist, tools.maxTools | `tools = tools.filter(t=>!policy.tools.denylist.includes(t.name)).slice(0,policy.tools.maxTools)` |
| vLLM · Ollama（经代理） | 代理层 | output.capBytes, rateLimit | `proxy.maxTokens=policy.output.capBytes; proxy.rpm=policy.rateLimit.requestsPerMinute` |
| n8n | Function 节点 | rateLimit, output.capBytes | `if (calls>policy.rateLimit.burst) return wait(); out=out.slice(0,policy.output.capBytes)` |
| 自建 ReAct 循环 | 主循环 | 全部字段 | `if (truncated) reportTotal(); if (depth>policy.subagent.maxDepth) stop()` |

注：分页模式（`pagination.mode`）按框架能力选 `offset`（读区间）/ `page`（页码）/ `cursor`（游标）；
子代理隔离（`subagent.readonly`/`maxDepth`）只有在框架支持派生子代理时才生效，否则该条标记为不适用。
