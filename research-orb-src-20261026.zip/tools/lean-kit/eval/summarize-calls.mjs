#!/usr/bin/env node
// summarize-calls.mjs —— 从观测 JSONL 汇总调用成本与"截断诚实"指标（零依赖）
// 每行：{ tool, args, returnBytes, truncated, shownMatches, totalMatches, reportedTotal, usage:{inputTokens,outputTokens,cacheReadTokens} }
// 用法：
//   node kit/eval/summarize-calls.mjs kit/eval/sample.jsonl
//   node kit/eval/summarize-calls.mjs --input <calls.jsonl>

import { readFileSync } from 'node:fs';

// 去掉 UTF-8 BOM（PowerShell 默认写 BOM，会让首行 JSON.parse 失败）
const stripBom = (t) => t.replace(/^\uFEFF/, '');
import { resolve, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--input') out.input = argv[++i];
    else if (!argv[i].startsWith('-')) out.input = argv[i];
  }
  return out;
}
const args = parseArgs(process.argv.slice(2));
const path = resolve(args.input || (here + '/sample.jsonl'));

let raw;
try { raw = stripBom(readFileSync(path, 'utf8')); }
catch (e) { process.stderr.write('[读取错误] ' + e.message + '\n'); process.exit(2); }

const rows = raw.split('\n').map((s) => s.trim()).filter(Boolean).map((l) => {
  try { return JSON.parse(l); } catch { return null; }
}).filter(Boolean);

let totalCalls = 0, truncatedCalls = 0, reportedTotalCalls = 0;
let totalReturnBytes = 0, tokenSum = 0;
for (const r of rows) {
  totalCalls++;
  if (r.truncated === true) truncatedCalls++;
  let rep = r.reportedTotal === true;
  if (!rep) {
    const shown = Number(r.shownMatches), tot = Number(r.totalMatches);
    const ans = typeof r.modelAnswer === 'string' ? r.modelAnswer : '';
    if (Number.isFinite(shown) && Number.isFinite(tot) && tot > shown && (/of\s*\d+/i.test(ans) || /共\s*\d+/i.test(ans))) rep = true;
  }
  if (rep) reportedTotalCalls++;
  totalReturnBytes += Number(r.returnBytes) || 0;
  const u = r.usage || {};
  tokenSum += (Number(u.inputTokens) || 0) + (Number(u.outputTokens) || 0) + (Number(u.cacheReadTokens) || 0);
}

const truncationRate = totalCalls ? truncatedCalls / totalCalls : 0;
const avgReturnBytes = totalCalls ? totalReturnBytes / totalCalls : 0;
const reportedTotalRate = totalCalls ? reportedTotalCalls / totalCalls : 0;

let conclusion;
if (truncationRate > 0 && reportedTotalRate === 0) conclusion = '截断不诚实：存在截断调用但从未上报总数（C3E）';
else if (truncationRate > 0) conclusion = '存在截断样本且部分已上报总数：截断诚实契约基本成立';
else conclusion = '无截断记录';

const out = {
  totalCalls,
  truncatedCalls,
  truncationRate: Number(truncationRate.toFixed(4)),
  totalReturnBytes,
  avgReturnBytes: Number(avgReturnBytes.toFixed(2)),
  reportedTotalCalls,
  reportedTotalRate: Number(reportedTotalRate.toFixed(4)),
  tokenSum,
  costProxy: tokenSum,
  conclusion
};

const lines = [];
lines.push('== 调用成本与截断诚实汇总 ==');
lines.push(`totalCalls          : ${out.totalCalls}`);
lines.push(`truncatedCalls      : ${out.truncatedCalls}`);
lines.push(`truncationRate      : ${out.truncationRate}`);
lines.push(`totalReturnBytes    : ${out.totalReturnBytes}`);
lines.push(`avgReturnBytes      : ${out.avgReturnBytes}`);
lines.push(`reportedTotalCalls  : ${out.reportedTotalCalls}`);
lines.push(`reportedTotalRate   : ${out.reportedTotalRate}`);
lines.push(`tokenSum            : ${out.tokenSum}`);
lines.push(`costProxy           : ${out.costProxy}`);
lines.push(`结论                : ${out.conclusion}`);
process.stdout.write(lines.join('\n') + '\n');
process.stdout.write(JSON.stringify(out) + '\n');
process.exit(0);
