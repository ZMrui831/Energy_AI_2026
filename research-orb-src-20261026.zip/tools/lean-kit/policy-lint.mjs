#!/usr/bin/env node
// policy-lint.mjs —— 与框架无关的「省钱契约」可判定器（零依赖，仅用 Node 内置模块）
//
// 用法：
//   node kit/policy-lint.mjs --policy kit/policy.example.json
//   node kit/policy-lint.mjs --policy <p.json> --agent-config <agent.json>
//   node kit/policy-lint.mjs --policy <p.json> --observed <calls.jsonl>
//
// 退出码：存在 FAIL → 1；全 PASS 或含 UNVERIFIED → 0；参数/读取错误 → 2。
//
// 设计约束：不 require 任何第三方；不绑定任何 agent 框架；纯 JSON 输入。

import { readFileSync } from 'node:fs';

// 去掉 UTF-8 BOM：Windows/PowerShell 默认写 BOM，JSON.parse 会直接抛错（实测会把 C1 降级成 UNVERIFIED）。
const stripBom = (s) => s.replace(/^\uFEFF/, '');
import { resolve } from 'node:path';

const USAGE = `用法：
  node kit/policy-lint.mjs --policy <policy.json>
  node kit/policy-lint.mjs --policy <p.json> --agent-config <agent.json>
  node kit/policy-lint.mjs --policy <p.json> --observed <calls.jsonl>

每条契约输出 PASS / FAIL / UNVERIFIED；FAIL 会给出"改哪个字段、改成什么"。
JSON 汇总行与退出码见文末。`;

function die(msg) {
  process.stderr.write('[参数/读取错误] ' + msg + '\n');
  process.exit(2);
}

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--policy') out.policy = argv[++i];
    else if (a === '--agent-config') out.agentConfig = argv[++i];
    else if (a === '--observed') out.observed = argv[++i];
    else if (a === '-h' || a === '--help') out.help = true;
  }
  return out;
}

function g(obj, ...keys) {
  let cur = obj;
  for (const k of keys) {
    if (cur == null) return undefined;
    cur = cur[k];
  }
  return cur;
}

// ---- agent-config 工具计数（兼容多种形态：数组 / .tools[] / .functions[] / 数字） ----
function countTools(ac) {
  if (ac == null) return null;
  if (Array.isArray(ac)) return ac.length;
  if (Array.isArray(ac.tools)) return ac.tools.length;
  if (Array.isArray(ac.functions)) return ac.functions.length;
  if (typeof ac.tools === 'number') return ac.tools;
  if (typeof ac.tool_count === 'number') return ac.tool_count;
  return null;
}
function listToolNames(ac) {
  let arr = null;
  if (Array.isArray(ac)) arr = ac;
  else if (Array.isArray(ac.tools)) arr = ac.tools;
  else if (Array.isArray(ac.functions)) arr = ac.functions;
  if (!arr) return [];
  return arr
    .map((t) => (typeof t === 'string' ? t : (t && (t.name || (t.function && t.function.name))) || null))
    .filter(Boolean);
}

// ============ 检查定义 ============
// 每个 check 返回 { verdict, evidence, fix } 或 null（表示跳过，例如未给 --observed 时的 E1）
const CHECKS = [
  {
    id: 'C1', title: '工具表受限',
    run: (policy, args) => {
      const maxTools = g(policy, 'tools', 'maxTools');
      if (!(typeof maxTools === 'number' && maxTools > 0))
        return { verdict: 'FAIL', evidence: `tools.maxTools=${JSON.stringify(maxTools)}（应为正整数）`, fix: '将 tools.maxTools 设为 >0 的整数（例如 13）。' };
      if (!args.agentConfig)
        return { verdict: 'UNVERIFIED', evidence: `tools.maxTools=${maxTools}；未提供 --agent-config，无法核对实际工具数`, fix: '传入 --agent-config <agent.json> 以比对真实工具数量。' };
      let ac;
      try { ac = JSON.parse(stripBom(readFileSync(resolve(args.agentConfig), 'utf8'))); }
      catch (e) { return { verdict: 'UNVERIFIED', evidence: `无法读取 agent-config：${e.message}`, fix: '确认 --agent-config 路径与 JSON 合法性。' }; }
      const used = countTools(ac);
      if (used == null)
        return { verdict: 'UNVERIFIED', evidence: 'agent-config 结构无法识别工具数（需含 tools[] / functions[]，或本身就是数组）', fix: '让 agent 配置暴露工具数组，或改用 --observed 观测。' };
      if (used <= maxTools)
        return { verdict: 'PASS', evidence: `实际工具数=${used} <= maxTools=${maxTools}`, fix: '' };
      const names = listToolNames(ac);
      const overflow = names.length ? names : [`(共 ${used} 个，未提供名称)`];
      return { verdict: 'FAIL', evidence: `实际工具数=${used} > maxTools=${maxTools}`, fix: `裁掉超出部分，使工具数 <= ${maxTools}；当前工具：${overflow.join(', ')}。` };
    }
  },
  {
    id: 'C2', title: '输出封顶',
    run: (policy) => {
      const capBytes = g(policy, 'output', 'capBytes');
      if (!(typeof capBytes === 'number' && capBytes > 0 && capBytes <= 262144))
        return { verdict: 'FAIL', evidence: `output.capBytes=${JSON.stringify(capBytes)}（须 0<capBytes<=262144）`, fix: '将 output.capBytes 设为 1..262144 之间（例如 65536）。' };
      const capLines = g(policy, 'output', 'capLines');
      if (capLines !== undefined && !(typeof capLines === 'number' && capLines > 0))
        return { verdict: 'FAIL', evidence: `output.capLines=${JSON.stringify(capLines)}（若存在须 >0）`, fix: '将 output.capLines 设为正整数（例如 800），或删除该字段。' };
      return { verdict: 'PASS', evidence: `capBytes=${capBytes}${capLines !== undefined ? `; capLines=${capLines}` : ''}`, fix: '' };
    }
  },
  {
    id: 'C3', title: '截断诚实',
    run: (policy) => {
      const banner = g(policy, 'output', 'truncationBanner');
      const req = g(policy, 'output', 'requireReportTotal');
      const hasToken = typeof banner === 'string' && (/of/i.test(banner) || banner.includes('共'));
      if (!hasToken)
        return { verdict: 'FAIL', evidence: `truncationBanner=${JSON.stringify(banner)}（须含 'of' 或 '共'）`, fix: '让 truncationBanner 含总数占位，例如 "Found {shown} of {total}"。' };
      if (req !== true)
        return { verdict: 'FAIL', evidence: `requireReportTotal=${JSON.stringify(req)}（须为 true）`, fix: '将 output.requireReportTotal 设为 true，强制截断时上报总数。' };
      return { verdict: 'PASS', evidence: `banner 含总数标记（${JSON.stringify(banner)}）且 requireReportTotal=true`, fix: '' };
    }
  },
  {
    id: 'C4', title: '分页契约',
    run: (policy) => {
      const mode = g(policy, 'pagination', 'mode');
      const note = g(policy, 'pagination', 'requireRangeNote');
      const okMode = ['offset', 'page', 'cursor'].includes(mode);
      if (!okMode)
        return { verdict: 'FAIL', evidence: `pagination.mode=${JSON.stringify(mode)}（须为 offset/page/cursor）`, fix: '将 pagination.mode 设为 offset（推荐）/page/cursor。' };
      if (note !== true)
        return { verdict: 'FAIL', evidence: `pagination.requireRangeNote=${JSON.stringify(note)}（须为 true）`, fix: '将 pagination.requireRangeNote 设为 true，要求引用截断区时注明范围。' };
      return { verdict: 'PASS', evidence: `mode=${mode}; requireRangeNote=true`, fix: '' };
    }
  },
  {
    id: 'C5', title: '压缩阈值',
    run: (policy) => {
      const t = g(policy, 'compaction', 'thresholdRatio');
      const r = g(policy, 'compaction', 'retainRatio');
      const h = g(policy, 'compaction', 'headroomTokens');
      if (!(typeof t === 'number' && t > 0 && t < 1))
        return { verdict: 'FAIL', evidence: `thresholdRatio=${JSON.stringify(t)}（须 0<t<1）`, fix: '将 compaction.thresholdRatio 设为 (retainRatio,1) 之间（例如 0.8）。' };
      if (!(typeof r === 'number' && r > 0 && r < t))
        return { verdict: 'FAIL', evidence: `retainRatio=${JSON.stringify(r)}（须 0<retainRatio<thresholdRatio=${t}）`, fix: `将 compaction.retainRatio 设为 (0,${t}) 之间（例如 ${Math.round(t * 0.25 * 100) / 100}）。` };
      if (!(typeof h === 'number' && h > 0))
        return { verdict: 'FAIL', evidence: `headroomTokens=${JSON.stringify(h)}（须 >0）`, fix: '将 compaction.headroomTokens 设为正整数（例如 4096）。' };
      return { verdict: 'PASS', evidence: `threshold=${t}; retain=${r}; headroom=${h}`, fix: '' };
    }
  },
  {
    id: 'C6', title: '子代理隔离',
    run: (policy) => {
      const ro = g(policy, 'subagent', 'readonly');
      const md = g(policy, 'subagent', 'maxDepth');
      const mo = g(policy, 'subagent', 'maxOutputTokens');
      if (ro !== true)
        return { verdict: 'FAIL', evidence: `subagent.readonly=${JSON.stringify(ro)}（须 true）`, fix: '将 subagent.readonly 设为 true，禁止子代理写操作。' };
      if (md !== 1)
        return { verdict: 'FAIL', evidence: `subagent.maxDepth=${JSON.stringify(md)}（须 1）`, fix: '将 subagent.maxDepth 设为 1，限制子代理不再派生子代理。' };
      if (!(typeof mo === 'number' && mo >= 1024 && mo <= 16384))
        return { verdict: 'FAIL', evidence: `subagent.maxOutputTokens=${JSON.stringify(mo)}（须 1024..16384）`, fix: '将 subagent.maxOutputTokens 设为 1024..16384 之间（例如 8192）。' };
      return { verdict: 'PASS', evidence: `readonly=true; maxDepth=1; maxOutputTokens=${mo}`, fix: '' };
    }
  },
  {
    id: 'C7', title: '限流',
    run: (policy) => {
      const rpm = g(policy, 'rateLimit', 'requestsPerMinute');
      const burst = g(policy, 'rateLimit', 'burst');
      if (!(typeof rpm === 'number' && rpm > 0))
        return { verdict: 'FAIL', evidence: `rateLimit.requestsPerMinute=${JSON.stringify(rpm)}（须 >0）`, fix: '将 rateLimit.requestsPerMinute 设为正整数（例如 10）。' };
      if (!(typeof burst === 'number' && burst >= rpm))
        return { verdict: 'FAIL', evidence: `rateLimit.burst=${JSON.stringify(burst)} < requestsPerMinute=${rpm}`, fix: `将 rateLimit.burst 设为 >= ${rpm}（例如 ${rpm * 2}）。` };
      return { verdict: 'PASS', evidence: `rpm=${rpm}; burst=${burst}`, fix: '' };
    }
  },
  {
    id: 'C8', title: '遥测',
    run: (policy) => {
      const fields = g(policy, 'telemetry', 'fields');
      if (!Array.isArray(fields))
        return { verdict: 'FAIL', evidence: `telemetry.fields=${JSON.stringify(fields)}（须为数组）`, fix: '将 telemetry.fields 设为字段名数组。' };
      const need = ['inputTokens', 'outputTokens', 'toolCalls'];
      const missing = need.filter((f) => !fields.includes(f));
      if (missing.length)
        return { verdict: 'FAIL', evidence: `telemetry.fields=${JSON.stringify(fields)}；缺少 ${missing.join(', ')}`, fix: `在 telemetry.fields 至少加入 ${missing.join(', ')}。` };
      return { verdict: 'PASS', evidence: `fields=${JSON.stringify(fields)}`, fix: '' };
    }
  },
  {
    id: 'E1', title: '观测证据（截断诚实）',
    run: (policy, args) => {
      if (!args.observed) return null; // 未给 --observed 则跳过
      let lines;
      try { lines = stripBom(readFileSync(resolve(args.observed), 'utf8')).split('\n').map((s) => s.trim()).filter(Boolean); }
      catch (e) { return { verdict: 'FAIL', evidence: `无法读取 --observed 文件：${e.message}`, fix: '确认 --observed 路径与 JSONL 合法。' }; }
      let total = 0, truncated = 0, reported = 0;
      for (const ln of lines) {
        let row;
        try { row = JSON.parse(ln); } catch { continue; }
        total++;
        if (row.truncated === true) truncated++;
        let isReported = row.reportedTotal === true;
        if (!isReported) {
          const shown = Number(row.shownMatches);
          const tot = Number(row.totalMatches);
          const ans = typeof row.modelAnswer === 'string' ? row.modelAnswer : '';
          if (Number.isFinite(shown) && Number.isFinite(tot) && tot > shown && (/of\s*\d+/i.test(ans) || /共\s*\d+/i.test(ans)))
            isReported = true;
        }
        if (isReported) reported++;
      }
      if (total === 0)
        return { verdict: 'FAIL', evidence: '观测文件无有效行', fix: '提供含调用记录的 JSONL。' };
      if (truncated > 0 && reported === 0)
        return { verdict: 'FAIL', evidence: `截断调用 ${truncated}/${total}，但上报总数 0 → C3E（截断却从不报总数）`, fix: '在截断时输出总数（如 "Found X of Y"），或换法核对到 Y。' };
      return { verdict: 'PASS', evidence: `截断调用 ${truncated}/${total}；上报总数 ${reported}；截断诚实契约成立`, fix: '' };
    }
  }
];

// ============ 主流程 ============
const args = parseArgs(process.argv.slice(2));
if (args.help) { process.stdout.write(USAGE + '\n'); process.exit(0); }
if (!args.policy) die('缺少必需参数 --policy <policy.json>');

let policy;
try { policy = JSON.parse(stripBom(readFileSync(resolve(args.policy), 'utf8'))); }
catch (e) { die(`无法读取/解析 policy 文件 ${args.policy}：${e.message}`); }

const checks = [];
let pass = 0, fail = 0, unverified = 0;
for (const c of CHECKS) {
  const r = c.run(policy, args);
  if (r == null) continue; // 跳过的（如未给 --observed 的 E1）
  checks.push({ id: c.id, title: c.title, verdict: r.verdict, evidence: r.evidence, fix: r.fix });
  if (r.verdict === 'PASS') pass++;
  else if (r.verdict === 'FAIL') fail++;
  else unverified++;
}

// ---- 人类可读表格 ----
const lines = [];
lines.push('ID   契约                判定          证据');
lines.push('---- -------------------- ------------ ----------------------------------------');
for (const c of checks) {
  const id = c.id.padEnd(4);
  const title = c.title.padEnd(18);
  const verdict = c.verdict.padEnd(12);
  lines.push(`${id} ${title} ${verdict} ${c.evidence}`);
  if (c.verdict === 'FAIL' && c.fix) lines.push(`     └ 修复：${c.fix}`);
}
lines.push('');
const ok = fail === 0;
lines.push(`汇总：PASS=${pass}  FAIL=${fail}  UNVERIFIED=${unverified}  → ${ok ? 'OK（无 FAIL）' : '存在 FAIL'}`);
process.stdout.write(lines.join('\n') + '\n');

// ---- JSON 汇总 ----
const summary = { ok, pass, fail, unverified, checks };
process.stdout.write(JSON.stringify(summary) + '\n');

process.exit(ok ? 0 : 1);
