// tools/check-imports.mjs
// 目的：一次抓出"相对 import 路径写错"这类致命错误（node --check 不解析路径，抓不到）
// 用法：node tools/check-imports.mjs        （可用作测试：import { checkImports } from ...）
import { readdirSync, readFileSync, statSync, existsSync } from 'node:fs'
import { join, dirname, resolve as presolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const PROJECT_ROOT = presolve(dirname(fileURLToPath(import.meta.url)), '..')
// S74c：排除运行期临时/备份目录（worker 曾在 data\tmp 留 tools-backup-*，
// 导致备份副本的 ../packages 相对 import 全部假红、扫描数 478→738）
const SKIP_DIR = /(^|[\\/])(node_modules|\.snapshots|\.venv|\.chromium|\.retired|backups|dist-packag|tmp|tools-backup[^\\/]*|.*-backup[^\\/]*)([\\/]|$)/
const CODE_EXT = /\.(mjs|js|cjs)$/
const PATTERNS = [
  /from\s+['"]([^'"]+)['"]/g,
  /import\(\s*['"]([^'"]+)['"]\s*\)/g,
  /require\(\s*['"]([^'"]+)['"]\s*\)/g,
]

function candidates(target) {
  if (existsSync(target) && statSync(target).isFile()) return true
  for (const guess of [target + '.mjs', target + '.js', target + '.cjs', join(target, 'index.mjs'), join(target, 'index.js')]) {
    if (existsSync(guess) && statSync(guess).isFile()) return true
  }
  return false
}

// S74c：跳过一次性/临时脚本（\_ 前缀）——它们的注释里常有示例 import（\'...\'），
// 会让护栏假红（工人 S74c 的 _migrate-import-v2.mjs 实测 2 处假失败）。
const SKIP_FILE = /^_/

function walk(dir, out = []) {
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const full = join(dir, entry.name)
    if (entry.isDirectory()) { if (!SKIP_DIR.test(full)) walk(full, out); continue }
    if (SKIP_FILE.test(entry.name)) continue
    if (CODE_EXT.test(entry.name)) out.push(full)
  }
  return out
}

export function checkImports(root = PROJECT_ROOT) {
  const files = walk(root)
  const failures = []
  for (const file of files) {
    const text = readFileSync(file, 'utf8')
    for (const re of PATTERNS) {
      re.lastIndex = 0
      let m
      while ((m = re.exec(text)) !== null) {
        const spec = m[1]
        if (!spec.startsWith('.')) continue            // 裸模块名（node:xxx / npm 包）不检查
        const target = presolve(dirname(file), spec)
        if (!candidates(target)) failures.push({ file: file.replace(root, ''), spec, resolved: target.replace(root, '') })
      }
    }
  }
  return { scanned: files.length, failures }
}

const isMain = process.argv[1] && process.argv[1].replace(/\\/g, '/').endsWith('tools/check-imports.mjs')
if (isMain) {
  const { scanned, failures } = checkImports()
  console.log('[check-imports] 扫描 ' + scanned + ' 个文件，相对 import 解析失败 ' + failures.length + ' 处')
  for (const f of failures) console.log('  FAIL ' + f.file + '  ->  ' + f.spec + '   (解析到 ' + f.resolved + ')')
  process.exit(failures.length === 0 ? 0 : 1)
}