// tools/check-anonymity.mjs —— 提交物匿名自检（比赛扣分项：出现校名/院名/姓名/导师/团队/吉祥物名 −15 分）
// 用法：node tools/check-anonymity.mjs [文件或目录...]
//   缺省扫描"必须干净"的提交物（REQUIRED）；README 等内部文档作 INFORMATIONAL 仅提示不判失败。
import { readFileSync, existsSync, statSync, readdirSync } from 'node:fs'
import { join, extname } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'

const DEFAULTS = [
  '上海交通大学', '上海交大', 'SJTU', '交大', '电子信息与电气工程学院', '电院', '能源学院',
  '能小猿', '指导教师', '指导老师', '团队名称', '队名',
  '54958', '张茂瑞', '茂瑞', '贾添翔', '卢达鑫', '徐新星', /* allow-hardcoded: 脱敏检测词表/基准，非路径引用 */
  '贾维斯', '萌源', 'dsh-orb', 'school-gateway', '学校网关',
  'C:\\Users', 'D:\\explorer', 'wxid_'
]
const denyPath = join(PROJECT_ROOT, 'data', 'anonymity-deny.txt')
let words = existsSync(denyPath)
  ? readFileSync(denyPath, 'utf8').split(/\r?\n/).map((s) => s.trim()).filter(Boolean)
  : [...DEFAULTS]

// package.json 的 author 值：一旦存在就视同禁用词（不得出现在任何提交物/上镜界面）
try {
  const pkg = JSON.parse(readFileSync(join(PROJECT_ROOT, 'package.json'), 'utf8'))
  if (pkg.author) {
    const author = typeof pkg.author === 'string' ? pkg.author : JSON.stringify(pkg.author)
    if (author.trim()) { words.push(author.trim()); console.log('[anonymity] 注意：package.json.author = "' + author + '" 已纳入禁用词') }
  }
} catch { /* 无 package.json 则跳过 */ }

// 必须干净：命中即 FAIL（exit 1）
const REQUIRED = [
  'AI-使用说明.md',
  'data/reports/record-demo.srt',
  'docs/案例正文-初稿.md',
  'docs/AI-使用声明.md'
]
// 内部文档：命中仅提示（这些文件不得提交、不得上镜），不导致失败
const INFORMATIONAL = ['README.md']

const exts = new Set(['.md', '.txt', '.srt', '.html', '.htm', '.json', '.mjs', '.js', '.css'])
function walk(p, out = []) {
  if (!existsSync(p)) return out
  const st = statSync(p)
  if (st.isDirectory()) { for (const n of readdirSync(p)) walk(join(p, n), out); return out }
  if (exts.has(extname(p).toLowerCase())) out.push(p)
  return out
}
function scan(files) {
  const hits = []
  for (const f of files) {
    let text = ''
    try { text = readFileSync(f, 'utf8') } catch { continue }
    text.split(/\r?\n/).forEach((line, i) => {
      for (const w of words) {
        if (!w || !line.includes(w)) continue
        hits.push({ file: f.replace(PROJECT_ROOT, ''), line: i + 1, word: w, ctx: line.slice(0, 100) })
      }
    })
  }
  return hits
}

const args = process.argv.slice(2)
const requiredFiles = (args.length ? args : REQUIRED).map((p) => join(PROJECT_ROOT, p)).flatMap((p) => walk(p))
const infoFiles = INFORMATIONAL.map((p) => join(PROJECT_ROOT, p)).flatMap((p) => walk(p))

console.log('[anonymity] 必须干净目标 ' + requiredFiles.length + ' 个，禁用词 ' + words.length + ' 条')
const reqHits = scan(requiredFiles)
const infoHits = scan(infoFiles)
if (infoHits.length) {
  console.log('[anonymity] 内部文档提示（不导致失败，但这些文件不得提交/上镜）：' + infoHits.length + ' 处')
  const byFile = new Map()
  for (const h of infoHits) { if (!byFile.has(h.file)) byFile.set(h.file, []); byFile.get(h.file).push(h) }
  for (const [file, list] of byFile) {
    console.log('  ' + file + '（' + list.length + ' 处，如 README）')
    for (const h of list.slice(0, 3)) console.log('    L' + h.line + '  [' + h.word + ']  ' + h.ctx)
  }
}
if (reqHits.length) {
  console.log('[anonymity] FAIL：必须干净目标中命中 ' + reqHits.length + ' 处')
  const byFile = new Map()
  for (const h of reqHits) { if (!byFile.has(h.file)) byFile.set(h.file, []); byFile.get(h.file).push(h) }
  for (const [file, list] of byFile) {
    console.log('  ' + file + '（' + list.length + ' 处）')
    for (const h of list.slice(0, 5)) console.log('    L' + h.line + '  [' + h.word + ']  ' + h.ctx)
  }
  process.exit(1)
}
console.log('[anonymity] PASS：必须干净目标未发现禁用信息')
