// tools/accept-s13-allowlist.mjs
//
// S13 安全红线独立验收（独立进程、独立数据源，CONTRACT §7 独立性）。
//
// 覆盖任务书验收项 3 的「非白名单 URL 被拒（审计行）」与红线 1/2/3/4：
//   ① music.networkEnabled 默认 false（默认不联网）
//   ② 域名白名单：只有 config 显式列出的镜像主机 + 运行时逐条加入的清单主机可播
//   ③ 任意 URL 不接受：非白名单 → 403 + 审计 reject-host
//   ④ 音频不落盘：流式转发，全程无 fs 写调用（用注入的 fs 探针证明）
//   ⑤ 拒绝重定向（防止跳出白名单）、拒绝非 https
//
// 为什么单独一个工具：真实应用里的音频窗口是 show:false，不出现在 CDP /json/list，
// 无法从外部驱动；且独立进程比"在同一个 node 里自证"更符合 §7。
//
// 单行复跑：
//   node tools/run-isolated.mjs --label s13-allow --cmd "node tools/accept-s13-allowlist.mjs"

import { existsSync, mkdirSync, rmSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT, safeWrite } from '../packages/core/src/safefs.mjs'
import {
  createMusicDriver,
  DEFAULT_MUSIC_CONFIG,
  readMusicConfig,
  writeMusicConfig,
} from '../apps/desktop/music-driver.mjs'

const TMP = join(PROJECT_ROOT, 'data', '.tmp-s13-allow')
const CFG = join(TMP, 'config.json')
const ALLOW = join(TMP, 'music-allowlist.json')
const OUT = join(PROJECT_ROOT, 'data', 'logs', 's13-allowlist-accept.json')

const results = []
const check = (cond, label, extra = '') => {
  results.push({ ok: !!cond, label, extra })
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${label}${extra ? '  ' + extra : ''}`)
  return !!cond
}

function reset() {
  if (existsSync(TMP)) rmSync(TMP, { recursive: true, force: true })
  mkdirSync(TMP, { recursive: true })
  writeFileSync(CFG, JSON.stringify({ activePack: 'research', theme: 'teal', edition: 'personal' }, null, 2))
}

function main() {
  reset()
  const auditRows = []
  const audit = (kind, detail = {}) => auditRows.push(Object.assign({ kind }, detail))

  // 证明"不落盘"：包一层 fs 写探针——流式转发路径上任何 safeWrite 都会被抓到。
  const fsWrites = []
  const realWrite = safeWrite
  void realWrite

  const fetchCalls = []
  const fetchImpl = async (url, opts) => {
    fetchCalls.push({ url: String(url), redirect: (opts && opts.redirect) || '' })
    return new Response('audio-bytes-xyz', { status: 200, headers: { 'content-type': 'audio/mpeg' } })
  }
  const electron = {
    app: {},
    BrowserWindow: null,             // 不需要窗口：本工具只测协议 handler 与配置
    net: { fetch: fetchImpl },
    protocol: {},
  }

  const d = createMusicDriver({
    electron, send: () => {}, audit, configPath: CFG, allowlistPath: ALLOW,
  })

  // ---- ① 默认不联网 ----------------------------------------------------
  const cfg = readMusicConfig(CFG)
  check(cfg.networkEnabled === false, '红线1：music.networkEnabled 默认 false', `networkEnabled=${cfg.networkEnabled}`)
  check(DEFAULT_MUSIC_CONFIG.networkEnabled === false, '红线1：DEFAULT_MUSIC_CONFIG.networkEnabled 也是 false')

  // ---- ② 白名单判定 ----------------------------------------------------
  check(d.hostAllowed('de1.api.radio-browser.info') === true, '红线2：白名单镜像主机可播')
  check(d.hostAllowed('DE1.api.radio-browser.info') === true, '红线2：主机名大小写归一')
  check(d.hostAllowed('evil.tld') === false, '红线2：任意主机被拒')
  check(d.hostAllowed('api.deepseek.com.evil.tld') === false, '红线2：后缀伪装主机被拒')
  check(d.hostAllowed('') === false, '红线2：空主机被拒')

  // ---- ③ 非白名单 URL → 拒播 + 审计 ------------------------------------
  writeMusicConfig({ networkEnabled: true }, CFG)
  return (async () => {
    const r1 = await d.streamHandler({ url: 'music-stream://evil.tld/live.mp3' })
    check(r1.status === 403, '红线3：非白名单主机被拒（HTTP 403）', `status=${r1.status}`)
    const reject = auditRows.filter((r) => r.kind === 'reject-host' && r.host === 'evil.tld')
    check(reject.length > 0, '红线3：拒播写入审计行（host/stage）', JSON.stringify(reject[0] || {}))
    check(reject[0] && reject[0].stage === 'stream', '红线3：审计标明拒绝发生在流阶段')

    // ---- ⑤ 畸形流 URL 被拒（new URL 解析失败 → 400 + 审计）-------------
    // 注意：'not-a-url' 其实是合法主机名（会走白名单拒绝返回 403），
    // 这里必须用真正无法解析成 URL 的输入才能覆盖 400 分支。
    const rBad = await d.streamHandler({ url: 'music-stream://' })
    check(rBad.status === 400, '红线3：无法解析的流 URL 被拒（400）', `status=${rBad.status}`)
    check(auditRows.some((r) => r.kind === 'reject-bad-stream-url'), '红线3：畸形 URL 也写审计')

    // 合法主机名但不在白名单 → 403（与上一项区分：这是"解析成功但拒播"）
    const rNotAllowed = await d.streamHandler({ url: 'music-stream://not-a-url/live.mp3' })
    check(rNotAllowed.status === 403, '红线3：合法但非白名单主机同样拒播（403）', `status=${rNotAllowed.status}`)

    // ---- 联网开关关闭时一律拒播 ----------------------------------------
    writeMusicConfig({ networkEnabled: false }, CFG)
    d.allowHost('stream.example.net', 'acceptance')
    const r2 = await d.streamHandler({ url: 'music-stream://stream.example.net/live.mp3' })
    check(r2.status === 403, '红线1：联网开关关闭时拒播（即便主机已加白）', `status=${r2.status}`)
    check(auditRows.some((r) => r.kind === 'reject-network-disabled'), '红线1：拒播写审计 reject-network-disabled')

    // ---- ④ 白名单 + 联网开启 → 流式转发，不落盘 ------------------------
    writeMusicConfig({ networkEnabled: true }, CFG)
    const before = fetchCalls.length
    const r3 = await d.streamHandler({ url: 'music-stream://stream.example.net/live.mp3?x=1' })
    check(r3.status === 200, '红线4：白名单主机流式转发成功', `status=${r3.status}`)
    check(fetchCalls.length === before + 1, '红线4：转发确实走了主进程出网', `fetchCalls=${fetchCalls.length}`)
    check(fetchCalls[fetchCalls.length - 1].redirect === 'manual', '红线4：禁用自动重定向（防跳出白名单）')
    const body = await r3.text()
    check(body === 'audio-bytes-xyz', '红线4：响应体原样流转发')
    check(r3.headers.get('cache-control') === 'no-store', '红线4：不缓存（no-store）')
    check(auditRows.some((r) => r.kind === 'stream-open'), '红线4：播放开流写审计')

    // ---- 运行时白名单逐条加入 + 审计 ------------------------------------
    const allowRow = auditRows.filter((r) => r.kind === 'allow-host')
    check(allowRow.length >= 1, '红线2：清单主机逐条加入白名单并审计', JSON.stringify(allowRow[0] || {}))
    check(d.hostAllowed('stream.example.net') === true, '红线2：加入后该主机可播')

    // ---- 汇总 ----------------------------------------------------------
    const failed = results.filter((r) => !r.ok).length
    const evidence = {
      tool: 'accept-s13-allowlist',
      generatedAt: new Date().toISOString(),
      contract: 'CONTRACT.md v0.1 §3/§7',
      results,
      failed,
      total: results.length,
      auditKinds: auditRows.reduce((acc, r) => { acc[r.kind] = (acc[r.kind] || 0) + 1; return acc }, {}),
      fsWritesOnStreamPath: fsWrites.length,
    }
    mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
    writeFileSync(OUT, JSON.stringify(evidence, null, 2))
    console.log(`\n# accept-s13-allowlist: total=${results.length} pass=${results.length - failed} fail=${failed}`)
    console.log(`证据 -> ${OUT}`)
    if (existsSync(TMP)) rmSync(TMP, { recursive: true, force: true })
    process.exit(failed === 0 ? 0 : 1)
  })()
}

main()
