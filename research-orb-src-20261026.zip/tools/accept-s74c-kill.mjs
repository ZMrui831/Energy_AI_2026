// tools/accept-s74c-kill.mjs —— S74c·P0-1 验收：**accept 进程清理必须精确，用户实例必须存活**
//
// 主管原始要求（P0-1，定性"主管过失，最优先"）：
//   1. 起 Electron 的 accept 脚本必须记录自己起的 PID，清理只杀这些 PID；
//   2. 若必须按名匹配，必须带唯一标识（--user-data-dir 或 --remote-debugging-port）；
//   3. 新增护栏 tools/check-accept-kill.mjs（宽匹配即 FAIL）；
//   4. 验收：起"模拟用户实例"→ 跑 accept → 结束时**用户实例仍存活** + 测试实例已清。
//
// 本脚本的 6 项断言：
//   K-1 只读口径一致：countOrbAll() === listOrbAll().length（预检看到的和列举到的同一个集合）
//   K-2 陌生 mark 不误杀：killMarked(不存在的 mark) → killed === 0，且"用户实例"存活
//   K-3 模拟用户实例能起来：listMarked(SIM) 非空，且此时"用户实例"仍存活
//   K-4 **精确回收**：killMarked(SIM) 只清掉模拟实例，且**用户实例仍存活**（核心断言）
//   K-5 accept 遇已有实例 fail-closed 且不误杀：跑真实 accept 脚本 → 结束后用户实例仍存活
//   K-6 护栏 check-accept-kill.mjs 退出码 0
//
// "用户实例"的取法（自适应，保证任何时候都能跑）：
//   · 优先用**真实**用户实例（命令行含 main.mjs 且不含 orbud- 工具标记的 electron 主进程）；
//   · 若本机没有在跑的实例，则起一个 STANDBY 实例作为替身（收尾时只清自己起的替身）。
//   **绝不**清理真实用户实例。

import { spawn, spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import {join, resolve} from 'node:path'
import {
  ORB_ELECTRON, mkMark, orbUdata, orbSpawnArgs, killMarked, countOrbAll, listOrbAll, listMarked, pidAlive,
} from './_orb-proc.mjs'

const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const EVIDENCE = join(PROJECT_ROOT, 'data', 'tmp', 'accept-s74c-kill.json')
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

let pass = 0
let total = 0
const rows = []
function check(id, ok, detail) {
  total++
  if (ok) pass++
  rows.push({ id, ok: !!ok, detail })
  console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`)
}

/** 起一个带唯一 mark 的隔离实例（数据目录也隔离）。 */
function startInstance(mark, port) {
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  delete env.ORB_LOG_DIR
  env.ORB_DATA_DIR = join(orbUdata(mark), 'data')
  const child = spawn(ORB_ELECTRON, orbSpawnArgs(mark, { port, main: MAIN }), { cwd: PROJECT_ROOT, env, stdio: 'ignore' })
  child.on('error', () => { /* noop */ })
  return child
}

async function waitMarked(mark, ms = 45000) {
  const dl = Date.now() + ms
  while (Date.now() < dl) {
    if (listMarked(mark).length > 0) return true
    await sleep(700)
  }
  return false
}

const SIM_MARK = mkMark('user-sim')
const STANDBY_MARK = mkMark('user-standby')
let standbyChild = null
let simChild = null
let userPid = 0
let userIsReal = false

console.log('accept-s74c-kill：S74c·P0-1 精确进程清理验收')
try {
  // ---- 选定"用户实例" ----
  const all = listOrbAll()
  const realMain = all.find((p) => /main\.mjs/.test(p.commandLine || '') && !/orbud-/.test(p.commandLine || ''))
  if (realMain) {
    userPid = realMain.pid
    userIsReal = true
    console.log(`  用户实例：真实（pid=${userPid}，非工具启动）→ 全程不得被杀`)
  } else {
    console.log('  本机当前无在跑实例 → 起 STANDBY 替身作为"用户实例"（收尾只清这个替身）')
    standbyChild = startInstance(STANDBY_MARK, 9391)
    if (!(await waitMarked(STANDBY_MARK))) throw new Error('STANDBY 替身未能启动')
    const standbyPids = listMarked(STANDBY_MARK)
    const mainPid = listOrbAll().find((p) => standbyPids.includes(p.pid) && /main\.mjs/.test(p.commandLine || ''))
    userPid = mainPid ? mainPid.pid : standbyPids[0]
    userIsReal = false
    console.log(`  用户实例：替身 STANDBY（pid=${userPid}）`)
  }

  // ---- K-1 只读口径一致 ----
  const cnt = countOrbAll()
  const lst = listOrbAll()
  check('K-1 只读口径一致', cnt === lst.length, `countOrbAll=${cnt} listOrbAll=${lst.length}`)

  // ---- K-2 陌生 mark 不误杀 ----
  const r0 = killMarked('orbm-nonexistent-000-000-zzz')
  const aliveAfterR0 = pidAlive(userPid)
  check('K-2 陌生 mark 不误杀', r0.killed === 0 && aliveAfterR0, `killed=${r0.killed} 用户实例存活=${aliveAfterR0}`)

  // ---- K-3 起模拟用户实例 ----
  simChild = startInstance(SIM_MARK, 9392)
  const simUp = await waitMarked(SIM_MARK)
  const simPids = listMarked(SIM_MARK)
  const aliveWithSim = pidAlive(userPid)
  check('K-3 模拟实例起来且不影响用户实例', simUp && simPids.length > 0 && aliveWithSim,
    `sim 进程=${simPids.length}（pid=${simPids.slice(0, 3).join(',')}） 用户实例存活=${aliveWithSim}`)

  // ---- K-4 精确回收：只杀模拟实例，用户实例必须活着 ----
  const rSim = killMarked(SIM_MARK)
  await sleep(1500)
  const simLeft = listMarked(SIM_MARK).length
  const userAlive = pidAlive(userPid)
  check('K-4 精确回收（只杀本 mark，用户实例存活）', rSim.killed > 0 && simLeft === 0 && userAlive,
    `killed=${rSim.killed} 模拟实例残留=${simLeft} 用户实例(pid=${userPid})存活=${userAlive}`)

  // ---- K-5 跑真实 accept：遇到已有实例应 fail-closed，且不得误杀 ----
  const target = join(PROJECT_ROOT, 'tools', 'accept-smoke-electron.mjs')
  let accOut = ''
  let accCode = -1
  if (existsSync(target)) {
    const r = spawnSync(process.execPath, [target], { encoding: 'utf8', timeout: 180000, cwd: PROJECT_ROOT, windowsHide: true })
    accCode = r.status === null ? -1 : r.status
    accOut = String(r.stdout || '') + String(r.stderr || '')
  } else {
    accOut = '(accept 脚本不存在)'
  }
  const userAliveAfterAccept = pidAlive(userPid)
  const failClosed = /fail-closed|已有|instance-running|skipped/i.test(accOut)
  check('K-5 accept 跑完后用户实例仍存活', userAliveAfterAccept,
    `脚本=accept-smoke-electron 退出码=${accCode} 用户实例存活=${userAliveAfterAccept}（${userIsReal ? '真实实例' : '替身'}）`)
  check('K-5b accept 遇到已有实例是 fail-closed 退出（不是硬起/不是清理）', failClosed,
    `命中 fail-closed 提示=${failClosed}｜首行=${accOut.split('\n')[0].slice(0, 90)}`)

  // ---- K-6 护栏 ----
  const g = spawnSync(process.execPath, [join(PROJECT_ROOT, 'tools', 'check-accept-kill.mjs')], { encoding: 'utf8', timeout: 120000 })
  check('K-6 护栏 check-accept-kill PASS', g.status === 0, `退出码=${g.status}`)
} catch (e) {
  total++
  rows.push({ id: 'EXC', ok: false, detail: String((e && e.message) || e).slice(0, 200) })
  console.log(`  [FAIL] EXC ${String((e && e.message) || e).slice(0, 200)}`)
} finally {
  // 收尾：**只清自己起的**进程（模拟实例 + 替身）。真实用户实例一律不碰。
  try { killMarked(SIM_MARK) } catch { /* noop */ }
  if (standbyChild) {
    try { killMarked(STANDBY_MARK) } catch { /* noop */ }
  }
  try { if (simChild) simChild.kill() } catch { /* noop */ }
  try { if (standbyChild) standbyChild.kill() } catch { /* noop */ }
  await sleep(1200)
  console.log(`  收尾：模拟实例残留=${listMarked(SIM_MARK).length}｜替身残留=${standbyChild ? listMarked(STANDBY_MARK).length : 0}`
    + `｜真实用户实例(pid=${userPid}${userIsReal ? '' : ' 替身'})存活=${pidAlive(userPid)}`)
}

try {
  mkdirSync(join(PROJECT_ROOT, 'data', 'tmp'), { recursive: true })
  writeFileSync(EVIDENCE, JSON.stringify({ at: new Date().toISOString(), pass, total, rows }, null, 2), 'utf8')
  console.log(`  证据：${EVIDENCE}`)
} catch { /* noop */ }

console.log(`\naccept-s74c-kill：${pass}/${total} ${pass === total ? 'PASS' : 'FAIL'}`)
process.exit(pass === total ? 0 : 1)
