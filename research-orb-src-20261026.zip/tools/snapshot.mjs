#!/usr/bin/env node
// 阶段快照：node tools/snapshot.mjs  -> .snapshots/<yyyyMMdd-HHmmss>/
import { cpSync, mkdirSync, writeFileSync, readdirSync, rmSync, existsSync, statSync } from 'node:fs'
import { join, resolve } from 'node:path'
const ROOT = resolve(import.meta.dirname, '..')
const SKIP = new Set(['node_modules', '.snapshots', '.git'])
const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19)
const dest = join(ROOT, '.snapshots', stamp)
mkdirSync(dest, { recursive: true })
let copied = 0
for (const name of readdirSync(ROOT)) {
  if (SKIP.has(name)) continue
  const from = join(ROOT, name)
  if (statSync(from).isDirectory() || statSync(from).isFile()) {
    cpSync(from, join(dest, name), { recursive: true })
    copied += 1
  }
}
writeFileSync(join(dest, 'SNAPSHOT.json'), JSON.stringify({ at: new Date().toISOString(), top: copied }, null, 2))
writeFileSync(join(ROOT, '.snapshots', 'LATEST.txt'), stamp)
const all = readdirSync(join(ROOT, '.snapshots')).filter((n) => n !== 'LATEST.txt').sort()
while (all.length > 10) {
  const old = all.shift()
  rmSync(join(ROOT, '.snapshots', old), { recursive: true, force: true })
  console.log('snapshot: 清理旧快照 ' + old)
}
console.log('snapshot: ' + dest + ' (' + copied + ' 个顶层项)')