// tools/fix-trajectory-placeholders.mjs —— S71·P0-1 历史占位行标注（一次性）
//
// 把 trajectory.jsonl 中 window/process 仍是占位串的行**保留但标注** placeholder:true；
// 召回与日报不展示这类行（confusion.retrieveEvents / buildRecallAnswer 已过滤）。
// 默认干跑（只统计不写）；`--apply` 才写，写前先导出备份到 data\exports\。
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const TRAJ = join(ROOT, 'data', 'coach', 'trajectory.jsonl')
const APPLY = process.argv.includes('--apply')
const PH = /（增量抽取）|（命令触发）|（手动捕获）|（自动捕获）/

if (!existsSync(TRAJ)) { console.log('[fix-placeholders] trajectory.jsonl 不存在，跳过'); process.exit(0) }
const lines = readFileSync(TRAJ, 'utf8').split('\n').filter((l) => l.trim())
const rows = []
let marked = 0
for (const l of lines) {
  let r = null
  try { r = JSON.parse(l) } catch { rows.push(l); continue }
  const dirty = !r.placeholder && (PH.test(String(r.window || '')) || PH.test(String(r.process || '')))
  if (dirty) { r.placeholder = true; marked += 1 }
  rows.push(JSON.stringify(r))
}
console.log(`[fix-placeholders] 共 ${lines.length} 行，命中占位 ${marked} 行${APPLY ? '（写入）' : '（干跑，未写；加 --apply 才落盘）'}`)
if (!APPLY) { console.log('  样例命中：' + lines.filter((l) => PH.test(l)).slice(0, 3).map((l) => l.slice(0, 120)).join(' | ')); process.exit(0) }
if (!marked) { console.log('  无需写入'); process.exit(0) }
const expDir = join(ROOT, 'data', 'exports')
mkdirSync(expDir, { recursive: true })
const stamp = new Date().toISOString().replace(/[:.]/g, '-')
const backup = join(expDir, `trajectory-backup-${stamp}.jsonl`)
writeFileSync(backup, lines.join('\n') + '\n')
writeFileSync(TRAJ, rows.join('\n') + '\n')
console.log(`[fix-placeholders] 已写回 ${TRAJ}（备份 ${backup}）`)
