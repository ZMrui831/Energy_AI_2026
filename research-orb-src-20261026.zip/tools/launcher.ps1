# tools/launcher.ps1 - research-orb desktop entry logic (single entry: start if not running, stop if running)
#
# NOTE: keep this file pure ASCII. Windows PowerShell 5.1 reads BOM-less files as ANSI,
#       and multi-byte comments then corrupt the parser.
#
# Safety rules (SAFETY.md):
#   * Target selection is ONLY "command line contains 'research-orb'".
#   * NEVER kill by image name; other electron/Edge processes are never touched.
#   * Only taskkill /PID <pid> /T /F for the enumerated PIDs.

$ErrorActionPreference = 'Continue'
$Root     = 'D:\explorer!\research-orb'
$Electron = 'D:\AI_Workspace\dsh-orb-electron\electron.exe'
$MainJs   = Join-Path $Root 'apps\desktop\main.mjs'
$LogFile  = Join-Path $Root 'data\logs\launcher.log'

function Get-OrbPids {
  Get-CimInstance Win32_Process -Filter "Name='electron.exe'" |
    Where-Object { $_.CommandLine -like '*research-orb*' } |
    ForEach-Object { [int]$_.ProcessId }
}

function Get-OtherCounts {
  # control counts proving other electron/Edge processes were untouched
  $edge = @(Get-CimInstance Win32_Process -Filter "Name='msedge.exe'").Count
  $all  = @(Get-CimInstance Win32_Process -Filter "Name='electron.exe'").Count
  "$edge|$all"
}

$pids = @(Get-OrbPids)

if ($pids.Count -gt 0) {
  $list = ($pids | ForEach-Object { "PID $_" }) -join ' '
  Write-Host "[research-orb] already running. PIDs (criterion: command line contains 'research-orb'): $list"
  Write-Host '[research-orb] stopping those PIDs only (taskkill /PID /T /F - no image-name kill)...'
  foreach ($p in $pids) {
    try { & taskkill /PID $p /T /F 2>&1 | Out-Null } catch { }
  }
  Start-Sleep -Milliseconds 1200
  $left = @(Get-OrbPids).Count
  $c = (Get-OtherCounts).Split('|')
  Write-Host "[research-orb] stopped. remaining research-orb processes = $left"
  Write-Host "[research-orb] other processes NOT touched: Edge=$($c[0]), electron(all)=$($c[1])"
  Add-Content -Path $LogFile -Value ("[{0}] STOP ok, pids={1}, remaining={2}, edge={3}, electronAll={4}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), ($pids -join ','), $left, $c[0], $c[1])
  exit 0
}

# ---- start ----
if (-not (Test-Path $Electron)) {
  Write-Host "[research-orb] ERROR: electron.exe not found at $Electron"
  exit 1
}
Write-Host '[research-orb] starting...'
$env:ELECTRON_RUN_AS_NODE = $null
Remove-Item Env:\ELECTRON_RUN_AS_NODE -ErrorAction SilentlyContinue
# DETACHED LAUNCH (critical): a plain Start-Process makes electron.exe attach to the
# caller's console (Electron calls AttachConsole(parent)). When the .bat console then
# closes, the app dies with it - observed twice during acceptance. Spawning through
# Win32_Process.Create gives the child NO console relationship at all, so the app
# outlives the launcher window (same behaviour as tools with stdio:'ignore').
$cmdLine = '"{0}" --no-sandbox "{1}"' -f $Electron, $MainJs
$null = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{
  CommandLine     = $cmdLine
  CurrentDirectory = $Root
}
Start-Sleep -Seconds 3
$running = @(Get-OrbPids).Count
$c = (Get-OtherCounts).Split('|')
Write-Host "[research-orb] started. research-orb processes = $running"
Write-Host "[research-orb] other processes NOT touched: Edge=$($c[0]), electron(all)=$($c[1])"
Write-Host '[research-orb] run this entry again to stop the app.'
Add-Content -Path $LogFile -Value ("[{0}] START ok, running={1}, edge={2}, electronAll={3}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $running, $c[0], $c[1])
exit 0
