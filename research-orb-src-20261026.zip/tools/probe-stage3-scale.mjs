// tools/probe-stage3-scale.mjs
//
// 阶段 3 验收探针（① 加速路径 / ① 真实路径 / ② 崩溃现场）。
//
// 为什么每个场景都要独立进程：RESEARCH_ORB_TIME_SCALE 由宿主 createCoreHost
// 读一次并缓存，同一进程内改环境变量是无效的 —— "加速"与"真实"必须分进程取证，
// 这本身就是"加速只是参数、两条路径共用同一套代码"的证明。
//
// 场景（用法：node tools/probe-stage3-scale.mjs <scene>）：
//   fast   RESEARCH_ORB_TIME_SCALE=60（由父进程设环境变量）：
//         起 1 分钟番茄，真实等 1.1 秒，主进程同款 tick() 到点收尾。
//         1 分钟 -> 1.1 秒，公式上 15 分钟 -> 15 秒（±1 个 tick）。
//   real   不设环境变量（scale=1，真实时长路径）：
//         起 1 分钟番茄，真实等 3 秒后暂停 —— 本段落账必须 ≈3 秒，不猜不补。
//   crash  起 1 分钟番茄，真实跑 31 秒后 tick（跨过 30s 心跳阈值，留下新心跳），
//         不收尾直接退出 —— 磁盘上留下"上个进程崩在现场"的状态，供父进程 recover()。
//
// 输出：stdout 最后一行是 JSON（供 tools/accept-stage3.mjs 采集）；
//       人读日志走 stderr。只写 data/timer 与 data/logs（唯一可写根内）。

import { createCoreHost } from '../apps/desktop/core-host.mjs'
import { dayKeyOf } from '../packages/core/src/timer-store.mjs'

const scene = process.argv[2]
if (!['fast', 'real', 'crash'].includes(scene)) {
  process.stderr.write('usage: node tools/probe-stage3-scale.mjs <fast|real|crash>\n')
  process.exit(2)
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const host = createCoreHost()
const reg = host.registry
await reg.enableAll()
const dayKey = dayKeyOf(Date.now())

/** 只汇总本会话的 segment 行（同一天可能跑过多次验收，不能拿全天总额冒充）。 */
function sessionSecOf(key, sessionId) {
  return host.timerStore
    .readDay(key)
    .filter((r) => r.type === 'segment' && r.sessionId === sessionId)
    .reduce((s, r) => s + (Number(r.sec) || 0), 0)
}

const out = { scene, dayKey, timeScale: host.timeScale }

if (scene === 'fast') {
  const r = await reg.runCommand('start', '1') // 1 分钟番茄
  const sessionId = r.value && r.value.ui && r.value.ui.snapshot && r.value.ui.snapshot.sessionId
  out.startOk = r.ok
  const t0 = Date.now()
  await sleep(1100) // 真实 1.1 秒；scale=60 -> 66 计时秒 >= 60
  const tick = host.timer.tick() // 与主进程 driver 每秒同款调用
  out.realMs = Date.now() - t0
  out.justCompleted = !!tick.justCompleted
  out.sessionSec = sessionSecOf(dayKey, sessionId)
  out.status = host.timer.status().status
  out.summaryTotalSec = tick.summary ? tick.summary.totalSec : null
  out.completed = tick.summary ? tick.summary.completed : null
} else if (scene === 'real') {
  const r = await reg.runCommand('start', '1')
  const sessionId = r.value && r.value.ui && r.value.ui.snapshot && r.value.ui.snapshot.sessionId
  out.startOk = r.ok
  const t0 = Date.now()
  await sleep(3000) // 真实 3 秒；scale=1 -> 本段落账必须 ≈3 秒
  const paused = host.timer.pause()
  out.realMs = Date.now() - t0
  out.accumulatedSec = host.timer.status().accumulatedSec
  out.sessionSec = sessionSecOf(dayKey, sessionId)
  out.status = host.timer.status().status
  out.pausedOk = paused.status === 'paused'
  // 立刻收尾，不把半截会话留给后续步骤
  host.timer.stop({ reason: 'probe-real' })
} else if (scene === 'crash') {
  const r = await reg.runCommand('start', '1')
  out.sessionId = r.value && r.value.ui && r.value.ui.snapshot && r.value.ui.snapshot.sessionId
  out.startOk = r.ok
  await sleep(31_000) // 跨过 HEARTBEAT_MS(30s)：下一次 tick 才会把心跳写到最后
  host.timer.tick() // heartbeatAt = 起点+31s（已记录时间的上界证据）
  out.crashed = true
  // 不收尾、不 dispose，直接退出 —— 模拟进程崩溃
}

process.stdout.write(JSON.stringify(out) + '\n')
// 注意：crash 场景故意不做 host.dispose()（那会 stop 收尾），进程自然退出即可
if (scene !== 'crash') await host.dispose()
