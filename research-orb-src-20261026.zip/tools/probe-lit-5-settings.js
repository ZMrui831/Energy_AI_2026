// tools/probe-lit-5-settings.js —— 面板取证 ⑤：设置页里的插件卡片区（证据：新增「文献」卡片）。
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const api = globalThis.researchOrb
api.send('window', { action: 'expand' })
await sleep(600)
// 点底座的设置按钮打开设置页
const btn = document.getElementById('permission-button')
if (btn) btn.click()
await sleep(900)
const settings = document.getElementById('ro-settings')
const groups = [...settings.querySelectorAll('.ro-group')]
const cardGroup = groups.find((g) => g.querySelector('.ro-group-title') && g.querySelector('.ro-group-title').textContent === '插件卡片')
if (!cardGroup) return { error: '设置页里没有插件卡片区', groups: groups.map((g) => g.querySelector('.ro-group-title') && g.querySelector('.ro-group-title').textContent) }
// 滚到插件卡片区
cardGroup.scrollIntoView({ block: 'start' })
await sleep(400)
return {
  settingsOpen: settings.classList.contains('ro-open'),
  cardTitles: [...cardGroup.querySelectorAll('.ro-choice span:first-child')].map((s) => s.textContent.trim()),
  bodies: [...cardGroup.querySelectorAll('.ro-note')].map((p) => p.textContent.slice(0, 90)),
  buttons: [...cardGroup.querySelectorAll('button')].map((b) => b.textContent),
}
