// tools/make-bench-fixtures.mjs —— S74·1-A：生成 bench suite 的**确定性**夹具
//
// 只做两件不需要真机的事（真机截图走 tools\capture-bench-fixtures.mjs）：
//   ① 空白/纯色图 ×2（期望 tool_id=unknown —— 不许编软件名）
//   ② 同图不同缩放 ×2（对照：缩放不应当改变识别结果）
//
// 零新增依赖：复用本机 GDI+（与 extract.mjs 的 shrinkForModel 同一套手法）。
// 幂等：同参数产出字节一致（固定种子内容），重复跑不产生噪音文件。

import { execFileSync } from 'node:child_process'
import { existsSync, mkdirSync, statSync } from 'node:fs'
import {join, resolve} from 'node:path'

const ROOT = resolve(import.meta.dirname, '..')
const OUT = join(ROOT, 'tests', 'fixtures', 'vision')
const SRC = join(OUT, 'dsh-split-screen.png')

mkdirSync(OUT, { recursive: true })

function ps(script, env = {}) {
  return execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], {
    encoding: 'utf8', timeout: 60000, env: { ...process.env, ...env },
  })
}

/** 纯色 PNG（无文字、无图标、无窗口边框）。 */
function solid(name, w, h, hex) {
  const out = join(OUT, name)
  const s = [
    '$ErrorActionPreference="Stop"',
    'Add-Type -AssemblyName System.Drawing',
    '$dst=$env:MF_OUT; $w=[int]$env:MF_W; $h=[int]$env:MF_H',
    '$bmp=New-Object System.Drawing.Bitmap $w,$h',
    '$g=[System.Drawing.Graphics]::FromImage($bmp)',
    '$c=[System.Drawing.ColorTranslator]::FromHtml($env:MF_COLOR)',
    '$br=New-Object System.Drawing.SolidBrush $c',
    '$g.FillRectangle($br,0,0,$w,$h)',
    '$g.Dispose();$br.Dispose()',
    '$bmp.Save($dst,[System.Drawing.Imaging.ImageFormat]::Png)',
    '$bmp.Dispose()',
    "Write-Output 'OK'",
  ].join('\n')
  const r = ps(s, { MF_OUT: out, MF_W: String(w), MF_H: String(h), MF_COLOR: hex })
  if (!/OK/.test(r)) throw new Error('纯色图生成失败：' + name + ' ' + r)
  return out
}

/** 等比缩放（宽 → maxW），PNG 输出。 */
function scale(src, name, maxW) {
  const out = join(OUT, name)
  const s = [
    '$ErrorActionPreference="Stop"',
    'Add-Type -AssemblyName System.Drawing',
    '$src=$env:MF_SRC; $dst=$env:MF_OUT; $mw=[int]$env:MF_W',
    '$img=[System.Drawing.Image]::FromFile($src)',
    '$w=[Math]::Min($mw,$img.Width); $h=[int]($img.Height*$w/$img.Width)',
    '$bmp=New-Object System.Drawing.Bitmap $w,$h',
    '$g=[System.Drawing.Graphics]::FromImage($bmp)',
    '$g.InterpolationMode="HighQualityBicubic"',
    '$g.DrawImage($img,0,0,$w,$h)',
    '$bmp.Save($dst,[System.Drawing.Imaging.ImageFormat]::Png)',
    '$g.Dispose();$bmp.Dispose();$img.Dispose()',
    "Write-Output ('OK ' + $w + 'x' + $h)",
  ].join('\n')
  const r = ps(s, { MF_SRC: src, MF_OUT: out, MF_W: String(maxW) })
  if (!/OK/.test(r)) throw new Error('缩放失败：' + name + ' ' + r)
  return { out, dim: r.trim() }
}

const rows = []
if (!existsSync(SRC)) { console.error('[fixtures] 源图缺失：' + SRC); process.exit(1) }
rows.push({ file: 'blank-dark-1280x800.png', note: '纯深灰 #1E1E1E，无界面元素', ...(() => { const p = solid('blank-dark-1280x800.png', 1280, 800, '#1E1E1E'); return { bytes: statSync(p).size } })() })
rows.push({ file: 'blank-light-1280x800.png', note: '纯白 #FFFFFF，无界面元素', ...(() => { const p = solid('blank-light-1280x800.png', 1280, 800, '#FFFFFF'); return { bytes: statSync(p).size } })() })
const c1 = scale(SRC, 'dsh-split-screen-w960.png', 960)
rows.push({ file: 'dsh-split-screen-w960.png', note: 'DSH 分屏缩到 960 宽（对照 A）', bytes: statSync(c1.out).size })
const c2 = scale(SRC, 'dsh-split-screen-w480.png', 480)
rows.push({ file: 'dsh-split-screen-w480.png', note: 'DSH 分屏缩到 480 宽（对照 B）', bytes: statSync(c2.out).size })
console.table(rows)
console.log('[make-bench-fixtures] 对照尺寸：' + c1.dim + ' / ' + c2.dim)
