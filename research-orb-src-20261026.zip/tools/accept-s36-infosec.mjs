// tools/accept-s36-infosec.mjs —— S36·v1.2-1 信息安全面板验收（≥8 项）。
// 单行复跑：node tools\accept-s36-infosec.mjs
// 证据：data\logs\s36-infosec-accept.json
import { mkdirSync, readFileSync, rmSync, writeFileSync, mkdtempSync, existsSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'

// S36 验收隔离：先设 ORB_LOG_DIR/ORB_DATA_DIR 再动态 import（safefs 在 import 时定格目录）
process.env.ORB_LOG_DIR = join(tmpdir(), 's36-info-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's36-info-data-' + Date.now())
const { dataPath } = await import('../packages/core/src/safefs.mjs')
const { buildPrivacyDashboard, renderPrivacyMarkdown } = await import('../packages/plugins/coach/privacy.mjs')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

// 桩 store：_db.prepare 按SQL 片段返回行；spy delete/insert 调用（只读验证）
function makeStubStore() {
  const calls = { insert: 0, delete: 0, update: 0 }
  const auditKinds = []
  for (let i = 0; i < 20; i++) {
    auditKinds.push(i % 7 === 0 ? 'skipped-sensitive' : (i % 5 === 0 ? 'tool-deny' : 'frame-registered'))
  }
  const auditRows = auditKinds.map((kind, i) => ({ ts: new Date(Date.now() - i * 60000).toISOString(), kind, metadata_json: JSON.stringify({ window: 'win' + i }) }))
  const rawRows = [
    { id: 'rf-del-1', sha256: 'a'.repeat(64), status: 'deleted' },
    { id: 'rf-del-2', sha256: 'b'.repeat(64), status: 'deleted' },
    { id: 'rf-ready-1', sha256: 'c'.repeat(64), status: 'ready' },
  ]
  const db = {
    prepare(sql) {
      if (/FROM audit_event/.test(sql)) return { all: () => auditRows }
      if (/FROM raw_frame/.test(sql)) return { all: () => rawRows }
      if (/FROM claim_evidence/.test(sql)) return { all: () => [] }
      return { all: () => [] }
    },
  }
  const store = {
    _db: db,
    getRawFrame(id) { return rawRows.find((r) => r.id === id) || null },
    insertRawFrame() { calls.insert += 1; return { id: 'x' } },
    deleteRawFrame() { calls.delete += 1; return true },
    purgeExpired() { calls.delete += 1; return true },
    resolveEvidence() { return { status: 'unregistered' } },
  }
  return { store, calls }
}

let md = ''
let dashboard = null
try {
  const { store, calls } = makeStubStore()
  dashboard = buildPrivacyDashboard({ store })
  md = renderPrivacyMarkdown(dashboard)

  // I-1：明文/未加密声明（不得暗示已加密）
  check('I-1 明文/未加密声明', md.includes('明文/未加密（依赖目录权限）') && !md.includes('已加密'),
    `声明=${md.includes('明文/未加密（依赖目录权限）')} 无"已加密"暗示=${!md.includes('已加密')}`, {})

  // I-2：明文路径白名单四项（memory/coach/logs/db）
  const wlOk = dashboard.infosec.encryption.plainPaths.join(',') === 'memory,coach,logs,db' && md.includes('memory / coach / logs / db')
  check('I-2 明文路径白名单四项', wlOk, `plainPaths=${dashboard.infosec.encryption.plainPaths.join(',')}`, {})

  // I-3：敏感窗口启发式拒截计数与 DB 一致（stub 里 20 条中 3 条 skipped-sensitive）
  check('I-3 敏感窗口拒截与 DB 一致', dashboard.infosec.counts.sensitiveBlocked === 3 && md.includes('敏感窗口拒截：3 次'),
    `counts=${dashboard.infosec.counts.sensitiveBlocked}`, {})

  // I-4：原图删除计数与 store 状态一致（stub 2 张 deleted）
  check('I-4 原图删除与 store 一致', dashboard.infosec.counts.originalDeleted === dashboard.statusStats.deleted && dashboard.statusStats.deleted === 2,
    `originalDeleted=${dashboard.infosec.counts.originalDeleted} statusStats.deleted=${dashboard.statusStats.deleted}`, {})

  // I-5：最近 5 条无绝对路径（脱敏生效）
  const recentSection = md.split('最近 5 条')[1] ? md.split('最近 5 条')[1].split('### 泄漏面')[0] : ''
  const absLeak = /[A-Za-z]:\\\\|项目外绝对路径/.test(recentSection)
  check('I-5 最近 5 条无绝对路径', !absLeak && dashboard.infosec.recent5.length > 0, `recent5=${dashboard.infosec.recent5.length} 绝对路径泄漏=${absLeak}`, {})

  // I-6：泄漏面四栏自洽（四项各带条数与解释）
  const leakOk = ['已删除（原图）', '仅保留摘要', '长期留存（结论+哈希）', '可导出（md/docx）'].every((k) => md.includes(k))
    && dashboard.infosec.leakface.length === 4
    && dashboard.infosec.leakface.every((l) => Number.isFinite(l.count) && l.note && l.note.length > 8)
  check('I-6 泄漏面四栏自洽', leakOk, `四栏=${dashboard.infosec.leakface.length}`, {})

  // I-7：只读（stub 的 insert/delete/purge 全程零调用）
  check('I-7 只读（零删除/零写入调用）', calls.insert === 0 && calls.delete === 0 && calls.update === 0,
    `insert=${calls.insert} delete=${calls.delete}`, {})

  // I-8：越权拒绝口径注明（writes.jsonl 只记成功写）
  check('I-8 越权拒绝口径注明', md.includes('口径：writes.jsonl 只记成功写入'), `含口径说明=true`, {})

  // I-9：导出 md 过匿名巡检（check-anonymity CLI 对导出文件 PASS）
  const out = mkdtempSync(join(tmpdir(), 's36-info-'))
  const exportPath = join(out, 'privacy-test.md')
  writeFileSync(exportPath, md, 'utf8')
  const anon = spawnSync(process.execPath, ['tools/check-anonymity.mjs', exportPath], { encoding: 'utf8' })
  const anonPass = /PASS/.test(anon.stdout || '') || anon.status === 0
  check('I-9 导出 md 匿名巡检 PASS', anonPass, `exit=${anon.status}`, {})
  try { rmSync(out, { recursive: true, force: true }) } catch { /* 尽力 */ }

  // I-10：四类计数键齐备（面板返回结构完整）
  const ck = Object.keys(dashboard.infosec.counts)
  check('I-10 四类计数键齐备', ['sensitiveBlocked', 'originalDeleted', 'denyRejected', 'pluginInstalls'].every((k) => ck.includes(k)),
    `keys=${ck.join(',')}`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's36-infosec-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s36-infosec: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
