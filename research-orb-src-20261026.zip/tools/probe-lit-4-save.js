// tools/probe-lit-4-save.js
//
// 面板取证 ④：在编辑弹层里把「读数（0-5）」从 0 改成 5 → 点保存 → 验证写回与索引重建。
// 这条专门验"编辑弹层是真的能写"，而不只是能显示（只显示不写就是假功能）。
const api = globalThis.researchOrb
const send = (type, detail) => api.send('ui', Object.assign({ type: type, at: Date.now() }, detail || {}))
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const lit = document.getElementById('ro-lit')
const editor = document.getElementById('ro-editor')

// 若弹层没开着就先打开（依赖脚本②留下的状态）
if (!editor.classList.contains('ro-open')) {
  const editBtn = [...lit.querySelectorAll('.ro-cand button')].find((b) => b.textContent === '编辑')
  if (!editBtn) return { error: '没有可编辑的卡片行' }
  editBtn.click()
  await sleep(500)
}
const rows = [...editor.querySelectorAll('.ro-editor-row')]
const readingRow = rows.find((r) => r.querySelector('label').textContent === '读数（0-5）')
if (!readingRow) return { error: '弹层里没有读数字段', fields: rows.map((r) => r.querySelector('label').textContent) }
const readingInput = readingRow.querySelector('input')
const before = readingInput.value
readingInput.value = '5'
const saveBtn = [...editor.querySelectorAll('button')].find((b) => b.textContent === '保存')
if (!saveBtn) return { error: '没有保存按钮' }
saveBtn.click()

// 等保存回包：编辑弹层应关闭、面板切到「卡片已更新」
let updated = false
for (let i = 0; i < 60; i += 1) {
  await sleep(400)
  updated = lit.textContent.indexOf('卡片已更新') >= 0
  if (updated) break
}
await sleep(400)
const rowsAfter = [...lit.querySelectorAll('.ro-cand')]
return {
  readingBefore: before,
  readingAfter: readingInput.value,
  editorClosed: !editor.classList.contains('ro-open'),
  panelSaysUpdated: updated,
  cardRowsAfter: rowsAfter.length,
  panelHead: lit.textContent.slice(0, 160),
}
