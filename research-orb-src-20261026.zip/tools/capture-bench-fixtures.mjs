// tools/capture-bench-fixtures.mjs —— S74·1-A：用 **dev-agent shot（真实抓屏）** 产出 bench 真机夹具
//
// 只补"必须真机"的 5 张：Word 文档 ×1、浏览器检索页 ×1、research-orb 自身面板 ×3。
// 纯色/缩放对照走 tools\make-bench-fixtures.mjs（确定性，无需真机）。
//
// 脱敏纪律（S74 主管要求"不要含个人信息"）：
//   · 抓屏仍是**整屏真实抓取**（走产品路径 ctx.core.screen），但入库前**裁剪到目标窗口矩形**，
//     只保留被测应用本身 —— 桌面壁纸/聊天记录/任务栏等个人信息一律不进夹具；
//   · Word 文档内容是中性学术文本（微电网两阶段鲁棒调度，无任何个人信息）；
//   · 浏览器用 **--inprivate**（无登录态）+ 中性学术检索词；
//   · 自身面板用**空白记事本最大化**做背景（面板是浮窗，全屏图必然带出桌面隐私）。
// 纪律：
//   · 隔离数据目录（ORB_DATA_DIR=tmp），不污染真实库（证据卫生）；
//   · 跑完杀干净：electron 子进程 + 打开的 Word / Edge（inprivate 实例）/ 记事本。
//   · 预检：已有 research-orb 实例在跑 → 拒绝执行（fail-closed）。

import { spawn, spawnSync, execFileSync } from 'node:child_process'
import { copyFileSync, existsSync, mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import http from 'node:http'
import {killMarked, countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('capture-bench-fixtures')

const ELECTRON = ORB_ELECTRON
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const CLI = join(PROJECT_ROOT, 'tools', 'dev-agent.mjs')
const FIXDIR = join(PROJECT_ROOT, 'tests', 'fixtures', 'vision')
const WORD_EXE = 'C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE'
const EDGE_EXE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe'
const PORT = 9342
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const WANT = {
  word: 'real-word-doc.png',
  browser: 'real-browser-search.png',
  self1: 'real-orb-home.png',
  self2: 'real-orb-trajectory.png',
  self3: 'real-orb-settings.png',
}
const missing = Object.entries(WANT).filter(([, f]) => !existsSync(join(FIXDIR, f)))
if (!missing.length) { console.log('[capture] 五张真机夹具已齐，跳过（要重拍请先删 tests\\fixtures\\vision\\real-*.png）'); process.exit(0) }
for (const p of [ELECTRON, WORD_EXE, EDGE_EXE]) if (!existsSync(p)) { console.error('[capture] 依赖缺失：' + p); process.exit(1) }

const countOrbProcs = () => countOrbAll()

// ---------------------------------------------------------------------------
// 环境与窗口工具（全部走 PowerShell + user32，不改任何产品代码）
// ---------------------------------------------------------------------------
const env = { ...process.env }
delete env.ELECTRON_RUN_AS_NODE
delete env.ORB_LOG_DIR
env.ORB_DATA_DIR = ''   // 启动前再填（tmpRoot 之后才知道）
env.CAP_WORD = WORD_EXE
env.CAP_EDGE = EDGE_EXE

const ps = (script, timeout = 60000, extraEnv = {}) => execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { encoding: 'utf8', timeout, env: { ...env, ...extraEnv } })

/** 激活 + 最大化某进程的主窗口，返回其屏幕矩形（物理像素）。 */
function focusMaximizeRect(procName) {
  const script = `
$ErrorActionPreference='Stop'
Add-Type @"
using System; using System.Runtime.InteropServices;
public struct RECT { public int L, T, R, B; }
public class CapWin {
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int n);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
}
"@
$p = Get-Process -Name $env:CAP_PROC -ErrorAction Stop | Where-Object { $_.MainWindowHandle -ne 0 -and [CapWin]::IsWindowVisible($_.MainWindowHandle) } | Select-Object -First 1
if (-not $p) { Write-Output 'NO_WINDOW'; exit 0 }
[CapWin]::ShowWindow($p.MainWindowHandle, 3) | Out-Null
[CapWin]::SetForegroundWindow($p.MainWindowHandle) | Out-Null
Start-Sleep -Milliseconds 700
$r = New-Object RECT
[CapWin]::GetWindowRect($p.MainWindowHandle, [ref]$r) | Out-Null
Write-Output ("RECT " + $r.L + " " + $r.T + " " + $r.R + " " + $r.B)
`
  const out = String(ps(script, 30000, { CAP_PROC: procName }) || '')
  const m = /RECT (-?\d+) (-?\d+) (-?\d+) (-?\d+)/.exec(out)
  if (!m) throw new Error(procName + ' 未取到窗口矩形：' + out.trim().slice(0, 120))
  return { x: Number(m[1]), y: Number(m[2]), w: Number(m[3]) - Number(m[1]), h: Number(m[4]) - Number(m[2]) }
}

/** 把整屏 PNG 裁到指定矩形（GDI+）。 */
function crop(src, dst, rect) {
  const script = `
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Drawing
$img=[System.Drawing.Image]::FromFile($env:CAP_SRC)
$dst=$env:CAP_DST
$w=[int]$env:CAP_W; $h=[int]$env:CAP_H; $x=[int]$env:CAP_X; $y=[int]$env:CAP_Y
# 坑：env 传进来是**字符串**，PowerShell 的 New-Object 会按字符串去做 .NET 构造函数重载绑定
#     （走 Bitmap(string,bool) 之类 → "参数无效"）。只有发生过算术运算才会变 int ——
#     所以之前"越界被裁掉的图能成、没越界的图必挂"。这里全部显式 [int]。
if ($x -lt 0) { $x = 0 }; if ($y -lt 0) { $y = 0 }
if ($x + $w -gt $img.Width) { $w = $img.Width - $x }
if ($y + $h -gt $img.Height) { $h = $img.Height - $y }
$bmp=New-Object System.Drawing.Bitmap $w,$h
$g=[System.Drawing.Graphics]::FromImage($bmp)
$g.DrawImage($img, (New-Object System.Drawing.Rectangle 0,0,$w,$h), (New-Object System.Drawing.Rectangle $x,$y,$w,$h), [System.Drawing.GraphicsUnit]::Pixel)
$bmp.Save($dst,[System.Drawing.Imaging.ImageFormat]::Png)
$g.Dispose();$bmp.Dispose();$img.Dispose()
Write-Output ('CROPPED ' + $w + 'x' + $h)
`
  const out = String(ps(script, 60000, { CAP_SRC: src, CAP_DST: dst, CAP_X: String(rect.x), CAP_Y: String(rect.y), CAP_W: String(rect.w), CAP_H: String(rect.h) }) || '')
  if (!/CROPPED/.test(out)) throw new Error('裁剪失败：' + out.trim().slice(0, 160))
  return out.trim()
}

// ---------------------------------------------------------------------------
// 中性 Word 文档
// ---------------------------------------------------------------------------
async function makeDocx(docxPath) {
  const { Document, Packer, Paragraph, HeadingLevel, TextRun } = await import('docx')
  const doc = new Document({
    sections: [{
      children: [
        new Paragraph({ text: '两阶段鲁棒调度在微电网能量管理中的应用', heading: HeadingLevel.HEADING_1 }),
        new Paragraph({ children: [new TextRun('摘要：针对分布式光伏与储能接入后的不确定性，本文构建日前-日内两阶段鲁棒优化模型。日前阶段以购电成本与储能退化成本最小为目标确定机组组合；日内阶段基于滚动时域求解鲁棒可行域内的再调度。算例表明，相较确定性模型，该方法的弃光率下降 4.2 个百分点。')] }),
        new Paragraph({ text: '1 引言', heading: HeadingLevel.HEADING_2 }),
        new Paragraph({ children: [new TextRun('微电网能量管理需要在源荷双侧不确定条件下兼顾经济性与鲁棒性。既有研究多采用随机规划，依赖精确概率分布；当预测误差分布偏移时，解的可行性难以保证。')] }),
        new Paragraph({ text: '2 模型建立', heading: HeadingLevel.HEADING_2 }),
        new Paragraph({ children: [new TextRun('目标函数包含购电成本、储能循环退化成本与弃光惩罚三项。约束涵盖功率平衡、储能荷电状态演化与线路容量。')] }),
        new Paragraph({ text: '3 求解方法', heading: HeadingLevel.HEADING_2 }),
        new Paragraph({ children: [new TextRun('采用列与约束生成算法迭代求解：主问题给出日前决策，子问题检验最劣场景并生成割平面。')] }),
      ],
    }],
  })
  writeFileSync(docxPath, await Packer.toBuffer(doc))
}

const killProcs = (names) => {
  for (const n of names) {
    try {
      ps(`Get-CimInstance Win32_Process -Filter "Name='$env:CAP_N'" | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }`, 30000, { CAP_N: n })
    } catch { /* 尽力 */ }
  }
}
const killEdgeInprivate = () => {
  try {
    ps(`Get-CimInstance Win32_Process -Filter "Name='msedge.exe'" | Where-Object { $_.CommandLine -like '*-inprivate*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }`, 30000)
  } catch { /* 尽力 */ }
}

// ---------------------------------------------------------------------------
// 主流程
// ---------------------------------------------------------------------------
let child = null
const tmpRoot = mkdtempSync(join(tmpdir(), 's74-fixtures-'))
env.ORB_DATA_DIR = join(tmpRoot, 'data')
try { execFileSync('node.exe', ['-e', 'fs.cpSync(process.argv[1], process.argv[2], {recursive:true})', join(PROJECT_ROOT, 'data', 'themes'), join(env.ORB_DATA_DIR, 'themes')], { timeout: 30000 }) } catch { /* 主题缺失回退 vendor 亮色，不影响抓屏 */ }
for (const f of ['providers.json', 'vision-context.json']) { try { copyFileSync(join(PROJECT_ROOT, 'data', f), join(env.ORB_DATA_DIR, f)) } catch { /* noop */ } }

function httpGetJson(url) {
  return new Promise((res, rej) => {
    http.get(url, (r) => { let b = ''; r.on('data', (c) => { b += c }); r.on('end', () => { try { res(JSON.parse(b)) } catch (e) { rej(e) } }) }).on('error', rej)
  })
}
async function cdpCommand(expression) {
  const list = await httpGetJson(`http://127.0.0.1:${PORT}/json/list`)
  const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(String(t.url || '')))
  if (!page) throw new Error('未找到面板页')
  const ws = new WebSocket(page.webSocketDebuggerUrl)
  await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', () => rej(new Error('ws 失败'))) })
  let id = 0
  const send = (method, params) => new Promise((res, rej) => {
    const mid = ++id
    const onMsg = (m) => { try { const msg = JSON.parse(String(m.data)); if (msg.id === mid) { ws.removeEventListener('message', onMsg); msg.error ? rej(new Error(msg.error.message)) : res(msg.result) } } catch { /* noop */ } }
    ws.addEventListener('message', onMsg)
    ws.send(JSON.stringify({ id: mid, method, params }))
    setTimeout(() => { ws.removeEventListener('message', onMsg); rej(new Error('CDP 超时：' + method)) }, 20000)
  })
  const r = await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  try { ws.close() } catch { /* noop */ }
  if (r && r.exceptionDetails) throw new Error('evaluate: ' + JSON.stringify(r.exceptionDetails).slice(0, 200))
  return r && r.result ? r.result.value : undefined
}

const runCli = (args, timeout = 180000) => {
  const r = spawnSync(process.execPath, [CLI, '--port=' + PORT, ...args], { cwd: PROJECT_ROOT, encoding: 'utf8', timeout, env })
  let json = null
  try { json = JSON.parse(String(r.stdout || '').trim()) } catch { /* 非 JSON */ }
  if (!json) console.log('   [cli-raw] ' + String(r.stdout || '').slice(0, 160) + ' ｜ ' + String(r.stderr || '').slice(0, 160))
  return json
}
function pngSize(p) {
  const b = readFileSync(p)
  if (b.length > 24 && b.slice(1, 4).toString('ascii') === 'PNG') return { width: b.readUInt32BE(16), height: b.readUInt32BE(20) }
  return { width: 0, height: 0 }
}
/** 物理像素矩形 → 抓屏图内矩形。抓屏尺寸是 DIP（实测 1812×1019），GetWindowRect 是物理像素，
 *  必须按 screenPhysW/shotW 缩放，否则裁剪错位/越界（实测 Bitmap 构造直接抛"参数无效"）。 */
function physicalToShot(rect, shotW) {
  const script = `
Add-Type @"
using System; using System.Runtime.InteropServices;
public class CapWin3 { [DllImport("user32.dll")] public static extern int GetSystemMetrics(int n); }
"@
Write-Output ("SCREEN " + [CapWin3]::GetSystemMetrics(0) + " " + [CapWin3]::GetSystemMetrics(1))
`
  const out = String(ps(script, 20000) || '')
  const m = /SCREEN (\d+) (\d+)/.exec(out)
  if (!m) throw new Error('取屏幕物理尺寸失败')
  const scale = shotW / Number(m[1])
  return {
    x: Math.round(rect.x * scale), y: Math.round(rect.y * scale),
    w: Math.round(rect.w * scale), h: Math.round(rect.h * scale),
  }
}

/** 整屏抓取 → 裁到矩形 → 入库。rect 为物理像素。 */
const shotInto = async (key, rectPhys) => {
  const r = runCli(['shot', '--label', key])
  if (!r || r.ok !== true || !existsSync(r.pngPath)) throw new Error('抓屏失败 ' + key + ' ' + JSON.stringify(r).slice(0, 200))
  const sz = pngSize(r.pngPath)
  const rect = physicalToShot(rectPhys, sz.width)
  console.log(`   [dbg] ${key} shot=${sz.width}x${sz.height} physRect=${JSON.stringify(rectPhys)} → shotRect=${JSON.stringify(rect)}`)
  const dst = join(FIXDIR, WANT[key])
  crop(r.pngPath, dst, rect)
  const st = (await import('node:fs')).statSync(dst)
  console.log(`[capture] ${key} → ${WANT[key]}  phys=${rectPhys.w}x${rectPhys.h} shot=${rect.w}x${rect.h}@${rect.x},${rect.y}  ${st.size}B`)
  return st.size
}
/** 按命令行定位 research-orb 的 electron 主进程，取其主窗口矩形（物理像素）。 */
function findOrbRect() {
  const script = `
$ErrorActionPreference='Stop'
Add-Type @"
using System; using System.Runtime.InteropServices;
public struct RECT { public int L, T, R, B; }
public class CapWin2 {
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
}
"@
$pat = '*' + $env:ORB_MARK + '*'
$procs = Get-CimInstance Win32_Process -Filter "Name='electron.exe'" | Where-Object { $_.CommandLine -like $pat }
$rect = $null
foreach ($p in $procs) {
  $gp = Get-Process -Id $p.ProcessId -ErrorAction SilentlyContinue
  if (-not $gp -or $gp.MainWindowHandle -eq 0) { continue }
  if (-not [CapWin2]::IsWindowVisible($gp.MainWindowHandle)) { continue }
  $r = New-Object RECT
  [CapWin2]::GetWindowRect($gp.MainWindowHandle, [ref]$r) | Out-Null
  $w = $r.R - $r.L; $h = $r.B - $r.T
  if ($w -gt 300 -and $h -gt 400) { $rect = "RECT " + $r.L + " " + $r.T + " " + $r.R + " " + $r.B; break }
}
if ($rect) { Write-Output $rect } else { Write-Output 'NO_WINDOW' }
`
  // 只扫"命令行含本 MARK"的实例 = 本脚本自己起的那个；不再按 app 路径通配满世界找
  // （否则量到的是**用户正在跑的实例**窗口，裁出来的夹具就不是本脚本的面板了）。
  const out = String(ps(script, 30000, { ORB_MARK: MARK }) || '')
  const m = /RECT (-?\d+) (-?\d+) (-?\d+) (-?\d+)/.exec(out)
  if (!m) throw new Error('research-orb 面板未取到矩形：' + out.trim().slice(0, 120))
  const rect = { x: Number(m[1]), y: Number(m[2]), w: Number(m[3]) - Number(m[1]), h: Number(m[4]) - Number(m[2]) }
  console.log('   [dbg] findOrbRect raw=' + JSON.stringify(rect))
  return rect
}

const got = {}
try {
  if (countOrbProcs() > 0) throw new Error('已有 research-orb 实例在跑（fail-closed）：先关闭再重拍')
  await makeDocx(join(tmpRoot, 'fixture-doc.docx'))
  mkdirSync(FIXDIR, { recursive: true })
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], { cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] })
  child.stdout.resume(); child.stderr.resume()

  let ready = false
  const dl = Date.now() + 90000
  while (Date.now() < dl && !ready) {
    try {
      const list = await httpGetJson(`http://127.0.0.1:${PORT}/json/list`)
      if (list.some((t) => t.type === 'page' && t.webSocketDebuggerUrl)) {
        const appLog = join(env.ORB_DATA_DIR, 'logs', 'app.jsonl')
        if (existsSync(appLog) && readFileSync(appLog, 'utf8').includes('bridge-injected')) ready = true
      }
    } catch { /* 等 */ }
    if (!ready) await sleep(800)
  }
  if (!ready) throw new Error('应用未就绪')
  await sleep(2000)
  console.log('[capture] 应用就绪')

  // ---- ① Word 文档（先收起面板，避免浮窗入镜）----
  if (!existsSync(join(FIXDIR, WANT.word))) {
    await cdpCommand(`globalThis.researchOrb.send('window', { action: 'collapse' })`)
    await sleep(1200)
    ps(`Start-Process -FilePath $env:CAP_WORD -ArgumentList @('"' + $env:CAP_DOC + '"') | Out-Null`, 60000, { CAP_DOC: join(tmpRoot, 'fixture-doc.docx') })
    await sleep(9000)
    const rect = focusMaximizeRect('WINWORD')
    await sleep(1800)
    await shotInto('word', rect)
    killProcs(['WINWORD.EXE'])
    await sleep(1500)
  }
  // ---- ② 浏览器检索页（inprivate，无登录态）----
  if (!existsSync(join(FIXDIR, WANT.browser))) {
    ps(`Start-Process -FilePath $env:CAP_EDGE -ArgumentList @('--inprivate','--new-window','https://www.bing.com/search?q=microgrid+two-stage+robust+energy+management+model+predictive+control') | Out-Null`, 60000)
    await sleep(9000)
    const rect = focusMaximizeRect('msedge')
    await sleep(2500)
    await shotInto('browser', rect)
    killEdgeInprivate()
    await sleep(1500)
  }
  // ---- ③ 自身面板 ×3（空白记事本最大化做背景，裁到面板矩形）----
  ps(`Start-Process notepad.exe | Out-Null`, 30000)
  await sleep(2500)
  focusMaximizeRect('notepad')
  await sleep(1500)
  await cdpCommand(`globalThis.researchOrb.send('window', { action: 'expand' })`)
  await sleep(2500)
  const panelRect = findOrbRect()
  if (panelRect.w < 300 || panelRect.h < 400) throw new Error('面板矩形异常：' + JSON.stringify(panelRect))
  const pages = [['self1', null], ['self2', 'trajectory'], ['self3', 'settings']]
  for (const [key, page] of pages) {
    if (existsSync(join(FIXDIR, WANT[key]))) continue
    if (page) { await cdpCommand(`globalThis.__s5.page('${page}')`); await sleep(2500) }
    await shotInto(key, panelRect)
  }
} catch (e) {
  console.error('[capture] 失败：' + String((e && e.stack) || e).slice(0, 600))
} finally {
  killProcs(['WINWORD.EXE'])
  killEdgeInprivate()
  killProcs(['notepad.exe'])
  try { if (child) child.kill() } catch { /* noop */ }
  await sleep(1500)
  // S74c·P0-1：这里原来按 app 路径通配 宽匹配 Stop-Process —— 会把**用户正在跑的实例**一起杀掉。
  // 现在只回收"命令行含本 MARK"的进程（即本脚本自己起的实例）。
  try { killMarked(MARK) } catch { /* noop */ }
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}
console.table(got)
const done = Object.keys(WANT).filter((k) => existsSync(join(FIXDIR, WANT[k])))
console.log(`[capture] 完成 ${done.length}/${Object.keys(WANT).length}（${done.join(', ')}）`)
process.exit(done.length === Object.keys(WANT).length ? 0 : 1)
