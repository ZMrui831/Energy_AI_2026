// tools/smoke-plugins.mjs
//
// 插件宿主冒烟：扫描 / 启用 / 列出 / 命令 / 沙箱越界拒绝 / 禁用。
// 跑法：node tools\smoke-plugins.mjs

import { existsSync } from 'node:fs'
import { resolve } from 'node:path'

import { createRegistry } from '../packages/plugins/index.mjs'
import { createProviders } from '../packages/core/src/providers/index.mjs'

const log = (...a) => process.stdout.write(a.join(' ') + '\n')
let failures = 0
function check(name, ok, extra = '') {
  log(`${ok ? 'PASS' : 'FAIL'}  ${name}${extra ? '  ' + extra : ''}`)
  if (!ok) failures += 1
}

async function main() {
  const providers = createProviders({})
  const registry = createRegistry({ core: { net: providers.net, providers } })

  const scanned = registry.scan()
  check('registry: 扫到 hello 插件', scanned.includes('hello'), JSON.stringify(scanned))

  const beforeEnable = registry.list().find((p) => p.id === 'hello')
  check('registry: 未启用时 enabled=false', beforeEnable && beforeEnable.enabled === false)
  check('registry: manifest 字段齐全', !!beforeEnable && beforeEnable.version === '0.1.0' && beforeEnable.capabilities.length > 0)
  check('registry: permissions 作为元数据带出', !!beforeEnable && beforeEnable.permissions.includes('fs:notes'))

  const r = await registry.enable('hello')
  check('registry: enable 成功', r.enabled === true && r.cards === 1 && r.commands === 2, JSON.stringify(r))

  const after = registry.get('hello')
  check('registry: list 反映启用态', after.enabled === true && after.error === null)

  const cards = registry.cards()
  check('registry: 卡片可列出', cards.length === 1 && cards[0].id === 'hello.status', JSON.stringify(cards.map((c) => c.id)))

  const cmds = registry.commands()
  check('registry: 命令可列出且不含 run 函数', cmds.length === 2 && !('run' in cmds[0]), JSON.stringify(cmds.map((c) => c.name)))

  const ran = await registry.runCommand('/hello', '世界')
  check('registry: 命令执行返回文本', ran.ok === true && /Hello, 世界!/.test(ran.value.text), ran.value && ran.value.text)

  const selfcheck = await registry.runCommand('hello.selfcheck')
  check('registry: 沙箱自证拦截越界写入', selfcheck.ok === true && /沙箱拦截越界写入：OK/.test(selfcheck.value.text), selfcheck.value && selfcheck.value.text)
  check('registry: 私有目录在 data/notes/hello 之内', selfcheck.value.notesRoot.replace(/\\/g, '/').endsWith('data/notes/hello'))

  const missing = await registry.runCommand('nope')
  check('registry: 未知命令返回 E_NO_COMMAND', missing.ok === false && missing.error === 'E_NO_COMMAND')

  // 落盘取证
check('registry: 私有笔记已写入', existsSync(resolve(import.meta.dirname, '..') + '/data/notes/hello/hello.md'))
check('registry: state.json 已写入', existsSync(resolve(import.meta.dirname, '..') + '/data/notes/hello/state.json'))

  const d = await registry.disable('hello')
  check('registry: disable 成功', d.enabled === false)
  const off = registry.get('hello')
  check('registry: 禁用后卡片/命令清空', off.enabled === false && registry.cards().length === 0 && registry.commands().length === 0)

  const re = await registry.enable('hello')
  check('registry: 可重复启用', re.enabled === true && registry.cards().length === 1)

  await registry.disposeAll()

  log(`\n${failures === 0 ? 'ALL PASS' : failures + ' FAILED'}`)
  process.exit(failures === 0 ? 0 : 1)
}

main().catch((err) => {
  log('SMOKE THREW: ' + (err && err.stack ? err.stack : err))
  process.exit(2)
})
