// tools/accept-s42-oneclick.mjs —— S42·A1 一键成结论验收（≥8 项）。
// 单行复跑：node tools\accept-s42-oneclick.mjs
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { createHash } from 'node:crypto'

process.env.ORB_LOG_DIR = join(tmpdir(), 's42-oc-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's42-oc-data-' + Date.now())
const { dataPath, PROJECT_ROOT } = await import('../packages/core/src/safefs.mjs')
const { runOneClickClaim } = await import('../packages/plugins/coach/one-click.mjs')
const { createStore } = await import('../packages/core/src/db.mjs')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const auditRows = () => {
  const f = join(process.env.ORB_LOG_DIR, 'coach.jsonl')
  try { return readFileSync(f, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)) } catch { return [] }
}

try {
  // 真实 registry + 生命周期桥（与宿主一致，复用 accept-s10-export 模式）
  const dir = mkdtempSync(join(PROJECT_ROOT, 'data', 'db', 's42-oc-'))
  const store = await createStore({ driver: 'sqlite', dbPath: join(dir, 'orb.sqlite'), dataDir: dir })
  store.initMigrations()
  const shotA = join(dir, 'a.png')
  writeFileSync(shotA, 'PNG-A-CONTENT')
  const shaA = createHash('sha256').update('PNG-A-CONTENT').digest('hex')
  store.insertRawFrame({ id: 'rf-oc-a', file_path: shotA, sha256: shaA, sensitivity: 'normal', created_at: new Date().toISOString(), expires_at: new Date(Date.now() + 3600_000).toISOString() })
  const { createRegistry } = await import('../packages/plugins/registry.mjs')
  const reg = createRegistry({ core: {} })
  reg.scan()
  await reg.enable('timeline')
  globalThis.__researchRegistry = reg
  globalThis.researchOrbLifecycle = { store, computeExpiry: (s, m) => new Date(Date.now() + 3600_000).toISOString(), insertRawFrame: (f) => store.insertRawFrame(f) }

  const REPLY = '虚拟电厂的收益机制分容量补偿、电量收益与辅助服务三类，聚合商与电网两级结算。'

  // O-1 全流程 5 步状态条（带证据）
  const r1 = await runOneClickClaim({ lastAssistantText: REPLY, evidence: { frames: ['rf-oc-a'] } })
  check('O-1 全流程 5 步状态条', r1.ok === true && r1.steps.length === 5 && r1.steps.every((s) => s.ok === true),
    `steps=${r1.steps.map((s) => s.name + (s.ok ? '✓' : '✗')).join('→')}`, {})

  // O-2 导出 md+docx 真实存在
  check('O-2 导出 md+docx 存在', r1.md && existsSync(r1.md) && r1.docx && existsSync(r1.docx),
    `md=${r1.md && r1.md.split(/[\\/]/).pop()} docx=${r1.docx && r1.docx.split(/[\\/]/).pop()}`, {})

  // O-3 幂等：同文本再跑 → already:true，不重建（claim 数不变）
  const claimCountBefore = store._db.prepare('SELECT COUNT(*) AS n FROM claim').get().n
  const r2 = await runOneClickClaim({ lastAssistantText: REPLY, evidence: { frames: ['rf-oc-a'] } })
  const claimCountAfter = store._db.prepare('SELECT COUNT(*) AS n FROM claim').get().n
  check('O-3 幂等不重建', r2.already === true && claimCountBefore === claimCountAfter && r2.claimId === r1.claimId,
    `already=${r2.already} claims=${claimCountBefore}→${claimCountAfter}`, {})

  // O-4 降级：无证据 → evidenceMode:none → 证据闸阻断 → 回滚草稿 + 提示
  const r3 = await runOneClickClaim({ lastAssistantText: '没有任何证据的一段回复，测降级路径。' })
  const draftLeft = store._db.prepare("SELECT COUNT(*) AS n FROM claim WHERE status = 'draft'").get().n
  check('O-4 无证据降级（提示+回滚不留半条）', r3.ok === false && r3.error === 'E_NONE_EVIDENCE' && /没有可挂的证据/.test(r3.downgrade || '') && draftLeft === 0,
    `err=${r3.error} drafts=${draftLeft}`, {})

  // O-5 审计行（one-click-* 逐步 + rollback）
  const audits = auditRows().filter((r) => String(r.kind || '').startsWith('one-click'))
  check('O-5 审计行（逐步+回滚）', audits.length >= 8 && audits.some((r) => r.kind === 'one-click-rollback'),
    `audit rows=${audits.length}`, {})

  // O-6 无 CDP（源码静态断言：无 CDP 操作痕迹；"无 CDP"的注释声明不算）
  const src = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'one-click.mjs'), 'utf8')
  const srcNoComments = src.replace(/\/\/[^\n]*/g, '')
  check('O-6 无 CDP/无 UI 自动化', !/remote-debugging|chrome-devtools|playwright|puppeteer|uiautomation/.test(srcNoComments) && /runCommand\('claim'/.test(src),
    `纯 registry 服务调用`, {})

  // O-7 失败步明确（空回复 → step1 失败 + E_NO_REPLY）
  const r7 = await runOneClickClaim({ lastAssistantText: '' })
  check('O-7 失败步明确', r7.ok === false && r7.error === 'E_NO_REPLY' && r7.steps[0].ok === false && r7.steps[0].step === 1,
    `err=${r7.error}`, {})

  // O-8 /coach oneclick 命令接线（静态断言，renderer→IPC→main 直调服务）
  const idx = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'index.mjs'), 'utf8')
  check('O-8 /coach oneclick 接线', idx.includes("sub === 'oneclick'"), `wired=${idx.includes("sub === 'oneclick'")}`, {})

  // O-9 导出内容含结论正文与证据 id
  const mdText = readFileSync(r1.md, 'utf8')
  check('O-9 导出内容完整', mdText.includes('容量补偿') && /rf-oc-a/.test(mdText),
    `md 含正文+证据 id`, {})

  store.close()
  try { rmSync(dir, { recursive: true, force: true }) } catch { /* 尽力 */ }
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's42-oneclick-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s42-oneclick: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
