// tools/accept-s25a-router.mjs —— S25·1B 分层路由验收（桩 net，零真实出网）。
// 单行复跑：node tools\accept-s25a-router.mjs
// 证据：data\logs\s25a-router-accept.json
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync, unlinkSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createRouter, routeOf, TASK_CLASSES } from '../packages/core/src/router.mjs'
import { activate as coachActivate, usageStats } from '../packages/plugins/coach/index.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 240), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's25a-router')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(WORK, { recursive: true })

const PROVIDERS = {
  cheap: { providerId: 'school-gateway', model: 'qwen' },
  flagship: { providerId: 'deepseek-api', model: 'deepseek-chat' },
}

try {
  // ① providers.json：引用形态、无明文密钥
  const pj = join(PROJECT_ROOT, 'data', 'providers.json')
  // S67·3-C：不写死模型版本（现网 flagship 已是 deepseek-v4-pro）——按族匹配 + 读实际值
  check('R1 providers.json 存在且 cheap≈qwen / flagship≈deepseek（读实际 model）', existsSync(pj) && (() => { const d = JSON.parse(readFileSync(pj, 'utf8')); return d.cheap && /qwen/i.test(String(d.cheap.model || '')) && d.flagship && /deepseek/i.test(String(d.flagship.model || '')) })())
  const raw = readFileSync(pj, 'utf8')
  check('R2 无明文密钥（仅 claude-settings:/secrets: 引用）', !/sk-[A-Za-z0-9]{16,}/.test(raw) && /claude-settings:ANTHROPIC_AUTH_TOKEN/.test(raw) && !new RegExp('Bearer\\s+[A-Za-z0-9_-]{20,}').test(raw))

  // ② 档位路由
  check('R3 routeOf：extract→cheap，summarize/score-plan/reason→flagship', routeOf('extract') === 'cheap' && routeOf('summarize') === 'flagship' && routeOf('score-plan') === 'flagship' && routeOf('reason') === 'flagship')
  check('R4 TASK_CLASSES 恰为四档', JSON.stringify([...TASK_CLASSES]) === JSON.stringify(['extract', 'summarize', 'score-plan', 'reason']))

  // ③ 桩 invoke：记录 tier，全部成功
  const usagePath = join(WORK, 'usage.jsonl')
  const tiers = []
  const router = createRouter({
    providers: PROVIDERS,
    invoke: async (p) => { tiers.push(p.tier); return { text: 'stub-' + p.tier, tokens: 10 } },
    usagePath,
    audit: () => {},
  })
  await router.run('extract', { prompt: 'x' })
  check('R5 extract 兑现走 cheap（stub 收到 tier=cheap）', tiers[0] === 'cheap')
  await router.run('summarize', { prompt: 'x' })
  await router.run('score-plan', { prompt: 'x' })
  const rReason = await router.run('reason', { prompt: 'x' })
  check('R6 summarize/score-plan/reason 兑现走 flagship', tiers[1] === 'flagship' && tiers[2] === 'flagship' && tiers[3] === 'flagship' && rReason.tier === 'flagship')

  // ④ 回落
  const usagePath2 = join(WORK, 'usage2.jsonl')
  const audits = []
  let failOnce = true
  const router2 = createRouter({
    providers: PROVIDERS,
    invoke: async (p) => {
      if (p.tier === 'cheap' && failOnce) { failOnce = false; throw Object.assign(new Error('gw down'), { code: 'E_HTTP_500' }) }
      if (p.payload && p.payload.prompt === 'fail-flagship') throw Object.assign(new Error('flagship down'), { code: 'E_HTTP_502' })
      return { text: 'fb-ok' }
    },
    usagePath: usagePath2,
    audit: (rec) => audits.push(rec),
  })
  const out2 = await router2.run('extract', { prompt: 'x' })
  check('R7 cheap 失败 → 回落旗舰一次且成功（fallback=true）', out2.ok === true && out2.tier === 'flagship' && out2.fallback === true)
  check('R8 route-fallback 审计行存在', audits.some((a) => a.kind === 'route-fallback' && a.from === 'cheap' && a.to === 'flagship'))
  const rReasonFail = await router2.run('reason', { prompt: 'fail-flagship' })
  check('R9 reason 永远旗舰：失败不回落（fallback=false）', rReasonFail.ok === false && rReasonFail.fallback === false)

  // ⑤ usage 字段与统计
  const rows = readFileSync(usagePath2, 'utf8').trim().split('\n').map((l) => JSON.parse(l))
  check('R10 usage 行字段齐（provider/model/taskClass/fallback）', rows.every((r) => r.providerId && r.model !== undefined && r.taskClass && typeof r.fallback === 'boolean') && rows.some((r) => r.fallback === true))
  // 喂一条已知行再验统计口径（与 /usage 同一函数）
  const stats = usageStats()
  check('R11 /usage 统计函数可分模型（含 providerId/model/calls）', typeof stats.total === 'number' && Array.isArray(stats.byModel) && stats.byModel.every((m) => m.providerId && m.model && m.calls >= 1))

  // ⑥ 令牌桶排队不失败
  const waits = []
  const limiter = (await import('../packages/core/src/router.mjs')).createRateLimiter({ capPerMin: 2, sleep: async (ms) => { waits.push(ms) } })
  for (let i = 0; i < 6; i++) await limiter.acquire()
  check('R12 令牌桶 6 连发（cap=2）全部排队成功不失败', waits.length >= 4 && waits.every((w) => w >= 0), `waits=${waits.length}次`)

  // ⑦ 未知档位
  let threw = false
  try { await router.run('bogus', {}) } catch (e) { threw = e.code === 'E_TASK_CLASS' }
  check('R13 未知 taskClass → E_TASK_CLASS 且不消耗请求', threw)

  // ⑧ 真实插件命令：/coach / /usage 注册（fake ctx，net 不可用）
  const cmds = {}
  // activate 会真起调度器（写 data/coach/scheduler.json）——D21/D22：记录事前状态，finally 复位
  var SCHED = join(PROJECT_ROOT, 'data', 'coach', 'scheduler.json')
  var schedBefore = existsSync(SCHED) ? readFileSync(SCHED, 'utf8') : null
  const cards = []
  await coachActivate({ net: { available: false }, ui: { registerCommand: (s) => { cmds[s.name] = s.run }, registerCard: (c) => cards.push(c.id) }, log: console })
  check('R14 coach 插件注册 /coach 与 /usage 命令', !!cmds.coach && !!cmds.usage)
  // 先用默认 usage 路径跑一次真实桩路由（写入真实 usage.jsonl 的探针行），再验 /usage 统计
  const routerReal = createRouter({ providers: PROVIDERS, invoke: async () => ({ text: 'probe', tokens: 10 }), audit: () => {} })
  await routerReal.run('extract', { prompt: 'accept-probe' })
  const rUsage = await cmds.usage('')
  check('R15 /usage 输出分模型统计文本（含真实探针行）', rUsage.ok === true && /共 \d+ 次/.test(rUsage.text) && /school-gateway\/qwen/.test(rUsage.text), rUsage.text.split('\n')[1] || '')
} catch (e) {
  check('R0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 240))
} finally {
  try { if (schedBefore === null) { if (existsSync(SCHED)) unlinkSync(SCHED) } else { writeFileSync(SCHED, schedBefore, 'utf8') } } catch (e) { console.error('SCHED_CLEANUP_ERR', (e && e.message || e).toString().slice(0, 160)) }
  rmSync(WORK, { recursive: true, force: true })
}

const pass = items.filter((i) => i.ok).length
const fail = items.length - pass
const out = { tool: 'accept-s25a-router', at: new Date().toISOString(), total: items.length, pass, fail, items }
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's25a-router-accept.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # accept-s25a-router: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 证据 -> data/logs/s25a-router-accept.json`)
process.exit(fail === 0 ? 0 : 1)
