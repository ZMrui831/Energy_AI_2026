// tools/probe-s30-memory.mjs —— S30·P0 长期记忆实机验证（真 Electron）。
// 单行复跑：node tools\probe-s30-memory.mjs
//
// 判据：① 真应用跑一轮后 longterm.md 出现事实条目 ② 读侧取回该事实（注入块）③ 问句不进库
//       ④ enabled=false 注入为空 ⑤ 证据 data/logs/s30-memory.json；残留必须 0。
// 纪律：备份 data\memory\* 与 data\coach\goal.json，finally 原样还原（D21/D22）；只杀自己起的进程树。
import { spawn, spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync, cpSync, rmSync, statSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { readLongTermMemoryContext } from '../packages/plugins/longterm-memory/context.mjs'
import { readLongTermConfig, writeLongTermConfig } from '../packages/plugins/longterm-memory/config.mjs'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('probe-s30-memory')

const ELECTRON_EXE = ORB_ELECTRON
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9349
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const MEM_DIR = join(PROJECT_ROOT, 'data', 'memory')
const GOAL_FILE = join(PROJECT_ROOT, 'data', 'coach', 'goal.json')
const BACKUP = join(PROJECT_ROOT, 'data', 'tmp', 's30-backup')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 240), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

async function findTarget(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await res.json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(t.url))
      if (page) return page
    } catch { /* 还没起来 */ }
    await sleep(300)
  }
  throw new Error(`CDP 目标未找到（port ${PORT}）`)
}
function connect(url) {
  return new Promise((res, rej) => {
    const ws = new WebSocket(url)
    let seq = 0
    const pending = new Map()
    ws.addEventListener('open', () => res({
      send(method, params = {}) {
        const id = ++seq
        return new Promise((ok, no) => {
          const timer = setTimeout(() => { if (pending.has(id)) { pending.delete(id); no(new Error(`CDP 超时 ${method}`)) } }, 30000)
          pending.set(id, { ok: (v) => { clearTimeout(timer); ok(v) }, no: (e) => { clearTimeout(timer); no(e) } })
          ws.send(JSON.stringify({ id, method, params }))
        })
      },
      close: () => ws.close(),
    }))
    ws.addEventListener('error', (e) => rej(new Error('ws error: ' + (e && e.message))))
    ws.addEventListener('message', (ev) => {
      let msg = null
      try { msg = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
      const p = pending.get(msg.id)
      if (!p) return
      pending.delete(msg.id)
      if (msg.error) p.no(new Error(JSON.stringify(msg.error)))
      else p.ok(msg.result)
    })
  })
}
let cdp = null
async function evalJs(body) {
  if (!cdp) throw new Error('CDP 未连接')
  const r = await cdp.send('Runtime.evaluate', { expression: `(async function(){ ${body} })()`, awaitPromise: true, returnByValue: true })
  if (r && r.exceptionDetails) throw new Error('renderer 异常：' + JSON.stringify((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails))
  return r && r.result ? r.result.value : undefined
}
function runningOwnApp() {
  try {
    // S74c·P0-1：只读计数统一走 _orb-proc.countOrbAll（本文件不再内嵌按 app 路径匹配的 PowerShell 串）
    return countOrbAll() > 0
  } catch { return true }
}
function countLines(p) { try { return readFileSync(p, 'utf8').split('\n').filter((l) => l.trim()).length } catch { return 0 } }
function diagRows() {
  const p = join(MEM_DIR, 'project', 'longterm.md.diag.log')
  try { return readFileSync(p, 'utf8').split('\n').filter((l) => l.trim()).map((l) => JSON.parse(l)) } catch { return [] }
}
async function sendChat(text) {
  return evalJs(`globalThis.researchOrb.send('ui', { type: 'chat', text: ${JSON.stringify(text)} }); return true`)
}
async function setupCapture() {
  await evalJs(`
    globalThis.__s30cap = []
    globalThis.researchOrb.on((msg) => {
      try { if (msg && msg.type === 'chat:done') globalThis.__s30cap.push({ at: Date.now(), ms: msg.ms, degraded: !!msg.degraded }) } catch (e) {}
    })
    return true
  `)
}
async function waitDone(sinceMs, timeoutMs = 90000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const caps = await evalJs(`return (globalThis.__s30cap || []).filter(x => x.at >= ${sinceMs}).length`)
      if (caps > 0) return true
    } catch { /* 重试 */ }
    await sleep(1000)
  }
  return false
}

async function main() {
  console.log('# S30·P0 长期记忆实机验证（真 Electron）')
  if (runningOwnApp()) { check('P-pre fail-closed', false, '已有本应用实例在跑：先 stop-app'); throw new Error('fail-closed') }
  check('P-pre 无残留本应用实例（fail-closed）', true)

  // ① 前置备份（D21/D22）：data\memory\* + data\coach\goal.json
  rmSync(BACKUP, { recursive: true, force: true })
  mkdirSync(BACKUP, { recursive: true })
  const memBefore = existsSync(MEM_DIR) ? readdirSync(MEM_DIR) : []
  for (const f of memBefore) cpSync(join(MEM_DIR, f), join(BACKUP, f), { recursive: true })
  const goalBefore = existsSync(GOAL_FILE) ? readFileSync(GOAL_FILE, 'utf8') : null
  check('P1 前置备份完成（data\\memory + goal.json）', true, `memory ${memBefore.length} 项，goal ${goalBefore ? '有' : '无'}`)

  const launchTs = Date.now()
  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN_MJS], { cwd: PROJECT_ROOT, env: childEnv, stdio: 'ignore' })
  let killed = false
  const killOwn = () => { if (killed) return; killed = true; try { spawnSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore' }) } catch {} }

  try {
    const target = await findTarget()
    cdp = await connect(target.webSocketDebuggerUrl)
    await cdp.send('Page.enable'); await cdp.send('Runtime.enable')
    const bridgeOk = await (async () => {
      const dl = Date.now() + 25000
      while (Date.now() < dl) {
        try { if (await evalJs(`return typeof globalThis.researchOrb === 'object' && !!globalThis.researchOrb`)) return true } catch {}
        await sleep(500)
      }
      return false
    })()
    check('P2 真实应用启动 + researchOrb 桥注入', bridgeOk, `port=${PORT}`)
    await setupCapture()
    await evalJs(`globalThis.researchOrb.send('window', { action: 'expand' }); return true`)
    await sleep(800)

    // ② 写一轮事实（真对话通道）
    const FACT = '我叫小测，我在做微电网方向的研究，正在写综述第二章'
    const t2 = Date.now()
    await sendChat(FACT)
    const done2 = await waitDone(t2)
    check('P3 事实轮 runTurn 完成（chat:done 收到）', done2)
    const mdPath = join(MEM_DIR, 'project', 'longterm.md')
    const mdText = existsSync(mdPath) ? readFileSync(mdPath, 'utf8') : ''
    const factRows = mdText.split('\n').filter((l) => l.trim() && !l.startsWith('#') && !l.startsWith('---') && !l.startsWith('<!--')).length
    const hasFact = mdText.includes('小测') || mdText.includes('微电网')
    check('P4 长期记忆实机写入：longterm.md 出现事实条目', existsSync(mdPath) && factRows >= 1 && hasFact, `条目 ${factRows} 条，含关键词=${hasFact}`)

    // ③ 注入可见（读侧取回；renderer 拿不到 system 片段 → 读侧单测式验证，据实注明）
    const ctx = readLongTermMemoryContext({ query: '小测' })
    check('P5 注入块可取回事实（读侧单测式验证）', typeof ctx === 'string' && (ctx.includes('小测') || ctx.includes('微电网')), '样例（打码）：' + String(ctx).replace(/小测/g, '小*').replace(/\s+/g, ' ').slice(0, 90))

    // ④ 跨会话：新开会话后再取
    await evalJs(`globalThis.researchOrb.send('ui', { type: 'session:new' }); return true`)
    await sleep(1000)
    const t4 = Date.now()
    await sendChat('今天继续推进第二章，先看下垂控制那节')
    const done4 = await waitDone(t4)
    const ctx2 = readLongTermMemoryContext({ query: '微电网' })
    check('P6 跨会话仍可取回事实（新 sessionId）', done4 && (ctx2.includes('小测') || ctx2.includes('微电网')), '样例（打码）：' + String(ctx2).replace(/小测/g, '小*').replace(/\s+/g, ' ').slice(0, 90))

    // ⑤ 提问不入库
    const linesBefore = countLines(mdPath)
    const diagBefore = diagRows().length
    const t5 = Date.now()
    await sendChat('我叫什么？')
    const done5 = await waitDone(t5)
    const linesAfter = countLines(mdPath)
    const diagAfter = diagRows().length
    const skippedRow = diagRows().slice(-1)[0] || {}
    check('P7 提问不入库：longterm.md 行数不增', done5 && linesAfter === linesBefore, `${linesBefore} → ${linesAfter}`)
    check('P8 diag.log 出现 skipped 计数（过滤生效可观测）', diagAfter > diagBefore && skippedRow.skipped === 'noise-or-question', JSON.stringify(skippedRow))

    // ⑥ 开关：enabled=false → 读侧空 → 还原
    writeLongTermConfig({ enabled: false })
    const cfgOff = readLongTermConfig()
    const ctxOff = readLongTermMemoryContext({ query: '小测' })
    check('P9 enabled=false → 注入为空（实测）', cfgOff.enabled === false && ctxOff === '', `cfg.enabled=${cfgOff.enabled}，ctx="${ctxOff}"`)
    writeLongTermConfig({ enabled: true })

    // ⑦ 截图取证
    const shot = await cdp.send('Page.captureScreenshot', { format: 'png' })
    const pngPath = join(PROJECT_ROOT, 'data', 'shots', 's30-memory.png')
    mkdirSync(join(PROJECT_ROOT, 'data', 'shots'), { recursive: true })
    writeFileSync(pngPath, Buffer.from(shot.data, 'base64'))
    check('P10 实机截图取证（data/shots/s30-memory.png）', existsSync(pngPath) && statSync(pngPath).size > 1000, `bytes=${statSync(pngPath).size}`)
  } catch (e) {
    check('P0 探针异常', false, String((e && e.stack) || e).slice(0, 240))
  } finally {
    killOwn()
    await sleep(1200)
    // 还原（D21/D22 + 任务书 finally）
    try {
      rmSync(MEM_DIR, { recursive: true, force: true })
      if (memBefore.length) mkdirSync(MEM_DIR, { recursive: true })
      for (const f of memBefore) cpSync(join(BACKUP, f), join(MEM_DIR, f), { recursive: true })
    } catch { /* 尽力 */ }
    try {
      if (goalBefore === null) { if (existsSync(GOAL_FILE)) spawnSync('cmd', ['/c', 'del', '/f', GOAL_FILE], { stdio: 'ignore' }) } else { writeFileSync(GOAL_FILE, goalBefore, 'utf8') }
    } catch { /* 尽力 */ }
    rmSync(BACKUP, { recursive: true, force: true })
    const memNow = existsSync(MEM_DIR) ? readdirSync(MEM_DIR) : []
    check('P11 finally 还原：data\\memory 与 goal.json 复位', JSON.stringify(memNow.sort()) === JSON.stringify(memBefore.sort()), `memory：${memBefore.length} → ${memNow.length} 项`)
    check('P12 残留 0（无孤儿 electron / 无临时备份）', !runningOwnApp() && !existsSync(BACKUP))
  }

  const pass = items.filter((i) => i.ok).length
  const fail = items.length - pass
  const out = { tool: 'probe-s30-memory', at: new Date().toISOString(), total: items.length, pass, fail, items }
  const outPath = join(PROJECT_ROOT, 'data', 'logs', 's30-memory.json')
  mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
  writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
  console.log(`\n  # probe-s30-memory: total=${items.length} pass=${pass} fail=${fail}`)
  console.log(`  # 证据 -> data/logs/s30-memory.json`)
  process.exit(fail === 0 ? 0 : 1)
}

main().catch((e) => { console.error('FATAL', (e && e.message) || e); process.exit(1) })
