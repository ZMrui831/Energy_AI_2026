// tools/coach-trigger.mjs —— S63·P1-1 命令行触发器（演示与验收不依赖 GUI 输入）
// S65·P0-2 扩：加 --perception status / grant / cmd（同 CDP 通道、同一条 plugin:command 路径）。
//
// 背景：面板输入焦点被全屏应用抢占（P0-1），发 /coach 命令要点 4 次才成功——
// 演示与验收改走命令行：CDP 连应用（渲染层）→ researchOrb.send('ui', plugin:command)
// → 主进程 registry 真跑命令（审计/usage 全走既有管线，不绕过任何护栏）。
//
// 用法：
//   node tools\coach-trigger.mjs --run-daily               # 抓屏 + 合并增量 + 归纳评分出日报
//   node tools\coach-trigger.mjs --incremental             # 手动触发一次增量抽取
//   node tools\coach-trigger.mjs --ask                     # 手动问询
//   node tools\coach-trigger.mjs --cmd "goal show"         # 任意 /coach 子命令
//   node tools\coach-trigger.mjs --perception status        # 读感知状态（同意/预算/今日计数）
//   node tools\coach-trigger.mjs --perception grant         # 走 GUI 授权按钮（替人点，不绕过确认）
//   node tools\coach-trigger.mjs --perception cmd "revoke"  # 任意 /perception 子命令（原样下发）
//   node tools\coach-trigger.mjs --plugin theme --cmd "use teal"   # 通用：任意插件命令
//   通用参数：--port 9336（CDP 端口）--timeout 90000
//
// 失败语义（三条，与 S63 一致，扩展后不变）：
//   ① 连不上 CDP / 渲染层桥未就绪 → exit 1；
//   ② 命令未被处理（超时内无任何回执/审计变化）→ exit 1；
//   ③ 命令返回 ok:false（探针收到 ok:false，或 coach 侧审计显示跳过/失败）→ exit 1。
// 不静默：每条都打印具体原因。
//
// ⚠️ 授权口径（必须读）：`--perception grant` **不是用户授权入口**。
// 它只是替验收/演示把"设置页 → 授权屏幕记录（本次会话）"这一步点掉（同一个按钮、
// 同一条 /perception grant 命令、同一条 consent-granted 审计），**不绕过任何确认语义**；
// 真实用户授权仍然是应用内那个按钮。找不到按钮就直接失败退出（没有后门）。

import { existsSync, readFileSync, statSync } from 'node:fs'
import {join, resolve} from 'node:path'

const argv = process.argv.slice(2)
const arg = (name, def = null) => {
  const i = argv.indexOf(name)
  return i >= 0 && argv[i + 1] !== undefined ? argv[i + 1] : def
}
const has = (name) => argv.includes(name)
const PORT = Number(arg('--port', 9336))
const TIMEOUT = Number(arg('--timeout', 90000))
const ROOT = resolve(import.meta.dirname, '..')

let plugin = 'coach'
let cmd = null
let mode = 'command' // command | perception-status | perception-grant
if (has('--perception')) {
  plugin = 'perception'
  const raw = arg('--perception', null)
  const v = raw && !String(raw).startsWith('-') ? String(raw) : 'status'
  if (v === 'status') { cmd = 'status'; mode = 'perception-status' }
  else if (v === 'grant') { cmd = 'grant session'; mode = 'perception-grant' }
  else if (v === 'cmd') { cmd = String(arg('--cmd', 'status')) }
  else {
    console.error('[coach-trigger] --perception 只支持 status | grant | cmd "<子命令>"')
    process.exit(2)
  }
} else if (arg('--plugin')) {
  plugin = String(arg('--plugin'))
  cmd = String(arg('--cmd', ''))
} else if (has('--run-daily')) cmd = 'run-daily'
else if (has('--incremental')) cmd = 'run-incremental'
else if (has('--ask')) cmd = 'ask'
else if (arg('--cmd')) cmd = String(arg('--cmd'))
if (cmd === null) {
  console.error('[coach-trigger] 未指定命令：--run-daily | --incremental | --ask | --cmd "<coach 子命令>" | --perception status|grant|cmd')
  process.exit(2)
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function findTarget(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await res.json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(String(t.url || '')))
      if (page) return page
    } catch { /* 应用未起/端口未开 → 继续等 */ }
    await sleep(400)
  }
  return null
}

// 极简 CDP WebSocket 客户端（无依赖）
function cdpConnect(url) {
  const WebSocket = globalThis.WebSocket || null
  if (!WebSocket) throw new Error('本 Node 无内置 WebSocket（需 ≥22）')
  const ws = new WebSocket(url)
  let id = 0
  const pending = new Map()
  ws.addEventListener('message', (ev) => {
    try {
      const m = JSON.parse(String(ev.data))
      if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id) }
    } catch { /* 非 JSON 忽略 */ }
  })
  const ready = new Promise((res, rej) => {
    ws.addEventListener('open', res)
    ws.addEventListener('error', () => rej(new Error('CDP WebSocket 连接失败')))
  })
  const send = (method, params = {}) => new Promise((res, rej) => {
    const mid = ++id
    pending.set(mid, (m) => (m.error ? rej(new Error(m.error.message)) : res(m.result)))
    ws.send(JSON.stringify({ id: mid, method, params }))
    setTimeout(() => { if (pending.has(mid)) { pending.delete(mid); rej(new Error('CDP 响应超时：' + method)) } }, TIMEOUT)
  })
  return { ready, send, close: () => { try { ws.close() } catch { /* noop */ } } }
}

const ev = async (cdp, expression) => {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r && r.exceptionDetails) throw new Error('evaluate: ' + JSON.stringify(r.exceptionDetails).slice(0, 200))
  return r && r.result ? r.result.value : undefined
}

const fileSize = (p) => (existsSync(p) ? statSync(p).size : -1)
const logTail = (p, n = 6) => {
  if (!existsSync(p)) return []
  return readFileSync(p, 'utf8').split('\n').filter((l) => l.trim()).slice(-n)
}

async function main() {
  const target = await findTarget()
  if (!target) {
    console.error(`[coach-trigger] ✗ 找不到应用（127.0.0.1:${PORT} 无 floating.html）——请先启动 research-orb（应用在跑才能触发命令）`)
    process.exit(1)
  }
  const cdp = cdpConnect(target.webSocketDebuggerUrl)
  await cdp.ready
  await cdp.send('Runtime.enable')
  const bridge = await cdp.send('Runtime.evaluate', { expression: 'typeof globalThis.researchOrb === "object" && !!globalThis.researchOrb', returnByValue: true })
  if (!bridge.result || bridge.result.value !== true) {
    console.error('[coach-trigger] ✗ 渲染层 researchOrb 桥未就绪（应用还在启动？）')
    process.exit(1)
  }

  // 记录触发前审计状态（用于确认命令真的被处理）
  const coachLog = join(ROOT, 'data', 'logs', 'coach.jsonl')
  const usageLog = join(ROOT, 'data', 'logs', 'usage.jsonl')
  const perceptionLog = join(ROOT, 'data', 'logs', 'perception.jsonl')
  const coachSize0 = fileSize(coachLog)
  const usageSize0 = fileSize(usageLog)
  const perceptionSize0 = fileSize(perceptionLog)

  // S65·P0-2 回包探针：主进程只在命令回包带 ui 时把结果转发给渲染层（forwardPluginPanel），
  // 探针挂在 researchOrb.onPanel(<pluginId>) 上，能同时拿到 ok:true 与 ok:false 两种回执 →
  // "命令未被处理" 与 "命令返回 ok:false" 两条失败语义都可判定（不靠猜）。
  // 注意：`researchOrb` 是底座暴露的**上行通道**（只有 send）；领域工具箱是 `globalThis.__ro`
  // （ui-bridge 末尾 `globalThis.__ro = R`，onPanel/onMsg 都在它上面）——探针必须挂 __ro。
  const probeExpr = `(() => {
    try {
      globalThis.__roProbe = { hits: [] }
      const R = globalThis.__ro || globalThis.researchOrb
      if (R && typeof R.onPanel === 'function') {
        R.onPanel(${JSON.stringify(plugin)}, (m) => {
          globalThis.__roProbe.hits.push({ name: (m && m.name) || null, ok: m ? m.ok !== false : null, code: (m && m.code) || null, kind: (m && m.ui && m.ui.kind) || null, message: (m && (m.message || (m.ui && m.ui.message))) || null })
        })
        return 'probe-on'
      }
      return 'no-onpanel'
    } catch (e) { return 'probe-fail:' + String((e && e.message) || e) }
  })()`
  const probe = await ev(cdp, probeExpr)
  console.log('[coach-trigger] 回包探针：' + probe)

  // ---- perception grant：走 GUI 授权按钮（与人点等价，不绕过确认）----
  if (mode === 'perception-grant') {
    await ev(cdp, `globalThis.researchOrb.send('window', { action: 'expand' })`)
    await sleep(1200)
    const nav = await ev(cdp, `(() => {
      const b = document.querySelector('#ro-ds-nav .ds-nav-btn[data-page="settings"]')
      if (b) { b.click(); return 'nav-clicked' }
      if (globalThis.__s5 && typeof globalThis.__s5.page === 'function') { try { globalThis.__s5.page('settings'); return 's5-settings' } catch (e) { return 's5-fail' } }
      return 'not-found'
    })()`)
    await sleep(900)
    const clicked = await ev(cdp, `(() => {
      const btns = Array.from(document.querySelectorAll('#panel button'))
      const b = btns.find((x) => /授权屏幕记录/.test((x.textContent || '')))
      if (b) { b.click(); return 'clicked' }
      return 'not-found'
    })()`)
    if (clicked !== 'clicked') {
      console.error(`[coach-trigger] ✗ 没找到设置页的「授权屏幕记录（本次会话）」按钮（nav=${nav}）——命令行不提供绕过确认的后门，请在应用内点该按钮`)
      process.exit(1)
    }
    console.log('[coach-trigger] 已点「授权屏幕记录（本次会话）」（与人点同一按钮/同一命令/同一审计），等待授权生效…')
    const deadline = Date.now() + Math.min(TIMEOUT, 20000)
    let grantedByAudit = false
    let grantedByUi = false
    while (Date.now() < deadline) {
      await sleep(700)
      if (perceptionSize0 >= 0 && fileSize(perceptionLog) !== perceptionSize0) {
        const tail = logTail(perceptionLog, 5)
        if (tail.some((l) => /consent-granted/.test(l))) { grantedByAudit = true; break }
      }
      const ui = await ev(cdp, `(() => { try { return /已授权屏幕记录/.test(document.body.innerText || '') } catch (e) { return false } })()`)
      if (ui === true) { grantedByUi = true; break }
      const hits = await ev(cdp, '(() => { try { return (globalThis.__roProbe && globalThis.__roProbe.hits) || [] } catch (e) { return [] } })()')
      if (Array.isArray(hits) && hits.some((h) => h && h.kind === 'consent' && h.ok === true)) { grantedByUi = true; break }
    }
    if (!grantedByAudit && !grantedByUi) {
      console.error('[coach-trigger] ✗ 20s 内未见授权生效（perception.jsonl 无新 consent-granted，界面也无授权提示）——命令未被处理或返回失败')
      process.exit(1)
    }
    const hits = await ev(cdp, '(() => { try { return (globalThis.__roProbe && globalThis.__roProbe.hits) || [] } catch (e) { return [] } })()')
    if (Array.isArray(hits) && hits.some((h) => h && h.ok === false)) {
      console.error('[coach-trigger] ✗ 命令返回 ok:false：' + JSON.stringify(hits.filter((h) => h && h.ok === false)))
      process.exit(1)
    }
    const tail = logTail(perceptionLog, 3)
    if (!grantedByAudit && perceptionSize0 < 0) console.log('[coach-trigger] 注：data\\logs\\perception.jsonl 不存在（实例可能用了 ORB_DATA_DIR 隔离，审计写在别处）→ 以界面回执判定')
    console.log('[coach-trigger] ✓ 授权已生效（' + (grantedByAudit ? 'perception.jsonl consent-granted' : '界面回执') + '）。perception.jsonl 尾部：')
    for (const l of tail) console.log('  ' + l.slice(0, 300))
    cdp.close()
    process.exit(0)
  }

  // 发命令（渲染层 send → main plugin:command → registry.runCommand(plugin, args)）
  const expr = `globalThis.researchOrb.send('ui', { type: 'plugin:command', name: ${JSON.stringify(plugin)}, args: ${JSON.stringify(cmd)} })`
  await cdp.send('Runtime.evaluate', { expression: expr, returnByValue: true })
  console.log(`[coach-trigger] 已发 /${plugin} ${cmd}，等待命令处理…`)

  // 轮询：coach 侧看审计/usage 变化；perception 侧看回包探针（带 ui 的回包才会转发到渲染层）
  const deadline = Date.now() + TIMEOUT
  let processed = false
  let how = ''
  // S69·1B：coach 命令以 **coach.jsonl 审计** 为准——perception.jsonl 的 sent-to-model 增量是
  // 背景抽取的噪声，绝不能当"命令已处理"（此前正是这样误判）；perception 命令才看 perception.jsonl。
  const isCoach = plugin === 'coach'
  while (Date.now() < deadline) {
    await sleep(1000)
    const auditChanged = isCoach ? (fileSize(coachLog) !== coachSize0) : (fileSize(perceptionLog) !== perceptionSize0)
    if (auditChanged) { processed = true; how = isCoach ? 'coach.jsonl 审计变化' : 'perception.jsonl 审计变化'; break }
    const hits = await ev(cdp, '(() => { try { return (globalThis.__roProbe && globalThis.__roProbe.hits) || [] } catch (e) { return [] } })()').catch(() => [])
    if (Array.isArray(hits) && hits.length > 0) { processed = true; how = '回包探针'; break }
  }
  if (!processed) {
    console.error(`[coach-trigger] ✗ ${TIMEOUT}ms 内未见 /${plugin} ${cmd} 被处理（审计与回包都无变化）——检查命令是否存在、consent 是否激活`)
    process.exit(1)
  }
  // 给命令完整跑完留一点时间（daily/ask 可能 10-30s），再收尾
  await sleep(3000)
  const hits = await ev(cdp, '(() => { try { return (globalThis.__roProbe && globalThis.__roProbe.hits) || [] } catch (e) { return [] } })()').catch(() => [])
  if (Array.isArray(hits) && hits.some((h) => h && h.ok === false)) {
    const bad = hits.filter((h) => h && h.ok === false)
    // S69·1B：ok:false 时打印 code/message（可判因），不靠猜
    console.error(`[coach-trigger] ✗ /${plugin} ${cmd} 返回 ok:false：` + JSON.stringify(bad.map((h) => ({ name: h.name, code: h.code, message: h.message, kind: h.kind }))))
    process.exit(1)
  }
  // 失败语义③的快路径：命令未执行时主进程推 chat:notice（"命令 /x 未执行：<错误>"）→ 界面可见
  const failText = await ev(cdp, `(() => { try { const m = /命令 \\/[^\\s]+ 未执行：[^\\n]*/.exec(document.body.innerText || ''); return m ? m[0] : null } catch (e) { return null } })()`).catch(() => null)
  if (failText) {
    console.error(`[coach-trigger] ✗ /${plugin} ${cmd} 返回失败（界面回执）：${failText}`)
    process.exit(1)
  }
  console.log(`[coach-trigger] ✓ /${plugin} ${cmd} 已处理（判定依据：${how}）`)
  if (Array.isArray(hits) && hits.length) console.log('[coach-trigger] 回包：' + JSON.stringify(hits.slice(0, 3)))
  const tail = logTail(coachLog, 4)
  if (tail.length) {
    console.log('[coach-trigger] coach.jsonl 尾部：')
    for (const l of tail) console.log('  ' + l.slice(0, 300))
  }
  const pTail = logTail(perceptionLog, 3)
  if (pTail.length && fileSize(perceptionLog) !== perceptionSize0) {
    console.log('[coach-trigger] perception.jsonl 尾部：')
    for (const l of pTail) console.log('  ' + l.slice(0, 300))
  }
  const usageTail = logTail(usageLog, 2)
  if (usageTail.length && fileSize(usageLog) !== usageSize0) {
    console.log('[coach-trigger] usage.jsonl 尾部：')
    for (const l of usageTail) console.log('  ' + l.slice(0, 300))
  }
  cdp.close()
  process.exit(0)
}

main().catch((e) => {
  console.error('[coach-trigger] ✗ ' + String((e && e.message) || e))
  process.exit(1)
})
