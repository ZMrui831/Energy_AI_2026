// tools/run-tests.mjs
//
// 跨平台测试运行器（npm test 入口）。
//
// 为什么需要它：
//   WorkBuddy 的 node 注入了 safe-delete 拦截层，会把 fs.rmSync/rm 转成对
//   genie-trash 二进制的一次子进程调用。测试清理只删除项目内的临时目录
//   （data/tmp、data/browser、data/logs 下的探针等），不涉及任何用户文件；
//   但在并行/高负载下 genie-trash 偶尔 ETIMEDOUT，导致"清理阶段"偶发失败、
//   拉低测试绿灯率。这里显式关闭该拦截（仅对测试子进程生效），让删除走原生
//   fs，既不影响断言，也消除环境性抖动。
//
//   - 串行执行（--test-concurrency=1）进一步降低 IO 竞争。
//   - 不修改任何测试逻辑，只决定"如何启动测试进程"。
//
// S33·C 日志隔离：启动时把 ORB_LOG_DIR 指到 %TEMP%\orb-test-logs-<pid>，
//   子进程所有 logPath/appendJsonl/writes 审计都写临时目录，**真实 data/logs 零改动**；
//   结束时打印该目录各文件行数（留证），且**不删除**（便于取证）。
// S33·D 残留清理：开头调用 clean-test-residue，清掉上一轮 test-b4-*/tmp 残留。

import { spawnSync } from 'node:child_process'
import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { fileURLToPath } from 'node:url'
import { dirname, join, resolve } from 'node:path'
import { cleanResidue, releaseStaleLocks } from './clean-test-residue.mjs'

const __dirname = dirname(fileURLToPath(import.meta.url))
const ROOT = resolve(__dirname, '..')

// 仅对本次派生的测试子进程关闭 safe-delete 拦截（测试清理只动项目内临时目录）。
process.env.CODEBUDDY_SAFE_DELETE_ENABLED = '0'

// S33·C：日志隔离目录（子进程继承该 env；safefs 据此改写 LOG_DIR）。
const isoLogDir = join(tmpdir(), `orb-test-logs-${process.pid}`)
process.env.ORB_LOG_DIR = isoLogDir
// S34·P0：数据目录隔离——整棵 data 树进临时目录，真实 data\ 其余目录零写入。
const isoDataDir = join(tmpdir(), `orb-test-data-${process.pid}`)
process.env.ORB_DATA_DIR = isoDataDir
// S34-fix: ORB_DATA_DIR 必须真实存在，否则子进程 mkdtemp/写入会 ENOENT
try {
  for (const sub of ['', 'tmp', 'browser', 'artifacts', 'notes', 'themes', 'coach', 'memory']) {
    mkdirSync(join(isoDataDir, sub), { recursive: true })
  }
} catch (e) {
  console.error('[run-tests] 创建 ORB_DATA_DIR 失败：' + e.message)
  process.exit(1)
}

// S34·P0：播种小体积种子资产——临时数据树需要内置主题/mode 定义/字体/fixtures/策略文件才能跑通。
try {
  const SEED = ['config.json', 'lean-policy.json', 'lifecycle-config.json', 'agent-tools.json', 'providers.json', 'secrets.json', 'modes', 'themes', 'fonts', 'fixtures', 'packs']
  let seeded = 0
  for (const name of SEED) {
    const src = join(ROOT, 'data', name)
    if (!existsSync(src)) continue
    cpSync(src, join(isoDataDir, name), { recursive: true })
    seeded++
  }
  console.log('[run-tests] 种子资产：' + seeded + '/' + SEED.length + ' 项已复制到临时数据目录')
} catch (e) {
  console.log('[run-tests] 种子复制失败（忽略）：' + String((e && e.message) || e))
}

// S33·D：启动先清残留（幂等；失败不阻断，只记录）。
try {
  const cleaned = cleanResidue({ root: ROOT })
  console.log(`[run-tests] 残留清理：before=${cleaned.before} after=${cleaned.after} removed=${cleaned.removed.length}${cleaned.remaining.length ? ' 仍残留=' + cleaned.remaining.join(',') : ''}`)
} catch (e) {
  console.log('[run-tests] 残留清理异常（忽略）：' + String((e && e.message) || e))
}
console.log(`[run-tests] 日志隔离：ORB_LOG_DIR=${isoLogDir}（测试期真实 data/logs 不被写入）`)
console.log(`[run-tests] 数据隔离：ORB_DATA_DIR=${isoDataDir}（测试期真实 data\ 其余目录零写入）`)

// S33：释放陈旧文件锁（把可重建的 config/demo/hello/packs journal 重命名进 data/tmp，避免 Windows 监视锁导致 EPERM）。
try {
  const moved = releaseStaleLocks({ root: ROOT })
  console.log(`[run-tests] 释放陈旧锁：${moved.length} 项${moved.length ? ' → ' + moved.join(', ') : ''}`)
} catch (e) {
  console.log('[run-tests] 释放陈旧锁异常（忽略）：' + String((e && e.message) || e))
}

// S55·B1：命令名冲突检测（重名 = registry 按注册顺序先到先得 = 后注册者静默失联）。
// 放在测试之前：撞名属于"启动即坏"的架构级缺陷，不该等 904 项跑完才发现。
try {
  const col = spawnSync(process.execPath, [join(__dirname, 'check-cmd-collision.mjs')], { cwd: ROOT, encoding: 'utf8' })
  if (col.status !== 0) {
    console.error(col.stdout || '')
    console.error(col.stderr || '')
    console.error('[run-tests] ✗ 命令名冲突检测失败 —— 先修冲突再跑测试（注册顺序决定谁生效，后注册者会静默失联）')
    process.exit(1)
  }
  const summary = String(col.stdout || '').split('\n').find((l) => l.includes('# check-cmd-collision')) || ''
  console.log('[run-tests] 命令冲突检测通过：' + summary.trim())
} catch (e) {
  console.log('[run-tests] 命令冲突检测异常（忽略）：' + String((e && e.message) || e))
}

// S61·P0-1 前置：providers 所有出网域名必须在白名单（换 provider 忘同步 domains.json
// 会让第一次真实调用才炸 —— E_DOMAIN_NOT_ALLOWED，实测教训）。
try {
  const pd = spawnSync(process.execPath, [join(__dirname, 'check-provider-domains.mjs')], { cwd: ROOT, encoding: 'utf8' })
  if (pd.status !== 0) {
    console.error(pd.stdout || '')
    console.error(pd.stderr || '')
    console.error('[run-tests] ✗ provider 域名白名单检测失败 —— 换 provider 必须同步 domains.json（见 tools\\check-provider-domains.mjs）')
    process.exit(1)
  }
  const pdSummary = String(pd.stdout || '').split('\n').find((l) => l.includes('# check-provider-domains')) || ''
  console.log('[run-tests] provider 域名白名单检测通过：' + pdSummary.trim())
} catch (e) {
  console.log('[run-tests] provider 域名检测异常（忽略）：' + String((e && e.message) || e))
}

const testsDir = join(ROOT, 'tests')
const files = readdirSync(testsDir)
  .filter((f) => f.endsWith('.test.mjs'))
  .sort()
  .map((f) => join(testsDir, f))

const extra = process.argv.slice(2)
const args = ['--test', '--test-concurrency=1', ...extra, ...files]

const res = spawnSync(process.execPath, args, { cwd: ROOT, stdio: 'inherit' })

// S33·C：结束打印隔离日志目录行数（留证，不删除）。
try {
  if (existsSync(isoLogDir)) {
    const logs = readdirSync(isoLogDir).filter((f) => f.endsWith('.jsonl'))
    const rows = logs.map((f) => {
      let n = 0
      try { n = readFileSync(join(isoLogDir, f), 'utf8').split('\n').filter(Boolean).length } catch { /* 读不到记 0 */ }
      return `${f}=${n}`
    })
    console.log(`[run-tests] 隔离日志留证目录（不删除）：${isoLogDir}`)
    console.log(`[run-tests] 行数：${rows.length ? rows.join('  ') : '（无 jsonl）'}`)
  } else {
    console.log(`[run-tests] 隔离日志目录未产生：${isoLogDir}`)
  }
} catch (e) {
  console.log('[run-tests] 打印隔离日志行数失败（忽略）：' + String((e && e.message) || e))
}

process.exit(res.status ?? 1)
