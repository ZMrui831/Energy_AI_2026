// tools/accept-s32-plans.mjs —— S32·2 计划提醒执行闭环验收（≥10 项）。
// 单行复跑：node tools\accept-s32-plans.mjs
// 证据：data\logs\s32-plans-accept.json
//
// 覆盖：add(落盘+审计) / list / done(状态+审计+入记忆) / drop(状态+审计+入记忆) /
//      到期 duePlans / 调度器 plan-due 触发一次 / 同一计划只提醒一次 / 提醒卡出口 /
//      已完成不再到期 / 事件流折叠取最新态 / 空文本 fail-closed。
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createPlanStore } from '../packages/plugins/coach/plans.mjs'
import { createScheduler } from '../packages/plugins/coach/scheduler.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's32-plans')
rmSync(WORK, { recursive: true, force: true })
const COACH = join(WORK, 'coach')
const SCHED = join(WORK, 'sched')
mkdirSync(COACH, { recursive: true })
mkdirSync(SCHED, { recursive: true })

let t = 1_000_000
const now = () => t
const audits = []
const mem = []
const memory = { saveMemory: (x) => { mem.push(x); return { file: 'mem-' + mem.length + '.md' } }, markDone: () => {} }
const plans = createPlanStore({ dir: COACH, now, audit: (r) => audits.push(r), memory })

try {
  // P1：add 落盘 + 审计
  const a = plans.add({ text: '补做下垂控制频带整定', dueAt: new Date(t + 60_000).toISOString() })
  const fileHasRow = existsSync(join(COACH, 'plans.jsonl')) && readFileSync(join(COACH, 'plans.jsonl'), 'utf8').includes(a.id)
  check('P1', a.status === 'pending' && fileHasRow && audits.some((r) => r.kind === 'plan-add' && r.id === a.id),
    `id=${a.id} status=${a.status} row=${fileHasRow} audit=${audits.some((r) => r.kind === 'plan-add')}`, { a })

  // P2：list 含该计划
  const list1 = plans.list()
  check('P2', list1.some((p) => p.id === a.id && p.text.includes('频带')), `list=${list1.length}`, { ids: list1.map((p) => p.id) })

  // P5：到期 duePlans（t+60s 后）
  const due = plans.duePlans(t + 120_000)
  check('P5', due.some((p) => p.id === a.id), `due=${due.map((p) => p.id)}`, { due })

  // P3：done → 状态 + 审计 + 入记忆
  const d = plans.done(a.id)
  const memDone = mem.some((m) => (m.title || '').includes('计划完成'))
  check('P3', d.status === 'done' && audits.some((r) => r.kind === 'plan-done' && r.id === a.id) && memDone,
    `status=${d.status} audit=${audits.some((r) => r.kind === 'plan-done')} mem=${memDone}`, { mem })

  // P9：已完成不再到期
  const due2 = plans.duePlans(t + 120_000)
  check('P9', !due2.some((p) => p.id === a.id), `dueAfterDone=${due2.map((p) => p.id)}`, { due2 })

  // P10：事件流折叠取最新态（list 里 a 为 done）
  const aState = plans.list().find((p) => p.id === a.id)
  check('P10', aState && aState.status === 'done', `foldStatus=${aState && aState.status}`, { aState })

  // P4：drop → 状态 + 审计 + 入记忆
  const b = plans.add({ text: '整理参考文献' })
  const dr = plans.drop(b.id)
  const memDrop = mem.some((m) => (m.title || '').includes('已放弃'))
  check('P4', dr.status === 'dropped' && audits.some((r) => r.kind === 'plan-dropped' && r.id === b.id) && memDrop,
    `status=${dr.status} audit=${audits.some((r) => r.kind === 'plan-dropped')} mem=${memDrop}`, {})

  // P11：空文本 fail-closed
  let emptyErr = null
  try { plans.add({ text: '   ' }) } catch (e) { emptyErr = e && e.code }
  check('P11', emptyErr === 'E_EMPTY_TEXT', `code=${emptyErr}`, {})

  // P6/P7/P8：调度器 plan-due 触发一次 + 同一计划只提醒一次 + 提醒卡出口
  const cards = []
  const fired = []
  const sched = createScheduler({
    dir: SCHED, now: () => t,
    onTrigger: async (kind, info) => {
      fired.push({ kind, info })
      if (kind === 'plan-due') cards.push({ id: info && info.id, text: info && info.text })
    },
  })
  sched.start()
  const duePlan = { id: 'pl-due-1', text: '写周报' }
  const r1 = await sched.feed({ duePlans: [duePlan] })
  const r2 = await sched.feed({ duePlans: [duePlan] })
  const fireCount = fired.filter((f) => f.kind === 'plan-due').length
  check('P6', r1.length === 1 && r1[0] === true && fireCount === 1, `r1=${r1} fire=${fireCount}`, { fired })
  check('P7', r2.length === 0 && fireCount === 1, `r2=${r2} fire=${fireCount}（第二次不再触发）`, {})
  check('P8', cards.length === 1 && cards[0].id === 'pl-due-1' && String(cards[0].text).includes('周报'),
    `cards=${JSON.stringify(cards)}`, { cards })

  // 附加：counters 记录 plan-due
  const st = sched.state()
  check('P12', st.counters['plan-due'] === 1 && Array.isArray(st.remindedPlans) && st.remindedPlans.includes('pl-due-1'),
    `counter=${st.counters['plan-due']} reminded=${st.remindedPlans}`, {})
  sched.stop()
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
}

const pass = items.filter((i) => i.ok).length
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(join(PROJECT_ROOT, 'data', 'logs', 's32-plans-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s32-plans: total=${items.length} pass=${pass} fail=${items.length - pass}`)
console.log('  # 证据 -> data/logs/s32-plans-accept.json')
process.exit(pass === items.length ? 0 : 1)
