// tools/diag-s55-consent.mjs —— S55·D 前置：授权→学习→采集 链路真实验证
//
// 目的：证明"教练线能不能用"的根本链路已通（此前 consent.grant 全仓库无调用方）：
//   点设置页「授权屏幕记录」→ consent-granted 审计 + 回执 → 点「开始学习」→ learn-start 审计
//   → 采集运行 45s → perception.jsonl 有今日事件 + 感知卡数字真实
//
// 用法：node tools\diag-s55-consent.mjs   （需应用退出；fail-closed；隔离数据目录）

import { mkdtempSync, rmSync, cpSync, existsSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import { spawn, spawnSync } from 'node:child_process'
import {killMarked, countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('diag-s55-consent')

const ELECTRON = ORB_ELECTRON
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9346
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}
const countProcs = () => countOrbAll()
const killOwn = () => killMarked(MARK)

async function findTarget(t = 40000) {
  const d = Date.now() + t
  while (Date.now() < d) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const l = await r.json()
      const p = l.find((x) => x.type === 'page' && x.webSocketDebuggerUrl && /floating\.html/i.test(String(x.url || '')))
      if (p) return p
    } catch { /* 等 */ }
    await sleep(350)
  }
  return null
}
function cdpConnect(wsUrl) {
  const ws = new WebSocket(wsUrl)
  let seq = 0
  const pending = new Map()
  const ready = new Promise((res, rej) => { ws.addEventListener('open', () => res()); ws.addEventListener('error', () => rej(new Error('ws'))) })
  ws.addEventListener('message', (ev) => {
    let m = null
    try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
    if (!m || !m.id) return
    const p = pending.get(m.id); if (!p) return
    pending.delete(m.id)
    if (m.error) p.rej(new Error(JSON.stringify(m.error))); else p.res(m.result)
  })
  const send = (method, params) => new Promise((res, rej) => { const id = ++seq; pending.set(id, { res, rej }); ws.send(JSON.stringify({ id, method, params })) })
  return { ready, send, close: () => { try { ws.close() } catch { /* noop */ } } }
}
async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r && r.exceptionDetails) throw new Error('ev: ' + JSON.stringify(r.exceptionDetails).slice(0, 240))
  return r && r.result ? r.result.value : undefined
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s55-consent-'))
let child = null
let cdp = null
const logDir = () => join(tmpRoot, 'data', 'logs')
const readLog = (name) => {
  const p = join(logDir(), name)
  try { return existsSync(p) ? readFileSync(p, 'utf8') : '' } catch { return '' }
}
try {
  if (countProcs() > 0) { console.log('PREFLIGHT-FAIL: 已有实例在跑'); process.exit(2) }
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  delete env.ORB_LOG_DIR
  env.ORB_DATA_DIR = join(tmpRoot, 'data')
  try { cpSync(join(PROJECT_ROOT, 'data', 'themes'), join(env.ORB_DATA_DIR, 'themes'), { recursive: true }) } catch { /* 就算了 */ }
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], { cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] })
  const target = await findTarget()
  if (!target) { console.log('NO-TARGET'); process.exit(3) }
  cdp = cdpConnect(target.webSocketDebuggerUrl)
  await cdp.ready
  await cdp.send('Runtime.enable')
  let bridge = false
  const dl = Date.now() + 30000
  while (Date.now() < dl) {
    try { bridge = await ev(cdp, 'typeof globalThis.__s5 === "object" && typeof globalThis.researchOrb === "object"'); if (bridge) break } catch { /* 等 */ }
    await sleep(400)
  }
  if (!bridge) { console.log('NO-BRIDGE'); process.exit(3) }
  await ev(cdp, 'globalThis.researchOrb.send("window", { action: "expand" })')
  await sleep(2200)
  // 首启引导挡住首页按钮 → 先跳过
  await ev(cdp, `(() => { const c = document.getElementById('ro-onboard-card'); if (c && getComputedStyle(c).display !== 'none') { const b = [...c.querySelectorAll('button')].find((x) => /跳过/.test(x.textContent || '')); if (b) b.click() } return 1 })()`)
  await sleep(400)

  const noticeText = () => ev(cdp, `(() => { const n = document.getElementById('s5-notice'); return n && n.style.display !== 'none' ? (n.textContent || '').trim() : '' })()`)
  const goNav = async (p) => { await ev(cdp, `(() => { const b = document.querySelector('#ro-ds-nav .ds-nav-btn[data-page="${p}"]'); if (b) b.click(); return !!b })()`); await sleep(800) }

  // 1) 设置页 → 点授权按钮
  await goNav('settings')
  const granted = await ev(cdp, `(() => {
    const b = [...document.querySelectorAll('#s5-settings button')].find((x) => /授权屏幕记录/.test(x.textContent || ''))
    if (!b) return 'missing'
    b.click()
    return 'ok'
  })()`)
  await sleep(2500)
  const noticeAfterGrant = await noticeText()
  const consentAudit = /consent-granted/.test(readLog('perception.jsonl'))
  check('D-1 设置页存在「授权屏幕记录」按钮并已点击', granted === 'ok', String(granted))
  check('D-2 授权回执可见（consent 4h / 重启失效）', /授权/.test(String(noticeAfterGrant)), JSON.stringify(String(noticeAfterGrant).slice(0, 90)))
  check('D-3 审计落 consent-granted（perception.jsonl）', consentAudit, consentAudit ? 'yes' : 'no')

  // 2) 首页 → 开始学习
  await goNav('home')
  const learnBefore = (readLog('timeline.jsonl').match(/learn-start/g) || []).length
  await ev(cdp, `(() => { const b = document.querySelector('#s5-home [data-act="learn"]'); if (b) b.click(); return !!b })()`)
  await sleep(5000)
  const learnAfter = (readLog('timeline.jsonl').match(/learn-start/g) || []).length
  const noticeAfterLearn = await noticeText()
  check('D-4 开始学习成功（learn-start 审计新增）', learnAfter > learnBefore, JSON.stringify({ before: learnBefore, after: learnAfter, notice: String(noticeAfterLearn).slice(0, 80) }))

  // 3) 采集运行 45s：events 增长（1Hz 元数据），帧数视屏幕变化
  const st1 = JSON.parse(await ev(cdp, `(() => {
    const kv = {}
    for (const row of document.querySelectorAll('#ro-percep-card .ro-percep-row')) {
      const k = row.querySelector('.ro-percep-k'), v = row.querySelector('.ro-percep-v')
      if (k && v) kv[k.textContent.trim()] = v.textContent.trim()
    }
    return JSON.stringify(kv)
  })()`))
  await sleep(45000)
  const st2 = JSON.parse(await ev(cdp, `(() => {
    const kv = {}
    for (const row of document.querySelectorAll('#ro-percep-card .ro-percep-row')) {
      const k = row.querySelector('.ro-percep-k'), v = row.querySelector('.ro-percep-v')
      if (k && v) kv[k.textContent.trim()] = v.textContent.trim()
    }
    return JSON.stringify(kv)
  })()`))
  const perc = readLog('perception.jsonl')
  const frameCount = (perc.match(/"kind":"frame-registered"/g) || []).length
  check('D-5 采集在跑：感知卡显示"感知 ● 开"', st2['感知'] === '● 开', JSON.stringify({ before: st1, after: st2 }))
  check('D-6 感知审计有事件（frame-registered ≥ 0，events 由 events-*.jsonl 记）', /frame-registered|consent-granted/.test(perc),
    JSON.stringify({ frames: frameCount, samples: st2['今日采样'], note: '桌面静止时帧可能为 0（真实采集非造假）' }))

  // 4) 结束学习
  await ev(cdp, `(() => { const b = document.querySelector('#s5-home [data-act="learn"]'); if (b && /结束/.test(b.textContent || '')) b.click(); return 1 })()`)
  await sleep(2000)
  check('D-7 结束学习有回执', /结束学习|已落账/.test(String(await noticeText())), JSON.stringify(String(await noticeText()).slice(0, 80)))

  // 5) S56：制造 1 次真实 extract（/coach ask → 抓屏 → 640 降采样送模）
  //    断言：perception.jsonl 的 sent-to-model 行数 +1、Σ(bytesBefore−bytesAfter) 增加、感知卡「已压缩送模」随之变化。
  const percRows = () => {
    const t = readLog('perception.jsonl')
    const rows = []
    for (const line of t.split('\n')) {
      const s = line.trim()
      if (!s) continue
      try { const r = JSON.parse(s); if (r && r.kind === 'sent-to-model') rows.push(r) } catch { /* 半行 */ }
    }
    return rows
  }
  const before = percRows()
  const beforeSaved = before.reduce((s, r) => s + Math.max(0, (Number(r.bytesBefore) || 0) - (Number(r.bytesAfter) || 0)), 0)
  // 渲染层直发命令（等价于点按钮；coach ask 无 UI 入口）
  await ev(cdp, `(() => { window.researchOrb.send('ui', { type: 'plugin:command', name: 'coach', args: 'ask' }); return 1 })()`)
  // qwen 视觉可能慢（extract 档超时 45s），轮询等 sent-to-model 出现
  let after = before
  for (let i = 0; i < 20; i++) {
    await sleep(3000)
    after = percRows()
    if (after.length > before.length) break
  }
  const afterSaved = after.reduce((s, r) => s + Math.max(0, (Number(r.bytesBefore) || 0) - (Number(r.bytesAfter) || 0)), 0)
  const cardNow = JSON.parse(await ev(cdp, `(() => {
    const kv = {}
    for (const row of document.querySelectorAll('#ro-percep-card .ro-percep-row')) {
      const k = row.querySelector('.ro-percep-k'), v = row.querySelector('.ro-percep-v')
      if (k && v) kv[k.textContent.trim()] = v.textContent.trim()
    }
    return JSON.stringify(kv)
  })()`))
  const last = after[after.length - 1] || null
  check('D-8 真实 extract → sent-to-model 审计 +1（frameId/bytesBefore/bytesAfter/ts 齐全）',
    after.length === before.length + 1 && !!last && typeof last.ts === 'number' && !!last.frameId && Number.isFinite(last.bytesBefore) && Number.isFinite(last.bytesAfter),
    JSON.stringify({ before: before.length, after: after.length, last }))
  check('D-9 省 MB 增加（Σ bytesBefore−bytesAfter，读审计非内存）',
    afterSaved > beforeSaved && last && last.bytesBefore > last.bytesAfter,
    JSON.stringify({ beforeSaved, afterSaved, delta: afterSaved - beforeSaved, card: cardNow['已压缩送模'] }))
} catch (e) {
  console.log('DIAG-ERROR: ' + String((e && e.stack) || e).slice(0, 400))
} finally {
  try { if (cdp) cdp.close() } catch { /* noop */ }
  killOwn()
  await sleep(1200)
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}
const pass = items.filter((i) => i.ok).length
console.log(`  # diag-s55-consent: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exitCode = items.length - pass === 0 ? 0 : 1
