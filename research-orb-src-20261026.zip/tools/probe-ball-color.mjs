// tools/probe-ball-color.mjs
//
// 一次性/可复跑探针：真启动 electron，读球面的「实际解析值」而非源码字面——
//   ① #ball-gif（旧蓝色 data: SVG）必须已隐藏；
//   ② .ro-ball-art 内联 SVG 存在，渐变 stop 解析出的颜色 == 当前主题 --ro-ball-to；
//   ③ 轨道动画 animationName == ro-orbit-spin（证明"球在动"，不是静态图）；
//   ④ 截一张折叠态球图 data/shots/ball-teal.png 供肉眼复核。
// 纪律：fail-closed（已有 research-orb electron 在跑则退出）；只杀自己起的进程（PID 树）。

import { spawn, spawnSync } from 'node:child_process'
import { mkdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('probe-ball-color')

const ELECTRON_EXE = ORB_ELECTRON
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const SHOTS = join(PROJECT_ROOT, 'data', 'shots')
const PORT = 9347
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '').trim())
  if (!m) return null
  const n = parseInt(m[1], 16)
  return `rgb(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255})`
}

async function findTarget(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await res.json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(t.url))
      if (page) return page
    } catch { /* 还没起来 */ }
    await sleep(300)
  }
  throw new Error(`CDP 目标未找到（port ${PORT}）`)
}

async function main() {
const pre = countOrbAll()
  if (countOrbAll() > 0) throw new Error('已有 research-orb electron 在运行（fail-closed）')
  mkdirSync(SHOTS, { recursive: true })

  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN_MJS], { cwd: PROJECT_ROOT, env: childEnv, stdio: 'ignore' })
  console.log(`electron pid=${child.pid}`)

  let cdp
  try {
    const target = await findTarget()
    const ws = new WebSocket(target.webSocketDebuggerUrl)
    await new Promise((res, rej) => {
      ws.addEventListener('open', res)
      ws.addEventListener('error', () => rej(new Error('CDP WebSocket 连接失败')))
    })
    const sess = { id: 0, pending: new Map() }
    ws.addEventListener('message', (ev) => {
      let m
      try { m = JSON.parse(ev.data) } catch { return }
      if (m.id !== undefined && sess.pending.has(m.id)) {
        const p = sess.pending.get(m.id)
        sess.pending.delete(m.id)
        m.error ? p.reject(new Error(m.error.message)) : p.resolve(m.result)
      }
    })
    cdp = {
      send: (method, params = {}) => new Promise((resolve, reject) => {
        const id = ++sess.id
        sess.pending.set(id, { resolve, reject })
        ws.send(JSON.stringify({ id, method, params }))
      }),
      evaluate: async (expr) => {
        const r = await cdp.send('Runtime.evaluate', { expression: expr, returnByValue: true })
        return r && r.result ? r.result.value : undefined
      },
    }
    await cdp.send('Page.enable')
    await cdp.send('Runtime.enable')
    await sleep(6000)

    // 折叠态：让球可见（面板不该挡住球）
    await cdp.evaluate(`window.researchOrb && window.researchOrb.send('window', { action: 'collapse' })`)
    await sleep(900)

    const info = await cdp.evaluate(`(() => {
      const gif = document.getElementById('ball-gif')
      const ball = document.getElementById('ball')
      const art = document.querySelector('.ro-ball-art')
      const s1 = document.querySelector('.ro-ball-art .ro-s1')
      const orbit = document.querySelector('.ro-ball-art .ro-orbit')
      const root = document.documentElement
      const cs = s1 ? getComputedStyle(s1) : null
      return {
        gifHidden: gif ? getComputedStyle(gif).display === 'none' : null,
        ballArt: !!art,
        stop1: cs ? cs.stopColor : null,
        ballToVar: getComputedStyle(root).getPropertyValue('--ro-ball-to').trim(),
        ballFromVar: getComputedStyle(root).getPropertyValue('--ro-ball-from').trim(),
        anim: orbit ? getComputedStyle(orbit).animationName : null,
        ballAnim: ball ? getComputedStyle(ball).animationName : null,
        mood: ball ? (ball.dataset.mood || '') : '',
      }
    })()`)
    console.log('BALL_INFO ' + JSON.stringify(info, null, 2))

    const expectTo = hexToRgb(info.ballToVar)
    const okGif = info.gifHidden === true
    const okArt = info.ballArt === true
    const okColor = !!info.stop1 && !!expectTo && info.stop1 === expectTo
    const okAnim = String(info.anim || '').includes('ro-orbit-spin')
    console.log(`CHECK gif-hidden=${okGif} inlineSvg=${okArt} color=${okColor}(${info.stop1} vs ${expectTo}) orbitAnim=${okAnim}(${info.anim}) ballAnim=${info.ballAnim}`)

    const s = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
    if (s && s.data) {
      const p = join(SHOTS, 'ball-teal.png')
      writeFileSync(p, Buffer.from(s.data, 'base64'))
      console.log('SHOT ' + p)
    }

    process.exitCode = (okGif && okArt && okColor && okAnim) ? 0 : 1
  } finally {
    try { spawnSync('taskkill', ['/PID', String(child.pid), '/T', '/F'], { stdio: 'ignore' }) } catch { /* noop */ }
  }
}

main().catch((e) => { console.error('PROBE FAILED:', e && e.message ? e.message : e); process.exitCode = 2 })
