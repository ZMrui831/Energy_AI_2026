#!/usr/bin/env node
// tools/demo-script.mjs
//
// S4 学习主线 · 可演示闭环（评委/用户视角）：
//   点开始学习 → learning 态 → 1Hz 廉价信号 → 停留超阈值 → 主动问一次"需要帮助吗"
//   → 用户确认 → 抓一帧 → 生成带 evidence_id 的草稿笔记 → 晋升正式 / 全弃 → 轨迹页数据
//
// 用法：
//   node tools/demo-script.mjs --fast [--dwell 45] [--answer accept|reject]
//   node tools/demo-script.mjs --real                      （真实 10 分钟停留）
//
// ⚠️ 演示加速（默认 --fast）：真实口径是「learning 态停留 10 分钟」才触发主动询问；
//    --fast 把停留阈值压缩为 --dwell 秒（默认 45，可配 30–60）。docs/DEMO.md 有同步声明。
//
// 诚实性（判据 G）：
//   · 每步 PASS/FAIL 都由该步的真实校验算出（文件存在/哈希一致/样本数达标），绝不硬编码"成功"；
//   · "用户确认"用 --answer 显式模拟（输出标注「模拟用户」），skipped 不算 PASS；
//   · 被拒（--answer reject）→ 写同意图 24h 冷却并当场复验抑制。
//
// 只调用公开 API：S1 createToolRuntime（fs.write/fs.delete/screen.capture，host 注入抓屏）、
// S2 startCollector/createEventRecorder/decide（真实 1Hz collector）、
// S3 createStore/computeExpiry（raw_frame 登记 = evidence_id 的来源）。

import { execFileSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { cpSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { dirname } from 'node:path'

import { appendJsonl, logPath, PROJECT_ROOT, safeWrite } from '../packages/core/src/safefs.mjs'
import { createStore, computeExpiry, DEFAULT_LIFECYCLE_CONFIG } from '../packages/core/src/db.mjs'
import { dataPath } from '../packages/core/src/safefs.mjs'
import { createToolRuntime } from '../packages/core/src/tools/index.mjs'
import { startCollector } from '../packages/plugins/perception/collector.mjs'
import { createEventRecorder } from '../packages/plugins/perception/events.mjs'
import { isSensitive } from '../packages/plugins/perception/sampler.mjs'
import {
  DRAFTS_DIR, FORMAL_DIR, PROACTIVE_COOLDOWN_MS, PROACTIVE_INTENT,
  appendSegment, buildAskText, buildTimelinePayload, computeConfidence,
  draftMarkdown, isCooling, listDirFiles, readSegments, recordRejection,
  timelineText, writeDwellEvidence,
} from '../packages/plugins/timeline/logic.mjs'

const HERE = dirname(fileURLToPath(import.meta.url))
const SHOTS_DIR = join(PROJECT_ROOT, 'data', 'shots')
const READ_CONSENT_PATH = dataPath('perception-config.json')

// S36：演示素材全预置——隔离数据树需要种子资产（modes/themes/fonts/fixtures/策略文件）才能跑通
try {
  const SEED = ['config.json', 'lean-policy.json', 'lifecycle-config.json', 'agent-tools.json', 'providers.json', 'secrets.json', 'modes', 'themes', 'fonts', 'fixtures', 'packs']
  for (const name of SEED) {
    const src = join(PROJECT_ROOT, 'data', name)
    if (!existsSync(src)) continue
    const dst = dataPath(name)
    if (!existsSync(dst)) cpSync(src, dst, { recursive: true })
  }
} catch { /* 种子复制失败不阻断（真实数据树下本就存在） */ }

// ---------------------------------------------------------------------------
// 参数
// ---------------------------------------------------------------------------

function parseArgs(argv) {
  const out = { mode: 'fast', dwellSec: 45, answer: 'accept', grantConsent: false, keepConsent: false }
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]
    if (a === '--fast') out.mode = 'fast'
    else if (a === '--real') out.mode = 'real'
    else if (a === '--dwell') out.dwellSec = Number(argv[++i]) || out.dwellSec
    else if (a === '--answer') out.answer = argv[++i] === 'reject' ? 'reject' : 'accept'
    // 主管补：--grant-consent 让演示**自包含可复跑**（等价于用户在面板点「本次允许屏幕感知」）；
    // 走 consent.grant() 官方 API（不手改 JSON），默认退出时自动撤销（--keep-consent 可保留）。
    else if (a === '--grant-consent') out.grantConsent = true
    else if (a === '--keep-consent') out.keepConsent = true
    // 主管补：--reset-cooldown 清空"主动询问"的 24h 冷却状态，让演示可重复（显式标注"模拟等待 24h"）
    else if (a === '--reset-cooldown') out.resetCooldown = true
  }
  if (out.mode === 'fast') out.dwellSec = Math.min(60, Math.max(30, out.dwellSec))
  else out.dwellSec = 600 // --real：真实 10 分钟
  return out
}

const args = parseArgs(process.argv.slice(2))

// 主管补：--reset-cooldown —— 只清演示用的主动询问冷却（data/timeline/proactive-state.json）。
// 诚实标注：它不是产品行为（产品不会自动清冷却），等价于"等到 24 小时之后再演示"。
if (args.resetCooldown) {
  try {
    const { safeWrite } = await import('../packages/core/src/safefs.mjs')
    const P = join(PROJECT_ROOT, 'data', 'timeline', 'proactive-state.json')
    safeWrite(P, JSON.stringify({ intent: null, lastRejectedAt: null, nextAllowedAt: 0 }, null, 2))
    console.log('[模拟] 已清空主动询问的 24h 冷却（等价于"等了 24 小时"；真实产品不会自动清）→ ' + P)
  } catch (e) {
    console.log('[警告] --reset-cooldown 失败：' + String((e && e.message) || e))
  }
}
const T0 = Date.now()
const steps = [] // { step, action, evidence, ok, ms }
const failures = [] // 分类失败原因（判据 B 用）

function step(n, action) {
  const t = Date.now()
  return {
    done(evidence, ok, note = '') {
      steps.push({ step: n, action, evidence, ok: !!ok, note, ms: Date.now() - t })
      const mark = ok ? 'PASS' : 'FAIL'
      console.log(`[step ${n}] ${action} → ${evidence} [${mark}]${note ? ' （' + note + '）' : ''}`)
      if (!ok) failures.push({ step: n, action, reason: note || 'verification-failed' })
      return !!ok
    },
  }
}

const sha256 = (buf) => createHash('sha256').update(buf).digest('hex')

// ---------------------------------------------------------------------------
// 抓屏（真实截屏，PowerShell CopyFromScreen；无 electron 依赖）
// ---------------------------------------------------------------------------

function pngSize(buf) {
  // PNG IHDR：宽高在固定偏移 16/20（大端）
  if (buf.length < 24 || buf.readUInt32BE(12) !== 0x49484452) return { width: null, height: null }
  return { width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) }
}

function realScreenCapture() {
  if (!existsSync(SHOTS_DIR)) mkdirSync(SHOTS_DIR, { recursive: true })
  const ts = new Date().toISOString().replace(/[:.]/g, '-')
  const pngPath = join(SHOTS_DIR, `capture-${ts}.png`)
  const ps =
    `Add-Type -AssemblyName System.Drawing;` +
    `Add-Type -AssemblyName System.Windows.Forms;` +
    `$b=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds;` +
    `$bmp=New-Object System.Drawing.Bitmap $b.Width,$b.Height;` +
    `$g=[System.Drawing.Graphics]::FromImage($bmp);` +
    `$g.CopyFromScreen($b.X,$b.Y,0,0,$bmp.Size);` +
    `$bmp.Save('${pngPath.split('\\').join('\\\\')}',[System.Drawing.Imaging.ImageFormat]::Png);` +
    `$g.Dispose();$bmp.Dispose();Write-Output OK`
  const r = execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], {
    timeout: 20_000, windowsHide: true, encoding: 'utf8',
  })
  if (!String(r).includes('OK')) throw new Error('capture: powershell 未确认落盘')
  const buf = readFileSync(pngPath)
  if (buf.length < 100) throw new Error('capture: PNG 过小')
  const { width, height } = pngSize(buf)
  const hash = sha256(buf)
  // 与 screen-capture.mjs 同口径：绝对路径落 writes.jsonl 审计
  appendJsonl(logPath('writes.jsonl'), {
    ts: new Date().toISOString(), op: 'write', path: pngPath, bytes: buf.length,
    purpose: 'demo-capture', hash,
  })
  return { ok: true, pngPath, bytes: buf.length, hash, width, height }
}

// ---------------------------------------------------------------------------
// 主流程
// ---------------------------------------------------------------------------

async function main() {
  const fast = args.mode === 'fast'
  const dwellMs = args.dwellSec * 1000
  const dwellLabel = fast
    ? `${args.dwellSec}s（演示加速：真实口径为 learning 停留 ${10} 分钟）`
    : `${args.dwellSec}s（真实时长）`

  console.log('════════════════════════════════════════════════')
  console.log(`research-orb 学习主线演示  mode=${args.mode}  answer=${args.answer}`)
  if (fast) {
    console.log(`⚠️ 演示加速：停留阈值由真实 10 分钟压缩为 ${args.dwellSec}s（--dwell 可配 30–60；--real 为真实时长）。`)
    console.log('   加速声明同步见 docs/DEMO.md。除停留时长外，其余各步均为真实执行与真实数据。')
  }
  console.log('════════════════════════════════════════════════')

  // ---- step 1：前提（S3.1 接线 = raw_frame 有生产者）----
  const s1 = step(1, '前提检查：S3.1 已接线（lifecycle store 可用）')
  let store = null
  try {
    if (!existsSync(join(PROJECT_ROOT, 'data', 'db', 'orb.sqlite'))) throw new Error('orb.sqlite 不存在')
    // S36：走 dataPath（跟随 ORB_DATA_DIR）——演示可在隔离数据树真跑，不碰真实 data/db
    store = await createStore({ driver: 'auto', dbPath: dataPath('db', 'orb.sqlite'), dataDir: dataPath('db') })
    store.initMigrations()
    const c = store.counts()
    s1.done(`data/db/orb.sqlite（raw_frame 现有 ${c.raw_frame.ready + c.raw_frame.deleted + c.raw_frame.error} 行）`, true)
  } catch (e) {
    s1.done('data/db/orb.sqlite', false, '阻塞：raw_frame 无生产者（S3.1 未接线）：' + String(e && e.message))
    return finish(2)
  }

  // ---- step 1.5：可选自助授权（--grant-consent；模拟"用户点击允许"，不伪造同意语义）----
  if (args.grantConsent) {
    try {
      const { grant } = await import('../packages/plugins/perception/consent.mjs')
      const { saveConfig } = await import('../packages/plugins/perception/index.mjs')
      // S36：隔离数据树首次运行时配置可能不存在 → 容忍缺省（空对象起步）
      const cfg = existsSync(READ_CONSENT_PATH) ? JSON.parse(readFileSync(READ_CONSENT_PATH, 'utf8')) : {}
      const prev = cfg.consent || {}
      cfg.consent = grant('session', { ttl: 4 * 60 * 60 * 1000, policyVersion: prev.policyVersion })
      saveConfig(cfg)
      console.log('[模拟用户] 已在面板上点击「本次允许屏幕感知」（session，≤4h）→ ' + READ_CONSENT_PATH)
      if (!args.keepConsent) {
        process.on('exit', () => {
          try {
            const cur = JSON.parse(readFileSync(READ_CONSENT_PATH, 'utf8'))
            cur.consent = grant('denied', { policyVersion: (cur.consent || {}).policyVersion })
            saveConfig(cur)
            console.log('[清理] 演示结束已撤销 session 同意（--keep-consent 可保留）')
          } catch { /* 撤销失败不影响结果 */ }
        })
      }
    } catch (e) {
      console.log('[警告] --grant-consent 失败：' + String((e && e.message) || e))
    }
  }

  // ---- step 2：同意前提（诚实：抓屏需要 session 同意）----
  const s2 = step(2, '同意前提：consent 允许屏幕采集（session）')
  let consentOk = false
  let consentId = 'unknown@demo'
  try {
    const cfg = JSON.parse(readFileSync(READ_CONSENT_PATH, 'utf8'))
    const c = cfg.consent || {}
    consentOk = c.mode === 'session' && (c.expiresAt == null || Date.now() <= c.expiresAt)
    consentId = `${c.mode || 'unknown'}@${c.grantedAt ?? 'demo'}`
    s2.done(`data/perception-config.json（mode=${c.mode}）`, consentOk, consentOk ? '' : 'consent 非 session 或已过期 → 演示拒绝抓屏（诚实失败）')
  } catch (e) {
    s2.done(READ_CONSENT_PATH, false, 'consent 配置不可读：' + String(e && e.message))
  }
  if (!consentOk) return finish(3)

  // ---- step 3：点开始学习 → learning 态，1Hz 廉价信号采集 ----
  const segId = `seg-${Date.now()}`
  const expectedSamples = Math.max(5, Math.floor(args.dwellSec * 0.8))
  const s3 = step(3, `点开始学习：learning 态 1Hz 采集 ${args.dwellSec}s（1Hz 真实 collector）`)
  const recorder = createEventRecorder()
  let samples = 0
  let eventsWritten = 0
  let sensitiveHit = 0
  let lastSample = null
  const collector = startCollector({
    onSample: (smp) => {
      samples += 1
      lastSample = smp
      const r = recorder.tick({
        ts: smp.ts, pid: smp.pid, hwnd: smp.hwnd, process: smp.process, title: smp.title,
        idleMs: smp.idleMs, isFullscreen: smp.isFullscreen, state: 'learning', consent: 'session',
      })
      eventsWritten += r.events.length
      if (isSensitive(smp.title, smp.process, undefined)) sensitiveHit += 1
    },
  })
  await new Promise((ok) => setTimeout(ok, dwellMs))
  collector.stop()
  try { recorder.flush() } catch { /* ignore */ }
  s3.done(
    `data/perception/events-*.jsonl（样本 ${samples} / 事件 ${eventsWritten}${sensitiveHit ? ' / 敏感拒采 ' + sensitiveHit : ''}）`,
    samples >= expectedSamples,
    samples >= expectedSamples ? '' : `样本不足（${samples} < ${expectedSamples}）`,
  )

  // ---- step 4：停留超阈值 → 主动问一次（判据 C：evidence_id + reason + 如何关闭 + 冷却）----
  const s4 = step(4, '停留超阈值 → 主动询问（一次）')
  if (isCooling()) {
    const st = JSON.parse(readFileSync(join(PROJECT_ROOT, 'data', 'timeline', 'proactive-state.json'), 'utf8'))
    s4.done('data/timeline/proactive-state.json', false,
      `冷却中（intent=${PROACTIVE_INTENT}，至 ${new Date(st.nextAllowedAt).toISOString()}）→ 24h 内不再弹，主线按设计终止（--answer accept 亦不得绕过冷却）`)
    appendSegment({ id: segId, startedAt: T0, endedAt: Date.now(), state: 'learning', outcome: 'blocked-cooldown', dwellLabel, samples, eventsWritten })
    return finish(4)
  }
  const evId = `ev-${Date.now()}`
  const windowTitle = lastSample ? String(lastSample.title || '') : ''
  const evPath = writeDwellEvidence({
    id: evId, kind: 'dwell', segmentId: segId, state: 'learning',
    startedAt: T0, dwellMs, dwellLabel, samples, eventsWritten,
    windowTitle, windowProcess: lastSample ? lastSample.process : null,
    consentId, note: fast ? '演示加速：停留阈值由真实 10 分钟压缩（docs/DEMO.md 已声明）' : '真实时长',
  })
  const disableHow = '本演示：--answer reject（写 24h 同意图冷却）；应用内：/perception revoke 或暂停采集'
  const reason = `learning 态下前台窗口停留超过阈值（阈值=${dwellLabel}，1Hz 样本 ${samples} 条）`
  console.log('   ── 主动询问（模拟用户界面）──────────────')
  console.log('   ' + buildAskText({ evidenceId: evId, reason, dwellLabel, windowTitle, disableHow }).split('\n').join('\n   '))
  console.log('   ────────────────────────────────────')
  if (args.answer === 'reject') {
    const st = recordRejection()
    const suppressed = isCooling()
    s4.done(`data/timeline/evidence/${evId}.json + proactive-state.json`, suppressed,
      `用户婉拒 → 同意图 24h 冷却（至 ${new Date(st.nextAllowedAt).toISOString()}）；当场复验抑制=${suppressed}`)
    appendSegment({
      id: segId, startedAt: T0, endedAt: Date.now(), state: 'learning', outcome: 'rejected',
      dwellLabel, confidence: computeConfidence({ dwellMs, dwellThresholdMs: dwellMs, samples, expectedSamples, eventsWritten }),
      samples, eventsWritten, evidence: [{ evidence_id: evId, kind: 'dwell', path: evPath }],
    })
    return finish(0)
  }
  s4.done(`data/timeline/evidence/${evId}.json`, existsSync(evPath), '模拟用户点「是」（--answer accept）')

  // ---- step 5：抓一帧（S1 screen.capture，host 注入真实 PS 抓屏）----
  const s5 = step(5, '用户确认 → 抓一帧（S1 screen.capture，真实截屏）')
  const runtime = createToolRuntime({
    host: { screen: { captureScreen: async () => realScreenCapture() } },
    // fs.write / fs.delete 为 confirm 档：演示里由 --answer accept 显式模拟用户批准
    confirm: async () => ({ approved: true, auto: true, note: '模拟用户批准（--answer accept）' }),
  })
  const cap = await runtime.run({ toolId: 'screen.capture', args: {} })
  const capOk = !!(cap && cap.ok && cap.value && cap.value.ok && existsSync(cap.value.path))
  s5.done(capOk ? cap.value.path : '（无）', capOk, capOk ? `${cap.value.bytes}B ${cap.value.width}x${cap.value.height}` : String(cap && cap.error && cap.error.message))

  // ---- step 6：原图登记进 S3（evidence_id = raw_frame.id，learning → 20min 保留）----
  const s6 = step(6, '原图登记进生命周期库（S3 insertRawFrame，learning 保留 20 分钟）')
  const evidenceId = `rf-demo-${Date.now()}`
  const capturedAt = new Date().toISOString()
  let row = null
  try {
    row = store.insertRawFrame({
      id: evidenceId,
      file_path: cap.value.path,
      sha256: cap.value.hash,
      sensitivity: 'normal',
      created_at: capturedAt,
      expires_at: computeExpiry('normal', 'learning', DEFAULT_LIFECYCLE_CONFIG, Date.parse(capturedAt)),
    })
    store.insertAuditEvent({
      ts: capturedAt, kind: 'frame-registered',
      metadata: { id: evidenceId, file_path: cap.value.path, sha256: cap.value.hash, segment_id: segId, evidence_ev: evId, mode: 'learning', consent_id: consentId, trace_id: `trc-${Date.now()}`, origin: 'demo-script' },
    })
  } catch (e) {
    s6.done(evidenceId, false, '登记失败：' + String(e && e.message))
    return finish(6)
  }
  s6.done(`raw_frame(${evidenceId}, expires_at=${row.expires_at})`, existsSync(cap.value.path))

  // ---- step 7：生成带 evidence_id 的草稿（只进 data/drafts/）----
  const s7 = step(7, '生成草稿笔记（只写 data/drafts/，绝不直接改正式笔记）')
  const draftId = `draft-${Date.now()}`
  const draftPath = join(DRAFTS_DIR, `${draftId}.md`)
  const content = draftMarkdown({
    draftId, segmentId: segId, evidenceId, windowTitle, dwellLabel,
    confidence: computeConfidence({ dwellMs, dwellThresholdMs: dwellMs, samples, expectedSamples, eventsWritten }),
    samples, eventsWritten, capturePath: cap.value.path, captureSha256: cap.value.hash, capturedAt,
  })
  const w = await runtime.run({ toolId: 'fs.write', args: { path: draftPath, content } })
  const draftOk = !!(w && w.ok && existsSync(draftPath))
  s7.done(draftOk ? `${draftPath}（${w.value.bytes}B）` : '（无）', draftOk)

  const confidence = computeConfidence({ dwellMs, dwellThresholdMs: dwellMs, samples, expectedSamples, eventsWritten })
  appendSegment({
    id: segId, startedAt: T0, endedAt: Date.now(), state: 'learning', outcome: 'pending',
    dwellLabel, confidence, samples, eventsWritten,
    evidence: [{ evidence_id: evId, kind: 'dwell', path: evPath }, { evidence_id: evidenceId, kind: 'frame', path: cap.value.path }],
    draftPath,
  })

  // ---- step 8：晋升正式（sha256 一致）----
  const s8 = step(8, '晋升正式：草稿内容原样写入 data/notes/（sha256 比对）')
  const notePath = join(FORMAL_DIR, `note-help-${Date.now()}.md`)
  const p8 = await runtime.run({ toolId: 'fs.write', args: { path: notePath, content } })
  const draftSha = sha256(readFileSync(draftPath))
  const formalSha = sha256(readFileSync(notePath))
  const promoteOk = !!(p8 && p8.ok && draftSha === formalSha)
  s8.done(`${notePath}（sha256 ${promoteOk ? '一致' : '不一致：' + draftSha.slice(0, 8) + ' vs ' + formalSha.slice(0, 8)}）`, promoteOk)

  // ---- step 9：草稿出清（fs.delete → data/trash，草稿目录为空）----
  const s9 = step(9, '晋升后清空草稿区（S1 fs.delete → data/trash，不真删）')
  const d9 = await runtime.run({ toolId: 'fs.delete', args: { path: draftPath } })
  const draftsLeft = listDirFiles(DRAFTS_DIR)
  s9.done(`data/drafts/ 剩 ${draftsLeft.length} 个文件（删除审计：${d9 && d9.ok ? 'ok' : 'fail'}）`, d9 && d9.ok && draftsLeft.length === 0)

  // ---- step 10：轨迹页数据（与 /timeline 命令同源）----
  appendSegment({
    id: segId, startedAt: T0, endedAt: Date.now(), state: 'learning', outcome: 'promoted',
    dwellLabel, confidence, samples, eventsWritten,
    evidence: [{ evidence_id: evId, kind: 'dwell', path: evPath }, { evidence_id: evidenceId, kind: 'frame', path: cap.value.path }],
    notePath,
  })
  const s10 = step(10, '轨迹页数据（/timeline 同源 payload，可回指 evidence_id）')
  const payload = buildTimelinePayload({ store, day: T0 })
  const mine = payload.segments.find((x) => x.id === segId)
  const ok10 = !!(mine && mine.evidence.some((e) => e.evidence_id === evidenceId && e.status === 'available'))
  console.log('   ' + timelineText(payload).split('\n').join('\n   '))
  s10.done(`segments-${new Date(T0).toISOString().slice(0, 10).replace(/-/g, '')}.jsonl`, ok10)

  return finish(0)
}

function finish(code) {
  const total = Date.now() - T0
  const pass = steps.filter((s) => s.ok).length
  console.log('────────────────────────────────────')
  console.log(`演示${fast0()}总用时：${(total / 1000).toFixed(1)}s（上限 ${args.mode === 'fast' ? 120 : '∞'}s）；步骤 ${pass}/${steps.length} PASS`)
  for (const s of steps) if (!s.ok) console.log(`  FAIL step ${s.step} ${s.action}: ${s.note}`)
  if (failures.length) {
    console.log('失败分类：' + failures.map((f) => `step${f.step}:${f.reason.slice(0, 60)}`).join('；'))
  }
  console.log(`退出码：${code}（0 = 全部步骤 PASS；skipped 不算 PASS）`)
  // 审计一行（演示运行记录，供判据 B 汇总）
  try {
    appendJsonl(join(PROJECT_ROOT, 'data', 'logs', 'demo-runs.jsonl'), {
      ts: new Date().toISOString(), mode: args.mode, answer: args.answer,
      totalMs: total, stepsPass: pass, stepsTotal: steps.length,
      failures, exit: code,
    })
  } catch { /* 审计失败不影响退出码语义 */ }
  process.exit(code)
  function fast0() { return args.mode === 'fast' ? '（加速）' : '（真实）' }
}

main().then(
  () => {},
  (e) => {
    console.error('[demo-script] 未捕获失败：', e && (e.stack || e.message))
    process.exit(1)
  },
)
