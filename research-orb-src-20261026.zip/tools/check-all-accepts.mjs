// tools/check-all-accepts.mjs —— S67·3-C 统一门禁：串行跑验收脚本，退出码聚合
//
// 默认只跑**离线 / 无 Electron / 无需网络**的快速验收（防漂基线）；`--all` 才跑全部
// （含 Electron CDP、真实 LLM 调用，耗时且依赖应用/网络，适合发布前手动跑）。
//
// 用法：
//   node tools/check-all-accepts.mjs                # 快速集（默认）
//   node tools/check-all-accepts.mjs --all          # 全部 accept-*.mjs
//   node tools/check-all-accepts.mjs --timeout=300000
import { spawnSync } from 'node:child_process'
import { readdirSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const TOOLS = dirname(fileURLToPath(import.meta.url))
const PROJECT_ROOT = join(TOOLS, '..')
const argv = process.argv.slice(2)
const all = argv.includes('--all')
const timeoutArg = (argv.find((a) => a.startsWith('--timeout=')) || '').split('=')[1]
const TIMEOUT = Number(timeoutArg) || 180000

// 快速集：离线、无 Electron、无需网络
const FAST = [
  'accept-s67-shell', 'accept-s67-portable', 'accept-s67-sensitive', 'accept-s67-dual-live',
  'accept-s28-clean', 'accept-s35-dual', 'accept-s25b-confusion', 'accept-s31-ask',
]

let list = FAST
if (all) {
  list = readdirSync(TOOLS).filter((f) => /^accept-.*\.mjs$/.test(f)).map((f) => f.replace(/\.mjs$/, '')).sort()
}

console.log(`[check-all-accepts] ${all ? '全部' : '快速集'} ${list.length} 个脚本，串行跑（每个 ≤${TIMEOUT}ms）`)
const results = []
for (const name of list) {
  const file = join(TOOLS, name + '.mjs')
  const t0 = Date.now()
  const r = spawnSync(process.execPath, [file], { cwd: PROJECT_ROOT, timeout: TIMEOUT, encoding: 'utf8', env: { ...process.env, NODE_OPTIONS: '' } })
  const ms = Date.now() - t0
  const ok = r.status === 0
  const tail = String((r.stdout || '').trim().split('\n').slice(-1)[0] || '').slice(0, 80)
  results.push({ name, ok, status: r.status, ms })
  console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${name} (exit=${r.status}, ${ms}ms) ${ok ? '' : tail}`)
}

const failed = results.filter((r) => !r.ok)
console.log(`\n[check-all-accepts] ${results.length - failed.length}/${results.length} 通过`)
if (failed.length) {
  console.log('  ✗ 失败：' + failed.map((f) => `${f.name}(exit=${f.status})`).join(', '))
  process.exit(1)
}
console.log('  ✓ 全绿')
