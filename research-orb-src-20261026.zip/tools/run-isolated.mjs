// tools/run-isolated.mjs —— 运行即沙箱（CONTRACT §7）
// 用法：
//   node tools/run-isolated.mjs --label s6 --cmd "node tools/accept-s6-evidence.mjs"
//   node tools/run-isolated.mjs --label probe --cmd "node -e \"...\"" --keep
// 行为：快照可变状态 → 跑命令（tee 日志）→ 把本次新增的文件归档为证据(含 sha256) → 恢复状态 → 写 RUN-REPORT.json
// 不修改产品代码：只做"外部隔离 + 状态还原"。
import { mkdirSync, existsSync, readFileSync, writeFileSync, readdirSync, statSync, copyFileSync, rmSync } from 'node:fs'
import { join, dirname, relative, resolve } from 'node:path'
import { createHash } from 'node:crypto'
import { spawnSync, execFileSync } from 'node:child_process'
import { countOrbAll } from './_orb-proc.mjs'

const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const DATA = join(PROJECT_ROOT, 'data')
const RUNS = join(DATA, 'runs')

const argv = process.argv.slice(2)
const arg = (k, d = null) => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : d }
const flag = (k) => argv.includes(k)
const label = arg('--label', 'run')
const cmd = arg('--cmd')
const keep = flag('--keep')
const clean = flag('--clean') // 归档证据后把本次新增文件从 data 清走（logs/runs 除外）
const allowApp = flag('--allow-app')
if (!cmd) { console.error('用法: --label <名> --cmd "<命令>" [--keep] [--allow-app]'); process.exit(2) }

const sha = (p) => createHash('sha256').update(readFileSync(p)).digest('hex')
const nowIso = () => new Date().toISOString()
const runId = `${label}-${new Date().toISOString().replace(/[:.]/g, '-')}`
const RUN_ROOT = join(RUNS, runId)
const EVID = join(RUN_ROOT, 'evidence')
const SNAP = join(RUN_ROOT, 'state-before')
mkdirSync(EVID, { recursive: true }); mkdirSync(SNAP, { recursive: true })

// 0) 安全闸：应用在跑时默认拒绝（避免还原时踩踏运行中的实例）
const app = () => countOrbAll()
if (app > 0 && !allowApp) { console.error(`[run-isolated] 检测到 research-orb 应用在运行(${app})，默认拒绝；如需继续加 --allow-app`); process.exit(3) }

// 1) 快照可变状态（只快照"会被验收改坏"的小文件/目录）
const STATE_FILES = ['config.json', 'perception-config.json', 'timeline/proactive-state.json', 'timer/state.json', 'db/orb.sqlite', 'db/orb.sqlite-wal', 'db/orb.sqlite-shm']
const STATE_DIRS = ['drafts', 'notes', 'progress']
const existed = new Map()
for (const rel of STATE_FILES) {
  const p = join(DATA, rel)
  if (existsSync(p)) { const dst = join(SNAP, rel); mkdirSync(dirname(dst), { recursive: true }); copyFileSync(p, dst); existed.set(rel, sha(p)) }
}
const dirSnap = new Map()
for (const d of STATE_DIRS) {
  const src = join(DATA, d); if (!existsSync(src)) continue
  const dst = join(SNAP, d); mkdirSync(dst, { recursive: true })
  for (const f of walk(src)) { const rel = relative(DATA, f); const t = join(SNAP, rel); mkdirSync(dirname(t), { recursive: true }); copyFileSync(f, t); dirSnap.set(rel, sha(f)) }
}

// 2) 跑命令（tee 到 run-root）
const t0 = Date.now()
const t0Iso = nowIso()
const child = spawnSync(cmd, { shell: true, cwd: PROJECT_ROOT, encoding: 'utf8', env: { ...process.env, ORB_RUN_ROOT: RUN_ROOT, CODEBUDDY_SAFE_DELETE_ENABLED: process.env.CODEBBUDY_SAFE_DELETE_ENABLED || '0' }, maxBuffer: 64 * 1024 * 1024 })
const stdoutPath = join(RUN_ROOT, 'stdout.log'); const stderrPath = join(RUN_ROOT, 'stderr.log')
writeFileSync(stdoutPath, child.stdout || ''); writeFileSync(stderrPath, child.stderr || '')

// 3) 归档本次新增/改动的文件为证据（排除 logs 与 runs 本身；logs 只记录增量）
const evidence = []
for (const f of walk(DATA)) {
  if (f.startsWith(RUN_ROOT) || f.includes(join(DATA, 'runs'))) continue
  const rel = relative(DATA, f)
  if (rel.startsWith('logs')) continue // 审计只增不删，归档交给日志轮转
  const st = statSync(f); if (st.mtimeMs < t0 - 1000) continue
  const dst = join(EVID, rel); mkdirSync(dirname(dst), { recursive: true }); copyFileSync(f, dst)
  evidence.push({ path: rel, bytes: st.size, sha256: sha(f) })
}
const logStats = readdirSync(join(DATA, 'logs')).filter((n) => n.endsWith('.jsonl')).map((n) => { const p = join(DATA, 'logs', n); return { name: n, bytes: statSync(p).size, sha256: sha(p) } })

// 3.2) 被测命令经 ORB_RUN_ROOT 直接落在 run-root 的产物也算证据（含 sha256 进清单）
for (const f of readdirSync(RUN_ROOT)) {
  const p = join(RUN_ROOT, f)
  if (!statSync(p).isFile()) continue
  if (f === 'RUN-REPORT.json' || f === 'stdout.log' || f === 'stderr.log') continue
  evidence.push({ path: `runs/${runId}/${f}`, bytes: statSync(p).size, sha256: sha(p) })
}

// 3.5) 可选清理：把本次新增并已归档的证据文件从 data 移除（--clean）
const cleaned = []
if (clean) {
  for (const ev of evidence) {
    try { rmSync(join(DATA, ev.path), { force: true }); cleaned.push(ev.path) } catch { /* 单条失败忽略 */ }
  }
}
// 4) 恢复状态（文件/目录），并删除本次新增的受管状态文件
const restored = []
for (const [rel, h] of existed) { const src = join(SNAP, rel), dst = join(DATA, rel); if (existsSync(src)) { const cur = existsSync(dst) ? sha(dst) : null; copyFileSync(src, dst); restored.push({ path: rel, before: h, during: cur, restored: sha(dst) === h }) } }
for (const d of STATE_DIRS) {
  const src = join(SNAP, d); if (!existsSync(src)) continue
  for (const f of walk(src)) { const rel = relative(SNAP, f); const dst = join(DATA, rel); mkdirSync(dirname(dst), { recursive: true }); copyFileSync(f, dst); restored.push({ path: rel, restored: sha(dst) === dirSnap.get(rel) }) }
  // 删除目录里本次新增的文件
  for (const f of walk(join(DATA, d))) { const rel = relative(DATA, f); if (!dirSnap.has(rel)) rmSync(f, { force: true }) }
}

// 5) RUN-REPORT
const report = { runId, label, cmd, contract: 'CONTRACT.md v0.1 §7', startedAt: t0Iso, endedAt: nowIso(), durationMs: Date.now() - t0, exit: child.status, evidence, cleaned, leftover: evidence.filter((e) => !cleaned.includes(e.path)).map((e) => e.path), logs: logStats, stateRestored: restored, keep: !!keep }
writeFileSync(join(RUN_ROOT, 'RUN-REPORT.json'), JSON.stringify(report, null, 2))
const bad = restored.filter((r) => r.restored === false)
console.log(`[run-isolated] ${runId}  exit=${report.exit}  用时=${(report.durationMs / 1000).toFixed(1)}s`)
console.log(`  证据 ${evidence.length} 项（归档于 data/runs/${runId}/evidence/，含 sha256）`)
console.log(`  状态还原 ${restored.length} 项，失败 ${bad.length} 项`)
if (bad.length) console.log('  ⚠️ 还原失败: ' + bad.map((b) => b.path).join(', '))
console.log(`  报告: data/runs/${runId}/RUN-REPORT.json${keep ? '（--keep：run-root 保留）' : '（run-root 保留，便于复核）'}`)
process.exit(report.exit == null ? 1 : report.exit)

function walk(dir, out = []) {
  if (!existsSync(dir)) return out
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, e.name)
    if (e.isDirectory()) walk(p, out); else out.push(p)
  }
  return out
}