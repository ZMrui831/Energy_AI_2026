// tools/accept-stage62-collapse.mjs
//
// P-R6.2 任务四 验收（真 electron）：
//   ① 默认折叠：启动后 .ro-welcome-body 不可见，只剩「▶ research-orb v0.6.0 说明（点击展开）」
//   ② 点击头展开 → body 可见；再点折叠 → 不可见
//   ③ 展开态重载面板 → 状态保持（localStorage 持久化）
//   ④ 几何契约不变：展开窗口仍 420×620
// 产出：data\shots\stage62-collapse-closed.png / stage62-collapse-open.png / stage62-collapse-reload.png

import { spawn, spawnSync } from 'node:child_process'
import { readFileSync, writeFileSync, existsSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { loadSettings, saveSettings } from '../packages/core/src/settings.mjs'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-stage62-collapse')

const ELECTRON_EXE = ORB_ELECTRON
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const LOG = join(PROJECT_ROOT, 'data', 'logs', 'stage62-collapse.txt')
const SHOTS = join(PROJECT_ROOT, 'data', 'shots')
const PORT = 9364

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const OUT = []
const results = []
const log = (s) => { OUT.push(s); console.log(s) }
const check = (cond, label, extra = '') => {
  log(`${cond ? 'PASS' : 'FAIL'}  ${label}${extra ? '  ' + extra : ''}`)
  results.push({ ok: !!cond, label, extra })
  return !!cond
}

async function findTarget(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const list = await (await fetch(`http://127.0.0.1:${PORT}/json/list`)).json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(t.url))
      if (page) return page
    } catch { /* 还没起来 */ }
    await sleep(300)
  }
  throw new Error(`CDP 目标未找到（port ${PORT}）`)
}

let cdp = null
async function connectCdp() {
  const target = await findTarget()
  const ws = new WebSocket(target.webSocketDebuggerUrl)
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve)
    ws.addEventListener('error', () => reject(new Error('CDP WebSocket 连接失败')))
  })
  const session = { ws, _id: 0, _pending: new Map() }
  ws.addEventListener('message', (ev) => {
    let m
    try { m = JSON.parse(ev.data) } catch { return }
    if (m.id !== undefined && session._pending.has(m.id)) {
      const p = session._pending.get(m.id)
      session._pending.delete(m.id)
      if (m.error) p.reject(new Error(m.error.message))
      else p.resolve(m.result)
    }
  })
  cdp = {
    send: (method, params = {}) => {
      const id = ++session._id
      return new Promise((resolve, reject) => {
        session._pending.set(id, { resolve, reject })
        session.ws.send(JSON.stringify({ id, method, params }))
      })
    },
    evaluate: async (expression) => {
      const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true })
      return r && r.result ? r.result.value : undefined
    },
    close: () => { try { session.ws.close() } catch { /* noop */ } },
  }
  await cdp.send('Page.enable')
  await cdp.send('Runtime.enable')
  return cdp
}

async function shot(name) {
  const s = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
  writeFileSync(join(SHOTS, name), Buffer.from(s.data, 'base64'))
  log(`shot: data/shots/${name} (${Buffer.from(s.data, 'base64').length} bytes)`)
}

async function main() {
  log('=== P-R6.2 任务四：说明区折叠 验收 ===')
  saveSettings({ theme: 'sky-blue', activePack: 'research', enabledPacks: ['research'] })

  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN_MJS], { cwd: PROJECT_ROOT, env: childEnv, stdio: 'ignore' })
  log(`electron pid=${child.pid}`)
  try {
    await connectCdp()
    await sleep(5500)
    // 跨运行状态清理：上一次验收可能把折叠状态写进了持久 profile 的 localStorage。
    // 先清键再重载，保证「默认折叠」判定建立在干净状态上。
    await cdp.evaluate(`(() => { localStorage.removeItem('ro-welcome-collapsed'); return true })()`)
    await cdp.send('Page.reload', { ignoreCache: true })
    await sleep(5500)
    await cdp.evaluate(`window.researchOrb.send('window', { action: 'expand' })`)
    await sleep(1400)

    // ① 默认折叠
    const probe = () => cdp.evaluate(`(() => {
      const base = document.getElementById('ro-welcome-base')
      if (!base) return null
      const body = base.querySelector('.ro-welcome-body')
      const visible = body ? getComputedStyle(body).display !== 'none' : false
      const headText = (base.querySelector('.ro-welcome-head') || {}).textContent || ''
      return { open: base.classList.contains('open'), bodyVisible: visible, headText, ls: localStorage.getItem('ro-welcome-collapsed') }
    })()`)
    const p1 = await probe()
    check(!!p1 && p1.open === false && p1.bodyVisible === false, '① 默认折叠：body 不可见，只剩一行摘要',
      p1 ? `head="${(p1.headText || '').slice(0, 40)}" ls=${p1.ls}` : 'n/a')
    await shot('stage62-collapse-closed.png')

    // ② 点击展开
    await cdp.evaluate(`(() => { const h = document.querySelector('#ro-welcome-base .ro-welcome-head'); if (h) h.click() })()`)
    await sleep(400)
    const p2 = await probe()
    check(!!p2 && p2.open === true && p2.bodyVisible === true, '② 点击头展开：body 可见', p2 ? `ls=${p2.ls}` : 'n/a')
    await shot('stage62-collapse-open.png')

    // ③ 展开态持久化：重载后仍展开
    await cdp.send('Page.reload', { ignoreCache: true })
    await sleep(5500)
    await cdp.evaluate(`window.researchOrb.send('window', { action: 'expand' })`)
    await sleep(1400)
    const p3 = await probe()
    check(!!p3 && p3.open === true && p3.bodyVisible === true && p3.ls === '0', '③ 重启（重载面板）后展开状态保持（localStorage=0）', p3 ? `ls=${p3.ls}` : 'n/a')
    await shot('stage62-collapse-reload.png')

    // 恢复默认折叠（清理现场）
    await cdp.evaluate(`(() => { localStorage.removeItem('ro-welcome-collapsed'); return true })()`)
    await cdp.send('Page.reload', { ignoreCache: true })
    await sleep(4000)

    // ④ 几何契约
    const b = await cdp.evaluate(`({ w: window.innerWidth, h: window.innerHeight })`)
    check(b && b.w >= 419 && b.w <= 422 && b.h >= 619 && b.h <= 622, '④ 几何契约：展开 420×620（±2px 平台边框）', `${b.w}x${b.h}`)
  } catch (err) {
    check(false, '工具异常', String((err && err.message) || err))
  } finally {
    try { cdp && cdp.close() } catch { /* noop */ }
    spawnSync('taskkill', ['/pid', String(child.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true })
    await sleep(900)

    check(countOrbAll()=== 0, '进程收尾：我方 electron 残留 = 0', String(countOrbAll()))
  }

  const failCount = results.filter((r) => !r.ok).length
  writeFileSync(LOG, `=== P-R6.2 任务四验收 (${new Date().toISOString()}) ===\n${OUT.join('\n')}\n\n=== ${failCount === 0 ? '全部通过' : failCount + ' 项失败'}（共 ${results.length} 项）===\n`, 'utf8')
  log(`\nevidence -> ${LOG}`)
  log(`=== 结果：${failCount === 0 ? '全部通过' : failCount + ' 项失败'}（共 ${results.length} 项）===`)
  process.exit(failCount === 0 ? 0 : 1)
}

main().catch((e) => { console.error('折叠验收异常:', e); process.exit(2) })