// tools/accept-s66-cards.mjs —— S66·P0-2 卡片规则机器化 + P0-1 待处理空态/计划往返验收
//
// 背景：用户截图定案"「待处理」有标题没内容"是最后一起；S66 把这条规则从"人眼审查"
// 升级为机器判定。规则（任务书原文口径）：
//   ① 枚举卡片容器（[data-card] / .ro-card），每张卡有标注名；
//   ② 每张卡：标题存在 且（有可见子内容 或 [data-empty-state] 空态节点）；
//   ③ 空态必须含 ≥1 个可点按钮；
//   ④ 卡内不许有 >40×40 的无文字纯色块（S48 口径）；
//   ⑤ 六个页面逐一扫描：每页 ≥1 张卡，且全部满足 ①②；
//   ⑥ 失败时输出"卡标题 + 缺失原因"。
// 另加 P0-1 专项：待处理卡三态（无计划空态 / 未到期空态 / 到期行）与"完成"真往返
// （种子 plans.jsonl → 行出现 → 点完成 → coach 勾销落盘 → 空态切换）。
//
// 纪律：fail-closed（已有实例在跑即退出）；隔离 ORB_DATA_DIR（真实 data 零写入）；
// 所有结论以页内探针 + 隔离目录文件系统为证，不看按钮文案猜状态。
// 用法：node tools\accept-s66-cards.mjs

import { mkdtempSync, rmSync, cpSync, mkdirSync, writeFileSync, existsSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'
import { spawn, spawnSync } from 'node:child_process'
import {killMarked, countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-s66-cards')

const ELECTRON = ORB_ELECTRON
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9346
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 400) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}
// 进程清理同时匹配两种命令行形态（相对路径启动的实例只有 *apps*desktop*main.mjs* 能命中）
const countProcs = () => countOrbAll()
const killOwn = () => killMarked(MARK)

async function findTarget(t = 45000) {
  const d = Date.now() + t
  while (Date.now() < d) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const l = await r.json()
      const p = l.find((x) => x.type === 'page' && x.webSocketDebuggerUrl && /floating\.html/i.test(String(x.url || '')))
      if (p) return p
    } catch { /* 等 */ }
    await sleep(350)
  }
  return null
}
function cdpConnect(wsUrl) {
  const ws = new WebSocket(wsUrl)
  let seq = 0
  const pending = new Map()
  const ready = new Promise((res, rej) => { ws.addEventListener('open', () => res()); ws.addEventListener('error', () => rej(new Error('ws'))) })
  ws.addEventListener('message', (ev) => {
    let m = null
    try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
    if (!m || !m.id) return
    const p = pending.get(m.id); if (!p) return
    pending.delete(m.id)
    if (m.error) p.rej(new Error(JSON.stringify(m.error))); else p.res(m.result)
  })
  const send = (method, params) => {
    const id = ++seq
    return Promise.race([
      new Promise((res, rej) => { pending.set(id, { res, rej }); ws.send(JSON.stringify({ id, method, params })) }),
      new Promise((_, rej) => setTimeout(() => rej(new Error('cdp-timeout ' + method)), 20000)),
    ])
  }
  return { ready, send, close: () => { try { ws.close() } catch { /* noop */ } } }
}
async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r && r.exceptionDetails) throw new Error('ev: ' + JSON.stringify(r.exceptionDetails).slice(0, 240))
  return r && r.result ? r.result.value : undefined
}

/** 页内探针：一次取回全部卡片事实（枚举/标题/内容/空态/色块 + 全部可见空态）。 */
const PROBE = `(() => {
  const panel = document.getElementById('panel')
  if (!panel) return JSON.stringify({ error: 'no-panel' })
  const vis = (el) => {
    if (!el) return false
    const cs = getComputedStyle(el)
    if (cs.display === 'none' || cs.visibility === 'hidden') return false
    if (el.hidden) return false
    const r = el.getBoundingClientRect()
    return r.width > 0 && r.height > 0
  }
  const near = (rgb) => {
    if (!rgb) return false
    const m = /rgba?\\(([^)]+)\\)/.exec(rgb)
    if (!m) return false
    const p = m[1].split(',').map((x) => Number(x.trim()))
    if (p.length < 3) return false
    return p[1] > 120 && p[1] - p[0] > 40 && Math.abs(p[2] - p[1]) < 90 && p[1] > p[2] - 10
  }
  const TITLE_SELS = ['.ro-percep-title', '.ro-pomo-title', '.ro-onboard-title', 'summary', 'h4', '.ds-t13', '.s5-sec']
  const cards = [...panel.querySelectorAll('[data-card]')].map((el) => {
    const r = el.getBoundingClientRect()
    const collapsed = el.tagName === 'DETAILS' && !el.open
    let titleEl = null
    for (const sel of TITLE_SELS) {
      const c = el.querySelector(sel)
      if (c && vis(c) && (c.textContent || '').trim()) { titleEl = { sel, text: (c.textContent || '').trim().slice(0, 40) }; break }
    }
    let contentCount = 0
    for (const c of el.querySelectorAll('*')) {
      if (!vis(c)) continue
      const t = (c.textContent || '').trim()
      if (!t) continue
      if (titleEl && c.matches(titleEl.sel) && t === titleEl.text) continue
      contentCount++
    }
    const empties = [...el.querySelectorAll('[data-empty-state]')].filter(vis).map((n) => {
      const btns = [...n.querySelectorAll('button')].filter(vis)
      return { text: ((n.querySelector('.ds-empty-text') || n).textContent || '').trim().slice(0, 60), btns: btns.length, btnLabels: btns.map((b) => (b.textContent || '').trim()) }
    })
    const blocks = []
    for (const c of el.querySelectorAll('*')) {
      const cs = getComputedStyle(c)
      if (!near(cs.backgroundColor)) continue
      const rr = c.getBoundingClientRect()
      if (rr.width < 40 || rr.height < 40) continue
      if ((c.innerText || '').trim()) continue
      if (c.children.length) continue
      if (/^(BUTTON|INPUT|TEXTAREA|SELECT)$/.test(c.tagName)) continue
      if (c.id === 'ball' || c.closest('#ball') || c.classList.contains('ds-dot') || c.closest('#ro-ds-nav')) continue
      blocks.push({ tag: c.tagName, cls: String(c.className || '').slice(0, 40), w: Math.round(rr.width), h: Math.round(rr.height) })
    }
    return {
      card: el.getAttribute('data-card') || '', title: el.getAttribute('data-card-title') || '',
      visible: vis(el), collapsed, w: Math.round(r.width), h: Math.round(r.height),
      titleEl, contentCount, empties, blocks,
    }
  })
  const allEmpties = [...panel.querySelectorAll('[data-empty-state]')].filter(vis).map((n) => {
    const btns = [...n.querySelectorAll('button')].filter(vis)
    return { text: ((n.querySelector('.ds-empty-text') || n).textContent || '').trim(), btns: btns.length, inCard: !!n.closest('[data-card]') }
  })
  return JSON.stringify({ page: window.__s5 ? window.__s5.currentPage() : null, cards, allEmpties })
})()`

/** 单卡判定（规则 ②③④）：skip=不可见（隐藏卡不判）；ok/原因逐条列，失败带卡标题。 */
function verdict(c) {
  if (!c.visible) return { skip: true }
  const reasons = []
  if (!c.title) reasons.push('缺 data-card-title 标注')
  if (!c.titleEl) reasons.push('缺可见标题元素')
  const hasContent = c.contentCount > 0 || c.empties.length > 0
  // 折叠 details：summary 即可见内容（收起是设计意图，不是"有标题没内容"）
  if (!hasContent && !c.collapsed) reasons.push('无可见内容且无 [data-empty-state] 空态节点')
  if (c.collapsed && !c.titleEl) reasons.push('折叠卡无可读 summary')
  for (const e of c.empties) if (e.btns < 1) reasons.push('空态无可点按钮')
  if (c.blocks.length) reasons.push('卡内 >40x40 无色块 x' + c.blocks.length + '（' + c.blocks.map((b) => b.cls || b.tag).join(',') + '）')
  return { skip: false, ok: reasons.length === 0, reasons, label: c.title || c.card || '(未命名卡)' }
}
const scanVerdicts = (probe) => {
  const fails = []
  let visible = 0
  for (const c of probe.cards || []) {
    const v = verdict(c)
    if (v.skip) continue
    visible++
    if (!v.ok) fails.push(v.label + '｜' + v.reasons.join('；'))
  }
  return { visible, fails }
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s66-cards-'))
const tmpData = join(tmpRoot, 'data')
let child = null
let cdp = null
try {
  if (countProcs() > 0) { console.log('PREFLIGHT-FAIL: 已有实例在跑'); process.exit(2) }
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  delete env.ORB_LOG_DIR
  env.ORB_DATA_DIR = tmpData
  try { cpSync(join(PROJECT_ROOT, 'data', 'themes'), join(tmpData, 'themes'), { recursive: true }) } catch { /* 无 themes 也行 */ }
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], { cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] })
  const target = await findTarget()
  if (!target) { console.log('NO-TARGET'); process.exit(3) }
  cdp = cdpConnect(target.webSocketDebuggerUrl)
  await cdp.ready
  await cdp.send('Runtime.enable')
  let bridge = false
  const dl = Date.now() + 30000
  while (Date.now() < dl) {
    try { bridge = await ev(cdp, 'typeof globalThis.__s5 === "object" && typeof globalThis.researchOrb === "object"'); if (bridge) break } catch { /* 等 */ }
    await sleep(400)
  }
  if (!bridge) { console.log('NO-BRIDGE'); process.exit(3) }
  await ev(cdp, 'globalThis.researchOrb.send("window", { action: "expand" })')
  // 等首页 status 回包（待处理卡从"加载中"占位变为真实形态）
  {
    const until = Date.now() + 15000
    let ready = false
    while (Date.now() < until) {
      try {
        const n = await ev(cdp, `(() => { const c = document.querySelector('#s5-home .s5-pending'); return c ? c.children.length : -1 })()`)
        if (n >= 2) { ready = true; break }
      } catch { /* 等 */ }
      await sleep(400)
    }
    if (!ready) check('C-0 首页 status 回包（待处理卡完成首渲染）', false, '15s 内待处理卡未渲染')
    else check('C-0 首页 status 回包（待处理卡完成首渲染）', true, 'ok')
  }
  const probeNow = async () => JSON.parse(await ev(cdp, PROBE))
  const goPage = async (p) => { await ev(cdp, `window.__s5.page(${JSON.stringify(p)})`); await sleep(1300) }
  const noticeText = () => ev(cdp, `(() => { const n = document.getElementById('s5-notice'); return n && n.style.display !== 'none' ? (n.textContent || '').trim() : '' })()`)

  // ---------- C-1 卡片枚举与标注 ----------
  {
    // 口径：DATA_DIR = ORB_DATA_DIR 本身（safefs：resolve(ENV_DATA_DIR)），
    // 计划账在 <ORB_DATA_DIR>/coach/plans.jsonl。诊断/隐私卡要访问过设置页才创建，
    // 故首页基线枚举 = 8 张（4 张首页常驻 + 4 张二级页容器）。
    const p = await probeNow()
    const all = p.cards || []
    const untitled = all.filter((c) => !c.title || !c.card)
    check('C-1 卡片枚举：全部 [data-card] 有标注（card + card-title）',
      all.length >= 8 && untitled.length === 0,
      `枚举 ${all.length} 张（可见 ${all.filter((c) => c.visible).length}）｜未标注=${JSON.stringify(untitled.map((c) => c.card))}｜名单=${JSON.stringify([...new Set(all.map((c) => c.card))])}`)
  }

  // ---------- C-2 首页逐卡：标题 + 内容或空态 ----------
  {
    const p = await probeNow()
    const v = scanVerdicts(p)
    check('C-2 首页每张可见卡满足"标题 +（可见内容 或 空态节点）"',
      v.visible >= 3 && v.fails.length === 0,
      `可见卡=${v.visible}｜失败=${v.fails.length ? JSON.stringify(v.fails) : '无'}`)
  }

  // ---------- C-3 可见空态：≥1 可点按钮 + 文案 ≤40 字 ----------
  {
    const p = await probeNow()
    const es = p.allEmpties || []
    const noBtn = es.filter((e) => e.btns < 1)
    const tooLong = es.filter((e) => e.text.length > 40)
    check('C-3 全部可见空态含 ≥1 可点按钮且文案 ≤40 字',
      es.length > 0 && noBtn.length === 0 && tooLong.length === 0,
      `可见空态=${es.length}｜缺按钮=${noBtn.length}｜超 40 字=${tooLong.length}｜例="${(es[0] && es[0].text) || ''}"`)
  }

  // ---------- C-4 卡内无 >40×40 无色块 ----------
  {
    const p = await probeNow()
    const bad = (p.cards || []).filter((c) => c.visible && c.blocks.length)
    check('C-4 可见卡内无 >40x40 无文字纯色块（S48 口径）',
      bad.length === 0,
      bad.length === 0 ? '0 块' : JSON.stringify(bad.map((c) => ({ card: c.title, blocks: c.blocks }))))
  }

  // ---------- C-5 六页逐一扫描 ----------
  let settingsProbe = null
  {
    const pages = ['home', 'chat', 'trajectory', 'notes', 'publish', 'settings']
    const lines = []
    let allOk = true
    for (const pg of pages) {
      await goPage(pg)
      if (pg === 'chat') {
        // 对话页唯一卡片是主动询问卡（全局浮层）：经桥真发 panel ask 让它出现
        await ev(cdp, `(() => { const s = window.__ro && window.__ro.send; if (s) s('ui', { type: 'plugin:command', name: 'panel', args: 'ask' }); return !!s })()`)
        await sleep(1600)
      }
      const p = await probeNow()
      if (pg === 'settings') settingsProbe = p
      const v = scanVerdicts(p)
      const ok = p.page === pg && v.visible >= 1 && v.fails.length === 0
      if (!ok) allOk = false
      const names = (p.cards || []).filter((c) => c.visible).map((c) => c.card).join('+')
      lines.push(`${pg}[${names}]:卡${v.visible}${v.fails.length ? ' 失败=' + JSON.stringify(v.fails) : ' OK'}`)
    }
    check('C-5 六页逐一扫描：每页 ≥1 张可见卡且全部过"标题+内容/空态"', allOk, lines.join('｜'))
    // C-5b：设置页动态卡（隐私 x4 + 诊断）在访问设置页后才创建 —— 枚举与标注在此页验全
    {
      const all = (settingsProbe && settingsProbe.cards) || []
      const privacy = all.filter((c) => c.card === 'privacy')
      const diag = all.find((c) => c.card === 'diagnostics')
      const titled = privacy.every((c) => !!c.title) && !!diag && !!diag.title
      check('C-5b 设置页：隐私卡 x4 + 诊断卡均带标注标题（动态卡不漏标）',
        privacy.length === 4 && !!diag && titled,
        `隐私=${privacy.length}（标题=${privacy.map((c) => c.title).join('/')}）｜诊断=${diag ? diag.title : '缺失'}`)
    }
    await goPage('home')
  }

  // ---------- C-6a 待处理卡：无计划空态（文案 + 看日报按钮 + 点击回执） ----------
  {
    const p = await probeNow()
    const card = (p.cards || []).find((c) => c.card === 'pending')
    const emp = card && card.empties && card.empties[0]
    const textOk = !!emp && /今天没有待办/.test(emp.text) && /建议/.test(emp.text)
    const btnOk = !!emp && emp.btns >= 1 && emp.btnLabels.some((b) => /看日报/.test(b))
    check('C-6a 待处理卡无计划态：空态文案（今天没有待办…1–3 条建议）+ [看日报] 按钮',
      !!card && card.visible && textOk && btnOk,
      JSON.stringify({ empty: emp || null }))
    // 点「看日报」→ 真回执（隔离实例今天没有日报 → 明说"还没有生成"，不装）
    await ev(cdp, `(() => { const c = document.querySelector('#s5-home .s5-pending [data-empty-state]'); const b = c && c.querySelector('button'); if (b) b.click(); return !!b })()`)
    await sleep(1500)
    const notice = await noticeText()
    const pg = await ev(cdp, 'window.__s5.currentPage ? window.__s5.currentPage() : null')
    check('C-6a2 点「看日报」有真回执（今天无日报 → 明示；不跳转不装数据）',
      /日报/.test(notice), JSON.stringify({ notice: notice.slice(0, 90), page: pg }))
    await goPage('home')
  }

  // ---------- C-6a3 有日报时：今日建议进行 + 看日报摘要真回执 ----------
  {
    const day = (() => { const d = new Date(); const p = (n) => String(n).padStart(2, '0'); return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}` })()
    const dailyDir = join(tmpData, 'coach', 'daily')
    mkdirSync(dailyDir, { recursive: true })
    const report = [
      '# 教练日报 ' + day,
      '',
      '- 评分：82 / 100（score-plan · 旗舰 LLM）',
      '- 轨迹：当日累计 4 条（本轮新增 3 条；全部可回指 trajectory.jsonl）',
      '',
      '## 明日建议',
      '',
      '1. 把 MPC 两阶段调度的约束推导整理成一张对比表。',
      '2. 用 25 分钟番茄钟专攻分布式优化第二章习题 2.3。',
      '',
    ].join('\n')
    writeFileSync(join(dailyDir, `daily-${day}.md`), report, 'utf8')
    await ev(cdp, 'window.__s5.refresh()')
    // 等 status 回包：今日建议行出现（≤3 条）
    let advice = null
    const until = Date.now() + 10000
    while (Date.now() < until) {
      try {
        advice = JSON.parse(await ev(cdp, `(() => {
          const secs = [...document.querySelectorAll('#s5-home .s5-pending .s5-sec')].map((x) => (x.textContent || '').trim())
          const rows = [...document.querySelectorAll('#s5-home .s5-pending .s5-row')].map((x) => (x.textContent || '').trim())
          return JSON.stringify({ secs, rows })
        })()`))
        if (advice && advice.secs.some((s) => /今日建议/.test(s)) && advice.rows.length >= 2) break
      } catch { /* 等 */ }
      await sleep(400)
    }
    check('C-6a3 有日报时：待处理卡渲染「今日建议」行（来自日报文件，≤3 条）',
      !!advice && advice.secs.some((s) => /今日建议/.test(s)) && advice.rows.some((r) => /MPC/.test(r)),
      JSON.stringify(advice))
    // 点「看日报」→ 真摘要 + 跳对话页
    await ev(cdp, `(() => { const c = document.querySelector('#s5-home .s5-pending [data-empty-state]'); const b = c && c.querySelector('button'); if (b) b.click(); return !!b })()`)
    await sleep(1500)
    const notice2 = await noticeText()
    const pg2 = await ev(cdp, 'window.__s5.currentPage ? window.__s5.currentPage() : null')
    check('C-6a4 点「看日报」→ 真摘要（评分 82 / 100 · 轨迹 4 条 · 建议 2 条）并跳对话页',
      /评分 82 \/ 100/.test(notice2) && /轨迹 4 条/.test(notice2) && pg2 === 'chat',
      JSON.stringify({ notice: notice2.slice(0, 120), page: pg2 }))
    await goPage('home')
  }

  // ---------- C-6b 计划往返：种子 → 到期行+完成 → 勾销落盘 → 空态切换 ----------
  {
    // 路径口径：DATA_DIR = ORB_DATA_DIR 本身 → 计划账在 <tmpData>/coach/plans.jsonl
    const coachDir = join(tmpData, 'coach')
    mkdirSync(coachDir, { recursive: true })
    const now = Date.now()
    const dueIso = new Date(now - 30 * 60 * 1000).toISOString()
    const nextIso = new Date(now + 3 * 3600 * 1000).toISOString()
    const DUE_ID = 'pl-s66-due-1'
    const DUE_TEXT = '整理微电网 MPC 两阶段调度笔记'
    const lines = [
      JSON.stringify({ ts: dueIso, id: DUE_ID, text: DUE_TEXT, dueAt: dueIso, status: 'pending', createdAt: dueIso, event: 'add', source: 'accept-s66' }),
      JSON.stringify({ ts: nextIso, id: 'pl-s66-next-1', text: '预习分布式优化下一章', dueAt: nextIso, status: 'pending', createdAt: nextIso, event: 'add', source: 'accept-s66' }),
    ]
    writeFileSync(join(coachDir, 'plans.jsonl'), lines.join('\n') + '\n', 'utf8')
    await ev(cdp, 'window.__s5.refresh()')
    // 等 status 回包：到期行出现
    let row = null
    const until = Date.now() + 10000
    while (Date.now() < until) {
      try {
        row = JSON.parse(await ev(cdp, `(() => {
          const rows = [...document.querySelectorAll('#s5-home .s5-pending .s5-plan-row')]
          const hit = rows.find((x) => /整理微电网/.test(x.textContent || ''))
          const btn = hit ? hit.querySelector('button') : null
          return JSON.stringify({ n: rows.length, text: hit ? (hit.textContent || '').trim().slice(0, 60) : null, btn: btn ? (btn.textContent || '').trim() : null })
        })()`))
        if (row && row.text) break
      } catch { /* 等 */ }
      await sleep(400)
    }
    check('C-6b1 种子计划后：待处理卡出现到期行（文本 + 到期标注 + [完成] 按钮）',
      !!row && !!row.text && row.btn === '完成' && /已到期/.test(row.text || ''),
      JSON.stringify(row))
    // 点「完成」→ 真勾销（coach plans done：记忆镜像 + 审计 + 只勾一次）
    await ev(cdp, `(() => { const rows = [...document.querySelectorAll('#s5-home .s5-pending .s5-plan-row')]; const hit = rows.find((x) => /整理微电网/.test(x.textContent || '')); const b = hit && hit.querySelector('button'); if (b) b.click(); return !!b })()`)
    let done = false
    let notice = ''
    const until2 = Date.now() + 10000
    while (Date.now() < until2) {
      await sleep(400)
      notice = await noticeText()
      const n = await ev(cdp, `document.querySelectorAll('#s5-home .s5-pending .s5-plan-row').length`)
      if (/计划已勾销/.test(notice) && n === 0) { done = true; break }
    }
    let fileHasDone = false
    try {
      const txt = readFileSync(join(coachDir, 'plans.jsonl'), 'utf8')
      fileHasDone = txt.split('\n').some((l) => { try { const r = JSON.parse(l); return r && r.id === DUE_ID && r.event === 'done' } catch { return false } })
    } catch { /* 读不到即未落盘 */ }
    check('C-6b2 点「完成」→ 勾销真往返（回执 + plans.jsonl 落 done 事件 + 到期行消失）',
      done && fileHasDone, JSON.stringify({ notice: notice.slice(0, 60), fileHasDone }))
    // 勾销后剩 1 条未到期 → 切换到"有计划未到期"空态（有 N 条计划待办，最近一条 HH:MM 到期 + 查看计划）
    const p2 = await probeNow()
    const card2 = (p2.cards || []).find((c) => c.card === 'pending')
    const emp2 = card2 && card2.empties && card2.empties[0]
    check('C-6b3 勾销后待处理卡切换"未到期"空态（N 条计划待办 + 最近一条 HH:MM 到期 + [查看计划]）',
      !!emp2 && /条计划待办/.test(emp2.text) && /最近一条 \d\d:\d\d 到期/.test(emp2.text) && emp2.btnLabels.some((b) => /查看计划/.test(b)),
      JSON.stringify({ empty: emp2 || null }))
  }

  // 证据落盘（隔离目录，真实 data 零写入）；LOG_DIR = ORB_DATA_DIR/logs
  try {
    const logDir = join(tmpData, 'logs')
    mkdirSync(logDir, { recursive: true })
    writeFileSync(join(logDir, 's66-cards-accept.json'), JSON.stringify({ tool: 'accept-s66-cards', at: new Date().toISOString(), total: items.length, pass: items.filter((i) => i.ok).length, items }, null, 2), 'utf8')
  } catch { /* 留证失败不阻断 */ }
} catch (e) {
  console.log('ACCEPT-ERROR: ' + String((e && e.stack) || e).slice(0, 400))
  check('C-X 验收脚本异常', false, String((e && e.message) || e).slice(0, 200))
} finally {
  try { if (cdp) cdp.close() } catch { /* noop */ }
  killOwn()
  await sleep(1200)
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}
const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s66-cards: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exitCode = items.length - pass === 0 ? 0 : 1
