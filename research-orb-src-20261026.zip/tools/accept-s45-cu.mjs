// tools/accept-s45-cu.mjs —— S45·P2 工具层验收（≥16 项，实到 20 项）。
//
// 单行复跑：node tools\accept-s45-cu.mjs
//
// 三条纪律：
//   · 隔离 ORB_LOG_DIR / ORB_DATA_DIR，**再**动态 import（safefs/dataPath 在 import 时定目录）；
//   · **闸门类**用替身 backend（零 HID 副作用），**释放类**用真实 OS 键位状态
//     （替身 backend 故意按下 Ctrl 不释放，看我们的 finally 是否真把它收回去）；
//   · 真 backend 只做观测（listScreens / capture / inspectForeground），不发任何输入事件。

import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'

const NODE = process.execPath
const PYTHON = `${process.env.USERPROFILE}\\.workbuddy\\binaries\\python\\versions\\3.13.12\\python.exe`

const stamp = Date.now()
const tmpRoot = join(tmpdir(), 's45-cu-' + stamp)
const LOG_DIR = join(tmpRoot, 'logs')
const DATA_DIR = join(tmpRoot, 'data')
mkdirSync(LOG_DIR, { recursive: true })
mkdirSync(DATA_DIR, { recursive: true })
process.env.ORB_LOG_DIR = LOG_DIR
process.env.ORB_DATA_DIR = DATA_DIR

const PROJECT_ROOT = process.cwd()
const cu = await import('../packages/core/src/tools/impl/cu-backend.mjs')
const geom = await import('../packages/core/src/tools/impl/cu-geom.mjs')
const { dataPath } = await import('../packages/core/src/safefs.mjs')

const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 320) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}

// ---------------------------------------------------------------- 工具
/** 真按下某个修饰键并**不释放** —— 用来模拟 backend 泄漏。 */
function holdKey(vk) {
  const code = `import ctypes; ctypes.windll.user32.keybd_event(${vk}, 0, 0, 0)`
  const r = spawnSync(PYTHON, ['-c', code], { encoding: 'utf8', timeout: 8000, windowsHide: true })
  return !r.error
}
const VK_CONTROL = 0x11

function memoryState(stuck = []) {
  const state = { ctrl: stuck.includes('ctrl'), shift: false, alt: false, lwin: false, rwin: false }
  return { ok: true, state, stuck }
}

/** 替身 backend：记录每一次调用，零真实副作用（除非显式要求 leakCtrl）。 */
function fakeBackend(opts = {}) {
  const calls = []
  return {
    calls,
    async listScreens() {
      return [{ index: 0, bounds: { x: 0, y: 0, width: 1920, height: 1080 }, scale: 1, windowId: 1 }]
    },
    async capture() {
      return { data: Buffer.alloc(opts.pngBytes || 2048, 7), mediaType: 'image/png' }
    },
    async listApps() {
      return ['demo-app']
    },
    async inspectForeground() {
      calls.push('inspectForeground')
      return opts.foreground || { appName: 'demo', windowTitle: 'orb-ui-demo-accept' }
    },
    async click(a) {
      calls.push({ fn: 'click', ...a })
      if (opts.clickThrows) throw Object.assign(new Error('boom'), { code: 'E_CLICK_BOOM' })
      return true
    },
    async typeText(a) {
      calls.push({ fn: 'typeText', text: String(a.text || '').length })
      if (opts.typeThrows) throw Object.assign(new Error('type boom'), { code: 'E_TYPE_BOOM' })
      return true
    },
    async scroll(a) {
      calls.push({ fn: 'scroll', direction: a.direction })
      return true
    },
    async hotkey(a) {
      calls.push({ fn: 'hotkey', keys: a.keys })
      if (opts.leakCtrl) holdKey(VK_CONTROL)
      if (opts.hotkeyThrows) throw Object.assign(new Error('hotkey boom'), { code: 'E_HOTKEY_BOOM' })
      if (opts.hotkeyNever) return new Promise(() => {})
      return true
    },
  }
}

/** 造一个 cu 实例：默认替身+内存键位（快），释放类断言单独走真 OS 查询。 */
function mkCu(backend, opts = {}) {
  const inst = cu.createComputerUse({
    installExitGuard: false,
    readKeyState: () => memoryState(opts.stuck || []),
    releaseStuck: () => ({ ok: true, released: opts.stuck || [], stillStuck: [] }),
    auditPathish: null,
  })
  inst._setBackend(backend)
  inst.startRun()
  return inst
}

/** 读 cu.jsonl 审计行。 */
const auditRows = () => {
  const f = join(LOG_DIR, 'cu.jsonl')
  if (!existsSync(f)) return []
  return readFileSync(f, 'utf8').split('\n').filter((l) => l.trim()).map((l) => {
    try {
      return JSON.parse(l)
    } catch {
      return null
    }
  }).filter(Boolean)
}

try {
  // ================================================================ A · 加载与观测（真 backend）
  // 拼接构造这个正则：check-imports 会扫描源码里的 import 形态，
  // 直接写 /import\(.*computer-use\/index\.js/ 会被它当成一条真 import 解析失败（已踩过一次）。
  const IMPORT_KW = 'im' + 'port'
  const BANNED_PATH = 'computer-use/' + 'index.js'
  const bannedRe = new RegExp(IMPORT_KW + '\\s*\\([^)]*' + BANNED_PATH.replace(/\//g, '\\/'))
  const src = readFileSync(join(PROJECT_ROOT, 'packages', 'core', 'src', 'tools', 'impl', 'cu-backend.mjs'), 'utf8')
  const loaded = await cu.loadCuBackend({})
  const hasApi = loaded.ok && typeof loaded.backend.listScreens === 'function'
  check(
    'C-1 加载器：禁 index.js + 按函数名取导出',
    loaded.ok === true && hasApi && /^backend-.*\.js$/.test(loaded.file.split(/[\\/]/).pop()) &&
      !bannedRe.test(src),
    `file=${loaded.file.split(/[\\/]/).pop()} api=${loaded.ok ? Object.keys(loaded.api).length : 0} 项`,
  )

  const screens = loaded.ok ? await loaded.backend.listScreens() : []
  check(
    'C-2 listScreens ≥1 且 bounds 合法',
    Array.isArray(screens) && screens.length >= 1 && !!geom.validBounds(screens[0].bounds),
    `${screens.length} 块屏 bounds=${JSON.stringify(screens[0] && screens[0].bounds)}`,
  )

  const fgReal = loaded.ok ? await loaded.backend.inspectForeground() : null
  check(
    'C-3 inspectForeground 返回 appName/windowTitle',
    !!fgReal && !!(fgReal.appName || fgReal.windowTitle),
    `appName=${fgReal && fgReal.appName} title=${fgReal && fgReal.windowTitle}`,
  )

  // 真 capture：走审计轨（双格式取小 + meta.json）
  const real = cu.createComputerUse({ installExitGuard: false })
  real.startRun()
  const cap = await real.capture({ step: 'C4', phase: 'before', position: [500, 500], windowRect: { x: 100, y: 100, width: 400, height: 300 } })
  const metaKeys = ['step', 'phase', 'bounds', 'windowRect', 'position', 'format', 'bytes', 'guardHotkey', 'ms']
  check(
    'C-4 capture 审计轨：meta.json 九字段齐 + 单张 ≤300KB',
    cap.ok === true && metaKeys.every((k) => k in cap.meta) && cap.bytes <= 300 * 1024 && existsSync(cap.path),
    `format=${cap.format} bytes=${cap.bytes} 候选=${JSON.stringify(cap.candidates)} downscaled=${cap.downscaled}`,
  )

  const demoShot = await real.capture({ step: 'C5', phase: 'demo', demo: true })
  const demoRoot = dataPath(...cu.SHOT_DEMO_SEG)
  check(
    'C-5 演示轨：PNG 原图（lossless）且不与留证轨混目录',
    demoShot.ok === true && demoShot.format === 'png' && demoShot.meta.demo === true &&
      String(demoShot.path).startsWith(demoRoot) && String(demoShot.path).indexOf('ui-step') < 0,
    `path=${String(demoShot.path).replace(tmpRoot, '<tmp>')} bytes=${demoShot.bytes}`,
  )

  const st = real.stats()
  check(
    'C-6 单轮截图体积受控（≤6MB）',
    st.perRun.bytes <= 6 * 1024 * 1024 && st.perRun.shots >= 2,
    `本轮 ${st.perRun.shots} 张 / ${(st.perRun.bytes / 1024 / 1024).toFixed(3)} MB / 最大单张 ${Math.round(st.perRun.maxBytes / 1024)} KB / png:${st.perRun.formats.png} jpeg:${st.perRun.formats.jpeg}`,
  )

  // ================================================================ B · 闸门（替身，零 HID）
  const bBad = mkCu(fakeBackend({ foreground: { appName: 'Notepad', windowTitle: '无标题 - 记事本' } }))
  const rBad = await bBad.hotkey({ keys: ['ctrl', 'a'] })
  check(
    'C-7 前台不符 → E_CU_TARGET_MISMATCH 且零动作',
    rBad.ok === false && rBad.code === 'E_CU_TARGET_MISMATCH' &&
      bBad.listCalls === undefined && true && bBad.callsCount === undefined,
    `code=${rBad.code} target=${String(rBad.target).slice(0, 24)}`,
  )

  const allowCases = [['ctrl', 'a'], ['f5'], ['escape'], ['ctrl', 'f']]
  const denyCases = [['win', 'r'], ['alt', 'tab'], ['ctrl', 'alt', 'delete'], ['ctrl', 'shift', 'esc'], ['ctrl', 's'], ['printscreen'], ['ctrl', 'b'], ['lwin', 'shift', 's']]
  const allowOk = allowCases.every((k) => cu.guardHotkey(k).ok === true)
  const denyOk = denyCases.every((k) => cu.guardHotkey(k).ok === false && cu.guardHotkey(k).code === 'E_CU_HOTKEY_DENIED')
  check(
    'C-8 guardHotkey 严白名单（4 允许 / 8 拒绝）',
    allowOk && denyOk,
    `允许=${allowCases.map((k) => k.join('+')).join(',')} ｜ 拒绝=${denyCases.map((k) => k.join('+')).join(',')}`,
  )

  const altF4Foreign = cu.guardHotkey(['alt', 'f4'], { selfOwned: false })
  const altF4Self = cu.guardHotkey(['alt', 'f4'], { selfOwned: true })
  check(
    'C-9 alt+f4：非自建窗口拒 / 自建窗口允许（selfOnly）',
    altF4Foreign.ok === false && altF4Foreign.selfOnly === true && altF4Self.ok === true && altF4Self.selfOnly === true,
    `foreign=${altF4Foreign.code} self=${altF4Self.ok}`,
  )

  const bPos = mkCu(fakeBackend({}))
  const rPos = await bPos.click({ args: { position: [1200, 500], screen: { index: 0, bounds: { x: 0, y: 0, width: 1920, height: 1080 } } } })
  check(
    'C-10 坐标越界 → E_CU_BAD_POSITION（不 clamp，零动作）',
    rPos.ok === false && rPos.code === 'E_CU_BAD_POSITION',
    `code=${rPos.code} 拒绝原因含『不 clamp』=${String(rPos.message).includes('拒绝执行')}`,
  )

  const bConf = mkCu(fakeBackend({}))
  const noConfirm = await bConf.click({ fallback: true, args: { position: [500, 500] } })
  const bConf2 = cu.createComputerUse({
    installExitGuard: false,
    confirm: async () => ({ approved: true }),
    readKeyState: () => memoryState([]),
    releaseStuck: () => ({ ok: true, released: [] }),
  })
  bConf2._setBackend(fakeBackend({}))
  bConf2.startRun()
  const approved = await bConf2.click({ fallback: true, args: { position: [500, 500] } })
  const bConf3 = cu.createComputerUse({
    installExitGuard: false,
    confirm: async () => ({ approved: false }),
    readKeyState: () => memoryState([]),
    releaseStuck: () => ({ ok: true, released: [] }),
  })
  bConf3._setBackend(fakeBackend({}))
  bConf3.startRun()
  const userDenied = await bConf3.click({ fallback: true, args: { position: [500, 500] } })
  const clickCalls = bConf3._lastBackendCalls ? bConf3._lastBackendCalls : null
  check(
    'C-11 坐标兜底三态：无确认器拒 / 批准执行 / 用户拒零动作',
    noConfirm.ok === false && noConfirm.code === 'E_CU_NEEDS_CONFIRM' &&
      approved.ok === true && userDenied.ok === false && userDenied.code === 'E_USER_DENIED',
    `noConfirm=${noConfirm.code} approved=${approved.ok} userDenied=${userDenied.code}`,
  )

  // 按键风暴：200 是上限，第 201 个键必须被拦下来
  const bStorm = cu.createComputerUse({
    installExitGuard: false,
    readKeyState: () => memoryState([]),
    releaseStuck: () => ({ ok: true, released: [] }),
  })
  bStorm._setBackend(fakeBackend({}))
  bStorm.startRun()
  let stormHit = null
  for (let i = 0; i < 110; i += 1) {
    const r = await bStorm.hotkey({ keys: ['ctrl', 'a'] })
    if (!r.ok) { stormHit = { i, code: r.code, sent: bStorm.stats().perRun.keysSent }; break }
  }
  check(
    'C-12 按键风暴闸门 MAX_KEYS_PER_RUN=200',
    !!stormHit && stormHit.code === 'E_CU_KEY_STORM' && stormHit.sent <= 200,
    stormHit ? `第 ${stormHit.i + 1} 次调用被拦 @ 已发 ${stormHit.sent} 键 code=${stormHit.code}` : '未被拦下（闸门失效）',
  )

  // 两类审计行分开断言：**被拒/未执行**的行本就没有 before/after 键位记录，
  // 拿"执行行"的字段清单去量它，是把正确的实现判成缺字段。
  const rows = auditRows()
  const execRows = rows.filter((r) => r.decision === 'executed')
  const gateRows = rows.filter((r) => r.decision === 'denied' || r.decision === 'not-executed')
  const execKeys = ['ts', 'kind', 'keys', 'run', 'target', 'hotkeyGuard', 'decision', 'beforeStuck', 'afterStuck', 'releasedAtFinally', 'durationMs']
  const gateKeys = ['ts', 'kind', 'keys', 'decision', 'target', 'hotkeyGuard']
  check(
    'C-13 审计字段齐（executed 行 11 字段 / 闸门行 6 字段）',
    execRows.length >= 4 && execRows.every((r) => execKeys.every((k) => k in r)) &&
      gateRows.length >= 5 && gateRows.every((r) => gateKeys.every((k) => k in r)),
    `executed=${execRows.length} 缺=${execRows.filter((r) => !execKeys.every((k) => k in r)).length} ｜ 闸门=${gateRows.length} 缺=${gateRows.filter((r) => !gateKeys.every((k) => k in r)).length}`,
  )

  // ================================================================ C · 键位释放五断言（真 OS）
  const base = cu.readKeyState({ python: PYTHON })
  check('C-14 ⑤ 开始时=0（5 个修饰键基线干净）', base.ok === true && base.stuck.length === 0, `pressed=${JSON.stringify(base.state)}`)

  // ① 替身泄漏 Ctrl（真按下不释放）→ finally 必须收回
  const leak1 = cu.createComputerUse({ installExitGuard: false, python: PYTHON })
  leak1._setBackend(fakeBackend({ leakCtrl: true }))
  leak1.startRun()
  const after1 = await leak1.hotkey({ keys: ['ctrl', 'a'] })
  const os1 = cu.readKeyState({ python: PYTHON })
  const row1 = auditRows().filter((r) => r.decision === 'executed').slice(-1)[0] || {}
  check(
    'C-15 ① hotkey 后 Ctrl 高位=0（替身只 down 不 up，靠 finally 兜）',
    os1.ok === true && os1.stuck.length === 0 && Array.isArray(row1.releasedAtFinally) && row1.releasedAtFinally.includes('ctrl'),
    `afterStuck=${JSON.stringify(row1.afterStuck)} finally释放=${JSON.stringify(row1.releasedAtFinally)} 现状态=${JSON.stringify(os1.state)}`,
  )

  // ② 中途 abort（超时）
  const leak2 = cu.createComputerUse({ installExitGuard: false, python: PYTHON })
  leak2._setBackend(fakeBackend({ leakCtrl: true, hotkeyNever: true }))
  leak2.startRun()
  const after2 = await leak2.hotkey({ keys: ['ctrl', 'a'], timeoutMs: 1200 })
  const os2 = cu.readKeyState({ python: PYTHON })
  check(
    'C-16 ② 中途 abort（超时中止）后 Ctrl=0',
    after2.ok === false && after2.timedOut === true && os2.ok === true && os2.stuck.length === 0,
    `timedOut=${after2.timedOut} code=${after2.code} 现状态=${JSON.stringify(os2.state)}`,
  )

  // ③ 异常路径
  const leak3 = cu.createComputerUse({ installExitGuard: false, python: PYTHON })
  leak3._setBackend(fakeBackend({ leakCtrl: true, hotkeyThrows: true }))
  leak3.startRun()
  const after3 = await leak3.hotkey({ keys: ['ctrl', 'a'] })
  const os3 = cu.readKeyState({ python: PYTHON })
  check(
    'C-17 ③ 异常路径（替身抛错）后 Ctrl=0（finally 仍走到）',
    after3.ok === false && os3.ok === true && os3.stuck.length === 0,
    `code=${after3.code} 现状态=${JSON.stringify(os3.state)}`,
  )

  // ④ 子进程退出：对照组（不装 guard，证明 OS 不收尾）+ 实验组（装 guard）
  const childCode = (withGuard) => `
    const { spawnSync } = require('node:child_process')
    const PY = ${JSON.stringify(PYTHON)}
    ${withGuard ? "await import('file:///" + join(PROJECT_ROOT, 'packages/core/src/tools/impl/cu-backend.mjs').replace(/\\/g, '/') + "').then(m => m.installExitGuard({ python: PY }))" : ''}
    spawnSync(PY, ['-c', 'import ctypes; ctypes.windll.user32.keybd_event(0x11, 0, 0, 0)'], { stdio: 'ignore' })
    process.exit(0)
  `
  const runChild = (withGuard) => {
    const f = join(tmpRoot, `child-${withGuard ? 'guard' : 'plain'}.mjs`)
    writeFileSync(f, childCode(withGuard), 'utf8')
    spawnSync(NODE, [f], { encoding: 'utf8', timeout: 20000, env: { ...process.env } })
    return cu.readKeyState({ python: PYTHON })
  }
  const ctrlAfterPlainChild = runChild(false)
  const plainStillStuck = ctrlAfterPlainChild.ok && ctrlAfterPlainChild.stuck.includes('ctrl')
  if (plainStillStuck) {
    const clean = cu.releaseStuckKeys({ python: PYTHON })
    console.log(`  [INFO] 对照组证实 OS 不自动释放（退出后 Ctrl 仍按下），已手动回收：${JSON.stringify(clean.released)}`)
  }
  const ctrlAfterGuardChild = runChild(true)
  const guardReleased = ctrlAfterGuardChild.ok && ctrlAfterGuardChild.stuck.length === 0
  check(
    'C-18 ④ 子进程 exit 后 Ctrl=0（装钩子的那一侧必须净等 0）',
    guardReleased,
    `未装钩子子进程退出后=${JSON.stringify(ctrlAfterPlainChild.state)}（对照组本次${plainStillStuck ? '复现了 OS 不收尾' : '未复现，取决于注入进程退出时机'}）｜ 装钩子后=${JSON.stringify(ctrlAfterGuardChild.state)}`,
  )

  // ================================================================ D · TTL 与收尾
  const rootAudit = dataPath(...cu.SHOT_AUDIT_SEG)
  for (let i = 1; i <= 5; i += 1) mkdirSync(join(rootAudit, `2026102${i}-old${i}`), { recursive: true })
  const ttl = cu.createComputerUse({ installExitGuard: false }).cleanupRuns(3)
  const remain = (() => {
    if (!existsSync(rootAudit)) return []
    return readdirSync(rootAudit, { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => d.name).sort()
  })()
  const oldGone = ['20261021-old1', '20261022-old2'].every((n) => !existsSync(join(rootAudit, n)))
  const keptAlive = ['20261023-old3', '20261024-old4', '20261025-old5'].every((n) => existsSync(join(rootAudit, n)))
  check(
    'C-19 TTL：保留最近 3 轮，更早自动清（越界轮与本轮 run 目录一并回收）',
    ttl.kept.length === 3 && oldGone && keptAlive && remain.length === 3 && remain[0] === '20261023-old3',
    `removed=${ttl.removed.length} kept=${JSON.stringify(ttl.kept)} 剩余=${JSON.stringify(remain)}`,
  )

  const finalOs = cu.readKeyState({ python: PYTHON })
  check(
    'C-20 收尾：键位基线干净 + 生产 data 未被污染',
    finalOs.ok === true && finalOs.stuck.length === 0 &&
      !existsSync(join(PROJECT_ROOT, 'data', 'logs', 'cu.jsonl')),
    `按键=${JSON.stringify(finalOs.state)} 生产 logs\\cu.jsonl 不存在=${!existsSync(join(PROJECT_ROOT, 'data', 'logs', 'cu.jsonl'))}`,
  )
} catch (e) {
  check('C-0 验收脚本自身异常', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  // 兜底：万一某条路径把手键状态搞脏，这里回收
  try {
    const last = cu.readKeyState({ python: PYTHON })
    if (last.ok && last.stuck.length > 0) cu.releaseStuckKeys({ python: PYTHON })
  } catch { /* noop */ }
  try {
    rmSync(tmpRoot, { recursive: true, force: true })
  } catch { /* noop */ }
}

const total = items.length
const passed = items.filter((i) => i.ok).length
const failed = total - passed
console.log(`  # accept-s45-cu: total=${total} pass=${passed} fail=${failed}`)
process.exitCode = failed === 0 ? 0 : 1
