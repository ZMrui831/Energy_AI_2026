// tools/probe-lit-2-editor.js
//
// 面板取证 ②：勾选前 3 条候选 → 点「生成选中卡片」→ 等批量结果 → 点第一行的「编辑」。
// 函数体形式（shot.mjs 已包在 async 函数里），见脚本①的说明。
const api = globalThis.researchOrb
const send = (type, detail) => api.send('ui', Object.assign({ type: type, at: Date.now() }, detail || {}))
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const lit = document.getElementById('ro-lit')
const editor = document.getElementById('ro-editor')
if (!lit) return { error: 'ro-lit 不存在' }

// 1) 勾选前三条
const boxes = [...lit.querySelectorAll('#ro-lit input[data-idx]')]
if (boxes.length < 3) return { error: '候选不足 3 条', boxes: boxes.length }
boxes.slice(0, 3).forEach((b) => { b.checked = true })

// 2) 点「生成选中卡片」（走面板按钮，等价于用户勾选后点按钮）
// 「生成选中卡片」直接挂在面板内容区（不在一行控件里），所以这里扫全部按钮
const gen = [...lit.querySelectorAll('button')].find((b) => b.textContent === '生成选中卡片')
if (!gen) return { error: '没有生成按钮' }
gen.click()

// 3) 等批量结果渲染（出现「编辑」按钮即说明已进入卡片视图）
let editBtn = null
for (let i = 0; i < 90; i += 1) {
  await sleep(400)
  editBtn = [...lit.querySelectorAll('.ro-cand button')].find((b) => b.textContent === '编辑')
  if (editBtn) break
}
if (!editBtn) {
  return { error: '批量生成后没有出现可编辑卡片', body: lit.textContent.slice(0, 200) }
}
editBtn.click()
await sleep(600)
const rows = [...editor.querySelectorAll('.ro-editor-row')]
return {
  editorOpen: editor.classList.contains('ro-open'),
  fieldCount: rows.length,
  fieldNames: rows.map((r) => r.querySelector('label').textContent),
  firstValues: rows.slice(0, 5).map((r) => {
    const i = r.querySelector('input, textarea')
    return i ? String(i.value).slice(0, 44) : null
  }),
  buttons: [...editor.querySelectorAll('button')].map((b) => b.textContent),
}
