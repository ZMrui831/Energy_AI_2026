// tools/accept-s65-dualscore.mjs —— S65·P0-1 增量路径双维打分验收（≥6 项）
// 单行复跑：node tools\accept-s65-dualscore.mjs
// 证据：data\logs\s65-dualscore-accept.json
//
// 修的是什么：增量抽取的轨迹只有 window/process="（增量抽取）" 占位串、intent=null
// → 关键词规则（classifyLine）必然落 null → 日报 workScore/lifeScore 永远 n/a。
// 本轮：视觉抽取的结构化 intent（学习|工作|生活|其他）→ work/life/不计数；
// 轨迹行落 line 字段；日报按维度算分；两维都空才写 n/a（不硬造 0）。
//
// 隔离：ORB_DATA_DIR/ORB_LOG_DIR 指临时目录（safefs 在 import 时定格目录 → 先设后 import）。
import { existsSync, mkdirSync, mkdtempSync, readFileSync, writeFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

process.env.ORB_LOG_DIR = join(tmpdir(), 's65-dual-logs-' + Date.now())
process.env.ORB_DATA_DIR = join(tmpdir(), 's65-dual-data-' + Date.now())
const { dataPath } = await import('../packages/core/src/safefs.mjs')
const { createDailyPipeline, intentLine, trackLine } = await import('../packages/plugins/coach/daily.mjs')

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }

// ── 桩：不调真实 LLM（本验收只判"分类与计分口径"，评分桩返回失败 → score=unavailable，绝不假造分）──
const router = {
  run: async (tier) => {
    if (tier === 'summarize') return { ok: true, text: '["随手记录"]' } // 中性归纳：证明分类来自结构化 intent 而非归纳词
    return { ok: false, error: { code: 'E_STUB_SCORE', message: '验收桩：本轮不评分（双维计分与评分无关）' } }
  },
}
const extractor = {
  extract: async ({ imagePath }) => ({
    frameId: 'f-' + Math.random().toString(36).slice(2, 8),
    textSha256: 's-' + Math.random().toString(36).slice(2, 10),
    text: '（验收桩文本）',
    structured: null, // 抓帧不给结构化 intent → 走关键词兜底（与增量行区分开）
    cached: false,
    source: 'stub',
  }),
}

const mkDir = (tag) => { const d = join(dataPath('tmp'), 's65-' + tag + '-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6)); mkdirSync(d, { recursive: true }); return d }
const writeInc = (dir, rows) => writeFileSync(join(dir, 'incremental.jsonl'), rows.map((r) => JSON.stringify(r)).join('\n') + '\n', 'utf8')
const trajRows = (dir) => {
  const p = join(dir, 'trajectory.jsonl')
  if (!existsSync(p)) return []
  return readFileSync(p, 'utf8').split('\n').filter((l) => l.trim()).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
}
const incRow = (intent, id) => ({
  ts: new Date().toISOString(),
  window: '（增量抽取）',
  process: '（增量抽取）',
  frameId: 'inc-' + id,
  textSha256: 'sha-inc-' + id,
  text: '（增量摘要，无关键词可用）',
  source: 'vision',
  structured: { app: '文档', intent, topic: '微电网调度', entities: ['微电网'] },
})
const NEUTRAL_FRAME = { imagePath: 'neutral.png', window: '记事本', process: 'notepad.exe' } // 关键词两表都不命中 → null

try {
  // ① 结构化 intent=学习 → line='work'（此前这条必然是 null）
  {
    const dir = mkDir('learn')
    writeInc(dir, [incRow('学习', 1)])
    const daily = createDailyPipeline({ router, extractor, dir })
    const r = await daily.run({ consentActive: true, frames: [NEUTRAL_FRAME], goal: 'g' })
    const row = trajRows(dir).find((x) => x.evidence && x.evidence.frameId === 'inc-1')
    check('D-1 ① 学习→work（增量行 line 落盘）', r.ok && row && row.line === 'work' && r.workScore === 1,
      `line=${row && row.line} workScore=${r.workScore} dims=${JSON.stringify(r.dims)}`, { dims: r.dims })
  }

  // ② 结构化 intent=娱乐 → line='life'
  {
    const dir = mkDir('fun')
    writeInc(dir, [incRow('娱乐', 2)])
    const daily = createDailyPipeline({ router, extractor, dir })
    const r = await daily.run({ consentActive: true, frames: [NEUTRAL_FRAME], goal: 'g' })
    const row = trajRows(dir).find((x) => x.evidence && x.evidence.frameId === 'inc-2')
    check('D-2 ② 娱乐→life（增量行 line 落盘）', r.ok && row && row.line === 'life' && r.lifeScore === 1,
      `line=${row && row.line} lifeScore=${r.lifeScore} dims=${JSON.stringify(r.dims)}`, { dims: r.dims })
  }

  // ③ 结构化 intent=其他 → line=null（不计数，计入未归类）
  {
    const dir = mkDir('other')
    writeInc(dir, [incRow('其他', 3)])
    const daily = createDailyPipeline({ router, extractor, dir })
    const r = await daily.run({ consentActive: true, frames: [NEUTRAL_FRAME], goal: 'g' })
    const row = trajRows(dir).find((x) => x.evidence && x.evidence.frameId === 'inc-3')
    const rep = readFileSync(r.reportPath, 'utf8')
    check('D-3 ③ 其他→null（不计数，进未归类）', r.ok && row && row.line === null && r.dims.unknown === 2 && rep.includes('未归类：2 条'),
      `line=${row && row.line} unknown=${r.dims.unknown} work=${r.workScore} life=${r.lifeScore}`, { dims: r.dims })
  }

  // ④ 两维都有 → 两维都计分 + 加权 total 可复算
  {
    const dir = mkDir('both')
    writeInc(dir, [incRow('学习', 4)])
    const daily = createDailyPipeline({ router, extractor, dir })
    const r = await daily.run({ consentActive: true, frames: [{ imagePath: 'life.png', window: 'Bilibili', process: 'chrome.exe' }], goal: 'g' })
    const expectTotal = Math.round(100 * (1 * r.weights.work + 1 * r.weights.life) / 2)
    const rep = readFileSync(r.reportPath, 'utf8')
    check('D-4 ④ 两维都有 → work/life 都计分 + total 加权可复算',
      r.ok && r.workScore === 1 && r.lifeScore === 1 && r.total === expectTotal && rep.includes('- workScore：1') && rep.includes('- lifeScore：1'),
      `work=${r.workScore} life=${r.lifeScore} total=${r.total}（期望 ${expectTotal}，权重 ${r.weights.work}/${r.weights.life}）`, { total: r.total })
  }

  // ⑤ 只有一维 → 该维计分、另一维 n/a + 报告标「单维」
  {
    const dir = mkDir('single')
    writeInc(dir, [incRow('学习', 5), incRow('学习', 6)])
    const daily = createDailyPipeline({ router, extractor, dir })
    const r = await daily.run({ consentActive: true, frames: [NEUTRAL_FRAME], goal: 'g' })
    const rep = readFileSync(r.reportPath, 'utf8')
    check('D-5 ⑤ 单维 → 另一维 n/a + 标「单维」',
      r.ok && r.workScore === 2 && r.lifeScore === 'n/a' && r.singleDim === 'work' && rep.includes('单维：work') && r.total === 100,
      `work=${r.workScore} life=${r.lifeScore} singleDim=${r.singleDim} total=${r.total}`, { singleDim: r.singleDim })
  }

  // ⑥ 两维都空 → 全 n/a，且不硬造 0
  {
    const dir = mkDir('none')
    writeInc(dir, [incRow('其他', 7)])
    const daily = createDailyPipeline({ router, extractor, dir })
    const r = await daily.run({ consentActive: true, frames: [NEUTRAL_FRAME], goal: 'g' })
    const rep = readFileSync(r.reportPath, 'utf8')
    check('D-6 ⑥ 两维都空 → 全 n/a（不写假 0）',
      r.ok && r.workScore === 'n/a' && r.lifeScore === 'n/a' && r.total === 'n/a' && rep.includes('workScore：n/a') && !/workScore：0(?!\d)/.test(rep),
      `work=${r.workScore} life=${r.lifeScore} total=${r.total} 报告含"workScore：0"=${/workScore：0(?!\d)/.test(rep)}`, {})
  }

  // ⑦ 兜底仍在：无结构化 intent 的抓帧行仍走关键词规则（向后兼容，不回归）
  {
    const dir = mkDir('fallback')
    const daily = createDailyPipeline({ router, extractor, dir })
    const r = await daily.run({ consentActive: true, frames: [{ imagePath: 'w.png', window: 'VSCode 微电网仿真', process: 'code.exe' }], goal: 'g' })
    const row = trajRows(dir)[0]
    check('D-7 ⑦ 关键词兜底仍在（无结构化 intent 的帧）', r.ok && row && row.line === 'work' && r.workScore === 1,
      `line=${row && row.line} window=${row && row.window}`, {})
    check('D-8 ⑧ 明确"其他"不兜底猜（不猜红线）',
      trackLine({ structuredIntent: '其他', window: 'VSCode 论文', process: 'code.exe' }) === null && intentLine('学习') === 'work' && intentLine('娱乐') === 'life' && intentLine('其他') === 'other' && intentLine('读论文') === null,
      `其他+VSCode→${trackLine({ structuredIntent: '其他', window: 'VSCode 论文', process: 'code.exe' })}；intentLine 学习/娱乐/其他/读论文=${intentLine('学习')}/${intentLine('娱乐')}/${intentLine('其他')}/${intentLine('读论文')}`, {})
  }
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.stack) || e))
}

try { rmSync(process.env.ORB_LOG_DIR, { recursive: true, force: true }); rmSync(process.env.ORB_DATA_DIR, { recursive: true, force: true }) } catch { /* 尽力 */ }
const pass = items.filter((i) => i.ok).length
mkdirSync(dataPath('logs'), { recursive: true })
writeFileSync(dataPath('logs', 's65-dualscore-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s65-dualscore: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(pass === items.length ? 0 : 1)
