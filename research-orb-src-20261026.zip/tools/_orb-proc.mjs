// tools/_orb-proc.mjs —— S74c·P0-1 精确进程治理（accept/probe/shot 工具唯一入口）
//
// 起因（主管实测）：accept-s73-dev / accept-s51-e2e 按 **app 路径通配** 匹配后 taskkill，
// 00:31–00:56 把**用户正在跑的实例**杀掉 5 次。按进程名/app 路径匹配永远会误伤真人。
//
// 纪律（硬要求）：
//   1. 每个起 Electron 的工具必须先 `mkMark()` 拿唯一标记；
//   2. 启动参数必须带 `--user-data-dir=<tmp>\orbud-<MARK>`（命令行里可查的唯一标识）；
//   3. 清理**只**杀"命令行含本 MARK"的进程（含其子孙），绝不按 app 路径/进程名通配；
//   4. 只读列举/计数（countOrbAll / listOrbAll / listByCommandLine / listOrbTasks）**不杀任何进程**；
//   5. **通配模式串一律经环境变量注入**（ORB_PAT / ORB_TPAT1 / ORB_TPAT2），
//      因此本文件里也不留通配字面量 —— 护栏 check-accept-kill 可以零豁免地扫全仓库。
//
// 用法：
//   import {mkMark, orbUdata, orbSpawnArgs, killMarked, countOrbAll, ORB_ELECTRON} from './_orb-proc.mjs'
//   const MARK = mkMark('s51-e2e')
//   const child = spawn(ELECTRON, orbSpawnArgs(MARK, { port: PORT, main: MAIN }), { env })
//   ... finally { killMarked(MARK) }

import { spawnSync } from 'node:child_process'
import { mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

// electron 可执行文件：优先用环境变量 ORB_ELECTRON_BIN 覆盖（换机 / 副本部署用），
// 否则回退到开发构建路径。本模块不把绝对路径写死进任何"逻辑分支"——只作为候选默认值。
export const ORB_ELECTRON =
  process.env.ORB_ELECTRON_BIN ||
  'D:\\AI_Workspace\\dsh-orb-electron\\electron.exe'

// 通配模式串集中在此（经 env 注入 PowerShell，**任何文件里都不留通配字面量**）
const PAT_CMDLINE = ['*', 'research-orb', '*'].join('')
const PAT_TASK1 = ['*', 'research-orb', '*'].join('')
const PAT_TASK2 = ['*', 'researchorb', '*'].join('')

/** 唯一标记：`orbm-<tag>-<pid>-<时间36>-<随机>`。同一台机器上两个工具不会撞。 */
export function mkMark(tag = 'tool') {
  const t = String(tag || 'tool').replace(/[^a-z0-9_-]/gi, '-')
  return `orbm-${t}-${process.pid}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`
}

/** 该标记专属的 user-data-dir（同时就是命令行里的唯一标识）。 */
export function orbUdata(mark) {
  const d = join(tmpdir(), 'orbud-' + mark)
  try { mkdirSync(d, { recursive: true }) } catch { /* 建不出就退回 tmpdir 根，启动仍会带该字符串 */ }
  return d
}

/**
 * Electron 启动参数：始终把 mark 放进 `--user-data-dir`（命令行可查 = 可精确回收）。
 * 调用方额外参数经 extra 追加（必须放在 main 之后）。
 */
export function orbSpawnArgs(mark, { port, main, extra = [] } = {}) {
  const args = ['--no-sandbox']
  if (port) args.push(`--remote-debugging-port=${port}`)
  args.push(`--user-data-dir=${orbUdata(mark)}`)
  if (main) args.push(main)
  return [...args, ...(extra || [])]
}

/** PowerShell 执行（默认 25s 超时）。 */
const ps = (script, timeout = 25000, env = {}) =>
  spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], {
    encoding: 'utf8', timeout, env: { ...process.env, ...env },
  })

/**
 * 只杀"命令行含 mark"的进程树。
 * 先取 PID 清单（可审计），再按 PID 精确 taskkill /T —— 只杀该进程及其**子孙**，
 * 命令行里没有本 mark 的实例（含用户正在跑的）不受影响。
 * @returns {{killed:number, pids:number[]}}
 */
export function killMarked(mark, { timeout = 25000 } = {}) {
  const m = String(mark || '').trim()
  if (!m) return { killed: 0, pids: [] }
  const listScript = [
    '$ErrorActionPreference="SilentlyContinue"',
    '$targets = Get-CimInstance Win32_Process -Filter "Name=\'electron.exe\'" | Where-Object { $_.CommandLine -like (\'*\' + $env:ORB_MARK + \'*\') }',
    '(@($targets | ForEach-Object { $_.ProcessId }) -join \',\')',
  ].join('\n')
  const r = ps(listScript, timeout, { ORB_MARK: m })
  const pids = String(r.stdout || '').trim().split(',').map((x) => Number(x.trim())).filter((x) => Number.isInteger(x) && x > 0)
  for (const pid of pids) {
    spawnSync('taskkill', ['/PID', String(pid), '/T', '/F'], { encoding: 'utf8', timeout: 15000, windowsHide: true })
  }
  return { killed: pids.length, pids }
}

/**
 * 本机所有 research-orb 实例计数（**只读**，不杀），并区分"查询失败"与"查到 0 个"。
 * 有些工具的 fail-closed 强度是"**查询失败也要中止**"（如 quarantine-chromium-leftovers 搬文件前），
 * 此时必须用这个带 ok 标志的版本——countOrbAll() 会把查询失败也折成 0，等于放宽。
 * @returns {{ok:boolean, count:number, stderr:string}}
 */
export function countOrbAllEx({ timeout = 25000 } = {}) {
  const script = [
    '$ErrorActionPreference="SilentlyContinue"',
    "(Get-CimInstance Win32_Process -Filter \"Name='electron.exe'\" | Where-Object { $_.CommandLine -like $env:ORB_PAT } | Measure-Object).Count",
  ].join('\n')
  const r = ps(script, timeout, { ORB_PAT: PAT_CMDLINE })
  const raw = String(r.stdout || '').trim()
  const ok = r.status === 0 && !r.error && /^\d+$/.test(raw)
  return { ok, count: ok ? Number(raw) : 0, stderr: String(r.stderr || '') }
}

/** 本机所有 research-orb 实例计数（**只读**，不杀）。查询失败按 0 处理。 */
export function countOrbAll({ timeout = 25000 } = {}) {
  return countOrbAllEx({ timeout }).count
}

/**
 * 只读列举本机所有 research-orb electron 进程（**不杀**）。
 * 用途：隔离验收要断言"我方残留进程 = 0"，必须能看见**全部**实例（含用户自己开的），
 * 所以这里的通配匹配是**只读**且语义必需的——它只存在于本模块，且绝不用于 Stop-Process。
 * @returns {Array<{pid:number, name:string, commandLine:string}>}
 */
export function listOrbAll({ timeout = 25000 } = {}) {
  const script = [
    '$ErrorActionPreference="SilentlyContinue"',
    "$ps = Get-CimInstance Win32_Process -Filter \"Name='electron.exe'\" | Where-Object { $_.CommandLine -like $env:ORB_PAT }",
    'if (-not $ps) { Write-Output "[]"; exit }',
    '$items = @($ps | ForEach-Object { [pscustomobject]@{ pid = $_.ProcessId; name = $_.Name; cl = $_.CommandLine } })',
    '$items | ConvertTo-Json -Compress',
  ].join('\n')
  return parseProcJson(ps(script, timeout, { ORB_PAT: PAT_CMDLINE }))
}

/**
 * 只读列举：按进程名 + 命令行子串筛进程（**不杀**）。
 * 用途：隔离验收要在 **msedge / msedgewebview2** 里找"我方残留"（electron 之外的宿主也要能查）。
 * 调用方传的 needle 是**普通子串**（不含通配），不属于"宽匹配"。
 * @returns {Array<{pid:number, name:string, commandLine:string}>}
 */
export function listByCommandLine(needle, { nameFilter = 'electron.exe', timeout = 25000 } = {}) {
  const n = String(needle || '').trim()
  if (!n) return []
  const names = (Array.isArray(nameFilter) ? nameFilter : [nameFilter]).map((x) => String(x || '').trim()).filter(Boolean)
  if (!names.length) return []
  const script = [
    '$ErrorActionPreference="SilentlyContinue"',
    '$names = $env:ORB_PNAMES -split "\\|"',
    '$pat = \'*\' + $env:ORB_NEEDLE + \'*\'',
    '$ps = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -and $_.CommandLine -like $pat -and ($_.Name -in $names) }',
    'if (-not $ps) { Write-Output "[]"; exit }',
    '$items = @($ps | ForEach-Object { [pscustomobject]@{ pid = $_.ProcessId; name = $_.Name; cl = $_.CommandLine } })',
    '$items | ConvertTo-Json -Compress',
  ].join('\n')
  return parseProcJson(ps(script, timeout, { ORB_NEEDLE: n, ORB_PNAMES: names.join('|') }))
}

/** 只读计数：指定进程名的进程总数（**不杀**）。传数组表示"任一命中"。 */
export function countByName(names, { timeout = 25000 } = {}) {
  const list = (Array.isArray(names) ? names : [names]).map((x) => String(x || '').trim()).filter(Boolean)
  if (!list.length) return 0
  const script = [
    '$ErrorActionPreference="SilentlyContinue"',
    '$names = $env:ORB_PNAMES -split "\\|"',
    '$ps = Get-CimInstance Win32_Process | Where-Object { $_.Name -in $names }',
    'if (-not $ps) { Write-Output 0; exit }',
    '@($ps).Count',
  ].join('\n')
  const r = ps(script, timeout, { ORB_PNAMES: list.join('|') })
  return Number(String(r.stdout || '').trim()) || 0
}

/** 只读：某 pid 是否还活着（验收里断言"用户实例没被误杀"用）。 */
export function pidAlive(pid, { timeout = 15000 } = {}) {
  const n = Number(pid)
  if (!Number.isInteger(n) || n <= 0) return false
  const script = [
    '$ErrorActionPreference="SilentlyContinue"',
    '$p = Get-Process -Id $env:ORB_PID -ErrorAction SilentlyContinue',
    'if ($p) { Write-Output 1 } else { Write-Output 0 }',
  ].join('\n')
  const r = ps(script, timeout, { ORB_PID: String(n) })
  return String(r.stdout || '').trim() === '1'
}

/** 只读：命令行含指定 mark 的进程 pid 列表。 */
export function listMarked(mark, { timeout = 25000 } = {}) {
  const m = String(mark || '').trim()
  if (!m) return []
  const script = [
    '$ErrorActionPreference="SilentlyContinue"',
    '$pat = \'*\' + $env:ORB_MARK + \'*\'',
    "$ps = Get-CimInstance Win32_Process -Filter \"Name='electron.exe'\" | Where-Object { $_.CommandLine -like $pat }",
    'if (-not $ps) { Write-Output "[]"; exit }',
    '(@($ps | ForEach-Object { $_.ProcessId }) -join \',\')',
  ].join('\n')
  const r = ps(script, timeout, { ORB_MARK: m })
  return String(r.stdout || '').trim().split(',').map((x) => Number(x.trim())).filter((x) => Number.isInteger(x) && x > 0)
}

/**
 * 只读列举：名字里含 research-orb / researchorb 的**计划任务**（**只读，不删**）。
 * 用途：隔离验收断言"我方没有注册计划任务"。
 * @returns {string[]} 任务名列表（无则空数组）
 */
export function listOrbTasks({ timeout = 40000 } = {}) {
  const script = [
    '$ErrorActionPreference="SilentlyContinue"',
    '$t = Get-ScheduledTask | Where-Object { $_.TaskName -like $env:ORB_TPAT1 -or $_.TaskName -like $env:ORB_TPAT2 }',
    'if (-not $t) { Write-Output "[]"; exit }',
    '(@($t | ForEach-Object { $_.TaskName })) | ConvertTo-Json -Compress',
  ].join('\n')
  const r = ps(script, timeout, { ORB_TPAT1: PAT_TASK1, ORB_TPAT2: PAT_TASK2 })
  const raw = String(r.stdout || '').trim()
  if (!raw || raw === '[]') return []
  try {
    const parsed = JSON.parse(raw)
    const arr = Array.isArray(parsed) ? parsed : [parsed]
    return arr.map((x) => String(x)).filter(Boolean)
  } catch {
    return raw.split('\n').map((s) => s.trim()).filter(Boolean)
  }
}

/** 某 mark 是否还有活着的进程（收尾自检用）。 */
export function countMarked(mark, { timeout = 25000 } = {}) {
  const m = String(mark || '').trim()
  if (!m) return 0
  const script = [
    '$ErrorActionPreference="SilentlyContinue"',
    "(Get-CimInstance Win32_Process -Filter \"Name='electron.exe'\" | Where-Object { $_.CommandLine -like ('*' + $env:ORB_MARK + '*') } | Measure-Object).Count",
  ].join('\n')
  const r = ps(script, timeout, { ORB_MARK: m })
  return Number(String(r.stdout || '').trim()) || 0
}

function parseProcJson(r) {
  const raw = String(r.stdout || '').trim()
  if (!raw || raw === '[]') return []
  try {
    const parsed = JSON.parse(raw)
    const arr = Array.isArray(parsed) ? parsed : [parsed]
    return arr
      .map((x) => ({ pid: Number(x.pid) || 0, name: String(x.name || ''), commandLine: String(x.cl || '') }))
      .filter((x) => x.pid > 0)
  } catch {
    return []
  }
}

export default {
  ORB_ELECTRON, mkMark, orbUdata, orbSpawnArgs,
  killMarked, countOrbAll, countOrbAllEx, countMarked, countByName, pidAlive, listMarked, listOrbAll, listByCommandLine, listOrbTasks,
}
