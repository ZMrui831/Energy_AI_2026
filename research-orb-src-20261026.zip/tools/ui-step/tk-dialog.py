# tk-dialog.py -- S42·B1 演示用标准对话框（自建进程，零用户数据；菜单栏+文本框+按钮）。
import sys, json, io, threading
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
import tkinter as tk
from tkinter import messagebox

mode = sys.argv[1] if len(sys.argv) > 1 else "editor"
root = tk.Tk()
root.title(mode + " - UIA演示记事本")
root.geometry("520x300")
mb = tk.Menu(root)
fm = tk.Menu(mb, tearoff=0)
fm.add_command(label="新建")
mb.add_cascade(label="文件(F)", menu=fm)
root.config(menu=mb)
tk.Label(root, text="演示记事本（自建进程，非系统记事本）").pack()
txt = tk.Text(root, height=8)
txt.pack(fill="both", expand=True)
status = {"closed": False, "canceled": False}

def on_close():
    if txt.get("1.0", "end").strip():
        ans = messagebox.askyesnocancel("保存", "是否保存更改？", parent=root)
        status["canceled"] = (ans is None)
        if ans is not True:
            root.destroy(); status["closed"] = True; return
    root.destroy(); status["closed"] = True

root.protocol("WM_DELETE_WINDOW", on_close)
tk.Button(root, text="取消", command=lambda: (status.update(canceled=True), root.destroy())).pack(side="bottom")
root.mainloop()
print(json.dumps(status, ensure_ascii=False))
