// tools/ui-step/ui-step.mjs
//
// S42·B1 computer use（方案 B）：白名单单步 + 可校验 + 可留证。每次单步强制六件：
//   ① 前台窗口一致性（不一致 → E_UI_NOT_FOREGROUND 拒）
//   ② 前后截图 → data/screens/ui-step/<ts>-{before|after}.png
//   ③ 白名单校验（窗口正则 + 控件名；外 → E_UI_NOT_WHITELISTED；deny 命中 → E_UI_DENIED_PATTERN）
//   ④ 10s 超时 → E_UI_TIMEOUT（中止不重试，由 uia.mjs 返回）
//   ⑤ 确认卡（三档权限 + describeRequest；人确认后才执行 → 未确认 E_UI_NOT_CONFIRMED）
//   ⑥ 审计 {ts,window,control,action,result,errorCode,shots[],durationMs}
import { spawnSync } from 'node:child_process'
import { existsSync, readFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { dataPath, appendJsonl, logPath, PROJECT_ROOT } from '../../packages/core/src/safefs.mjs'
import { uia } from './uia.mjs'

const WHITELIST_PATH = () => dataPath('ui-whitelist.json')
const SHOTS_DIR = () => dataPath('screens', 'ui-step')
const PY = process.env.RESEARCH_UI_PYTHON || `${process.env.USERPROFILE}\\.workbuddy\\binaries\\python\\versions\\3.13.12\\python.exe`

export function loadWhitelist() {
  try { return JSON.parse(readFileSync(WHITELIST_PATH(), 'utf8')) } catch { return { windows: [], denyPatterns: [], allowOnDialog: [] } }
}

function audit(rec) {
  try { appendJsonl(logPath('ui-step.jsonl'), { ts: new Date().toISOString(), ...rec }) } catch { /* 尽力 */ }
}

function shot(path) {
  try {
    mkdirSync(SHOTS_DIR(), { recursive: true })
    const r = spawnSync(PY, ['-c', `from PIL import ImageGrab; ImageGrab.grab().save(r'${path}')`], { encoding: 'utf8', timeout: 15000 })
    return r.status === 0 && existsSync(path)
  } catch { return false }
}

/** 匹配窗口白名单：fgName（真实前台标题）或调用方 windowRegex 任一命中即可；控件再过 allowed/deny。 */
export function checkWhitelist({ windowRegex, controlName, dialog = false, wl = loadWhitelist(), windowTitle = null }) {
  const title = windowTitle != null ? windowTitle : windowRegex
  const entry = (wl.windows || []).find((w) => {
    try { return new RegExp(w.titleRegex, 'i').test(title) } catch { return false }
  })
  if (!entry) {
    // 回退：调用方的目标正则本身能对上某条白名单（操作者显式指定目标）也算命中
    const fallback = (wl.windows || []).find((w) => { try { return new RegExp(windowRegex, 'i').test(w.titleRegex) || new RegExp(w.titleRegex, 'i').test(windowRegex) } catch { return false } })
    if (!fallback) return { ok: false, code: 'E_UI_NOT_WHITELISTED', reason: `窗口「${title}」不在白名单（允许：${(wl.windows || []).map((w) => w.titleRegex).join('、') || '无'}）` }
    return matchControls(fallback, controlName, dialog, wl, title)
  }
  return matchControls(entry, controlName, dialog, wl, title)
}

function matchControls(entry, controlName, dialog, wl, title) {
  if (controlName) {
    // 对话框例外优先：allowOnDialog 是显式策划的「安全放弃」按钮集合（不保存/否/取消/Don't Save）。
    // 「不保存」含子串「保存」——若先查 denyPatterns 会被误杀，丢弃动作永远点不了
    // （S66 对账实测：U-10 连续三次 E_UI_DENIED_PATTERN）。非对话框上下文仍走原优先级。
    const dialogHit = dialog && (wl.allowOnDialog || []).some((p) => controlName.includes(p))
    if (dialogHit) return { ok: true, entry }
    const denyHit = (wl.denyPatterns || []).find((p) => controlName.includes(p))
    if (denyHit) return { ok: false, code: 'E_UI_DENIED_PATTERN', reason: `控件「${controlName}」命中拒绝模式「${denyHit}」（保存/删除/发送/上传/支付/格式化/卸载 一律拒）` }
    if (!(entry.allowed || []).some((a) => controlName.includes(a))) {
      return { ok: false, code: 'E_UI_NOT_WHITELISTED', reason: `控件「${controlName}」不在窗口「${entry.titleRegex}」的允许列表（允许：${(entry.allowed || []).join('、')}）` }
    }
  }
  return { ok: true, entry }
}

/** 确认卡描述（人读）。 */
export function describeRequest({ action, windowRegex, controlName, text }) {
  return [
    '【UI 单步确认卡】',
    `- 动作：${action}`,
    `- 窗口：${windowRegex}`,
    controlName ? `- 控件：${controlName}` : null,
    text != null ? `- 写入内容：${String(text).slice(0, 80)}${String(text).length > 80 ? '…' : ''}` : null,
    '- 安全件：前台一致性 / 前后截图 / 白名单 / 10s 超时 / 本确认卡 / 审计留证',
    '- 不可逆操作（保存/删除/发送/上传/支付/格式化/卸载）永远拒绝。',
  ].filter(Boolean).join('\n')
}

/**
 * 执行一个 UI 单步（六件套全强制）。
 * @param {{action:'invoke'|'setText'|'close'|'list', windowRegex:string, controlName?:string, text?:string,
 *          confirmGranted?:boolean, dialog?:boolean, whitelistPath?:string}} input
 */
export function uiStep(input = {}, hooks = {}) {
  const t0 = Date.now()
  const { action, windowRegex, controlName = '', text, dialog = false } = input
  const ui = hooks._uia || ((cmd, a2) => uia(cmd, a2, { pid: input.pid ?? null }))
  const rec = { window: windowRegex, control: controlName, action, result: '', errorCode: null, shots: [], durationMs: 0 }

  // ⑤ 确认卡：未确认 → 拒（list 只读不需要确认）
  if (action !== 'list' && input.confirmGranted !== true) {
    rec.result = 'refused'; rec.errorCode = 'E_UI_NOT_CONFIRMED'; rec.durationMs = Date.now() - t0
    audit(rec)
    return { ok: false, code: 'E_UI_NOT_CONFIRMED', reason: '未获人工确认（确认卡未批准）', describe: describeRequest(input), audit: rec }
  }

  // ③ 白名单（白名单先于前台：未过白名单根本不激活窗口——零打扰拒绝）
  const wl = input.whitelistPath ? JSON.parse(readFileSync(input.whitelistPath, 'utf8')) : loadWhitelist()
  const wlCheck = checkWhitelist({ windowRegex, controlName, dialog, wl })
  if (!wlCheck.ok) {
    rec.result = 'refused'; rec.errorCode = wlCheck.code; rec.durationMs = Date.now() - t0
    audit(rec)
    return { ...wlCheck, audit: rec }
  }

  // ① 前台一致性（list 除外）
  if (action !== 'list') {
    const fg = ui('foreground', { '--title-regex': windowRegex })
    if (!fg.ok) { rec.result = 'refused'; rec.errorCode = fg.code || 'E_UI_FOCUS'; rec.durationMs = Date.now() - t0; audit(rec); return { ...fg, audit: rec } }
    if (fg.isForeground !== true) {
      rec.result = 'refused'; rec.errorCode = 'E_UI_NOT_FOREGROUND'; rec.durationMs = Date.now() - t0
      audit(rec)
      return { ok: false, code: 'E_UI_NOT_FOREGROUND', reason: `前台窗口不一致（前台 pid=${fg.fgPid}「${fg.fgName}」，目标 pid=${fg.wantPid}）——拒绝执行`, audit: rec }
    }
  }

  // ② 前后截图
  const stamp = new Date().toISOString().replace(/[:.]/g, '-')
  const beforeShot = join(SHOTS_DIR(), `${stamp}-before.png`)
  const afterShot = join(SHOTS_DIR(), `${stamp}-after.png`)
  const beforeOk = shot(beforeShot)
  rec.shots.push(beforeOk ? beforeShot : '(截图失败)')

  // 执行
  let r = null
  if (action === 'list') {
    r = ui('listWindows')
  } else if (action === 'invoke') {
    r = ui('invoke', { '--title-regex': windowRegex, '--control-name': controlName })
  } else if (action === 'setText') {
    r = ui('setText', { '--title-regex': windowRegex, '--control-name': controlName, '--text': String(text || '') })
  } else if (action === 'close') {
    r = ui('closeWindow', { '--title-regex': windowRegex })
  } else if (action === 'sendKeys') {
    r = ui('sendKeys', { '--title-regex': windowRegex, '--keys': String(text || '') })
  } else if (action === 'getValue') {
    r = ui('getValue', { '--title-regex': windowRegex, '--control-name': controlName })
  } else {
    r = { ok: false, code: 'E_USAGE', reason: '未知动作：' + action }
  }
  // ④ 超时由 uia 返回 E_UI_TIMEOUT（中止不重试）
  if (!r.ok && r.code === 'E_UI_TIMEOUT') {
    rec.result = 'timeout'; rec.errorCode = 'E_UI_TIMEOUT'; rec.durationMs = Date.now() - t0
    audit(rec)
    return { ...r, audit: rec }
  }

  const afterOk = shot(afterShot)
  rec.shots.push(afterOk ? afterShot : '(截图失败)')
  rec.result = r.ok ? 'executed' : 'failed'
  rec.errorCode = r.ok ? null : (r.code || 'E_UI_ACTION')
  rec.durationMs = Date.now() - t0
  audit(rec)
  return { ...r, shots: rec.shots.filter((s) => s !== '(截图失败)'), audit: rec }
}

/** /ui allow：加白名单窗口（二次确认 + 审计）。 */
export function uiAllow({ titleRegex, allowed = [], note = '', doubleConfirm = false }) {
  if (!titleRegex) return { ok: false, code: 'E_USAGE', reason: '用法：/ui allow <窗口标题正则> [允许控件,逗号分隔]' }
  if (doubleConfirm !== true) return { ok: false, code: 'E_CONFIRM_REQUIRED', reason: '二次确认：再次执行同命令并带 --yes 才会写入白名单（审计留行）' }
  const wl = loadWhitelist()
  if (!wl.windows.some((w) => w.titleRegex === titleRegex)) {
    wl.windows.push({ titleRegex, allowed, note })
  } else {
    const w = wl.windows.find((w) => w.titleRegex === titleRegex)
    w.allowed = [...new Set([...(w.allowed || []), ...allowed])]
  }
  mkdirSync(dataPath(), { recursive: true })
  const { writeFileSync } = require('node:fs')
  writeFileSync(WHITELIST_PATH(), JSON.stringify(wl, null, 2), 'utf8')
  audit({ action: 'allow', window: titleRegex, allowed })
  return { ok: true, text: `已加白：${titleRegex}（允许：${allowed.join('、') || '整窗'}）` }
}

/** /ui deny：移出白名单（审计）。 */
export function uiDeny({ titleRegex }) {
  const wl = loadWhitelist()
  const before = wl.windows.length
  wl.windows = wl.windows.filter((w) => w.titleRegex !== titleRegex)
  mkdirSync(dataPath(), { recursive: true })
  const fs = require('node:fs')
  fs.writeFileSync(WHITELIST_PATH(), JSON.stringify(wl, null, 2), 'utf8')
  audit({ action: 'deny', window: titleRegex, removed: before - wl.windows.length })
  return { ok: true, text: `已移出白名单：${titleRegex}` }
}

/** /ui list：列出当前窗口（只读，不需确认）。 */
export function uiList() {
  const r = uia('listWindows')
  if (!r.ok) return r
  const lines = r.windows.map((w) => `- [${w.type}] ${w.name}（${w.class}，pid=${w.pid}）`)
  return { ok: true, count: r.count, text: `当前窗口 ${r.count} 个：\n` + lines.join('\n') }
}

export default { uiStep, checkWhitelist, describeRequest, uiAllow, uiDeny, uiList, loadWhitelist }
