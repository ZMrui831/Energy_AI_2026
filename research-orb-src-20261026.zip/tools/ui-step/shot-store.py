# tools/ui-step/shot-store.py —— 截图落盘治理（S45·P2 第 2 条口径）
#
# 纠正过一次口径：**不是一律转 JPEG**。Pillow 13.0.0 实测 ——
#   · 纯色/大色块画面（1360×871）：PNG 5.3 KB vs JPEG q70 18.9 KB，JPEG 反而大 3.5 倍；
#   · 真实桌面截图：PNG 1.27 MB，JPEG 才有明显收益。
# 所以规则是 **双格式取小**：pngBuf 与 jpeg70Buf 都生成，谁小落谁，
# 后缀与 meta.format 如实记录；都不达标就在长边 1280 → 960 两档降采样后再比一轮。
#
# 用法：
#   python tools\ui-step\shot-store.py --src <tmp.png> --outdir <dir> --stem <name> [--maxkb 300]
#   python tools\ui-step\shot-store.py --src <tmp.png> --outdir <dir> --stem <name> --lossless   # 演示素材轨：PNG 原图
#
# stdout 最后一行 JSON：{"ok":true,"path":...,"format":"png|jpeg","bytes":N,
#                        "width":W,"height":H,"candidates":{"png":N,"jpeg":N},
#                        "downscaled":"none|1280|960","oversized":bool}

import argparse
import io
import json
import os
import sys
from datetime import datetime, timezone

from PIL import Image

MAX_KB_DEFAULT = 300
LONG_EDGE_STEPS = [1280, 960]


def read_bytes(path):
    with open(path, "rb") as f:
        return f.read()


def png_bytes(im):
    buf = io.BytesIO()
    im.save(buf, "PNG", optimize=True)
    return buf.getvalue()


def jpeg_bytes(im, quality=70):
    buf = io.BytesIO()
    im.convert("RGB").save(buf, "JPEG", quality=quality, optimize=True)
    return buf.getvalue()


def downscale(im, long_edge):
    w, h = im.size
    scale = min(1.0, float(long_edge) / float(max(w, h)))
    if scale >= 1.0:
        return im, False
    nw = max(1, int(round(w * scale)))
    nh = max(1, int(round(h * scale)))
    return im.resize((nw, nh), Image.LANCZOS), True


def pick_smaller(im):
    """同一张图：算 png/jpeg 两个候选，返回 (payload, format, candidates)。"""
    p_bytes = png_bytes(im)
    j_bytes = jpeg_bytes(im)
    cands = {"png": len(p_bytes), "jpeg": len(j_bytes)}
    if len(p_bytes) <= len(j_bytes):
        return p_bytes, "png", cands
    return j_bytes, "jpeg", cands


def main():
    ap = argparse.ArgumentParser(description="截图双格式取小落盘")
    ap.add_argument("--src", required=True, help="源 PNG（capture 出来的原始字节）")
    ap.add_argument("--outdir", required=True, help="落盘目录（由上层决定是留证轨还是演示轨）")
    ap.add_argument("--stem", required=True, help="文件名主干（不含后缀）")
    ap.add_argument("--maxkb", type=int, default=MAX_KB_DEFAULT, help="单张上限 KB")
    ap.add_argument("--lossless", action="store_true", help="演示素材轨：PNG 原图，不做压缩/降采样取舍")
    args = ap.parse_args()

    try:
        im = Image.open(args.src)
        im.load()
    except Exception as e:
        print(json.dumps({"ok": False, "error": f"cannot open source: {type(e).__name__}: {e}"}, ensure_ascii=False))
        return 2

    os.makedirs(args.outdir, exist_ok=True)

    # 演示素材轨：原图直落，不取舍
    if args.lossless:
        out = os.path.join(args.outdir, args.stem + ".png")
        with open(out, "wb") as f:
            f.write(read_bytes(args.src))
        print(json.dumps({
            "ok": True, "path": out, "format": "png", "bytes": os.path.getsize(out),
            "width": im.size[0], "height": im.size[1], "candidates": {"png": os.path.getsize(out), "jpeg": None},
            "downscaled": "none", "oversized": False, "lossless": True,
            "ts": datetime.now(timezone.utc).isoformat(),
        }, ensure_ascii=False))
        return 0

    budget = args.maxkb * 1024
    payload, fmt, cands = pick_smaller(im)
    downscaled = "none"
    if len(payload) > budget:
        for edge in LONG_EDGE_STEPS:
            small, changed = downscale(im, edge)
            if not changed:
                continue
            payload, fmt, cands = pick_smaller(small)
            downscaled = str(edge)
            im = small
            if len(payload) <= budget:
                break

    out = os.path.join(args.outdir, args.stem + "." + fmt)
    with open(out, "wb") as f:
        f.write(payload)

    print(json.dumps({
        "ok": True, "path": out, "format": fmt, "bytes": os.path.getsize(out),
        "width": im.size[0], "height": im.size[1], "candidates": cands,
        "downscaled": downscaled, "oversized": os.path.getsize(out) > budget, "lossless": False,
        "ts": datetime.now(timezone.utc).isoformat(),
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
