// tools/ui-step/uia.mjs —— S42·B1 Node↔UIA 桥：spawnSync 一次性 Python 调用（UTF-8、10s 超时、失败不重试、结构化 JSON）。
import { spawnSync } from 'node:child_process'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../../packages/core/src/safefs.mjs'

const BRIDGE = join(PROJECT_ROOT, 'tools', 'ui-step', 'uia-bridge.py')
const PY_CANDIDATES = [
  process.env.RESEARCH_UI_PYTHON || '',
  `${process.env.USERPROFILE}\\.workbuddy\\binaries\\python\\versions\\3.13.12\\python.exe`,
  'C:\\Program Files\\Python313\\python.exe',
].filter(Boolean)
let pyCache = null

function resolvePy() {
  if (pyCache) return pyCache
  for (const py of PY_CANDIDATES) {
    const r = spawnSync(py, ['-c', 'import uiautomation; print("ok")'], { encoding: 'utf8', timeout: 30000 })
    if (r.status === 0) { pyCache = py; return py }
  }
  return null
}

/**
 * 调 UIA 桥（一次一进程；失败不重试）。
 * @returns {{ok:boolean, code?:string, reason?:string, [k:string]:any}}
 */
export function uia(cmd, args = {}, { timeoutMs = 10000, pid = null } = {}) {
  const py = resolvePy()
  if (!py) return { ok: false, code: 'E_UIA_UNAVAILABLE', reason: '没有带 uiautomation 的 Python 解释器' }
  const argv = [BRIDGE, cmd]
  for (const [k, v] of Object.entries(args)) argv.push(k, String(v))
  if (pid != null) argv.push('--pid', String(pid))
  const r = spawnSync(py, argv, { encoding: 'utf8', timeout: timeoutMs, env: { ...process.env, PYTHONIOENCODING: 'utf-8' } })
  const line = String(r.stdout || '').trim().split('\n').filter(Boolean).pop()
  let parsed = null
  try { parsed = JSON.parse(line) } catch { parsed = null }
  if (!parsed) {
    if (r.signal === 'SIGTERM' || /ETIMEDOUT|timed out/i.test(String(r.error || ''))) {
      return { ok: false, code: 'E_UI_TIMEOUT', reason: `UIA 调用超时（>${timeoutMs}ms）：中止不重试` }
    }
    return { ok: false, code: 'E_UI_BRIDGE', reason: String(r.stderr || r.stdout || '无输出').slice(0, 160) }
  }
  return parsed
}

export default { uia }
