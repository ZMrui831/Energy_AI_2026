# uia-bridge.py -- S42·B1 UIA 桥（Python uiautomation，零新增 npm 依赖）。
#
# 用法（一次性进程，无驻留）：
#   python uia-bridge.py listWindows
#   python uia-bridge.py findWindow --title-regex "记事本"
#   python uia-bridge.py listControls --title-regex "记事本" [--max 40]
#   python uia-bridge.py invoke --title-regex "记事本" --control-name "文件(F)"
#   python uia-bridge.py setText --title-regex "记事本" --control-name "文本编辑器" --text "内容"
#   python uia-bridge.py closeWindow --title-regex "记事本"
#   python uia-bridge.py foreground --title-regex "记事本"
# Output: stdout 一行 JSON {"ok":true,...}；失败 {"ok":false,"code":"…","reason":"…"} exit 1。
# 纪律：UTF-8 输出；每次调用即退（零常驻）；不做任何白名单判断（那是 Node 层的职责）。

import io
import json
import sys
import time

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

try:
    import uiautomation as uia
except Exception as e:  # noqa: BLE001
    sys.stdout.write(json.dumps({"ok": False, "code": "E_UIA_UNAVAILABLE", "reason": str(e)[:160]}, ensure_ascii=False) + "\n")
    sys.exit(1)


def emit(obj, code=0):
    sys.stdout.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.exit(code)


def arg(name, default=None):
    if name in sys.argv:
        i = sys.argv.index(name)
        if i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return default


PID = None


def find_by_regex(rx, want_pid=None):
    import re
    pat = re.compile(rx or "")
    desktop = uia.GetRootControl()
    hits = []
    for w in desktop.GetChildren():
        name = w.Name or ""
        cls = w.ClassName or ""
        if want_pid is not None and w.ProcessId != want_pid:
            continue
        if pat.search(name) or pat.search(cls):
            hits.append(w)
    return hits


def win_info(w, depth=0):
    return {"name": (w.Name or "")[:60], "class": (w.ClassName or "")[:40], "type": str(w.ControlTypeName), "pid": w.ProcessId}


def ctrl_info(c, depth=0):
    return {"name": (c.Name or "")[:60], "type": str(c.ControlTypeName), "class": (c.ClassName or "")[:40], "depth": depth, "offscreen": bool(c.IsOffscreen)}


def walk(c, out, max_n, depth=0):
    if len(out) >= max_n or depth > 6:
        return
    for ch in c.GetChildren():
        out.append(ctrl_info(ch, depth))
        walk(ch, out, max_n, depth + 1)
        if len(out) >= max_n:
            return



def pick_visible(hits_ctrls):
    """多标签窗口：优先取非 offscreen 的控件（活动标签）。"""
    for c in hits_ctrls:
        try:
            if not c.IsOffscreen:
                return c
        except Exception:
            pass
    return hits_ctrls[0] if hits_ctrls else None


def find_controls(w, cname, max_depth=6):
    """按名/类收集全部匹配控件（供多标签挑可见者）。"""
    out = []
    for c, _ in uia.WalkControl(w, includeTop=False, maxDepth=max_depth):
        if (c.Name or "") == cname or (c.ClassName or "") == cname:
            out.append(c)
    return out


def main():
    global PID
    cmd = sys.argv[1] if len(sys.argv) > 1 else ""
    PID = int(arg("--pid")) if arg("--pid") else None
    try:
        if cmd == "listWindows":
            desktop = uia.GetRootControl()
            wins = [win_info(w) for w in desktop.GetChildren()]
            emit({"ok": True, "count": len(wins), "windows": wins})

        elif cmd == "findWindow":
            rx = arg("--title-regex", "")
            hits = find_by_regex(rx)
            if not hits:
                emit({"ok": False, "code": "E_UI_WINDOW_NOT_FOUND", "reason": f"未匹配窗口：{rx}"}, 1)
            emit({"ok": True, "count": len(hits), "windows": [win_info(w) for w in hits[:5]]})

        elif cmd == "foreground":
            rx = arg("--title-regex", "")
            hits = find_by_regex(rx)
            if not hits:
                emit({"ok": False, "code": "E_UI_WINDOW_NOT_FOUND", "reason": f"未匹配窗口：{rx}"}, 1)
            w = hits[0]
            try:
                w.SetActive()
                w.SetFocus()
            except Exception as e:  # noqa: BLE001
                emit({"ok": False, "code": "E_UI_FOCUS", "reason": str(e)[:120]}, 1)
            time.sleep(0.4)
            fg = uia.GetForegroundControl()
            if fg is None:
                emit({"ok": True, "isForeground": False, "fgPid": -1, "wantPid": w.ProcessId, "fgName": "(无前台窗口)"})
            same = fg.ProcessId == w.ProcessId
            fg_name = (fg.Name or "") or (w.Name or "")
            emit({"ok": True, "isForeground": bool(same), "fgPid": fg.ProcessId, "wantPid": w.ProcessId, "fgName": fg_name[:60]})

        elif cmd == "listControls":
            rx = arg("--title-regex", "")
            max_n = int(arg("--max", "40"))
            hits = find_by_regex(rx)
            if not hits:
                emit({"ok": False, "code": "E_UI_WINDOW_NOT_FOUND", "reason": f"未匹配窗口：{rx}"}, 1)
            out = []
            walk(hits[0], out, max_n)
            emit({"ok": True, "count": len(out), "controls": out})

        elif cmd == "invoke":
            rx = arg("--title-regex", "")
            cname = arg("--control-name", "")
            hits = find_by_regex(rx)
            if not hits:
                emit({"ok": False, "code": "E_UI_WINDOW_NOT_FOUND", "reason": f"未匹配窗口：{rx}"}, 1)
            w = hits[0]
            try:
                w.SetActive()
            except Exception:
                pass
            time.sleep(0.3)
            target = pick_visible(find_controls(w, cname))
            if target is None:
                emit({"ok": False, "code": "E_UI_CONTROL_NOT_FOUND", "reason": f"控件不存在：{cname}"}, 1)
            last_err = None
            done = False
            for attempt in ("invoke", "expand", "click"):
                try:
                    if attempt == "invoke":
                        target.GetInvokePattern().Invoke()
                    elif attempt == "expand":
                        target.GetExpandCollapsePattern().ExpandCollapse()
                    else:
                        rect = target.BoundingRectangle
                        target.Click(simulateMove=False, x=int(rect.width() / 2), y=int(rect.height() / 2)) if hasattr(rect, "width") and callable(getattr(rect, "width", None)) else target.Click(simulateMove=False)
                    done = True
                    break
                except Exception as e:  # noqa: BLE001
                    last_err = e
            if not done:
                emit({"ok": False, "code": "E_UI_INVOKE", "reason": (str(last_err)[:120] if last_err else "全部模式失败")}, 1)
            emit({"ok": True, "invoked": cname, "pattern": attempt})

        elif cmd == "setText":
            rx = arg("--title-regex", "")
            cname = arg("--control-name", "")
            text = arg("--text", "")
            hits = find_by_regex(rx)
            if not hits:
                emit({"ok": False, "code": "E_UI_WINDOW_NOT_FOUND", "reason": f"未匹配窗口：{rx}"}, 1)
            w = hits[0]
            target = pick_visible(find_controls(w, cname))
            if target is None:
                emit({"ok": False, "code": "E_UI_CONTROL_NOT_FOUND", "reason": f"控件不存在：{cname}"}, 1)
            try:
                try:
                    target.GetValuePattern().SetValue(text)
                except Exception:
                    w.SetActive()
                    target.SetFocus()
                    time.sleep(0.2)
                    uia.SendKeys("{Ctrl}a", waitTime=0.1)
                    uia.SendKeys("{Delete}", waitTime=0.1)
                    uia.SendKeys(text, waitTime=0.05)
            except Exception as e:  # noqa: BLE001
                emit({"ok": False, "code": "E_UI_SETTEXT", "reason": str(e)[:120]}, 1)
            emit({"ok": True, "setText": cname, "chars": len(text)})

        elif cmd == "getValue":
            rx = arg("--title-regex", "")
            cname = arg("--control-name", "")
            hits = find_by_regex(rx)
            if not hits:
                emit({"ok": False, "code": "E_UI_WINDOW_NOT_FOUND", "reason": f"未匹配窗口：{rx}"}, 1)
            target = pick_visible(find_controls(hits[0], cname))
            if target is None:
                emit({"ok": False, "code": "E_UI_CONTROL_NOT_FOUND", "reason": f"控件不存在：{cname}"}, 1)
            val = ""
            try:
                val = target.GetValuePattern().Value
            except Exception:
                try:
                    val = target.Name or ""
                except Exception:
                    val = ""
            emit({"ok": True, "value": str(val)[:2000]})

        elif cmd == "sendKeys":
            rx = arg("--title-regex", "")
            keys = arg("--keys", "")
            hits = find_by_regex(rx)
            if not hits:
                emit({"ok": False, "code": "E_UI_WINDOW_NOT_FOUND", "reason": f"未匹配窗口：{rx}"}, 1)
            try:
                hits[0].SetActive()
                time.sleep(0.3)
                uia.SendKeys(keys, waitTime=0.2)
            except Exception as e:  # noqa: BLE001
                emit({"ok": False, "code": "E_UI_SENDKEYS", "reason": str(e)[:120]}, 1)
            emit({"ok": True, "keys": keys})

        elif cmd == "closeWindow":
            rx = arg("--title-regex", "")
            hits = find_by_regex(rx)
            if not hits:
                emit({"ok": True, "closed": False, "reason": "窗口已不存在"})
            try:
                hits[0].SendKeys("{Alt}F4")
                time.sleep(0.5)
                remaining = find_by_regex(rx)
                emit({"ok": True, "closed": len(remaining) == 0, "remaining": len(remaining)})
            except Exception as e:  # noqa: BLE001
                emit({"ok": False, "code": "E_UI_CLOSE", "reason": str(e)[:120]}, 1)

        else:
            emit({"ok": False, "code": "E_USAGE", "reason": f"未知命令：{cmd}"}, 1)
    except Exception as e:  # noqa: BLE001
        emit({"ok": False, "code": "E_UI_BRIDGE", "reason": str(e)[:160]}, 1)


if __name__ == "__main__":
    main()
