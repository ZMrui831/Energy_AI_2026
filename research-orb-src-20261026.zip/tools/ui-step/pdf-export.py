# tools/ui-step/pdf-export.py -- S42·B2 结论导出 PDF（reportlab + CID 中文字体，零新增 npm 依赖）。
#
# 用法：python pdf-export.py <payload.json>
#   payload: {"out": "<abs>.pdf", "title": "…", "body": [{"h2": "…"}, {"p": "…"}, {"table": [[..],[..]]}], "footer": "…"}
# Output: 写 PDF；stdout {"ok":true,"pages":N}；失败 {"ok":false,"reason":"…"} exit 1。
import io
import json
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

try:
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib import colors
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.cidfonts import UnicodeCIDFont
except Exception as e:  # noqa: BLE001
    sys.stdout.write(json.dumps({"ok": False, "code": "E_PDF_UNAVAILABLE", "reason": str(e)[:160]}, ensure_ascii=False) + "\n")
    sys.exit(1)


def main():
    payload = json.loads(open(sys.argv[1], encoding="utf-8").read())
    out = payload["out"]
    try:
        pdfmetrics.registerFont(UnicodeCIDFont("STSong-Light"))  # 内置 CID 中文字体，零字体文件依赖
    except Exception as e:  # noqa: BLE001
        sys.stdout.write(json.dumps({"ok": False, "reason": "CID 字体注册失败：" + str(e)[:120]}, ensure_ascii=False) + "\n")
        sys.exit(1)

    styles = getSampleStyleSheet()
    h1 = ParagraphStyle("h1", parent=styles["Heading1"], fontName="STSong-Light", fontSize=16)
    h2 = ParagraphStyle("h2", parent=styles["Heading2"], fontName="STSong-Light", fontSize=13)
    body = ParagraphStyle("body", parent=styles["BodyText"], fontName="STSong-Light", fontSize=10.5, leading=16)
    foot = ParagraphStyle("foot", parent=styles["BodyText"], fontName="STSong-Light", fontSize=8, textColor=colors.grey)

    def esc(s):
        return str(s).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    story = [Paragraph(esc(payload.get("title", "结论导出")), h1), Spacer(1, 10)]
    pages_holder = {"n": 0}

    def on_page(canvas, doc):
        pages_holder["n"] += 1
        footer = payload.get("footer", "")
        if footer:
            canvas.setFont("STSong-Light", 8)
            canvas.setFillGray(0.4)
            canvas.drawString(50, 28, footer[:180])
            canvas.drawRightString(545, 28, f"第 {pages_holder['n']} 页")

    for block in payload.get("body", []):
        if "h2" in block:
            story.append(Paragraph(esc(block["h2"]), h2))
        elif "p" in block:
            story.append(Paragraph(esc(block["p"]), body))
        elif "table" in block:
            rows = [[Paragraph(esc(str(c)), body) for c in row] for row in block["table"]]
            t = Table(rows, hAlign="LEFT")
            t.setStyle(TableStyle([
                ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
                ("BACKGROUND", (0, 0), (-1, 0), colors.Color(0.9, 0.93, 0.95)),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]))
            story.append(t)
        story.append(Spacer(1, 6))
    story.append(Spacer(1, 16))
    story.append(Paragraph(esc(payload.get("footer", "")), foot))

    doc = SimpleDocTemplate(out, pagesize=A4, leftMargin=50, rightMargin=50, topMargin=50, bottomMargin=46)
    doc.build(story, onFirstPage=on_page, onLaterPages=on_page)
    import os
    if not os.path.exists(out) or os.path.getsize(out) < 500:
        sys.stdout.write(json.dumps({"ok": False, "reason": "PDF 未产出或过小"}, ensure_ascii=False) + "\n")
        sys.exit(1)
    sys.stdout.write(json.dumps({"ok": True, "pages": pages_holder["n"], "bytes": os.path.getsize(out)}, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
