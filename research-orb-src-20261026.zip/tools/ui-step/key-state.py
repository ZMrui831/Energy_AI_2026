# tools/ui-step/key-state.py —— 修饰键状态探针（P-044 五条断言的工具）
#
# 为什么需要它： computer use 一旦发真键鼠事件，"Ctrl/Alt 卡住不释放"是会把人桌面
# 拖死的事故 —— 表现为之后所有点击都变成多选、拖动窗口变成复制。backend 内部虽然
# 配对 down/up，但**中途 abort / 异常 / 进程退出**这三条路径是否在 finally 里释放，
# 必须由操作系统层面来回答，不能由我们自己声明。
#
# 用法：
#   python tools\ui-step\key-state.py              # 只读：输出 5 个修饰键状态
#   python tools\ui-step\key-state.py --release    # 修复：对仍按下的键补发 KEYUP（唯一允许的写操作）
#
# 输出（stdout 最后一行是 JSON）：
#   {"ok":true,"pressed":{...},"stuck":[...],"released":[...],"ts":"..."}
#
# 纪律：默认只读；--release 只在检测到 stuck 时由上层显式调用（并必须落审计）。

import argparse
import ctypes
import json
import sys
from datetime import datetime, timezone

USER32 = ctypes.windll.user32

KEYEVENTF_KEYUP = 0x0002
MODIFIERS = [
    ("ctrl", 0x11),   # VK_CONTROL
    ("shift", 0x10),  # VK_SHIFT
    ("alt", 0x12),    # VK_MENU
    ("lwin", 0x5B),   # VK_LWIN
    ("rwin", 0x5C),   # VK_RWIN
]


def read_state():
    """读一次当前状态。位 15（0x8000）置位 = 当前按下。"""
    return {name: bool(USER32.GetAsyncKeyState(vk) & 0x8000) for name, vk in MODIFIERS}


def release_stuck(state):
    """对仍按下的键补发一个 KEYUP。这是**修复性**输入，不是普通操作。"""
    released = []
    for name, vk in MODIFIERS:
        if state.get(name):
            USER32.keybd_event(vk, 0, KEYEVENTF_KEYUP, 0)
            released.append(name)
    return released


def main():
    ap = argparse.ArgumentParser(description="修饰键状态探针（只读 / --release 释放）")
    ap.add_argument("--release", action="store_true", help="对仍按下的修饰键补发 KEYUP")
    args = ap.parse_args()

    before = read_state()
    stuck = [k for k, v in before.items() if v]
    released = []
    if args.release and stuck:
        released = release_stuck(before)
        after = read_state()
        still = [k for k, v in after.items() if v]
        payload = {
            "ok": True,
            "pressed": before,
            "stuck": stuck,
            "released": released,
            "stillStuckAfterRelease": still,
            "state": after,
            "ts": datetime.now(timezone.utc).isoformat(),
        }
    else:
        payload = {
            "ok": True,
            "pressed": before,
            "stuck": stuck,
            "released": released,
            "state": before,
            "ts": datetime.now(timezone.utc).isoformat(),
        }

    print(json.dumps(payload, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
