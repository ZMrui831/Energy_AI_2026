// tools/shot.mjs —— CDP 截图工具（开发/取证用）
//
// 前置：已经有一个带 --remote-debugging-port 的 electron 在跑（见 start-dev.cmd）。
// 用法：
//   node tools\shot.mjs data\shots\x.png --expand --wait 1500
//   node tools\shot.mjs data\shots\x.png --eval "document.title" --wait 300
//   node tools\shot.mjs data\shots\x.png --script tools\probe.js --wait 800
//
// 只写项目根内的文件；连不上就报错退出，不做任何重试轰炸。

import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, resolve } from 'node:path'

const args = process.argv.slice(2)
const out = args[0]
if (!out) {
  process.stderr.write('usage: node tools/shot.mjs <out.png> [--expand] [--eval JS] [--script FILE] [--wait MS] [--port N] [--keep]\n')
  process.exit(2)
}

const flag = (name, fallback = null) => {
  const i = args.indexOf(name)
  return i >= 0 && args[i + 1] !== undefined ? args[i + 1] : fallback
}
const has = (name) => args.includes(name)

const PORT = Number(flag('--port', '9333'))
const WAIT = Number(flag('--wait', '1200'))
const EXPAND = has('--expand')
const KEEP = has('--keep')
const EVAL = flag('--eval', null)
const SCRIPT = flag('--script', null)

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

async function findTarget() {
  for (let i = 0; i < 40; i += 1) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await res.json()
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl)
      if (page) return page
    } catch {
      /* 还没起来 */
    }
    await sleep(250)
  }
  throw new Error(`CDP 目标未找到（port ${PORT}）`)
}

function connect(url) {
  return new Promise((res, rej) => {
    const ws = new WebSocket(url)
    let seq = 0
    const pending = new Map()
    ws.addEventListener('open', () =>
      res({
        send(method, params = {}) {
          const id = ++seq
          return new Promise((ok, no) => {
            pending.set(id, { ok, no })
            ws.send(JSON.stringify({ id, method, params }))
          })
        },
        close: () => ws.close(),
      }),
    )
    ws.addEventListener('error', (e) => rej(new Error(`ws error: ${e && e.message}`)))
    ws.addEventListener('message', (ev) => {
      let msg = null
      try {
        msg = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data))
      } catch {
        return
      }
      const p = pending.get(msg.id)
      if (!p) return
      pending.delete(msg.id)
      if (msg.error) p.no(new Error(JSON.stringify(msg.error)))
      else p.ok(msg.result)
    })
  })
}

async function main() {
  const target = await findTarget()
  const cdp = await connect(target.webSocketDebuggerUrl)
  await cdp.send('Page.enable')
  await cdp.send('Runtime.enable')

  const logs = []
  if (EXPAND) {
    await cdp.send('Runtime.evaluate', {
      expression: `(function(){ try { globalThis.researchOrb.send('window',{action:'expand'}); return 'expand-sent' } catch(e){ return 'expand-failed:'+e.message } })()`,
      returnByValue: true,
    })
  }

  const script = SCRIPT ? readFileSync(resolve(SCRIPT), 'utf8') : EVAL
  if (script) {
    const r = await cdp.send('Runtime.evaluate', {
      expression: `(async function(){ ${script} })()`,
      awaitPromise: true,
      returnByValue: true,
    })
    if (r && r.result) logs.push(JSON.stringify(r.result.value !== undefined ? r.result.value : r.result))
    if (r && r.exceptionDetails) logs.push('EXCEPTION: ' + JSON.stringify(r.exceptionDetails.exception && r.exceptionDetails.exception.description))
  }

  await sleep(WAIT)

  const shot = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
  const data = shot && shot.data ? shot.data : shot && shot.result && shot.result.data
  if (!data) throw new Error('截图失败：CDP 未返回 data')

  const abs = resolve(out)
  mkdirSync(dirname(abs), { recursive: true })
  writeFileSync(abs, Buffer.from(data, 'base64'))
  process.stdout.write(`shot: ${abs} (${Buffer.from(data, 'base64').length} bytes)\n`)
  if (logs.length > 0) process.stdout.write('eval: ' + logs.join(' | ') + '\n')
  if (!KEEP) cdp.close()
  process.exit(0)
}

main().catch((err) => {
  process.stderr.write('shot failed: ' + (err && err.message ? err.message : err) + '\n')
  process.exit(1)
})
