// 汇总 Temp 里各验收脚本今日最新证据的 pass/total
import { readdirSync, readFileSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { tmpdir } from 'node:os'

const dirs = readdirSync(tmpdir()).filter((d) => /-data-\d+$/.test(d))
const latest = new Map()
for (const d of dirs) {
  const logsDir = join(tmpdir(), d, 'logs')
  if (!existsSync(logsDir)) continue
  for (const f of readdirSync(logsDir)) {
    if (!f.endsWith('-accept.json')) continue
    const p = join(logsDir, f)
    const key = f.replace('-accept.json', '')
    const ts = Number((d.match(/-data-(\d+)$/) || [])[1] || 0)
    if (!latest.has(key) || latest.get(key).ts < ts) latest.set(key, { ts, p })
  }
}
const rows = [...latest.entries()].sort((a, b) => b[1].ts - a[1].ts)
const today = Date.now() - 14 * 3600 * 1000
for (const [key, v] of rows) {
  if (v.ts < today) continue
  let j = null
  try { j = JSON.parse(readFileSync(v.p, 'utf8')) } catch {}
  if (!j || typeof j.pass !== 'number') { console.log(`${key}: (结构不同) ${v.p}`); continue }
  const when = new Date(v.ts).toISOString().slice(5, 16).replace('T', ' ')
  console.log(`${key}: pass=${j.pass}/${j.total} @${when}Z`)
}
