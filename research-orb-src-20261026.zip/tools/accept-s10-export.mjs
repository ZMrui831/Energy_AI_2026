// tools/accept-s10-export.mjs —— S10 镜 4 后半验收：结论导出（md + docx）。
//
// 独立性（CONTRACT §7）：独立子进程 + 独立夹具库（data/db/s10-export-*/）；
// 导出走**真实插件命令**（/claim export，经 registry runCommand + lifecycle 桥），
// 不直接调用导出组装函数；docx 落盘后解包 OOXML 验证内容（zip 中央目录 + document.xml 文本）。
//
// 单行复跑：node tools/run-isolated.mjs --label s10 --cmd "node tools/accept-s10-export.mjs"

import './_accept-isolate.mjs' // S67·3-A：先于产品模块求值，把 data/logs 指到临时目录
import { mkdirSync, mkdtempSync, writeFileSync, readFileSync, existsSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { createHash } from 'node:crypto'
import { inflateSync, inflateRawSync } from 'node:zlib'

import { PROJECT_ROOT, logPath, dataPath } from '../packages/core/src/safefs.mjs'
import { createStore } from '../packages/core/src/db.mjs'

const sha = (p) => createHash('sha256').update(readFileSync(p)).digest('hex')
const items = []
function report(id, clause, ok, detail, evidence = {}) {
  items.push({ id, clause, ok: !!ok, detail, evidence })
  console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`)
}

/** 从 .docx（zip）里取出 word/document.xml 的纯文本（零依赖：手工解中央目录 + inflate）。 */
function docxText(buf) {
  // 找 EOCD（0x06054b50）→ 中央目录条目里 name='word/document.xml' 的压缩字节 → inflate
  let eocd = -1
  for (let i = buf.length - 22; i >= 0; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break }
  }
  if (eocd < 0) return null
  const cdOffset = buf.readUInt32LE(eocd + 16)
  let p = cdOffset
  while (p < buf.length - 4 && buf.readUInt32LE(p) === 0x02014b50) {
    const nameLen = buf.readUInt16LE(p + 28)
    const extraLen = buf.readUInt16LE(p + 30)
    const commentLen = buf.readUInt16LE(p + 32)
    const localOff = buf.readUInt32LE(p + 42)
    const name = buf.toString('utf8', p + 46, p + 46 + nameLen)
    if (name === 'word/document.xml') {
      const lNameLen = buf.readUInt16LE(localOff + 26)
      const lExtraLen = buf.readUInt16LE(localOff + 28)
      const compMethod = buf.readUInt16LE(localOff + 8)
      const start = localOff + 30 + lNameLen + lExtraLen
      // 数据大小：中央目录的 compressed size（p+20）
      const compSize = buf.readUInt32LE(p + 20)
      const comp = buf.subarray(start, start + compSize)
      // method 0 = stored（原样）；method 8 = raw deflate（RFC1951，需 inflateRaw）
      const raw = compMethod === 0 ? comp : inflateRawSync(comp)
      // 抽 <w:t> 文本
      const xml = raw.toString('utf8')
      const texts = []
      const re = /<w:t[^>]*>([\s\S]*?)<\/w:t>/g
      let m
      while ((m = re.exec(xml)) !== null) texts.push(m[1])
      return texts.join('')
    }
    p += 46 + nameLen + extraLen + commentLen
  }
  return null
}

async function main() {
  mkdirSync(dataPath('db'), { recursive: true })
  const dir = mkdtempSync(join(dataPath('db'), 's10-export-'))
  const store = await createStore({ driver: 'sqlite', dbPath: join(dir, 'orb.sqlite'), dataDir: dir })
  store.initMigrations()

  // 两条证据：一条可用（文件在盘）、一条已删（status=deleted，文件不在）
  const shotA = join(dir, 'a.png')
  writeFileSync(shotA, 'PNG-A-CONTENT')
  const shaA = createHash('sha256').update('PNG-A-CONTENT').digest('hex')
  store.insertRawFrame({ id: 'rf-exp-a', file_path: shotA, sha256: shaA, sensitivity: 'normal', created_at: new Date().toISOString(), expires_at: new Date(Date.now() + 3600_000).toISOString() })
  store.insertRawFrame({ id: 'rf-exp-b', file_path: join(dir, 'gone.png'), sha256: 'e'.repeat(64), sensitivity: 'normal', created_at: new Date().toISOString(), expires_at: new Date().toISOString() })
  store.setRawFrameStatus('rf-exp-b', 'deleted')

  // 真实插件命令路径：registry + lifecycle 桥（与宿主一致）
  const { createRegistry } = await import('../packages/plugins/registry.mjs')
  const reg = createRegistry({ core: {} })
  reg.scan()
  await reg.enable('timeline')
  globalThis.__researchRegistry = reg
  globalThis.researchOrbLifecycle = {
    store,
    computeExpiry: (s, m) => (m === 'learning' ? new Date(Date.now() + 20 * 60_000).toISOString() : new Date(Date.now() + 6 * 3600_000).toISOString()),
    insertRawFrame: (f) => store.insertRawFrame(f),
  }

  const created = await reg.runCommand('claim', 'new frame rf-exp-a')
  const claimId = created.value && created.value.ui && created.value.ui.claimId
  await reg.runCommand('claim', `attach ${claimId} frame rf-exp-b`)
  const pub = await reg.runCommand('claim', `publish ${claimId}`)
  report('S10-E0', 'CONTRACT §6 前置：草稿经真实命令发布（双证据：1 可用 + 1 已删）',
    !!claimId && pub.value && pub.value.ok,
    `claimId=${claimId}；publish ok=${pub.value && pub.value.ok}（证据 ${pub.value && pub.value.evidenceCount} 条）`,
    { claimId, publish: pub.value })

  const ex = await reg.runCommand('claim', `export ${claimId}`)
  const ui = ex.value && ex.value.ui
  const mdText = ui && ui.md && existsSync(ui.md) ? readFileSync(ui.md, 'utf8') : ''
  const mdOk = !!ui && !!ui.md && existsSync(ui.md)
  const docxOk = !!ui && !!ui.docx && existsSync(ui.docx)
  const docxBody = docxOk ? docxText(readFileSync(ui.docx)) : null

  const checks = [
    ['md 存在', mdOk],
    ['docx 存在（复用既有 docx 能力）', docxOk],
    ['md 含 evidence_id rf-exp-a 与 rf-exp-b', /rf-exp-a/.test(mdText) && /rf-exp-b/.test(mdText)],
    ['md 含当前可用性：可用 + 已删', /\| 可用 \|/.test(mdText) && /\| 已删 \|/.test(mdText)],
    ['md 含三档标签（直接证据）', /直接证据/.test(mdText)],
    ['md 含固定降级文案（已删证据）', /原图已按保留策略删除；保留时间、窗口、摘要与内容哈希，无法恢复画面。/.test(mdText)],
    ['md 含导出时间与产品版本', /导出时间：/.test(mdText) && /产品版本：research-orb s10/.test(mdText)],
    ['docx 正文含 evidence_id 与降级文案', !!docxBody && /rf-exp-a/.test(docxBody) && /rf-exp-b/.test(docxBody) && /原图已按保留策略删除/.test(docxBody)],
    ['docx 正文含导出时间/版本/档位', !!docxBody && /导出时间/.test(docxBody) && /s10/.test(docxBody) && /直接证据/.test(docxBody)],
  ]
  const allOk = checks.every(([, ok]) => ok)
  report('S10-E1', 'CONTRACT §6/§7 导出内容完整（md+docx：正文/evidence_id/可用性/档位/降级文案/时间/版本）',
    allOk,
    checks.map(([label, ok]) => `${ok ? '✓' : '✗'}${label}`).join('；'),
    { checks: checks.map(([label, ok]) => ({ label, ok })), md: ui && ui.md, docx: ui && ui.docx, mdSha256: ui && ui.mdSha256, docxSha256: ui && ui.docxSha256, docxBytes: docxOk ? readFileSync(ui.docx).length : null, docxError: ui && ui.docxError })

  // 未发布结论不得导出
  const draft = await reg.runCommand('claim', 'new text 未发布草稿不得导出')
  const draftId = draft.value && draft.value.ui && draft.value.ui.claimId
  const bad = await reg.runCommand('claim', `export ${draftId}`)
  report('S10-E2', 'CONTRACT §6 未过证据闸的结论不得导出', bad.value && bad.value.ok === false && bad.value.code === 'E_NOT_PUBLISHED',
    `导出被拒：code=${bad.value && bad.value.code}`, { code: bad.value && bad.value.code })

  store.close()
  try { rmSync(dir, { recursive: true, force: true }) } catch { /* noop */ }
  // 导出到 data/exports 的验收文件清走（run-isolated 快照不含该目录；显式申报）
  const cleaned = []
  for (const p of [ui && ui.md, ui && ui.docx]) {
    if (p && existsSync(p)) { try { rmSync(p, { force: true }); cleaned.push(p) } catch { /* noop */ } }
  }

  const out = {
    label: 's10-claim-export',
    ts: new Date().toISOString(),
    verdict: items.every((i) => i.ok) ? 'accept' : 'reject',
    preState: { fixture: `独立夹具库 ${dir}（已清理）`, exportsCleaned: cleaned },
    rerun: 'node tools/run-isolated.mjs --label s10 --cmd "node tools/accept-s10-export.mjs"',
    independence: { data: '独立子进程 + 独立夹具库；导出走真实插件命令（registry runCommand）；docx 内容经 OOXML 解包验证（不经导出方自证的字段）', selfReported: [] },
    items,
    artifacts: [
      { path: 'packages/core/src/lifecycle/publish.mjs', sha256: sha(join(PROJECT_ROOT, 'packages/core/src/lifecycle/publish.mjs')) },
      { path: 'packages/plugins/timeline/index.mjs', sha256: sha(join(PROJECT_ROOT, 'packages/plugins/timeline/index.mjs')) },
      { path: 'packages/plugins/research-literature/lib/docx-export.mjs', sha256: sha(join(PROJECT_ROOT, 'packages/plugins/research-literature/lib/docx-export.mjs')) },
      { path: 'tools/accept-s10-export.mjs', sha256: sha(join(PROJECT_ROOT, 'tools/accept-s10-export.mjs')) },
    ],
  }
  const payload = JSON.stringify(out, null, 2)
  writeFileSync(logPath('s10-export-evidence.json'), payload)
  const runRoot = process.env.ORB_RUN_ROOT
  if (runRoot) { try { writeFileSync(join(runRoot, 's10-export-evidence.json'), payload) } catch { /* noop */ } }
  console.log(`S10 镜4-结论导出：${items.filter((i) => i.ok).length}/${items.length} → ${out.verdict}`)
  console.log(`证据：${logPath('s10-export-evidence.json')}`)
  process.exit(out.verdict === 'accept' ? 0 : 1)
}

main().catch((e) => { console.error('S10 export 验收异常:', e); process.exit(2) })
