// tools/accept-s25a-extract.mjs —— S25·2B 截图→文本验收（真实 qwen 1 请求 + 桩路径全离线）。
// 单行复跑：node tools\accept-s25a-extract.mjs
// 证据：data\logs\s25a-extract-accept.json。
// 纪律：网络请求共 1 个（≤10/min）；密钥运行时直读不落盘；预制样本图用系统字体渲染。
import { spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync, statSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createRouter } from '../packages/core/src/router.mjs'
import { makeInvoke } from '../packages/plugins/coach/index.mjs'
import { createExtractor, visionMessages, hitRate, ExtractError } from '../packages/plugins/coach/extract.mjs'
import { runWinrtOcr } from '../packages/plugins/coach/ocr.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 240), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's25a-extract')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(join(WORK, 'frames'), { recursive: true })
mkdirSync(join(WORK, 'coach'), { recursive: true })

const SAMPLE = '微电网逆变器下垂控制策略研究综述初稿计划' // 恰 20 字
const SAMPLE_IMG = join(WORK, 'frames', 'sample-text.png')
const COACH_DIR = join(WORK, 'coach')
const TRASH = join(WORK, 'trash')

// 预制样本图：白底黑字大号中文（清晰可转录）
function renderSampleImage() {
  const script = [
    'Add-Type -AssemblyName System.Drawing;',
    `$b=New-Object System.Drawing.Bitmap 1400,360;`,
    '$g=[System.Drawing.Graphics]::FromImage($b);',
    '$g.Clear([System.Drawing.Color]::White);',
    `$f=New-Object System.Drawing.Font('Microsoft YaHei',56);`,
    '$g.DrawString("' + SAMPLE.slice(0, 10) + '",$f,[System.Drawing.Brushes]::Black,40,40);',
    '$g.DrawString("' + SAMPLE.slice(10) + '",$f,[System.Drawing.Brushes]::Black,40,160);',
    `$b.Save('${SAMPLE_IMG.replace(/\\/g, '\\\\')}',[System.Drawing.Imaging.ImageFormat]::Png);`,
    '$g.Dispose();$b.Dispose();',
  ].join(' ')
  spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], { timeout: 30000, encoding: 'utf8' })
  return existsSync(SAMPLE_IMG)
}

try {
  check('X0 预制 20 字样本图渲染成功', renderSampleImage() && statSync(SAMPLE_IMG).size > 2000, `bytes=${existsSync(SAMPLE_IMG) ? statSync(SAMPLE_IMG).size : 0}`)
  // pristine 副本：E1 的 extract 会删除原件，后续用例从副本取图
  const KEEP = join(WORK, 'sample-keep.png')
  writeFileSync(KEEP, readFileSync(SAMPLE_IMG))

  const audits = []
  const audit = (rec) => audits.push(rec)
  // 真实 router：cheap=qwen 走网关（1 个请求），flagship 兑现同样走网关（本验收不会触发旗舰）
  const realRouter = createRouter({
    providers: (() => { try { const d = JSON.parse(readFileSync(join(PROJECT_ROOT, 'data', 'providers.json'), 'utf8')); return { cheap: d.cheap, flagship: d.flagship } } catch { return {} } })(),
    invoke: makeInvoke({ net: null }), // invoke 内部自取网关（resolveRef），net 参数不用于网关路径
    audit,
    usagePath: join(WORK, 'usage.jsonl'), // S67·3-C：E1 用真实 usage.providerId 对账 source
  })
  const ex = createExtractor({ dir: COACH_DIR, router: realRouter, trashDir: TRASH })

  // ① 真实 qwen 视觉转录（1 个网络请求）
  const r1 = await ex.extract({ imagePath: SAMPLE_IMG })
  // S67·3-C：首跳可能是 GLM(zhipu) 而非 qwen——按 S63 口径断言 source === usage 实际 providerId
  const usageRows = (() => { try { return readFileSync(join(WORK, 'usage.jsonl'), 'utf8').split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean) } catch { return [] } })()
  const u1 = usageRows.filter((r) => r.taskClass === 'extract').pop()
  check('E1 真实视觉转录成功（source === usage.providerId）', r1.ok === true && !!u1 && r1.source === u1.providerId && r1.cached === false, `source=${r1.source} usage=${u1 && u1.providerId}`)
  const rate = hitRate(SAMPLE, r1.text)
  check(`E2 20 字样本命中 ≥80%（实测 ${(rate * 100).toFixed(0)}%）`, rate >= 0.8, `text=${String(r1.text).replace(/\s+/g, ' ').slice(0, 60)}`)
  check('E3 文本 sha256 与内容一致', r1.textSha256 === (await import('node:crypto')).createHash('sha256').update(Buffer.from(r1.text, 'utf8')).digest('hex'))

  // ② 原图消失 + trash 副本 + 审计
  check('E4 处理后原图已删除', !existsSync(SAMPLE_IMG))
  const trashFiles = existsSync(TRASH) ? readdirSync(TRASH) : []
  check('E5 trash 副本存在（TTL 由既有清理机制覆盖）', trashFiles.length >= 1, `trash=${trashFiles.join(',').slice(0, 80)}`)
  const auditText = readFileSync(join(PROJECT_ROOT, 'data', 'logs', 'coach.jsonl'), 'utf8')
  const frameRows = auditText.split('\n').filter((l) => l.includes('frame-processed')).map((l) => JSON.parse(l))
  const lastFrame = frameRows[frameRows.length - 1]
  check('E6 审计行字段齐 {frameId,textSha256,bytes,deletedAt,ok}', !!lastFrame && lastFrame.frameId === r1.frameId && lastFrame.textSha256 === r1.textSha256 && typeof lastFrame.bytes === 'number' && !!lastFrame.deletedAt && lastFrame.ok === true)
  check('E7 只留文本+sha256+时间（frames-index 无图片路径/二进制）', (() => { const idx = JSON.parse(readFileSync(join(COACH_DIR, 'frames-index.json'), 'utf8')); const v = Object.values(idx)[0]; return !JSON.stringify(v).includes('frames') && !JSON.stringify(v).includes('.png') })())

  // ③ 去重：同内容图（新路径、同哈希）二次处理 → 缓存返回，不重复调用（不扣配额）
  let invokeCalls = 0
  const countRouter = createRouter({ providers: { cheap: {}, flagship: {} }, invoke: async () => { invokeCalls += 1; return { text: 't' } }, audit: () => {}, usagePath: join(WORK, 'usage-count.jsonl') })
  const exCount = createExtractor({ dir: join(WORK, 'coach2'), router: countRouter, trashDir: join(WORK, 'trash2'), ocr: () => ({ ok: true, text: '兜底' }) })
  const trashCopy = readdirSync(TRASH).map((f) => join(TRASH, f))[0]
  const dup1 = join(WORK, 'frames', 'dup1.png')
  writeFileSync(dup1, readFileSync(trashCopy))
  const rDup = await exCount.extract({ imagePath: dup1 })
  const before = invokeCalls
  const dup2 = join(WORK, 'frames', 'dup2.png')
  writeFileSync(dup2, readFileSync(trashCopy)) // 同内容新路径（模拟同一张截图再次出现）
  const rDup2 = await exCount.extract({ imagePath: dup2 })
  check('E8 同图去重：同哈希新路径 cached=true 且不重复调用（不扣配额）', rDup.cached === false && rDup2.cached === true && invokeCalls === before && rDup2.frameId === rDup.frameId)
  const other = join(WORK, 'frames', 'other.png')
  writeFileSync(other, Buffer.from('different image body'))
  const rOther = await exCount.extract({ imagePath: other })
  check('E9 不同图不去重（新哈希触发真实调用）', rOther.cached === false && invokeCalls === before + 1)

  // ④ qwen 失败 → OCR 兜底 + extract-fallback 审计
  const stubRouter = createRouter({ providers: { cheap: { providerId: 'school-gateway', model: 'qwen' }, flagship: {} }, invoke: async () => { throw Object.assign(new Error('gw down'), { code: 'E_HTTP_500' }) }, audit: () => {}, usagePath: join(WORK, 'usage-stub.jsonl') })
  const exStub = createExtractor({ dir: join(WORK, 'coach3'), router: stubRouter, trashDir: join(WORK, 'trash3'), ocr: (p) => runWinrtOcr(p) })
  const bigImg = join(WORK, 'frames', 'big-text.png')
  writeFileSync(bigImg, readFileSync(KEEP))
  const rOcr = await exStub.extract({ imagePath: bigImg })
  check('E10 qwen 失败 → OCR 兜底得到文本（source=ocr）', rOcr.ok === true && rOcr.source === 'ocr' && String(rOcr.text).length > 0, `ocr text=${String(rOcr.text).replace(/\s+/g, ' ').slice(0, 40)}`)
  check('E11 extract-fallback 审计行存在', audits.some((a) => a.kind === 'extract-fallback') || readFileSync(join(PROJECT_ROOT, 'data', 'logs', 'coach.jsonl'), 'utf8').includes('extract-fallback'))

  // ⑤ 缺图
  let threw = false
  try { await ex.extract({ imagePath: join(WORK, 'frames', 'nope.png') }) } catch (e) { threw = e.code === 'E_FRAME_NOT_FOUND' }
  check('E12 缺图 → E_FRAME_NOT_FOUND', threw)
} catch (e) {
  check('X0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 240))
} finally {
  rmSync(WORK, { recursive: true, force: true })
}

const pass = items.filter((i) => i.ok).length
const fail = items.length - pass
const out = { tool: 'accept-s25a-extract', at: new Date().toISOString(), total: items.length, pass, fail, items }
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's25a-extract-accept.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # accept-s25a-extract: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 证据 -> data/logs/s25a-extract-accept.json`)
process.exit(fail === 0 ? 0 : 1)

function readdirSafe(dir) { try { return readdirSync(dir) } catch { return [] } }
