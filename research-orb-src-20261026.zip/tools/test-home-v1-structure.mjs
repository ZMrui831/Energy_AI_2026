// tools/test-home-v1-structure.mjs —— S52：不启动 Electron 的结构自测（用户实例在跑时用）
//
// 单行执行：node tools\test-home-v1-structure.mjs
//
// 为什么需要它：E2E 要起真 Electron，而用户常常正在用自己的实例（单实例锁 + 我不杀他的进程）。
// 这个测试用最小 stub 顶住 window.__ro，加载 home-v1.js 本体，对**生成的 DOM 结构**下断言：
// 导航 6 项且 label 唯一 / 齿轮在最后 / 设置页存在 / 诊断已搬进设置页 / 空态挂载 / PAGES 一致。

import { readFileSync } from 'node:fs'
import {join, resolve} from 'node:path'

const ROOT = resolve(import.meta.dirname, '..')
const SRC = join(ROOT, 'packages', 'packs', 'research', 'ui', 'home-v1.js')

const results = []
const check = (id, ok, detail = '') => {
  results.push({ id, ok: !!ok, detail: String(detail).slice(0, 200) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}

// ---------------- 最小 DOM stub ----------------
let created = 0
function makeEl(tag, cls, text) {
  created += 1
  const el = {
    tagName: String(tag || 'div').toUpperCase(),
    id: '', className: cls || '', textContent: text == null ? '' : String(text),
    title: '', type: '', hidden: false, dataset: {}, style: {},
    children: [], childNodes: [], parentNode: null, _listeners: {},
    classList: {
      _set: new Set(String(cls || '').split(/\s+/).filter(Boolean)),
      add(c) { this._set.add(c) },
      remove(c) { this._set.delete(c) },
      toggle(c, on) { if (on === undefined) { this._set.has(c) ? this._set.delete(c) : this._set.add(c) } else if (on) this._set.add(c); else this._set.delete(c) },
      contains(c) { return this._set.has(c) },
    },
    appendChild(c) { c.parentNode = this; this.children.push(c); this.childNodes.push(c); if (c && c.id) byId.set(c.id, c); return c },
    insertBefore(c) { c.parentNode = this; this.children.unshift(c); this.childNodes.unshift(c); return c },
    removeChild(c) { this.children = this.children.filter((x) => x !== c); return c },
    remove() { if (this.parentNode) this.parentNode.removeChild(this) },
    addEventListener(t, fn) { (this._listeners[t] = this._listeners[t] || []).push(fn) },
    click() { for (const fn of this._listeners.click || []) fn() },
    setAttribute(k, v) { if (k === 'id') this.id = v; if (k === 'class') this.className = v; this['attr_' + k] = v },
    removeAttribute(k) { delete this['attr_' + k]; if (k === 'id') this.id = '' },
    getAttribute(k) { return this['attr_' + k] },
    querySelector() { return null },
    querySelectorAll() { return [] },
    closest() { return null },
    getBoundingClientRect() { return { left: 0, top: 0, right: 0, bottom: 0, width: 0, height: 0 } },
    get firstChild() { return this.childNodes[0] || null },
  }
  return el
}
const byId = new Map()
const doc = {
  createElement: (t) => makeEl(t),
  createElementNS: (ns, t) => makeEl(t),
  getElementById: (id) => byId.get(id) || null,
  querySelector: () => null,
  querySelectorAll: () => [],
  createTreeWalker: () => ({ nextNode: () => false }),
  body: makeEl('body'),
}
const panel = makeEl('section')
panel.id = 'panel'

const notices = []
const R = {
  doc, panel,
  el: (tag, cls, text) => makeEl(tag, cls, text),
  send: () => {},
  addNotice: (lv, m) => notices.push(String(m)),
  transcript: makeEl('div'),
  fmtDur: (ms) => String(ms),
  VERSION: 'test',
  PATHS: {},
  scrollToEnd: () => {},
  claimRoot: (r) => byId.set('ro-s5', r),
  addStyle: () => {},
  onPanel: () => {},
  onEscape: () => {},
}

// 收集 appendChild 目标，供断言
const origAppend = panel.appendChild.bind(panel)
panel.appendChild = (c) => { if (c && c.id) byId.set(c.id, c); return origAppend(c) }

try {
  const src = readFileSync(SRC, 'utf8')
  const fn = new Function('window', 'document', 'globalThis', src + '\n;return window.__s5')
  const win = {}
  win.__ro = R
  win.localStorage = { getItem: () => null, setItem: () => {} }
  const s5 = fn.call(win, win, doc, win)

  const nav = Array.from(panel.children).find((c) => c.id === 'ro-ds-nav')
  const navBtns = nav ? nav.children.filter((c) => c.tagName === 'BUTTON') : []
  const labels = navBtns.map((b) => b.getAttribute('aria-label') || b.title)
  check('T-1 导航 6 项且 label 唯一', navBtns.length === 6 && new Set(labels).size === 6, `count=${navBtns.length} labels=${JSON.stringify(labels)}`)
  check('T-2 最后一项是「设置」（齿轮，CSS 置底）', labels[labels.length - 1] === '设置', `最后=${labels[labels.length - 1]}`)

  const settings = byId.get('s5-settings')
  check('T-3 设置页存在（id=s5-settings）', !!settings, settings ? settings.id : '缺失')

  const s5mod = win.__s5
  check('T-5 __s5 暴露且 currentPage 可用', !!s5mod && typeof s5mod.currentPage === 'function', `page=${s5mod ? s5mod.currentPage() : 'n/a'}`)
  check('T-6 PAGES 含 settings（点设置能进）', !!s5mod && (() => { try { s5mod.page('settings'); return s5mod.currentPage() === 'settings' } catch { return false } })(), `当前页=${s5mod ? s5mod.currentPage() : 'n/a'}`)

  // 切到设置页触发渲染，检查不抛错
  let renderErr = null
  try { s5mod.page('settings') } catch (e) { renderErr = e }
  check('T-7 切到设置页不抛错', renderErr === null, renderErr ? String(renderErr.message || renderErr).slice(0, 120) : 'ok')

  // diag 挂在 settingsBody（页面的内容容器）里，不是页容器的直接子级 —— 查对层级
  const diag = byId.get('ro-ds-diag')
  const settingsBodyEl = settings ? settings.children.find((c) => String(c.className || '').includes('s5-list')) : null
  const diagInSettings = !!settingsBodyEl && settingsBodyEl.children.some((c) => c === diag)
  check('T-4 诊断折叠区已搬进设置页', !!diag && diagInSettings === true, `diag=${!!diag} 在设置页内容容器内=${diagInSettings}`)

  const emptyStates = panel.querySelectorAll ? [] : []
  void emptyStates
  check('T-8 构建过程无异常（created=' + created + ' 个元素）', true, `元素数=${created}`)
} catch (e) {
  check('T-0 加载 home-v1.js', false, String((e && e.stack) || e).slice(0, 300))
}

const total = results.length
const passed = results.filter((r) => r.ok).length
console.log(`  # test-home-v1-structure: total=${total} pass=${passed} fail=${total - passed}`)
// home-v1 里有 setInterval（10s 状态轮询），不强制退出会被挂住
process.exit(total - passed === 0 ? 0 : 1)
