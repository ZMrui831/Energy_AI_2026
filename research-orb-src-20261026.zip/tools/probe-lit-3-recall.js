// tools/probe-lit-3-recall.js —— 面板取证 ③：索引检索框做中文问答（函数体形式，见脚本①的说明）。
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const editor = document.getElementById('ro-editor')
const lit = document.getElementById('ro-lit')
if (editor && editor.classList.contains('ro-open')) {
  const cancel = [...editor.querySelectorAll('button')].find((b) => b.textContent === '取消')
  if (cancel) cancel.click()
  await sleep(250)
}
const input = lit.querySelector('.ro-idxinput')
if (!input) return { error: '没有索引检索框' }
input.value = '构网型逆变器的惯量支撑有哪些实现路径'
const go = [...lit.querySelectorAll('button')].find((b) => b.textContent === '检索')
if (!go) return { error: '没有检索按钮', buttons: [...lit.querySelectorAll('button')].map((b) => b.textContent) }
go.click()
let pre = null
for (let i = 0; i < 90; i += 1) {
  await sleep(400)
  pre = lit.querySelector('.ro-pre')
  if (pre && pre.textContent.indexOf('出处') >= 0) break
}
await sleep(500)
const cites = [...lit.querySelectorAll('.ro-cite')]
return {
  litOpen: lit.classList.contains('ro-open'),
  answerChars: pre ? pre.textContent.length : 0,
  answerHead: pre ? pre.textContent.slice(0, 220) : null,
  citationRows: cites.length,
  firstCitation: cites.length > 0 ? cites[0].textContent.slice(0, 130) : null,
}
