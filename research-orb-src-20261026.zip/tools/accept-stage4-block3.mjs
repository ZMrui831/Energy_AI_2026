// tools/accept-stage4-block3.mjs
//
// 阶段 4 块 3（笔记操作深化）验收取证器 —— 走**真实 registry 路径**：
// createRegistry → scan → enable(research-literature) → reg.runCommand(...)。
// 与块 1/2 的"createEngine + 桩 scope"不同：块 3 的交付物就是磁盘上的笔记/索引/导出，
// 必须用宿主同款的真实 scoped fs（safeWrite → writes.jsonl 审计）与真实 data 布局取证。
//
// 用例（与任务书 9 项验收对应）：
//   ① 双向链接：A 卡正文写 [[card-b]]（模拟用户编辑，经 safeWrite 留审计）+ 悬空 [[ghost-b3]]
//      → /note links 两侧查询 + 悬空清单
//   ② 四类模板各生成一次 → 贴四份 front-matter 头 + 骨架 section
//   ③ 批量：3 张卡批量打标签 + 改状态 → 卡片/meta 落实 + plugins.jsonl 审计 3 条
//   ④ 检索：标签过滤（不误召回）/ 项目过滤（topic + project/ 标签双路）/ 中文 query 自动补英文
//   ⑤ 导出：单篇 md + 整主题合并 md（目录+大纲）；BibTeX 回归（card.update 填真 DOI → /bib → citation-js 自检）
//   ⑥ Zotero 只读：data/fixtures 里的 .bib → 候选集；适配器源码 fs 导入行静态取证
//   ⑦ 全量测试 ≥420 + 真实 electron 冒烟
//   ⑧ 隔离复核 + vendor/orb-base 与 start.cmd 未改（与开工快照对比）
//   ⑨ 汇总 ≤15 行
//
// 产物：data/logs/stage43-* + data/logs/stage43-summary.json
// 清理：accept-b3 主题与其导出/候选为本次取证产物，结束时删除（.links.json 重建为真值）。

import { spawn, spawnSync } from 'node:child_process'
import { existsSync, readdirSync, readFileSync, rmSync, statSync } from 'node:fs'
import { join } from 'node:path'

import { createRegistry } from '../packages/plugins/index.mjs'
import { createNet } from '../packages/core/src/net.mjs'
import { createProviders } from '../packages/core/src/providers/index.mjs'
import { PROJECT_ROOT, safeWrite } from '../packages/core/src/safefs.mjs'
import {countOrbAll, killMarked, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-stage4-block3')

const LOGS = join(PROJECT_ROOT, 'data', 'logs')
const APP_LOG = join(LOGS, 'app.jsonl')
const RENDERER_LOG = join(LOGS, 'renderer.jsonl')
const PLUGIN_LOG = join(LOGS, 'plugins.jsonl')
const NOTES = join(PROJECT_ROOT, 'data', 'notes')
const TOPIC = 'accept-b3'
const ELECTRON_EXE = ORB_ELECTRON
const RESULTS = []

const startedAt = new Date().toISOString()

function evidence(name, text) {
  safeWrite(join(LOGS, name), text)
  return `data/logs/${name}`
}
function record(id, title, ok, detail, files = []) {
  RESULTS.push({ id, title, ok: !!ok, detail, files })
  process.stdout.write(`[${ok ? 'PASS' : 'FAIL'}] ${id} ${title}\n        ${String(detail).replace(/\n/g, '\n        ')}\n`)
  if (files.length > 0) process.stdout.write(`        证据：${files.join('  ')}\n`)
}
async function step(id, title, fn) {
  try {
    return await fn()
  } catch (err) {
    record(id, title, false, `异常：${(err && err.message) || err}`, [])
    return null
  }
}
function runNode(args) {
  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  const r = spawnSync(process.execPath, args, { cwd: PROJECT_ROOT, encoding: 'utf8', env: childEnv })
  return { status: r.status, stdout: String(r.stdout || ''), stderr: String(r.stderr || '') }
}
function pluginLogLines(since) {
  if (!existsSync(PLUGIN_LOG)) return []
  return readFileSync(PLUGIN_LOG, 'utf8')
    .split('\n')
    .filter((l) => l.trim())
    .slice(since)
    .map((l) => {
      try {
        return JSON.parse(l)
      } catch {
        return null
      }
    })
    .filter(Boolean)
}
/** 用户编辑动作也要走唯一写出口（safefs → writes.jsonl），绝不裸写。 */
function editNoteBody(rel, appendText) {
  const abs = join(NOTES, rel)
  const md = readFileSync(abs, 'utf8')
  const r = safeWrite(abs, md.replace(/\s+$/, '') + '\n\n' + appendText + '\n')
  return r
}
function head(md, n = 14) {
  return md.split('\n').slice(0, n).join('\n')
}

// ---------------------------------------------------------------------------
// 真实 registry + 引擎
// ---------------------------------------------------------------------------

const NET_LOG = join(LOGS, 'stage43-net.jsonl')
safeWrite(NET_LOG, '')
const net = createNet({ logFile: NET_LOG })
const providers = createProviders({ net })
const reg = createRegistry({ core: { net, providers } })
reg.scan()
const en = await reg.enable('research-literature')
if (!en.enabled) {
  process.stderr.write(`research-literature 启用失败：${en.error}\n`)
  process.exit(1)
}
// runCommand 返回 { ok, pluginId, name, value: { text, ui, ok, code } } —— 解包到 value 层
const run = async (name, args) => {
  const r = await reg.runCommand(name, args)
  return (r && r.value) || { ok: false, text: `(命令 ${name} 无返回值：${r && r.error ? r.error : '未知'})` }
}
const pluginLogSince = existsSync(PLUGIN_LOG) ? readFileSync(PLUGIN_LOG, 'utf8').split('\n').filter((l) => l.trim()).length : 0

// 开工快照对比素材（⑧ 用）：vendor/orb-base 与 start.cmd 的指纹
function fingerprint(rel) {
  const abs = join(PROJECT_ROOT, rel)
  if (!existsSync(abs)) return null
  const st = statSync(abs)
  if (st.isFile()) return { rel, mtimeMs: st.mtimeMs, size: st.size }
  let files = 0
  let newest = 0
  const walk = (d) => {
    for (const name of readdirSync(d)) {
      const p = join(d, name)
      const s = statSync(p)
      if (s.isDirectory()) walk(p)
      else {
        files += 1
        newest = Math.max(newest, s.mtimeMs)
      }
    }
  }
  walk(abs)
  return { rel, files, newestMtimeMs: newest }
}
const FP_BASE = [fingerprint('vendor/orb-base'), fingerprint('start.cmd'), fingerprint('start-dev.cmd')]

// ---------------------------------------------------------------------------
// 准备工作区（accept-b3 主题）
// ---------------------------------------------------------------------------

await step('准备', '清场 + 建验收主题', async () => {
  rmSync(join(NOTES, TOPIC), { recursive: true, force: true })
  const a = await run('note', `new ${TOPIC} card-a --template 方法`)
  const b = await run('note', `new ${TOPIC} card-b --template 综述`)
  record('准备', `建卡 card-a / card-b（主题 ${TOPIC}）`, a.ok && b.ok, `${a.ok ? 'A ok' : a.text}${b.ok ? '；B ok' : '；' + b.text}`)
})

// ---------------------------------------------------------------------------
// ① 双向链接
// ---------------------------------------------------------------------------

await step('①', '双向链接：A 卡正文 [[card-b]] + 悬空 [[ghost-b3]] → 两侧查询 + 悬空清单', async () => {
  // 模拟用户编辑（走 safeWrite 唯一出口）：card-a 正文引用 card-b 与一个不存在的 ghost
  editNoteBody(`${TOPIC}/card-a.md`, '本文与 [[card-b]] 的综述谱系衔接；另见 [[ghost-b3]]（计划建卡）。')
  const a = await run('note', 'links card-a')
  const b = await run('note', 'links card-b')
  const checks = {
    'A 引用 card-b 与 ghost-b3': /本卡引用（2）：card-b, ghost-b3/.test(a.text),
    '悬空清单点名 ghost-b3（目标不存在）': /→ \[\[ghost-b3\]\]（目标不存在）/.test(a.text),
    'B 侧被 A 引用（backlink 指到 accept-b3/card-a）': /← accept-b3\/card-a/.test(b.text),
    'B 自身无出链（正文没写 [[]]）': /本卡引用（0）/.test(b.text),
  }
  const txt = [`=== ① 双向链接（/note links 两侧查询 + 悬空清单）===`, '', '--- links card-a ---', a.text, '', '--- links card-b ---', b.text, '', '=== 逐项检查 ===', ...Object.entries(checks).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`)].join('\n')
  const rel = evidence('stage43-01-links.txt', txt)
  record('①', '双向链接（反链/悬空/两侧查询）', Object.values(checks).every(Boolean), `${Object.values(checks).filter(Boolean).length}/${Object.keys(checks).length} 项在位`, [rel])
})

// ---------------------------------------------------------------------------
// ② 四类模板
// ---------------------------------------------------------------------------

await step('②', '四类模板各生成一次（front-matter 头 + 骨架）', async () => {
  const cases = [
    ['rv-b3', '综述', '主线演进'],
    ['mth-b3', '方法', '适用条件与前提假设'],
    ['exp-b3', '实验', '与预期的偏差'],
    ['fail-b3', '失败', '何时可重试'],
  ]
  const heads = []
  let ok = true
  for (const [slug, tpl, section] of cases) {
    const r = await run('note', `new ${TOPIC} ${slug} --template ${tpl}`)
    if (!r.ok) {
      ok = false
      heads.push(`!!! ${slug}（${tpl}）建卡失败：${r.text}`)
      continue
    }
    const md = readFileSync(join(NOTES, TOPIC, `${slug}.md`), 'utf8')
    const tagOk = md.includes(`template/${tpl}`) && md.includes('project/accept-b3')
    const skelOk = md.includes(`## ${section}`) && md.includes('(待补)')
    if (!tagOk || !skelOk) ok = false
    heads.push(`--- ${slug}（${tpl}）${tagOk && skelOk ? 'OK' : 'MISS'} ---\n${head(md, 16)}`)
  }
  const txt = [`=== ② 四类模板（front-matter 头 + 骨架）===`, '', ...heads].join('\n')
  const rel = evidence('stage43-02-templates.txt', txt)
  record('②', '四类模板各生成一次，front-matter 与骨架符合预期', ok, `${cases.length} 份头部取证`, [rel])
})

// ---------------------------------------------------------------------------
// ③ 批量操作 + 审计
// ---------------------------------------------------------------------------

await step('③', '批量：3 张卡打标签 + 改状态，审计日志有对应记录', async () => {
  const before = pluginLogLines(pluginLogSince).length
  const r = await run('note', `batch --topic ${TOPIC} --pick 1,2,3 --tag 领域/构网型,重点 --status reading`)
  const audit = pluginLogLines(pluginLogSince).filter((l) => String(l.message || '').startsWith('note.batch'))
  const checks = {
    '批量返回 3/3 成功': /批量操作完成：3\/3 张卡/.test(r.text),
    '卡片 front-matter 有新标签': readFileSync(join(NOTES, TOPIC, 'card-a.md'), 'utf8').includes('领域/构网型'),
    'meta 侧车 status=reading': JSON.parse(readFileSync(join(NOTES, TOPIC, 'card-a.meta.json'), 'utf8')).status === 'reading',
    '审计日志 3 条 note.batch': audit.length >= 3,
  }
  const txt = [`=== ③ 批量操作 ===`, '', r.text, '', `审计（plugins.jsonl，本次新增 ${audit.length} 条 note.batch）：`, ...audit.slice(0, 3).map((l) => JSON.stringify(l)), '', '=== 逐项检查 ===', ...Object.entries(checks).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`)].join('\n')
  const rel = evidence('stage43-03-batch.txt', txt)
  record('③', '批量打标签 + 改状态 + 审计', Object.values(checks).every(Boolean), `${Object.values(checks).filter(Boolean).length}/${Object.keys(checks).length} 项在位`, [rel])
})

// ---------------------------------------------------------------------------
// ④ 检索
// ---------------------------------------------------------------------------

await step('④', '检索：标签过滤不误召回 / 项目过滤双路 / 中文 query 自动补英文', async () => {
  const byTag = await run('note', 'find  --tag template/综述')
  const byProject = await run('note', 'find  --project accept-b3')
  // 中文 query：往 rv-b3 的「问题」字段写英文同义表述（front-matter 是重渲染的真相源，
  // 经 card.update 原路校验写回 + 自动重建索引——不碰正文，避免与用户批注/链接互相踩）
  await run('card.update', JSON.stringify({ rel: `${TOPIC}/rv-b3.md`, patch: { 问题: 'grid-forming inverter inertia support（惯量支撑）是本综述的核心线索' } }))
  const byQuery = await run('note', 'find 惯量支撑 --project accept-b3')
  const checks = {
    '标签过滤：template/综述 只命中 rv-b3（不误召回其它模板卡）': /rv-b3/.test(byTag.text) && !/mth-b3/.test(byTag.text) && !/card-a/.test(byTag.text),
    '项目过滤：主题目录路径命中（accept-b3 下全部卡）': (byProject.text.match(/accept-b3\//g) || []).length >= 4,
    '中文 query 自动补英文后命中 rv-b3': /rv-b3/.test(byQuery.text),
    '不误召回：query+tag 用不存在的标签 → 0 命中': true,
  }
  const none = await run('note', 'find 惯量支撑 --tag 不存在的标签xyz')
  checks['不误召回：query+tag 用不存在的标签 → 0 命中'] = /命中 0 条/.test(none.text)
  const txt = [
    '=== ④ 检索 ===',
    '',
    '--- find --tag template/综述 ---', byTag.text,
    '', '--- find --project accept-b3 ---', byProject.text,
    '', '--- find 惯量支撑 --project accept-b3（中文→英文双路）---', byQuery.text,
    '', '--- find 惯量支撑 --tag 不存在的标签xyz（不误召回）---', none.text,
    '', '=== 逐项检查 ===',
    ...Object.entries(checks).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`),
  ].join('\n')
  const rel = evidence('stage43-04-find.txt', txt)
  record('④', '标签/项目过滤 + 中文双路检索', Object.values(checks).every(Boolean), `${Object.values(checks).filter(Boolean).length}/${Object.keys(checks).length} 项在位`, [rel])
})

// ---------------------------------------------------------------------------
// ⑤ 导出（markdown 单篇/合并 + BibTeX 回归）
// ---------------------------------------------------------------------------

await step('⑤', '导出：单篇 md + 整主题合并 md + BibTeX 回归（citation-js 自检）', async () => {
  // 给 card-b 填一个真实 DOI（经 card.update 原路校验写回），让 /bib 有真条目可导
  await run('card.update', JSON.stringify({ rel: `${TOPIC}/card-b.md`, patch: { doi: '10.1109/lcsys.2020.3044551', title: 'Grid-Forming Frequency Shaping Control for Low-Inertia Power Systems' } }))
  const single = await run('note', `export ${TOPIC} --slug card-a`)
  const merged = await run('note', `export ${TOPIC}`)
  const bib = await run('bib', TOPIC)
  const expDir = join(PROJECT_ROOT, 'data', 'exports')
  const singleFile = readdirSync(expDir).find((f) => f.startsWith(`${TOPIC}-card-a-`))
  const mergedFile = readdirSync(expDir).find((f) => f.startsWith(`${TOPIC}-20`) && f.endsWith('.md'))
  const bibFile = readdirSync(expDir).find((f) => f.startsWith(`${TOPIC}-`) && f.endsWith('.bib'))
  const singleOk = single.ok && singleFile && readFileSync(join(expDir, singleFile), 'utf8').includes('research-orb 笔记导出')
  const mergedOk = merged.ok && mergedFile && /## 目录/.test(readFileSync(join(expDir, mergedFile), 'utf8')) && /## 大纲/.test(readFileSync(join(expDir, mergedFile), 'utf8'))
  const bibOk = bib.ok === true && bibFile && /自检（citation-js 回读）：通过/.test(bib.text)
  const checks = {
    '单篇导出（带导出头）': !!singleOk,
    '整主题合并导出（目录 + 大纲 + 逐卡正文）': !!mergedOk,
    'BibTeX 导出 + citation-js 回读自检通过': !!bibOk,
  }
  const bibPath = bibFile ? `data/exports/${bibFile}` : '(无)'
  const bibHead = bibFile ? readFileSync(join(expDir, bibFile), 'utf8').split('\n').slice(0, 8).join('\n') : ''
  const txt = [
    '=== ⑤ 导出 ===',
    '',
    '--- /note export --slug card-a ---', single.text,
    '', '--- /note export ' + TOPIC + ' ---', merged.text,
    '', '--- /bib ' + TOPIC + ' ---', bib.text,
    '', `BibTeX 片段（${bibPath}）：`, bibHead,
    '', '=== 逐项检查 ===',
    ...Object.entries(checks).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`),
  ].join('\n')
  const rel = evidence('stage43-05-export.txt', txt)
  record('⑤', 'Markdown 单篇/合并导出 + BibTeX 回归', Object.values(checks).every(Boolean), `单篇=${singleFile || '缺'}；合并=${mergedFile || '缺'}；bib=${bibPath}；bib.ok=${bib.ok}`, [rel])
})

// ---------------------------------------------------------------------------
// ⑥ Zotero 只读
// ---------------------------------------------------------------------------

await step('⑥', 'Zotero 只读互通：.bib → 候选集；适配器源码静态取证无写路径', async () => {
  const zot = join(PROJECT_ROOT, 'data', 'fixtures', 'zotero-export-accept-b3.bib')
  safeWrite(zot, [
    '@article{zaccept,',
    '  title = {Zotero Acceptance Fixture on Virtual Synchronous Generator},',
    '  author = {Chen, Hao and Rossi, Maria},',
    '  journal = {IEEE Transactions on Smart Grid},',
    '  year = {2023},',
    '  doi = {10.1109/zotero.accept.1},',
    '  abstract = {Fixture for block-3 acceptance.},',
    '}',
  ].join('\n'))
  const r = await run('note', `zotero data/fixtures/zotero-export-accept-b3.bib --topic ${TOPIC}`)
  const candFile = readdirSync(join(PROJECT_ROOT, 'data', 'index', 'candidates')).find((f) => /zotero/i.test(f))
  const src = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'research-literature', 'lib', 'zotero.mjs'), 'utf8')
  const fsImport = /import \{([^}]*)\} from 'node:fs'/.exec(src)
  const checks = {
    '导入成功且候选数 ≥1': r.ok && /条候选/.test(r.text),
    '候选集落 data/index/candidates/': !!candFile,
    '适配器 node:fs 只 import 读函数': !!fsImport && fsImport[1].split(',').map((s) => s.trim()).sort().join(',') === 'existsSync,readFileSync,readdirSync,statSync',
  }
  const txt = [
    '=== ⑥ Zotero 只读互通 ===',
    '',
    '--- /note zotero ---', r.text,
    '', `适配器 fs 导入行：${fsImport ? 'import {' + fsImport[1].trim() + "} from 'node:fs'" : '(未找到)'}`,
    '（完整静态断言在 tests/notes.test.mjs：写函数名一个都不允许出现）',
    '', '=== 逐项检查 ===',
    ...Object.entries(checks).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`),
  ].join('\n')
  const rel = evidence('stage43-06-zotero.txt', txt)
  record('⑥', 'Zotero 只读互通 + 无写路径静态取证', Object.values(checks).every(Boolean), `候选集=${candFile || '缺'}`, [rel])
})

// ---------------------------------------------------------------------------
// ⑦ 全量测试 + electron 冒烟
// ---------------------------------------------------------------------------

await step('⑦', '全量测试 ≥420 + 真实 electron 冒烟', async () => {
  const files = readdirSync(join(PROJECT_ROOT, 'tests')).filter((f) => f.endsWith('.test.mjs')).map((f) => join('tests', f))
  const tr = runNode(['--test', '--test-concurrency=1', ...files])
  const out = tr.stdout + tr.stderr
  const pass = Number((out.match(/# pass (\d+)/) || [])[1] || 0)
  const fail = Number((out.match(/# fail (\d+)/) || [])[1] || -1)
  const testsRel = evidence('stage43-07-tests.txt', out)

  // electron 冒烟（与块 1/2 同款）
  // S74c·P0-1：只读计数统一走 _orb-proc.countOrbAll（下游不再消费 .stdout）
  const running = countOrbAll()
  let smokeOk = false
  let smokeDetail = ''
  if (Number.isFinite(running) && running > 0) {
    smokeDetail = `已有 ${running} 个 research-orb 进程在运行（fail-closed）`
  } else {
    const appBefore = existsSync(APP_LOG) ? readFileSync(APP_LOG, 'utf8').length : 0
    const renBefore = existsSync(RENDERER_LOG) ? readFileSync(RENDERER_LOG, 'utf8').length : 0
    const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs'), '--no-sandbox'], {
      cwd: PROJECT_ROOT,
      env: (() => { const e = { ...process.env }; delete e.ELECTRON_RUN_AS_NODE; return e })(),
      stdio: 'ignore',
      detached: false,
    })
    const seen = { bridgeInjected: null, bridgeFailed: null, panelFailed: null }
    const deadline = Date.now() + 60_000
    while (Date.now() < deadline) {
      await new Promise((r2) => setTimeout(r2, 1000))
      const appNow = existsSync(APP_LOG) ? readFileSync(APP_LOG, 'utf8') : ''
      for (const line of appNow.slice(appBefore).split('\n')) {
        if (!line.trim()) continue
        try {
          const j = JSON.parse(line)
          if (j.type === 'bridge-injected') seen.bridgeInjected = j
          if (j.type === 'bridge-inject-failed') seen.bridgeFailed = j
          if (j.type === 'panel-load-failed') seen.panelFailed = j
        } catch { /* 半行跳过 */ }
      }
      if (seen.bridgeInjected || seen.bridgeFailed) break
      if (child.exitCode !== null) break
    }
    if (seen.bridgeInjected) await new Promise((r2) => setTimeout(r2, 3000))
    try { child.kill('SIGKILL') } catch { /* 已退出 */ }
    await new Promise((r2) => setTimeout(r2, 1500))
    // S74c·P0-1：原为按 app 路径通配 宽匹配 Stop-Process（会误杀用户实例）→ 改为只回收本脚本自己起的进程树
    killMarked(MARK)
    const renNow = existsSync(RENDERER_LOG) ? readFileSync(RENDERER_LOG, 'utf8') : ''
    const uncaught = renNow.slice(renBefore).split('\n').filter((l) => l.trim()).filter((l) => /Uncaught/i.test(l))
    smokeOk = !!seen.bridgeInjected && !seen.bridgeFailed && !seen.panelFailed && uncaught.length === 0
    smokeDetail = `bridge-injected=${!!seen.bridgeInjected} Uncaught=${uncaught.length}`
  }
  const smokeRel = evidence('stage43-07-smoke.txt', `electron 冒烟：${smokeDetail}\n本阶段改动：/note 命令族注册 + 版本单一来源（core/src/version.mjs）+ package.json 0.4.0-phase4.2`)
  record('⑦', '全量测试 + electron 冒烟', fail === 0 && pass >= 422 && smokeOk, `${pass} 通过 / 失败 ${fail}；${smokeDetail}`, [testsRel, smokeRel])
})

// ---------------------------------------------------------------------------
// ⑧ 隔离复核 + 未改断言
// ---------------------------------------------------------------------------

await step('⑧', '隔离复核 + vendor/orb-base 与 start.cmd 未改', async () => {
  const r = runNode([join('tools', 'probe-isolation.mjs'), 'verify', '--tag', 'stage32'])
  const rel = evidence('stage43-08-iso-verify.txt', r.stdout + r.stderr)
  let verify = null
  try { verify = JSON.parse(readFileSync(join(PROJECT_ROOT, 'data', 'shots', 'stage32-iso-verify.json'), 'utf8')) } catch { verify = null }
  const fpNow = [fingerprint('vendor/orb-base'), fingerprint('start.cmd'), fingerprint('start-dev.cmd')]
  const fpSame = FP_BASE.every((f, i) => JSON.stringify(f) === JSON.stringify(fpNow[i]))
  record('⑧', '隔离复核（orb 哈希/计划任务/writes 越界 0）+ 启动面未改', r.status === 0 && !!verify && fpSame,
    `exit=${r.status}；vendor/orb-base 与 start*.cmd 指纹与开工快照一致=${fpSame}`, [rel])
})

// ---------------------------------------------------------------------------
// 清场（本次取证的产物）
// ---------------------------------------------------------------------------

try {
  rmSync(join(NOTES, TOPIC), { recursive: true, force: true })
  safeWrite(join(NOTES, '.links.json'), JSON.stringify({ schemaVersion: 1, generatedAt: new Date().toISOString(), cards: {}, backlinks: {}, dangling: [], stat: { cards: 0, linkCount: 0, danglingCount: 0 }, note: 'accept-b3 验收主题已清理；此为空索引，写卡后自动重建' }, null, 2))
  for (const f of readdirSync(join(PROJECT_ROOT, 'data', 'exports'))) {
    if (f.startsWith(TOPIC) && (f.endsWith('.md') || f.endsWith('.bib'))) rmSync(join(PROJECT_ROOT, 'data', 'exports', f), { force: true })
  }
  for (const f of readdirSync(join(PROJECT_ROOT, 'data', 'index', 'candidates'))) {
    if (/zotero/i.test(f)) rmSync(join(PROJECT_ROOT, 'data', 'index', 'candidates', f), { force: true })
  }
  rmSync(join(PROJECT_ROOT, 'data', 'fixtures', 'zotero-export-accept-b3.bib'), { force: true })
  safeWrite(join(LOGS, 'stage43-cleanup.txt'), `清理时间 ${new Date().toISOString()}\n删除：data/notes/${TOPIC}/、exports 的 ${TOPIC}-*、candidates 的 zotero-*、fixtures 的 zotero-export-accept-b3.bib\n保留：.links.json 已重置为空索引（写卡后自动重建）\n`)
} catch (err) {
  safeWrite(join(LOGS, 'stage43-cleanup.txt'), `清理异常：${String(err && err.message)}`)
}

// ---------------------------------------------------------------------------
// 汇总
// ---------------------------------------------------------------------------

const summary = {
  stage: '4-block3',
  startedAt,
  finishedAt: new Date().toISOString(),
  results: RESULTS,
  allPass: RESULTS.every((r) => r.ok),
}
safeWrite(join(LOGS, 'stage43-summary.json'), JSON.stringify(summary, null, 2))
process.stdout.write(`\n汇总：${RESULTS.filter((r) => r.ok).length}/${RESULTS.length} 通过 -> data/logs/stage43-summary.json\n`)
process.exit(summary.allPass ? 0 : 1)
