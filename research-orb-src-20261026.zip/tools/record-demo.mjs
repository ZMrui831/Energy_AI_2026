// tools/record-demo.mjs —— 录屏编排器（D3–D4：可录屏 + 可匿名；S18：7 镜 + 目标时长）
// 作用：启动真实应用 → 注入匿名遮罩 → 按叙事逐场景驱动 UI → 打印时间码 → 生成 SRT 字幕骨架
// 用法：
//   node tools/record-demo.mjs                          全部 7 镜，总长 270s（--target 默认）
//   node tools/record-demo.mjs --target 300             按权重分配每镜时长，总长 300s
//   node tools/record-demo.mjs --scenes 1,2 --hold 4    只录 S1/S2，每镜固定 4s（覆盖权重分配）
//   node tools/record-demo.mjs --claim clm-…           S6 逃生舱：发布页抓不到已发布结论时用该 id
//   node tools/record-demo.mjs --no-launch              附着到已在跑的应用（需带 --remote-debugging-port）
// 时长模型：--hold 显式给定 → 每镜都用该值（冒烟/补录用）；否则按 --target × 权重/Σ权重
// 分配每镜时长（取整差额补到权重最大镜，保证总长 = target），结束打印每镜起止时间码并校验 ±15s。
import { spawn, spawnSync, execFileSync } from 'node:child_process'
import { mkdirSync, writeFileSync, readFileSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import {countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('record-demo')

const arg = (k, d = null) => { const i = process.argv.indexOf(k); return i >= 0 ? process.argv[i + 1] : d }
const flag = (k) => process.argv.includes(k)
const ELECTRON_EXE = ORB_ELECTRON
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = Number(arg('--port', '9351'))
const TARGET = Number(arg('--target', '270'))          // 目标总时长（秒）
const HOLD_ARG = arg('--hold', null)                   // 显式每镜时长（秒），覆盖权重分配
const OUT = join(PROJECT_ROOT, 'data', 'reports')
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const mmss = (ms) => String(Math.floor(ms / 60000)).padStart(2, '0') + ':' + String(Math.floor((ms % 60000) / 1000)).padStart(2, '0')

// 7 镜叙事（S6/S7 旁白措辞取自 docs/SHOT-VAULT.md 与 docs/SHOT-CHART.md；
// 关键错误码/数字在 SRT 里单独成行，方便对口型）。
const SCENES = [
  { id: 'S1', weight: 0.8, title: '问题与形态：悬浮球即工作台', score: '选题10·风格10', narration: ['做文献调研时，大模型几秒就能给出一串文献和结论，但它会虚构DOI、张冠李戴。', '这颗贴边的球就是研究助手，点开是工作台。'] },
  { id: 'S2', weight: 1.2, title: '检索后DOI双源校验（切终端跑 accept-s10-doi）', score: '内容30·创新20', narration: ['检索到的每篇DOI都要过两个独立学术库核对。', '界面按双源、仅单源、未收录分行标记，对不上的直接亮出来。'] },
  { id: 'S3', weight: 1.0, title: 'AI整理：没挂证据的话进"待验证"区', score: '内容30·结构20', narration: ['AI负责归纳，但它写的每句话，没挂上可回指证据，就进待验证区。', '不能用肯定语气当结论。'] },
  { id: 'S4', weight: 1.3, title: '现场证伪：无证据结论被数据库拒绝（切终端跑 verify-demo）', score: '内容30·创新20', narration: ['现场演示：用裸 SQL 强行发布一条没有证据的结论。', '数据库这一层直接拒绝，状态停在草稿。', '拒绝码：CLAIM_EVIDENCE_REQUIRED'] },
  { id: 'S5', weight: 1.0, title: '人做判断：三档结论带证据编号导出', score: '结构20·内容30', narration: ['最后由人决定接受还是补证。', '导出的每条结论都带证据编号，能回到原文那一页；原图删了也如实说明。'] },
  { id: 'S6', weight: 0.9, title: '写入笔记库：已发布结论变成笔记库一页（/vault write|ask）', score: '结构20·内容30', narration: ['结论不只存在数据库里。', '它变成笔记库里的一页，带证据编号。', '笔记 front-matter：claim_id / status / evidence_ids / published_at', '下次提问，它能引用这一页回答。'] },
  { id: 'S7', weight: 0.9, title: '图表与表格：核验数据变成一张图一张表（/chart bars|table）', score: '创新20·内容30', narration: ['核验过的数据，变成一张图、一张表。', '图上写着每根柱子背后的证据编号。', '拿走的表格自带来源和校验哈希。', '1600×1000 · evidence_id 可回指 · sha256 防篡改', '无证据结论当场拒绝：E_NO_EVIDENCE'] },
]

let child = null
if (!flag('--no-launch')) {
  // S74c·P0-1：这里原来按 app 路径通配 宽匹配 Stop-Process，会把**用户正在跑的实例**杀掉（实测多次）。
  // 现在只做只读计数提示；本脚本收尾只清理自己启动的 pid。
  const preRunning = countOrbAll()
  if (preRunning > 0) console.log(`[record-demo] 提示：本机已有 ${preRunning} 个 research-orb 实例在运行（不会替你关闭；本脚本只清理自己启动的实例）`)
  await sleep(1200)
  // 关键：清掉 ELECTRON_RUN_AS_NODE，否则 electron 会当普通 node 跑并立刻退出（本项目经典坑）
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN_MJS], { cwd: PROJECT_ROOT, stdio: 'ignore', detached: true, env })
  child.unref()
  console.log('[record] 应用已启动 pid=' + child.pid + '，等待 CDP…')
}

async function findTarget(timeoutMs = 30000) {
  const t0 = Date.now()
  while (Date.now() - t0 < timeoutMs) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await r.json()
      const t = list.find((x) => x.type === 'page' && x.webSocketDebuggerUrl && /floating\.html/i.test(x.url))
      if (t) return t
    } catch { /* 还没起来 */ }
    await sleep(500)
  }
  throw new Error('CDP 目标未找到（port ' + PORT + '）')
}
const target = await findTarget()
const ws = new WebSocket(target.webSocketDebuggerUrl)
await new Promise((res, rej) => { ws.addEventListener('open', res); ws.addEventListener('error', () => rej(new Error('CDP 连接失败'))) })
let seq = 0
const pending = new Map()
ws.addEventListener('message', (ev) => { const m = JSON.parse(ev.data); if (m.id && pending.has(m.id)) { pending.get(m.id)(m); pending.delete(m.id) } })
const send = (method, params = {}) => new Promise((res, rej) => { const id = ++seq; pending.set(id, (m) => (m.error ? rej(new Error(method + ': ' + m.error.message)) : res(m.result))); ws.send(JSON.stringify({ id, method, params })) })
const evalJs = async (expr) => { const r = await send('Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true }); return r.result ? r.result.value : undefined }
await send('Page.enable'); await send('Runtime.enable')

// 匿名遮罩：新文档 + 当前文档都注入
const maskSrc = readFileSync(join(PROJECT_ROOT, 'tools', 'record-mask.js'), 'utf8')
if (!flag('--no-mask')) {
  try { await send('Page.addScriptToEvaluateOnNewDocument', { source: maskSrc }) } catch { /* 旧版不支持则仅注入当前文档 */ }
  const r = await evalJs(maskSrc)
  console.log('[record] 匿名遮罩: ' + r)
}

/**
 * 等首开完成：pack UI 注入 + __s5 就绪（避免录到"半渲染"画面）。
 * 依据 app.jsonl 的 pack-ui-injected 与页面内 window.__s5 双条件。
 */
async function waitFirstPaint(timeoutMs = 25000) {
  const t0 = Date.now()
  while (Date.now() - t0 < timeoutMs) {
    const ready = await evalJs("(() => !!(window.__s5 && window.__s5.currentPage))()")
    if (ready) { await sleep(400); return true }
    await sleep(300)
  }
  console.log('[record] 警告：__s5 未就绪（继续但画面可能未完全注入）')
  return false
}

async function waitUI(ms = 1500) { await sleep(ms) }
async function clickBall() {
  await evalJs("(() => { const b = document.getElementById('ball'); if (b) b.click(); return !!b })()")
}
/** 确保面板展开：折叠时 pack UI 在 panel.hidden 里，innerText 抓不到、录屏也只有球。
 *  注意：球的展开走 pointerdown→pointerup（见 ui-bridge endDrag），合成 click 不触发，必须发指针事件。 */
async function ensureExpanded() {
  const isOpen = () => evalJs("(() => !!document.body.classList.contains('expanded'))()")
  if (await isOpen()) return true
  await evalJs(`(() => {
    const b = document.getElementById('ball')
    if (!b) return 'no-ball'
    const r = b.getBoundingClientRect()
    const o = { bubbles: true, cancelable: true, composed: true, pointerId: 1, pointerType: 'mouse', isPrimary: true, button: 0, buttons: 1, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 }
    b.dispatchEvent(new PointerEvent('pointerdown', o))
    b.dispatchEvent(new PointerEvent('pointerup', { ...o, buttons: 0 }))
    return 'toggled'
  })()`)
  for (let i = 0; i < 20; i++) { if (await isOpen()) { await waitUI(600); return true } await sleep(250) }
  return false
}
async function gotoPage(name) {
  await evalJs(`(() => { try { if (window.__s5 && typeof window.__s5.page === 'function') window.__s5.page('${name}'); else if (window.__s5) window.__s5.currentPage = '${name}'; } catch (e) {} return (window.__s5 && typeof window.__s5.currentPage === 'function' && window.__s5.currentPage()) || '' })()`)
}

/** 走真实输入通路打字并回车：#prompt（contenteditable）+ keydown Enter → submit() → 'chat' 通道 → 插件命令。 */
async function typeCommand(cmd) {
  return evalJs(`(() => {
    const p = document.getElementById('prompt')
    if (!p) return 'no-prompt'
    p.textContent = ${JSON.stringify(cmd)}
    p.classList.remove('prompt-empty')
    p.dispatchEvent(new Event('input', { bubbles: true }))
    p.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', shiftKey: false, bubbles: true, cancelable: true }))
    return 'typed'
  })()`)
}

/** 从发布页结论列表里抓一条已发布结论的 claim_id。
 *  读 .s5-row 的 textContent（面板折叠时 body.innerText 恒为空，不能依赖可见性）。 */
async function findPublishedClaimId() {
  return evalJs(`(() => {
    const re = /(clm-[0-9a-z-]+)\\s*\\[published\\]/
    for (const row of document.querySelectorAll('.s5-row')) {
      const m = (row.textContent || '').match(re)
      if (m) return m[1]
    }
    const m2 = (document.body.innerText || '').match(re)
    return m2 ? m2[1] : ''
  })()`) || ''
}

/** 点开发布页里某条结论的行（渲染详情：证据编号可见）。 */
async function openClaimRow(cid) {
  return evalJs(`(() => {
    const els = [...document.querySelectorAll('.s5-row')]
    const el = els.find((e) => (e.textContent || '').includes(${JSON.stringify(cid)}))
    if (!el) return false
    el.click()
    return true
  })()`)
}

await waitFirstPaint()
const want = arg('--scenes', 'all')
const list = want === 'all' ? SCENES : SCENES.filter((s) => want.split(',').includes(s.id.replace('S', '')))

// ---- 每镜时长分配 ----------------------------------------------------------
const holdOverride = HOLD_ARG !== null && Number.isFinite(Number(HOLD_ARG)) ? Number(HOLD_ARG) * 1000 : null
const sumW = list.reduce((a, s) => a + s.weight, 0) || 1
const holds = (() => {
  if (holdOverride !== null) return list.map(() => holdOverride)
  const base = list.map((s) => Math.floor(TARGET * 1000 * s.weight / sumW))
  // 取整差额补到权重最大镜，保证总长 = target
  const rem = TARGET * 1000 - base.reduce((a, b) => a + b, 0)
  let idxMax = 0
  list.forEach((s, i) => { if (s.weight > list[idxMax].weight) idxMax = i })
  base[idxMax] += rem
  return base
})()
const holdMsOf = (i) => holds[i]

mkdirSync(OUT, { recursive: true })
const t0 = Date.now()
const timeline = []
const plannedTotal = list.reduce((a, _s, i) => a + holdMsOf(i), 0)
console.log('\n=== 录屏叙事（请按时间码配字幕/旁白）===')
console.log('  时长模式: ' + (holdOverride !== null ? `--hold ${HOLD_ARG}s（每镜固定）` : `--target ${TARGET}s × 权重分配（计划总长 ${Math.round(plannedTotal / 1000)}s）`) + '\n')
for (let i = 0; i < list.length; i++) {
  const sc = list[i]
  const start = Date.now() - t0
  console.log('[' + mmss(start) + '] ' + sc.id + ' ' + sc.title + '   ←(' + sc.score + '，权重 ' + sc.weight + '，计划 ' + mmss(holdMsOf(i)) + ')')
  if (sc.id === 'S1') { await ensureExpanded(); await waitUI(2500); await gotoPage('home'); await waitUI(2000) }
  else if (sc.id === 'S2') { console.log('        → 现在切到终端执行: node tools\\accept-s10-doi.mjs（DOI双源/单源/未收录四态）'); await waitUI(6000) }
  else if (sc.id === 'S3') { await gotoPage('home'); await waitUI(2500) }
  else if (sc.id === 'S4') { console.log('        → 现在切到终端执行: node tools\\verify-demo.mjs（四步证伪，约 15 秒）'); await waitUI(6000) }
  else if (sc.id === 'S5') { await gotoPage('publish'); await waitUI(2000) }
  else if (sc.id === 'S6') {
    await ensureExpanded()
    await gotoPage('publish')
    let cid = ''
    for (let i = 0; i < 8 && !cid; i++) { await waitUI(1000); cid = await findPublishedClaimId() } // 轮询等结论列表（慢环境耐受）
    if (!cid && arg('--claim', null)) cid = String(arg('--claim', null)) // 逃生舱：--claim 显式指定（现场 DB 慢时用）
    if (cid) {
      await openClaimRow(cid); await waitUI(2000)
      console.log('        → 已发布结论 ' + cid + '（详情可见证据编号）')
      await gotoPage('chat'); await waitUI(1000)
      console.log('        → 输入: /vault write ' + cid)
      await typeCommand('/vault write ' + cid); await waitUI(3000)
      console.log('        → 现在切到文件管理器打开: data\\vault-demo\\研究结论\\' + cid + '.md（front-matter 特写）')
      await waitUI(3000)
      console.log('        → 输入: /vault ask ' + cid)
      await typeCommand('/vault ask ' + cid); await waitUI(3000)
    } else {
      console.log('        → 发布页未找到已发布结论（不编造：按镜头脚本口述，跳过实跑）')
      await waitUI(2000)
    }
  }
  else if (sc.id === 'S7') {
    await ensureExpanded()
    await gotoPage('chat'); await waitUI(1000)
    console.log('        → 输入: /chart bars trust')
    await typeCommand('/chart bars trust'); await waitUI(7000)
    console.log('        → 现在打开产物 PNG（镜头推近底部来源标注，1–2 秒特写）')
    await waitUI(4000)
    console.log('        → 输入: /chart table claims')
    await typeCommand('/chart table claims'); await waitUI(7000)
    console.log('        → 同目录 sidecar .json：{source, evidenceIds, claimIds, generatedAt, sha256}')
    await waitUI(2000)
  }
  const rest = Math.max(0, holdMsOf(i) - (Date.now() - t0 - start))
  await sleep(rest)
  const end = Date.now() - t0
  timeline.push({ id: sc.id, title: sc.title, score: sc.score, narration: sc.narration.join('\n'), startMs: start, endMs: end, weight: sc.weight, holdMs: holdMsOf(i) })
}

// SRT 字幕骨架（旁白多行；关键错误码/数字已单独成行）
const srtTime = (ms) => { const h = String(Math.floor(ms / 3600000)).padStart(2, '0'); const m = String(Math.floor((ms % 3600000) / 60000)).padStart(2, '0'); const s = String(Math.floor((ms % 60000) / 1000)).padStart(2, '0'); return `${h}:${m}:${s},000` }
const srt = timeline.map((t, i) => `${i + 1}\n${srtTime(t.startMs)} --> ${srtTime(t.endMs)}\n${t.narration}\n`).join('\n')
writeFileSync(join(OUT, 'record-demo.srt'), srt, 'utf8')
writeFileSync(join(OUT, 'record-demo.timeline.json'), JSON.stringify({ generatedAt: new Date().toISOString(), target: TARGET, hold: HOLD_ARG, mode: holdOverride !== null ? 'hold' : 'target-weights', totalMs: Date.now() - t0, scenes: timeline }, null, 2))

// ---- 结束：每镜起止时间码 + 总长校验 ---------------------------------------
const totalMs = Date.now() - t0
console.log('\n=== 完成 ===')
console.log('  每镜时间码:')
for (const t of timeline) console.log('    ' + t.id + '  ' + mmss(t.startMs) + '–' + mmss(t.endMs) + '  ' + t.title)
console.log('  总时长: ' + mmss(totalMs) + '（' + list.length + ' 镜）')
if (holdOverride === null) {
  const delta = totalMs - TARGET * 1000
  const ok = Math.abs(delta) <= 15000
  console.log('  目标校验: ' + TARGET + 's±15s → ' + (ok ? 'PASS' : 'FAIL') + '（偏差 ' + (delta / 1000).toFixed(1) + 's）')
} else {
  console.log('  目标校验: --hold 模式（每镜 ' + HOLD_ARG + 's），不按 ' + TARGET + 's±15s 校验')
}
console.log('  字幕骨架: data/reports/record-demo.srt')
console.log('  时间线  : data/reports/record-demo.timeline.json')
console.log('  提示: 录屏请只裁应用窗口区域；遮罩已把真实路径/用户名替换为中性文本')
if (child) { try { spawnSync('taskkill', ['/pid', String(child.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true }) } catch { /* ignore */ } }
try { ws.close() } catch { /* ignore */ }
process.exit(0)
