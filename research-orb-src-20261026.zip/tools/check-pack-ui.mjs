// tools/check-pack-ui.mjs —— S52·P0-2 护栏：pack.json 声明的 ui 与 ui 目录必须一致
//
// 单行执行：node tools\check-pack-ui.mjs
// 命中即退出码 1（可接进 run-tests 前置）。
//
// 为什么要有它：S52 发现 `ui/timeline.js` 存在却从没被加载（不在 pack.json 的 ui 数组里），
// 我上一轮据此去"收住它的 region"，结果两边都空、页面全白 —— 改坏的直接原因。
// 护栏规则：
//   ① pack.json ui 数组里的每个文件都必须存在（否则启动即缺功能）；
//   ② ui 目录下**未被声明**的 .js 一律报警（存在但没加载 = 最坑的形态）；
//   ③ 只允许一个 "home*" 主文件（避免 home.js / home-v1.js 双份并行）。

import { existsSync, readdirSync, readFileSync } from 'node:fs'
import { join, dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const PACK = join(ROOT, 'packages', 'packs', 'research', 'pack.json')
const UI_DIR = join(ROOT, 'packages', 'packs', 'research', 'ui')

if (!existsSync(PACK)) {
  console.error('[pack-ui] 找不到 pack.json')
  process.exit(2)
}
const pack = JSON.parse(readFileSync(PACK, 'utf8'))
const declared = (pack.ui || []).map((p) => String(p).replace(/^ui\//, ''))
const problems = []

for (const f of declared) {
  if (!existsSync(join(UI_DIR, f))) problems.push(`已声明但文件不存在：ui/${f}`)
}

const onDisk = existsSync(UI_DIR) ? readdirSync(UI_DIR).filter((f) => /\.js$/.test(f)) : []
const undeclared = onDisk.filter((f) => !declared.includes(f))
for (const f of undeclared) problems.push(`存在但**未被加载**：ui/${f}（轨迹页/逻辑可能根本没挂上）`)

const homes = declared.filter((f) => /^home.*\.js$/.test(f))
if (homes.length > 1) problems.push(`主文件重复声明：${homes.join(' / ')}（只能有一个生效，另一个应标 @deprecated 或删除）`)

if (problems.length === 0) {
  console.log(`[pack-ui] PASS：声明 ${declared.length} 个，目录 ${onDisk.length} 个，全部对齐`)
  process.exit(0)
}
console.error(`[pack-ui] FAIL：${problems.length} 处不一致`)
for (const p of problems) console.error('   ' + p)
process.exit(1)
