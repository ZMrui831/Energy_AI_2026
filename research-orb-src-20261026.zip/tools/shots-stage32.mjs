// tools/shots-stage32.mjs —— P-R3.2 验收项 3 的 GUI 截图补拍（主管要求的 4 张）：
//   ① stage32-01-ball-badge.png   球角标/圆环（计时运行中，ro-ball-badge ro-on）
//   ② stage32-02-timer-panel.png  计时面板（含项目/阶段选择：计时卡片 + /project 列表）
//   ③ stage32-03-idle-*.png       空闲询问（ro-idleask 徽标 + 面板保留/扣除）
//   ④ stage32-04-settings.png     设置页（插件卡片区）
//
// 纪律与既有验收一致：
//   · fail-closed：已有 research-orb electron 在跑就退出，不抢。
//   · RESEARCH_ORB_TIME_SCALE=2：加速测试模式（数据按既定规则不计入进度汇总），
//     180 分钟会话 ≈ 90 真实分钟，足够撑过空闲阈值（真实 300 秒，不随倍速缩放）。
//   · 空闲询问等的是**真实系统空闲**（powerMonitor.getSystemIdleTime），
//     最多等 12 分钟；等不到就如实记 fail，不伪造状态。
//   · 结束只杀自己起的 research-orb electron（命令行过滤），不碰其他进程。
//
// 用法：node tools/shots-stage32.mjs
// 产物：data/shots/stage32-*.png + data/logs/stage32-shots.json

import { spawn, spawnSync } from 'node:child_process'
import { existsSync } from 'node:fs'
import { join } from 'node:path'
import { writeFileSync } from 'node:fs'

import { PROJECT_ROOT, safeWrite } from '../packages/core/src/safefs.mjs'
import {killMarked, countOrbAll, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('shots-stage32')

const ELECTRON_EXE = ORB_ELECTRON
const MAIN_MJS = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const SHOTS = join(PROJECT_ROOT, 'data', 'shots')
const PORT = 9333
const SUMMARY = { at: null, timeScale: 2, shots: [], idlePromptTriggered: false, ok: false }

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

// ---------------------------------------------------------------------------
// CDP 最小客户端（与 tools/shot.mjs 同一机制：连接已有的调试端口）
// ---------------------------------------------------------------------------

async function findTarget(timeoutMs = 30000) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const list = await res.json()
      // 认准面板本体（floating.html）。窗口创建到桥注入之间可能短暂存在别的 page 目标
      // （about:blank / 已被 GPU 崩溃回收的旧目标），连上去 eval 会一直空转。
      const page = list.find((t) => t.type === 'page' && t.webSocketDebuggerUrl && /floating\.html/i.test(t.url))
      if (page) return page
    } catch {
      /* 还没起来 */
    }
    await sleep(300)
  }
  throw new Error(`CDP 目标未找到（port ${PORT}，等待 ${timeoutMs}ms）`)
}

let cdp = null

async function connectCdp() {
  const target = await findTarget()
  const c = await connect(target.webSocketDebuggerUrl)
  await c.send('Page.enable')
  await c.send('Runtime.enable')
  return c
}

/** 连接失效（GPU 崩溃回收 renderer / 目标被替换）时换新目标重连。 */
async function ensureCdp() {
  if (cdp) {
    try {
      await cdp.send('Runtime.evaluate', { expression: '1', returnByValue: true })
      return cdp
    } catch {
      try { cdp.close() } catch { /* 忽略 */ }
      cdp = null
    }
  }
  cdp = await connectCdp()
  return cdp
}

/** 在 renderer 里执行一段函数体（自动包 async IIFE 并 await）；连接失效自动重连一次。 */
async function evalJs(body) {
  const c = await ensureCdp()
  let r
  try {
    r = await c.send('Runtime.evaluate', {
      expression: `(async function(){ ${body} })()`,
      awaitPromise: true,
      returnByValue: true,
    })
  } catch (err) {
    // socket 层失效：强制重连后重试一次
    try { cdp.close() } catch { /* 忽略 */ }
    cdp = null
    const c2 = await ensureCdp()
    r = await c2.send('Runtime.evaluate', {
      expression: `(async function(){ ${body} })()`,
      awaitPromise: true,
      returnByValue: true,
    })
  }
  if (r && r.exceptionDetails) {
    throw new Error('renderer 异常：' + JSON.stringify((r.exceptionDetails.exception && r.exceptionDetails.exception.description) || r.exceptionDetails))
  }
  return r && r.result ? r.result.value : undefined
}

function connect(url) {
  return new Promise((res, rej) => {
    const ws = new WebSocket(url)
    let seq = 0
    const pending = new Map()
    ws.addEventListener('open', () =>
      res({
        send(method, params = {}) {
          const id = ++seq
          return new Promise((ok, no) => {
            pending.set(id, { ok, no })
            ws.send(JSON.stringify({ id, method, params }))
            // 响应超时：renderer 崩溃/目标被替换时 evaluate 会永远等不到回包，必须能挣脱
            const timer = setTimeout(() => {
              if (pending.has(id)) {
                pending.delete(id)
                no(new Error(`CDP 响应超时（30s）：${method}`))
              }
            }, 30000)
            const wrappedOk = (v) => { clearTimeout(timer); ok(v) }
            const wrappedNo = (e) => { clearTimeout(timer); no(e) }
            pending.set(id, { ok: wrappedOk, no: wrappedNo })
          })
        },
        close: () => ws.close(),
      }),
    )
    ws.addEventListener('error', (e) => rej(new Error(`ws error: ${e && e.message}`)))
    ws.addEventListener('message', (ev) => {
      let msg = null
      try {
        msg = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data))
      } catch {
        return
      }
      const p = pending.get(msg.id)
      if (!p) return
      pending.delete(msg.id)
      if (msg.error) p.no(new Error(JSON.stringify(msg.error)))
      else p.ok(msg.result)
    })
  })
}

const sleepJs = async (ms) => {
  await ensureCdp()
  return evalJs(`await new Promise(r => setTimeout(r, ${ms}))`)
}

async function shot(name) {
  const c = await ensureCdp()
  const s = await c.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false })
  const data = s && s.data
  if (!data) throw new Error('截图失败：CDP 未返回 data')
  const abs = join(SHOTS, name)
  writeFileSync(abs, Buffer.from(data, 'base64'))
  const entry = { file: `data/shots/${name}`, bytes: Buffer.from(data, 'base64').length }
  SUMMARY.shots.push(entry)
  process.stdout.write(`shot: ${entry.file} (${entry.bytes} bytes)\n`)
  return entry
}

/** 面板上行（与 probe-lit-*.js 同一形状：ui 通道 + plugin:command）。 */
const sendUi = (type, detail) => evalJs(`globalThis.researchOrb.send('ui', Object.assign({ type: ${JSON.stringify(type)}, at: Date.now() }, ${JSON.stringify(detail || {})}))`)
const sendWindow = (action) => evalJs(`globalThis.researchOrb.send('window', { action: ${JSON.stringify(action)} })`)
const sendCommand = (name, args) => sendUi('plugin:command', { name, args })

/** 轮询一个 renderer 条件，直到为真或超时。 */
async function pollJs(expression, timeoutMs, everyMs = 500) {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline) {
    try {
      if (await evalJs(expression)) return true
    } catch {
      /* 桥还没好，继续等 */
    }
    await sleep(everyMs)
  }
  return false
}

function killOwnElectron() { return killMarked(MARK) }

// ---------------------------------------------------------------------------
// 主流程
// ---------------------------------------------------------------------------

SUMMARY.at = new Date().toISOString()

// fail-closed：已有 research-orb electron 在跑就不动手
// S74c·P0-1：只读计数统一走 _orb-proc.countOrbAll（下游不再消费 .stdout）
const running = countOrbAll()
if (Number.isFinite(running) && running > 0) {
  SUMMARY.error = `已有 ${running} 个 research-orb electron 在运行，先退出再补拍（fail-closed）`
  safeWrite(join(PROJECT_ROOT, 'data', 'logs', 'stage32-shots.json'), JSON.stringify(SUMMARY, null, 2))
  process.stderr.write(SUMMARY.error + '\n')
  process.exit(1)
}

const childEnv = { ...process.env, RESEARCH_ORB_TIME_SCALE: '2' }
// ELECTRON_RUN_AS_NODE 必须**删除**而不是设空串：Electron 只要见到该变量（哪怕空值）
// 就以纯 Node 运行，`--no-sandbox` 会报 bad option、球体永远不会出现（实测踩过）。
delete childEnv.ELECTRON_RUN_AS_NODE
// Chromium 开关必须放在应用路径之前（electron.exe --switch app.mjs），
// 放在后面会被当成 app argv 而不是 Chromium 开关，调试端口起不来。
const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN_MJS], {
  cwd: PROJECT_ROOT,
  env: childEnv,
  stdio: 'ignore',
  detached: false,
})
process.stdout.write(`electron pid=${child.pid}（timeScale=2，debug port ${PORT}）\n`)

try {
  // 等桥就绪（认准 floating.html 目标 + researchOrb 已注入；连接失效自动重连）
  await ensureCdp()
  const bridgeReady = await pollJs(`return typeof globalThis.researchOrb === 'object' && !!globalThis.researchOrb`, 25000)
  if (!bridgeReady) throw new Error('researchOrb 桥未注入（25s）')

  // ① 球角标/圆环：先建项目与阶段（start 的位置参数引用已存在的项目），再起加速会话
  process.stdout.write('[step] 建项目/阶段 + 起计时\n')
  sendCommand('project', 'new 备赛')
  await sleepJs(800)
  sendCommand('project', 'add-stage 备赛 写作')
  await sleepJs(800)
  sendCommand('start', '180 备赛 写作')
  process.stdout.write('[step] 等球角标进入运行态\n')
  const badgeOn = await pollJs(
    `const b=document.querySelector('.ro-ball-badge'); return !!(b && b.classList.contains('ro-on') && !b.classList.contains('ro-idleask'))`,
    12000,
  )
  if (!badgeOn) throw new Error('球角标未进入运行态（ro-ball-badge ro-on 未出现）')
  await sleepJs(800)
  await shot('stage32-01-ball-badge.png')

  // ② 计时面板（含项目/阶段选择）：展开 → 计时卡片 + /project 列表
  process.stdout.write('[step] 展开面板拍计时卡片\n')
  sendWindow('expand')
  await sleepJs(1200)
  sendCommand('project', '')
  const timerCard = await pollJs(`return !!document.querySelector('.ro-timer-clock')`, 8000)
  await sleepJs(1500)
  SUMMARY.shots.push({ file: 'data/shots/stage32-02-timer-panel.png', timerCard, note: timerCard ? null : '计时卡片未检测到（ro-timer-clock）' })
  await shot('stage32-02-timer-panel.png')

  // ④ 设置页：插件卡片区（先拍设置，空闲等待放最后，省总时长）
  process.stdout.write('[step] 打开设置页\n')
  // 先关计时面板：设置层与计时面板层重叠，计时面板开着会把设置页盖在底下（首拍实测踩中）
  await evalJs(`const b=document.querySelector('#ro-timer .ro-settings-close'); if (b) b.click()`)
  await sleepJs(600)
  await evalJs(`(()=>{ const b=document.getElementById('permission-button'); if (b) b.click(); })()`)
  await sleepJs(1000)
  await evalJs(`(()=>{ const s=document.getElementById('ro-settings'); if (!s) return; const g=[...s.querySelectorAll('.ro-group')].find(g=>{ const t=g.querySelector('.ro-group-title'); return t && t.textContent==='插件卡片' }); if (g) g.scrollIntoView({block:'start'}); })()`)
  await sleepJs(600)
  const settingsOpen = await evalJs(`const s=document.getElementById('ro-settings'); return !!(s && s.classList.contains('ro-open'))`)
  SUMMARY.shots.push({ file: 'data/shots/stage32-04-settings.png', settingsOpen, note: settingsOpen ? null : '设置页未打开' })
  await shot('stage32-04-settings.png')
  // 关设置页（再次点击权限按钮切换；面板回到对话态）
  await evalJs(`(()=>{ const b=document.getElementById('permission-button'); if (b) b.click(); })()`)
  await sleepJs(600)

  // ③ 空闲询问：等**真实**系统空闲 ≥300s（驱动器每 5s 探测一次；人不动就行）。
  //    最多等 12 分钟；等到拍球徽标 + 面板保留/扣除两张，然后回「保留」并验证解除。
  process.stdout.write('[step] 等待真实系统空闲 ≥300s 以触发空闲询问（最多 12 分钟）\n')
  sendWindow('collapse')
  await sleepJs(600)
  const idleFound = await pollJs(
    `const b=document.querySelector('.ro-ball-badge'); return !!(b && b.classList.contains('ro-idleask'))`,
    12 * 60 * 1000,
    5000,
  )
  SUMMARY.idlePromptTriggered = idleFound
  if (idleFound) {
    await sleepJs(800)
    await shot('stage32-03-idle-ball.png')
    sendWindow('expand')
    const askUi = await pollJs(
      `const s=document.body.textContent; return s.includes('保留') && s.includes('扣除')`,
      8000,
    )
    await sleepJs(600)
    SUMMARY.shots.push({ file: 'data/shots/stage32-03-idle-panel.png', askUi, note: askUi ? null : '面板未检测到保留/扣除文案' })
    await shot('stage32-03-idle-panel.png')
    // 回「保留」并验证徽标解除（与面板按钮同一条上行：timer:idle-resolve keep=true）
    sendUi('timer:idle-resolve', { keep: true })
    const cleared = await pollJs(
      `const b=document.querySelector('.ro-ball-badge'); return !!(b && !b.classList.contains('ro-idleask'))`,
      8000,
    )
    SUMMARY.idleResolvedKeep = cleared
    await sleepJs(500)
  } else {
    SUMMARY.shots.push({ file: null, ok: false, note: '12 分钟内未等到真实系统空闲 300s（期间可能有键鼠活动），空闲询问截图未拍——如实记录，不伪造' })
  }

  // 收尾：停表（加速会话不计入进度）+ 收起
  sendCommand('stop', '')
  await sleepJs(1500)
  sendWindow('collapse')
  await sleepJs(400)

  SUMMARY.ok = SUMMARY.shots.filter((s) => s.file).length >= 4 && SUMMARY.idlePromptTriggered
} catch (err) {
  SUMMARY.error = String((err && err.message) || err)
  process.stderr.write('shots-stage32 失败：' + SUMMARY.error + '\n')
} finally {
  try {
    if (cdp) cdp.close()
  } catch {
    /* 忽略 */
  }
  killOwnElectron()
  await sleep(2000)
  // 确认清干净（kill 失败会让后续验收 fail-closed 退出，所以这里复核）
  // S74c·P0-1：收尾复核同样走 countOrbAll（这里要的是**本机全部**实例数，不是只数自己的）
  SUMMARY.electronLeft = countOrbAll()
  safeWrite(join(PROJECT_ROOT, 'data', 'logs', 'stage32-shots.json'), JSON.stringify(SUMMARY, null, 2))
  process.stdout.write(`summary -> data/logs/stage32-shots.json（ok=${SUMMARY.ok}，electronLeft=${SUMMARY.electronLeft}）\n`)
  process.exit(existsSync(join(SHOTS, 'stage32-01-ball-badge.png')) && SUMMARY.electronLeft === 0 ? 0 : 1)
}
