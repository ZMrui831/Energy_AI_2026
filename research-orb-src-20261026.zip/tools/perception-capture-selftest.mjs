// tools/perception-capture-selftest.mjs
//
// 感知层 S2 · R3 补验：真实 Electron 内的抓屏链路闭环。
//
// 运行方式（必须在 Electron 主进程跑，纯 node 下 desktopCapturer 不可用）：
//   electron.exe tools/perception-capture-selftest.mjs
//   （Electron 44 会清空 ELECTRON_RUN_AS_NODE 的场景由调用方负责——本脚本
//     被 accept-s2-perception.mjs 以清空该变量的环境 spawn。）
//
// 做什么（一次性，自动退出，绝不弹窗/抢前台/发声）：
//   1. 抓 4 帧（间隔 5s，desktopCapturer 全屏缩略图 1920×1080）。
//   2. 每帧 nativeImage.resize 到 256×144 → toBitmap(BGRA) → 灰度 Uint8Array(256*144)。
//   3. 相邻帧 computeDiff → changeScore；按 sampler.decide('normal') 的真实闸门
//      （threshold/minInterval/maxPerMinute 来自 data/perception-config.json）
//      统计"真实原图决策数"。
//   4. 决策命中（或从未命中时做一次显式管道验证）→ 真实 PNG 落盘
//      data/perception/shots/（经 safefs，写审计照旧）。
//   5. 输出 JSON 证据到 data/perception/accept/capture-<ts>.json：
//      frames / scores[] / stats{min,max,mean} / histogram / realDecisions /
//      savedPng / pipelineValidation，然后 app.quit()。
//
// 隐私说明：本脚本只应被验收命令显式触发（R3 要求），抓屏与落盘属验收取证，
// 不改变应用默认 consent=denied 的运行时行为。

import { app, desktopCapturer } from 'electron'
import { join } from 'node:path'

import { PROJECT_ROOT, safeWrite } from '../packages/core/src/safefs.mjs'
import { computeDiff } from '../packages/plugins/perception/diff.mjs'
import { decide } from '../packages/plugins/perception/sampler.mjs'
import { existsSync, readFileSync } from 'node:fs'

const ACCEPT_DIR = join(PROJECT_ROOT, 'data', 'perception', 'accept')
const SHOTS_DIR = join(PROJECT_ROOT, 'data', 'perception', 'shots')
const CONFIG_PATH = join(PROJECT_ROOT, 'data', 'perception-config.json')

const FRAME_COUNT = 4
const FRAME_GAP_MS = 5000

/** nativeImage → 256×144 灰度 Uint8Array（BGRA → Rec.601 luma）。 */
function toGray256x144(img) {
  const small = img.resize({ width: 256, height: 144, quality: 'best' })
  const size = small.getSize()
  const buf = small.toBitmap() // BGRA, 4 bytes/px on win32
  const n = size.width * size.height
  const gray = new Uint8Array(n)
  for (let i = 0; i < n; i++) {
    const b = buf[i * 4]
    const g = buf[i * 4 + 1]
    const r = buf[i * 4 + 2]
    gray[i] = (0.299 * r + 0.587 * g + 0.114 * b) | 0
  }
  return { gray, width: size.width, height: size.height }
}

async function grabFrame() {
  const sources = await desktopCapturer.getSources({
    types: ['screen'],
    thumbnailSize: { width: 1920, height: 1080 },
  })
  if (!sources || sources.length === 0) return null
  return sources[0].thumbnail
}

function statsOf(arr) {
  if (!arr || arr.length === 0) return null
  const min = Math.min(...arr)
  const max = Math.max(...arr)
  const mean = arr.reduce((a, b) => a + b, 0) / arr.length
  return { min: Math.round(min * 1000) / 1000, max: Math.round(max * 1000) / 1000, mean: Math.round(mean * 1000) / 1000 }
}

function histogramOf(arr) {
  const bins = new Array(10).fill(0)
  for (const v of arr || []) {
    const idx = Math.min(9, Math.max(0, Math.floor(v * 10)))
    bins[idx] += 1
  }
  return bins
}

async function main() {
  const result = {
    ts: Date.now(),
    frames: 0,
    scores: [],
    stats: null,
    histogram: null,
    realDecisions: 0,
    decisionTs: [],
    savedPng: null,
    pipelineValidation: false,
    notes: [],
  }

  // 读取真实配置（决策闸门用真实阈值，不放宽）。sampler.decide 的 config 形如
  // { overrides: { normal: { capture: {...} } } }，从 data/perception-config.json 映射。
  let overrides = {}
  try {
    if (existsSync(CONFIG_PATH)) {
      const cfg = JSON.parse(readFileSync(CONFIG_PATH, 'utf8'))
      const nrm = cfg && cfg.intervals && cfg.intervals.normal
      if (nrm) {
        overrides = {
          normal: {
            capture: {
              enabled: nrm.captureEnabled !== false,
              minIntervalMs: Number(nrm.captureMinIntervalMs ?? 60000),
              maxPerMinute: Number(nrm.captureMaxPerMinute ?? 1),
              threshold: Number(nrm.captureThreshold ?? 0.12),
            },
          },
        }
      }
    }
  } catch { overrides = {} }
  if (!overrides.normal) result.notes.push('config 不可读，回落 sampler 内置默认阈值')

  const grays = []
  for (let i = 0; i < FRAME_COUNT; i++) {
    if (i > 0) await new Promise((r) => setTimeout(r, FRAME_GAP_MS))
    const img = await grabFrame()
    if (!img || img.isEmpty()) {
      result.notes.push(`frame ${i}: 抓屏为空`)
      continue
    }
    grays.push({ ts: Date.now(), ...toGray256x144(img), native: img })
    result.frames += 1
  }

  // 相邻帧 diff + 真实闸门决策
  let lastShotTs = 0
  const shotTimes = []
  for (let i = 1; i < grays.length; i++) {
    const a = grays[i - 1]
    const b = grays[i]
    const d = computeDiff(a.gray, b.gray)
    const score = Math.round(d.changeScore * 1000) / 1000
    result.scores.push(score)
    const dec = decide('normal', { changeScore: score }, { overrides })
    const cap = dec.capture || {}
    const gapOk = b.ts - lastShotTs >= (cap.minIntervalMs ?? 0)
    const perMin = shotTimes.filter((t) => b.ts - t < 60000).length
    if (cap.enabled && score > (cap.threshold ?? 1) && gapOk && perMin < (cap.maxPerMinute ?? 0)) {
      result.realDecisions += 1
      result.decisionTs.push(b.ts)
      shotTimes.push(b.ts)
      lastShotTs = b.ts
      // 决策命中 → 真实原图落盘（经 safefs，根内 + 写审计）
      const pngPath = join(SHOTS_DIR, `selftest-${b.ts}.png`)
      try {
        safeWrite(pngPath, b.native.toPNG())
        result.savedPng = pngPath
      } catch (e) {
        result.notes.push(`决策帧落盘失败: ${e && e.message}`)
      }
    }
  }

  // 管道验证：若自然决策从未命中（屏幕确实没变），显式落一张 PNG 证明
  // "抓屏→灰度→diff→落盘"管道端到端可用（标记 pipelineValidation，不冒充自然决策）。
  if (!result.savedPng && grays.length > 0) {
    const last = grays[grays.length - 1]
    const pngPath = join(SHOTS_DIR, `selftest-pipeline-${last.ts}.png`)
    try {
      safeWrite(pngPath, last.native.toPNG())
      result.savedPng = pngPath
      result.pipelineValidation = true
      result.notes.push('自然决策=0（changeScore 分布见上），已显式落一张管道验证帧证明真实落盘链路可用')
    } catch (e) {
      result.notes.push(`管道验证帧落盘失败: ${e && e.message}`)
    }
  }

  result.stats = statsOf(result.scores)
  result.histogram = histogramOf(result.scores)

  const outPath = join(ACCEPT_DIR, `capture-${result.ts}.json`)
  safeWrite(outPath, JSON.stringify(result, null, 2))
  console.log('[capture-selftest] ' + JSON.stringify({ outPath, frames: result.frames, realDecisions: result.realDecisions, stats: result.stats, savedPng: result.savedPng }))
  return { result, outPath }
}

app.whenReady()
  .then(async () => {
    try {
      await main()
      app.exit(0)
    } catch (e) {
      try {
        safeWrite(join(ACCEPT_DIR, `capture-error-${Date.now()}.json`), JSON.stringify({ error: String(e && e.stack || e) }, null, 2))
      } catch { /* 尽力留证 */ }
      console.error('[capture-selftest] 失败:', e && e.message)
      app.exit(1)
    }
  })
