// tools/s6-probe.mjs —— S6 证据闸探针（独立进程；只动 argv 给的 workdir 内自建夹具）。
//
// 独立性（CONTRACT §7）：与被测对象（publish.mjs + 迁移）不同进程、不同路径；
// 数据层闸（S6-2/S6-3/S6-5）用**裸 SQL**验证，不经过 publish.mjs —— 证明强制在数据层。
//
// 用法：
//   node tools/s6-probe.mjs --workdir <dir> [--only S6-2]
// 输出：单行 JSON 到 stdout（{ok, items:[{id, clause, ok, detail, evidence}]}）。

import { mkdirSync, copyFileSync, writeFileSync, readFileSync, rmSync, existsSync } from 'node:fs'
import {join, resolve} from 'node:path'
import { createHash } from 'node:crypto'
import { fileURLToPath } from 'node:url'
import { dirname } from 'node:path'

import { createStore, computeExpiry } from '../packages/core/src/db.mjs'
import {
  DEGRADED_EVIDENCE_COPY, MIGRATION_FILE,
  createClaim, attachEvidence, publishClaim, publishSummary,
  resolveEvidence, claimEvidenceReport, rollbackS6,
} from '../packages/core/src/lifecycle/publish.mjs'

const HERE = dirname(fileURLToPath(import.meta.url))
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MIG_DIR = join(PROJECT_ROOT, 'packages', 'core', 'src', 'db', 'migrations')
const sha256Of = (buf) => createHash('sha256').update(buf).digest('hex')

const argv = process.argv.slice(2)
const arg = (k, d = null) => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : d }
const WORK = arg('--workdir') || join(PROJECT_ROOT, 'data', 'tmp', `s6-probe-${Date.now()}`)
const ONLY = arg('--only')
mkdirSync(WORK, { recursive: true })

const items = []
function report(id, clause, ok, detail, evidence = {}) {
  items.push({ id, clause, ok: !!ok, detail, evidence })
  console.error(`[${ok ? 'PASS' : 'FAIL'}] ${id} (${clause}) ${detail}`)
}

async function freshStore(name, apply = true) {
  const dir = join(WORK, name)
  mkdirSync(dir, { recursive: true })
  const store = await createStore({ driver: 'sqlite', dbPath: join(dir, 'orb.sqlite'), dataDir: dir })
  if (apply) store.initMigrations()
  return { dir, store }
}

async function main() {
  // ---------- S6-1：迁移幂等 + checksum 入账（§7） ----------
  {
    const { dir, store } = await freshStore('fx1', false)
    const migFile = join(MIG_DIR, MIGRATION_FILE)
    const fileSha = sha256Of(readFileSync(migFile))
    const r1 = store.initMigrations()
    const r2 = store.initMigrations()
    const rows = store._db.prepare('SELECT version, checksum FROM schema_migration ORDER BY version').all()
    const ok = r2.applied === 0 && r2.skipped === rows.length && rows.some((r) => r.version === MIGRATION_FILE && r.checksum === fileSha)
    report('S6-1', 'CONTRACT §7 迁移幂等/可重复', ok,
      `首次 applied=${r1.applied}，重复 applied=${r2.applied}/skipped=${r2.skipped}；0002 checksum 与文件一致=${rows.some((r) => r.version === MIGRATION_FILE && r.checksum === fileSha)}`,
      { firstApply: r1, rerun: r2, migrations: rows, migrationFileSha256: fileSha, migrationFile: `packages/core/src/db/migrations/${MIGRATION_FILE}`, dbPath: join(dir, 'orb.sqlite') })
    store.close()
  }

  // ---------- S6-2：数据层闸——裸 SQL 无证据发布被拒（§6） ----------
  {
    const { dir, store } = await freshStore('fx2')
    const db = store._db
    db.prepare("INSERT INTO claim(id, kind, text, evidence_mode, status, created_at) VALUES ('clm-s6-2','observation','S6-2 裸 SQL 发布尝试','direct','draft',?)").run(new Date().toISOString())
    let msg = null
    try {
      db.exec("UPDATE claim SET status = 'published' WHERE id = 'clm-s6-2'")
    } catch (e) { msg = String(e && e.message) }
    const after = db.prepare("SELECT status FROM claim WHERE id = 'clm-s6-2'").get()
    const ok = !!msg && msg.includes('CLAIM_EVIDENCE_REQUIRED') && after.status === 'draft'
    report('S6-2', 'CONTRACT §6 数据层强制（触发器，非应用层 if）', ok,
      `裸 SQL UPDATE → ${msg ? msg.slice(0, 80) : '未抛错'}；发布后 status=${after.status}`,
      { triggerMessage: msg, statusAfter: after.status, via: 'raw SQL（不经过 publish.mjs）' })
    store.close()
  }

  // ---------- S6-3：禁止直插 published（§1.4 状态机） ----------
  {
    const { store } = await freshStore('fx3')
    let msg = null
    try {
      store._db.prepare("INSERT INTO claim(id, kind, text, evidence_mode, status, created_at) VALUES ('clm-s6-3','observation','直插 published','direct','published',?)").run(new Date().toISOString())
    } catch (e) { msg = String(e && e.message) }
    const ok = !!msg && msg.includes('CLAIM_EVIDENCE_DIRECT_INSERT_FORBIDDEN')
    report('S6-3', 'CONTRACT §1.4 claim 必须 draft 创建', ok, `直插 published → ${msg ? msg.slice(0, 80) : '未抛错'}`, { triggerMessage: msg, via: 'raw SQL' })
    store.close()
  }

  // ---------- S6-4：有证据 → 发布成功（§6） ----------
  {
    const { store } = await freshStore('fx4')
    const c = createClaim(store, { id: 'clm-s6-4', kind: 'observation', text: 'S6-4 有证据结论', evidenceMode: 'direct' })
    const sha = 'a'.repeat(64)
    const at = attachEvidence(store, { claimId: 'clm-s6-4', evidenceId: 'ev_rawframe_1_deadbe', layer: 'raw_frame', relation: 'direct', sha256: sha })
    const p = publishClaim(store, 'clm-s6-4')
    const row = store._db.prepare("SELECT status, published_at FROM claim WHERE id = 'clm-s6-4'").get()
    const ok = c.ok && at.ok && p.ok && row.status === 'published' && !!row.published_at && p.evidenceCount === 1
    report('S6-4', 'CONTRACT §6 草稿→证据校验→发布', ok,
      `publishClaim ok=${p.ok} status=${row.status} evidenceCount=${p.evidenceCount} published_at=${row.published_at}`,
      { publish: p, dbRow: row, evidenceSha256: sha })
    store.close()
  }

  // ---------- S6-5：none 证据不得发布（§6，数据层+流程双层） ----------
  {
    const { store } = await freshStore('fx5')
    createClaim(store, { id: 'clm-s6-5', kind: 'manual', text: 'S6-5 无证据结论', evidenceMode: 'none' })
    attachEvidence(store, { claimId: 'clm-s6-5', evidenceId: 'ev_none_1', layer: 'audit', relation: 'none' })
    const p = publishClaim(store, 'clm-s6-5')
    let sqlMsg = null
    try {
      store._db.exec("UPDATE claim SET status = 'published' WHERE id = 'clm-s6-5'")
    } catch (e) { sqlMsg = String(e && e.message) }
    const after = store._db.prepare("SELECT status FROM claim WHERE id = 'clm-s6-5'").get()
    const blocked = store._db.prepare("SELECT COUNT(*) n FROM audit_event WHERE kind = 'publish-blocked' AND metadata_json LIKE '%clm-s6-5%'").get().n
    const ok = p.ok === false && p.code === 'E_NONE_EVIDENCE' && !!sqlMsg && sqlMsg.includes('CLAIM_EVIDENCE_REQUIRED') && after.status === 'draft' && blocked >= 1
    report('S6-5', 'CONTRACT §6 none 不得进正式结论', ok,
      `publishClaim code=${p.code}；裸 SQL 亦被触发器拒（${sqlMsg ? sqlMsg.slice(0, 40) : 'null'}）；status=${after.status}；publish-blocked 审计=${blocked}`,
      { publish: p, sqlTrigger: sqlMsg, statusAfter: after.status, blockedAudits: blocked })
    store.close()
  }

  // ---------- S6-6：summary 发布闸（§6） ----------
  {
    const { store } = await freshStore('fx6')
    store.insertSummary({ id: 'sum-s6-6', content: 'S6-6 summary 草稿', status: 'draft' })
    const b1 = publishSummary(store, 'sum-s6-6')
    const draftStill = store._db.prepare("SELECT status FROM summary WHERE id = 'sum-s6-6'").get().status
    store._db.prepare("INSERT INTO summary_evidence(summary_id, evidence_id, layer, relation, sha256, created_at) VALUES ('sum-s6-6','ev_rawframe_9_cafe','raw_frame','direct',?,?)")
      .run('b'.repeat(64), new Date().toISOString())
    const p2 = publishSummary(store, 'sum-s6-6')
    const after = store._db.prepare("SELECT status FROM summary WHERE id = 'sum-s6-6'").get().status
    const ok = b1.ok === false && b1.code === 'CLAIM_EVIDENCE_REQUIRED' && draftStill === 'draft' && p2.ok && after === 'published'
    report('S6-6', 'CONTRACT §6 summary 发布必须有证据', ok,
      `缺证据：code=${b1.code} 且停在 ${draftStill}；补证据后：ok=${p2.ok} status=${after}`,
      { blocked: b1, published: p2, statusAfter: after })
    store.close()
  }

  // ---------- S6-7：删除后的诚实性（§6/§2） ----------
  {
    const { dir, store } = await freshStore('fx7')
    const shot = join(dir, 'frame.png')
    writeFileSync(shot, 'PNGFIXTURE-S6-7')
    const sha = sha256Of(readFileSync(shot))
    const nowIso = new Date().toISOString()
    store.insertRawFrame({ id: 'rf-s6-7', file_path: shot, sha256: sha, sensitivity: 'normal', created_at: nowIso, expires_at: computeExpiry('normal', 'learning', undefined, Date.parse(nowIso)) })
    createClaim(store, { id: 'clm-s6-7', kind: 'perception', text: 'S6-7 引用原图的结论', evidenceMode: 'direct' })
    attachEvidence(store, { claimId: 'clm-s6-7', evidenceId: 'rf-s6-7', layer: 'raw_frame', relation: 'direct', sha256: sha })
    const p = publishClaim(store, 'clm-s6-7')
    const before = resolveEvidence(store, 'rf-s6-7')
    // 清理：删文件 + 行转 deleted（S3 cleaner 同口径）
    rmSync(shot, { force: true })
    store.setRawFrameStatus('rf-s6-7', 'deleted')
    const after = resolveEvidence(store, 'rf-s6-7')
    const rep = claimEvidenceReport(store, 'clm-s6-7')
    const ok = p.ok && before.status === 'available' && after.status === 'deleted' && after.label === DEGRADED_EVIDENCE_COPY && after.sha256 === sha && rep.degraded === true
    report('S6-7', 'CONTRACT §6/§2 删除后仍可回指 + 固定降级文案', ok,
      `清理前=${before.status}；清理后=${after.status}，label="${after.label.slice(0, 24)}…"，sha256 保留=${after.sha256 === sha}`,
      { publish: p, before, after, reportDegraded: rep.degraded, fixedCopy: DEGRADED_EVIDENCE_COPY })
    store.close()
  }

  // ---------- S6-8：迁移安全（checksum 篡改 fail-closed）+ 回滚/重升级（§7） ----------
  {
    // 8a 篡改：复制一份迁移目录，改 0002 内容 → 对已应用 0002 的库 initMigrations 必须整体拒绝
    const { dir, store } = await freshStore('fx8a')
    const migCopy = join(dir, 'migrations')
    mkdirSync(migCopy, { recursive: true })
    for (const f of ['0001_init.sql', MIGRATION_FILE]) copyFileSync(join(MIG_DIR, f), join(migCopy, f))
    const before = store._db.prepare('SELECT COUNT(*) n FROM schema_migration').get().n
    const claimTablesBefore = store._db.prepare("SELECT COUNT(*) n FROM sqlite_master WHERE type='table' AND name='claim'").get().n
    writeFileSync(join(migCopy, MIGRATION_FILE), readFileSync(join(migCopy, MIGRATION_FILE), 'utf8') + '\n-- 篡改：S6 验收用')
    let msg = null
    try { store.initMigrations(migCopy) } catch (e) { msg = `${(e && e.code) || ''} ${String(e && e.message)}` }
    const after = store._db.prepare('SELECT COUNT(*) n FROM schema_migration').get().n
    const ok = !!msg && (msg.includes('E_MIGRATION_CHECKSUM')) && after === before && claimTablesBefore === 1
    report('S6-8a', 'CONTRACT §7 校验失败整体拒绝，不半途改库', ok,
      `篡改后 initMigrations → ${msg ? msg.slice(0, 60) : '未抛错'}；migration 行数 ${before}→${after}；claim 表仍存在=${claimTablesBefore === 1}`,
      { triggerMessage: msg, migrationsBefore: before, migrationsAfter: after, via: 'raw SQL' })

    // 8b 回滚 + 重升级
    const rb = rollbackS6(store)
    const claimGone = store._db.prepare("SELECT COUNT(*) n FROM sqlite_master WHERE type='table' AND name='claim'").get().n === 0
    const migGone = store._db.prepare('SELECT COUNT(*) n FROM schema_migration WHERE version = ?').get(MIGRATION_FILE).n === 0
    const re = store.initMigrations() // 重升级（原目录，未篡改）
    const claimBack = store._db.prepare("SELECT COUNT(*) n FROM sqlite_master WHERE type='table' AND name='claim'").get().n === 1
    const okB = rb.ok && claimGone && migGone && re.applied >= 1 && claimBack
    report('S6-8b', 'CONTRACT §7 升级/回滚路径可重复', okB,
      `rollback ok=${rb.ok}（claim 表消失=${claimGone}，账本登记消失=${migGone}）；重升级 applied=${re.applied}，claim 表恢复=${claimBack}`,
      { rollback: rb, reapply: re, claimTableRestored: claimBack })
    store.close()
  }

  const okAll = items.every((i) => i.ok)
  // stdout 只出**一行紧凑 JSON**（父进程按行解析；人类可读进度在 stderr）
  process.stdout.write(JSON.stringify({ ok: okAll, workdir: WORK, items }) + '\n')
  process.exit(okAll ? 0 : 1)
}

main().catch((e) => {
  process.stdout.write(JSON.stringify({ ok: false, fatal: String((e && e.stack) || e), items }) + '\n')
  process.exit(2)
})
