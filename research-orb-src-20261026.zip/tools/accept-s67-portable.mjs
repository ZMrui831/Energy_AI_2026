// tools/accept-s67-portable.mjs
//
// S67·1-B 验收：硬编码绝对路径 → 可移植（换机即生效）+ fail-closed 保护不失效
//
// 纪律：绝不假绿；自报数字需在干净 shell 复跑得到。
// 隔离：ORB_DATA_DIR / ORB_LOG_DIR 整体挪到临时目录，真实 data 零写入。
//
// 用法：node tools/accept-s67-portable.mjs

import { mkdtempSync, existsSync, readFileSync, rmSync, readdirSync, statSync } from 'node:fs'
import { tmpdir, homedir } from 'node:os'
import { join, isAbsolute } from 'node:path'

// 隔离必须在静态 import 之前设定（safefs 在加载时解析 DATA_DIR）。
const TEST_DATA = mkdtempSync(join(tmpdir(), 'orb-s67-portable-'))
process.env.ORB_DATA_DIR = TEST_DATA
process.env.ORB_LOG_DIR = join(TEST_DATA, 'logs')

const items = []
const addItem = (id, ok, detail = '', evidence = {}) => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300), evidence })
  console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`)
  return ok
}

// 递归收集 .mjs（跳过 node_modules / data / docs / .git / dist / .venv 及 accept-s67 自检脚本自身）
function collectMjs(dir, out = []) {
  let entries = []
  try { entries = readdirSync(dir) } catch { return out }
  for (const e of entries) {
    if (e === 'node_modules' || e === 'data' || e === 'docs' || e === '.git' || e === 'dist' || e === '.venv') continue
    const p = join(dir, e)
    let st
    try { st = statSync(p) } catch { continue }
    if (st.isDirectory()) collectMjs(p, out)
    else if (e.endsWith('.mjs') && !/accept-s67/.test(e)) out.push(p)
  }
  return out
}

// 收集 tools/check-*.mjs（1-B 实际改动的护栏脚本）。
// 排除 check-anonymity / check-submission：它们本身就是匿名护栏，必须以检测词
// （54958 / explorer）作为 deny 词表，属"检测目标"而非"硬编码路径"，不在 1-B 范围内。
function collectCheckTools(toolsDir) {
  let entries = []
  try { entries = readdirSync(toolsDir) } catch { return [] }
  return entries
    .filter((e) => /^check-.*\.mjs$/.test(e) && !/check-anonymity|check-submission/.test(e))
    .map((e) => join(toolsDir, e))
}

// 剥离块注释与行注释后，搜索硬编码痕迹（注释里的说明不算）。
function hasHardcodeInCode(file) {
  let text
  try { text = readFileSync(file, 'utf8') } catch { return false }
  let stripped = text.replace(/\/\*[\s\S]*?\*\//g, '') // 块注释
  stripped = stripped.replace(/(^|[^:])\/\/.*$/gm, '$1') // 行注释（保留 http(s):// 之前的部分）
  return /54958|explorer!/i.test(stripped) /* allow-hardcoded: 脱敏检测词表/基准，非路径引用 */
}

async function main() {
  const { PROJECT_ROOT } = await import('../packages/core/src/safefs.mjs')
  const { DEFAULT_DENY_ROOTS, createPolicy, evaluate, normalizePath } = await import('../packages/core/src/tools/permissions.mjs')

  // P1：PROJECT_ROOT 从模块位置推导 + 自校验锚点存在（换目录即生效的核心）
  const anchor = join(PROJECT_ROOT, 'packages', 'core', 'src', 'safefs.mjs')
  addItem('P1 PROJECT_ROOT 自校验锚点存在(换目录生效基础)',
    isAbsolute(PROJECT_ROOT) && existsSync(anchor),
    `PROJECT_ROOT=${PROJECT_ROOT} 锚点存在=${existsSync(anchor)}`)

  // P2：safefs.mjs 源码（非注释）无硬编码 explorer!/54958 —— 证明 PROJECT_ROOT 非写死
  const sf = join(PROJECT_ROOT, 'packages', 'core', 'src', 'safefs.mjs')
  const sfClean = !hasHardcodeInCode(sf)
  addItem('P2 safefs.mjs 源码无硬编码 explorer!/54958(换目录生效前提)', /* allow-hardcoded: 脱敏检测词表/基准，非路径引用 */
    sfClean, `safefs.mjs 含硬编码=${sfClean ? '否' : '是'}`)

  // P3：DEFAULT_DENY_ROOTS 改用 os.homedir() 动态生成；源码无明文用户名
  const hasHome = DEFAULT_DENY_ROOTS.some((r) => r.startsWith(homedir()))
  const perm = join(PROJECT_ROOT, 'packages', 'core', 'src', 'tools', 'permissions.mjs')
  const permClean = !hasHardcodeInCode(perm)
  addItem('P3 DEFAULT_DENY_ROOTS 动态 homedir(源码无硬编码用户名)',
    hasHome && permClean,
    `含homedir项=${hasHome} 源码无硬编码=${permClean} 共${DEFAULT_DENY_ROOTS.length}项`)

  // 装配策略用于路径判定（真实 evaluate 逻辑）
  const policy = createPolicy()

  // P4：越界路径（不在任何授权根）一律 E_OUTSIDE_ROOTS 拒（越界仍拒）
  const outside = normalizePath('C:\\notallowed-by-policy\\x.txt')
  const r4 = evaluate({ toolId: 'fs.read', targets: [outside], policy })
  addItem('P4 越界路径 E_OUTSIDE_ROOTS 拒绝',
    r4.decision === 'deny' && r4.code === 'E_OUTSIDE_ROOTS',
    `${r4.code}:${r4.reason}`)

  // P5：拒绝根前缀拒 —— 含不存在子路径仍拒（fail-closed，绝不因"目录不存在"而放行）
  const denyTarget = join(homedir(), '.ssh', 'this-key-does-not-exist-' + Date.now())
  const r5 = evaluate({ toolId: 'fs.read', targets: [denyTarget], policy })
  addItem('P5 拒绝根前缀拒(含不存在子路径, fail-closed)',
    r5.decision === 'deny' && r5.code === 'E_ROOT_DENIED',
    `${r5.code}:${r5.reason}`)

  // P6：源码（packages + tools/check-*，非注释处）无硬编码 explorer!/54958（1-B 实际改动范围）
  const files = [...collectMjs(join(PROJECT_ROOT, 'packages')), ...collectCheckTools(join(PROJECT_ROOT, 'tools'))]
  const bad = files.filter(hasHardcodeInCode)
  addItem('P6 源码非注释处无硬编码 explorer!/54958', /* allow-hardcoded: 脱敏检测词表/基准，非路径引用 */
    bad.length === 0, bad.length ? `命中:${bad.slice(0, 5).join(' / ')}` : `扫描 ${files.length} 个 .mjs 文件，无命中`)

  // 清理临时目录
  try { rmSync(TEST_DATA, { recursive: true, force: true }) } catch { /* ignore */ }

  const pass = items.every((i) => i.ok)
  console.log(`\n[S67·1-B portable] ${items.filter((i) => i.ok).length}/${items.length} 通过 ${pass ? 'OK' : 'FAILED'}`)
  process.exit(pass ? 0 : 1)
}

main().catch((e) => { console.error('[accept-s67-portable] 异常:', e); process.exit(2) })
