// tools/accept-s58-budget.mjs —— S58 P0-1/P0-2/P0-3/P1 验收（≥12 项）
//
// 判据要点：阈值相对基线（base×2.5/2）、内存只做 3000MB 极值兜底、**本机 level===0**、
//          actions 不含 disable-visual-model、budget 审计含 metrics、诊断 fired 可见、
//          baseline 无 BOM、6648 条会话首屏 <300ms。
// 用法：node tools\accept-s58-budget.mjs

import { mkdtempSync, rmSync, mkdirSync, writeFileSync, readFileSync, existsSync, openSync, writeSync, closeSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'

const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 320) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s58-b-'))
process.env.ORB_DATA_DIR = join(tmpRoot, 'data')
mkdirSync(join(tmpRoot, 'data', 'logs'), { recursive: true })

try {
  const B = await import('../packages/core/src/budget.mjs')
  const BL = await import('../packages/core/src/budget-baseline.mjs')

  // B-1 阈值 = base × 系数
  const th = B.thresholdsFromBaseline({ cpuP95: 10, cpuAvg: 2, memMB: 500 })
  check('B-1 阈值相对基线（cpuP95=base×2.5、cpuAvg=base×2）', th.cpuP95 === 25 && th.cpuAvg === 4, JSON.stringify({ cpuP95: th.cpuP95, cpuAvg: th.cpuAvg }))

  // B-2 下限保护（基线采到 0）
  const th0 = B.thresholdsFromBaseline({ cpuP95: 0, cpuAvg: 0, memMB: 0 })
  check('B-2 阈值下限保护（基线 0 → cpuP95 1.5 / cpuAvg 0.8，不会永远触发）', th0.cpuP95 === 1.5 && th0.cpuAvg === 0.8, JSON.stringify({ cpuP95: th0.cpuP95, cpuAvg: th0.cpuAvg }))

  // B-3 内存只做极值兜底
  const lv2900 = B.diagnoseBudget({ cpuAvg: 3, cpuP95: 12, memMB: 2900 }, { thresholds: th }).level
  const lv3001 = B.diagnoseBudget({ cpuAvg: 3, cpuP95: 12, memMB: 3001 }, { thresholds: th }).level
  check('B-3 内存极值兜底（2900MB 不降级；3001MB 直达 L5）', lv2900 === 0 && lv3001 === 5, JSON.stringify({ lv2900, lv3001, cap: B.MEM_ABS_CAP_MB }))

  // B-4 本机真实 metrics → level===0（硬指标）
  const { sampleHostMetrics } = await import('../packages/plugins/perception/metrics.mjs')
  const real = await sampleHostMetrics({ cmdlineMatch: 'research-orb', iterations: 4, intervalMs: 400 }).catch(() => null)
  const realLevel = real ? B.diagnoseBudget(real, { thresholds: B.thresholdsFromBaseline({ cpuP95: real.cpuP95, cpuAvg: real.cpuAvg, memMB: real.memMB }) }).level : -1
  const fallbackLevel = real ? B.diagnoseBudget(real, { thresholds: B.FALLBACK_THRESHOLDS }).level : -1
  check('B-4 本机 level===0（相对基线 + 宽松兜底两条路都为 0）', !!real && realLevel === 0 && fallbackLevel === 0,
    JSON.stringify({ metrics: real, realLevel, fallbackLevel }))

  // B-5 actions 不含 disable-visual-model（全 7 级）
  const allActions = []
  for (let lv = 1; lv <= B.MAX_LEVEL; lv++) allActions.push(...B.actionsFor(lv))
  const srcBudget = readFileSync(join(PROJECT_ROOT, 'packages', 'core', 'src', 'budget.mjs'), 'utf8')
  check('B-5 actions 不含 disable-visual-model（运行时 + 源码双检）',
    !allActions.includes('disable-visual-model') && !/['"]disable-visual-model['"]/.test(srcBudget.replace(/\/\/.*$/gm, '')),
    JSON.stringify({ actions: [...new Set(allActions)] }))

  // B-6 budget 审计含 metrics（源码：_sampleBudget 写 metrics + thresholds + fired）
  const srcPerc = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'perception', 'index.mjs'), 'utf8')
  const hasAuditMetrics = /kind: 'budget'[\s\S]{0,400}metrics,/.test(srcPerc) && /kind: 'budget'[\s\S]{0,400}thresholds,/.test(srcPerc)
  check('B-6 budget 审计含 metrics + thresholds + fired（不再只报 level）', hasAuditMetrics, hasAuditMetrics ? 'yes' : 'no')

  // B-7 诊断 fired 数组（7 项、与 level 自洽、可定位到具体级）
  const dg = B.diagnoseBudget({ cpuAvg: 10, cpuP95: 40, memMB: 500 }, { thresholds: th })
  check('B-7 诊断 fired 7 项且 level = 最高 fired 级',
    dg.fired.length === 7 && dg.level === 2 && dg.fired[0].fired === true && dg.fired[1].fired === true && dg.fired[2].fired === false,
    JSON.stringify({ level: dg.level, fired: dg.fired }))

  // B-8 baseline 写出无 BOM（首字节不是 EF BB BF）
  const bpath = join(tmpRoot, 'data', 'baseline-test.json')
  const written = BL.writeBaseline({ cpuP95: 8.5, cpuAvg: 1.2, memMB: 480, samples: 12 }, bpath)
  const buf = readFileSync(bpath)
  const noBom = !(buf[0] === 0xef && buf[1] === 0xbb && buf[2] === 0xbf)
  const parsed = JSON.parse(buf.toString('utf8'))
  check('B-8 baseline.json 无 BOM UTF-8 且可解析', !!written && noBom && parsed.cpuP95 === 8.5 && typeof parsed.at === 'number',
    JSON.stringify({ noBom, keys: Object.keys(parsed) }))

  // B-9 baseline 过期 → null（7 天 TTL）
  const stale = BL.readBaseline(bpath, Date.now() + 8 * 24 * 3600 * 1000)
  const fresh = BL.readBaseline(bpath)
  check('B-9 基线 TTL（8 天后视为过期 → null；当次可读）', stale === null && !!fresh, JSON.stringify({ stale: stale === null, fresh: !!fresh }))

  // B-10 collectBaseline 聚合（P95 用分位而非均值）
  const fake = { i: 0 }
  const col = await BL.collectBaseline({
    sample: async () => { fake.i += 1; const v = [1, 2, 3, 4, 100][fake.i % 5]; return { cpuP95: v, cpuAvg: 2, memMB: 400 + v } },
    times: 5, intervalMs: 1,
  })
  check('B-10 基采样聚合（P95 取分位数，不被峰值拉平）', !!col && col.samples === 5 && col.cpuP95 === 100 && col.memMB > 400,
    JSON.stringify(col))

  // B-11 6648 条会话：首屏 50 条 <300ms（两阶段扫描）
  const sessDir = join(tmpRoot, 'data', 'sessions')
  mkdirSync(sessDir, { recursive: true })
  const line = (id, i) => [
    JSON.stringify({ type: 'session', id, createdAt: new Date().toISOString(), title: '会话 ' + i, provider: 'p', model: 'm' }),
    JSON.stringify({ type: 'user', ts: Date.now(), seq: 1, text: '内容 ' + i }),
    JSON.stringify({ type: 'assistant', ts: Date.now(), seq: 2, text: '回复' }),
  ].join('\n') + '\n'
  for (let i = 0; i < 6648; i++) {
    const id = 's-perf-' + String(i).padStart(4, '0')
    const p = join(sessDir, id + '.jsonl')
    const fd = openSync(p, 'w')
    writeSync(fd, line(id, i))
    closeSync(fd)
  }
  const SI = await import('../packages/core/src/session-index.mjs')
  const t0 = Date.now()
  const page = SI.scanSessions({ dir: sessDir, offset: 0, pageSize: 50 })
  const cost = Date.now() - t0
  check('B-11 6648 条会话首屏 50 条 <300ms（两阶段扫描：只读窗口文件头部）',
    page.ok && page.items.length === 50 && page.total === 200 && page.hasMore === true && cost < 300,
    JSON.stringify({ costMs: cost, items: page.items.length, total: page.total }))

  // B-12 level 0 时视觉可用（extract 无条件写 sent-to-model；无视觉降级动作）
  const srcExtract = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'extract.mjs'), 'utf8')
  const sentAuditUnconditional = /S56：sent-to-model 真审计[\s\S]{0,500}kind: 'sent-to-model'/.test(srcExtract)
  check('B-12 level 0 时视觉可用（sent-to-model 审计无条件写出，无视觉降级路径）',
    sentAuditUnconditional && !/disable-visual-model/.test(srcExtract), JSON.stringify({ sentAuditUnconditional }))
} catch (e) {
  check('B-0 验收异常', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}
const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s58-budget: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exitCode = items.length - pass === 0 ? 0 : 1
