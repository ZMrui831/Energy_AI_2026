// tools/accept-s33-logdir.mjs —— S33·C 测试日志隔离验收（≥6 项）。
// 单行复跑：node tools\accept-s33-logdir.mjs
// 证据：data\logs\s33-logdir-accept.json
//
// 覆盖：子进程在 ORB_LOG_DIR 下写日志（temp 增长）/ 真实 data/logs 行数不变 /
//      audit-preflight 前后均通过（不受测试影响）/ 反例：ORB_LOG_DIR 指真实目录必须告警 /
//      run-tests 接线（设 env + 清残留 + 打印行数 + 不删除）/ safefs 导出 LOG_DIR 跟随 env。
import { spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { pathToFileURL } from 'node:url'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { auditPreflight } from '../packages/plugins/coach/audit-preflight.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 260), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const REAL_LOGS = join(PROJECT_ROOT, 'data', 'logs')
const WRITER = join(PROJECT_ROOT, 'tools', '_probe-logdir-writer.mjs')
const RUN_TESTS = join(PROJECT_ROOT, 'tools', 'run-tests.mjs')

function countJsonl(dir) {
  const out = {}
  if (!existsSync(dir)) return out
  for (const f of readdirSync(dir)) {
    if (!f.endsWith('.jsonl')) continue
    try { out[f] = readFileSync(join(dir, f), 'utf8').split('\n').filter(Boolean).length } catch { out[f] = -1 }
  }
  return out
}
function runWriter(envLogDir, n = 7) {
  return spawnSync(process.execPath, [WRITER, String(n)], {
    cwd: PROJECT_ROOT,
    env: { ...process.env, ORB_LOG_DIR: envLogDir },
    encoding: 'utf8',
  })
}

const isoDir = join(tmpdir(), `orb-accept-logdir-${process.pid}`)
try {
  rmSync(isoDir, { recursive: true, force: true })

  // 前置：preflight 通过（真实日志本身健康）
  let preOk = false
  try { preOk = auditPreflight().ok === true } catch { preOk = false }

  const before = countJsonl(REAL_LOGS)
  const child = runWriter(isoDir, 7)
  const after = countJsonl(REAL_LOGS)

  // C1：子进程按 ORB_LOG_DIR 写（stdout 里 LOG_DIR == isoDir，且 exit 0）
  let meta = null
  try { meta = JSON.parse(String(child.stdout || '').trim().split('\n').pop()) } catch { meta = null }
  const logDirMatches = meta && String(meta.LOG_DIR).toLowerCase() === isoDir.toLowerCase()
  check('C1', child.status === 0 && logDirMatches, `exit=${child.status} child.LOG_DIR=${meta && meta.LOG_DIR}`, { stdout: String(child.stdout || '').slice(0, 160) })

  // C2：临时目录确实新增了行
  const tempFile = meta ? meta.file : join(isoDir, 'probe-logdir.jsonl')
  let tempLines = 0
  try { tempLines = readFileSync(tempFile, 'utf8').split('\n').filter(Boolean).length } catch { tempLines = 0 }
  check('C2', tempLines === 7, `temp=${tempFile.split(/[\\/]/).pop()} lines=${tempLines}/7`)

  // C3：真实 data/logs 行数不变（逐文件对比）
  const changed = Object.keys({ ...before, ...after }).filter((k) => (before[k] || 0) !== (after[k] || 0))
  check('C3', changed.length === 0, `realFiles=${Object.keys(before).length} changed=${changed.join(',') || '无'}`, { changed })

  // C4：audit-preflight 前后均通过（测试期不被影响）
  let postOk = false
  try { postOk = auditPreflight().ok === true } catch { postOk = false }
  check('C4', preOk && postOk, `pre=${preOk} post=${postOk}`)

  // C5：反例——ORB_LOG_DIR 指真实目录必须告警（只 import 不写，避免污染真实日志）
  const safefsUrl = pathToFileURL(join(PROJECT_ROOT, 'packages', 'core', 'src', 'safefs.mjs')).href
  const bad = spawnSync(process.execPath, ['--input-type=module', '-e', `import(${JSON.stringify(safefsUrl)}).then(()=>console.log('ok'))`], {
    cwd: PROJECT_ROOT,
    env: { ...process.env, ORB_LOG_DIR: REAL_LOGS },
    encoding: 'utf8',
  })
  const warn = String(bad.stderr || '') + String(bad.stdout || '')
  check('C5', /警告/.test(warn) && /ORB_LOG_DIR/.test(warn), `stderr含告警=${/警告/.test(warn)}`, { stderr: String(bad.stderr || '').slice(0, 200) })

  // C6：run-tests 接线（设 env / 清残留 / 打印行数 / 不删除）
  const rt = readFileSync(RUN_TESTS, 'utf8')
  const setsEnv = /process\.env\.ORB_LOG_DIR\s*=/.test(rt)
  const usesClean = /cleanResidue\s*\(/.test(rt)
  const prints = /行数/.test(rt)
  const notDelete = !/rmSync\(\s*isoLogDir/.test(rt) && !/rmSync\(isoLogDir/.test(rt)
  check('C6', setsEnv && usesClean && prints && notDelete, `setEnv=${setsEnv} clean=${usesClean} print=${prints} notDelete=${notDelete}`)

  // C7：safefs 导出 LOG_DIR 跟随 env（子进程已打印，再断言字段存在）
  check('C7', !!meta && typeof meta.WRITES_LOG === 'string' && String(meta.WRITES_LOG).startsWith(isoDir), `WRITES_LOG=${meta && meta.WRITES_LOG}`, {})
} catch (e) {
  check('X0', false, '未捕获异常：' + String((e && e.message) || e))
} finally {
  try { rmSync(isoDir, { recursive: true, force: true }) } catch { /* 尽力 */ }
}

const pass = items.filter((i) => i.ok).length
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(join(PROJECT_ROOT, 'data', 'logs', 's33-logdir-accept.json'), JSON.stringify({ items, pass, total: items.length }, null, 2) + '\n', 'utf8')
console.log(`\n  # accept-s33-logdir: total=${items.length} pass=${pass} fail=${items.length - pass}`)
console.log('  # 证据 -> data/logs/s33-logdir-accept.json')
process.exit(pass === items.length ? 0 : 1)
