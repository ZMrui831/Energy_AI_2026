#!/usr/bin/env node
// tools/probe-stage3-1.mjs —— 阶段 3.1 验收②的加速/真实对照探针
//
// 用法（父进程传环境变量，本脚本不自己设）：
//   node tools/probe-stage3-1.mjs fast     # RESEARCH_ORB_TIME_SCALE=60：1 分钟番茄 ~1.3 秒真实走完
//   node tools/probe-stage3-1.mjs real     # 不设（或 =1）：真实等 ~3.5 秒
//
// 为什么用子进程：readTimeScale 在 core-host 里进程级读一次缓存，同进程改 env 无效；
// 两个场景各起一个"进程"，本身也是"加速只是参数、两条路径共用一套代码"的证明。
//
// 输出：stdout 逐行日志，最后一行是 JSON 摘要（父进程 parse 最后一行）。

import { createCoreHost } from '../apps/desktop/core-host.mjs'

const scenario = process.argv[2] || 'real'
const sleepMs = scenario === 'fast' ? 1300 : 3500

const host = createCoreHost()
const reg = host.registry
await reg.enableAll()

const t0 = Date.now()
const startRes = await reg.runCommand('start', '1') // 1 分钟番茄
if (!startRes.ok) {
  console.log(JSON.stringify({ scenario, error: 'start failed: ' + startRes.error }))
  process.exit(1)
}
const startText = (startRes.value && startRes.value.text) || ''
const scaleWarn = startText.includes('加速测试模式')

await new Promise((r) => setTimeout(r, sleepMs))

const stopRes = await reg.runCommand('stop', '')
if (!stopRes.ok) {
  console.log(JSON.stringify({ scenario, error: 'stop failed: ' + stopRes.error }))
  process.exit(1)
}
const realMs = Date.now() - t0

// 从账本按 sessionId 汇总本段落账（不拿全天总额冒充）
const dayKey = (startRes.value.ui && startRes.value.ui.snapshot && startRes.value.ui.snapshot.dayKey) || null
const dk = dayKey || new Date().toISOString().slice(0, 10)
const records = host.timerStore.readDay(dk)
const sessionId = startRes.value.ui.snapshot.sessionId
const mine = records.filter((r) => r.sessionId === sessionId)
const ledgerSec = mine.filter((r) => r.type === 'segment').reduce((s, r) => s + (Number(r.sec) || 0), 0)
const stopRow = mine.find((r) => r.type === 'stop')

console.log(
  JSON.stringify({
    scenario,
    timeScale: host.timeScale,
    startOk: true,
    stopOk: true,
    sessionId,
    dayKey: dk,
    plannedSec: startRes.value.ui.snapshot.plannedSec,
    realMs,
    ledgerSec,
    stopTotalSec: stopRow ? stopRow.totalSec : null,
    stopCompleted: stopRow ? stopRow.completed : null,
    scaleWarn,
    startTextHasScale: scaleWarn,
  }),
)
await host.dispose()
process.exit(0)
