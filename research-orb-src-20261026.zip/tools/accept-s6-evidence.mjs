// tools/accept-s6-evidence.mjs —— S6 证据闸验收（父进程）。
//
// CONTRACT §7：验收不得由实现者自证 —— 探针（tools/s6-probe.mjs）以**独立子进程**跑，
// 夹具库在**独立路径**（data/tmp/s6-accept-<ts>/…，与生产 data/db/orb.sqlite 不同库）；
// 数据层闸场景（S6-2/3/5/8a）用裸 SQL 验证，不经过 publish.mjs。
// 父进程只做：建 workdir → 起探针 → 校验 JSON → 产物 sha256 → 写机器可读证据。
//
// 单行复跑（唯一入口）：
//   node tools/run-isolated.mjs --label s6 --cmd "node tools/accept-s6-evidence.mjs"
// 单场景复跑（每条验收的细粒度命令）：
//   node tools/s6-probe.mjs --workdir <tmp> --only S6-2

import { spawnSync } from 'node:child_process'
import { createHash } from 'node:crypto'
import { mkdirSync, readFileSync, writeFileSync, existsSync, rmSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT, logPath } from '../packages/core/src/safefs.mjs'

const sha = (p) => createHash('sha256').update(readFileSync(p)).digest('hex')
const nowTag = new Date().toISOString().replace(/[:.]/g, '-')
const WORK = join(PROJECT_ROOT, 'data', 'tmp', `s6-accept-${nowTag}`)
mkdirSync(WORK, { recursive: true })

const CLAUSES = {
  'S6-1': '§7 迁移幂等/可重复执行 + checksum 入账',
  'S6-2': '§6 数据层强制：无证据结论不得发布（触发器 CLAIM_EVIDENCE_REQUIRED）',
  'S6-3': '§1.4 claim 必须 draft 创建（禁直插 published）',
  'S6-4': '§6 草稿→证据校验→发布（有证据可发布）',
  'S6-5': '§6 none 证据不得进正式结论（流程+数据层双层）',
  'S6-6': '§6 summary 发布必须有证据',
  'S6-7': '§6/§2 原图清理后结论仍可回指 + 固定降级文案',
  'S6-8a': '§7 迁移 checksum 校验失败整体拒绝（fail-closed）',
  'S6-8b': '§7 升级/回滚路径可重复',
}

// 前置状态（显式）：生产库不参与；探针自建夹具（sqlite driver）。
const PRE_STATE = {
  productionDbUntouched: true,
  fixture: '探针在独立 workdir 自建 sqlite 夹具库（0001+0002 新库）',
  workdir: WORK,
}

function main() {
  const r = spawnSync(process.execPath, [join(PROJECT_ROOT, 'tools', 's6-probe.mjs'), '--workdir', WORK], {
    encoding: 'utf8', timeout: 180_000, cwd: PROJECT_ROOT,
  })
  let probe = null
  try {
    const line = String(r.stdout || '').trim().split('\n').filter(Boolean).pop()
    probe = JSON.parse(line)
  } catch { probe = null }

  const artifacts = [
    { path: 'packages/core/src/db/migrations/0002_claim_evidence.sql', sha256: sha(join(PROJECT_ROOT, 'packages/core/src/db/migrations/0002_claim_evidence.sql')) },
    { path: 'packages/core/src/lifecycle/publish.mjs', sha256: sha(join(PROJECT_ROOT, 'packages/core/src/lifecycle/publish.mjs')) },
    { path: 'tools/s6-probe.mjs', sha256: sha(join(PROJECT_ROOT, 'tools', 's6-probe.mjs')) },
    { path: 'tools/accept-s6-evidence.mjs', sha256: sha(join(PROJECT_ROOT, 'tools', 'accept-s6-evidence.mjs')) },
  ]

  const out = {
    label: 's6-evidence-gate',
    ts: new Date().toISOString(),
    verdict: null,
    preState: PRE_STATE,
    rerun: 'node tools/run-isolated.mjs --label s6 --cmd "node tools/accept-s6-evidence.mjs"',
    independence: {
      mode: 'different-process + different-path',
      detail: '探针为独立子进程；夹具库在 data/tmp/s6-accept-*/（非生产 data/db/orb.sqlite）；数据层闸场景（S6-2/3/5/8a）经裸 SQL 验证，不经过 publish.mjs。',
      selfReported: [],
    },
    items: [],
    artifacts,
    probeExit: r.status,
  }

  if (!probe) {
    out.verdict = 'reject'
    out.items.push({ id: 'S6-0', clause: '§7 探针可执行', ok: false, detail: '探针无 JSON 输出', evidence: { stderr: String(r.stderr || '').slice(0, 500), status: r.status } })
  } else {
    for (const it of probe.items) {
      out.items.push({
        id: it.id,
        clause: CLAUSES[it.id] || it.clause,
        ok: it.ok,
        detail: it.detail,
        evidence: it.evidence,
        rerunOne: `node tools/s6-probe.mjs --workdir <tmpdir> --only ${it.id}`,
      })
    }
    const failed = out.items.filter((i) => !i.ok)
    out.verdict = failed.length === 0 && probe.ok ? 'accept' : 'reject'
    out.failures = failed.map((f) => ({ id: f.id, reason: f.detail }))
  }

  // 证据双写：run-root（经 ORB_RUN_ROOT，run-isolated 会连同 sha256 收进 RUN-REPORT）
  // + data/logs（耐久副本，供人查）。§7：RUN-REPORT.json 含 evidence 清单与哈希。
  const runRoot = process.env.ORB_RUN_ROOT
  const logPathAbs = logPath('s6-accept-evidence.json')
  const payload = JSON.stringify(out, null, 2)
  writeFileSync(logPathAbs, payload)
  if (runRoot) {
    try { writeFileSync(join(runRoot, 's6-evidence.json'), payload) } catch { /* run-root 不可写时以 logs 副本为准 */ }
  }
  console.log(`S6 证据闸验收：${out.items.filter((i) => i.ok).length}/${out.items.length} 通过 → ${out.verdict}`)
  for (const it of out.items) console.log(`  [${it.ok ? 'PASS' : 'FAIL'}] ${it.id} ${it.detail}`)
  console.log(`证据(JSON+sha256)：${logPathAbs}`)
  for (const a of artifacts) console.log(`  sha256 ${a.sha256.slice(0, 16)}… ${a.path}`)

  // 清理夹具（run-isolated 会把新文件归档为证据；夹具库体积无审计价值，产物以 JSON 为准）
  try { rmSync(WORK, { recursive: true, force: true }) } catch { /* noop */ }
  process.exit(out.verdict === 'accept' ? 0 : 1)
}

main()
