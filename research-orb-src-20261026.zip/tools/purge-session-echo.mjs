// tools/purge-session-echo.mjs —— S52：清洗会话历史里已沉积的"查询回执"污染
//
// 单行执行：node tools\purge-session-echo.mjs          # 预演（只报告）
//          node tools\purge-session-echo.mjs --apply   # 先导出再删
//
// 背景：/timeline 等查询命令曾被主进程走成"流式对话"，每次切页都往会话里追加一条
// 「轨迹（20261024）：今天还没有片段。」（实测隔离库切一次页 +456 条，真实库累计上千条）。
// UI 侧已在 endStream 拦掉**新增**，但历史里已沉积的会被回放刷屏 —— 这个工具清它们。
//
// 纪律：先导出到 data\db\session-echo-purge-<ts>.json；只删命中行；不静默删。
// 注意：**需要应用退出后运行**（否则 sqlite 独占，只读都打不开）。

import { existsSync, mkdirSync, writeFileSync } from 'node:fs'
import {join, resolve} from 'node:path'
import { DatabaseSync } from 'node:sqlite'

const ROOT = resolve(import.meta.dirname, '..')
const DB = join(ROOT, 'data', 'db', 'orb.sqlite')
const APPLY = process.argv.includes('--apply')
const RE = /轨迹（\d{8}）：|今天还没有片段/

if (!existsSync(DB)) {
  console.error('[echo-purge] 找不到库：' + DB)
  process.exit(2)
}

let db
try {
  db = new DatabaseSync(DB)
} catch (e) {
  console.error('[echo-purge] 打不开库（应用可能正在运行）：' + (e && e.message))
  process.exit(3)
}

const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all().map((r) => r.name)
const plan = []
for (const t of tables) {
  const cols = db.prepare(`PRAGMA table_info("${t}")`).all().map((c) => c.name)
  const textCols = cols.filter((c) => /text|content|message|body|turn/i.test(c))
  if (textCols.length === 0) continue
  for (const c of textCols) {
    try {
      const rows = db.prepare(`SELECT rowid AS __rid, "${c}" AS __v FROM "${t}" WHERE "${c}" LIKE ? OR "${c}" LIKE ?`).all('%轨迹（%', '%今天还没有片段%')
      for (const r of rows) {
        if (RE.test(String(r.__v || ''))) plan.push({ table: t, col: c, rowid: r.__rid, text: String(r.__v).slice(0, 120) })
      }
    } catch { /* 该列类型不支持 LIKE 就跳过 */ }
  }
}

console.log(`[echo-purge] 命中 ${plan.length} 行`)
for (const p of plan.slice(0, 10)) console.log(`   ${p.table}.${p.col} rowid=${p.rowid}  ${p.text}`)

if (plan.length === 0) {
  console.log('[echo-purge] 无需处理')
  process.exit(0)
}

const stamp = new Date().toISOString().replace(/[:.]/g, '-')
const out = join(ROOT, 'data', 'db', `session-echo-purge-${stamp}.json`)
mkdirSync(join(ROOT, 'data', 'db'), { recursive: true })
writeFileSync(out, JSON.stringify({ at: new Date().toISOString(), reason: 'S52 查询回执混入会话历史', plan }, null, 2), 'utf8')
console.log(`[echo-purge] 已导出 ${out}`)

if (!APPLY) {
  console.log('[echo-purge] 预演完成，未删除。加 --apply 执行。')
  process.exit(0)
}

let changed = 0
for (const p of plan) {
  try {
    const r = db.prepare(`DELETE FROM "${p.table}" WHERE rowid = ?`).run(p.rowid)
    changed += r.changes || 0
  } catch (e) {
    console.error(`[echo-purge] 删失败 ${p.table}.${p.col}#${p.rowid}: ${e && e.message}`)
  }
}
console.log(`[echo-purge] 已删除 ${changed} 行`)
db.close()
