// tools/accept-stage4-block1.mjs
//
// 阶段 4 块 1（引用级可验证，产品红线）验收取证器。
//
// 用例（与任务书一一对应，全部真跑，不用桩）：
//   ① 真实 DOI 正确引用（贴校验置信度）：10.1109/lcsys.2020.3044551
//      （2026-10-15 实测 Crossref 200：IEEE Control Systems Letters, 2021,
//       Yan Jiang / Andrey Bernstein / Petr Vorobev / Enrique Mallada）。
//      走**引擎的 /verify 命令路径**（真 net 出网，审计落 data/logs/stage41-net.jsonl）。
//   ② 伪造 DOI 被拒（贴拒绝理由）：10.9999/fake.doi.12345（Crossref/OpenAlex 双源 404）。
//      附 ②b：真实 DOI + 张冠李戴的标题 → 拒引（相似度低于门槛）。
//   ③ PDF quote 命中与不命中各一例：data/fixtures/sample-paper.pdf，真 unpdf 抽取。
//   ④ 总装渲染四件套：结论区（三档）/ 来源清单（角标）/ 拒引区 / 未验证断言区，
//      且 unverified 断言绝不出现在结论区（"无来源不出结论"的机械验证）。
//   ⑤ 全量测试全绿（≥376：338 基线 + cite-verify 33 + 插件层 5）。
//   ⑥ 真实 electron 冒烟：本阶段改过插件激活路径（新增 /verify 命令），
//      必须证明桌面端仍 bridge-injected 且 renderer 无 Uncaught。
//   ⑦ 隔离复核：probe-isolation verify（对最新基线，证明本阶段零越界改动）。
//
// 说明：本块无 GUI 改动，data/shots 下的界面截图随总验收的 electron 冒烟统一补拍；
// 本工具的所有取证落 data/logs/stage41-*。
//
// 用法：node tools/accept-stage4-block1.mjs
// 产物：data/logs/stage41-*.txt / .json + data/logs/stage41-summary.json

import { spawn, spawnSync } from 'node:child_process'
import { existsSync, readdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

import { createEngine } from '../packages/plugins/research-literature/index.mjs'
import { renderVerifiedAnswer, verifyAssertion } from '../packages/plugins/research-literature/lib/cite-verify.mjs'
import { createNet } from '../packages/core/src/net.mjs'
import { PROJECT_ROOT, safeWrite } from '../packages/core/src/safefs.mjs'
import {countOrbAll, killMarked, mkMark, orbUdata, ORB_ELECTRON} from './_orb-proc.mjs'

const MARK = mkMark('accept-stage4-block1')

const LOGS = join(PROJECT_ROOT, 'data', 'logs')
const APP_LOG = join(LOGS, 'app.jsonl')
const RENDERER_LOG = join(LOGS, 'renderer.jsonl')
const NET_LOG = join(LOGS, 'stage41-net.jsonl')
const FIXTURE_PDF = join(PROJECT_ROOT, 'data', 'fixtures', 'sample-paper.pdf')
const ELECTRON_EXE = ORB_ELECTRON
const RESULTS = []

// 用例常量（DOI 元数据为 2026-10-15 实测快照；断言写得与线上记录一致，
// 校验器仍然实时解析——若线上记录变动，置信度会如实反映，不会假装匹配）
const REAL_DOI = '10.1109/lcsys.2020.3044551'
const REAL_CLAIM = {
  title: 'Grid-Forming Frequency Shaping Control for Low-Inertia Power Systems',
  year: 2021,
  authors: ['Yan Jiang', 'Andrey Bernstein'],
}
const FAKE_DOI = '10.9999/fake.doi.12345'
const QUOTE_HIT = 'Simulations on a modified IEEE 9-bus system show improved frequency nadir by 32 percent.'
const QUOTE_MISS = 'Simulations on a modified IEEE 9-bus system show improved frequency nadir by 90 percent.'

const startedAt = new Date().toISOString()

function evidence(name, text) {
  safeWrite(join(LOGS, name), text)
  return `data/logs/${name}`
}
function jsonEvidence(name, obj) {
  return evidence(name, JSON.stringify(obj, null, 2))
}
function record(id, title, ok, detail, files = []) {
  RESULTS.push({ id, title, ok: !!ok, detail, files })
  process.stdout.write(`[${ok ? 'PASS' : 'FAIL'}] ${id} ${title}\n        ${String(detail).replace(/\n/g, '\n        ')}\n`)
  if (files.length > 0) process.stdout.write(`        证据：${files.join('  ')}\n`)
}
async function step(id, title, fn) {
  try {
    return await fn()
  } catch (err) {
    record(id, title, false, `异常：${(err && err.message) || err}`, [])
    return null
  }
}
function runNode(args, { env = null } = {}) {
  const childEnv = { ...process.env }
  delete childEnv.ELECTRON_RUN_AS_NODE
  if (env) Object.assign(childEnv, env)
  const r = spawnSync(process.execPath, args, { cwd: PROJECT_ROOT, encoding: 'utf8', env: childEnv })
  return { status: r.status, stdout: String(r.stdout || ''), stderr: String(r.stderr || '') }
}
function existsSyncSafe(p) {
  try {
    return existsSync(p)
  } catch {
    return false
  }
}
function killOwnElectron() { return killMarked(MARK) }

// ---------------------------------------------------------------------------
// 引擎（真 net；scopes 用最小桩——/verify 不落盘，createEngine 传了 scopes 就不会碰 ctx.fs）
// ---------------------------------------------------------------------------

safeWrite(NET_LOG, '') // 截断而非删除，便于逐行断言本次出网
const net = createNet({ logFile: NET_LOG })
const ctx = { log: { info() {}, warn() {}, error() {}, debug() {} }, net }
const engine = createEngine(ctx, {
  scopes: { notes: { name: 'stub' }, pdf: { name: 'stub' }, index: { name: 'stub' }, exports: { name: 'stub' } },
  secretsLoader: () => ({}),
})
const deps = engine._internals.verifyDeps()

/** 本次 net 审计里与两个元数据源相关的行（证明只走了白名单域名）。 */
function netAuditLines() {
  if (!existsSyncSafe(NET_LOG)) return []
  return readFileSync(NET_LOG, 'utf8')
    .split('\n')
    .filter((l) => l.trim())
    .map((l) => {
      try {
        return JSON.parse(l)
      } catch {
        return null
      }
    })
    .filter(Boolean)
}

// ---------------------------------------------------------------------------
// ① 真实 DOI：正确引用，贴校验置信度（经 /verify 命令路径）
// ---------------------------------------------------------------------------

let realDoiResult = null

await step('①', '真实 DOI 正确引用：/verify 命令路径贴出校验置信度（真 net 双源解析）', async () => {
  const r = await engine.verify(
    `doi ${REAL_DOI} --title "${REAL_CLAIM.title}" --year ${REAL_CLAIM.year} --author "Yan Jiang, Andrey Bernstein"`,
  )
  realDoiResult = r
  const audit = netAuditLines().filter((l) => /crossref|openalex/.test(String(l.host || '')))
  const txt = [
    '=== ① 真实 DOI 用例（产品红线：可验证的引用必须贴置信度）===',
    `命令：/verify doi ${REAL_DOI} --title "${REAL_CLAIM.title}" --year ${REAL_CLAIM.year} --author "Yan Jiang, Andrey Bernstein"`,
    '',
    '=== /verify 输出（renderVerifyReport）===',
    r.text,
    '',
    '=== ui payload ===',
    JSON.stringify(r.ui, null, 2),
    '',
    '=== net 审计（本次出网，只允许 api.crossref.org / api.openalex.org）===',
    ...audit.map((l) => `  ${l.decision} ${l.host} ${l.url || ''}${l.count ? ' x' + l.count : ''}`),
    `本次审计行数：${audit.length}（deny 行数：${audit.filter((l) => l.decision === 'deny').length}）`,
    '',
    `（网络经本机环境出口；DOI 元数据快照时间 ${startedAt}）`,
  ].join('\n')
  const rel = evidence('stage41-01-real-doi.txt', txt)
  const jsonRel = jsonEvidence('stage41-01-real-doi.json', {
    at: new Date().toISOString(),
    doi: REAL_DOI,
    claim: REAL_CLAIM,
    ok: r.ok,
    ui: r.ui,
    netAudit: audit,
  })
  const ok = r.ok === true && r.ui.status === 'verified' && r.ui.metaChecked === true && Number(r.ui.confidence) >= 0.9
  record('①', '真实 DOI 正确引用（贴校验置信度，≥0.9）', ok, `status=${r.ui.status} 置信度=${r.ui.confidence} 解析源=${r.ui.resolvedBy}`, [rel, jsonRel])
  return r
})

// ---------------------------------------------------------------------------
// ② 伪造 DOI：被拒 + 拒绝理由；②b 真 DOI + 错标题同样拒引
// ---------------------------------------------------------------------------

await step('②', '伪造 DOI 被拒（贴拒绝理由：Crossref 与 OpenAlex 均未收录）', async () => {
  const r = await engine.verify(`doi ${FAKE_DOI} --title "A Paper That Does Not Exist Anywhere"`)
  const audit = netAuditLines().filter((l) => /crossref|openalex/.test(String(l.host || '')))
  const txt = [
    '=== ② 伪造 DOI 用例（产品红线：拒引必须给出理由）===',
    `命令：/verify doi ${FAKE_DOI} --title "A Paper That Does Not Exist Anywhere"`,
    '',
    '=== /verify 输出 ===',
    r.text,
    '',
    '=== ui payload ===',
    JSON.stringify(r.ui, null, 2),
    '',
    '=== net 审计（双源各打过一次，均 404）===',
    ...audit.map((l) => `  ${l.decision} ${l.host}`),
  ].join('\n')
  const rel = evidence('stage41-02-fake-doi.txt', txt)
  const jsonRel = jsonEvidence('stage41-02-fake-doi.json', { at: new Date().toISOString(), doi: FAKE_DOI, ok: r.ok, ui: r.ui, netAudit: audit })
  const ok = r.ok === false && r.ui.status === 'rejected' && /Crossref 与 OpenAlex 均未收录/.test(r.text) && /不得出现在任何结论中/.test(r.text)
  record('②', '伪造 DOI 被拒（拒绝理由：双源均未收录；不得作为结论）', ok, `status=${r.ui.status}；理由已入文案`, [rel, jsonRel])
  return r
})

await step('②b', '真实 DOI + 张冠李戴标题 → 拒引（相似度低于门槛 0.6）', async () => {
  const r = await engine.verify(`doi ${REAL_DOI} --title "A Deep Learning Approach to Household Load Forecasting"`)
  const txt = [
    '=== ②b 真 DOI + 错标题（门槛裁决，不是扣分是资格线）===',
    `命令：/verify doi ${REAL_DOI} --title "A Deep Learning Approach to Household Load Forecasting"`,
    '',
    r.text,
    '',
    JSON.stringify(r.ui, null, 2),
  ].join('\n')
  const rel = evidence('stage41-02b-title-mismatch.txt', txt)
  const jsonRel = jsonEvidence('stage41-02b-title-mismatch.json', { at: new Date().toISOString(), ok: r.ok, ui: r.ui })
  const ok = r.ok === false && r.ui.status === 'rejected' && /标题不匹配：相似度 0\.\d+ 低于门槛 0\.6/.test(r.text)
  record('②b', '真实 DOI + 错标题 → 拒引（理由带相似度数值）', ok, `status=${r.ui.status}`, [rel, jsonRel])
  return r
})

// ---------------------------------------------------------------------------
// ③ PDF quote：命中与不命中各一例（真 unpdf 抽取仓库夹具）
// ---------------------------------------------------------------------------

await step('③a', 'PDF quote 命中：归一化后逐字命中 → 可引用', async () => {
  const r = await engine.verify(`quote ${QUOTE_HIT} --pdf ${FIXTURE_PDF}`)
  const txt = [
    '=== ③a PDF 引文命中（真 unpdf 抽取 data/fixtures/sample-paper.pdf）===',
    `命令：/verify quote ${QUOTE_HIT} --pdf ${FIXTURE_PDF}`,
    '',
    r.text,
    '',
    JSON.stringify(r.ui, null, 2),
  ].join('\n')
  const rel = evidence('stage41-03a-quote-hit.txt', txt)
  const jsonRel = jsonEvidence('stage41-03a-quote-hit.json', { at: new Date().toISOString(), ok: r.ok, ui: r.ui, pdf: FIXTURE_PDF })
  const ok = r.ok === true && r.ui.status === 'verified' && /归一化后逐字命中/.test(r.text)
  record('③a', 'PDF quote 命中（归一化后逐字命中才允许引用）', ok, `status=${r.ui.status}`, [rel, jsonRel])
  return r
})

await step('③b', 'PDF quote 不命中：数字被改 → 拒引（带规模与前缀命中诊断）', async () => {
  const r = await engine.verify(`quote ${QUOTE_MISS} --pdf ${FIXTURE_PDF}`)
  const txt = [
    '=== ③b PDF 引文不命中（把 32 percent 改成 90 percent）===',
    `命令：/verify quote ${QUOTE_MISS} --pdf ${FIXTURE_PDF}`,
    '',
    r.text,
    '',
    JSON.stringify(r.ui, null, 2),
  ].join('\n')
  const rel = evidence('stage41-03b-quote-miss.txt', txt)
  const jsonRel = jsonEvidence('stage41-03b-quote-miss.json', { at: new Date().toISOString(), ok: r.ok, ui: r.ui, pdf: FIXTURE_PDF })
  const ok = r.ok === false && r.ui.status === 'rejected' && /未在 PDF 全文中逐字命中/.test(r.text) && /最长前缀命中/.test(r.text)
  record('③b', 'PDF quote 不命中 → 拒引（诊断含最长前缀命中比例）', ok, `status=${r.ui.status}`, [rel, jsonRel])
  return r
})

// ---------------------------------------------------------------------------
// ④ 总装渲染：四件套 + 无来源不出结论（用与命令同一份 deps 组装多源答案）
// ---------------------------------------------------------------------------

await step('④', '总装渲染：结论三档 + 角标来源清单 + 拒引区 + 未验证断言区', async () => {
  const a1 = await verifyAssertion(
    { text: 'Grid-Forming Frequency Shaping Control 可改善低惯量系统的频率响应', strength: 'proven', sources: [{ kind: 'doi', ref: REAL_DOI, claim: REAL_CLAIM }] },
    deps,
  )
  const a2 = await verifyAssertion({ text: '该策略或可推广至含储能的综合能源系统', strength: 'inferred' }, deps)
  const a3 = await verifyAssertion(
    { text: '某结论以一篇不存在的文献为依据', strength: 'proven', sources: [{ kind: 'doi', ref: FAKE_DOI, claim: { title: 'Fabricated Paper' } }] },
    deps,
  )
  const a4 = await verifyAssertion(
    { text: '某结论的引文与 PDF 原文不符', strength: 'proven', sources: [{ kind: 'pdf', ref: FIXTURE_PDF, locator: { quote: QUOTE_MISS } }] },
    deps,
  )
  const a5 = await verifyAssertion({ text: '没有任何来源的断言', strength: 'proven' }, deps)
  const assertions = [a1, a2, a3, a4, a5]
  const out = renderVerifiedAnswer({ lead: '问题：构网型/频率整形控制能否支撑低惯量系统？', assertions })

  const conclusion = out.split('【来源清单】')[0]
  const checks = {
    '结论区含 proven 断言且带 [1] 角标与「已证实」': /- Grid-Forming Frequency Shaping Control 可改善低惯量系统的频率响应 \[1\] —— 已证实/.test(conclusion),
    '结论区含 inferred 断言且显式标注「推断」': /- 该策略或可推广至含储能的综合能源系统 —— 推断/.test(conclusion),
    '结论区不含任何 unverified 断言（无来源不出结论）':
      !conclusion.includes('不存在的文献') && !conclusion.includes('引文与 PDF 原文不符') && !conclusion.includes('没有任何来源的断言'),
    '来源清单由校验器追加且编号从 [1] 开始': /【来源清单】（由引用校验器追加，非模型输出）\n\[1\] doi:/.test(out),
    '拒引区列出伪造 DOI 且带「引用校验失败（原因）」': /拒引｜DOI 10\.9999\/fake\.doi\.12345｜引用校验失败（DOI 无法解析：Crossref 与 OpenAlex 均未收录该 DOI/.test(out),
    '拒引区列出 PDF 引文不命中': /拒引｜PDF 引文 .*sample-paper\.pdf｜引用校验失败（引文未在 PDF 全文中逐字命中/.test(out),
    '未验证断言区集中列出三条（降级两条 + 无源一条）':
      /【未验证断言】（无来源或校验未通过，不得作为结论）/.test(out) &&
      /- 某结论以一篇不存在的文献为依据 —— 待验证（全部 1 个来源校验失败）/.test(out) &&
      /- 某结论的引文与 PDF 原文不符 —— 待验证（全部 1 个来源校验失败）/.test(out) &&
      /- 没有任何来源的断言 —— 待验证（未提供任何来源）/.test(out),
    '强度三档在同一段输出中全部出现': /已证实/.test(out) && /推断/.test(out) && /待验证/.test(out),
  }
  const txt = [
    '=== ④ 总装渲染（renderVerifiedAnswer，deps 与 /verify 命令同一份）===',
    '',
    out,
    '',
    '=== 逐项检查 ===',
    ...Object.entries(checks).map(([k, v]) => `${v ? 'OK  ' : 'MISS'} ${k}`),
  ].join('\n')
  const rel = evidence('stage41-04-render.txt', txt)
  const jsonRel = jsonEvidence('stage41-04-render.json', {
    at: new Date().toISOString(),
    checks,
    assertions: assertions.map((a) => ({ text: a.text, claimed: a.claimed, effective: a.effective, downgradeReason: a.downgradeReason, confidence: a.confidence })),
  })
  const ok = Object.values(checks).every(Boolean)
  record('④', '总装渲染四件套（三档强度/角标/拒引/未验证专区；无源断言不进结论区）', ok, `${Object.values(checks).filter(Boolean).length}/${Object.keys(checks).length} 项在位`, [rel, jsonRel])
  return assertions
})

// ---------------------------------------------------------------------------
// ⑤ 全量测试
// ---------------------------------------------------------------------------

await step('⑤', 'node --test 全量（≥376 条全绿：338 基线 + cite-verify 33 + 插件层 5）', async () => {
  const files = readdirSync(join(PROJECT_ROOT, 'tests')).filter((f) => f.endsWith('.test.mjs')).map((f) => join('tests', f))
  const r = runNode(['--test', '--test-concurrency=1', ...files])
  const out = r.stdout + r.stderr
  const passM = out.match(/# pass (\d+)/)
  const failM = out.match(/# fail (\d+)/)
  const pass = passM ? Number(passM[1]) : 0
  const fail = failM ? Number(failM[1]) : -1
  const rel = evidence('stage41-05-tests.txt', out)
  const jsonRel = jsonEvidence('stage41-05-tests.json', { at: new Date().toISOString(), total: pass + (fail > 0 ? fail : 0), pass, fail, files: files.length })
  record('⑤', '全量测试全绿（≥376）', fail === 0 && pass >= 376 && r.status === 0, `${pass} 通过，失败 ${fail}`, [rel, jsonRel])
})

// ---------------------------------------------------------------------------
// ⑥ 真实 electron 冒烟（本阶段改过插件激活路径）
// ---------------------------------------------------------------------------

await step('⑥', '真实 electron 冒烟：bridge-injected 且 renderer 无 Uncaught', async () => {
  // S74c·P0-1：这块是**只读**预检（fail-closed），用 _orb-proc 的 countOrbAll 统一口径，
  // 不在本文件内嵌按 app 路径匹配的 PowerShell 串。
  const running = countOrbAll()
  if (Number.isFinite(running) && running > 0) {
    record('⑥', '真实 electron 冒烟', false, `已有 ${running} 个 research-orb 进程在运行，先退出再验收（fail-closed）`, [])
    return null
  }

  const appBefore = existsSyncSafe(APP_LOG) ? readFileSync(APP_LOG, 'utf8').length : 0
  const renBefore = existsSyncSafe(RENDERER_LOG) ? readFileSync(RENDERER_LOG, 'utf8').length : 0

  const child = spawn(ELECTRON_EXE, [`--user-data-dir=${orbUdata(MARK)}`, join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs'), '--no-sandbox'], {
    cwd: PROJECT_ROOT,
    env: (() => { const e = { ...process.env }; delete e.ELECTRON_RUN_AS_NODE; return e })(),
    stdio: 'ignore',
    detached: false,
  })

  const seen = { start: null, coreReady: null, windowReady: null, bridgeInjected: null, bridgeFailed: null, panelFailed: null, rendererGone: null }
  const deadline = Date.now() + 60_000
  while (Date.now() < deadline) {
    await new Promise((r) => setTimeout(r, 1000))
    const appNow = existsSyncSafe(APP_LOG) ? readFileSync(APP_LOG, 'utf8') : ''
    for (const line of appNow.slice(appBefore).split('\n')) {
      if (!line.trim()) continue
      try {
        const j = JSON.parse(line)
        if (j.type === 'start') seen.start = j
        if (j.type === 'core-ready') seen.coreReady = j
        if (j.type === 'window-ready') seen.windowReady = j
        if (j.type === 'bridge-injected') seen.bridgeInjected = j
        if (j.type === 'bridge-inject-failed') seen.bridgeFailed = j
        if (j.type === 'panel-load-failed') seen.panelFailed = j
        if (j.type === 'renderer-gone') seen.rendererGone = j
      } catch {
        /* 半行跳过 */
      }
    }
    if (seen.bridgeInjected || seen.bridgeFailed) break
    if (child.exitCode !== null) break
  }
  if (seen.bridgeInjected) await new Promise((r) => setTimeout(r, 3000))
  try { child.kill('SIGKILL') } catch { /* 已退出 */ }
  await new Promise((r) => setTimeout(r, 1500))
  killOwnElectron()

  const renNow = existsSyncSafe(RENDERER_LOG) ? readFileSync(RENDERER_LOG, 'utf8') : ''
  const newRendererLines = renNow.slice(renBefore).split('\n').filter((l) => l.trim()).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
  const uncaught = newRendererLines.filter((r) => /Uncaught/i.test(String(r.message || '')))

  const injectedOk = !!seen.bridgeInjected
  const ok = injectedOk && !seen.bridgeFailed && !seen.panelFailed && uncaught.length === 0
  const txt = [
    '=== electron 冒烟（--no-sandbox；agent shell 环境既定变通）===',
    '本阶段改动：research-literature 插件新增 /verify 命令注册与 cardBody/actions 文案。',
    '',
    JSON.stringify(seen, null, 2),
    '',
    `Uncaught 行数：${uncaught.length}`,
    `bridge-injected：${injectedOk ? '有' : '无'}；inject-failed：${seen.bridgeFailed ? '有（回归！）' : '无'}`,
    '',
    '（render-process-gone 为本机已知 GPU 环境问题，只记录不判负，见 STAGE-LOG。）',
  ].join('\n')
  const rel = evidence('stage41-06-smoke.txt', txt)
  const jsonRel = jsonEvidence('stage41-06-smoke.json', { at: new Date().toISOString(), seen, uncaught, ok })
  record('⑥', '真实 electron 冒烟（新命令注册不破坏注入）', ok,
    `bridge-injected=${injectedOk ? 'OK' : 'FAIL'} Uncaught=${uncaught.length}`, [rel, jsonRel])
})

// ---------------------------------------------------------------------------
// ⑦ 隔离复核（对最新基线）
// ---------------------------------------------------------------------------

await step('⑦', '隔离复核：probe-isolation verify（对 stage32 基线，本阶段零越界）', async () => {
  const r = runNode([join('tools', 'probe-isolation.mjs'), 'verify', '--tag', 'stage32'])
  const rel = evidence('stage41-07-iso-verify.txt', r.stdout + r.stderr)
  let verify = null
  try { verify = JSON.parse(readFileSync(join(PROJECT_ROOT, 'data', 'shots', 'stage32-iso-verify.json'), 'utf8')) } catch { verify = null }
  const ok = r.status === 0 && !!verify
  record('⑦', 'probe-isolation verify（stage32 基线）：orb 哈希/计划任务/writes 越界 0', ok,
    `exit=${r.status}；结论=${verify ? JSON.stringify(verify.conclusion || verify).slice(0, 300) : '(无)'}`, [rel])
})

// ---------------------------------------------------------------------------
// 汇总
// ---------------------------------------------------------------------------

const summary = {
  stage: '4-block1',
  startedAt,
  finishedAt: new Date().toISOString(),
  results: RESULTS,
  allPass: RESULTS.every((r) => r.ok),
}
safeWrite(join(LOGS, 'stage41-summary.json'), JSON.stringify(summary, null, 2))
process.stdout.write(`\n汇总：${RESULTS.filter((r) => r.ok).length}/${RESULTS.length} 通过 -> data/logs/stage41-summary.json\n`)
process.exit(summary.allPass ? 0 : 1)
