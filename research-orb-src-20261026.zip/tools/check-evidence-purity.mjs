// tools/check-evidence-purity.mjs —— S67·3-A 护栏 2：生产证据纯净检查
//
// 口径（诚实，避免误伤）：
//   · claim 文本：验收结论应当是人写的，命中「验收|测试|fixture|stub|rf-s\d+-setup」即视为测试残留。
//   · trajectory 文本：**不收裸「测试/验收」**——真实活动会自然提到"生成单元测试"/"测试接口"；
//     只用强特征「S\d+ 验收|rf-s\d+-setup|fixture|stub」。
//   · raw_frame id：强特征「rf-s\d+-setup|accept-s\d+」。
//   · 日志：出现「ORB_DATA_DIR=…tmp」或「orb-accept-」即隔离痕迹泄漏到生产日志。
//
// 用法：node tools/check-evidence-purity.mjs   （0=PASS，1=有残留）
import { DatabaseSync } from 'node:sqlite'
import { readFileSync, existsSync, readdirSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { fileURLToPath } from 'node:url'

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..')
const DB = join(ROOT, 'data', 'db', 'orb.sqlite')
const TRAJ = join(ROOT, 'data', 'coach', 'trajectory.jsonl')
const LOGS = join(ROOT, 'data', 'logs')

const CLAIM_MARK = /验收|测试|fixture|stub|rf-s\d+-setup/i
const TRAJ_MARK = /S\d+\s*验收|rf-s\d+-setup|fixture|stub/i
const RAWFRAME_MARK = /rf-s\d+-setup|accept-s\d+/i
const LOG_MARK = /ORB_DATA_DIR=[^"\s]*tmp|orb-accept-/i

const hits = []
try {
  const db = new DatabaseSync(DB, { readOnly: true })
  for (const c of db.prepare('SELECT id, status, text FROM claim').all()) {
    if (CLAIM_MARK.test(String(c.text || ''))) hits.push({ surface: 'claim', id: c.id, why: '文本含测试特征', text: String(c.text || '').slice(0, 60) })
  }
  for (const r of db.prepare('SELECT id FROM raw_frame').all()) {
    if (RAWFRAME_MARK.test(String(r.id))) hits.push({ surface: 'raw_frame', id: r.id, why: 'id 含测试特征' })
  }
  // G4：已发布结论必须至少一条非 none 证据；否则是完整性破损（证据被剥离仍 published）
  try {
    const broken = db.prepare(
      `SELECT c.id, c.text FROM claim c
       WHERE c.status = 'published'
         AND (SELECT COUNT(*) FROM claim_evidence ce WHERE ce.claim_id = c.id AND ce.relation <> 'none') = 0`,
    ).all()
    for (const b of broken) hits.push({ surface: 'claim-integrity', id: b.id, why: 'published 但无证据（G4 完整性破损）', text: String(b.text || '').slice(0, 50) })
  } catch { /* 老库无 claim 表则跳过 */ }
  db.close()
} catch (e) { console.log('[check-evidence-purity] db 跳过：' + e.message) }

if (existsSync(TRAJ)) {
  readFileSync(TRAJ, 'utf8').split('\n').filter(Boolean).forEach((l, i) => {
    if (TRAJ_MARK.test(l)) hits.push({ surface: 'trajectory', id: 'line ' + (i + 1), why: '轨迹含强测试特征' })
  })
}

try {
  for (const f of readdirSync(LOGS).filter((x) => x.endsWith('.jsonl'))) {
    let lines = []
    try { lines = readFileSync(join(LOGS, f), 'utf8').split('\n').filter(Boolean) } catch { continue }
    lines.forEach((l, i) => { if (LOG_MARK.test(l)) hits.push({ surface: 'log', id: f + ':' + (i + 1), why: '含 tmp 隔离痕迹' }) })
  }
} catch { /* no logs */ }

console.log('[check-evidence-purity] 生产证据测试残留 ' + hits.length + ' 处')
for (const h of hits.slice(0, 25)) console.log('  - [' + h.surface + '] ' + h.id + ' — ' + h.why + (h.text ? ' · ' + h.text : ''))
if (hits.length) {
  console.log('\n建议：node tools/export-evidence.mjs --purge-test --apply   （先导出留档，再删测试残留）')
  process.exit(1)
}
console.log('  ✓ PASS：生产证据库/日志未发现测试特征')
