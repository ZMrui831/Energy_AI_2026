// tools/accept-s57-multisession.mjs —— S57·A T8 多会话验收（≥10 项）
//
// 裁定：抽屉 / 只删不改名（软删回收）/ 索引 200 分页 50 / 默认关。
// 全部模块级 + 数据路径验证（确定性），UI 抽屉渲染由 accept-s51-e2e 的 E-23/E-24 覆盖。
//
// 用法：node tools\accept-s57-multisession.mjs

import { mkdtempSync, rmSync, mkdirSync, writeFileSync, existsSync, readdirSync, statSync, utimesSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import {join, resolve} from 'node:path'

const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s57-ms-'))
process.env.ORB_DATA_DIR = join(tmpRoot, 'data')
const DIR = join(tmpRoot, 'data', 'sessions')
const TRASH = join(tmpRoot, 'data', 'trash', 'sessions')
mkdirSync(DIR, { recursive: true })
mkdirSync(TRASH, { recursive: true })

const mkSession = (id, title, users, mtimeMs = null) => {
  const p = join(DIR, id + '.jsonl')
  const lines = [JSON.stringify({ type: 'session', id, createdAt: new Date().toISOString(), title, provider: 'p', model: 'm' })]
  for (const u of users) {
    lines.push(JSON.stringify({ type: 'user', ts: Date.now(), seq: 1, text: u }))
    lines.push(JSON.stringify({ type: 'assistant', ts: Date.now(), seq: 2, text: '回复' }))
  }
  writeFileSync(p, lines.join('\n') + '\n', 'utf8')
  if (mtimeMs) { try { utimesSync(p, new Date(mtimeMs), new Date(mtimeMs)) } catch { /* noop */ } }
  return p
}

try {
  const { scanSessions, softDeleteSession, listTrashSessions, restoreSession, INDEX_MAX, PAGE_SIZE } = await import('../packages/core/src/session-index.mjs')
  const { loadSettings } = await import('../packages/core/src/settings.mjs')

  // ① 默认关
  const cfg = loadSettings(join(tmpRoot, 'nope-config.json'))
  check('M-1 默认关（multiSession.enabled=false）——关时行为与旧版一致', cfg.multiSession && cfg.multiSession.enabled === false, JSON.stringify(cfg.multiSession))

  // 造 2 个会话
  const pA = mkSession('s-a', '论文方法章节', ['帮我梳理方法章节'], Date.now() - 3600e3)
  mkSession('s-b', '文献检索', ['检索 2024 年光伏预测'], Date.now())

  // ② 列表出现
  const r1 = scanSessions({ dir: DIR })
  check('M-2 开启后索引出现（2 条，按 updatedAt 降序）',
    r1.ok && r1.items.length === 2 && r1.items[0].id === 's-b' && r1.items[1].id === 's-a', JSON.stringify(r1.items.map((x) => x.id)))

  // ③ 切换后 turns 归位（模块级：读目标会话 turns 与标题）
  const { readSession } = await import('../packages/core/src/session.mjs')
  const sess = readSession('s-a', { dir: DIR })
  check('M-3 切换目标会话可读且 turns 归位（2 行 user+assistant 对）',
    !!sess && sess.turns.length === 2 && sess.meta.title === '论文方法章节', JSON.stringify({ turns: sess && sess.turns.length, title: sess && sess.meta.title }))

  // ④ 发送落当前会话（数据路径：appendUser 只落目标文件）
  const beforeA = readFileSync(pA, 'utf8').split('\n').length
  const { appendUser } = await import('../packages/core/src/session.mjs')
  appendUser('s-a', '新的一条', { dir: DIR })
  const afterA = readFileSync(pA, 'utf8').split('\n').length
  const bLines = readFileSync(join(DIR, 's-b.jsonl'), 'utf8').split('\n').length
  check('M-4 发送落当前会话（目标文件 +1 行，其它会话不变）', afterA === beforeA + 1 && bLines === 4, JSON.stringify({ beforeA, afterA, bLines }))

  // ⑤ 分页 50：造 55 个
  for (let i = 0; i < 53; i++) mkSession('s-fill-' + String(i).padStart(2, '0'), '填充 ' + i, ['x'], Date.now() - 60000 - i * 1000)
  const page1 = scanSessions({ dir: DIR, offset: 0 })
  const page2 = scanSessions({ dir: DIR, offset: 50 })
  check('M-5 分页 50 生效（首页 50 条 hasMore=true，第二页 5 条收尾）',
    page1.items.length === PAGE_SIZE && page1.hasMore === true && page2.items.length === 5 && page2.hasMore === false,
    JSON.stringify({ p1: page1.items.length, p2: page2.items.length, total: page1.total }))
  check('M-6 索引封顶 200（INDEX_MAX 常量存在且 ≥ 分页）', INDEX_MAX === 200 && PAGE_SIZE === 50, JSON.stringify({ INDEX_MAX, PAGE_SIZE }))

  // ⑥ 软删 → 回收区
  const del = softDeleteSession({ dir: DIR, trashDir: TRASH, id: 's-b' })
  const trashList = listTrashSessions({ trashDir: TRASH })
  check('M-7 软删：文件进回收区（可恢复，不重命名 id）',
    del.ok && !existsSync(join(DIR, 's-b.jsonl')) && trashList.items.length === 1 && /^s-b-\d{4}-\d{2}-\d{2}T/.test(trashList.items[0].file),
    JSON.stringify({ del, trash: trashList.items[0] && trashList.items[0].file }))

  // ⑦ 删后索引不崩
  const afterDel = scanSessions({ dir: DIR })
  check('M-8 删后列表正常（计数 -1，不抛）', afterDel.ok && afterDel.total === page1.total - 1, JSON.stringify({ total: afterDel.total, before: page1.total }))

  // ⑧ 坏文件跳过并在 bad 里
  // S58 两阶段扫描后：total 统计的是"文件数"（阶段1 不读内容，无法预知坏文件），
  // 坏文件不进 items 且计入 bad —— 断言 items 不含它、其它项数量不变。
  writeFileSync(join(DIR, 's-broken.jsonl'), 'not-json\n', 'utf8')
  const withBad = scanSessions({ dir: DIR })
  check('M-9 坏文件跳过并计入 bad（不污染 items，不影响其它项）',
    withBad.ok && withBad.bad.some((b) => b.id === 's-broken') &&
    !withBad.items.some((x) => x.id === 's-broken') &&
    withBad.items.length >= afterDel.items.length - 1, // 坏文件占窗口一席（排在最前），最多挤掉 1 条
    JSON.stringify({ bad: withBad.bad, items: withBad.items.length, before: afterDel.items.length }))

  // ⑨ 标题现算不回写（mtime 不变）+ 错误恢复路径
  const pC = mkSession('s-c', '', ['这是我的第一条消息，用来现算标题'], Date.now() - 2 * 3600e3)
  const st0 = statSync(pC).mtimeMs
  const r2 = scanSessions({ dir: DIR, offset: 0, pageSize: 200 })
  const c = r2.items.find((x) => x.id === 's-c')
  const st1 = statSync(pC).mtimeMs
  check('M-10 无 title 现算（deriveTitle 语义）且文件 mtime 不变（只读不回写）',
    !!c && /这是我的第一条消息/.test(c.title) && Math.abs(st1 - st0) < 5,
    JSON.stringify({ title: c && c.title, mtimeSame: Math.abs(st1 - st0) < 5 }))

  // 恢复
  const rest = restoreSession({ dir: DIR, trashDir: TRASH, file: trashList.items[0].file })
  const back = scanSessions({ dir: DIR })
  check('M-11 回收区可恢复（文件回 sessions，索引重新出现）',
    rest.ok && existsSync(join(DIR, 's-b.jsonl')) && back.items.some((x) => x.id === 's-b'),
    JSON.stringify({ rest, hasB: back.items.some((x) => x.id === 's-b') }))

  // ⑩ 降级路径：目录不可用 → ok=false（main 侧据此退回单会话）
  const badDir = join(tmpRoot, 'as-file')
  writeFileSync(badDir, 'x', 'utf8')
  const degraded = scanSessions({ dir: badDir })
  check('M-12 降级：目录不可读时返回 ok=false（main 退回当前会话模式）', degraded.ok === false, JSON.stringify({ ok: degraded.ok, code: degraded.code }))
} catch (e) {
  check('M-0 验收异常', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}
const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s57-multisession: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exitCode = items.length - pass === 0 ? 0 : 1
