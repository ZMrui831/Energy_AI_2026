// tools/accept-s25b-confusion.mjs —— S25·2E 困惑问询验收。
// 单行复跑：node tools\accept-s25b-confusion.mjs
// 证据：data\logs\s25b-confusion-accept.json
import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createRouter } from '../packages/core/src/router.mjs'
import { createExtractor } from '../packages/plugins/coach/extract.mjs'
import { createConfusionCoach, ASK_COOLDOWN_MS_DEFAULT } from '../packages/plugins/coach/confusion.mjs'

const items = []
const check = (id, ok, detail = '', evidence = {}) => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 240), evidence }); console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's25b-confusion')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(join(WORK, 'coach'), { recursive: true })
const COACH_DIR = join(WORK, 'coach')
const usagePath = join(WORK, 'usage.jsonl') // 桩显式 usagePath（红线）

let t = 1000000
const now = () => t

// 种子轨迹 5 条（最近 3 条应进上下文）
// S67·3-C：用产品真实默认（24h），不再写死 30min（写死会让"冷却过后可再问"必然假熔断）
const COOLDOWN = ASK_COOLDOWN_MS_DEFAULT
for (let i = 0; i < 5; i++) {
  writeFileSync(join(COACH_DIR, 'trajectory.jsonl'), '', 'utf8') // 先清
}
const seedRows = Array.from({ length: 5 }, (_, i) => JSON.stringify({
  ts: new Date(1000000 + i * 60000).toISOString(),
  window: '窗口' + i,
  process: 'proc' + i + '.exe',
  intent: '意图' + i,
  level: 'direct',
  evidence: { frameId: 'fr-seed' + i, textSha256: 'sha' + i },
}))
writeFileSync(join(COACH_DIR, 'trajectory.jsonl'), seedRows.join('\n') + '\n', 'utf8')

const IMG = join(WORK, 'frame.png')
writeFileSync(IMG, Buffer.from('confusion frame body'))
// S67·3-C：extractor 按设计删原图，多步复用同一 IMG 会第二次起 "文件已删"；每步给新副本
let _imgSeq = 0
const freshImg = () => { const p = join(WORK, `frame-${++_imgSeq}.png`); writeFileSync(p, Buffer.from('confusion frame body')); return p }

function makeStubRouter() {
  return createRouter({
    providers: { cheap: { providerId: 'school-gateway', model: 'qwen' }, flagship: { providerId: 'deepseek-api', model: 'deepseek-chat' } },
    invoke: async ({ taskClass }) => {
      if (taskClass === 'extract') return { text: '屏幕文字：求解下垂控制参数始终发散（桩）' }
      return { text: '教练观察到你在调下垂控制参数。是参考模型的频带选得太宽，还是仿真步长不匹配？' }
    },
    usagePath,
    audit: () => {},
  })
}
const asked = []
const mk = (over = {}) => createConfusionCoach({
  dir: COACH_DIR, router: makeStubRouter(), now,
  extractor: createExtractor({ dir: COACH_DIR, router: makeStubRouter(), trashDir: join(WORK, 'trash'), ocr: () => ({ ok: true, text: '兜底文本' }) }),
  onAsk: async (info) => asked.push(info), ...over,
})

try {
  const coach = mk()

  // ① 主动 ask：成功 + 上下文含最近 3 条轨迹
  const r1 = await coach.ask({ imagePath: freshImg(), trigger: 'manual', window: '仿真窗口', process: 'Code.exe', consentActive: true })
  check('C1 /coach ask（主动）成功且问询非空', r1.ok === true && String(r1.question).includes('下垂控制'))
  check('C2 上下文含最近 3 条轨迹（seed4/3/2）', r1.context.recentTrajectory === 3)

  // ② 冷却期内不重复
  t += 60000 // 1 分钟后
  const r2 = await coach.ask({ imagePath: freshImg(), trigger: 'manual', consentActive: true })
  check('C3 冷却期内不重复（cooledDown）', r2.cooledDown === true && r2.ok === false)

  // ③ 冷却过后可再问（auto-dwell 触发同路径）
  t += COOLDOWN + 60000
  const r3 = await coach.ask({ imagePath: freshImg(), trigger: 'auto-dwell', window: '仿真窗口', consentActive: true })
  check('C4 冷却过后可再问；auto-dwell 触发同路径', r3.ok === true && asked.length >= 2, `r3.ok=${r3.ok} asked=${asked.length} reason=${r3.reason || r3.code || ''} q=${String(r3.question || '').slice(0, 20)}`)

  // ④ 未同意 → 跳过 + 审计
  t += COOLDOWN + 60000
  const r4 = await coach.ask({ imagePath: freshImg(), trigger: 'manual', consentActive: false })
  const auditText = readFileSync(join(PROJECT_ROOT, 'data', 'logs', 'coach.jsonl'), 'utf8')
  check('C5 未同意感知 → 跳过且审计 skipped-no-consent', r4.skipped === true && auditText.includes('skipped-no-consent'))

  // ⑤ 冷却可配（0 = 每次都可问）
  const coachNoCd = mk({ cooldownMs: 0 })
  const a1 = await coachNoCd.ask({ imagePath: freshImg(), trigger: 'manual', consentActive: true })
  const a2 = await coachNoCd.ask({ imagePath: freshImg(), trigger: 'manual', consentActive: true })
  check('C6 冷却可配（0 分钟 → 连续两问都不冷却）', a1.ok === true && a2.ok === true)

  // ⑥ 轨迹为空 → 降级仍可问
  const coachEmpty = createConfusionCoach({
    dir: join(WORK, 'empty'), router: makeStubRouter(), now,
    trajectoryFile: join(WORK, 'empty', 'trajectory.jsonl'),
    extractor: createExtractor({ dir: join(WORK, 'empty'), router: makeStubRouter(), trashDir: join(WORK, 'trash-e'), ocr: () => ({ ok: true, text: '兜底' }) }),
  })
  const e1 = await coachEmpty.ask({ imagePath: freshImg(), trigger: 'auto-dwell', window: '窗口', consentActive: true })
  check('C7 轨迹为空 → 降级仍可问（context.recentTrajectory=0）', e1.ok === true && e1.context.recentTrajectory === 0)

  // ⑦ extract 失败 → 诚实降级（不编造屏幕内容）
  const coachFail = createConfusionCoach({
    dir: join(WORK, 'fail'), router: makeStubRouter(), now,
    trajectoryFile: join(WORK, 'fail', 'trajectory.jsonl'),
    extractor: createExtractor({ dir: join(WORK, 'fail'), router: createRouter({ providers: { cheap: {}, flagship: {} }, invoke: async () => { throw Object.assign(new Error('down'), { code: 'E_HTTP_500' }) }, audit: () => {}, usagePath: join(WORK, 'usage-fail.jsonl') }), trashDir: join(WORK, 'trash-f'), ocr: () => ({ ok: false, text: '', err: 'no engine' }) }),
  })
  const f1 = await coachFail.ask({ imagePath: freshImg(), trigger: 'manual', window: '窗口', consentActive: true })
  check('C8 extract 失败 → 诚实降级（问询声明读不到屏幕上下文）', f1.ok === true && f1.degraded === true && /读不到屏幕上下文/.test(f1.question))

  // ⑨ 审计 coach-ask 行
  check('C9 coach.jsonl 审计 coach-ask 行（trigger/frameId/llmOk）', readFileSync(join(PROJECT_ROOT, 'data', 'logs', 'coach.jsonl'), 'utf8').includes('"kind":"coach-ask"'))
} catch (e) {
  check('C0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 240))
} finally {
  rmSync(WORK, { recursive: true, force: true })
}

const pass = items.filter((i) => i.ok).length
const fail = items.length - pass
const out = { tool: 'accept-s25b-confusion', at: new Date().toISOString(), total: items.length, pass, fail, items }
const outPath = join(PROJECT_ROOT, 'data', 'logs', 's25b-confusion-accept.json')
mkdirSync(join(PROJECT_ROOT, 'data', 'logs'), { recursive: true })
writeFileSync(outPath, JSON.stringify(out, null, 2), 'utf8')
console.log(`\n  # accept-s25b-confusion: total=${items.length} pass=${pass} fail=${fail}`)
console.log(`  # 证据 -> data/logs/s25b-confusion-accept.json`)
process.exit(fail === 0 ? 0 : 1)
