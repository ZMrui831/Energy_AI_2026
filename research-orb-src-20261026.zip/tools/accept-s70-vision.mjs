// tools/accept-s70-vision.mjs —— S71·2B 视觉叙事四层验收（真实夹具 + 真实 GLM）
// 夹具：tests\fixtures\vision\dsh-split-screen.png（1920×1048：左 DSH 主窗 + 右 research-orb 面板）
// 单行复跑：node tools\accept-s70-vision.mjs   （含 4 次真实 GLM 调用，约 2-3 分钟）
import { copyFileSync, existsSync, readFileSync, mkdirSync, rmSync, renameSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../packages/core/src/safefs.mjs'
import { createRouter } from '../packages/core/src/router.mjs'
import { createExtractor, loadVisionContext, visionMessages } from '../packages/plugins/coach/extract.mjs'
import { makeInvoke } from '../packages/plugins/coach/index.mjs'
import { createDailyPipeline } from '../packages/plugins/coach/daily.mjs'

const items = []
const check = (id, ok, detail = '') => { items.push({ id, ok: !!ok, detail: String(detail).slice(0, 300) }); console.log(`  [${ok ? 'PASS' : 'FAIL'}] ${id} ${detail}`) }
const WORK = join(PROJECT_ROOT, 'data', 'tmp', 's70-vision')
const FIXTURE = join(PROJECT_ROOT, 'tests', 'fixtures', 'vision', 'dsh-split-screen.png')
const VCTX = join(PROJECT_ROOT, 'data', 'vision-context.json')
rmSync(WORK, { recursive: true, force: true })
mkdirSync(join(WORK, 'coach'), { recursive: true })

const providers = (() => { try { const d = JSON.parse(readFileSync(join(PROJECT_ROOT, 'data', 'providers.json'), 'utf8')); return { cheap: d.cheap, flagship: d.flagship, vision: d.vision } } catch { return {} } })()
const router = createRouter({ providers, invoke: makeInvoke({ net: null }), audit: () => {}, usagePath: join(WORK, 'usage.jsonl') })
const extractor = createExtractor({ dir: join(WORK, 'coach'), router, trashDir: join(WORK, 'trash') })

/** 跑一次真实抽取（每次新副本 + 清 frames-index，确保真调 GLM 而非缓存）。 */
async function runOnce(i) {
  const img = join(WORK, `in-${i}.png`)
  copyFileSync(FIXTURE, img)
  rmSync(join(WORK, 'coach', 'frames-index.json'), { force: true })
  return extractor.extract({ imagePath: img })
}

try {
  if (!existsSync(FIXTURE)) throw new Error('夹具缺失：' + FIXTURE)

  // ①③ 同图 ×3 真调：tool.name 含 "DeepSeek Harness"（不许"桌面/系统设置"），一致率 ≥2/3
  const runs = []
  for (let i = 1; i <= 3; i++) {
    const r = await runOnce(i)
    const st = r.structured || {}
    const tool = String((st.layers && st.layers.tool && st.layers.tool.name) || st.app || '')
    runs.push({ r, tool })
    console.log(`  [run${i}] tool="${tool}" intent=${st.intent} conf=${st.layers && st.layers.confidence}`)
  }
  const dshHits = runs.filter((x) => /deepseek\s*harness/i.test(x.tool)).length
  const badNames = runs.filter((x) => /桌面|系统设置/.test(x.tool)).length
  check('V-1 tool.name 含 "DeepSeek Harness"（不许桌面/系统设置）', dshHits >= 1 && badNames === 0, `tools=${runs.map((x) => x.tool).join(' | ')}`)
  check('V-2 同图 ×3 一致率 ≥2/3', dshHits >= 2, `hits=${dshHits}/3`)

  // ② 四层 evidence 非空且 ≥6 字可见文字（取首个 tool 命中的 run）
  const good = runs.find((x) => /deepseek\s*harness/i.test(x.tool)) || runs[0]
  const L = (good.r.structured && good.r.structured.layers) || {}
  // 每层 evidence：至少 1 条 ≥6 字可见文字（模型会混入短导航词，如"插件"）
  const evidOk = (arr) => Array.isArray(arr) && arr.length >= 1 && arr.some((s) => String(s).length >= 6)
  check('V-3 四层 evidence 非空（tool/intent/顶层 ≥6 字可见文字）', evidOk(L.tool && L.tool.evidence) && evidOk(L.intent && L.intent.evidence) && evidOk(L.evidence), JSON.stringify({ tool: L.tool && L.tool.evidence, intent: L.intent && L.intent.evidence, top: L.evidence }))
  check('V-4 四层齐（scene/tool/task/intent/narrative/confidence）', !!L.scene && !!L.task && !!L.narrative && Number.isFinite(L.confidence), `scene=${String(L.scene).slice(0, 30)} task=${String(L.task).slice(0, 30)}`)

  // ⑤ 旧字段兼容：structured.app=tool.name、topic=task、intent 三值
  const st0 = good.r.structured || {}
  check('V-5 旧字段兼容（app=tool.name 含 DSH；topic 非空；intent 三值内）', /deepseek\s*harness/i.test(String(st0.app || '')) && !!st0.topic && ['学习', '工作', '生活', '其他', 'self'].includes(String(st0.intent || '')), `app=${st0.app} topic=${st0.topic} intent=${st0.intent}`)

  // ⑥ 注入 ≤600 token（≈2400 字符）
  const vc = loadVisionContext()
  check('V-6 资料库注入 ≤600 token（≤2400 字符）', vc.bytes <= 2400 && vc.block.length <= 2400, `bytes=${vc.bytes}`)

  // ⑦ 资料库缺失走默认（改名 → loadVisionContext 默认空块 → 真实抽取仍 ok 不崩）
  let missingOk = false
  let missingRun = null
  try {
    renameSync(VCTX, VCTX + '.bak-s70')
    try {
      const vcMiss = loadVisionContext()
      const imgM = join(WORK, 'in-missing.png')
      copyFileSync(FIXTURE, imgM)
      rmSync(join(WORK, 'coach', 'frames-index.json'), { force: true })
      missingRun = await extractor.extract({ imagePath: imgM })
      missingOk = vcMiss.block === '' && vcMiss.trimmed === false && missingRun && missingRun.ok === true
    } finally { renameSync(VCTX + '.bak-s70', VCTX) }
  } catch { /* 恢复失败也要暴露 */ }
  check('V-7 资料库缺失走默认（空块，抽取不崩）', missingOk, `ok=${missingRun && missingRun.ok}`)

  // ⑧ 超限裁剪 + 审计钩子：loadVisionContext(极小上限) → trimmed:true；extract 源码有 vision-context-trimmed
  const vcTiny = loadVisionContext(10)
  const src = readFileSync(join(PROJECT_ROOT, 'packages', 'plugins', 'coach', 'extract.mjs'), 'utf8')
  check('V-8 超限裁剪（trimmed 机制）+ 审计钩子存在', vcTiny.trimmed === true && src.includes('vision-context-trimmed'), `bytes=${vcTiny.bytes}`)

  // ⑨ self 不入轨迹：structured.self=true 的帧不写 trajectory
  const stubExtractor = { async extract() { return { ok: true, cached: false, frameId: 'fr-self01', textSha256: 'sha-self', text: 'orb 面板', structured: { app: 'research-orb', intent: 'self', self: true }, source: 'stub' } } }
  const stubRouter = { async run() { return { ok: true, text: '["x"]' } } }
  const p = createDailyPipeline({ dir: join(WORK, 'coach'), router: stubRouter, extractor: stubExtractor, now: () => Date.now() })
  const fimg = join(WORK, 'self.png'); copyFileSync(FIXTURE, fimg)
  const dr = await p.run({ consentActive: true, goal: 'g', frames: [{ imagePath: fimg, window: 'w', process: 'p', source: 'perception' }] })
  const traj = existsSync(join(WORK, 'coach', 'trajectory.jsonl')) ? readFileSync(join(WORK, 'coach', 'trajectory.jsonl'), 'utf8').trim().split('\n').filter(Boolean) : []
  check('V-9 self（orb 自身面板）不入轨迹', dr.ok === true && traj.length === 0, `traj=${traj.length}`)
} catch (e) {
  check('V-0 验收脚本崩溃', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  rmSync(WORK, { recursive: true, force: true })
}

const pass = items.filter((i) => i.ok).length
console.log(`  # accept-s70-vision: total=${items.length} pass=${pass} fail=${items.length - pass}`)
process.exit(items.every((i) => i.ok) ? 0 : 1)
