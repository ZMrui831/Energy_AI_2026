// tools/accept-s74c-console.mjs —— S74c·P0-2 冻结面板缺失 4 资源拦截验收（≥4 项）。
//
// 单行复跑：node tools\accept-s74c-console.mjs
//
// 背景：vendor\orb-base\panel\floating.html 引用 theme.css / chat.css /
// deepseek-avatar-square.gif / shell.js，vendor 是冻结区（safefs 会 E_PROTECTED_ZONE），
// 这 4 个文件不存在 → 控制台 4 条 404 error。P0-2 由主进程用特权 scheme orb-panel://panel/
// 服务面板，并对这 4 个资源返回空桩（css/js 空文本、gif 1×1 透明），首次审计 vendor-stub。
//
// 验收点：
//   C1 控制台 error 数 = 0（4 个 404 应被消除）
//   C2 4 资源 HTTP 状态均 200（页面内 fetch 各自资源）
//   C3 审计含 vendor-stub，且覆盖 4 个文件
//   C4 orb-panel 协议注册成功（审计 orb-panel-protocol registered）
//   C5 vendor 面板目录文件 mtime 不变（只读不写）

import { mkdtempSync, rmSync, cpSync, mkdirSync, readFileSync, existsSync, statSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { spawn } from 'node:child_process'
import { killMarked, countOrbAll, mkMark, orbUdata, ORB_ELECTRON } from './_orb-proc.mjs'

const MARK = mkMark('accept-s74c-console')
const ELECTRON = ORB_ELECTRON
const PROJECT_ROOT = resolve(import.meta.dirname, '..')
const MAIN = join(PROJECT_ROOT, 'apps', 'desktop', 'main.mjs')
const PORT = 9342
const VENDOR_PANEL = join(PROJECT_ROOT, 'vendor', 'orb-base', 'panel')
const STUB_FILES = ['theme.css', 'chat.css', 'shell.js', 'deepseek-avatar-square.gif']
const sleep = (ms) => new Promise((r) => setTimeout(r, ms))

const items = []
const check = (id, ok, detail = '') => {
  items.push({ id, ok: !!ok, detail: String(detail).slice(0, 380) })
  console.log('  [' + (ok ? 'PASS' : 'FAIL') + '] ' + id + ' ' + detail)
}
const countProcs = () => countOrbAll()
const killOwn = () => killMarked(MARK)

async function findTarget(t = 40000) {
  const d = Date.now() + t
  while (Date.now() < d) {
    try {
      const r = await fetch(`http://127.0.0.1:${PORT}/json/list`)
      const l = await r.json()
      const p = l.find((x) => x.type === 'page' && x.webSocketDebuggerUrl && /floating\.html/i.test(String(x.url || '')))
      if (p) return p
    } catch { /* 等 */ }
    await sleep(350)
  }
  return null
}
function cdpConnect(wsUrl) {
  const ws = new WebSocket(wsUrl)
  let seq = 0
  const pending = new Map()
  const errors = []
  const ready = new Promise((res, rej) => { ws.addEventListener('open', () => res()); ws.addEventListener('error', () => rej(new Error('ws'))) })
  ws.addEventListener('message', (ev) => {
    let m = null
    try { m = JSON.parse(typeof ev.data === 'string' ? ev.data : String(ev.data)) } catch { return }
    if (m && m.method === 'Runtime.consoleAPICalled' && m.params && m.params.type === 'error') {
      errors.push((m.params.args || []).map((a) => a.value || a.description || '').join(' ').slice(0, 200))
    }
    if (!m || !m.id) return
    const p = pending.get(m.id); if (!p) return
    pending.delete(m.id)
    if (m.error) p.rej(new Error(JSON.stringify(m.error))); else p.res(m.result)
  })
  const send = (method, params) => new Promise((res, rej) => { const id = ++seq; pending.set(id, { res, rej }); ws.send(JSON.stringify({ id, method, params })) })
  return { ready, send, errors, close: () => { try { ws.close() } catch { /* noop */ } } }
}
async function ev(cdp, expression) {
  const r = await cdp.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })
  if (r && r.exceptionDetails) throw new Error('ev: ' + JSON.stringify(r.exceptionDetails).slice(0, 200))
  return r && r.result ? r.result.value : undefined
}

const tmpRoot = mkdtempSync(join(tmpdir(), 'orb-s74c-console-'))
const logDir = join(tmpRoot, 'logs')
mkdirSync(logDir, { recursive: true })
let child = null
let cdp = null
// vendor mtime 快照（启动前）
const beforeMtime = new Map()
try {
  for (const n of ['floating.html', 'floating.css', ...STUB_FILES]) {
    const fp = join(VENDOR_PANEL, n)
    if (existsSync(fp)) beforeMtime.set(n, Math.round(statSync(fp).mtimeMs))
  }
} catch { /* noop */ }
try {
  if (countProcs() > 0) {
    check('C0 预检（已有实例在跑则退出）', false, '请先关闭 research-orb 实例')
    throw new Error('preflight')
  }
  const env = { ...process.env }
  delete env.ELECTRON_RUN_AS_NODE
  delete env.ORB_LOG_DIR
  env.ORB_DATA_DIR = join(tmpRoot, 'data')
  env.ORB_LOG_DIR = logDir
  // 主题保真：隔离实例的临时数据目录缺 themes\ 会回退 vendor 默认亮色；复制真实 themes 让应用自己注入。
  try { cpSync(join(PROJECT_ROOT, 'data', 'themes'), join(env.ORB_DATA_DIR, 'themes'), { recursive: true }) } catch { /* 无 themes 就算了 */ }
  child = spawn(ELECTRON, [`--user-data-dir=${orbUdata(MARK)}`, '--no-sandbox', `--remote-debugging-port=${PORT}`, MAIN], { cwd: PROJECT_ROOT, env, stdio: ['ignore', 'pipe', 'pipe'] })
  const tail = []
  const push = (b) => { tail.push(String(b)); while (tail.length > 20) tail.shift() }
  if (child.stdout) child.stdout.on('data', push)
  if (child.stderr) child.stderr.on('data', push)

  const target = await findTarget()
  if (!target) { check('C0 启动', false, 'CDP 未就绪：' + tail.join('').slice(-300)); throw new Error('no-target') }
  cdp = cdpConnect(target.webSocketDebuggerUrl)
  await cdp.ready
  await cdp.send('Runtime.enable')
  let bridge = false
  const dl = Date.now() + 30000
  while (Date.now() < dl) {
    try { bridge = await ev(cdp, 'typeof globalThis.__s5 === "object"'); if (bridge) break } catch { /* 等 */ }
    await sleep(400)
  }
  if (!bridge) { check('C0 桥就绪', false, '30s 未就绪'); throw new Error('no-bridge') }
  await sleep(1500) // 等 4 个资源请求落定 + 审计落盘

  // ---------- C1 控制台 error 数 = 0 ----------
  check('C1 控制台 error 数 = 0（4 个 404 已消除）', cdp.errors.length === 0,
    cdp.errors.length ? JSON.stringify(cdp.errors.slice(0, 4)) : '0')

  // ---------- C2 4 资源 HTTP 状态均 200（页面内 fetch） ----------
  const statuses = await ev(cdp, `(() => Promise.all(${JSON.stringify(STUB_FILES)}.map(f => fetch(f).then(r => r.status).catch(e => 'ERR:' + e.message))))()`)
  const all200 = Array.isArray(statuses) && statuses.length === 4 && statuses.every((s) => s === 200)
  check('C2 4 资源 HTTP 状态均 200', all200, JSON.stringify(statuses))

  // ---------- C3 审计含 vendor-stub 且覆盖 4 文件 ----------
  let stubFiles = []
  try {
    const appLog = join(logDir, 'app.jsonl')
    if (existsSync(appLog)) {
      const lines = readFileSync(appLog, 'utf8').trim().split('\n').filter(Boolean)
      for (const ln of lines) {
        try {
          const o = JSON.parse(ln)
          if (o.type === 'vendor-stub' && o.file && !stubFiles.includes(o.file)) stubFiles.push(o.file)
        } catch { /* 跳过坏行 */ }
      }
    }
  } catch { /* noop */ }
  const covered = STUB_FILES.every((f) => stubFiles.includes(f))
  check('C3 审计含 vendor-stub 且覆盖 4 文件', covered, 'seen=' + JSON.stringify(stubFiles))

  // ---------- C4 orb-panel 协议注册成功 ----------
  let registered = false
  try {
    const appLog = join(logDir, 'app.jsonl')
    if (existsSync(appLog)) {
      const lines = readFileSync(appLog, 'utf8').trim().split('\n').filter(Boolean)
      registered = lines.some((ln) => { try { const o = JSON.parse(ln); return o.type === 'orb-panel-protocol' && o.registered === true } catch { return false } })
    }
  } catch { /* noop */ }
  check('C4 orb-panel://panel 协议注册成功', registered, registered ? 'registered' : '未找到 orb-panel-protocol 审计')

  // ---------- C5 vendor 面板目录文件 mtime 不变 ----------
  const changed = []
  for (const [n, m0] of beforeMtime) {
    const fp = join(VENDOR_PANEL, n)
    if (!existsSync(fp)) continue
    const m1 = Math.round(statSync(fp).mtimeMs)
    if (m1 !== m0) changed.push(`${n}:${m0}->${m1}`)
  }
  check('C5 vendor 面板文件 mtime 不变（只读不写）', changed.length === 0,
    changed.length ? '变化=' + changed.join(', ') : '全部未变')
} catch (e) {
  const msg = String((e && e.message) || e)
  if (!['preflight', 'no-target', 'no-bridge'].includes(msg)) check('C0 脚本异常', false, String((e && e.stack) || e).slice(0, 300))
} finally {
  try { if (cdp) cdp.close() } catch { /* noop */ }
  killOwn()
  await sleep(1200)
  try { rmSync(tmpRoot, { recursive: true, force: true }) } catch { /* noop */ }
}

const total = items.length
const passed = items.filter((i) => i.ok).length
console.log(`  # accept-s74c-console: total=${total} pass=${passed} fail=${total - passed}`)
process.exitCode = total - passed === 0 ? 0 : 1
