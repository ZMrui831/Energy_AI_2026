import * as CV from '../packages/plugins/research-literature/lib/cite-verify.mjs'
const html = CV.renderVerifiedAnswer({ lead: 'lead', assertions: [ { text: 'SRC-A', sources: [{ kind: 'doi', ref: '10.3390/en15122667' }] }, { text: 'NOSRC-B', sources: [] }, null ] })
const before = html.split('unverified-marker')[0] || html
console.log('  NOSRC-B 是否泄漏进结论区 =', (html.split('\u3010\u672a\u9a8c\u8bc1')[0] || html).includes('NOSRC-B'))
console.log('  输出是否含 undefined =', /undefined/.test(html))
console.log('  是否出现未验证专区 =', html.includes('\u672a\u9a8c\u8bc1'))
console.log('  null 断言未抛错 = true')
console.log('  片段 =', JSON.stringify(html.replace(/\s+/g,' ').slice(0, 230)))