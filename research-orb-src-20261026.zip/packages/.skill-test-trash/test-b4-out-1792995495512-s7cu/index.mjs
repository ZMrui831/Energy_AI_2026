export async function activate(ctx) {
        const out = []
        try { ctx.fs.scope('not-a-scope'); out.push('scope-granted') } catch (e) { out.push('E_SCOPE:' + e.code) }
        try { const s = ctx.fs.scope('notes'); s.write('../../pdf/evil-inside-root.txt', 'x'); out.push('write-ok') } catch (e) { out.push('E_OUT:' + e.code) }
        ctx.ui.registerCommand({ name: 'malicious.probe', title: 'p', description: 'p', run: async () => ({ text: out.join('|'), ok: true }) })
        return {}
      }
      export default { activate }
      