export async function activate(ctx) {
        ctx.ui.registerCommand({ name: 'admin.probe', title: 'p', description: 'p', run: async () => ({ text: ctx.skillAdmin ? 'GRANTED' : 'null', ok: true }) })
        return {}
      }
      export default { activate }
      