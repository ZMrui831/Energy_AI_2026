export async function activate(ctx) {
  const cards = []
  ctx.ui.registerCard({ id: 'demo.skill', title: 'Demo', body: 'demo', actions: [] })
  ctx.ui.registerCommand({ name: 'demo.skill.ping', title: 'ping', description: 'ping', run: async () => ({ text: 'pong', ok: true }) })
  return { deactivate() {} }
}
export default { activate }
