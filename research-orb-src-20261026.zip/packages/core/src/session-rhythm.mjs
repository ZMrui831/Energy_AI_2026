// packages/core/src/session-rhythm.mjs —— S70·2A 归档与节律（北京时间切日 + 日目录 + 指令分级）
//
// 纪律：
//   · 切日以 **Asia/Shanghai（固定 +08:00）** 为准，**不依赖机器本地时区**（用 UTC 偏移计算）。
//   · 新会话写 data\sessions\<yyyymmdd>\s-<yyyymmdd>-<hhmmss>-<rand>.jsonl；
//     旧 6674 个平铺文件保持只读兼容（不迁移、不重命名）。
//   · <yyyymmdd> ≠ 今日 → 归档；归档不进当天上下文（召回/视觉/轨迹/日报基数），但有独立索引可检索。
//   · 消息分 instruction|chat（宁严勿松）；instruction 额外落 <yyyymmdd>\instructions.jsonl。

import { existsSync, readdirSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

const BJ_OFFSET_MS = 8 * 3600 * 1000
const pad = (n) => String(n).padStart(2, '0')

/** 把毫秒时间戳换到北京时间墙钟（用 UTC 字段读，避免受本机时区影响）。 */
export function bjParts(ms) {
  const d = new Date(Number(ms) + BJ_OFFSET_MS)
  const y = d.getUTCFullYear(), mo = d.getUTCMonth() + 1, da = d.getUTCDate()
  const h = d.getUTCHours(), mi = d.getUTCMinutes(), s = d.getUTCSeconds()
  return { yyyymmdd: `${y}${pad(mo)}${pad(da)}`, hhmmss: `${pad(h)}${pad(mi)}${pad(s)}`, y, mo, da, h, mi, s }
}

/** 北京时间日目录名：yyyyMMdd。 */
export function dayDirName(ms) { return bjParts(ms).yyyymmdd }

/** 新会话文件名：s-<yyyymmdd>-<hhmmss>-<rand>.jsonl。 */
export function sessionRelName(ms, rand) {
  const p = bjParts(ms)
  const r = String(rand || Math.random().toString(36).slice(2, 6))
  return `s-${p.yyyymmdd}-${p.hhmmss}-${r}.jsonl`
}

/** 会话相对路径：<yyyymmdd>/s-...jsonl。 */
export function sessionRelPath(ms, rand) { return `${dayDirName(ms)}/${sessionRelName(ms, rand)}` }

/** 某日目录是否归档（≠ 今日北京日）。 */
export function isArchivedDay(dayName, nowMs = Date.now()) { return String(dayName) !== dayDirName(nowMs) }

/** 日期目录名是否合法（8 位数字）。 */
export function isDayDirName(name) { return /^\d{8}$/.test(String(name || '')) }

/**
 * 消息分级（宁严勿松）：含祈使/约束词，或"短且明确要求" → instruction；其余 chat。
 * @returns {'instruction'|'chat'}
 */
export function classifyMessageKind(text) {
  const t = String(text || '').trim()
  if (!t) return 'chat'
  // 约束/祈使词命中 → instruction
  if (/(以后|不要|必须|记住|改成|禁止|一定要|下次|务必|别忘|不许|统一用)/.test(t)) return 'instruction'
  // 短句 + 明确要求（祈使开头/含"要…"）
  if (t.length < 60 && /^(请|帮我|把|将|给我|记得|改|统一|记得|别)/.test(t)) return 'instruction'
  return 'chat'
}

/** yyyyMMdd → yyyy-MM-dd（展示用）。 */
export function fmtDay(d) { return d && d.length === 8 ? `${d.slice(0, 4)}-${d.slice(4, 6)}-${d.slice(6, 8)}` : '' }

/** 归档汇总：<yyyymmdd> ≠ 今日的日目录 → 归档（扫描 sessionsRoot 一层日目录）。 */
export function summarizeArchive(sessionsRoot, nowMs = Date.now()) {
  const res = { archivedSessions: 0, archivedMsgs: 0, earliestDay: '' }
  if (!existsSync(sessionsRoot)) return res
  let days = []
  try { days = readdirSync(sessionsRoot).filter(isDayDirName) } catch { return res }
  const today = dayDirName(nowMs)
  for (const d of days) {
    if (d === today) continue
    const p = join(sessionsRoot, d)
    let files = []
    try { files = readdirSync(p).filter((n) => n.endsWith('.jsonl') && n !== 'instructions.jsonl') } catch { continue }
    for (const f of files) {
      res.archivedSessions += 1
      try { res.archivedMsgs += readFileSync(join(p, f), 'utf8').split('\n').filter(Boolean).length } catch { /* skip */ }
      if (!res.earliestDay || d < res.earliestDay) res.earliestDay = d
    }
  }
  return res
}

/** 日报「归档」行。 */
export function archiveLine(sessionsRoot, nowMs = Date.now()) {
  const s = summarizeArchive(sessionsRoot, nowMs)
  if (!s.archivedSessions) return '- 归档：今日无归档会话'
  return `- 归档：今日归档 ${s.archivedSessions} 个会话（${s.archivedMsgs} 条消息），最早 ${fmtDay(s.earliestDay)}`
}

/** 日报「指令」行（只统计今日 instructions.jsonl）。 */
export function instructionLine(sessionsRoot, nowMs = Date.now()) {
  const p = join(sessionsRoot, dayDirName(nowMs), 'instructions.jsonl')
  let n = 0
  try { if (existsSync(p)) n = readFileSync(p, 'utf8').split('\n').filter(Boolean).length } catch { /* skip */ }
  return `- 指令：今日 ${n} 条指令（instruction，可检索）`
}
