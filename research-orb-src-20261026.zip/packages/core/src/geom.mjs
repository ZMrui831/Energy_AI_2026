// packages/core/src/geom.mjs
//
// 窗口拖动 / 几何钳制的**纯函数**层（P-R6.2 任务二）。
//
// 为什么抽出来：拖动 bug 的根因之一是「位移计算」与「钳制」散落在 IPC 处理器里，
// 无法单测。本文件零依赖、零 Electron import，输入输出都是普通对象，可被
// tests/geom.test.mjs 直接断言（dpi 1.0/1.25/1.5、多屏负坐标、越界钳制、异常复位）。
//
// 坐标系约定（与 Electron 一致）：
//   · 本文件所有坐标都是 **DIP**（device independent pixel）。物理像素换算见
//     toPhysical/toDip——DPI 换算只在"与 OS API 交界"处发生，几何数学全程 DIP，
//     这是官方 orb 修复 120%/150% 缩放吸边问题的同一结论。
//   · 多显示器：workArea 可能含负坐标（主屏左侧/上方的副屏），钳制必须用
//     「光标所在显示器」的 workArea，而不是主屏。

/** 单显示器描述（从 Electron Display 裁剪出的最小集）。 */
/**
 * @typedef {object} DisplayLike
 * @property {{x:number, y:number, width:number, height:number}} workArea
 * @property {number} [scaleFactor]
 */

/**
 * @typedef {object} BoundsLike
 * @property {number} x
 * @property {number} y
 * @property {number} width
 * @property {number} height
 */

export const EDGE_MARGIN_DEFAULT = 16

/** DIP → 物理像素（round，避免半像素抖动）。 */
export function toPhysical(pt, dpi) {
  const k = Number(dpi) || 1
  return { x: Math.round(pt.x * k), y: Math.round(pt.y * k) }
}

/** 物理像素 → DIP。 */
export function toDip(pt, dpi) {
  const k = Number(dpi) || 1
  return { x: pt.x / k, y: pt.y / k }
}

/**
 * 找到包含某点的显示器（多屏 + 负坐标安全）；找不到回落第一个。
 * @param {{x:number,y:number}} pt
 * @param {DisplayLike[]} displays
 */
export function displayAt(pt, displays) {
  if (!Array.isArray(displays) || displays.length === 0) return null
  for (const d of displays) {
    const wa = d.workArea
    if (pt.x >= wa.x && pt.x < wa.x + wa.width && pt.y >= wa.y && pt.y < wa.y + wa.height) return d
  }
  return displays[0]
}

/**
 * 把 bounds 钳制进指定显示器的 workArea（含边距）。窗口比 workArea 还大时
 * 以 workArea 为准（宁可裁掉也不留屏幕外部分）。
 * @param {BoundsLike} bounds
 * @param {DisplayLike|DisplayLike[]} display 单个显示器或列表（自动选包含点者）
 * @param {{x:number,y:number}} [anchor] 用于选择显示器的参考点（默认 bounds 中心）
 * @param {number} [margin]
 * @returns {BoundsLike}
 */
export function clampToWorkArea(bounds, display, anchor = null, margin = EDGE_MARGIN_DEFAULT) {
  const list = Array.isArray(display) ? display : display ? [display] : []
  if (!bounds || list.length === 0) return bounds
  const center = anchor || { x: bounds.x + bounds.width / 2, y: bounds.y + bounds.height / 2 }
  const d = displayAt(center, list)
  const area = d.workArea
  const m = Math.max(0, Number(margin) || 0)
  const maxX = area.x + area.width - m - bounds.width
  const maxY = area.y + area.height - m - bounds.height
  return {
    width: bounds.width,
    height: bounds.height,
    x: Math.round(Math.min(Math.max(bounds.x, area.x + m), Math.max(area.x + m, maxX))),
    y: Math.round(Math.min(Math.max(bounds.y, area.y + m), Math.max(area.y + m, maxY))),
  }
}

/**
 * 右下角默认落点（含边距）。
 * @param {BoundsLike} size {width,height}
 * @param {DisplayLike} display
 * @param {number} [margin]
 */
export function anchoredBounds(size, display, margin = EDGE_MARGIN_DEFAULT) {
  const area = (Array.isArray(display) ? display[0] : display).workArea
  const m = Math.max(0, Number(margin) || 0)
  return clampToWorkArea(
    { x: area.x + area.width - size.width - m, y: area.y + area.height - size.height - m, width: size.width, height: size.height },
    display,
    null,
    m,
  )
}

/**
 * 拖动目标位置（**不钳制**）——1:1 跟手的核心。
 * 以「按下瞬间的光标位置」与「按下瞬间的窗口位置」为固定偏移，之后任意时刻：
 *   target = startWin + (cursor - startCursor)
 * 这样无论中间发生过什么（哪怕窗口被外力移动过），位移都严格等于光标位移，
 * 不会出现"反向移动"（反向的根因是每次 move 都用**当前**窗口位置当基准，
 * 与钳制叠加形成正反馈）。
 *
 * @param {{x:number,y:number}} startCursor 按下时 getCursorScreenPoint()（DIP）
 * @param {BoundsLike} startBounds 按下时窗口 bounds（DIP）
 * @param {{x:number,y:number}} cursor 当前光标（DIP）
 * @returns {{x:number,y:number,width:number,height:number}}
 */
export function dragTarget(startCursor, startBounds, cursor) {
  const dx = Number(cursor.x) - Number(startCursor.x)
  const dy = Number(cursor.y) - Number(startCursor.y)
  return {
    x: Math.round(Number(startBounds.x) + dx),
    y: Math.round(Number(startBounds.y) + dy),
    width: Math.round(Number(startBounds.width)),
    height: Math.round(Number(startBounds.height)),
  }
}

/**
 * 拖动会话状态机（一次按下→抬起）。
 * 期间**禁止钳制**（任务书要求 3），只在 end 时钳制到 workArea。
 */
export function createDragSession({ displays, margin = EDGE_MARGIN_DEFAULT } = {}) {
  let start = null // { cursor, bounds }
  let moved = false
  return {
    get active() { return !!start },
    get moved() { return moved },
    /** 按下：记录固定偏移。返回 null（无需落界）。 */
    begin(cursor, bounds) {
      start = { cursor: { x: Number(cursor.x), y: Number(cursor.y) }, bounds: { ...bounds } }
      moved = false
      return null
    },
    /** 移动：返回目标 bounds（未钳制）。光标未动返回 null（省一次 setBounds）。 */
    move(cursor) {
      if (!start) return null
      const target = dragTarget(start.cursor, start.bounds, cursor)
      if (!moved && target.x === start.bounds.x && target.y === start.bounds.y) return null
      moved = true
      return target
    },
    /** 抬起：钳制进 workArea（含边距）。返回最终 bounds；未拖动返回 null。 */
    end(cursor, displaysNow = displays) {
      if (!start) return null
      const target = dragTarget(start.cursor, start.bounds, cursor)
      start = null
      if (!moved) return null
      return clampToWorkArea(target, displaysNow || [], { x: target.x + target.width / 2, y: target.y + target.height / 2 }, margin)
    },
    cancel() { start = null; moved = false },
  }
}

/**
 * 尺寸护栏（治"屏幕被占用"）：可见尺寸只允许「收起」或「展开」两态。
 * 面积超过 maxArea（默认面板面积 ×1.2）即判异常。
 * @param {BoundsLike} bounds
 * @param {BoundsLike} panelSize
 * @param {number} [tolerance=1.2]
 * @returns {{ok:boolean, area:number, limit:number, reason?:string}}
 */
export function assertSaneBounds(bounds, panelSize, tolerance = 1.2) {
  const area = Math.max(0, Number(bounds.width) || 0) * Math.max(0, Number(bounds.height) || 0)
  const limit = Math.max(0, Number(panelSize.width) || 0) * Math.max(0, Number(panelSize.height) || 0) * (Number(tolerance) || 1.2)
  if (area > limit) {
    return { ok: false, area, limit, reason: `窗口面积 ${Math.round(area)}px² 超过面板面积×${tolerance}（${Math.round(limit)}px²）` }
  }
  return { ok: true, area, limit }
}

/**
 * 越界判定：bounds 是否完全落在所有显示器并集之外（或与任何显示器都不相交）。
 * @param {BoundsLike} bounds
 * @param {DisplayLike[]} displays
 */
export function isOffscreen(bounds, displays) {
  if (!Array.isArray(displays) || displays.length === 0) return false
  for (const d of displays) {
    const wa = d.workArea
    const ix = Math.min(bounds.x + bounds.width, wa.x + wa.width) - Math.max(bounds.x, wa.x)
    const iy = Math.min(bounds.y + bounds.height, wa.y + wa.height) - Math.max(bounds.y, wa.y)
    if (ix > 0 && iy > 0) return false
  }
  return true
}

/**
 * 圆形命中测试（点击穿透：球的本体是圆，四角是透明区）。
 * @param {{x:number,y:number}} pt 相对窗口左上角的点（DIP）
 * @param {number} size 窗口边长（球窗口为正方形）
 * @param {number} [radiusRatio=0.5] 圆半径占比
 */
export function insideCircle(pt, size, radiusRatio = 0.5) {
  const cx = size / 2
  const cy = size / 2
  const r = size * (Number(radiusRatio) || 0.5)
  const dx = Number(pt.x) - cx
  const dy = Number(pt.y) - cy
  return dx * dx + dy * dy <= r * r
}

export default {
  toPhysical, toDip, displayAt, clampToWorkArea, anchoredBounds,
  dragTarget, createDragSession, assertSaneBounds, isOffscreen, insideCircle,
  EDGE_MARGIN_DEFAULT,
}