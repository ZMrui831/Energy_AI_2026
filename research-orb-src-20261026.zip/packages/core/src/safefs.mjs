// packages/core/src/safefs.mjs
//
// 应用内【唯一】写文件出口。任何模块想落盘都必须走这里，没有例外。
//
// 契约（对应 SAFETY.md 第 1/6 节）：
//   1. 目标路径 resolve 后必须落在项目根 D:\explorer!\research-orb 之下，否则抛错（E_OUTSIDE_ROOT）；
//   2. 每次 safeWrite 追加一行审计到 data/logs/writes.jsonl（{ts, path, bytes}）；
//   3. 冻结区（vendor/ 只读快照、.snapshots/ 历史现场）允许写入但会在审计行里标记
//      protected:true + reason，便于事后追责；真正的拦截留给 code review 与 tools/guard-path.mjs。
//
// 为什么 appendJsonl 不做审计：审计本身也是日志。如果 net.jsonl / ui.jsonl 这类
// 高频日志每写一行就往 writes.jsonl 里再写一行，writes.jsonl 会被日志噪声淹没，
// 反而失去"谁改了工程文件"的可读性。appendJsonl 只享受"根内断言"，不产生级联审计。

import { appendFileSync, existsSync, mkdirSync, writeFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'

// D17：Windows 文件锁（EPERM/EBUSY/EACCES）会让同步写抛错并阻塞主进程。
// 策略：短退避重试（同步睡眠，不改调用方契约）→ 仍失败才抛。
const RETRY_DELAYS_MS = [15, 45, 120, 300]
function isTransientFsError(e) {
  const c = e && (e.code || e.errno || '')
  return c === 'EPERM' || c === 'EBUSY' || c === 'EACCES'
}
function syncSleep(ms) {
  try { Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms) } catch { const t = Date.now() + ms; while (Date.now() < t) { /* busy */ } }
}
function withFsRetry(fn, label = 'fs') {
  let last = null
  for (let i = 0; i <= RETRY_DELAYS_MS.length; i++) {
    try { return fn() } catch (e) {
      if (!isTransientFsError(e)) throw e
      last = e
      if (i === RETRY_DELAYS_MS.length) break
      syncSleep(RETRY_DELAYS_MS[i])
    }
  }
  throw last
}
import { dirname, isAbsolute, join, relative, resolve, sep } from 'node:path'

/**
 * S67·1-B：唯一可写根。从本文件位置（packages/core/src/safefs.mjs）上溯推导，
 * 不再硬编码项目根（评委机器无此路径 → 可写根错位）。
 * 自校验：向上直到某目录包含 packages/core/src/safefs.mjs（即自身），该目录即项目根。
 */
function deriveProjectRoot() {
  let dir = dirname(fileURLToPath(import.meta.url))
  for (let i = 0; i < 8; i++) {
    if (existsSync(join(dir, 'packages', 'core', 'src', 'safefs.mjs'))) return resolve(dir)
    const parent = dirname(dir)
    if (parent === dir) break
    dir = parent
  }
  // 自校验失败：目录被移动/打包，给出明确错误而非静默回退到错误根。
  throw new Error('[safefs] 无法从模块位置推导 PROJECT_ROOT（未找到 packages/core/src/safefs.mjs 自校验锚点）')
}
export const PROJECT_ROOT = deriveProjectRoot()

/** 真实数据目录（生产）。S34·P0：测试经 ORB_DATA_DIR 整体挪走，真实目录测试期零写入。 */
export const REAL_DATA_DIR = join(PROJECT_ROOT, 'data')
export const REAL_LOGS_DIR = join(REAL_DATA_DIR, 'logs')

/**
 * S34·P0 数据目录隔离：ORB_DATA_DIR 决定整棵 data 树（config/notes/music/artifacts/themes/tmp/…）。
 * 默认真实 data；测试期 run-tests 指到 %TEMP%\orb-test-data-<pid>，真实目录零写入。
 * 显式指回真实目录必须告警。
 */
const ENV_DATA_DIR = process.env.ORB_DATA_DIR
export const DATA_DIR = resolve(ENV_DATA_DIR || REAL_DATA_DIR)
if (ENV_DATA_DIR && DATA_DIR.toLowerCase() === REAL_DATA_DIR.toLowerCase()) {
  process.stderr.write('[research-orb/safefs] 警告：ORB_DATA_DIR 指向真实数据目录（data），测试将污染真实数据；请指向临时目录。\n')
}

/**
 * S33·C 日志目录：默认跟随 DATA_DIR/logs（可被 ORB_LOG_DIR 单独覆盖）。
 */
const ENV_LOG_DIR = process.env.ORB_LOG_DIR
export const LOG_DIR = resolve(ENV_LOG_DIR || join(DATA_DIR, 'logs'))
if (ENV_LOG_DIR && LOG_DIR.toLowerCase() === REAL_LOGS_DIR.toLowerCase()) {
  process.stderr.write('[research-orb/safefs] 警告：ORB_LOG_DIR 指向真实日志目录（data/logs），测试将污染真实审计日志；请指向临时目录。\n')
}

/** 审计日志：所有 safeWrite 都会在这里留痕（跟随 LOG_DIR）。 */
export const WRITES_LOG = join(LOG_DIR, 'writes.jsonl')

/** 数据文件/目录路径（跟随 DATA_DIR；零参返回 DATA_DIR 本身）。 */
export function dataPath(...parts) {
  return parts.length ? join(DATA_DIR, ...parts) : DATA_DIR
}

/**
 * 冻结区（S67·3-D·G6）：
 *   · hard=true：**直接 throw E_PROTECTED_ZONE**（vendor 冻结快照 / db 迁移脚本，禁止任何写入）；
 *   · hard 省略：允许写但打标记（.snapshots 历史现场，用于追责）。
 */
const PROTECTED_ZONES = [
  { dir: join(PROJECT_ROOT, 'vendor'), reason: 'frozen-vendor-snapshot', hard: true },
  { dir: join(PROJECT_ROOT, 'packages', 'core', 'src', 'db', 'migrations'), reason: 'db-migrations-frozen', hard: true },
  { dir: join(PROJECT_ROOT, '.snapshots'), reason: 'phase-snapshot-archive' },
]

export class SafeFsError extends Error {
  constructor(code, message, target) {
    super(message)
    this.name = 'SafeFsError'
    this.code = code
    this.target = target
  }
}

/** 规范化路径；Windows 大小写不敏感，统一小写后再比较，避免 root 与 Root 绕开断言。 */
function normalize(p) {
  return resolve(String(p))
}

/** 判断 abs 是否落在 dir 之下（大小写不敏感，Windows 友好）。 */
function isUnderDir(abs, dir) {
  const a = resolve(String(abs)).toLowerCase()
  const d = resolve(String(dir)).toLowerCase()
  return a === d || a.startsWith(d.endsWith(sep) ? d : d + sep)
}

/**
 * 断言路径在项目根之下。越界抛 SafeFsError('E_OUTSIDE_ROOT')。
 * 注意：Windows 上跨盘符时 path.relative 会返回绝对路径，所以两种情况都要判。
 * @param {string} target
 * @returns {string} 绝对路径
 */
export function assertInsideRoot(target) {
  if (typeof target !== 'string' || target.length === 0) {
    throw new SafeFsError('E_BAD_PATH', 'safeFs: 路径必须是非空字符串', String(target))
  }
  if (target.includes('\0')) {
    throw new SafeFsError('E_BAD_PATH', 'safeFs: 路径含空字节', target)
  }
  const abs = normalize(target)
  const rel = relative(PROJECT_ROOT, abs)
  // rel === '' 表示目标就是根目录本身；跨盘符时 rel 是绝对路径。
  if (rel !== '' && (rel.startsWith('..' + sep) || rel === '..' || isAbsolute(rel))) {
    // S34·P0：可写根集合 = PROJECT_ROOT ∪ DATA_DIR ∪ LOG_DIR（测试期后两者可在根外）。
    if (isUnderDir(abs, DATA_DIR) || isUnderDir(abs, LOG_DIR)) return abs
    throw new SafeFsError(
      'E_OUTSIDE_ROOT',
      `safeFs: 拒绝越界写入（可写根 ${PROJECT_ROOT} / ${DATA_DIR} / ${LOG_DIR}）-> ${abs}`,
      abs,
    )
  }
  return abs
}

/** 冻结区检查：只打标记，不拦截。 */
export function protectedZoneOf(absPath) {
  const abs = normalize(absPath).toLowerCase()
  for (const zone of PROTECTED_ZONES) {
    const zdir = zone.dir.toLowerCase()
    if (abs === zdir || abs.startsWith(zdir + sep)) return zone.reason
  }
  return null
}

/** 硬冻结区检查（vendor / db/migrations）：命中返回 reason，调用方应拒绝写入。 */
export function hardProtectedZoneOf(absPath) {
  const abs = normalize(absPath).toLowerCase()
  for (const zone of PROTECTED_ZONES) {
    if (!zone.hard) continue
    const zdir = zone.dir.toLowerCase()
    if (abs === zdir || abs.startsWith(zdir + sep)) return zone.reason
  }
  return null
}

function mkdirp(absPath) {
  const dir = dirname(absPath)
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
}

function toBuffer(data) {
  if (Buffer.isBuffer(data)) return data
  if (data instanceof Uint8Array) return Buffer.from(data)
  if (typeof data === 'string') return Buffer.from(data, 'utf8')
  return Buffer.from(JSON.stringify(data, null, 2), 'utf8')
}

/**
 * 追加一行 JSON 到审计日志。审计自身失败不能反过来炸掉业务写入，
 * 但必须在 stderr 留下痕迹（此时 stdout/stderr 属于本应用，不是 dsh-orb）。
 */
function audit(entry) {
  try {
    mkdirp(WRITES_LOG)
    try { withFsRetry(() => appendFileSync(WRITES_LOG, JSON.stringify(entry) + '\n', 'utf8'), 'audit') } catch { /* 审计尽力：锁持久占用时放弃本行，不打断主流程 */ }
  } catch (err) {
    process.stderr.write(`[research-orb/safefs] audit failed: ${err && err.message}\n`)
  }
}

/**
 * 应用内唯一写文件出口。
 * @param {string} path 目标路径（绝对路径，或相对于项目根）
 * @param {string|Buffer|Uint8Array|object} data 内容
 * @param {{append?: boolean, audit?: boolean, encoding?: BufferEncoding}} [opts]
 * @returns {{path: string, bytes: number}} 实际写入的绝对路径与字节数
 */
export function safeWrite(path, data, opts = {}) {
  const rawAbs = resolve(String(path))
  // S33·C / S34·P0：日志与数据目录（可能被 ORB_LOG_DIR/ORB_DATA_DIR 指到项目根之外）允许写，
  // 不走根断言；其余仍严格夹逼 PROJECT_ROOT。
  const abs = isUnderDir(rawAbs, LOG_DIR) || isUnderDir(rawAbs, DATA_DIR) ? rawAbs : assertInsideRoot(path)
  // S67·3-D·G6：硬冻结区（vendor / db/migrations）直接拒绝，写审计追责后再抛。
  const hardReason = hardProtectedZoneOf(abs)
  if (hardReason) {
    audit({ ts: new Date().toISOString(), path: abs, denied: true, protected: true, reason: hardReason })
    throw new SafeFsError('E_PROTECTED_ZONE', `safeFs: 拒绝写入冻结区（${hardReason}）-> ${abs}`, abs)
  }
  const buf = toBuffer(data)
  // 目标就是审计日志本身时：只写不审，否则会自引用成环。
  const isAuditLog = abs.toLowerCase() === WRITES_LOG.toLowerCase()
  const auditEnabled = opts.audit !== false && !isAuditLog
  const mode = opts.append ? 'append' : 'write'

  mkdirp(abs)
  withFsRetry(() => {
    if (opts.append) appendFileSync(abs, buf)
    else writeFileSync(abs, buf)
  }, 'safeWrite')

  if (auditEnabled) {
    const reason = protectedZoneOf(abs)
    audit({
      ts: new Date().toISOString(),
      path: abs,
      bytes: buf.length,
      mode,
      ...(reason ? { protected: true, reason } : {}),
    })
  }
  return { path: abs, bytes: buf.length }
}

/**
 * 追加一行 JSONL（日志专用，无级联审计）。目标仍必须落在项目根之下。
 * @param {string} path
 * @param {unknown} record
 * @returns {{path: string, bytes: number}}
 */
export function appendJsonl(path, record) {
  const line = JSON.stringify(record) + '\n'
  const abs = resolve(String(path))
  // S33·C / S34·P0：日志与数据目录允许在项目根之外（测试隔离），绕开根断言。
  if (isUnderDir(abs, LOG_DIR) || isUnderDir(abs, DATA_DIR)) {
    mkdirp(abs)
    withFsRetry(() => appendFileSync(abs, line, 'utf8'), 'appendJsonl')
    return { path: abs, bytes: Buffer.byteLength(line) }
  }
  return safeWrite(path, line, { append: true, audit: false })
}

/** 日志文件路径（跟随 LOG_DIR；logs 目录由调用方按需创建）。 */
export function logPath(name) {
  return join(LOG_DIR, name)
}

export default { PROJECT_ROOT, REAL_DATA_DIR, DATA_DIR, REAL_LOGS_DIR, LOG_DIR, WRITES_LOG, SafeFsError, assertInsideRoot, protectedZoneOf, hardProtectedZoneOf, safeWrite, appendJsonl, logPath, dataPath }
