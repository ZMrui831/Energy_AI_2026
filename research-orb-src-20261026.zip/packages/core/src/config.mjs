// packages/core/src/config.mjs
//
// 凭据与配置的【唯一】读取入口（阶段 1 新增）。
//
// 为什么单独一个文件：SAFETY.md 第 4 节要求密钥只从 data\secrets.json 或环境变量读，
// 学校网关从 ~/.claude/settings.json 运行时直读。把"读密钥"收敛到一个文件，
// 审查只需盯这一处；provider 只拿到已经组装好的请求参数，不自己碰文件。
//
// 铁律：
//   · 只读，绝不写回 secrets.json / settings.json，也绝不复制 token 到别处
//   · 对外只暴露 describeConfig()（掩码），原值只交给发起请求的那一行代码
//   · 任何日志/汇报/截图都不得出现明文 —— 打印一律走 maskKey()

import { existsSync, readFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

import { PROJECT_ROOT, dataPath } from './safefs.mjs'

export const SECRETS_PATH = dataPath('secrets.json')
export const DEFAULT_CLAUDE_SETTINGS_PATH = join(homedir(), '.claude', 'settings.json')

/** 密钥打码：前 4 位 + ***（与 net.mjs 的 maskSecret 同口径，这里避免循环依赖而重复实现）。 */
export function maskKey(value) {
  if (typeof value !== 'string' || value.length === 0) return '***'
  if (value.length <= 4) return '***'
  return value.slice(0, 4) + '***'
}

function readJson(path) {
  if (!path || !existsSync(path)) return null
  try {
    return JSON.parse(readFileSync(path, 'utf8'))
  } catch {
    return null
  }
}

/** 读 secrets.json（只读；不存在或损坏返回 null，不抛）。 */
export function loadSecrets(secretsPath = SECRETS_PATH) {
  return readJson(secretsPath)
}

/**
 * deepseek-api 的请求参数。
 * @returns {{ baseUrl: string, apiKey: string, models: string[], ready: boolean, source: string }}
 */
export function deepseekConfig({ secretsPath = SECRETS_PATH, secrets = null, baseUrl = null, apiKey = null } = {}) {
  const doc = secrets || loadSecrets(secretsPath) || {}
  const ds = doc.deepseek || {}
  const configured = Array.isArray(ds.models) && ds.models.length > 0 ? ds.models.map(String) : null
  const resolved = {
    baseUrl: baseUrl || (typeof ds.baseUrl === 'string' && ds.baseUrl ? ds.baseUrl : 'https://api.deepseek.com'),
    apiKey: apiKey || (typeof ds.apiKey === 'string' ? ds.apiKey : ''),
    // 命题要求 deepseek-chat / deepseek-reasoner；secrets.json 里的 models 优先，缺省用这两个。
    models: configured || ['deepseek-chat', 'deepseek-reasoner'],
    source: existsSync(secretsPath) ? 'data/secrets.json' : 'default',
  }
  resolved.ready = resolved.apiKey.length > 0
  return resolved
}

/**
 * 网关对外开放的模型：命题（阶段 1）明确为 deepseek-chat / deepseek-reasoner。
 * secrets.json 的 gateway.models 里另配了 minimax-m2.7 / qwen3.8-27b —— 本阶段不开放，
 * 但会以 configuredModels 原样带出来（面板/自检可见），需要开放时把这里换成 configured 即可。
 */
export const GATEWAY_MANDATED_MODELS = Object.freeze(['deepseek-chat', 'deepseek-reasoner'])

/**
 * school-gateway 的请求参数：baseUrl 与 authToken 运行时从 ~/.claude/settings.json 的 env 读取。
 * @returns {{ baseUrl, authToken, settingsPath, models, configuredModels, ready, source, pathExists }}
 */
export function gatewayConfig({ secretsPath = SECRETS_PATH, secrets = null, settingsPath = null } = {}) {
  const doc = secrets || loadSecrets(secretsPath) || {}
  const gw = doc.gateway || {}
  const resolvedPath =
    settingsPath ||
    (typeof gw.settingsPath === 'string' && gw.settingsPath ? gw.settingsPath : DEFAULT_CLAUDE_SETTINGS_PATH)

  const settings = readJson(resolvedPath) || {}
  const env = settings.env && typeof settings.env === 'object' ? settings.env : {}
  const configured = Array.isArray(gw.models) && gw.models.length > 0 ? gw.models.map(String) : null

  const resolved = {
    baseUrl: typeof env.ANTHROPIC_BASE_URL === 'string' ? env.ANTHROPIC_BASE_URL : '',
    authToken: typeof env.ANTHROPIC_AUTH_TOKEN === 'string' ? env.ANTHROPIC_AUTH_TOKEN : '',
    settingsPath: resolvedPath,
    pathExists: existsSync(resolvedPath),
    models: [...GATEWAY_MANDATED_MODELS],
    configuredModels: configured || [],
    source: 'claude-settings',
  }
  resolved.ready = resolved.baseUrl.length > 0 && resolved.authToken.length > 0
  return resolved
}

/**
 * 可打印描述（掩码）：进日志、进面板、进 --selftest 的都是这个。
 * 注意这里只输出 baseUrl（不是密钥）、key 掩码与模型 id。
 */
export function describeConfig(config) {
  return {
    baseUrl: config.baseUrl || null,
    key: maskKey(config.apiKey || config.authToken || ''),
    models: [...(config.models || [])],
    ready: !!config.ready,
    source: config.source || null,
    ...(config.settingsPath ? { settingsPath: config.settingsPath } : {}),
    ...(config.configuredModels && config.configuredModels.length > 0
      ? { configuredModels: [...config.configuredModels] }
      : {}),
  }
}
