// packages/core/src/lifecycle/cleaner.mjs
//
// S3 清理状态机 runCleanup()——判据 1/2/3/5 与孤儿治理的执行体。
//
// 一轮的次序（任务书 §6）：
//   1. listExpiredReady → 单事务 markDeleting（先改状态后删文件：崩溃后由
//      listByStatus('deleting') 续跑，判据 2）；
//   2. 逐条删文件：先 assertInsideRoot 校验（根外 → 直接置 error，绝不 fs 操作），
//      成功 → 'deleted' + audit(frame-deleted)；失败 → 'error' 且 file_path 保留（判据 1）；
//   3. 拾起遗留 'deleting' 记录同样处理；
//   4. 同一条记录连续失败 3 轮 → audit(lifecycle-stuck) 并停止重试该条
//      （error 文本里带 attempt=N 标记，跨轮次、跨重启计数；E_OUTSIDE_ROOT 为
//      终局失败，不重试）；
//   5. 过期 active observation → tombstoneObservation（判据 3）；
//   6. 孤儿文件：shotsDir 下的 *.png 凡 DB 无 raw_frame 记录（任何状态都算“有记录”）
//      → 移入 trashDir 并 audit(orphan-moved)——只搬不删。空库护栏：库里一条
//      raw_frame 记录都没有时跳过扫描（首跑空库会把全部历史截图误判为孤儿）。
//
// 删文件是 safefs 纪律的例外：用 node:fs 直接删，但删前必须 assertInsideRoot。

import { assertInsideRoot } from '../safefs.mjs'
import { DEFAULT_LIFECYCLE_CONFIG, mergeLifecycleConfig } from '../db.mjs'
import { knownExternalPaths } from './capture-registry.mjs'
import { existsSync, mkdirSync, readdirSync, renameSync, rmSync, statSync } from 'node:fs'
import { join, resolve, dirname } from 'node:path'

/** 可重试失败标记：error 文本内嵌尝试次数，跨轮跨重启计数。 */
const ATTEMPT_RE = /E_DELETE_RETRYABLE attempt=(\d+)/
const STUCK_MARK = 'E_DELETE_STUCK'

export const CLEANUP_STATS_KEYS = ['marked', 'deleted', 'errored', 'tombstoned', 'orphansMoved', 'stuck', 'trashExpired']

function nowIso() {
  return new Date().toISOString()
}

/**
 * 删除单条 raw_frame 的物理文件并推进状态。
 * @returns {void}
 */
function deleteOne(store, row, stats, auditFn) {
  let abs
  try {
    abs = assertInsideRoot(row.file_path)
  } catch (e) {
    // 根外路径：终局失败，置 error 不删、不重试（判据 1：file_path 保留）。
    store.setRawFrameStatus(row.id, 'error', `E_OUTSIDE_ROOT: ${e.message}`)
    stats.errored += 1
    auditFn({ kind: 'frame-delete-denied', metadata: { id: row.id, file_path: row.file_path, reason: 'outside-root' } })
    return
  }
  try {
    // D10（CONTRACT §1.4 内的终态判定优化）：文件确实不存在时直接终态
    // deleted(reason=already-gone)，不空转重试轮次、不产 stuck 审计噪声。
    // 注意：只处理"不存在"这一种可判定事实；目录/占用等仍走原失败分支。
    if (!existsSync(abs)) {
      store.setRawFrameStatus(row.id, 'deleted')
      stats.deleted += 1
      auditFn({ kind: 'frame-deleted', metadata: { id: row.id, file_path: row.file_path, sha256: row.sha256, reason: 'already-gone' } })
      return
    }
    // force:false：文件不存在 / 是目录 / 被占用都会抛错 → 走失败分支。
    rmSync(abs, { force: false, recursive: false })
    store.setRawFrameStatus(row.id, 'deleted')
    stats.deleted += 1
    auditFn({ kind: 'frame-deleted', metadata: { id: row.id, file_path: row.file_path, sha256: row.sha256 } })
  } catch (e) {
    const msg = String(e && e.message ? e.message : e)
    const prev = ATTEMPT_RE.exec(row.error || '')
    const attempt = prev ? Number(prev[1]) + 1 : 1
    if (attempt >= 3) {
      // 连续 3 轮同一记录失败 → 记 stuck，之后任何一轮都不再重试该条。
      store.setRawFrameStatus(row.id, 'error', `${STUCK_MARK} attempts=${attempt}; lifecycle-stuck; ${msg}`)
      stats.errored += 1
      stats.stuck += 1
      auditFn({ kind: 'lifecycle-stuck', metadata: { id: row.id, attempts: attempt, last_error: msg } })
    } else {
      store.setRawFrameStatus(row.id, 'error', `E_DELETE_RETRYABLE attempt=${attempt}; ${msg}`)
      stats.errored += 1
    }
  }
}

/** 唯一化回收站目标名，避免同名孤儿互相覆盖。 */
function uniqueTrashPath(trashDir, name) {
  let dest = join(trashDir, name)
  if (!existsSync(dest)) return dest
  const stem = name.replace(/(\.[^.]+)$/, '')
  const ext = name.slice(stem.length) || ''
  let i = 1
  do {
    dest = join(trashDir, `${stem}-${Date.now()}-${i}${ext}`)
    i += 1
  } while (existsSync(dest))
  return dest
}

/**
 * 孤儿扫描：shotsDir 下的 *.png，DB 无记录 → 移入 trashDir（只搬不删）。
 * 已知路径 = DB 全部状态行 + **显式例外台账**（capture-registry：非应用进程抓屏的
 * 显式登记通道）。没有登记、DB 又无记录的 PNG 才是无主 → 搬回收站（不悄悄删）。
 * @returns {number} 移动数量
 */
function sweepOrphans(store, shotsDir, trashDir, auditFn, dataDir) {
  if (!shotsDir || !existsSync(shotsDir)) return 0
  const statuses = ['ready', 'deleting', 'deleted', 'error']
  let totalRows = 0
  const known = new Set()
  for (const st of statuses) {
    for (const r of store.listByStatus(st)) {
      totalRows += 1
      if (r.file_path) known.add(resolve(r.file_path).toLowerCase())
    }
  }
  if (totalRows === 0) {
    // 空库护栏：没有任何记录时不做孤儿判定，防止首跑误搬全部历史截图。
    auditFn({ kind: 'orphan-scan-skipped', metadata: { reason: 'empty-db-guard', shots_dir: String(shotsDir) } })
    return 0
  }
  // 显式例外通道（D11-②）：harness/人工抓屏登记过的路径也算"有主"
  let exceptions = 0
  try {
    const ext = knownExternalPaths(dataDir)
    exceptions = ext.size
    for (const p of ext) known.add(p)
  } catch { /* 台账不可用不阻断（DB 已知路径仍然有效） */ }
  mkdirSync(trashDir, { recursive: true })
  let moved = 0
  for (const name of readdirSync(shotsDir)) {
    if (!name.toLowerCase().endsWith('.png')) continue
    const p = join(shotsDir, name)
    if (known.has(resolve(p).toLowerCase())) continue
    try {
      assertInsideRoot(p)
    } catch {
      continue // shots 目录本身越界时逐文件跳过，不做 fs 操作
    }
    const dest = uniqueTrashPath(trashDir, name)
    renameSync(p, dest)
    moved += 1
    auditFn({ kind: 'orphan-moved', metadata: { from: p, to: dest } })
  }
  if (exceptions > 0) {
    auditFn({ kind: 'orphan-scan-exceptions', metadata: { known_external: exceptions, moved: moved } })
  }
  return moved
}

/**
 * 回收区到期（D11-①，CONTRACT §2）：trash 内超过 retention.trashDays 的文件**物理删除**
 * （回收区是最后一站，删后不可恢复），每条落 audit（trash-expired：路径/字节/mtime/ageDays）。
 * @returns {{expired:number, bytesFreed:number}}
 */
export function sweepTrash(trashDir, trashDays, auditFn, now = Date.now()) {
  const out = { expired: 0, bytesFreed: 0 }
  if (!trashDir || !existsSync(trashDir)) return out
  const ttlMs = Math.max(0, Number(trashDays) || 0) * 86_400_000
  let names = []
  try {
    names = readdirSync(trashDir)
  } catch { return out }
  for (const name of names) {
    const p = join(trashDir, name)
    let st = null
    try { st = statSync(p) } catch { continue }
    if (!st.isFile()) continue // 只清文件；目录交给人工
    const ageMs = now - st.mtimeMs
    if (ageMs < ttlMs) continue
    const ageDays = Math.round(ageMs / 86_400_000)
    try {
      rmSync(p, { force: true })
      out.expired += 1
      out.bytesFreed += st.size
      auditFn({ kind: 'trash-expired', metadata: { path: p, bytes: st.size, age_days: ageDays, ttl_days: trashDays } })
    } catch {
      auditFn({ kind: 'trash-expire-failed', metadata: { path: p, reason: 'rm-failed' } })
    }
  }
  return out
}

/** 回收区统计（体积/条数；统计命令与首页状态条用）。 */
export function trashStats(trashDir) {
  if (!trashDir || !existsSync(trashDir)) return { files: 0, bytes: 0 }
  let files = 0
  let bytes = 0
  try {
    for (const name of readdirSync(trashDir)) {
      try {
        const st = statSync(join(trashDir, name))
        if (st.isFile()) { files += 1; bytes += st.size }
      } catch { /* 跳过 */ }
    }
  } catch { /* 按空统计 */ }
  return { files, bytes }
}

/**
 * 跑一轮清理。
 * @param {{store: object, config?: object, shotsDir?: string, trashDir?: string, now?: string|number|Date, audit?: Function}} opts
 *   audit 可注入替代审计通道；缺省写 store.insertAuditEvent。
 * @returns {{marked:number, deleted:number, errored:number, tombstoned:number, orphansMoved:number, stuck:number}}
 */
export async function runCleanup({ store, config, shotsDir, trashDir, dataDir = null, now = new Date(), audit } = {}) {
  if (!store || typeof store.listExpiredReady !== 'function') {
    throw new Error('runCleanup: 需要注入 store（createStore 的返回值）')
  }
  const cfg = mergeLifecycleConfig(config || DEFAULT_LIFECYCLE_CONFIG)
  const auditFn = audit || ((ev) => store.insertAuditEvent({ ts: nowIso(), kind: ev.kind, metadata: ev.metadata }))
  const stats = { marked: 0, deleted: 0, errored: 0, tombstoned: 0, orphansMoved: 0, stuck: 0, trashExpired: 0 }
  const nowStr = now instanceof Date ? now.toISOString() : String(now)

  // 1. 过期 ready → deleting（先改状态，崩溃可续跑）
  const expired = store.listExpiredReady(nowStr, cfg.cleanup.batchSize ?? 500)
  if (expired.length > 0) {
    store.markDeleting(expired.map((r) => r.id))
    stats.marked = expired.length
  }

  // 2+3. 处理集 = 遗留 deleting（含本轮刚标记的）+ 轮次内可重试的 error
  const pending = store.listByStatus('deleting')
  const retryable = store.listByStatus('error').filter((r) => {
    const m = ATTEMPT_RE.exec(r.error || '')
    return m !== null && Number(m[1]) < 3
  })
  const processed = new Set()
  for (const row of [...pending, ...retryable]) {
    if (processed.has(row.id)) continue
    processed.add(row.id)
    const cur = store.getRawFrame(row.id) // 重读最新态，避免拿到过期快照
    if (!cur || cur.status === 'deleted') continue
    if ((cur.error || '').includes(STUCK_MARK)) continue // 已 stuck 的永不重试
    deleteOne(store, cur, stats, auditFn)
  }

  // 5. 过期 active observation → 墓碑（判据 3）
  const cutoff = new Date(Date.parse(nowStr) - cfg.retention.observationDays * 86_400_000).toISOString()
  for (const ob of store.listExpiredActiveObservations(cutoff)) {
    store.tombstoneObservation(ob.id)
    stats.tombstoned += 1
  }

  // 6. 孤儿文件 → 回收站（已知路径 = DB 行 + 显式例外台账）
  stats.orphansMoved = sweepOrphans(store, shotsDir, trashDir, auditFn, dataDir)

  // 7. 回收区到期（D11-①，CONTRACT §2）：超 retention.trashDays 物理删除（不可恢复），审计留痕
  const trashDays = Number(cfg.retention.trashDays) > 0 ? Number(cfg.retention.trashDays) : 7
  const tr = sweepTrash(trashDir, trashDays, auditFn, Date.parse(nowStr) || Date.now())
  stats.trashExpired = tr.expired

  return stats
}

export default { runCleanup }
