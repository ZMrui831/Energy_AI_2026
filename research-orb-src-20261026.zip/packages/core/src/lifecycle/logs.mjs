// packages/core/src/lifecycle/logs.mjs
//
// S3 数据生命周期 —— 日志轮转清扫器。
// 设计约束：
//   1. 不改 safefs、不介入任何写入路径：轮转是"事后清扫"，由调用方显式触发；
//   2. logsDir 必须显式传入——本模块绝不默认对真实 data/logs 做任何事；
//   3. fail-closed：切割后回读校验总行数，不一致抛 E_ROTATION_LINE_LOSS，
//      且在抛错之前不删除任何文件（宁可不清理，不可丢行）；
//   4. rotateOnly 名单（默认 writes.jsonl，即审计日志）的过期分片只归档不删除
//      （重命名为 -archived-<ts>），语义：审计记录永不丢。
//
// 落盘纪律：路径在项目根内 → 一律走 safefs 的 safeWrite/appendJsonl（关闭级联审计，
// 否则轮转审计日志会给审计日志再写一行、成环）；路径在根外（测试临时夹具）→ safefs
// 的根内断言会拒绝，此时退回 node:fs 直写，仅限显式传入的临时目录。

import {
  existsSync,
  readdirSync,
  readFileSync,
  renameSync,
  rmSync,
  statSync,
  appendFileSync,
  writeFileSync,
} from 'node:fs'
import { isAbsolute, join, relative, resolve, sep } from 'node:path'
import { PROJECT_ROOT, appendJsonl as safeAppendJsonl, safeWrite } from '../safefs.mjs'

// ---------------------------------------------------------------- 路径工具

function insideRoot(p) {
  const abs = resolve(String(p))
  const rel = relative(resolve(PROJECT_ROOT), abs)
  return rel === '' || !(rel.startsWith('..' + sep) || rel === '..' || isAbsolute(rel))
}

/** 根内走 safefs（audit:false 防止轮转审计日志时成环）；根外临时夹具直写。 */
function writeFileAny(path, data) {
  if (insideRoot(path)) return safeWrite(path, data, { audit: false })
  return writeFileSync(path, data, 'utf8')
}

/** 根内走 safefs appendJsonl；根外临时夹具直写。只允许 append 单行，绝不重写整文件。 */
function appendJsonlAny(path, record) {
  if (insideRoot(path)) return safeAppendJsonl(path, record)
  return appendFileSync(path, JSON.stringify(record) + '\n', 'utf8')
}

// ---------------------------------------------------------------- 解析工具

const RE_DAY_PART = /-(\d{8})(?:-(\d+))?\.jsonl$/
const RE_SEQ_PART = /-(\d+)\.jsonl$/
const RE_ARCHIVED = /-archived-[^.]+\.jsonl$/

/** 已切割文件（-YYYYMMDD / -YYYYMMDD-K / -K / -archived-*）不作为主文件再轮转。 */
function isSplitFileName(name) {
  return RE_DAY_PART.test(name) || RE_SEQ_PART.test(name) || RE_ARCHIVED.test(name)
}

function escapeRegex(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

function localDay(d) {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}${m}${day}`
}

/** 解析一行 JSON 的 ts 字段 → 本地 YYYYMMDD；解析失败归入 fallbackDay（当天）。 */
function dayOfLine(line, fallbackDay) {
  try {
    const obj = JSON.parse(line)
    const t =
      typeof obj?.ts === 'number'
        ? obj.ts
        : typeof obj?.ts === 'string'
          ? Date.parse(obj.ts)
          : NaN
    if (Number.isFinite(t)) return localDay(new Date(t))
  } catch {
    /* fallthrough */
  }
  return fallbackDay
}

function readLines(path) {
  const text = readFileSync(path, 'utf8')
  if (text === '') return []
  const lines = text.split('\n')
  if (lines[lines.length - 1] === '') lines.pop()
  return lines
}

function splitByBytes(lines, maxBytes) {
  const chunks = []
  let cur = []
  let curBytes = 0
  for (const line of lines) {
    const b = Buffer.byteLength(line, 'utf8') + 1
    if (cur.length > 0 && curBytes + b > maxBytes) {
      chunks.push(cur)
      cur = []
      curBytes = 0
    }
    cur.push(line)
    curBytes += b
  }
  if (cur.length > 0) chunks.push(cur)
  return chunks
}

// ---------------------------------------------------------------- 纯函数

/**
 * 给定行数组与单文件字节上限，返回按天（再按大小）切割的计划。
 * @param {string[]} lines
 * @param {{maxBytes?: number, dayOf?: (line: string) => string}} opts
 *   dayOf(line) 返回 'YYYYMMDD'；缺省时解析行 JSON 的 ts 字段（本地时区），失败归当天。
 * @returns {{totalLines: number, parts: Array<{suffix: string, day: string, index: number, lines: string[]}>}}
 *   suffix 形如 '-20261017'（单分片）或 '-20261017-1' / '-20261017-2'（超限再切）。
 */
export function planRotation(lines, opts = {}) {
  const maxBytes = opts.maxBytes ?? 8 * 1024 * 1024
  let dayOf = opts.dayOf
  if (typeof dayOf !== 'function') {
    const today = localDay(new Date())
    dayOf = (line) => dayOfLine(line, today)
  }
  const groups = new Map() // day -> lines（保持行序）
  for (const line of lines) {
    const day = dayOf(line)
    if (!groups.has(day)) groups.set(day, [])
    groups.get(day).push(line)
  }
  const parts = []
  let totalLines = 0
  for (const day of [...groups.keys()].sort()) {
    const dayLines = groups.get(day)
    totalLines += dayLines.length
    const chunks = splitByBytes(dayLines, maxBytes)
    chunks.forEach((chunk, i) => {
      parts.push({
        suffix: chunks.length === 1 ? `-${day}` : `-${day}-${i + 1}`,
        day,
        index: i + 1,
        lines: chunk,
      })
    })
  }
  return { totalLines, parts }
}

// ---------------------------------------------------------------- 主流程

/**
 * 日志轮转清扫器。
 * @param {{
 *   logsDir: string,                    // 必填，绝不默认指向真实 data/logs
 *   maxFileMB?: number,                 // 单文件上限，默认 8
 *   retainDays?: number,                // 保留天数，默认 14
 *   rotateOnly?: string[],              // 只轮转不删的文件名单，默认 ['writes.jsonl']
 *   now?: Date|number,
 * }} opts
 * @returns {{
 *   files: Array<{name, beforeLines, afterLines, parts, archivedOrDeleted}>,
 *   totalBeforeLines: number, totalAfterLines: number,
 * }}
 */
export function rotateLogs(opts = {}) {
  if (!opts.logsDir) {
    throw new Error('E_NO_LOGSDIR: rotateLogs 必须显式传入 logsDir（绝不默认轮转真实 data/logs）')
  }
  const logsDir = resolve(String(opts.logsDir))
  if (!existsSync(logsDir) || !statSync(logsDir).isDirectory()) {
    return { files: [], retention: [], totalBeforeLines: 0, totalAfterLines: 0 }
  }
  const now = opts.now ? new Date(opts.now) : new Date()
  const maxBytes = Math.max(1, Math.round((opts.maxFileMB ?? 8) * 1024 * 1024))
  const retainDays = opts.retainDays ?? 14
  const rotateOnly = new Set(
    (opts.rotateOnly ?? ['writes.jsonl', 'net.jsonl', 'tool.jsonl', 'perception.jsonl']).map((s) => String(s).replace(/\.jsonl$/, '')),
  )
  const today = localDay(now)

  const mainNames = readdirSync(logsDir)
    .filter((n) => n.endsWith('.jsonl') && n !== 'lifecycle.jsonl' && !isSplitFileName(n))
    .sort()

  const files = []
  const retainedActions = [] // {name, base, action, renamedTo?}
  let totalBefore = 0
  let totalAfter = 0

  for (const name of mainNames) {
    const mainPath = join(logsDir, name)
    const base = name.slice(0, -'.jsonl'.length)
    const beforeBytes = statSync(mainPath).size
    const mainLines = readLines(mainPath)
    const beforeLines = mainLines.length
    totalBefore += beforeLines

    // 1) 主文件内容按天分组
    const dayGroups = new Map()
    for (const line of mainLines) {
      const day = dayOfLine(line, today)
      if (!dayGroups.has(day)) dayGroups.set(day, [])
      dayGroups.get(day).push(line)
    }

    // 2) 同 base+day 的既有分片内容并入（防止覆盖丢失），计划新分片
    const parts = []
    const superseded = new Set() // 内容已被并入的旧分片，校验通过后才删除
    let mergedTotal = 0
    for (const day of [...dayGroups.keys()].sort()) {
      const merged = []
      const dayRe = new RegExp(`^${escapeRegex(base)}-${day}(?:-(\\d+))?\\.jsonl$`)
      const existing = readdirSync(logsDir)
        .filter((n) => dayRe.test(n))
        .sort()
      for (const old of existing) {
        // 20MB 级文件可达 30 万行：spread 展开超 V8 参数上限（~65k）会炸
        // RangeError: Maximum call stack size exceeded —— 必须迭代 push。
        for (const l of readLines(join(logsDir, old))) merged.push(l)
        superseded.add(old)
      }
      for (const l of dayGroups.get(day)) merged.push(l)
      mergedTotal += merged.length
      const chunks = splitByBytes(merged, maxBytes)
      chunks.forEach((chunk, i) => {
        parts.push({
          name: chunks.length === 1 ? `${base}-${day}.jsonl` : `${base}-${day}-${i + 1}.jsonl`,
          lines: chunk,
        })
      })
    }

    // 3) 先写分片，再回读校验总行数——不过则抛 E_ROTATION_LINE_LOSS，
    //    此时尚未清空主文件、未删除任何旧分片（fail-closed）
    let afterBytes = 0
    for (const part of parts) {
      const p = join(logsDir, part.name)
      writeFileAny(p, part.lines.length ? part.lines.join('\n') + '\n' : '')
      afterBytes += statSync(p).size
    }
    let writtenLines = 0
    for (const part of parts) writtenLines += readLines(join(logsDir, part.name)).length
    if (writtenLines !== mergedTotal) {
      const err = new Error(
        `E_ROTATION_LINE_LOSS: ${name} 切割后行数不一致（expect=${mergedTotal} got=${writtenLines}），已中止且未删除任何文件`,
      )
      err.code = 'E_ROTATION_LINE_LOSS'
      throw err
    }

    // 4) 校验通过：主文件清空（内容已全部归档到按天分片，总行数不变）
    writeFileAny(mainPath, '')

    // 5) 删除内容已被并入新分片的旧文件
    for (const old of superseded) {
      if (!parts.some((p) => p.name === old)) rmSync(join(logsDir, old), { force: true })
    }

    const afterLines = writtenLines // 主文件归零 + 分片行数
    totalAfter += afterLines
    files.push({ name, beforeLines, afterLines, parts: parts.map((p) => p.name), archivedOrDeleted: [] })

    // 6) 轮转记录 → lifecycle.jsonl（append 单行，绝不重写整文件）
    appendJsonlAny(join(logsDir, 'lifecycle.jsonl'), {
      ts: now.toISOString(),
      kind: 'log-rotated',
      file: name,
      beforeBytes,
      afterBytes,
      beforeLines,
      afterLines,
      parts: parts.map((p) => p.name),
    })
  }

  // 7) 保留期清扫：-YYYYMMDD 分片早于 now-retainDays 的删除；
  //    rotateOnly 名单的只重命名为 -archived-<ts>（审计永不丢）。
  //    注意：只有行数校验全部通过后才会走到这里。
  const cutoffMs = now.getTime() - retainDays * 86400000
  for (const n of readdirSync(logsDir)) {
    const m = RE_DAY_PART.exec(n)
    if (!m) continue
    const d = m[1]
    const dayMs = Date.parse(`${d.slice(0, 4)}-${d.slice(4, 6)}-${d.slice(6, 8)}T00:00:00`)
    if (!(Number.isFinite(dayMs) && dayMs < cutoffMs)) continue
    const base = n.replace(RE_DAY_PART, '')
    const p = join(logsDir, n)
    if (rotateOnly.has(base)) {
      const newName = n.replace(/\.jsonl$/, `-archived-${now.getTime()}.jsonl`)
      renameSync(p, join(logsDir, newName))
      retainedActions.push({ name: n, base, action: 'archived', renamedTo: newName })
    } else {
      rmSync(p, { force: true })
      retainedActions.push({ name: n, base, action: 'deleted' })
    }
  }
  for (const act of retainedActions) {
    const entry = files.find((f) => f.name.replace(/\.jsonl$/, '') === act.base)
    if (entry) entry.archivedOrDeleted.push(act)
  }

  return { files, retention: retainedActions, totalBeforeLines: totalBefore, totalAfterLines: totalAfter }
}

export default { rotateLogs, planRotation }
