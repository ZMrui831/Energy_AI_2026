// packages/core/src/lifecycle/import.mjs
//
// S3 数据生命周期 —— S2 感知事件导入（宽松解析 + 幂等）。
//
// 设计约束：
//   1. data/perception 只读：本模块只读 events-*.jsonl，绝不写感知目录；
//   2. 目录/文件不存在 → 正常返回 {skipped:true}，绝不抛错（没有 S2 数据不是故障）；
//   3. 宽松解析：畸形行跳过计数、不中断；tick-batch（内存聚合产物）不进 DB；
//   4. 幂等键 (ts, kind, sha256(rawLine))：通过 store.findObservationBySourceKey 查重，
//      已有同键记录（row.id 相同）则跳过；
//   5. 写入只走注入的 store（契约见下）。defaultStore() 为惰性动态 import A 路的
//      ../db.mjs——本模块顶层不 import 它，测试一律用注入的 fake store。
//
// store 注入契约（由 A 路的 db.mjs 实现）：
//   upsertObservation(rec)            => void   // rec: {id, kind, source_frame_id, ocr_excerpt, created_at}
//   findObservationBySourceKey(ts, kind) => row|null  // 按 (created_at 毫秒 ts, kind) 查
//   insertAuditEvent({ts, kind, metadata}) => void

import { createHash } from 'node:crypto'
import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { join, resolve } from 'node:path'

/**
 * 宽松解析一行 S2 事件。
 * @param {string} line
 * @returns {{ok:true, rec:{id, kind, ts, rawSha256}} |
 *           {ok:false, reason: string, isTickBatch: boolean}}
 */
export function parseEventLine(line) {
  const trimmed = String(line ?? '').trim()
  if (!trimmed) return { ok: false, reason: 'empty-line', isTickBatch: false }
  let obj
  try {
    obj = JSON.parse(trimmed)
  } catch {
    return { ok: false, reason: 'json-parse-failed', isTickBatch: false }
  }
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) {
    return { ok: false, reason: 'not-object', isTickBatch: false }
  }
  // summary 批次行（内存聚合产物）不导入为 observation
  if (obj.type === 'tick-batch') {
    return { ok: false, reason: 'tick-batch', isTickBatch: true }
  }
  if (typeof obj.type !== 'string' || obj.type === '') {
    return { ok: false, reason: 'missing-type', isTickBatch: false }
  }
  const ts =
    typeof obj.ts === 'number'
      ? obj.ts
      : typeof obj.ts === 'string'
        ? Date.parse(obj.ts)
        : NaN
  if (!Number.isFinite(ts)) {
    return { ok: false, reason: 'missing-or-bad-ts', isTickBatch: false }
  }
  const rawSha256 = createHash('sha256').update(trimmed, 'utf8').digest('hex')
  // id 只含 ts + 哈希前缀，不含文件名/标题等敏感信息
  const id = `obs_${ts}_${rawSha256.slice(0, 10)}`
  return { ok: true, rec: { id, kind: obj.type, ts, rawSha256 } }
}

/**
 * 导入 S2 感知事件到注入的 store。
 * @param {{
 *   store: {upsertObservation, findObservationBySourceKey, insertAuditEvent?},
 *   perceptionDir?: string,   // 默认 'data/perception'（只读）
 *   now?: Date|number,
 * }} opts
 * @returns {{skipped:true, note:string} |
 *           {skipped:false, files:number, imported:number, skippedDuplicates:number,
 *            skippedMalformed:number, skippedTickBatch:number}}
 */
export function importPerceptionEvents(opts = {}) {
  const { store } = opts
  if (!store || typeof store.upsertObservation !== 'function') {
    throw new Error('E_NO_STORE: importPerceptionEvents 需要显式注入 store（或使用 defaultStore()）')
  }
  const dir = resolve(String(opts.perceptionDir ?? 'data/perception'))
  const note = '未发现 S2 数据，跳过'
  if (!existsSync(dir) || !statSync(dir).isDirectory()) return { skipped: true, note }
  const files = readdirSync(dir)
    .filter((n) => /^events-.*\.jsonl$/.test(n))
    .sort()
  if (files.length === 0) return { skipped: true, note }

  let imported = 0
  let skippedDuplicates = 0
  let skippedMalformed = 0
  let skippedTickBatch = 0

  for (const name of files) {
    const lines = readLinesOf(join(dir, name))
    for (const line of lines) {
      const parsed = parseEventLine(line)
      if (!parsed.ok) {
        if (parsed.isTickBatch) skippedTickBatch++
        else skippedMalformed++
        continue
      }
      const { id, kind, ts } = parsed.rec
      const existing = store.findObservationBySourceKey(ts, kind)
      if (existing && existing.id === id) {
        skippedDuplicates++
        continue
      }
      store.upsertObservation({
        id,
        kind,
        source_frame_id: null,
        ocr_excerpt: null,
        created_at: new Date(ts).toISOString(),
      })
      imported++
    }
  }

  const summary = {
    files: files.length,
    imported,
    skippedDuplicates,
    skippedMalformed,
    skippedTickBatch,
  }
  if (typeof store.insertAuditEvent === 'function') {
    const now = opts.now ? new Date(opts.now) : new Date()
    store.insertAuditEvent({
      ts: now.toISOString(),
      kind: 'perception-imported',
      metadata: summary,
    })
  }
  return { skipped: false, ...summary }
}

function readLinesOf(path) {
  const text = readFileSync(path, 'utf8')
  if (text === '') return []
  const lines = text.split('\n')
  if (lines[lines.length - 1] === '') lines.pop()
  return lines
}

// ---------------------------------------------------------------- 默认 store

let _defaultStorePromise = null

/**
 * 惰性默认 store 工厂：动态 import A 路的 ../db.mjs → createStore({driver:'auto'})。
 * 测试绝不调用它（不依赖 A 路进度）；只在真实运行入口使用。
 */
export function defaultStore() {
  if (!_defaultStorePromise) {
    _defaultStorePromise = import('../db.mjs').then((db) => db.createStore({ driver: 'auto' }))
  }
  return _defaultStorePromise
}

export default { parseEventLine, importPerceptionEvents, defaultStore }
