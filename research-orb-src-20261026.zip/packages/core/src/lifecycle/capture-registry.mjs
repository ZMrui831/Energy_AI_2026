// packages/core/src/lifecycle/capture-registry.mjs
//
// S8 · 抓屏登记一致（CONTRACT §2/§6）：任何落在 data\shots\ 的 PNG 都必须"有主"——
//   产品路径：S1 screen.capture（宿主桥）→ insertRawFrame（DB 登记，raw_frame 行即身份）；
//   非应用进程（独立 harness / 人工取证）产生的抓屏：必须走本模块的**显式例外通道**
//   （registerExternalCapture：入根校验 + sha256 + reason + 审计），孤儿清扫据此认得它，
//   **不塞进孤儿扫描的猜测逻辑**（那会掩盖 harness/app 路径差异）。
//
// 台账：<dataDir>/capture-exceptions.jsonl（append-only；只增不删，与 audit 同纪律）。

import { existsSync, appendFileSync, mkdirSync, readFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { join, resolve, basename } from 'node:path'

import { assertInsideRoot } from '../safefs.mjs'

export const EXCEPTIONS_FILE = 'capture-exceptions.jsonl'

const sha256Of = (buf) => createHash('sha256').update(buf).digest('hex')

/** 例外台账路径（dataDir 下）。 */
export function exceptionsPath(dataDir) {
  return join(dataDir, EXCEPTIONS_FILE)
}

/**
 * 显式登记一次"非应用进程产生的抓屏"。
 * @param {{dataDir:string, filePath:string, reason:string, by?:string}} input
 * @returns {{ok:boolean, id?:string, sha256?:string, error?:string}}
 */
export function registerExternalCapture({ dataDir, filePath, reason, by = 'harness' }) {
  if (!dataDir || !filePath) return { ok: false, error: 'E_ARGS: dataDir/filePath 必填' }
  if (!reason || !String(reason).trim()) return { ok: false, error: 'E_ARGS: reason 必填（例外必须可解释）' }
  let abs
  try {
    abs = assertInsideRoot(filePath)
  } catch (e) {
    return { ok: false, error: `E_OUTSIDE_ROOT: ${e.message}` }
  }
  if (!existsSync(abs)) return { ok: false, error: `E_NOT_FOUND: ${abs}` }
  let sha
  try {
    sha = sha256Of(readFileSync(abs))
  } catch (e) {
    return { ok: false, error: `E_READ: ${e.message}` }
  }
  const id = `capx_${Date.now()}_${sha.slice(0, 8)}`
  const rec = { id, ts: new Date().toISOString(), path: abs, name: basename(abs), sha256: sha, reason: String(reason).slice(0, 300), by: String(by).slice(0, 60) }
  try {
    mkdirSync(dataDir, { recursive: true })
    appendFileSync(exceptionsPath(dataDir), JSON.stringify(rec) + '\n', 'utf8')
  } catch (e) {
    return { ok: false, error: `E_WRITE: ${e.message}` }
  }
  return { ok: true, id, sha256: sha, path: abs }
}

/**
 * 孤儿扫描的"已知路径"补充源：例外台账登记过的抓屏（小写绝对路径集合）。
 * @param {string} dataDir
 * @returns {Set<string>}
 */
export function knownExternalPaths(dataDir) {
  const out = new Set()
  const p = exceptionsPath(dataDir)
  if (!existsSync(p)) return out
  try {
    for (const line of readFileSync(p, 'utf8').split('\n')) {
      const s = line.trim()
      if (!s) continue
      try {
        const rec = JSON.parse(s)
        if (rec && rec.path) out.add(resolve(rec.path).toLowerCase())
      } catch { /* 半行跳过 */ }
    }
  } catch { /* 台账不可读按空集合（不猜） */ }
  return out
}

/** 例外台账条数（统计命令用）。 */
export function countExternalCaptures(dataDir) {
  return knownExternalPaths(dataDir).size
}

export default { registerExternalCapture, knownExternalPaths, countExternalCaptures, exceptionsPath, EXCEPTIONS_FILE }
