// packages/core/src/lifecycle/publish.mjs
//
// S6 证据闸 · 发布流程（CONTRACT §6）：草稿 → 证据校验 → 发布。
//
// 分工（红线：强制点在**数据层**）：
//   · 数据层：migrations/0002_claim_evidence.sql 的触发器
//     CLAIM_EVIDENCE_REQUIRED / SUMMARY_EVIDENCE_REQUIRED / *_no_direct_published_insert。
//     任何路径（本模块、裸 SQL、第三方工具）绕过应用层都逃不过触发器。
//   · 本模块：可解释的流程与审计——缺证据必须**停在草稿**并留下 audit（publish-blocked），
//     none 证据明确拒绝（E_NONE_EVIDENCE），发布成功落 audit（claim-published）。
//   · 删除后的诚实性：resolveEvidence() 对已清理原图返回固定降级文案，
//     结论仍可回指（evidence_id + sha256 不随文件删除而消失）。
//
// 依赖纪律：只调用 db.mjs 公开 API（createStore/initMigrations/insertAuditEvent/
// getRawFrame/setRawFrameStatus/close）与 node:sqlite 的既存连接（store._db，sqlite driver）；
// jsonl driver 无关系表 → 诚实降级 E_DRIVER_UNSUPPORTED（不伪装能发布）。
//
// 证据 ID（CONTRACT §6）：ev_<kind>_<utc_ms>_<rand>。

import { randomBytes } from 'node:crypto'
import { existsSync as fsExistsSync } from 'node:fs'

export const DEGRADED_EVIDENCE_COPY = '原图已按保留策略删除；保留时间、窗口、摘要与内容哈希，无法恢复画面。'

/** 本片迁移文件名（回滚/审计对账用）。 */
export const MIGRATION_FILE = '0002_claim_evidence.sql'

/** §6 证据 ID：ev_<kind>_<utc_ms>_<rand>。 */
export function nextEvidenceId(kind = 'obs', now = Date.now()) {
  const rand = randomBytes(3).toString('hex')
  return `ev_${kind}_${now}_${rand}`
}

function rawDb(store) {
  // sqlite driver：类实例持 this._db（node:sqlite DatabaseSync）。jsonl → null。
  return store && store._db ? store._db : null
}

function audit(store, kind, metadata) {
  try {
    store.insertAuditEvent({ ts: new Date().toISOString(), kind, metadata })
  } catch { /* 审计失败不改发布结论，但调用方应记录 */ }
}

// ---------------------------------------------------------------------------
// claim 草稿
// ---------------------------------------------------------------------------

/** 创建 claim（只能 draft；直插 published 会被 0002 触发器拒绝——这里也先挡一道）。 */
export function createClaim(store, { id, kind = 'observation', text, evidenceMode = 'direct' }) {
  const db = rawDb(store)
  if (!db) return { ok: false, code: 'E_DRIVER_UNSUPPORTED', reason: 'claim 需要 sqlite driver（数据层强制）；jsonl 降级不可发布' }
  if (!id || !text) return { ok: false, code: 'E_ARGS', reason: 'id/text 必填' }
  if (!['direct', 'derived', 'none'].includes(evidenceMode)) return { ok: false, code: 'E_ARGS', reason: 'evidenceMode ∈ direct|derived|none' }
  db.prepare('INSERT INTO claim(id, kind, text, evidence_mode, status, created_at) VALUES (?, ?, ?, ?, ?, ?)')
    .run(id, kind, String(text), evidenceMode, 'draft', new Date().toISOString())
  return { ok: true, id, status: 'draft' }
}

/** 关联一条证据（layer 声明指哪一层；relation  direct|derived|none）。 */
export function attachEvidence(store, { claimId, evidenceId, layer = 'raw_frame', relation = 'direct', sha256 = null }) {
  const db = rawDb(store)
  if (!db) return { ok: false, code: 'E_DRIVER_UNSUPPORTED', reason: 'claim 需要 sqlite driver' }
  if (!claimId || !evidenceId) return { ok: false, code: 'E_ARGS', reason: 'claimId/evidenceId 必填' }
  const r = db.prepare('INSERT INTO claim_evidence(claim_id, evidence_id, layer, relation, sha256, created_at) VALUES (?, ?, ?, ?, ?, ?)')
    .run(claimId, String(evidenceId), layer, relation, sha256 || null, new Date().toISOString())
  return { ok: true, linkId: Number(r.lastInsertRowid), claimId, evidenceId, layer, relation }
}

/** 非 none 证据条数（发布闸的判定口径，与触发器一致）。 */
export function countPublishableEvidence(store, claimId) {
  const db = rawDb(store)
  if (!db) return -1
  const row = db.prepare("SELECT COUNT(*) AS n FROM claim_evidence WHERE claim_id = ? AND relation <> 'none'").get(claimId)
  return Number(row.n)
}

// ---------------------------------------------------------------------------
// 发布：草稿 → 证据校验 → 发布（缺证据停在草稿 + 可解释审计）
// ---------------------------------------------------------------------------

/**
 * 发布一条 claim。返回 {ok, code?, status, evidenceCount, reason?}。
 *   · 缺证据 → ok:false, code:'CLAIM_EVIDENCE_REQUIRED'，**不更新**（停在草稿），audit=publish-blocked。
 *   · evidence_mode='none' → ok:false, code:'E_NONE_EVIDENCE'（§6: none 不得进正式结论）。
 *   · 成功 → status='published'，audit=claim-published。
 *   · 触发器兜底：计数与更新之间证据被删 → 更新被 DB 拒绝，如实返回触发器报文。
 */
export function publishClaim(store, claimId) {
  const db = rawDb(store)
  if (!db) return { ok: false, code: 'E_DRIVER_UNSUPPORTED', status: 'draft', reason: 'claim 需要 sqlite driver（数据层强制）' }
  const claim = db.prepare('SELECT id, status, evidence_mode FROM claim WHERE id = ?').get(claimId)
  if (!claim) return { ok: false, code: 'E_NO_CLAIM', status: 'draft', reason: `claim 不存在：${claimId}` }
  if (claim.status === 'published') return { ok: true, already: true, status: 'published', claimId }
  if (claim.status === 'deleted') return { ok: false, code: 'E_CLAIM_DELETED', status: 'deleted', reason: 'claim 已删除，不得发布' }

  if (claim.evidence_mode === 'none') {
    audit(store, 'publish-blocked', { claimId, reason: 'evidence_mode=none：无直接证据不得进正式结论（CONTRACT §6）', code: 'E_NONE_EVIDENCE' })
    return { ok: false, code: 'E_NONE_EVIDENCE', status: 'draft', claimId, reason: 'evidence_mode=none：无直接证据不得进正式结论' }
  }

  const n = countPublishableEvidence(store, claimId)
  if (n <= 0) {
    audit(store, 'publish-blocked', { claimId, reason: 'CLAIM_EVIDENCE_REQUIRED：非 none 证据 0 条，停在草稿', evidenceCount: n, code: 'CLAIM_EVIDENCE_REQUIRED' })
    return { ok: false, code: 'CLAIM_EVIDENCE_REQUIRED', status: 'draft', claimId, evidenceCount: n, reason: '非 none 证据 0 条，停在草稿' }
  }

  try {
    db.prepare("UPDATE claim SET status = 'published', published_at = ? WHERE id = ?")
      .run(new Date().toISOString(), claimId)
  } catch (err) {
    // 数据层触发器兜底（例如并发下证据被清空）：如实记录，不伪装成功。
    const msg = String((err && err.message) || err)
    audit(store, 'publish-blocked', { claimId, reason: msg.slice(0, 300), evidenceCount: n, code: 'CLAIM_EVIDENCE_REQUIRED' })
    return { ok: false, code: 'CLAIM_EVIDENCE_REQUIRED', status: 'draft', claimId, evidenceCount: n, reason: msg }
  }
  const evIds = db.prepare("SELECT evidence_id FROM claim_evidence WHERE claim_id = ? AND relation <> 'none'").all(claimId).map((r) => r.evidence_id)
  audit(store, 'claim-published', { claimId, evidenceCount: n, evidence_ids: evIds })
  return { ok: true, status: 'published', claimId, evidenceCount: n, evidence_ids: evIds }
}

/** summary 发布闸（§6: summary draft→published 必须有证据）。 */
export function publishSummary(store, summaryId) {
  const db = rawDb(store)
  if (!db) return { ok: false, code: 'E_DRIVER_UNSUPPORTED', status: 'draft', reason: 'summary 发布闸需要 sqlite driver' }
  const row = db.prepare('SELECT id, status FROM summary WHERE id = ?').get(summaryId)
  if (!row) return { ok: false, code: 'E_NO_SUMMARY', status: 'draft', reason: `summary 不存在：${summaryId}` }
  if (row.status === 'published') return { ok: true, already: true, status: 'published', summaryId }
  if (row.status === 'deleted') return { ok: false, code: 'E_SUMMARY_DELETED', status: 'deleted', reason: 'summary 已删除，不得发布' }
  const n = Number(db.prepare("SELECT COUNT(*) AS n FROM summary_evidence WHERE summary_id = ? AND relation <> 'none'").get(summaryId).n)
  if (n <= 0) {
    audit(store, 'publish-blocked', { summaryId, reason: 'CLAIM_EVIDENCE_REQUIRED：summary 非 none 证据 0 条，停在草稿', evidenceCount: n, code: 'CLAIM_EVIDENCE_REQUIRED' })
    return { ok: false, code: 'CLAIM_EVIDENCE_REQUIRED', status: 'draft', summaryId, evidenceCount: n, reason: '非 none 证据 0 条，停在草稿' }
  }
  try {
    db.prepare("UPDATE summary SET status = 'published' WHERE id = ?").run(summaryId)
  } catch (err) {
    const msg = String((err && err.message) || err)
    audit(store, 'publish-blocked', { summaryId, reason: msg.slice(0, 300), evidenceCount: n, code: 'CLAIM_EVIDENCE_REQUIRED' })
    return { ok: false, code: 'CLAIM_EVIDENCE_REQUIRED', status: 'draft', summaryId, evidenceCount: n, reason: msg }
  }
  audit(store, 'summary-published', { summaryId, evidenceCount: n })
  return { ok: true, status: 'published', summaryId, evidenceCount: n }
}

// ---------------------------------------------------------------------------
// 删除后的诚实性（§6）：证据仍可回指；原图没了就说没了，固定文案，不伪装
// ---------------------------------------------------------------------------

function minutesLeft(iso, now) {
  const ms = Date.parse(iso) - now
  return Number.isFinite(ms) ? Math.max(0, Math.round(ms / 60000)) : null
}

/**
 * 解析一条证据的当前状态（供轨迹页/claim 详情回指）。
 * @returns {{evidence_id, layer, status, label, sha256?, file_path?, remainingMinutes?}}
 */
export function resolveEvidence(store, evidenceId, layer = 'raw_frame', now = Date.now()) {
  if (layer === 'raw_frame') {
    const row = store.getRawFrame(evidenceId)
    if (!row) return { evidence_id: evidenceId, layer, status: 'unregistered', label: '未登记到生命周期库' }
    if (row.status === 'deleted') {
      return { evidence_id: evidenceId, layer, status: 'deleted', label: DEGRADED_EVIDENCE_COPY, sha256: row.sha256, file_path: row.file_path }
    }
    if (row.status === 'error') {
      return { evidence_id: evidenceId, layer, status: 'error', label: '清理失败（保留待排查）：画面不可查看，哈希可回指', sha256: row.sha256, file_path: row.file_path }
    }
    const fs = globalThis.__s6fs // 测试可注入；默认走 node:fs
    let alive = false
    try {
      const existsSync = fs || fsExistsSync
      alive = existsSync(row.file_path)
    } catch { alive = false }
    if (!alive) {
      return { evidence_id: evidenceId, layer, status: 'missing', label: '原图文件缺失（已被移动或清理）；保留 sha256 可回指，无法恢复画面', sha256: row.sha256, file_path: row.file_path }
    }
    return {
      evidence_id: evidenceId, layer, status: 'available',
      label: `原图在盘（保留倒计时 ${minutesLeft(row.expires_at, now)} 分钟）`,
      sha256: row.sha256, file_path: row.file_path, remainingMinutes: minutesLeft(row.expires_at, now),
    }
  }
  // 其它层：存在性与状态（observation 软删 / summary 软删都有行保留，可回指）
  const db = rawDb(store)
  if (!db) return { evidence_id: evidenceId, layer, status: 'unregistered', label: '该层不可对账（jsonl 降级）' }
  if (layer === 'observation') {
    const r = db.prepare('SELECT id, status FROM observation WHERE id = ?').get(evidenceId)
    if (!r) return { evidence_id: evidenceId, layer, status: 'unregistered', label: '未登记的 observation' }
    return { evidence_id: evidenceId, layer, status: r.status === 'deleted' ? 'deleted' : 'available', label: r.status === 'deleted' ? 'observation 已软删（tombstone，id 仍可引用）' : 'observation 在册' }
  }
  if (layer === 'summary') {
    const r = db.prepare('SELECT id, status FROM summary WHERE id = ?').get(evidenceId)
    if (!r) return { evidence_id: evidenceId, layer, status: 'unregistered', label: '未登记的 summary' }
    return { evidence_id: evidenceId, layer, status: r.status, label: `summary 状态=${r.status}` }
  }
  return { evidence_id: evidenceId, layer, status: 'available', label: `${layer} 层证据（id 可回指）` }
}

/** claim 的完整回指清单（轨迹页/审计用）。 */
export function claimEvidenceReport(store, claimId, now = Date.now()) {
  const db = rawDb(store)
  if (!db) return { ok: false, code: 'E_DRIVER_UNSUPPORTED' }
  const claim = db.prepare('SELECT id, kind, text, evidence_mode, status, created_at, published_at FROM claim WHERE id = ?').get(claimId)
  if (!claim) return { ok: false, code: 'E_NO_CLAIM' }
  const links = db.prepare('SELECT evidence_id, layer, relation, sha256 FROM claim_evidence WHERE claim_id = ? ORDER BY id').all(claimId)
  // S67·3-D·D4：详情展示路径的只读完整性复查——published 但（非 none）证据为 0 → 告警，
  // 不自动改状态（改状态属业务决策，交给人）。
  const nonNone = links.filter((l) => l.relation !== 'none').length
  const integrityWarning = claim.status === 'published' && nonNone === 0 ? '证据缺失' : undefined
  return {
    ok: true, claim,
    evidence: links.map((l) => resolveEvidence(store, l.evidence_id, l.layer, now)),
    ...(integrityWarning ? { integrityWarning } : {}),
    degraded: links.some((l) => l.layer === 'raw_frame' && resolveEvidence(store, l.evidence_id, l.layer, now).status !== 'available'),
  }
}

/**
 * S67·3-D·G4：已发布结论完整性复查。
 * published 结论必须至少有一条 relation<>'none' 的 claim_evidence；若证据被剥离而结论
 * 仍是 published（删证据未联动 / 历史脏数据），这里逐条报出。导出/展示前调用。
 * @returns {{ok:boolean, code?:string, broken:Array<{id:string,text:string}>}}
 */
export function verifyClaimIntegrity(store) {
  const db = rawDb(store)
  if (!db) return { ok: false, code: 'E_DRIVER_UNSUPPORTED', broken: [] }
  let rows = []
  try {
    rows = db.prepare(
      `SELECT c.id, c.text FROM claim c
       WHERE c.status = 'published'
         AND (SELECT COUNT(*) FROM claim_evidence ce WHERE ce.claim_id = c.id AND ce.relation <> 'none') = 0`,
    ).all()
  } catch (e) {
    return { ok: false, code: 'E_INTEGRITY_QUERY', broken: [], reason: String((e && e.message) || e) }
  }
  return { ok: rows.length === 0, broken: rows.map((r) => ({ id: r.id, text: String(r.text || '').slice(0, 60) })) }
}

// ---------------------------------------------------------------------------
// 回滚路径（§7 沙箱内验证）：drop 本片对象 + 迁移账本登记（幂等）
// ---------------------------------------------------------------------------

export function rollbackS6(store) {
  const db = rawDb(store)
  if (!db) return { ok: false, code: 'E_DRIVER_UNSUPPORTED' }
  db.exec('BEGIN')
  try {
    db.exec('DROP TRIGGER IF EXISTS CLAIM_EVIDENCE_REQUIRED')
    db.exec('DROP TRIGGER IF EXISTS SUMMARY_EVIDENCE_REQUIRED')
    db.exec('DROP TRIGGER IF EXISTS trg_claim_no_direct_published_insert')
    db.exec('DROP TRIGGER IF EXISTS trg_summary_no_direct_published_insert')
    db.exec('DROP TABLE IF EXISTS claim_evidence')
    db.exec('DROP TABLE IF EXISTS summary_evidence')
    db.exec('DROP TABLE IF EXISTS claim')
    db.prepare('DELETE FROM schema_migration WHERE version = ?').run(MIGRATION_FILE)
    db.exec('COMMIT')
  } catch (err) {
    try { db.exec('ROLLBACK') } catch { /* noop */ }
    return { ok: false, code: 'E_ROLLBACK', reason: String((err && err.message) || err) }
  }
  return { ok: true, dropped: ['claim', 'claim_evidence', 'summary_evidence', '4 只触发器'], migration: MIGRATION_FILE }
}

// ---------------------------------------------------------------------------
// 结论导出（S10 镜 4）：把一条结论连同其证据当前状态打包成可带走的内容。
// 纯数据组装（不碰 fs）；文件落盘由调用方（timeline 插件）负责。
// ---------------------------------------------------------------------------

/** 三档标签（CONTRACT §6：none 不得用事实语气）。 */
export function evidenceModeLabel(mode) {
  if (mode === 'none') return '无直接证据（不得作为事实）'
  if (mode === 'derived') return '推导证据'
  return '直接证据'
}

/**
 * 组装导出行内容。
 * @returns {{ok:boolean, code?:string, claim?:object, evidence?:Array, label?:string, markdown?:string}}
 */
export function buildClaimExport(store, claimId, { version = 's10', now = Date.now() } = {}) {
  const db = rawDb(store)
  if (!db) return { ok: false, code: 'E_DRIVER_UNSUPPORTED', reason: '导出需要 sqlite driver' }
  const claim = db.prepare('SELECT id, kind, text, evidence_mode, status, created_at, published_at FROM claim WHERE id = ?').get(claimId)
  if (!claim) return { ok: false, code: 'E_NO_CLAIM', reason: `claim 不存在：${claimId}` }
  if (claim.status !== 'published') {
    return { ok: false, code: 'E_NOT_PUBLISHED', reason: '只有已发布结论可导出（未过证据闸的结论不得对外）' }
  }
  const links = db.prepare('SELECT evidence_id, layer, relation, sha256 FROM claim_evidence WHERE claim_id = ? ORDER BY id').all(claimId)
  const evidence = links.map((l) => {
    const r = resolveEvidence(store, l.evidence_id, l.layer, now)
    return {
      evidence_id: l.evidence_id,
      layer: l.layer,
      relation: l.relation,
      sha256: l.sha256 || r.sha256 || null,
      status: r.status,
      availability: r.status === 'available' ? '可用' : r.status === 'deleted' ? '已删' : r.status === 'expired' ? '已过期' : r.status === 'missing' ? '缺失' : r.status,
      label: r.label,
    }
  })
  const label = evidenceModeLabel(claim.evidence_mode)
  const degraded = evidence.filter((e) => e.status !== 'available')
  const exportTime = new Date(now).toISOString()
  const lines = [
    `# 结论导出 · ${claim.id}`,
    '',
    `- 导出时间：${exportTime}`,
    `- 产品版本：research-orb ${version}`,
    `- 结论状态：${claim.status}（发布于 ${claim.published_at || '?'}）`,
    `- 证据档位：${label}`,
    `- 证据条数：${evidence.length}（可回指 ${evidence.filter((e) => e.relation !== 'none').length}；当前可用 ${evidence.filter((e) => e.status === 'available').length}）`,
    '',
    '## 结论正文',
    '',
    String(claim.text || ''),
    '',
    '## 证据清单',
    '',
    '| # | evidence_id | 层 | 关系 | 当前可用性 | sha256 |',
    '| --- | --- | --- | --- | --- | --- |',
  ]
  evidence.forEach((e, i) => {
    lines.push(`| ${i + 1} | ${e.evidence_id} | ${e.layer} | ${e.relation} | ${e.availability} | ${e.sha256 ? e.sha256.slice(0, 16) + '…' : '-'} |`)
  })
  lines.push('')
  if (degraded.length > 0) {
    lines.push('## 降级说明（部分证据已不可查看）', '')
    for (const e of degraded) lines.push(`- ${e.evidence_id}：${e.label}`)
    lines.push('')
  }
  lines.push(
    '## 核验方式',
    '',
    '- 每条证据均可用 evidence_id 在 lifecycle 库回指（raw_frame / observation / summary / audit 行保留，删除不清身份）。',
    '- 数据层证据闸：无（非 none）证据的结论不得发布（CONTRACT §6）。',
    '',
  )
  // S67·3-D·D4：导出前全量完整性复查（只读，不阻断导出）——published 但证据被剥离的
  // claim 在这里以「证据缺失」告警显形；是否撤销/补证据属业务决策，交给人。
  const integrity = verifyClaimIntegrity(store)
  return { ok: true, claim, evidence, label, degraded: degraded.length, integrity, markdown: lines.join('\n') }
}

export default {
  nextEvidenceId, createClaim, attachEvidence, countPublishableEvidence,
  publishClaim, publishSummary, resolveEvidence, claimEvidenceReport, rollbackS6,
  buildClaimExport, evidenceModeLabel, verifyClaimIntegrity,
  DEGRADED_EVIDENCE_COPY, MIGRATION_FILE,
}
