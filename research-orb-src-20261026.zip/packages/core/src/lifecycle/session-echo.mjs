// packages/core/src/lifecycle/session-echo.mjs —— S56·T9 会话回声清理（可发现版）
//
// 背景：/timeline 等查询命令曾走成流式对话，往会话里沉积「轨迹（20261024）：今天还没有片段。」
// 这类回声（真实库累计上千条）。tools/purge-session-echo.mjs 是 CLI 版；这里是**可复用模块**：
// 启动时检测（scan）→ 首页可点提示 → 用户确认 → 退出时清理（purge）→ 下次启动显示结果。
//
// 纪律（沿 CLI 版）：先导出再删；只删命中行；不静默删；清理发生在应用退出时（sqlite 由本进程持有）。
// 用 node:sqlite DatabaseSync 同步 API（退出钩子里必须同步）。

import { existsSync, mkdirSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { DatabaseSync } from 'node:sqlite'

/** 回声特征（与 tools/purge-session-echo.mjs 同口径）。 */
const RE = /轨迹（\d{8}）：|今天还没有片段/

/**
 * 扫描待清理回声（只读）。
 * @returns {{ok:boolean, count:number, plan:Array<{table:string,col:string,rowid:number,text:string}>, code?:string}}
 */
export function scanSessionEcho(dbPath) {
  if (!existsSync(dbPath)) return { ok: false, count: 0, plan: [], code: 'E_NO_DB' }
  let db = null
  try {
    db = new DatabaseSync(dbPath)
  } catch (e) {
    // 应用运行中/独占时打不开：不是错误，如实返回"未知"
    return { ok: false, count: 0, plan: [], code: 'E_LOCKED' }
  }
  const plan = []
  try {
    const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'").all().map((r) => r.name)
    for (const t of tables) {
      const cols = db.prepare(`PRAGMA table_info("${t}")`).all().map((c) => c.name)
      const textCols = cols.filter((c) => /text|content|message|body|turn/i.test(c))
      for (const c of textCols) {
        try {
          const rows = db.prepare(`SELECT rowid AS __rid, "${c}" AS __v FROM "${t}" WHERE "${c}" LIKE ? OR "${c}" LIKE ?`).all('%轨迹（%', '%今天还没有片段%')
          for (const r of rows) {
            if (RE.test(String(r.__v || ''))) plan.push({ table: t, col: c, rowid: r.__rid, text: String(r.__v).slice(0, 120) })
          }
        } catch { /* 该列不支持 LIKE 跳过 */ }
      }
    }
  } catch (e) {
    return { ok: false, count: 0, plan: [], code: 'E_SCAN' }
  } finally {
    try { db.close() } catch { /* noop */ }
  }
  return { ok: true, count: plan.length, plan }
}

/**
 * 清理回声：先导出 JSON 备份 → 事务内逐行删除。
 * @returns {{ok:boolean, purged:number, backupPath?:string, code?:string}}
 */
export function purgeSessionEcho(dbPath, backupDir) {
  const scanned = scanSessionEcho(dbPath)
  if (!scanned.ok) return { ok: false, purged: 0, code: scanned.code }
  if (scanned.count === 0) return { ok: true, purged: 0 }
  // 先导出（纪律：先导出再删）
  let backupPath = null
  try {
    if (backupDir) {
      mkdirSync(backupDir, { recursive: true })
      backupPath = join(backupDir, `session-echo-purge-${new Date().toISOString().replace(/[:.]/g, '-')}.json`)
      writeFileSync(backupPath, JSON.stringify({ at: new Date().toISOString(), count: scanned.count, plan: scanned.plan }, null, 2), 'utf8')
    }
  } catch { /* 备份失败则不删（宁可不删也不静默丢数据） */
    return { ok: false, purged: 0, code: 'E_BACKUP' }
  }
  let db = null
  try {
    db = new DatabaseSync(dbPath)
    // rowid 删除必须逐表批处理（SQLite 不允许跨表 rowid 混删）
    const byTable = new Map()
    for (const p of scanned.plan) {
      if (!byTable.has(p.table)) byTable.set(p.table, [])
      byTable.get(p.table).push(p.rowid)
    }
    let purged = 0
    db.exec('BEGIN')
    try {
      for (const [t, rids] of byTable) {
        const stmt = db.prepare(`DELETE FROM "${t}" WHERE rowid = ?`)
        for (const rid of rids) { stmt.run(rid); purged += 1 }
      }
      db.exec('COMMIT')
    } catch (e) {
      try { db.exec('ROLLBACK') } catch { /* noop */ }
      return { ok: false, purged: 0, code: 'E_DELETE', backupPath }
    }
    return { ok: true, purged, backupPath }
  } catch (e) {
    return { ok: false, purged: 0, code: 'E_LOCKED', backupPath }
  } finally {
    try { if (db) db.close() } catch { /* noop */ }
  }
}
