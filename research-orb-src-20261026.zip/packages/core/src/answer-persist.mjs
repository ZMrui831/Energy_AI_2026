// packages/core/src/answer-persist.mjs —— S71·P0-2 命令/UI 回答落盘到当前会话
//
// 只落"内容型"答案（召回 / 显式 persist），避免面板 status 轮询把"状态已刷新"灌进会话（S56 教训）。
// S73 修复：registry 的 runCommand 返回是**嵌套**的 {ok, pluginId, name, value:{text,persist,...}} ——
// 文本/标记都在 value 里，顶层只有 ok。此前只读顶层 result.text → 恒空 → 落盘被跳过（D-3 根因）。

/** 该命令结果是否值得落盘（内容型答案，非内部轮询）。registry 包装与裸结果两层都兼容。 */
export function shouldPersistAnswer(result) {
  if (!result || result.ok === false) return false
  const v = result.value && typeof result.value === 'object' ? result.value : {}
  const text = String(result.text ?? v.text ?? '')
  if (!text.trim()) return false
  return result.recall === true || v.recall === true || v.persist === true
}

/**
 * 落盘命令答案：{type:'assistant', ts, text, source:'recall'|'command'|'screenshot', frameIds}。
 * @returns {{persisted:boolean, sessionId?:string, source?:string, chars?:number, frameIds?:string[]}}
 */
export function persistCommandAnswer({ sessions, sessionId, result, createTitle = '命令回答' }) {
  if (!shouldPersistAnswer(result)) return { persisted: false }
  const v = result.value && typeof result.value === 'object' ? result.value : {}
  const text = String(result.text ?? v.text ?? '')
  let sid = sessionId
  if (!sid) { const s = sessions.createSession({ title: createTitle }); sid = s.id }
  const source = (result.recall || v.recall) ? 'recall' : (result.source || v.source || 'command')
  const frameIds = text.match(/fr-[a-z0-9]+/g) || []
  sessions.appendAssistant(sid, { text, source, frameIds, provider: 'plugin' })
  return { persisted: true, sessionId: sid, source, chars: text.length, frameIds }
}
