// packages/core/src/router.mjs
//
// S25·1B 分层路由：把 LLM 调用按任务档位分流到 cheap（网关 qwen）/ flagship（现有 deepseek）。
//
// 纪律（红线）：
//   · 本模块【不直接出网】——LLM 兑现函数 invoke 由调用方注入（插件经 ctx.net 走白名单/
//     审计/限速；测试注桩）。网关配额 10 req/min → 内置令牌桶，桶空时【排队等待】而非失败。
//   · 失败回落旗舰一次，回落必须落审计（route-fallback）。
//   · 每次 run 落一行 usage（data/logs/usage.jsonl）：provider/model/taskClass/fallback，
//     供 /usage 出分模型统计。
//   · providers.json 只存引用（claude-settings:* / secrets:*），绝不存明文密钥。

import { appendJsonl, logPath } from './safefs.mjs'

export const TASK_CLASSES = Object.freeze(['extract', 'summarize', 'score-plan', 'reason'])

/** 档位路由：extract→cheap；summarize|score-plan→flagship；reason 永远旗舰。未知档位返回 null。 */
export function routeOf(taskClass) {
  switch (taskClass) {
    case 'extract': return 'cheap'
    case 'summarize':
    case 'score-plan':
    case 'reason': return 'flagship'
    default: return null
  }
}

/**
 * 令牌桶（10 req/min 默认，桶空排队不失败）。
 * now/sleep 可注入（测试用虚拟时钟压缩等待）。
 */
export function createRateLimiter({ capPerMin = 10, now = () => Date.now(), sleep = (ms) => new Promise((r) => setTimeout(r, ms)), onWait = null } = {}) {
  const intervalMs = 60000 / capPerMin
  let tokens = capPerMin
  let last = now()
  let queueTail = 0 // 队尾应得时间戳（串行排队，避免突发齐发）
  async function acquire() {
    const t0 = now()
    // 补币：按真实流逝时间回填
    const elapsed = t0 - last
    tokens = Math.min(capPerMin, tokens + elapsed / intervalMs)
    last = t0
    tokens -= 1
    if (tokens >= 0) {
      queueTail = Math.max(queueTail, t0)
      return 0
    }
    // 桶空：排队到队尾之后的下一个发币点（不失败）
    const base = Math.max(queueTail, t0)
    const wait = Math.max(0, base + intervalMs - t0)
    queueTail = base + intervalMs
    // B2：桶满排队时记一次 rate-wait 审计（排队不失败、不绕桶）
    if (wait > 0) { try { if (typeof onWait === 'function') onWait(wait) } catch { /* 审计回调失败不影响排队 */ } await sleep(wait) }
    return wait
  }
  return { acquire, get queued() { return tokens < 0 } }
}

/**
 * @param {{
 *   providers: {cheap:object, flagship:object, vision?:object},
 *   invoke: async ({tier, provider, taskClass, payload}) => {text, tokens?, meta?},
 *   audit?: (rec) => void,
 *   usagePath?: string,
 *   now?: () => number,
 *   sleep?: (ms) => Promise,
 *   capPerMin?: number,
 *   onRateWait?: (waitMs:number) => void,
 * }} opts
 * invoke 由调用方注入：vision 走智谱 GLM（S60），cheap 走网关 qwen，flagship 走 deepseek 管线；
 * 本模块只做【选档 + 限速 + 回落 + 审计 + usage】。
 */
export function createRouter(opts = {}) {
  const providers = opts.providers || {}
  if (typeof opts.invoke !== 'function') throw Object.assign(new Error('router: 需要注入 invoke（本模块不直接出网）'), { code: 'E_NO_INVOKE' })
  const audit = opts.audit || ((rec) => { try { appendJsonl(logPath('router.jsonl'), rec) } catch { /* 尽力 */ } })
  const usageWrite = (rec) => { try { appendJsonl(opts.usagePath || logPath('usage.jsonl'), rec) } catch { /* 尽力 */ } }
  const limiter = createRateLimiter({ capPerMin: opts.capPerMin ?? 10, now: opts.now, sleep: opts.sleep, onWait: (waitMs) => { try { audit({ ts: new Date(now()).toISOString(), kind: 'rate-wait', waitMs: Math.round(waitMs) }); if (typeof opts.onRateWait === 'function') opts.onRateWait(waitMs) } catch { /* 审计失败不影响排队 */ } } })
  const now = opts.now || (() => Date.now())

  /**
   * 第一跳档位：extract 且有 vision provider → 'vision'（S60 智谱 GLM）；否则沿用 routeOf。
   * routeOf 保持不变（'extract'→'cheap'），以免破坏既有单测与无 vision 配置的部署。
   */
  function firstTierFor(taskClass) {
    const base = routeOf(taskClass)
    if (taskClass === 'extract' && providers.vision && providers.vision.providerId) return 'vision'
    return base
  }

  /**
   * @param {'extract'|'summarize'|'score-plan'|'reason'} taskClass
   * @param {{messages?:Array, prompt?:string, [k:string]:any}} payload
   * @returns {Promise<{ok:boolean, text?:string, tier:string, providerId:string, model:string, fallback:boolean, ms:number, error?:{code,message}, meta?:object}>}
   */
  async function run(taskClass, payload = {}) {
    const tier = routeOf(taskClass)
    if (!tier) {
      throw Object.assign(new Error(`router: 未知任务档位 ${JSON.stringify(taskClass)}（应为 ${TASK_CLASSES.join('/')}）`), { code: 'E_TASK_CLASS' })
    }
    const hop = async (t, isFallback) => {
      const provider = providers[t] || {}
      const ms0 = now()
      let ok = true
      let text = ''
      let tokens
      let meta
      let error
      try {
        await limiter.acquire()
        const r = await opts.invoke({ tier: t, provider, taskClass, payload })
        text = String((r && r.text) ?? '')
        tokens = r && r.tokens
        meta = r && r.meta
      } catch (e) {
        ok = false
        error = { code: (e && e.code) || 'E_INVOKE', message: String((e && e.message) || e).slice(0, 200) }
      }
      const ms = now() - ms0
      usageWrite({
        ts: new Date().toISOString(),
        taskClass,
        tier: t,
        providerId: provider.providerId || t,
        model: provider.model || '',
        fallback: !!isFallback,
        ok,
        ms,
        ...(tokens != null ? { tokens } : {}),
        ...(meta && typeof meta === 'object' ? meta : {}),
        ...(!ok && error ? { error } : {}),
      })
      return { ok, text, tokens, error, ms, meta }
    }

    // 第一跳：extract 有 vision → 智谱 GLM；其余 → routeOf（cheap/flagship）
    const first = firstTierFor(taskClass)
    const r1 = await hop(first, false)
    if (r1.ok) {
      const p = providers[first] || {}
      return { ok: true, text: r1.text, tier: first, providerId: p.providerId || first, model: p.model || '', fallback: false, ms: r1.ms, meta: r1.meta }
    }
    // vision 失败 → 回退网关 qwen（cheap）一次（S60 要求：保留现有网关实现）
    if (first === 'vision') {
      const v = providers.vision || {}
      audit({ ts: new Date().toISOString(), kind: 'route-fallback', taskClass, from: v.providerId || 'zhipu', to: 'gateway', error: r1.error })
      const rq = await hop('cheap', true)
      const pq = providers.cheap || {}
      if (rq.ok) {
        return { ok: true, text: rq.text, tier: 'cheap', providerId: pq.providerId || 'cheap', model: pq.model || '', fallback: true, ms: rq.ms, meta: rq.meta }
      }
      // 网关也失败 → 再回落旗舰（与既有 cheap→flagship 链一致）
      audit({ ts: new Date().toISOString(), kind: 'route-fallback', taskClass, from: 'gateway', to: 'flagship', error: rq.error })
      const rf = await hop('flagship', true)
      const pf = providers.flagship || {}
      if (rf.ok) {
        return { ok: true, text: rf.text, tier: 'flagship', providerId: pf.providerId || 'flagship', model: pf.model || '', fallback: true, ms: rf.ms, meta: rf.meta }
      }
      audit({ ts: new Date().toISOString(), kind: 'route-fallback-failed', taskClass, error: rf.error })
      return { ok: false, tier: 'flagship', providerId: pf.providerId || 'flagship', model: pf.model || '', fallback: true, ms: rf.ms, error: rf.error }
    }
    // 旗舰已最高档：不回落，如实失败
    if (first === 'flagship') {
      return { ok: false, tier: 'flagship', providerId: (providers.flagship && providers.flagship.providerId) || 'flagship', model: (providers.flagship && providers.flagship.model) || '', fallback: false, ms: r1.ms, error: r1.error }
    }
    // cheap 失败 → 回落旗舰一次（排队不失败），审计 route-fallback
    audit({ ts: new Date().toISOString(), kind: 'route-fallback', taskClass, from: 'cheap', to: 'flagship', error: r1.error })
    const r2 = await hop('flagship', true)
    const p2 = providers.flagship || {}
    if (r2.ok) {
      return { ok: true, text: r2.text, tier: 'flagship', providerId: p2.providerId || 'flagship', model: p2.model || '', fallback: true, ms: r2.ms, meta: r2.meta }
    }
    audit({ ts: new Date().toISOString(), kind: 'route-fallback-failed', taskClass, error: r2.error })
    return { ok: false, tier: 'flagship', providerId: p2.providerId || 'flagship', model: p2.model || '', fallback: true, ms: r2.ms, error: r2.error }
  }

  return { run, routeOf, firstTierFor, limiter, TASK_CLASSES }
}

export default { TASK_CLASSES, routeOf, createRateLimiter, createRouter }
