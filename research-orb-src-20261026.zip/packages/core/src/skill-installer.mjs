// packages/core/src/skill-installer.mjs
//
// skill 适配性安装器的核心逻辑（P-R4 块 4）——纯函数、无副作用、可单测。
// 复制/审计/启停由 registry 调用方完成；这里只回答三个问题：
//   1) 这个目录是不是一个合法的 skill 候选？（scanCandidates / readSkillManifest）
//   2) 它声明了什么权限？（summarizePermissions —— 给用户确认用）
//   3) 它的文件与声明的 sha256 白名单一致吗？（buildFileManifest / verifySource）
//
// 红线（沿用事故教训，写入 tests/skill-installer.test.mjs 的断言）：
//   · 禁止自动更新、禁止远程下载执行 —— 本模块只认**本地目录**，没有任何 URL/网络参数；
//   · 哈希校验失败必须拒绝安装（宁可不装，不可装错）；
//   · 卸载 = 移入退休目录（只移不删），不删除任何用户内容。

import { createHash } from 'node:crypto'
import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs'
import { join, relative } from 'node:path'

export const SKILL_MANIFEST = 'plugin.json'
export const SKILL_SCHEMA_VERSION = 1
export const RETIRED_DIR = '.retired'

export function sha256(buf) {
  return createHash('sha256').update(buf).digest('hex')
}

/**
 * 读一个 skill 目录的 manifest（存在且是合法 JSON 对象才返回，否则 null）。
 */
export function readSkillManifest(dir) {
  const p = join(dir, SKILL_MANIFEST)
  if (!existsSync(p)) return null
  try {
    const raw = JSON.parse(readFileSync(p, 'utf8'))
    return raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : null
  } catch {
    return null
  }
}

/**
 * 扫描一个本地目录下的 skill 候选（子目录含 plugin.json 即候选；跳过点开头/文件）。
 * @param {string} dir 用户指定的收件目录
 * @returns {{dir: string, id: string|null, name: string, version: string}[]} id 取 manifest.id（非法则为 null）
 */
export function scanCandidates(dir) {
  const out = []
  if (!existsSync(dir) || !statSync(dir).isDirectory()) return out
  for (const name of readdirSync(dir)) {
    if (name.startsWith('.')) continue
    const sub = join(dir, name)
    let st = null
    try {
      st = statSync(sub)
    } catch {
      continue
    }
    if (!st.isDirectory()) continue
    const raw = readSkillManifest(sub)
    if (!raw) continue
    out.push({
      dir: sub,
      id: typeof raw.id === 'string' && raw.id ? raw.id : null,
      name: typeof raw.name === 'string' ? raw.name : name,
      version: typeof raw.version === 'string' ? raw.version : '0.0.0',
    })
  }
  return out
}

/**
 * 权限清单（给用户确认的"你要给这个 skill 什么"）。
 * 从 manifest 的 scopes / permissions / capabilities 归纳成 fs / net / ui / llm 四类细项。
 * @param {object} raw 原始 manifest
 */
export function summarizePermissions(raw) {
  const scopes = Array.isArray(raw.scopes) ? raw.scopes.map(String) : []
  const permissions = Array.isArray(raw.permissions) ? raw.permissions.map(String) : []
  const capabilities = Array.isArray(raw.capabilities) ? raw.capabilities.map(String) : []
  const fsGrant = scopes.map((s) => `fs:data/${s}/`)
  const netGrant = permissions.filter((p) => p.startsWith('net:')).map((p) => `net:${p.slice(4)}（仅白名单）`)
  const uiGrant = capabilities.filter((c) => c.startsWith('ui.')).map((c) => `ui:${c.slice(3)}`)
  const llmGrant = capabilities.includes('llm') || permissions.includes('llm') ? ['llm:受控 provider（无直连密钥）'] : []
  return {
    scopes,
    permissions,
    capabilities,
    lines: [
      `fs（数据作用域）：${fsGrant.length ? fsGrant.join(', ') : '无'}`,
      `net（出网，仅白名单域）：${netGrant.length ? netGrant.join(', ') : '无出网'}`,
      `ui（面板能力）：${uiGrant.length ? uiGrant.join(', ') : '无'}`,
      `llm（模型调用）：${llmGrant.length ? llmGrant.join(', ') : '无'}`,
    ],
  }
}

/**
 * 为一个 skill 目录生成哈希白名单（{ 相对路径: sha256 }）——skill 作者发布时的"封条"。
 * 跳过点开头文件/目录（.git 等）与 plugin.json 自身（hash 字段没法哈希自己）。
 * @param {string} dir
 */
export function buildFileManifest(dir) {
  const files = {}
  const walk = (d) => {
    for (const name of readdirSync(d)) {
      if (name.startsWith('.')) continue
      const p = join(d, name)
      const st = statSync(p)
      if (st.isDirectory()) {
        walk(p)
        continue
      }
      const rel = relative(dir, p).replace(/\\/g, '/')
      if (rel === SKILL_MANIFEST) continue
      files[rel] = sha256(readFileSync(p))
    }
  }
  walk(dir)
  return files
}

/**
 * 来源校验：实际文件 vs 声明的哈希白名单。
 * 三种失败都必须拒绝安装：
 *   · E_HASH_MISSING  —— manifest 没有可用的 hash 白名单（非空对象）
 *   · E_UNEXPECTED_FILE —— 实际文件不在白名单里（白名单没封到的文件 = 未声明内容）
 *   · E_HASH_MISMATCH —— 文件在白名单里但哈希不一致（被篡改）
 * plugin.json 自身不在白名单内（它是声明的载体），但要求存在。
 * @param {string} dir
 * @param {object} raw 原始 manifest（须含 hash: { rel: sha256 }）
 * @returns {{ok: true, files: number} | {ok: false, code: string, message: string, details: string[]}}
 */
export function verifySource(dir, raw) {
  const declared = raw && raw.hash && typeof raw.hash === 'object' && !Array.isArray(raw.hash) ? raw.hash : null
  if (!declared || Object.keys(declared).length === 0) {
    return { ok: false, code: 'E_HASH_MISSING', message: 'manifest 缺少可用的 hash 哈希白名单（{ 相对路径: sha256 }），拒绝安装', details: [] }
  }
  if (!existsSync(join(dir, SKILL_MANIFEST))) {
    return { ok: false, code: 'E_NO_MANIFEST', message: `缺少 ${SKILL_MANIFEST}`, details: [] }
  }
  const actual = buildFileManifest(dir)
  const details = []
  for (const [rel, expect] of Object.entries(declared)) {
    if (!(rel in actual)) {
      details.push(`白名单文件缺失：${rel}`)
      continue
    }
    if (String(actual[rel]).toLowerCase() !== String(expect).toLowerCase()) {
      details.push(`哈希不一致（疑似被篡改）：${rel} 声明 ${String(expect).slice(0, 12)}… 实际 ${actual[rel].slice(0, 12)}…`)
    }
  }
  for (const rel of Object.keys(actual)) {
    if (!(rel in declared)) details.push(`白名单之外的文件：${rel}（未声明内容不得安装）`)
  }
  if (details.length > 0) {
    const code = details.some((d) => d.startsWith('哈希不一致')) ? 'E_HASH_MISMATCH' : 'E_UNEXPECTED_FILE'
    return { ok: false, code, message: `来源校验失败（${details.length} 处），拒绝安装`, details }
  }
  return { ok: true, files: Object.keys(actual).length }
}

export default {
  SKILL_MANIFEST,
  SKILL_SCHEMA_VERSION,
  RETIRED_DIR,
  sha256,
  readSkillManifest,
  scanCandidates,
  summarizePermissions,
  buildFileManifest,
  verifySource,
}
