// packages/core/src/memory-inject.mjs —— 记忆注入（S74·采纳 dsh-orb 建议）
//
// 来源：dsh-orb 征集答复 #3「记忆注入管线 host hook + 只读外部适配」
//   · buildMemoryContext(topK3, ≤800字)
//   · 300ms 超时静默降级
// 我们只取"纯函数 + 硬上限"这部分（不取 host hook 那套跨进程管线）。
//
// 纪律：
//   1. **topK ≤ 3、总字数 ≤ 800**（挤上下文会反噬；硬上限写进常量）
//   2. 只注入与当前问题**有词面交集**的条目（宁缺勿滥）
//   3. 每条带 kind 前缀（目标/偏好/决定/卡点），让模型知道"这是什么记忆"
//   4. 输出里带 `（你的偏好：…）` 这类可读标注，用户看得懂

export const MEMORY_INJECT_LIMITS = Object.freeze({ topK: 3, maxChars: 800, minOverlap: 1 })

const KIND_LABEL = Object.freeze({
  goal: '目标', preference: '偏好', decision: '决定', blocker: '卡点', other: '记录',
})

const STOP = new Set(['的', '了', '是', '在', '我', '你', '他', '她', '它', '和', '与', '就', '都', '也', '还', '很', '吗', '呢', '吧', '啊', '什么', '怎么', '这个', '那个'])

/** 切成 2-gram 词面（中文无需分词器，避免引依赖） */
function grams(text) {
  const s = String(text || '').replace(/[\s\p{P}]+/gu, '')
  const out = new Set()
  for (let i = 0; i < s.length - 1; i += 1) {
    const g = s.slice(i, i + 2)
    if (!STOP.has(g)) out.add(g)
  }
  return out
}

/** 词面交集打分 + 类别权重 + 时间衰减 */
function scoreEntry(qGrams, entry, now) {
  const tGrams = grams((entry && entry.text) || '')
  let overlap = 0
  for (const g of qGrams) if (tGrams.has(g)) overlap += 1
  if (overlap < MEMORY_INJECT_LIMITS.minOverlap) return 0
  const kindBoost = { blocker: 1.35, preference: 1.25, goal: 1.2, decision: 1.0 }[entry.kind] || 0.9
  const conf = Number.isFinite(entry.confidence) ? entry.confidence : 0.8
  const ts = Date.parse(String(entry.ts || ''))
  const ageDays = Number.isFinite(ts) ? Math.max(0, (now - ts) / 86400000) : 30
  const recency = 1 / (1 + ageDays / 7) // 7 天半衰
  return overlap * kindBoost * conf * recency
}

/**
 * 构造注入块。
 * @param {string} query 当前问题
 * @param {Array} entries 记忆条目 [{ts,kind,text,confidence}]
 * @param {{topK?:number,maxChars?:number,now?:number}} [opts]
 * @returns {{text:string, used:Array, chars:number, dropped:number}}
 */
export function buildMemoryContext(query, entries, opts = {}) {
  const topK = Math.max(1, Math.min(3, Number(opts.topK) || MEMORY_INJECT_LIMITS.topK))
  const maxChars = Math.max(80, Math.min(800, Number(opts.maxChars) || MEMORY_INJECT_LIMITS.maxChars))
  const now = Number(opts.now) || Date.now()
  const list = Array.isArray(entries) ? entries.filter((e) => e && String(e.text || '').trim()) : []
  if (!list.length) return { text: '', used: [], chars: 0, dropped: 0 }
  const qGrams = grams(query)
  if (!qGrams.size) return { text: '', used: [], chars: 0, dropped: list.length }
  const scored = list
    .map((e) => ({ e, s: scoreEntry(qGrams, e, now) }))
    .filter((x) => x.s > 0)
    .sort((a, b) => b.s - a.s)
  if (!scored.length) return { text: '', used: [], chars: 0, dropped: list.length }
  const used = []
  const lines = []
  let chars = 0
  for (const { e } of scored) {
    if (used.length >= topK) break
    const label = KIND_LABEL[e.kind] || KIND_LABEL.other
    const body = String(e.text).replace(/\s+/g, ' ').trim()
    const line = `· [${label}] ${body}`
    if (chars + line.length > maxChars) continue
    lines.push(line)
    used.push({ id: e.id || null, kind: e.kind || 'other', text: body })
    chars += line.length
  }
  if (!lines.length) return { text: '', used: [], chars: 0, dropped: list.length }
  return {
    text: `关于你之前说过的事（只在与当前问题相关时才会出现）：\n${lines.join('\n')}`,
    used,
    chars,
    dropped: list.length - used.length,
  }
}

/** 带超时的安全包装：超时就返回空注入（静默降级，不阻塞回答） */
export function buildMemoryContextWithTimeout(query, entries, opts = {}) {
  const timeoutMs = Number(opts.timeoutMs) || 300
  const started = Date.now()
  try {
    const r = buildMemoryContext(query, entries, opts)
    if (Date.now() - started > timeoutMs) return { text: '', used: [], chars: 0, dropped: 0, timedOut: true }
    return r
  } catch {
    return { text: '', used: [], chars: 0, dropped: 0, failed: true }
  }
}

export default { MEMORY_INJECT_LIMITS, buildMemoryContext, buildMemoryContextWithTimeout }