// packages/core/src/budget-baseline.mjs —— S58·P0-1 预算"自身基线"采样与读写
//
// 为什么：绝对阈值（cpuAvg 3% / cpuP95 12% / memMB 300MB）在正常机器上必然误触发，
// 本机曾常年停在 L5（停云调用）而实际毫无问题。改为"相对自身基线"：
//   启动采样 60s（默认 12 次 × 5s）→ data/budget-baseline.json → 阈值 = base × 系数。
//
// 纪律：
//   · JSON 一律**无 BOM UTF-8**（主管踩过 BOM 坑）。
//   · 基线只影响"何时降级"，不改变任何采集语义；缺失/过期 → 调用方用 FALLBACK_THRESHOLDS。
//   · 采样失败不阻断启动（返回 null，60s 后再试一次即可）。

import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { dataPath } from './safefs.mjs'

export const BASELINE_FILE = () => dataPath('budget-baseline.json')
const BASELINE_TTL_MS = 7 * 24 * 3600 * 1000

/** 读基线（不存在/损坏/过期 → null）。 */
export function readBaseline(path = BASELINE_FILE(), now = Date.now()) {
  try {
    if (!existsSync(path)) return null
    const doc = JSON.parse(readFileSync(path, 'utf8'))
    if (!doc || typeof doc !== 'object') return null
    if (typeof doc.at !== 'number' || now - doc.at > BASELINE_TTL_MS) return null
    const ok = ['cpuP95', 'cpuAvg', 'memMB'].every((k) => Number.isFinite(Number(doc[k])))
    if (!ok) return null
    return doc
  } catch {
    return null
  }
}

/** 写基线（无 BOM UTF-8；目录不存在则创建）。 */
export function writeBaseline(baseline, path = BASELINE_FILE(), now = Date.now()) {
  try {
    mkdirSync(dirname(path), { recursive: true })
    const doc = {
      at: now,
      cpuP95: Number(baseline.cpuP95) || 0,
      cpuAvg: Number(baseline.cpuAvg) || 0,
      memMB: Number(baseline.memMB) || 0,
      samples: Number(baseline.samples) || 0,
      note: '启动采样 60s 自身指标；阈值 = base × 2.5/2/1.8（内存另受 3000MB 极值兜底）',
    }
    // 关键：不写 BOM（writeFileSync + 'utf8' 默认无 BOM）
    writeFileSync(path, JSON.stringify(doc, null, 2), 'utf8')
    return doc
  } catch {
    return null
  }
}

/** 分位数（0..1）。 */
export function percentile(values, p) {
  const arr = values.filter((v) => Number.isFinite(v)).slice().sort((a, b) => a - b)
  if (!arr.length) return 0
  const idx = Math.min(arr.length - 1, Math.max(0, Math.round(p * (arr.length - 1))))
  return arr[idx]
}

/**
 * 采样自身基线：sample() 每次返回 {cpuP95,cpuAvg,memMB}。
 * @param {{sample:Function, times?:number, intervalMs?:number, onProgress?:Function}} opts
 * @returns {Promise<{cpuP95:number,cpuAvg:number,memMB:number,samples:number}|null>}
 */
export async function collectBaseline({ sample, times = 12, intervalMs = 5000, onProgress = null } = {}) {
  if (typeof sample !== 'function') return null
  const p95s = []
  const avgs = []
  const mems = []
  for (let i = 0; i < times; i++) {
    try {
      const m = await sample()
      if (m) {
        if (Number.isFinite(Number(m.cpuP95))) p95s.push(Number(m.cpuP95))
        if (Number.isFinite(Number(m.cpuAvg))) avgs.push(Number(m.cpuAvg))
        if (Number.isFinite(Number(m.memMB))) mems.push(Number(m.memMB))
      }
    } catch { /* 单次失败跳过 */ }
    if (typeof onProgress === 'function') { try { onProgress(i + 1, times) } catch { /* noop */ } }
    if (i < times - 1) await new Promise((r) => setTimeout(r, intervalMs))
  }
  if (!p95s.length && !avgs.length && !mems.length) return null
  const mean = (a) => (a.length ? a.reduce((s, v) => s + v, 0) / a.length : 0)
  return {
    // P95 指标取样本的 P95（而不是均值）—— 峰值型指标用均值会低估
    cpuP95: percentile(p95s, 0.95),
    cpuAvg: mean(avgs),
    memMB: mean(mems),
    samples: Math.max(p95s.length, avgs.length, mems.length),
  }
}

export default { BASELINE_FILE, readBaseline, writeBaseline, collectBaseline, percentile }
