// packages/core/src/providers/deepseek-api.mjs
//
// deepseek-api —— DeepSeek 官方 API（OpenAI 兼容 /chat/completions）。
//
// 凭据：data\secrets.json 的 deepseek.apiKey / deepseek.baseUrl（经 config.mjs 单点读取）。
// 出网：一律经 net.mjs（白名单含 api.deepseek.com；令牌桶；reasoner 每分钟 10 次；429 指数退避；net.jsonl 审计）。
// 密钥纪律：只出现在 Authorization 头里；net.mjs 不记录请求头；本文件不打印 key（打码走 maskKey）。

import { ENDPOINTS, assertAllowedBaseUrl, createNet } from '../net.mjs'
import { deepseekConfig, describeConfig, maskKey } from '../config.mjs'
import {
  EVENT,
  ModelProvider,
  ProviderError,
  collectStream,
  errorFromResponse,
  errorFromThrown,
  normalizeMessages,
  parseSse,
  shortMessage,
} from './provider.mjs'

export const DEEPSEEK_PROVIDER_ID = 'deepseek-api'
export const DEEPSEEK_MODELS = Object.freeze(['deepseek-chat', 'deepseek-reasoner'])
export const REASONER_MODEL = 'deepseek-reasoner'

export class DeepSeekProvider extends ModelProvider {
  constructor({ net, secretsPath, config } = {}) {
    const cfg = config || deepseekConfig({ secretsPath })
    super({
      id: DEEPSEEK_PROVIDER_ID,
      name: 'DeepSeek 官方 API',
      kind: 'openai-compatible',
      models: cfg.models,
      defaultModel: cfg.models.includes('deepseek-chat') ? 'deepseek-chat' : cfg.models[0],
      net: net || createNet(),
    })
    this._cfg = cfg
    assertAllowedBaseUrl(cfg.baseUrl, 'deepseek.baseUrl')
    // 主动断言一次模型名，避免把 kimi 之类的名字发到 deepseek
    for (const m of cfg.models) {
      if (!DEEPSEEK_MODELS.includes(m)) {
        throw new ProviderError('E_UNKNOWN_MODEL', `${DEEPSEEK_PROVIDER_ID}: 不支持的模型 ${m}`)
      }
    }
  }

  get baseUrl() {
    return this._cfg.baseUrl
  }

  /** 掩码配置（日志/面板用）。 */
  describeConfig() {
    return describeConfig(this._cfg)
  }

  /**
   * 模型列表。live:true 时真打一次 /v1/models（走白名单与令牌桶），失败退回本地清单。
   */
  async listModels({ live = false } = {}) {
    if (!live) return super.listModels()
    if (!this._cfg.ready) return super.listModels()
    try {
      const res = await this.net.request(ENDPOINTS.deepseekModels(this._cfg.baseUrl), {
        method: 'GET',
        headers: this._headers(),
        model: '',
        limitKey: `${this.id}:models`,
      })
      if (!res.ok) return super.listModels()
      const payload = await res.json()
      const ids = Array.isArray(payload && payload.data)
        ? payload.data.map((m) => String(m.id)).filter((id) => DEEPSEEK_MODELS.includes(id))
        : []
      return ids.length > 0 ? ids.map((id) => ({ id, name: id, source: 'live' })) : super.listModels()
    } catch {
      return super.listModels()
    }
  }

  _headers() {
    return {
      'content-type': 'application/json',
      accept: 'text/event-stream',
      // 密钥只出现在这里，不进任何日志
      authorization: `Bearer ${this._cfg.apiKey}`,
    }
  }

  /**
   * 流式对话。
   * @yields {{type:'delta',text:string,channel:'content'|'reasoning'}|{type:'done',...}|{type:'error',...}}
   */
  async *chat({ messages, tools, stream = true, model = null, signal = null, temperature = null } = {}) {
    let normalized
    try {
      normalized = normalizeMessages(messages)
    } catch (err) {
      yield errorFromThrown(err, { provider: this.id, model })
      return
    }

    const chosen = model || this.defaultModel
    if (!this.hasModel(chosen)) {
      yield {
        type: EVENT.ERROR,
        code: 'E_UNKNOWN_MODEL',
        message: `${this.id}: 不支持的模型 ${chosen}`,
        retryable: false,
        provider: this.id,
        model: chosen,
      }
      return
    }
    if (!this._cfg.ready) {
      yield {
        type: EVENT.ERROR,
        code: 'E_NO_KEY',
        message: `${this.id}: 缺少 API key（data/secrets.json 的 deepseek.apiKey，当前 ${maskKey('')}）`,
        retryable: false,
        provider: this.id,
        model: chosen,
      }
      return
    }

    const body = {
      model: chosen,
      messages: normalized,
      stream: stream !== false,
      ...(temperature === null ? {} : { temperature }),
      ...(tools && tools.length > 0 ? { tools } : {}),
    }

    let response
    try {
      response = await this.net.request(ENDPOINTS.deepseekChatCompletions(this._cfg.baseUrl), {
        method: 'POST',
        headers: this._headers(),
        body: JSON.stringify(body),
        model: chosen,
        limitKey: `${this.id}:${chosen}`,
        ...(signal ? { signal } : {}),
      })
    } catch (err) {
      yield errorFromThrown(err, { provider: this.id, model: chosen })
      return
    }

    if (!response.ok) {
      yield await errorFromResponse(response, { provider: this.id, model: chosen })
      return
    }

    // 非流式：一次读完，包成单个 delta
    if (body.stream === false) {
      try {
        const payload = await response.json()
        const text = payload?.choices?.[0]?.message?.content || ''
        if (text) yield { type: EVENT.DELTA, text, channel: 'content' }
        yield {
          type: EVENT.DONE,
          text,
          provider: this.id,
          model: payload?.model || chosen,
          usage: payload?.usage || null,
          finishReason: payload?.choices?.[0]?.finish_reason || null,
        }
      } catch (err) {
        yield errorFromThrown(err, { provider: this.id, model: chosen })
      }
      return
    }

    let text = ''
    let reasoning = ''
    let usage = null
    let finishReason = null
    // P-R7：function calling 的增量是以 index 分片的，必须按 index 归并后再整段 emit，
    // 否则拿到的是半个 JSON 串（arguments 被切成多块）。
    const pendingCalls = []
    try {
      for await (const frame of parseSse(response.body)) {
        if (frame.data === '[DONE]') break
        const json = frame.json
        if (!json) continue
        if (json.usage) usage = json.usage
        const choice = Array.isArray(json.choices) ? json.choices[0] : null
        if (!choice) continue
        if (choice.finish_reason) finishReason = choice.finish_reason
        const delta = choice.delta || {}
        // reasoner 的思维链走 reasoning_content，单独给一个 channel，界面可折叠显示
        if (typeof delta.reasoning_content === 'string' && delta.reasoning_content) {
          reasoning += delta.reasoning_content
          yield { type: EVENT.DELTA, text: delta.reasoning_content, channel: 'reasoning' }
        }
        if (typeof delta.content === 'string' && delta.content) {
          text += delta.content
          yield { type: EVENT.DELTA, text: delta.content, channel: 'content' }
        }
        if (Array.isArray(delta.tool_calls)) {
          for (const tc of delta.tool_calls) {
            const idx = Number.isFinite(tc.index) ? tc.index : 0
            while (pendingCalls.length <= idx) {
              pendingCalls.push({ id: '', name: '', arguments: '' })
            }
            const slot = pendingCalls[idx]
            if (tc.id) slot.id += String(tc.id)
            if (tc.function && tc.function.name) slot.name += String(tc.function.name)
            if (tc.function && typeof tc.function.arguments === 'string') slot.arguments += tc.function.arguments
          }
        }
      }
    } catch (err) {
      yield errorFromThrown(err, { provider: this.id, model: chosen })
      return
    }

    const toolCalls = pendingCalls
      .filter((c) => c.name)
      .map((c, i) => ({
        id: c.id || `call_${i}`,
        type: 'function',
        name: c.name,
        arguments: c.arguments || '{}',
      }))

    if (toolCalls.length > 0) {
      yield { type: EVENT.TOOL_CALLS, toolCalls, provider: this.id, model: chosen }
    }

    yield {
      type: EVENT.DONE,
      text,
      reasoning: reasoning || null,
      provider: this.id,
      model: chosen,
      usage,
      finishReason,
      ...(toolCalls.length > 0 ? { toolCalls } : {}),
    }
  }
}

export function createDeepSeekProvider(options = {}) {
  return new DeepSeekProvider(options)
}

/** 便捷：一次性取完整回复（内部复用流式，便于测试与非交互场景）。 */
export async function askDeepSeek({ messages, model, net, signal, secretsPath } = {}) {
  const provider = createDeepSeekProvider({ net, secretsPath })
  const result = await collectStream(provider.chat({ messages, model, signal }))
  return {
    ...result,
    text: result.text,
    error: result.errors.length > 0 ? shortMessage(result.errors[0].message) : null,
  }
}
