// packages/core/src/providers/school-gateway.mjs
//
// school-gateway —— 学校 Anthropic 兼容网关（models.sjtu.edu.cn）。
//
// 凭据：baseUrl 与 authToken 在【运行时】从 C:\Users\54958\.claude\settings.json 的
//       env.ANTHROPIC_BASE_URL / env.ANTHROPIC_AUTH_TOKEN 读取（只读！）。
//       —— 绝不写回该文件、绝不把 token 复制进 secrets.json、绝不进日志/汇报/截图。
//       —— 该文件属于 C:\Users\54958\.dsh\** 之外（SAFETY.md 单独标注为"只允许读"）。
// 出网：一律经 net.mjs；白名单已含 models.sjtu.edu.cn。
// 密钥纪律：token 只出现在 x-api-key 头；net.mjs 不记录请求头。

import { ENDPOINTS, assertAllowedBaseUrl, createNet } from '../net.mjs'
import { describeConfig, gatewayConfig, maskKey } from '../config.mjs'
import {
  EVENT,
  ModelProvider,
  ProviderError,
  collectStream,
  errorFromResponse,
  errorFromThrown,
  normalizeMessages,
  parseSse,
  shortMessage,
} from './provider.mjs'

export const GATEWAY_PROVIDER_ID = 'school-gateway'
export const GATEWAY_MODELS = Object.freeze(['deepseek-chat', 'deepseek-reasoner'])
export const ANTHROPIC_VERSION = '2023-06-01'
const DEFAULT_MAX_TOKENS = 2048

export class SchoolGatewayProvider extends ModelProvider {
  constructor({ net, secretsPath, settingsPath, config } = {}) {
    const cfg = config || gatewayConfig({ secretsPath, ...(settingsPath ? { settingsPath } : {}) })
    super({
      id: GATEWAY_PROVIDER_ID,
      name: '学校网关（Anthropic 兼容）',
      kind: 'anthropic-compatible',
      models: cfg.models,
      defaultModel: cfg.models.includes('deepseek-chat') ? 'deepseek-chat' : cfg.models[0],
      net: net || createNet(),
    })
    this._cfg = cfg
    if (cfg.baseUrl) assertAllowedBaseUrl(cfg.baseUrl, 'gateway ANTHROPIC_BASE_URL')
  }

  get baseUrl() {
    return this._cfg.baseUrl
  }

  /** 掩码配置（日志/面板用）：只有 baseUrl 路径与 key 掩码，没有 token 本体。 */
  describeConfig() {
    return describeConfig(this._cfg)
  }

  /** 配置是否就绪（settings.json 是否存在 + 两个 env 是否齐备）。 */
  get ready() {
    return !!this._cfg.ready
  }

  _headers() {
    return {
      'content-type': 'application/json',
      accept: 'text/event-stream',
      'anthropic-version': ANTHROPIC_VERSION,
      // token 只出现在这里
      'x-api-key': this._cfg.authToken,
    }
  }

  async *chat({ messages, tools, stream = true, model = null, signal = null, maxTokens = DEFAULT_MAX_TOKENS } = {}) {
    let normalized
    try {
      normalized = normalizeMessages(messages)
    } catch (err) {
      yield errorFromThrown(err, { provider: this.id, model })
      return
    }

    const chosen = model || this.defaultModel
    if (!this.hasModel(chosen)) {
      yield {
        type: EVENT.ERROR,
        code: 'E_UNKNOWN_MODEL',
        message: `${this.id}: 不支持的模型 ${chosen}`,
        retryable: false,
        provider: this.id,
        model: chosen,
      }
      return
    }
    if (!this._cfg.ready) {
      const why = this._cfg.pathExists
        ? 'settings.json 缺少 env.ANTHROPIC_BASE_URL / env.ANTHROPIC_AUTH_TOKEN'
        : `settings.json 不存在（${this._cfg.settingsPath}）`
      yield {
        type: EVENT.ERROR,
        code: 'E_NO_CREDENTIALS',
        message: `${this.id}: ${why}（token 掩码 ${maskKey(this._cfg.authToken)}）`,
        retryable: false,
        provider: this.id,
        model: chosen,
      }
      return
    }

    // Anthropic 协议：system 走顶层字段，messages 只留 user/assistant
    const systemText = normalized
      .filter((m) => m.role === 'system')
      .map((m) => m.content)
      .join('\n\n')
    const turns = normalized.filter((m) => m.role !== 'system')
    const body = {
      model: chosen,
      max_tokens: maxTokens,
      messages: turns.map((m) => ({ role: m.role, content: m.content })),
      stream: stream !== false,
      ...(systemText ? { system: systemText } : {}),
      ...(tools && tools.length > 0 ? { tools } : {}),
    }

    let response
    try {
      response = await this.net.request(ENDPOINTS.anthropicMessages(this._cfg.baseUrl), {
        method: 'POST',
        headers: this._headers(),
        body: JSON.stringify(body),
        model: chosen,
        limitKey: `${this.id}:${chosen}`,
        ...(signal ? { signal } : {}),
      })
    } catch (err) {
      yield errorFromThrown(err, { provider: this.id, model: chosen })
      return
    }

    if (!response.ok) {
      yield await errorFromResponse(response, { provider: this.id, model: chosen })
      return
    }

    if (body.stream === false) {
      try {
        const payload = await response.json()
        const text = Array.isArray(payload?.content)
          ? payload.content.filter((b) => b && b.type === 'text').map((b) => b.text).join('')
          : ''
        if (text) yield { type: EVENT.DELTA, text, channel: 'content' }
        yield {
          type: EVENT.DONE,
          text,
          provider: this.id,
          model: payload?.model || chosen,
          usage: payload?.usage || null,
          finishReason: payload?.stop_reason || null,
        }
      } catch (err) {
        yield errorFromThrown(err, { provider: this.id, model: chosen })
      }
      return
    }

    let text = ''
    let reasoning = ''
    let usage = null
    let finishReason = null
    try {
      for await (const frame of parseSse(response.body)) {
        const json = frame.json
        if (!json) continue
        const type = json.type || frame.event
        if (type === 'content_block_delta' && json.delta) {
          const kind = json.delta.type
          if (kind === 'text_delta' && typeof json.delta.text === 'string') {
            text += json.delta.text
            yield { type: EVENT.DELTA, text: json.delta.text, channel: 'content' }
          } else if (kind === 'thinking_delta' && typeof json.delta.thinking === 'string') {
            reasoning += json.delta.thinking
            yield { type: EVENT.DELTA, text: json.delta.thinking, channel: 'reasoning' }
          }
        } else if (type === 'message_delta') {
          if (json.delta && json.delta.stop_reason) finishReason = json.delta.stop_reason
          if (json.usage) usage = { ...(usage || {}), ...json.usage }
        } else if (type === 'message_start' && json.message) {
          if (json.message.usage) usage = { ...(usage || {}), ...json.message.usage }
          if (json.message.model && !finishReason) finishReason = finishReason || null
        } else if (type === 'error') {
          yield {
            type: EVENT.ERROR,
            code: 'E_GATEWAY',
            message: shortMessage(json.error?.message || JSON.stringify(json)),
            retryable: false,
            provider: this.id,
            model: chosen,
          }
          return
        } else if (type === 'message_stop') {
          break
        }
      }
    } catch (err) {
      yield errorFromThrown(err, { provider: this.id, model: chosen })
      return
    }

    yield {
      type: EVENT.DONE,
      text,
      reasoning: reasoning || null,
      provider: this.id,
      model: chosen,
      usage,
      finishReason,
    }
  }
}

export function createSchoolGatewayProvider(options = {}) {
  return new SchoolGatewayProvider(options)
}

export async function askGateway({ messages, model, net, signal, secretsPath } = {}) {
  const provider = createSchoolGatewayProvider({ net, secretsPath })
  const result = await collectStream(provider.chat({ messages, model, signal }))
  return { ...result, error: result.errors.length > 0 ? shortMessage(result.errors[0].message) : null }
}
