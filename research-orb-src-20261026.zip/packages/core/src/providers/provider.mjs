// packages/core/src/providers/provider.mjs
//
// provider 抽象层：所有模型出口都实现同一套接口，agent/插件只能看到这一套。
//
//   interface ModelProvider {
//     id: string
//     name: string
//     listModels(): Promise<Array<{ id, name, notes? }>>
//     chat({ messages, tools?, stream?, model?, signal? }): AsyncIterable<ChatEvent>
//   }
//
// ChatEvent 统一三态：
//   { type: 'delta', text }                                   增量文本
//   { type: 'done',  text, model, provider, usage, finishReason, aborted? }
//   { type: 'error', code, message, status?, retryable }
//
// 出网一律经 packages/core/src/net.mjs（白名单/令牌桶/reasoner 每分钟/429 退避/net.jsonl），
// provider 不得自己调 fetch。

import { NetError, classifyStatus } from '../net.mjs'

export const EVENT = Object.freeze({ DELTA: 'delta', DONE: 'done', ERROR: 'error', TOOL_CALLS: 'tool_calls' })

export class ProviderError extends Error {
  constructor(code, message, details = {}) {
    super(message)
    this.name = 'ProviderError'
    this.code = code
    Object.assign(this, details)
  }
}

/** 把疑似密钥的串打码（错误正文可能回显请求头/URL，保险起见统一过一遍）。 */
export function stripSecrets(text) {
  return String(text == null ? '' : text)
    .replace(/\bsk-[A-Za-z0-9._-]{6,}/g, (m) => m.slice(0, 4) + '***')
    .replace(/\bBearer\s+[A-Za-z0-9._-]{6,}/gi, 'Bearer ***')
}

/** 裁剪错误正文，避免把整页 HTML 写进日志/界面。 */
export function shortMessage(text, limit = 300) {
  return stripSecrets(String(text == null ? '' : text).replace(/\s+/g, ' ').trim()).slice(0, limit)
}

/**
 * 归一化消息。
 * P-R7：工具回路需要 `assistant(带 tool_calls)` 与 `tool(带 tool_call_id)` 两种新形态：
 *   · assistant 消息允许带 tool_calls（OpenAI function calling 的"我要调工具"）；
 *   · tool 消息必须带 tool_call_id（否则服务端无法把结果对回那次调用）。
 * 这里只做结构校验与字段透传，**不发明协议**。
 */
export function normalizeMessages(messages) {
  if (!Array.isArray(messages) || messages.length === 0) {
    throw new ProviderError('E_BAD_MESSAGES', 'chat: messages 必须是非空数组')
  }
  const allowed = new Set(['system', 'user', 'assistant', 'tool'])
  return messages.map((m, i) => {
    if (!m || typeof m !== 'object') throw new ProviderError('E_BAD_MESSAGES', `chat: messages[${i}] 必须是对象`)
    if (!allowed.has(m.role)) throw new ProviderError('E_BAD_MESSAGES', `chat: messages[${i}].role 非法 -> ${m.role}`)
    // OpenAI 允许"只调工具不说话"的 assistant 消息 content 为 null —— 放开这一档，
    // 但其余角色仍必须是字符串（否则服务端会 400，而 400 很难归因到消息装配）。
    const hasToolCalls = m.role === 'assistant' && Array.isArray(m.tool_calls) && m.tool_calls.length > 0
    if (typeof m.content !== 'string' && !(hasToolCalls && m.content === null)) {
      throw new ProviderError('E_BAD_MESSAGES', `chat: messages[${i}].content 必须是字符串`)
    }
    const out = { role: m.role, content: m.content }
    if (hasToolCalls) {
      out.tool_calls = m.tool_calls.map((c) => ({
        id: String((c && c.id) || ''),
        type: 'function',
        function: {
          name: String((c && c.function && c.function.name) || ''),
          arguments: String((c && c.function && c.function.arguments) || '{}'),
        },
      }))
    }
    if (m.role === 'tool') {
      if (!m.tool_call_id) {
        throw new ProviderError('E_BAD_MESSAGES', `chat: messages[${i}] 是 tool 角色但缺 tool_call_id`)
      }
      out.tool_call_id = String(m.tool_call_id)
      if (m.name) out.name = String(m.name)
    }
    return out
  })
}

/** 把 Response.body 归一成"按块产出字符串"的异步迭代器（Node Readable / Web Stream 都吃）。 */
export async function* readChunks(body) {
  if (!body) return
  if (typeof body.getReader === 'function') {
    const reader = body.getReader()
    const decoder = new TextDecoder('utf-8')
    try {
      for (;;) {
        const { done, value } = await reader.read()
        if (done) break
        if (value) yield decoder.decode(value, { stream: true })
      }
    } finally {
      try {
        reader.releaseLock()
      } catch {
        /* 已释放 */
      }
    }
    return
  }
  if (typeof body[Symbol.asyncIterator] === 'function') {
    const decoder = new TextDecoder('utf-8')
    for await (const chunk of body) {
      yield typeof chunk === 'string' ? chunk : decoder.decode(chunk, { stream: true })
    }
    return
  }
  if (typeof body.on === 'function') {
    // 老式 Node Readable
    const decoder = new TextDecoder('utf-8')
    const queue = []
    let ended = false
    let failure = null
    body.on('data', (c) => queue.push(typeof c === 'string' ? c : decoder.decode(c, { stream: true })))
    body.on('end', () => {
      ended = true
    })
    body.on('error', (err) => {
      failure = err
      ended = true
    })
    while (!ended || queue.length > 0) {
      if (queue.length === 0) {
        await new Promise((r) => setTimeout(r, 5))
        continue
      }
      yield queue.shift()
    }
    if (failure) throw failure
  }
}

/**
 * 解析 SSE：产出 { event, data, json } — json 为 data 段的 JSON.parse 结果（解析失败则 null）。
 * 兼容 OpenAI 的 `data: [DONE]`（json 为 null、data 为 '[DONE]'）与 Anthropic 的 `event:` 行。
 */
export async function* parseSse(body) {
  let buffer = ''
  let eventName = 'message'
  let dataLines = []

  const flush = function* () {
    if (dataLines.length === 0) return
    const data = dataLines.join('\n')
    let json = null
    try {
      json = JSON.parse(data)
    } catch {
      json = null
    }
    yield { event: eventName, data, json }
    eventName = 'message'
    dataLines = []
  }

  for await (const chunk of readChunks(body)) {
    buffer += chunk
    let idx = buffer.indexOf('\n')
    while (idx >= 0) {
      let line = buffer.slice(0, idx)
      buffer = buffer.slice(idx + 1)
      if (line.endsWith('\r')) line = line.slice(0, -1)
      if (line === '') {
        yield* flush()
      } else if (line.startsWith(':')) {
        // 注释/心跳，忽略
      } else if (line.startsWith('event:')) {
        eventName = line.slice(6).trim()
      } else if (line.startsWith('data:')) {
        dataLines.push(line.slice(5).replace(/^ /, ''))
      }
      idx = buffer.indexOf('\n')
    }
  }
  yield* flush()
}

/** 非 2xx 时读一小段正文并分类成统一错误事件。 */
export async function errorFromResponse(response, meta = {}) {
  let text = ''
  try {
    const raw = await response.text()
    text = shortMessage(raw, 300)
  } catch {
    text = ''
  }
  const { code, retryable } = classifyStatus(response.status)
  return {
    type: EVENT.ERROR,
    code,
    status: response.status,
    retryable,
    message: `${meta.provider || 'provider'}: HTTP ${response.status}${text ? ' -> ' + text : ''}`,
    provider: meta.provider,
    model: meta.model,
  }
}

/** 消费事件流，聚合成 { text, done, errors }（测试、selftest、非流式调用都用它）。 */
export async function collectStream(events) {
  let text = ''
  let done = null
  const errors = []
  for await (const ev of events) {
    if (!ev) continue
    if (ev.type === EVENT.DELTA) text += ev.text
    else if (ev.type === EVENT.DONE) done = ev
    else if (ev.type === EVENT.ERROR) errors.push(ev)
  }
  return { text, done, errors }
}

/** 把 NetError（网络/白名单/限流）转成统一错误事件，避免 provider 直接漏出内部异常。 */
export function errorFromThrown(err, meta = {}) {
  if (err instanceof NetError) {
    return {
      type: EVENT.ERROR,
      code: err.code,
      message: shortMessage(err.message),
      retryable: err.code === 'E_DOMAIN_NOT_ALLOWED' ? false : true,
      provider: meta.provider,
      model: meta.model,
    }
  }
  if (err && (err.name === 'AbortError' || err.code === 'ABORT_ERR')) {
    return {
      type: EVENT.ERROR,
      code: 'E_ABORTED',
      message: '请求已被用户中断',
      retryable: false,
      aborted: true,
      provider: meta.provider,
      model: meta.model,
    }
  }
  return {
    type: EVENT.ERROR,
    code: 'E_PROVIDER',
    message: shortMessage(err && err.message ? err.message : String(err)),
    retryable: false,
    provider: meta.provider,
    model: meta.model,
  }
}

/**
 * provider 基类：只管元数据与公共约定，具体协议由子类实现 chat()。
 */
export class ModelProvider {
  constructor({ id, name, models = [], defaultModel = null, net, kind = 'unknown' }) {
    if (!id) throw new ProviderError('E_BAD_PROVIDER', 'provider 必须有 id')
    this.id = id
    this.name = name || id
    this.kind = kind
    this.net = net || null
    this._models = models.map((m) => (typeof m === 'string' ? { id: m, name: m } : { name: m.id, ...m }))
    this.defaultModel = defaultModel || (this._models[0] && this._models[0].id) || null
  }

  /** 返回元数据副本，密钥/令牌一律不在这里出现。 */
  async listModels() {
    return this._models.map((m) => ({ ...m }))
  }

  hasModel(modelId) {
    return this._models.some((m) => m.id === modelId)
  }

  /** 面板/日志用的可打印描述：只含 id、name、模型 id 与是否就绪，不含任何凭据。 */
  describe() {
    return {
      id: this.id,
      name: this.name,
      kind: this.kind,
      defaultModel: this.defaultModel,
      models: this._models.map((m) => m.id),
    }
  }

  // eslint-disable-next-line require-yield
  async *chat() {
    throw new ProviderError('E_NOT_IMPLEMENTED', `${this.id}: chat() 未实现`)
  }
}
