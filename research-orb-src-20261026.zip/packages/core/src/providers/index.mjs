// packages/core/src/providers/index.mjs
//
// provider 工厂：agent / 插件 / 面板只通过这里拿 provider，拿不到"自己 new 一个绕过限速的"。

import { createNet } from '../net.mjs'
import { DEEPSEEK_PROVIDER_ID, DeepSeekProvider, createDeepSeekProvider } from './deepseek-api.mjs'
import { GATEWAY_PROVIDER_ID, SchoolGatewayProvider, createSchoolGatewayProvider } from './school-gateway.mjs'

export * from './provider.mjs'
export * from './deepseek-api.mjs'
export * from './school-gateway.mjs'

export const PROVIDER_IDS = Object.freeze([DEEPSEEK_PROVIDER_ID, GATEWAY_PROVIDER_ID])

/**
 * 建立 provider 注册表（全部共享同一个 net 实例 → 限速与审计口径一致）。
 * @returns {{ list: Function, byId: Function, net: object, describe: Function }}
 */
export function createProviders({ net = null, secretsPath, settingsPath, fetchImpl } = {}) {
  const shared = net || createNet(fetchImpl ? { fetchImpl } : {})
  const map = new Map()
  const errors = []

  const built = [
    ['deepseek', () => new DeepSeekProvider({ net: shared, secretsPath })],
    ['gateway', () => new SchoolGatewayProvider({ net: shared, secretsPath, settingsPath })],
  ]
  for (const [label, factory] of built) {
    try {
      const provider = factory()
      map.set(provider.id, provider)
    } catch (err) {
      // provider 构造失败不应拖垮整个应用：记下来，界面/自检里明示
      errors.push({ label, message: String((err && err.message) || err) })
    }
  }

  return {
    net: shared,
    list: () => [...map.values()],
    byId: (id) => map.get(id) || null,
    has: (id) => map.has(id),
    describe: () => ({
      providers: [...map.values()].map((p) => ({
        ...p.describe(),
        config: typeof p.describeConfig === 'function' ? p.describeConfig() : null,
      })),
      errors,
    }),
    errors,
  }
}

export default { createProviders, PROVIDER_IDS }
