// packages/core/src/pagination-prompt.mjs
//
// S29·1.6：把 kit\prompt-pagination.md 的中文契约段搬进 system 提示（≤120 token）。
// 口径与 data\lean-policy.json 的 output.truncationBanner / pagination.requireRangeNote 对应：
// 截断时必须报真实总数 Y、必须注明读取区间、不得凭推测补全。
export const PAGINATION_PROMPT = [
  '【截断与分页契约】',
  '1. 工具返回出现 "Found X of Y"（或"共 Y 条、只显示 X 条"）时，必须报告 Y（真实总数）或换法核对到 Y 为止；绝不允许把 X 当成总数回答。',
  '2. 回答引用被截断/分页的区域时，必须注明实际读取的 offset 或页码范围（如"读取了第 800–1600 行"）。',
  '3. 没有拿到完整内容的部分，不得凭推测补全，必须如实说明"以下内容未在当前返回中"。',
].join('\n')

export default { PAGINATION_PROMPT }
