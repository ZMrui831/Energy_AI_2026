// packages/core/src/progress.mjs
//
// 进度汇总（对应任务书交付 3）：把计时账本与当日产出收成一份日报数据。
//
// 口径（全部可重算、可对账）：
//   · 专注时长 = 当天 data/timer/<day>.jsonl 里所有 segment.sec 之和
//     （pause/stop/跨午夜/空闲扣除都会先落 segment 行，所以"求和即总账"）；
//   · 产出计数走【文件 mtime】：data/notes/** 的 .md（排除插件私有抽屉）与
//     data/exports/** 的 .bib，mtime 落在当天本地时间窗内才算"当日新增"；
//   · 汇总时机由调用方驱动：主进程每 60s 一次 + 计时结束时一次（见 main.mjs）。
//
// 为什么产出不靠"创建时登记"：卡片可能被 /card.update 改写、bib 可能重新导出，
// 登记表会与现实漂移；mtime 是文件系统自己记的账，永远和磁盘一致。

import { addDays as addDaysLocal, dayKeyOf } from './timer-store.mjs'
import { createProjects } from './projects.mjs'

const UNCLASSIFIED = '未归类'

/**
 * @param {{ store: object, now?: () => number }} options
 */
export function createProgress(options = {}) {
  const store = options.store
  if (!store || typeof store.readDay !== 'function') {
    throw new Error('progress: 必须注入 store（见 timer-store.mjs）')
  }
  const now = options.now || (() => Date.now())
  const projects = createProjects(store, { now })

  /** 当天事件流 -> 进度对象（纯函数部分，单测直接打）。 */
  function summarizeDay(dayKey) {
    const records = store.readDay(dayKey)
    // 加速/测试会话排除：RESEARCH_ORB_TIME_SCALE≠1 时 start 行带 timeScale，
    // segment 行不带，所以按 sessionId 关联建黑名单。这些会话的 segment /
    // stop / interrupted 一律不进真实进度（专注时长、会话数、分项目），
    // 只在 scaled 区单列（报告里"测试/加速数据"段展示）。
    // 注意：旧账本/内存行没有 timeScale 字段（undefined），Number() 会是 NaN，
    // 必须显式排除 —— "没带字段"不等于"加速"。
    const scaledSessionIds = new Set(
      records
        .filter((r) => r && r.type === 'start' && r.timeScale != null && Number(r.timeScale) !== 1)
        .map((r) => r.sessionId),
    )
    const isScaled = (r) => r && scaledSessionIds.has(r.sessionId)
    const segments = records.filter((r) => r && r.type === 'segment' && !isScaled(r))
    const focusSec = segments.reduce((sum, r) => sum + (Number(r.sec) || 0), 0)

    const byProjectMap = new Map()
    for (const seg of segments) {
      const key = seg.projectId || UNCLASSIFIED
      const cur =
        byProjectMap.get(key) ||
        { projectId: seg.projectId || null, name: UNCLASSIFIED, focusSec: 0, segments: 0, stages: [] }
      cur.focusSec += Number(seg.sec) || 0
      cur.segments += 1
      // 阶段细分：日报要把时间归到"项目 / 阶段"（任务书验收①的形式）
      if (seg.stageId) {
        const st = cur.stages.find((x) => x.stageId === seg.stageId) || { stageId: seg.stageId, stageName: seg.stageId, focusSec: 0 }
        st.focusSec += Number(seg.sec) || 0
        if (!cur.stages.includes(st)) cur.stages.push(st)
      }
      byProjectMap.set(key, cur)
    }
    // 补上项目名/阶段名（项目可能已删/改名，取当前名字并标注）
    const byProject = [...byProjectMap.values()].map((row) => {
      if (row.projectId) {
        try {
          const p = projects.get(row.projectId)
          row.name = p.name
          for (const st of row.stages) {
            const found = (p.stages || []).find((s) => s.id === st.stageId)
            st.stageName = found ? found.name : `${st.stageId}（阶段已删除）`
          }
        } catch {
          row.name = `${row.projectId}（项目已删除）`
          for (const st of row.stages) st.stageName = `${st.stageId}（阶段已删除）`
        }
      }
      row.stages.sort((a, b) => b.focusSec - a.focusSec)
      return row
    })
    byProject.sort((a, b) => b.focusSec - a.focusSec || String(a.name).localeCompare(String(b.name)))

    // 加速区单列：会话数、段数、计时秒数（不计入上方任何汇总）
    const scaledSegments = records.filter((r) => r && r.type === 'segment' && isScaled(r))

    const outputs = store.outputs(dayKey)
    return {
      dayKey,
      generatedAt: new Date(now()).toISOString(),
      focusSec,
      segmentCount: segments.length,
      sessionCount: records.filter((r) => r && r.type === 'start' && !isScaled(r)).length,
      completedCount: records.filter((r) => r && r.type === 'stop' && r.completed && !isScaled(r)).length,
      interruptedCount: records.filter((r) => r && r.type === 'interrupted' && !isScaled(r)).length,
      byProject,
      outputs: {
        cards: { count: outputs.cards.length, files: outputs.cards.map((f) => f.rel) },
        bib: { count: outputs.bib.length, files: outputs.bib.map((f) => f.rel) },
      },
      scaled: {
        sessionCount: scaledSessionIds.size,
        segmentCount: scaledSegments.length,
        focusSec: scaledSegments.reduce((s, r) => s + (Number(r.sec) || 0), 0),
      },
    }
  }

  /** 汇总并落盘 data/progress/<day>.json。 */
  function writeDay(dayKey) {
    const progress = summarizeDay(dayKey)
    store.writeProgress(dayKey, progress)
    return { dayKey, path: store.paths.progress(dayKey), progress }
  }

  /** 读已落盘的当日进度（没有则返回 null）。 */
  function readDay(dayKey) {
    return store.readProgress(dayKey) || null
  }

  /**
   * 节流刷新：主进程每秒调一次，内部按 minIntervalMs 自行判断要不要真写。
   * @param {{dayKey?: string, minIntervalMs?: number, force?: boolean}} [args]
   */
  let lastWriteAt = 0
  function maybeRefresh(args = {}) {
    const dayKey = args.dayKey || dayKeyOf(now())
    const minIntervalMs = args.minIntervalMs === undefined ? 60_000 : args.minIntervalMs
    const t = now()
    if (!args.force && t - lastWriteAt < minIntervalMs) return null
    lastWriteAt = t
    return writeDay(dayKey)
  }

  /** 周汇总：对周一到周日逐日重算（不读中间文件，口径永远最新）。 */
  function summarizeWeek(weekMondayKey, { mondayOf } = {}) {
    const monday = mondayOf || weekMondayKey
    const days = []
    for (let i = 0; i < 7; i += 1) {
      const dk = addDaysLocal(monday, i)
      days.push(summarizeDay(dk))
    }
    const focusSec = days.reduce((s, d) => s + d.focusSec, 0)
    const sessions = days.reduce((s, d) => s + d.sessionCount, 0)
    const completed = days.reduce((s, d) => s + d.completedCount, 0)
    const interrupted = days.reduce((s, d) => s + d.interruptedCount, 0)
    const activeDays = days.filter((d) => d.focusSec > 0 || d.sessionCount > 0).length

    const byProjectMap = new Map()
    const cardSet = new Set()
    const bibSet = new Set()
    for (const d of days) {
      for (const row of d.byProject) {
        const key = row.projectId || UNCLASSIFIED
        // 注意：不能用 `{ ...row }` 起头再 `+= row.focusSec` —— 那会把每个项目的
        // 第一天多加一倍（复制时已含当次值）。从零累加才符合"逐日重算再汇总"的口径。
        const cur = byProjectMap.get(key) || { projectId: row.projectId || null, name: row.name, focusSec: 0, segments: 0, stages: [] }
        cur.focusSec += row.focusSec
        cur.segments += row.segments || 0
        // 阶段细分按 stageId 跨日合并（阶段名取当天见过的名字，项目已删时带标注）
        for (const s of row.stages || []) {
          const st = cur.stages.find((x) => x.stageId === s.stageId) || { stageId: s.stageId, stageName: s.stageName, focusSec: 0 }
          st.focusSec += s.focusSec
          if (!cur.stages.includes(st)) cur.stages.push(st)
        }
        byProjectMap.set(key, cur)
      }
      for (const f of d.outputs.cards.files) cardSet.add(f)
      for (const f of d.outputs.bib.files) bibSet.add(f)
    }
    const byProject = [...byProjectMap.values()].sort((a, b) => b.focusSec - a.focusSec)
    // 加速/测试会话：逐日单列值再汇总（与逐日重算口径一致，不读中间文件）
    const scaled = {
      sessionCount: days.reduce((s, d) => s + (d.scaled ? d.scaled.sessionCount : 0), 0),
      segmentCount: days.reduce((s, d) => s + (d.scaled ? d.scaled.segmentCount : 0), 0),
      focusSec: days.reduce((s, d) => s + (d.scaled ? d.scaled.focusSec : 0), 0),
    }
    return {
      weekKey: monday,
      from: monday,
      to: addDaysLocal(monday, 6),
      generatedAt: new Date(now()).toISOString(),
      focusSec,
      sessionCount: sessions,
      completedCount: completed,
      interruptedCount: interrupted,
      activeDays,
      byProject,
      outputs: {
        cards: { count: cardSet.size, files: [...cardSet].sort() },
        bib: { count: bibSet.size, files: [...bibSet].sort() },
      },
      days,
      scaled,
    }
  }

  return { summarizeDay, writeDay, readDay, maybeRefresh, summarizeWeek, projects }
}

export default { createProgress }
