// packages/core/src/session.mjs
//
// 会话落盘：data\sessions\<id>.jsonl（追加写，经 safefs.appendJsonl）。
//
// 为什么用 JSONL 而不是单个 JSON：
//   1. 追加写天然抗中断 —— 崩在第 7 轮，前 6 轮仍然完整可读；
//   2. safeWrite 的审计只记"写入路径 + 字节数"，一次追加一行，代价恒定；
//   3. 出问题时可以逐行 diff，不需要解析整个文档。
//
// 文件格式（每行一个 JSON 对象，第一行必为 session 元信息）：
//   { type:'session',   id, createdAt, title, provider, model }
//   { type:'user',      ts, seq, text }
//   { type:'assistant', ts, seq, text, reasoning?, provider, model, usage?, finishReason?, aborted?, degraded?, degradedReason?, ms? }
//   { type:'notice',    ts, seq, level, code, message }   ← 降级/错误等系统级提示，界面按此渲染徽标
//
// 读取口径：readSession() 返回 { meta, turns, notices, lines, path }；
// 任何一行解析失败都不会让整个会话报废（坏行计入 badLines 并跳过）。

import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT, appendJsonl, assertInsideRoot, dataPath } from './safefs.mjs'

/** 会话目录：data\sessions（唯一可写根之内）。 */
export const SESSIONS_DIR = dataPath('sessions')

/** 会话 id 合法字符集：只允许 id 出现在文件名里，杜绝 ../ 之类的路径花招。 */
const SESSION_ID_RE = /^[a-z0-9][a-z0-9_-]{2,63}$/i

export class SessionError extends Error {
  constructor(code, message, details = {}) {
    super(message)
    this.name = 'SessionError'
    this.code = code
    Object.assign(this, details)
  }
}

/** 本地时间戳串：20251015-142301（便于人眼排序，不含冒号以避开 Windows 文件名限制）。 */
export function stamp(date = new Date()) {
  const p = (n, w = 2) => String(n).padStart(w, '0')
  return (
    `${date.getFullYear()}${p(date.getMonth() + 1)}${p(date.getDate())}` +
    `-${p(date.getHours())}${p(date.getMinutes())}${p(date.getSeconds())}`
  )
}

/** 生成会话 id（时间戳 + 4 位随机后缀，避免同秒碰撞）。 */
export function newSessionId(date = new Date(), rand = Math.random) {
  const suffix = Math.floor(rand() * 0x10000)
    .toString(16)
    .padStart(4, '0')
  return `s-${stamp(date)}-${suffix}`
}

export function assertSessionId(id) {
  if (typeof id !== 'string' || !SESSION_ID_RE.test(id)) {
    throw new SessionError('E_BAD_SESSION_ID', `session: 非法会话 id -> ${String(id)}`)
  }
  return id
}

/** 会话文件路径（含根内断言，越界直接抛）。 */
export function sessionPath(id) {
  assertSessionId(id)
  return assertInsideRoot(join(SESSIONS_DIR, `${id}.jsonl`))
}

/** 从首条用户消息里取一个可读标题（去换行、截断 40 字符）。 */
export function deriveTitle(text, limit = 40) {
  const clean = String(text == null ? '' : text)
    .replace(/\s+/g, ' ')
    .trim()
  if (!clean) return '新会话'
  return clean.length > limit ? clean.slice(0, limit) + '…' : clean
}

/**
 * 创建会话：写第一行元信息。
 * @param {{ id?: string, title?: string, provider?: string, model?: string, now?: Date }} [opts]
 * @returns {{ id: string, path: string, meta: object }}
 */
export function createSession({ id = null, title = '新会话', provider = null, model = null, now = new Date() } = {}) {
  const sid = assertSessionId(id || newSessionId(now))
  const path = sessionPath(sid)
  if (existsSync(path)) {
    throw new SessionError('E_SESSION_EXISTS', `session: 会话已存在 -> ${sid}`, { id: sid })
  }
  const meta = {
    type: 'session',
    id: sid,
    createdAt: now.toISOString(),
    title: String(title || '新会话'),
    provider: provider || null,
    model: model || null,
  }
  appendJsonl(path, meta)
  return { id: sid, path, meta }
}

/**
 * 追加一行（不做 id 存在性校验：错误事件可能发生在会话创建失败之后，仍要留痕）。
 * @returns {{path: string, bytes: number}}
 */
export function appendLine(id, record) {
  const path = sessionPath(id)
  return appendJsonl(path, record)
}

/** 记一条用户消息。 */
export function appendUser(id, text, extra = {}) {
  return appendLine(id, { type: 'user', ts: new Date().toISOString(), text: String(text ?? ''), ...extra })
}

/** 记一条助手消息（含可选中断/降级元信息）。 */
export function appendAssistant(id, record = {}) {
  return appendLine(id, { type: 'assistant', ts: new Date().toISOString(), ...record })
}

/** 记一条系统提示（降级、错误、限速等），界面据此显示徽标，不混进对话气泡。 */
export function appendNotice(id, { level = 'info', code = 'E_NOTICE', message = '', ...rest } = {}) {
  return appendLine(id, {
    type: 'notice',
    ts: new Date().toISOString(),
    level,
    code,
    message: String(message ?? ''),
    ...rest,
  })
}

/** 读取会话全文；坏行跳过并计数，不抛。 */
export function readSession(id) {
  const path = sessionPath(id)
  if (!existsSync(path)) throw new SessionError('E_NO_SESSION', `session: 会话不存在 -> ${id}`, { id })
  const raw = readFileSync(path, 'utf8')
  const lines = raw.split('\n').filter((l) => l.trim().length > 0)
  const records = []
  let badLines = 0
  for (const line of lines) {
    try {
      records.push(JSON.parse(line))
    } catch {
      badLines += 1
    }
  }
  const meta = records.find((r) => r && r.type === 'session') || null
  const turns = records.filter((r) => r && (r.type === 'user' || r.type === 'assistant'))
  const notices = records.filter((r) => r && r.type === 'notice')
  return { id, path, meta, records, turns, notices, lines: lines.length, badLines }
}

/** 只读头部若干行，用于列表页（避免整文件读入）。 */
function peekMeta(id, maxBytes = 4096) {
  const path = sessionPath(id)
  let text = ''
  try {
    const fd = readFileSync(path, 'utf8')
    text = fd.slice(0, maxBytes)
  } catch {
    return null
  }
  const firstLine = text.split('\n')[0]
  try {
    return JSON.parse(firstLine)
  } catch {
    return null
  }
}

/**
 * 列出全部会话（按 mtime 倒序，最新在前）。
 * @returns {Array<{id, title, provider, model, createdAt, updatedAt, bytes, turns}>}
 */
export function listSessions({ dir = SESSIONS_DIR } = {}) {
  let names = []
  try {
    names = readdirSync(dir)
  } catch {
    return []
  }
  const out = []
  for (const name of names) {
    if (!name.toLowerCase().endsWith('.jsonl')) continue
    const id = name.slice(0, -'.jsonl'.length)
    if (!SESSION_ID_RE.test(id)) continue
    let stat = null
    try {
      stat = statSync(join(dir, name))
    } catch {
      continue
    }
    const meta = peekMeta(id) || {}
    // 轮数按行数近似（首行 session + notice 不算对话轮）
    let turns = 0
    try {
      const text = readFileSync(join(dir, name), 'utf8')
      for (const line of text.split('\n')) {
        if (line.includes('"type":"user"')) turns += 1
      }
    } catch {
      turns = 0
    }
    out.push({
      id,
      title: meta.title || id,
      provider: meta.provider || null,
      model: meta.model || null,
      createdAt: meta.createdAt || null,
      updatedAt: stat ? stat.mtime.toISOString() : null,
      bytes: stat ? stat.size : 0,
      turns,
    })
  }
  out.sort((a, b) => String(b.updatedAt || '').localeCompare(String(a.updatedAt || '')))
  return out
}

/** 取会话的对话消息（不含 notice），可直接喂给 provider.chat()。 */
export function historyMessages(id, { limit = null, system = null } = {}) {
  const { turns } = readSession(id)
  let msgs = turns
    .filter((t) => typeof t.text === 'string' && t.text.length > 0)
    .map((t) => ({ role: t.type === 'user' ? 'user' : 'assistant', content: t.text }))
  if (limit && msgs.length > limit) msgs = msgs.slice(msgs.length - limit)
  return system ? [{ role: 'system', content: String(system) }, ...msgs] : msgs
}

export default {
  SESSIONS_DIR,
  SessionError,
  newSessionId,
  sessionPath,
  deriveTitle,
  createSession,
  appendLine,
  appendUser,
  appendAssistant,
  appendNotice,
  readSession,
  listSessions,
  historyMessages,
}
