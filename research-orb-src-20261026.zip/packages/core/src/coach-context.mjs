// packages/core/src/coach-context.mjs
//
// S25·1A：把「画像 + 目标 + 蓝图摘要」压成 ≤700 token 的 system 片段的【宿主侧只读读取器】。
// 与 profile-context.mjs 同一模式：不改 agent.mjs 内部，由宿主（main.mjs）拼到既有 system 参数。
// 纪律：纯读取、全程 try/catch，任何异常返回 ''（绝不拖停主进程）；
//       token 估算与 profile 插件同口径（estimateTokens = ceil(len/2)）。
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from './safefs.mjs'

// S36：双模数据根——显式传 root 保持 <root>/data 旧布局（测试/宿主注入）；缺省走 DATA_DIR（跟随 ORB_DATA_DIR）。
const dataBase = (root) => (root == null ? DATA_DIR : join(root, 'data'))
export const COACH_DIR = (root) => join(dataBase(root), 'coach')
export const COACH_DIGEST_MAX_TOKENS = 700

export function estimateTokens(s) {
  return Math.max(0, Math.ceil((s || '').length / 2))
}

/** 按 token 预算截断（尽量保完整行；省略号计入预算）。 */
export function fitTokens(text, maxTokens) {
  const t = String(text || '').trim()
  if (!t) return ''
  const maxChars = Math.max(0, maxTokens * 2)
  if (estimateTokens(t) <= maxTokens) return t
  const cut = t.slice(0, Math.max(0, maxChars - 1)) // 留 1 字符给省略号
  const nl = cut.lastIndexOf('\n')
  const body = nl > maxChars * 0.5 ? cut.slice(0, nl) : cut
  return (body + '…').slice(0, maxChars)
}

function readGoal(root) {
  try {
    const p = join(COACH_DIR(root), 'goal.json')
    if (!existsSync(p)) return null
    const g = JSON.parse(readFileSync(p, 'utf8'))
    return g && typeof g.goal === 'string' && g.goal.trim() ? { goal: g.goal.trim(), updatedAt: g.updatedAt || null } : null
  } catch { return null }
}

function readBlueprint(root) {
  try {
    const p = join(COACH_DIR(root), 'blueprint.md')
    if (!existsSync(p)) return ''
    return readFileSync(p, 'utf8').trim()
  } catch { return '' }
}

function readProfileDigest(root) {
  try {
    const base = dataBase(root)
    const p = join(base, 'profile-digest.txt')
    if (!existsSync(p)) return ''
    const prof = existsSync(join(base, 'profile.json'))
      ? JSON.parse(readFileSync(join(base, 'profile.json'), 'utf8'))
      : null
    if (!prof || prof.personalization !== true) return '' // 与 profile-context 同口径：未开启个性化不注入
    return readFileSync(p, 'utf8').trim()
  } catch { return '' }
}

/**
 * 组装教练 system 片段：画像段 + 目标段 + 蓝图摘要段，总 ≤ maxTokens（默认 700）。
 * @returns {string} '' 表示无可注入内容
 */
export function readCoachSystemContext({ root = PROJECT_ROOT, maxTokens = COACH_DIGEST_MAX_TOKENS } = {}) {
  try {
    const profile = readProfileDigest(root)
    const goal = readGoal(root)
    const blueprint = readBlueprint(root)
    if (!profile && !goal && !blueprint) return ''

    const profileTokens = estimateTokens(profile)
    const goalText = goal ? `【用户目标】${goal.goal}` : ''
    const goalTokens = estimateTokens(goalText)

    // 蓝图预算 = 总预算 − 画像 − 目标 − 结构开销；画像超预算时先压画像
    let profileFit = profile
    let budgetLeft = maxTokens - profileTokens - goalTokens - 8
    if (budgetLeft < 40 && profile) {
      profileFit = fitTokens(profile, Math.max(40, maxTokens - goalTokens - 60))
      budgetLeft = maxTokens - estimateTokens(profileFit) - goalTokens - 8
    }
    const blueprintFit = fitTokens(blueprint, Math.max(0, budgetLeft))

    const sections = []
    if (profileFit) sections.push('【用户画像】\n' + profileFit)
    if (goalText) sections.push(goalText)
    if (blueprintFit) sections.push('【研究蓝图（摘要）】\n' + blueprintFit)
    const joined = sections.join('\n')
    // 最终兜底：总预算硬截断
    return fitTokens(joined, maxTokens)
  } catch {
    return ''
  }
}

export default { readCoachSystemContext, estimateTokens, fitTokens, COACH_DIGEST_MAX_TOKENS }
