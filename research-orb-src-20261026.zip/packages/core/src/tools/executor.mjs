// packages/core/src/tools/executor.mjs
//
// 工具执行器（P-R7 架构第三层）：**唯一**的工具入口。模型、插件、命令都只能走这里。
//
// 一次调用的固定顺序（顺序本身就是安全边界，不能调换）：
//   ① 登记检查   —— 未登记的工具直接拒绝（E_TOOL_UNKNOWN）
//   ② 参数校验   —— JSON Schema，缺参数就拒绝，**绝不猜测补全**
//   ③ 路径解析   —— desktop: / project: / home: 展开成绝对路径（桌面读注册表，不猜）
//   ④ 权限判定   —— 拒绝根 / 红线 / 授权根 / 符号链接；deny 一律不执行
//   ⑤ 用户确认   —— confirm 档：批准才继续；**超时 = 不执行**（不是"默认放行"）
//   ⑥ 写前快照   —— 写操作先把目标现状抄进 data\snapshots\<id>\，产出可撤销项
//   ⑦ 执行       —— 带超时；超时给 impl 一个 AbortSignal 让它杀掉自己的子树
//   ⑧ 写后读回   —— 文件类写操作读回校验 sha256/字节数，不一致 → E_WRITE_VERIFY → 自动回滚
//   ⑨ 审计       —— data\logs\tool.jsonl 一行，字段齐全（含绝对路径、决策、哈希、耗时）
//
// 不变量：
//   · **授予（grant）只能抹掉"问"，不能抹掉"拒"**；
//   · **没有确认处理器时，confirm 档一律不执行**（headless 默认拒绝，fail-closed）；
//   · 每一步失败都要落审计 —— "被拒绝"同样是可追责的动作。

import { createRequire } from 'node:module'
import { DECISION, TIER, createGrantStore, createPolicy, describeRequest, evaluate } from './permissions.mjs'
import { currentModePermissions, currentModeId } from '../modes.mjs'
import { createRollback, nodeFsAdapter } from './rollback.mjs'
import { formatErrors } from './schema.mjs'
import { ToolRegistryError } from './registry.mjs'
import { appendJsonl, logPath } from '../safefs.mjs'

const require_ = createRequire(import.meta.url)

/** 默认哈希（读回校验与审计共用同一口径：sha256）。 */
const defaultHash = (data) => {
  const { createHash } = require_('node:crypto')
  return createHash('sha256').update(data).digest('hex')
}

/** 默认文件系统（读回校验用）。与 rollback 共用一套适配层，测试可整体注入。 */
let _defaultFs = null
function getDefaultFs() {
  if (!_defaultFs) _defaultFs = nodeFsAdapter()
  return _defaultFs
}

export class ToolError extends Error {
  constructor(code, message, extra = {}) {
    super(message)
    this.name = 'ToolError'
    this.code = code
    Object.assign(this, extra)
  }
}

export const DEFAULT_CONFIRM_TIMEOUT_MS = 120000

/** 没有确认处理器时的默认回答：**不批准**。headless 下绝不放行。 */
function denyByDefault() {
  return { approved: false, reason: 'no-confirm-handler' }
}

/** 给 impl 的超时包装：超时后 reject，并给 AbortSignal 让 impl 自杀。 */
function withTimeout(promise, ms, controller) {
  if (!Number.isFinite(ms) || ms <= 0) return Promise.resolve(promise)
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      try {
        controller.abort()
      } catch {
        /* 已 abort */
      }
      reject(new ToolError('E_TIMEOUT', `工具执行超时（${ms}ms）已中止`))
    }, ms)
    Promise.resolve(promise).then(
      (v) => {
        clearTimeout(timer)
        resolve(v)
      },
      (e) => {
        clearTimeout(timer)
        reject(e)
      },
    )
  })
}

/** 摘要化参数：审计要"看得懂"，但不能把整篇正文塞进日志。 */
function summarizeArgs(args, limit = 400) {
  if (args == null) return {}
  const out = {}
  for (const [k, v] of Object.entries(args)) {
    if (typeof v === 'string') out[k] = v.length > 160 ? v.slice(0, 160) + `…(${v.length})` : v
    else if (Array.isArray(v)) out[k] = `[${v.length} 项]`
    else if (v && typeof v === 'object') out[k] = `{${Object.keys(v).join(',')}}`
    else out[k] = v
  }
  const s = JSON.stringify(out)
  return s && s.length > limit ? { _truncated: s.slice(0, limit) + '…' } : out
}

/**
 * @param {{
 *   registry: object,
 *   policy?: object,
 *   grants?: object,
 *   paths: object,
 *   rollback?: object,
 *   confirm?: Function,          // async (request) => {approved, remember?}
 *   confirmTimeoutMs?: number,
 *   lstat?: Function|null,       // 符号链接探测
 *   fs?: object,                 // 注入文件系统（读回校验用）
 *   onEvent?: Function,          // 可视化：正在做什么
 *   auditPath?: string,
 * }} options
 */
export function createToolExecutor(options = {}) {
  const registry = options.registry
  if (!registry || typeof registry.get !== 'function') {
    throw new ToolError('E_NO_REGISTRY', 'executor: 需要 createToolRegistry() 的返回值')
  }
  const policy = options.policy || createPolicy({ paths: options.paths })
  const grants = options.grants || createGrantStore()
  const rollback = options.rollback || createRollback({ root: options.snapshotRoot, fs: options.fs })
  const confirm = options.confirm || denyByDefault
  const confirmTimeoutMs = Number.isFinite(options.confirmTimeoutMs) ? options.confirmTimeoutMs : DEFAULT_CONFIRM_TIMEOUT_MS
  const emit = typeof options.onEvent === 'function' ? options.onEvent : () => {}
  const auditFile = options.auditPath || logPath('tool.jsonl')
  const lstat = options.lstat || null

  // 审计出口。默认走 safefs（唯一写出口 + 根断言）；测试可注入，
  // 于是"审计字段是否齐全"能纯内存验证，不必往 data\logs\ 里丢测试文件。
  const audit =
    typeof options.audit === 'function'
      ? options.audit
      : (rec) => {
          try {
            appendJsonl(auditFile, rec)
          } catch (err) {
            process.stderr.write(`[research-orb/tools] 工具审计写入失败：${err && err.message}\n`)
          }
        }

  /**
   * 跑一次工具。
   * @param {{toolId:string, args?:object, sessionId?:string, origin?:string}} call
   */
  async function run(call = {}) {
    const t0 = Date.now()
    const toolId = String(call.toolId || '')
    const args = call.args && typeof call.args === 'object' ? call.args : {}
    const sessionId = call.sessionId || null
    const origin = call.origin || 'unknown'
    const rec = { ts: new Date().toISOString(), sessionId, origin, toolId, args: summarizeArgs(args) }

    const fail = (code, message, extra = {}) => {
      const ms = Date.now() - t0
      audit({ ...rec, decision: 'error', result: 'error', code, message: String(message).slice(0, 300), durationMs: ms, ...extra })
      emit({ type: 'tool:error', toolId, code, message: String(message), targets: rec.targets || [] })
      return { ok: false, toolId, error: { code, message: String(message) }, denied: false, ms, ...extra }
    }

    // ① 登记检查
    const tool = registry.get(toolId)
    if (!tool) return fail('E_TOOL_UNKNOWN', `未登记的工具 ${toolId}（可用：${registry.list().map((t) => t.id).join(', ')}）`)

    // ② 参数校验（缺参数拒绝，不猜）
    try {
      registry.validateArgs(toolId, args)
    } catch (err) {
      if (err instanceof ToolRegistryError && err.code === 'E_TOOL_UNKNOWN') return fail('E_TOOL_UNKNOWN', err.message)
      const msg = err && err.errors ? formatErrors(err.errors) : String((err && err.message) || err)
      return fail('E_BAD_ARGS', msg)
    }

    // ③ 路径解析
    const rawTargets = (() => {
      try {
        return tool.targetsOf(args) || []
      } catch (err) {
        return null
      }
    })()
    if (rawTargets === null) return fail('E_BAD_TARGETS', '工具无法从参数中解析出目标路径')
    const targets = []
    for (const raw of rawTargets) {
      const r = options.paths.resolveInput(raw)
      if (!r.ok) return fail(r.code || 'E_BAD_PATH', r.message, { targets })
      targets.push(r.path)
    }
    rec.targets = targets
    rec.write = tool.write === true

    // ④ 权限判定
    // ④.5 运行模式叠加（S22）：readonly 档 denyWrite/denyExec 命中即拒绝，并复用既有审计路径
    const modePerm = currentModePermissions()
    const modeBlocks =
      !!modePerm &&
      ((tool.write === true && modePerm.denyWrite === true) ||
        (tool.id === 'shell.run' && modePerm.denyExec === true))
    let decision
    if (modeBlocks) {
      decision = {
        decision: DECISION.DENY,
        tier: 'mode',
        code: 'E_MODE_READONLY',
        reason: `当前模式「${currentModeId()}」禁止此操作（denyWrite=${!!(modePerm && modePerm.denyWrite)} / denyExec=${!!(modePerm && modePerm.denyExec)}）`,
        matchedRoot: null,
      }
    } else {
      decision = evaluate({ toolId, targets, write: tool.write === true, policy, grants, lstat })
    }
    rec.decision = decision.decision
    rec.tier = decision.tier
    rec.reason = decision.reason
    rec.matchedRoot = decision.matchedRoot

    if (decision.decision === DECISION.DENY) {
      const ms = Date.now() - t0
      audit({ ...rec, result: 'denied', code: decision.code, durationMs: ms })
      emit({ type: 'tool:denied', toolId, code: decision.code, reason: decision.reason, targets })
      return { ok: false, denied: true, toolId, error: { code: decision.code, message: decision.reason }, targets, ms }
    }

    // ⑤ 确认
    if (decision.decision === DECISION.CONFIRM) {
      const request = describeRequest({ toolId, args, targets, decision })
      emit({ type: 'tool:confirm', toolId, ...request, targets, timeoutMs: confirmTimeoutMs })
      let answer
      let confirmTimer = null
      try {
        answer = await Promise.race([
          Promise.resolve(confirm({ ...request, toolId, args, targets, timeoutMs: confirmTimeoutMs })),
          new Promise((_, reject) => {
            // 这个定时器**必须**能被清掉：否则"用户点了批准"之后它还会挂在那里，
            // 把事件循环拖住整整一个超时周期（表现为主进程迟迟不退出）——
            // 修法是 clearTimeout（见下面两处），**不是** unref：
            // unref 会让"等待用户批准"这件事不再托住事件循环，
            // 纯 node 场景下进程会在超时还没到时就退出，把授权请求丢在半路。
            confirmTimer = setTimeout(() => reject(new ToolError('E_CONFIRM_TIMEOUT', `等待批准超时（${confirmTimeoutMs}ms）`)), confirmTimeoutMs)
          }),
        ])
      } catch (err) {
        if (confirmTimer) clearTimeout(confirmTimer)
        const ms = Date.now() - t0
        const code = (err && err.code) || 'E_CONFIRM_FAILED'
        audit({ ...rec, result: 'not-executed', code, message: String((err && err.message) || err), durationMs: ms })
        emit({ type: 'tool:denied', toolId, code, reason: String((err && err.message) || err), targets })
        return { ok: false, denied: true, notExecuted: true, toolId, error: { code, message: String((err && err.message) || err) }, targets, ms }
      }
      if (confirmTimer) clearTimeout(confirmTimer)
      const approved = !!(answer && answer.approved)
      if (!approved) {
        const ms = Date.now() - t0
        const code = answer && answer.reason === 'timeout' ? 'E_CONFIRM_TIMEOUT' : 'E_USER_DENIED'
        audit({ ...rec, result: 'not-executed', code, durationMs: ms })
        emit({ type: 'tool:denied', toolId, code, reason: code === 'E_USER_DENIED' ? '用户未批准' : '等待批准超时', targets })
        return { ok: false, denied: true, notExecuted: true, toolId, error: { code, message: code === 'E_USER_DENIED' ? '用户未批准，未执行' : '等待批准超时，未执行' }, targets, ms }
      }
      if (answer && answer.remember) grants.grant(toolId)
      rec.granted = true
    }

    // ⑥ 写前快照
    let snapshotEntry = null
    if (tool.write === true) {
      try {
        snapshotEntry = rollback.before(targets, { toolId })
      } catch (err) {
        return fail((err && err.code) || 'E_SNAPSHOT_FAILED', (err && err.message) || err)
      }
      rec.snapshotId = snapshotEntry.id
    }

    // ⑦ 执行
    const controller = new AbortController()
    emit({
      type: 'tool:start',
      toolId,
      label: tool.label,
      targets,
      write: tool.write === true,
      snapshotId: snapshotEntry ? snapshotEntry.id : null,
    })
    let value
    try {
      const ctx = {
        paths: options.paths,
        signal: controller.signal,
        deadline: Date.now() + tool.timeoutMs,
        emit: (ev) => emit({ ...ev, toolId }),
        toolId,
      }
      value = await withTimeout(tool.run(args, ctx), tool.timeoutMs, controller)
    } catch (err) {
      const ms = Date.now() - t0
      const code = (err && err.code) || 'E_TOOL_FAILED'
      const message = String((err && err.message) || err)
      // 写操作失败：已经动过的东西要能回去 —— 直接回滚本次快照
      if (snapshotEntry) {
        try {
          rollback.undo(snapshotEntry.id)
          rec.rolledBack = true
          emit({ type: 'tool:rollback', toolId, snapshotId: snapshotEntry.id, reason: message })
        } catch (ue) {
          rec.rollbackFailed = String((ue && ue.message) || ue)
        }
      }
      audit({ ...rec, result: 'error', code, message: message.slice(0, 300), durationMs: ms })
      emit({ type: 'tool:error', toolId, code, message, targets })
      return { ok: false, toolId, error: { code, message }, targets, snapshotId: snapshotEntry ? snapshotEntry.id : null, rolledBack: !!rec.rolledBack, ms }
    }

    // ⑧ 写后读回校验（只针对产出了文件的写操作）
    let verified = null
    const expectHash = value && typeof value === 'object' && typeof value.hash === 'string' ? value.hash : null
    const primary = value && typeof value === 'object' && typeof value.path === 'string' ? value.path : targets[0] || null
    if (tool.write === true && primary && (expectHash || (value && value.bytes !== undefined))) {
      const got = readBack(primary, options.fs)
      const okHash = expectHash ? !!got && got.hash === expectHash : true
      const okBytes = value && Number.isFinite(value.bytes) ? !!got && got.bytes === value.bytes : true
      verified = { path: primary, exists: !!got, bytes: got ? got.bytes : 0, hash: got ? got.hash : null, hashMatch: okHash, bytesMatch: okBytes }
      rec.verified = verified
      if (!got || !okHash || !okBytes) {
        const ms = Date.now() - t0
        const code = 'E_WRITE_VERIFY'
        if (snapshotEntry) {
          try {
            rollback.undo(snapshotEntry.id)
            rec.rolledBack = true
            emit({ type: 'tool:rollback', toolId, snapshotId: snapshotEntry.id, reason: '写后读回校验失败' })
          } catch (ue) {
            rec.rollbackFailed = String((ue && ue.message) || ue)
          }
        }
        const message = `写后读回校验失败（${primary}）：${!got ? '文件不存在' : !okHash ? '哈希不一致' : '字节数不一致'}，已回滚`
        audit({ ...rec, result: 'error', code, message, durationMs: ms })
        emit({ type: 'tool:error', toolId, code, message, targets })
        return { ok: false, toolId, error: { code, message }, targets, verified, snapshotId: snapshotEntry ? snapshotEntry.id : null, rolledBack: !!rec.rolledBack, ms }
      }
    }

    // ⑨ 审计
    const ms = Date.now() - t0
    const bytes = value && typeof value === 'object' ? value.bytes : undefined
    audit({
      ...rec,
      result: 'ok',
      bytes: Number.isFinite(bytes) ? bytes : undefined,
      hash: expectHash || (verified && verified.hash) || (value && value.hash) || undefined,
      durationMs: ms,
    })
    emit({ type: 'tool:done', toolId, label: tool.label, targets, value, ok: true, ms, snapshotId: snapshotEntry ? snapshotEntry.id : null })

    return {
      ok: true,
      toolId,
      targets,
      value,
      verified,
      snapshotId: snapshotEntry ? snapshotEntry.id : null,
      undoable: !!snapshotEntry,
      tier: decision.tier,
      ms,
    }
  }

  function readBack(path, injectedFs) {
    const useFs = injectedFs || getDefaultFs()
    try {
      if (!useFs.existsSync(path)) return null
      const data = useFs.readFileSync(path)
      return { bytes: data.length, hash: (options.hash || defaultHash)(data) }
    } catch {
      return null
    }
  }

  return {
    run,
    policy,
    grants,
    rollback,
    auditPath: auditFile,
    undoLast: () => rollback.undoLast(),
    undo: (id) => rollback.undo(id),
    undoList: () => rollback.list(),
    tools: () => registry.list(),
  }
}

export default { createToolExecutor, ToolError, DEFAULT_CONFIRM_TIMEOUT_MS, DECISION, TIER }
