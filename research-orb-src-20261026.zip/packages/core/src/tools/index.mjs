// packages/core/src/tools/index.mjs
//
// 工具层装配入口（P-R7）。**任何想用工具的地方都从这里取 runtime**，不要自己 new。
//
//   registry   —— 能力清单 + 参数契约（唯一真相）
//   policy     —— 权限矩阵（授权根 / 拒绝根 / 红线 / 三档）
//   grants     —— "本次会话同类不再询问"的记录（只能抹掉 confirm）
//   executor   —— 唯一执行闸门（校验 → 权限 → 确认 → 快照 → 执行 → 读回 → 审计）
//   rollback   —— 快照与 /undo
//
// 注入点说明：
//   host.windowTitles / focusWindow / clipboard —— Electron 专有能力（core 不 import electron）
//   host.net / host.screen / host.timer / host.notes —— 复用既有内核能力，不重写一遍
//   没注入的能力走**诚实降级**，绝不伪造成功。

import { createPathResolver } from './paths.mjs'
import { createPolicy, createGrantStore } from './permissions.mjs'
import { createToolRegistry } from './registry.mjs'
import { createRollback } from './rollback.mjs'
import { createToolExecutor } from './executor.mjs'
import { registerFsTools } from './impl/fs.mjs'
import { registerDocTools } from './impl/doc.mjs'
import { registerShellTools } from './impl/shell.mjs'
import { registerAppTools } from './impl/app.mjs'
import { registerClipTools } from './impl/clip.mjs'
import { registerBridgeTools } from './impl/bridge.mjs'
import { registerSubagentTools } from './impl/subagent.mjs'
import { PROJECT_ROOT } from '../safefs.mjs'

export const TOOL_LAYER_VERSION = '0.7.0-tools'

/**
 * @param {{
 *   paths?: object,
 *   config?: object,          // data\config.json 全文（读其中的 tools 段）
 *   host?: object,            // 宿主注入的 Electron / 内核能力
 *   confirm?: Function,       // 权限卡回调；**不传 = confirm 档一律不执行**（fail-closed）
 *   onEvent?: Function,       // 可视化事件流
 *   fs?: object, child?: object,
 *   snapshotRoot?: string, auditPath?: string,
 * }} options
 */
export function createToolRuntime(options = {}) {
  const paths = options.paths || createPathResolver()
  const host = options.host || {}
  const registry = createToolRegistry()

  const toolCfg = (options.config && options.config.tools) || {}
  const shellExtra = Array.isArray(toolCfg.shell && toolCfg.shell.extraAllow) ? toolCfg.shell.extraAllow : []

  registerFsTools(registry, { fs: options.fs })
  registerDocTools(registry, { fs: options.fs })
  registerShellTools(registry, {
    child: options.child,
    extraAllow: shellExtra,
    roots: toolCfg.roots || undefined,
  })
  registerAppTools(registry, { child: options.child, fs: options.fs, host })
  registerClipTools(registry, { child: options.child, host })
  registerBridgeTools(registry, { host, fs: options.fs })
  // S45·P1：只读子代理（俗称 spawn_researcher）。出网能力只在宿主注入时才给，
  // 没注入 -> web 类目标如实写成【无法验证+原因】，绝不猜。
  registerSubagentTools(registry, {
    fs: options.fs,
    net: host && host.net && typeof host.net.request === 'function' ? host.net : null,
  })

  const policy = createPolicy({ paths, config: options.config })
  const grants = createGrantStore()
  const rollback = createRollback({ root: options.snapshotRoot, fs: options.fs })
  const executor = createToolExecutor({
    registry,
    policy,
    grants,
    paths,
    rollback,
    ...(options.confirm ? { confirm: options.confirm } : {}),
    ...(options.onEvent ? { onEvent: options.onEvent } : {}),
    ...(options.auditPath ? { auditPath: options.auditPath } : {}),
    ...(options.fs ? { fs: options.fs } : {}),
  })

  return {
    version: TOOL_LAYER_VERSION,
    registry,
    policy,
    grants,
    executor,
    rollback,
    paths,
    host,
    root: PROJECT_ROOT,
    /** 工具清单（面板/文档用）。 */
    tools: () => registry.list(),
    /** 跑一次工具（唯一入口）。 */
    run: (call) => executor.run(call),
    /** 撤销。 */
    undoLast: () => executor.undoLast(),
    undo: (id) => executor.undo(id),
    undoList: () => executor.undoList(),
    /** 双通道：OpenAI function calling 用的 tools 数组。 */
    openAITools: (ids) => registry.toOpenAITools(ids),
    /** 双通道：学校网关严格 JSON 回退用的规格文本。 */
    gatewaySpec: (ids) => registry.toGatewaySpec(ids),
    /** 会话结束/切换形态时清空授权（授权不跨会话）。 */
    resetGrants: () => grants.clear(),
    /** 自检用：把关键事实摆出来（授权根、拒绝根、工具数、档位）。 */
    describe: () => ({
      version: TOOL_LAYER_VERSION,
      root: PROJECT_ROOT,
      paths: paths.describe(),
      tools: registry.list().map((t) => ({ id: t.id, label: t.label, write: t.write })),
      policy: policy.describe(),
      pendingUndos: executor.undoList().length,
    }),
  }
}

export {
  createPathResolver, createPolicy, createGrantStore, createToolRegistry, createRollback, createToolExecutor,
}
export default { createToolRuntime, TOOL_LAYER_VERSION }
