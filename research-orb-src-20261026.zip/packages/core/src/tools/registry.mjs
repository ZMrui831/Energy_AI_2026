// packages/core/src/tools/registry.mjs
//
// 工具注册表（P-R7 架构第一层）：**能力清单 + 参数契约**的唯一真相。
//
// 一个工具 = { id, label, description, params(JSON Schema), targetsOf(args), run(args, ctx) }
//   · params    既有文档作用也是闸门：模型传错参数就拒绝，绝不猜；
//   · targetsOf 从参数里抽出"这次要动哪些文件"——权限矩阵只对**解析后的绝对路径**
//     做判定，绝不对模型给的原始字符串做判定（否则 desktop: 别名形同虚设）；
//   · run       真正的执行体，只允许通过 ctx 拿到受限能力（ctx.fs / ctx.exec / ctx.paths…），
//     拿不到裸 require('fs')，也就绕不过权限闸门。
//
// 双通道输出：
//   toOpenAITools()      —— deepseek-api（OpenAI 兼容 function calling）
//   toGatewaySpec()      —— school-gateway 的严格 JSON 回退提示词（见 agent 的工具回路）

import { assertValid, validate } from './schema.mjs'
import { TIER } from './permissions.mjs'

export class ToolRegistryError extends Error {
  constructor(code, message, extra = {}) {
    super(message)
    this.name = 'ToolRegistryError'
    this.code = code
    Object.assign(this, extra)
  }
}

const TOOL_ID_RE = /^[a-z][a-z0-9]*(\.[a-z0-9]+)+$/

/**
 * 定义一个工具。
 * @param {{
 *   id: string, label: string, description: string,
 *   params?: object,                       // 根必须是 { type:'object', properties, required }
 *   targetsOf?: (args:object)=>string[],   // 抽出路径类参数（原始字符串，由 executor 解析）
 *   timeoutMs?: number,
 *   write?: boolean,                       // 是否为写操作（写前快照 / 写后读回校验）
 *   run: (args:object, ctx:object)=>Promise<any>|any,
 * }} def
 */
export function defineTool(def) {
  const id = String(def.id || '')
  if (!TOOL_ID_RE.test(id)) {
    throw new ToolRegistryError('E_BAD_TOOL_ID', `工具 id 必须是 小写.小写 形式 -> ${id}`)
  }
  if (typeof def.run !== 'function') {
    throw new ToolRegistryError('E_NO_RUN', `工具 ${id} 缺少 run()`)
  }
  const params = def.params || { type: 'object', properties: {}, required: [] }
  if (params.type !== 'object') {
    throw new ToolRegistryError('E_BAD_SCHEMA', `工具 ${id} 的 params 根必须是 object`)
  }
  return {
    id,
    label: def.label || id,
    description: String(def.description || '').trim(),
    params,
    targetsOf: typeof def.targetsOf === 'function' ? def.targetsOf : () => [],
    timeoutMs: Number.isFinite(def.timeoutMs) ? def.timeoutMs : 30000,
    write: def.write === true,
    run: def.run,
  }
}

export function createToolRegistry() {
  const tools = new Map()

  function register(def) {
    const tool = def && typeof def.run === 'function' && def.id ? def : defineTool(def)
    if (tools.has(tool.id)) {
      throw new ToolRegistryError('E_DUPLICATE', `工具重复登记 -> ${tool.id}`)
    }
    tools.set(tool.id, tool)
    return tool
  }

  function get(id) {
    return tools.get(String(id || '')) || null
  }

  function has(id) {
    return tools.has(String(id || ''))
  }

  function list() {
    return [...tools.values()].map((t) => ({
      id: t.id,
      label: t.label,
      description: t.description,
      write: t.write,
      timeoutMs: t.timeoutMs,
      params: t.params,
    }))
  }

  /** 校验参数：失败抛 SchemaError（E_BAD_ARGS）。 */
  function validateArgs(id, args) {
    const tool = get(id)
    if (!tool) throw new ToolRegistryError('E_TOOL_UNKNOWN', `未登记的工具 -> ${id}`)
    return assertValid(tool.params, args == null ? {} : args, id)
  }

  /** 只返回 ok/errors，不抛（模型回退通道会用）。 */
  function checkArgs(id, args) {
    const tool = get(id)
    if (!tool) return { ok: false, errors: [{ path: '$', code: 'E_TOOL_UNKNOWN', message: `未登记的工具 ${id}` }] }
    return validate(tool.params, args == null ? {} : args)
  }

  /** deepseek（OpenAI 兼容）function calling 的 tools 数组。 */
  function toOpenAITools(ids = null) {
    const picked = ids ? ids.map(get).filter(Boolean) : [...tools.values()]
    return picked.map((t) => ({
      type: 'function',
      function: {
        name: t.id,
        description: t.description || t.label,
        parameters: t.params,
      },
    }))
  }

  /**
   * school-gateway 的严格 JSON 回退规格（模型看得懂的文本）。
   * 网关走 Anthropic 协议，本机网关不保证支持 tools，所以退化成"严格 JSON"：
   * 模型必须在正文里输出且仅输出一个 JSON 对象，由 agent 侧解析。
   */
  function toGatewaySpec(ids = null) {
    const picked = ids ? ids.map(get).filter(Boolean) : [...tools.values()]
    const lines = [
      '你可以使用下面的工具。**必须且只能**输出如下格式的一个 JSON 对象（不要包裹在代码块里，不要附加任何解释文字）：',
      '{"tool": "<工具名>", "args": { ...参数... }}',
      '',
      '规则：',
      '· 不需要工具时，正常用自然语言回答，不要输出 JSON；',
      '· 参数必须严格符合下面的声明，缺少必填参数就不要调用；',
      '· 路径可以用别名前缀：project:（项目根）、home:（用户目录）、desktop:（系统登记的桌面）；',
      '· 一次只调用一个工具；调用后会看到结果，再决定下一步。',
      '',
      '工具清单：',
    ]
    for (const t of picked) {
      const req = Array.isArray(t.params.required) ? t.params.required : []
      const props = t.params.properties || {}
      lines.push(`- ${t.id}（${t.label}）：${t.description}`)
      const keys = Object.keys(props)
      if (keys.length === 0) lines.push('    参数：无')
      else {
        for (const k of keys) {
          const p = props[k] || {}
          const bits = [String(p.type || 'any')]
          if (req.includes(k)) bits.push('必填')
          if (p.enum) bits.push('取值 ' + p.enum.join('|'))
          if (p.description) bits.push(p.description)
          lines.push(`    · ${k}：${bits.join('，')}`)
        }
      }
    }
    return lines.join('\n')
  }

  return { register, get, has, list, validateArgs, checkArgs, toOpenAITools, toGatewaySpec, size: () => tools.size }
}

export default { defineTool, createToolRegistry, ToolRegistryError, TIER }
