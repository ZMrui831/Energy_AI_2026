// packages/core/src/tools/schema.mjs
//
// 极简 JSON Schema 校验器（只支持工具参数需要的那部分）。
//
// 为什么自己写而不是装 ajv：
//   1. 工具参数 Schema 只用得到 type/properties/required/enum/范围/长度/items/additionalProperties，
//      引一个校验器进来为这点功能背一份供应链与体积，不划算；
//   2. **校验失败必须拒绝、绝不猜测补全**——这是硬要求。自己写可以精确控制
//      "缺参数就是错，不填默认值"这条纪律（见 COERCE 常量恒为 false）。
//
// 支持的关键词：
//   type: object | array | string | number | integer | boolean | null
//   properties / required / additionalProperties(false 时拒绝未声明字段)
//   items（数组元素 schema）
//   enum / minimum / maximum / exclusiveMinimum / exclusiveMaximum
//   minLength / maxLength / pattern / minItems / maxItems

export class SchemaError extends Error {
  constructor(code, message, extra = {}) {
    super(message)
    this.name = 'SchemaError'
    this.code = code
    Object.assign(this, extra)
  }
}

/** 是否允许"猜测补全"：恒为 false。缺参数 = 拒绝，不猜。 */
export const COERCE = false

const TYPE_OF = (v) => {
  if (v === null) return 'null'
  if (Array.isArray(v)) return 'array'
  if (Number.isInteger(v) && typeof v === 'number') return 'integer'
  return typeof v
}

/** type 判定：integer 也算 number（JSON Schema 语义）。 */
function matchesType(value, type) {
  const t = TYPE_OF(value)
  if (t === type) return true
  if (type === 'number' && t === 'integer') return true
  return false
}

function typeName(value) {
  const t = TYPE_OF(value)
  return t === 'integer' ? 'number' : t
}

/**
 * 校验参数。
 * @param {object} schema  JSON Schema（根必须是 object）
 * @param {object} value   待校验值
 * @returns {{ok:boolean, errors: Array<{path:string, code:string, message:string}>}}
 */
export function validate(schema, value) {
  const errors = []
  walk(schema || {}, value, '$', errors, 0)
  return { ok: errors.length === 0, errors }
}

/** 严格版：不通过直接抛 SchemaError（executor 用）。 */
export function assertValid(schema, value, toolId = '') {
  const r = validate(schema, value)
  if (!r.ok) {
    const first = r.errors[0]
    throw new SchemaError(
      'E_BAD_ARGS',
      `${toolId ? toolId + ': ' : ''}参数校验失败（${first.path} ${first.message}）；不会猜测补全`,
      { toolId, errors: r.errors },
    )
  }
  return true
}

const MAX_DEPTH = 12

function walk(schema, value, path, errors, depth) {
  if (depth > MAX_DEPTH) {
    errors.push({ path, code: 'E_TOO_DEEP', message: '参数嵌套过深' })
    return
  }
  if (!schema || typeof schema !== 'object') return

  if (schema.type) {
    const types = Array.isArray(schema.type) ? schema.type : [schema.type]
    const ok = types.some((t) => matchesType(value, t))
    if (!ok) {
      errors.push({
        path,
        code: 'E_TYPE',
        message: `应为 ${types.join('|')}，实际 ${typeName(value)}`,
      })
      return
    }
  }

  if (schema.enum && Array.isArray(schema.enum)) {
    if (!schema.enum.some((e) => e === value)) {
      errors.push({ path, code: 'E_ENUM', message: `必须是 ${schema.enum.map((e) => JSON.stringify(e)).join(' / ')} 之一` })
      return
    }
  }

  if (typeof value === 'string') {
    if (typeof schema.minLength === 'number' && value.length < schema.minLength) {
      errors.push({ path, code: 'E_MIN_LENGTH', message: `长度不能少于 ${schema.minLength}（当前 ${value.length}）` })
    }
    if (typeof schema.maxLength === 'number' && value.length > schema.maxLength) {
      errors.push({ path, code: 'E_MAX_LENGTH', message: `长度不能超过 ${schema.maxLength}（当前 ${value.length}）` })
    }
    if (schema.pattern) {
      const re = schema.pattern instanceof RegExp ? schema.pattern : new RegExp(schema.pattern)
      if (!re.test(value)) errors.push({ path, code: 'E_PATTERN', message: `不匹配 ${re}` })
    }
  }

  if (typeof value === 'number') {
    if (typeof schema.minimum === 'number' && value < schema.minimum) {
      errors.push({ path, code: 'E_MINIMUM', message: `不能小于 ${schema.minimum}` })
    }
    if (typeof schema.maximum === 'number' && value > schema.maximum) {
      errors.push({ path, code: 'E_MAXIMUM', message: `不能大于 ${schema.maximum}` })
    }
    if (typeof schema.exclusiveMinimum === 'number' && value <= schema.exclusiveMinimum) {
      errors.push({ path, code: 'E_EXCLUSIVE_MINIMUM', message: `必须大于 ${schema.exclusiveMinimum}` })
    }
    if (typeof schema.exclusiveMaximum === 'number' && value >= schema.exclusiveMaximum) {
      errors.push({ path, code: 'E_EXCLUSIVE_MAXIMUM', message: `必须小于 ${schema.exclusiveMaximum}` })
    }
  }

  if (Array.isArray(value)) {
    if (typeof schema.minItems === 'number' && value.length < schema.minItems) {
      errors.push({ path, code: 'E_MIN_ITEMS', message: `至少 ${schema.minItems} 项` })
    }
    if (typeof schema.maxItems === 'number' && value.length > schema.maxItems) {
      errors.push({ path, code: 'E_MAX_ITEMS', message: `最多 ${schema.maxItems} 项` })
    }
    if (schema.items && typeof schema.items === 'object') {
      value.forEach((item, i) => walk(schema.items, item, `${path}[${i}]`, errors, depth + 1))
    }
  }

  if (value && typeof value === 'object' && !Array.isArray(value)) {
    const props = schema.properties || {}
    const required = Array.isArray(schema.required) ? schema.required : []
    for (const key of required) {
      if (!Object.prototype.hasOwnProperty.call(value, key)) {
        errors.push({ path: `${path}.${key}`, code: 'E_REQUIRED', message: '缺少必填参数（不猜测补全）' })
      }
    }
    for (const [key, sub] of Object.entries(props)) {
      if (Object.prototype.hasOwnProperty.call(value, key)) {
        walk(sub, value[key], `${path}.${key}`, errors, depth + 1)
      }
    }
    if (schema.additionalProperties === false) {
      for (const key of Object.keys(value)) {
        if (!Object.prototype.hasOwnProperty.call(props, key)) {
          errors.push({ path: `${path}.${key}`, code: 'E_UNKNOWN_ARG', message: '未声明的参数（additionalProperties=false）' })
        }
      }
    }
  }
}

/** 把错误列表压成一行人话（界面/日志用）。 */
export function formatErrors(errors = []) {
  return errors.map((e) => `${e.path}: ${e.message}`).join('；')
}

export default { validate, assertValid, formatErrors, SchemaError, COERCE }
