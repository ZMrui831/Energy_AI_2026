// packages/core/src/tools/py-runner.mjs
//
// 跨进程（Node → Python）输出编码约定的**唯一实现**（主管冷跑 432/433 的必修根因）。
//
// 问题：在 cp936 等控制台代码页下，Python stdout 默认跟随控制台编码而非 UTF-8；
// Node 侧以 encoding:'utf8' 读取 → 中文 mojibake（如 `Grid-Forming Control ���鿨`）。
// 修复：强制 UTF-8（PEP 540 UTF-8 模式 `-X utf8` + PYTHONUTF8=1 / PYTHONIOENCODING=utf-8）。
//
// 【P-R7 分层修订】实现原本在 tools\lib\run-python.mjs，但 core 层（工具实现）
// 需要调 Python 生成 docx/xlsx/pptx —— 让 core 反向依赖 tools\（开发脚本目录）
// 是分层倒挂。所以：**实现下沉到 core，tools\lib\run-python.mjs 改为再导出**，
// 对外 API 一字不变（tests\python-encoding.test.mjs 继续钉住同一份实现）。
//
// 代码约定：任何从 Node 调用 Python 的代码都必须走这里，禁止裸 spawnSync 传 python。

import { spawnSync } from 'node:child_process'

/** 强制 UTF-8 的环境变量（与 Node 的 encoding:'utf8' 严格对齐）。 */
export const FORCE_UTF8_ENV = Object.freeze({ PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' })

function buildEnv(extra) {
  return { ...process.env, ...FORCE_UTF8_ENV, ...(extra || {}) }
}

/** 运行一段 Python 源码串（等价于 `python -X utf8 -c <code> [args...]`）。 */
export function runPython(python, code, args = [], opts = {}) {
  const env = buildEnv(opts.env)
  return spawnSync(python, ['-X', 'utf8', '-c', code, ...args], { encoding: 'utf8', ...opts, env })
}

/** 运行一个 .py 文件（等价于 `python -X utf8 <file> [args...]`）。 */
export function runPythonFile(python, file, args = [], opts = {}) {
  const env = buildEnv(opts.env)
  return spawnSync(python, ['-X', 'utf8', file, ...args], { encoding: 'utf8', ...opts, env })
}

export default { runPython, runPythonFile, FORCE_UTF8_ENV }
