// packages/core/src/tools/permissions.mjs
//
// 工具权限矩阵（P-R7）。**纯函数、零 IO**——所有需要文件系统的判定（符号链接）
// 由调用方注入探测函数，于是"红线路径必须拒绝"这类用例可以在纯 node 下单测。
//
// 三档（tier）：
//   auto    直接执行，只留审计
//   confirm 先弹权限卡，用户批准才执行；未批准/超时一律不执行
//   deny    一律拒绝，连 confirm 都不给（拒绝也要审计，拒绝是可追责的动作）
//
// 判定顺序（先严后松，DENY 不可被任何东西覆盖）：
//   1. 工具未登记              -> deny（E_TOOL_UNKNOWN，未登记的工具默认不可用，fail-closed）
//   2. 工具 tier = deny        -> deny（E_TOOL_DENIED）
//   3. 目标落在拒绝根          -> deny（E_ROOT_DENIED，读也不行）
//   4. 目标落在红线            -> deny（E_REDLINE）
//   5. 目标不在任何授权根      -> deny（E_OUTSIDE_ROOTS）
//   6. 符号链接逃出授权根      -> deny（E_SYMLINK_ESCAPE，需调用方注入 lstat）
//   7. tier = auto             -> allow
//   8. tier = confirm 且本次会话已授权同类 -> allow（E_GRANTED，只跳过"问"，不跳过"审"）
//   9. tier = confirm 否则     -> confirm（待用户批准；超时 = 不执行）
//
// 关键不变量：**会话授权（grant）只能抹掉 confirm，永远不能抹掉 deny**。

// S36：数据根参与工具层授权根（仅 ORB_DATA_DIR 隔离时与 PROJECT_ROOT 不同；safefs 无反向依赖，无环）。
import { DATA_DIR, PROJECT_ROOT } from '../safefs.mjs'
import { join } from 'node:path'
import { homedir } from 'node:os'

/** 工具风险档位。 */
export const TIER = Object.freeze({ AUTO: 'auto', CONFIRM: 'confirm', DENY: 'deny' })

/** 判定结果。 */
export const DECISION = Object.freeze({ ALLOW: 'allow', CONFIRM: 'confirm', DENY: 'deny' })

export class PermissionError extends Error {
  constructor(code, message, extra = {}) {
    super(message)
    this.name = 'PermissionError'
    this.code = code
    Object.assign(this, extra)
  }
}

/**
 * 默认授权根（别名在 createPolicy 时用 paths 解析器展开）：
 *   project:            项目根，唯一长期可写根
 *   desktop:            系统登记的真实桌面（**不是** %USERPROFILE%\Desktop）
 *   D:\AI_Workspace\_out  交付物输出区
 */
export const DEFAULT_ALLOW_ROOTS = Object.freeze(['project:', 'desktop:', 'D:\\AI_Workspace\\_out'])

/**
 * 拒绝根：连读都不给（SAFETY.md §2 的硬红线 + 含凭据的位置）。
 * S67·1-B：用户主目录下的敏感位置改用 os.homedir() 动态生成（换机即生效，不再硬编码
 * C:\Users\54958）；系统级红线（Windows / Program Files）保留；原项目级黑名单
 * （dsh-orb 源码/台账、萌源）保留为附加项。
 * 不变式：路径缺失（如评委机器没有 .ssh）仍按前缀拒（fail-closed，绝不放行）。
 */
const HOME = homedir()
export const DEFAULT_DENY_ROOTS = Object.freeze([
  join(HOME, '.ssh'),
  join(HOME, '.claude'),
  join(HOME, '.dsh'),
  join(HOME, 'AppData'),
  'C:\\Windows',
  'C:\\Program Files',
  'C:\\Program Files (x86)',
  'C:\\ProgramData',
  // —— 以下为原硬编码项目级黑名单，保留为附加项（换机可能不存在，不影响前缀拒）——
  'D:\\AI_Workspace\\dsh-orb-cordis', // orb 源码，一字不改
  'D:\\dsh-orb-project', // orb 台账，只读
  'D:\\AI_Workspace\\island-desktop', // 萌源
])

/** 红线：即使落在授权根内也禁止工具层写入的具体文件。 */
export const DEFAULT_RED_LINES = Object.freeze([
  { pattern: /(^|\\)data\\secrets\.json$/i, why: '凭据文件，工具层禁止读写' },
  { pattern: /(^|\\)settings\.json$/i, why: '网关凭据来源，只读' },
  { pattern: /(^|\\)(\.git|node_modules)\\config$/i, why: '工具链配置，禁止改写' },
  { pattern: /(^|\\)desktop\.ini$/i, why: '系统外壳元数据，禁止改写' },
  { pattern: /(^|\\)thumbs\.db$/i, why: '系统缩略图缓存，禁止改写' },
])

/** 默认工具档位表。**未登记的工具一律按 confirm 处理（不自动放行）**。 */
export const DEFAULT_TOOL_TIERS = Object.freeze({
  // 读类：只读取，不改任何东西
  'fs.list': TIER.AUTO,
  'fs.stat': TIER.AUTO,
  'fs.search': TIER.AUTO,
  'fs.read': TIER.AUTO,
  'app.list': TIER.AUTO,
  'app.focus': TIER.AUTO,
  'clip.get': TIER.AUTO,
  'screen.capture': TIER.AUTO,
  'note.list': TIER.AUTO,
  'note.read': TIER.AUTO,
  'timer.status': TIER.AUTO,
  // S45·P1：只读子代理 spawn_researcher —— 只读、零落盘（唯一出口是一条审计行），
  // 内部自带能力白名单 + 读取预算 + 抽查作废。与 fs.read 同档。
  'researcher.spawn': TIER.AUTO,
  // 写类：一律要批准
  'fs.write': TIER.CONFIRM,
  'fs.mkdir': TIER.CONFIRM,
  'fs.move': TIER.CONFIRM,
  'fs.copy': TIER.CONFIRM,
  'fs.delete': TIER.CONFIRM,
  'doc.docx': TIER.CONFIRM,
  'doc.xlsx': TIER.CONFIRM,
  'doc.pptx': TIER.CONFIRM,
  'doc.md': TIER.CONFIRM,
  'shell.run': TIER.CONFIRM,
  'app.launch': TIER.CONFIRM,
  'clip.set': TIER.CONFIRM,
  'net.fetch': TIER.CONFIRM,
  'note.write': TIER.CONFIRM,
  'timer.start': TIER.CONFIRM,
  'timer.stop': TIER.CONFIRM,
})

/** 写类工具集合（用于"写操作必须先快照"与"必须读回校验"）。 */
export const WRITE_TOOLS = new Set([
  'fs.write', 'fs.mkdir', 'fs.move', 'fs.copy', 'fs.delete',
  'doc.docx', 'doc.xlsx', 'doc.pptx', 'doc.md',
  'shell.run', 'note.write',
])

/** 破坏性工具（删除/覆盖/移动）——执行前必须快照，且必须可 /undo。 */
export const DESTRUCTIVE_TOOLS = new Set(['fs.delete', 'fs.move', 'fs.write', 'doc.docx', 'doc.xlsx', 'doc.pptx', 'doc.md'])

// ---------------------------------------------------------------- 路径工具

/**
 * Windows 语义规范化：统一分隔符、去掉尾部反斜杠。
 * **UNC 与 \\?\ 前缀必须原样保留**——它们天生含连续反斜杠，一旦折叠成单斜杠，
 * `\\srv\share` 会退化成 `\srv\share`，UNC 检测随之失效（真事故，不是假想）。
 */
export function normalizePath(p) {
  const raw = String(p == null ? '' : p).replace(/\//g, '\\')
  const unc = /^\\\\(\?\\)?/.exec(raw)
  if (unc) {
    const head = unc[0]
    const rest = raw.slice(head.length).replace(/\\{2,}/g, '\\').replace(/\\+$/, '')
    return head + rest
  }
  const collapsed = raw.replace(/\\{2,}/g, '\\')
  // 盘符根（D:\）保留尾部反斜杠，否则 isUnder 会把 D:\x 判成不在 D: 之下
  if (/^[A-Za-z]:\\?$/.test(collapsed)) return collapsed.replace(/\\$/, '') + '\\'
  return collapsed.replace(/\\+$/, '')
}

/** candidate 是否等于或位于 root 之下（Windows 大小写不敏感）。 */
export function isUnder(candidate, root) {
  const C = normalizePath(candidate).toLowerCase()
  const R = normalizePath(root).toLowerCase().replace(/\\+$/, '')
  if (!R) return false
  if (C === R) return true
  return C.startsWith(R.endsWith('\\') ? R : R + '\\')
}

/** 在 roots 里找出第一个包住 abs 的根。 */
export function matchRoot(abs, roots = []) {
  for (const r of roots) if (isUnder(abs, r)) return r
  return null
}

// ---------------------------------------------------------------- 策略

/**
 * 展开策略里的别名根。
 * @param {string[]} roots
 * @param {{resolveInput?: Function}} [paths]
 */
export function expandRoots(roots, paths = null) {
  const out = []
  for (const r of roots) {
    if (typeof r !== 'string' || !r) continue
    // 别名前缀必须 ≥2 字符：单字符是盘符（D:\AI_Workspace\_out 不是别名）。
    if (/^[A-Za-z][A-Za-z0-9_-]+:/.test(r) && paths && typeof paths.resolveInput === 'function') {
      const got = paths.resolveInput(r)
      if (got && got.ok) {
        out.push(got.path)
        continue
      }
      // 别名解析失败（如桌面读不到）就跳过，绝不塞一个猜出来的根进来
      continue
    }
    out.push(normalizePath(r))
  }
  return out
}

/**
 * 装配运行时策略。
 * @param {{paths?: object, config?: object, roots?: string[], denyRoots?: string[], toolTiers?: object}} [options]
 */
export function createPolicy(options = {}) {
  const paths = options.paths || null
  const cfg = options.config && options.config.tools ? options.config.tools : {}
  const roots = expandRoots(cfg.allowRoots || options.roots || DEFAULT_ALLOW_ROOTS, paths)
  // S36：ORB_DATA_DIR 隔离时，数据根也是工具层授权根（演示/测试在隔离数据树内可用工具层）。
  // 仅当调用方未显式指定授权根时注入——显式配置（如 data\config.json tools 段）以调用方为准。
  if (!(cfg.allowRoots || options.roots)) {
    try {
      const dNorm = normalizePath(DATA_DIR)
      if (normalizePath(PROJECT_ROOT) !== dNorm && !roots.some((r) => normalizePath(r) === dNorm)) roots.push(dNorm)
    } catch { /* DATA_DIR 不可用时维持原授权根 */ }
  }
  const denyRoots = (cfg.denyRoots || options.denyRoots || DEFAULT_DENY_ROOTS).map((r) => normalizePath(r))
  const toolTiers = { ...DEFAULT_TOOL_TIERS, ...(cfg.tiers || options.toolTiers || {}) }
  const redLines = [...DEFAULT_RED_LINES, ...(cfg.redLines || [])]

  return {
    roots,
    denyRoots,
    toolTiers,
    redLines,
    /** 工具档位：未登记 -> confirm（fail-closed，绝不默认 auto）。 */
    tierOf(toolId) {
      if (typeof toolId !== 'string' || !toolId) return TIER.DENY
      // 前缀匹配：'note.' 之类未逐条登记的子命令按族默认处理
      if (toolTiers[toolId]) return toolTiers[toolId]
      return toolId.endsWith('.') ? TIER.CONFIRM : TIER.CONFIRM
    },
    isKnown(toolId) {
      return typeof toolId === 'string' && Object.prototype.hasOwnProperty.call(toolTiers, toolId)
    },
    describe() {
      return {
        roots,
        denyRoots,
        redLines: redLines.map((r) => String(r.pattern) + (r.why ? ' — ' + r.why : '')),
        tiers: { ...toolTiers },
      }
    },
  }
}

// ---------------------------------------------------------------- 会话授权

/**
 * "本次会话同类不再询问"的授权记录。
 * 只能抹掉 confirm，**不参与 deny 判定**。
 */
export function createGrantStore() {
  const grants = new Map() // toolId -> { at, scope }
  return {
    grant(toolId, scope = '*') {
      grants.set(String(toolId), { at: new Date().toISOString(), scope })
      return true
    },
    has(toolId) {
      return grants.has(String(toolId))
    },
    list() {
      return [...grants.entries()].map(([toolId, v]) => ({ toolId, ...v }))
    },
    clear() {
      grants.clear()
    },
  }
}

// ---------------------------------------------------------------- 判定

/**
 * 判定一次工具调用。
 * @param {{
 *   toolId: string,
 *   targets?: string[],          // 已解析的绝对路径
 *   write?: boolean,
 *   policy: object,
 *   grants?: object|null,
 *   lstat?: Function|null,       // 注入式符号链接探测 (p)=>{isSymbolicLink, realpath}|null
 * }} input
 * @returns {{decision:string, tier:string, code:string|null, reason:string, toolId:string, targets:string[], matchedRoot:string|null}}
 */
export function evaluate(input = {}) {
  const { toolId, targets = [], write = false, policy, grants = null, lstat = null } = input
  const abs = targets.filter((t) => typeof t === 'string' && t).map((t) => normalizePath(t))
  const base = { toolId: String(toolId || ''), targets: abs, matchedRoot: null, write: !!write }

  if (!toolId || typeof toolId !== 'string') {
    return { ...base, decision: DECISION.DENY, tier: TIER.DENY, code: 'E_TOOL_UNKNOWN', reason: '工具名为空' }
  }

  const tier = policy.tierOf(toolId)
  if (tier === TIER.DENY) {
    return { ...base, decision: DECISION.DENY, tier, code: 'E_TOOL_DENIED', reason: `工具 ${toolId} 已被策略禁用` }
  }

  for (const t of abs) {
    // 2.5) 纵深防御：正常链路里 .. 与 UNC 已在 paths 层被拒，这里再判一次。
    //      工具入口不止一条（插件、脚本、未来的 MCP），闸门必须自洽。
    if (t.split('\\').includes('..')) {
      return { ...base, decision: DECISION.DENY, tier, code: 'E_TRAVERSAL', reason: `${t} 含 .. 上行段，已拒绝` }
    }
    if (t.startsWith('\\\\') || t.startsWith('//')) {
      return { ...base, decision: DECISION.DENY, tier, code: 'E_UNC', reason: `${t} 是 UNC 网络路径，已拒绝` }
    }
    // 3) 拒绝根：读也不行
    const denied = matchRoot(t, policy.denyRoots)
    if (denied) {
      return { ...base, decision: DECISION.DENY, tier, code: 'E_ROOT_DENIED', reason: `${t} 落在拒绝根 ${denied}（读操作同样拒绝）` }
    }
    // 4) 红线
    for (const line of policy.redLines) {
      if (line.pattern && line.pattern.test && line.pattern.test(t)) {
        return { ...base, decision: DECISION.DENY, tier, code: 'E_REDLINE', reason: `${t} 命中红线：${line.why || '禁止改写'}` }
      }
    }
    // 5) 授权根
    const root = matchRoot(t, policy.roots)
    if (!root) {
      return { ...base, decision: DECISION.DENY, tier, code: 'E_OUTSIDE_ROOTS', reason: `${t} 不在任何授权根之内（授权根：${policy.roots.join(' / ')}）` }
    }
    // 6) 符号链接逃逸
    if (typeof lstat === 'function') {
      let info = null
      try {
        info = lstat(t)
      } catch {
        info = null
      }
      if (info && info.isSymbolicLink && info.realpath) {
        const rp = normalizePath(info.realpath)
        if (!matchRoot(rp, policy.roots) || matchRoot(rp, policy.denyRoots)) {
          return { ...base, decision: DECISION.DENY, tier, code: 'E_SYMLINK_ESCAPE', reason: `${t} 是符号链接，指向 ${rp}，已逃出授权根` }
        }
      }
    }
  }

  const firstRoot = abs.length > 0 ? matchRoot(abs[0], policy.roots) : null

  if (tier === TIER.AUTO) {
    return { ...base, decision: DECISION.ALLOW, tier, code: null, reason: '只读工具，授权根内自动执行', matchedRoot: firstRoot }
  }
  if (grants && grants.has(toolId)) {
    return { ...base, decision: DECISION.ALLOW, tier, code: 'E_GRANTED', reason: `本次会话已授权 ${toolId}（同类不再询问）`, matchedRoot: firstRoot }
  }
  return { ...base, decision: DECISION.CONFIRM, tier, code: null, reason: `工具 ${toolId} 需要用户批准`, matchedRoot: firstRoot }
}

/** 生成给用户看的权限卡文案（界面与日志共用同一口径）。 */
export function describeRequest({ toolId, args = {}, targets = [], decision }) {
  const what = TOOL_LABELS[toolId] || toolId
  const where = targets.length > 0 ? targets.join('、') : '（无文件路径）'
  return {
    title: `需要批准：${what}`,
    what,
    where,
    args,
    tier: decision ? decision.tier : null,
    code: decision ? decision.code : null,
  }
}

const TOOL_LABELS = {
  'fs.read': '读取文件',
  'fs.write': '写入文件',
  'fs.mkdir': '创建目录',
  'fs.move': '移动文件',
  'fs.copy': '复制文件',
  'fs.delete': '删除文件',
  'fs.list': '列目录',
  'fs.stat': '查看文件信息',
  'fs.search': '搜索文件',
  'doc.docx': '生成 Word 文档',
  'doc.xlsx': '生成表格',
  'doc.pptx': '生成演示文稿',
  'doc.md': '生成 Markdown',
  'shell.run': '运行命令',
  'app.launch': '打开应用',
  'app.focus': '切换窗口',
  'app.list': '列出窗口',
  'clip.get': '读取剪贴板',
  'clip.set': '写入剪贴板',
  'screen.capture': '截取屏幕',
  'net.fetch': '访问网络',
  'note.write': '写备忘',
  'note.read': '读备忘',
  'note.list': '列备忘',
  'timer.start': '开始计时',
  'timer.stop': '结束计时',
  'timer.status': '查看计时',
  'researcher.spawn': '派只读研究员',
}

export default {
  TIER, DECISION, PermissionError, DEFAULT_ALLOW_ROOTS, DEFAULT_DENY_ROOTS, DEFAULT_RED_LINES,
  DEFAULT_TOOL_TIERS, WRITE_TOOLS, DESTRUCTIVE_TOOLS, TOOL_LABELS,
  createPolicy, createGrantStore, evaluate, describeRequest, expandRoots, isUnder, matchRoot, normalizePath,
}
