// packages/core/src/tools/paths.mjs
//
// 路径解析层（P-R7 工具层的地基）。三条硬纪律：
//
//   1. **桌面路径必须解析、不得猜**。
//      本机事实：系统登记的桌面是 D:\Desktop，而 %USERPROFILE%\Desktop
//      （C:\Users\54958\Desktop）只是一个遗留空壳。主管曾因此把入口放到用户
//      看不见的目录，被当场指出。所以桌面一律读注册表
//      HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders 的
//      Desktop 值；读不到就 fail-closed（E_DESKTOP_UNRESOLVED），
//      **绝不回退到 %USERPROFILE%\Desktop 猜**。
//
//   2. **本文件零业务逻辑、零副作用**：注册表读取器由外部注入（默认实现才碰
//      PowerShell），于是"注册表值与 %USERPROFILE%\Desktop 不同"的用例可以在
//      纯 node 下单测（见 tests/tools-paths.test.mjs）。
//
//   3. **拒绝即拒绝**：UNC、空字节、Windows 非法字符、保留设备名、以及任何
//      `..` 段一律拒绝，不做规范化"洗白"——洗白过的路径在审计里看不出原貌，
//      属于安全反模式。

import { spawnSync } from 'node:child_process'
import { isAbsolute, resolve, sep, win32 } from 'node:path'
import { PROJECT_ROOT } from '../safefs.mjs'

// 全部走 win32 语义：本机是 Windows，且单测要能脱离运行平台稳定复现。
const pathIsAbsolute = (p) => win32.isAbsolute(String(p))
const pathResolve = (...parts) => win32.resolve(...parts)
const pathRelative = (from, to) => win32.relative(from, to)

/** 系统登记桌面的注册表位置（主管指定的唯一真相来源）。 */
export const SHELL_FOLDERS_KEY =
  'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders'
export const SHELL_FOLDERS_PS_PATH =
  'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Shell Folders'
export const DESKTOP_VALUE_NAME = 'Desktop'

/** 支持的别名（≥2 字符；单字符前缀是 Windows 盘符，不是别名）。 */
export const ALIASES = Object.freeze(['project', 'home', 'desktop'])

export class PathError extends Error {
  constructor(code, message, extra = {}) {
    super(message)
    this.name = 'PathError'
    this.code = code
    Object.assign(this, extra)
  }
}

const ILLEGAL_CHARS = /[<>:"|?*]/
const RESERVED_NAMES = new Set([
  'CON', 'PRN', 'AUX', 'NUL',
  ...Array.from({ length: 9 }, (_, i) => `COM${i + 1}`),
  ...Array.from({ length: 9 }, (_, i) => `LPT${i + 1}`),
])

/**
 * 真实实现：读系统登记的桌面目录。
 * 只读，不改注册表。PowerShell 输出强制 UTF-8（与 tools/lib/run-python.mjs 同一纪律）。
 * @returns {string|null} 失败返回 null（调用方必须 fail-closed，不得猜测）
 */
export function readShellFolderDesktop({ execSync = null } = {}) {
  const run = execSync || ((cmd, args) => spawnSync(cmd, args, { encoding: 'utf8' }))
  try {
    const res = run('powershell', [
      '-NoProfile',
      '-NonInteractive',
      '-Command',
      `[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; (Get-ItemProperty -Path '${SHELL_FOLDERS_PS_PATH}' -Name ${DESKTOP_VALUE_NAME}).${DESKTOP_VALUE_NAME}`,
    ])
    if (!res || res.status !== 0) return null
    const out = String(res.stdout || '').trim()
    if (!out) return null
    // 多行时只取第一行（属性输出理论上只有一行，多出来说明环境异常）
    const first = out.split(/\r?\n/)[0].trim()
    return first || null
  } catch {
    return null
  }
}

/** 判断一个前缀是不是"别名"（单字符 = 盘符，不算）。 */
export function splitAlias(input) {
  const m = /^([A-Za-z][A-Za-z0-9_-]*):(.*)$/.exec(input)
  if (!m) return { alias: null, rest: input }
  const [, head, rest] = m
  if (head.length === 1) return { alias: null, rest: input } // D:\... 盘符
  return { alias: head.toLowerCase(), rest }
}

function rejectIllegal(rest, input) {
  // Windows 盘符的冒号是合法的（D:\a b.docx），先摘掉再查非法字符；
  // 只认"盘符 + 分隔符/结尾"，避免把 `desktop:a:b` 里的冒号也洗白掉。
  const cleaned = String(rest).replace(/^[A-Za-z]:(?=[\\/]|$)/, '')
  if (ILLEGAL_CHARS.test(cleaned)) {
    throw new PathError('E_BAD_PATH', `路径含 Windows 非法字符 < > : " | ? * -> ${input}`, { input })
  }
  for (const seg of cleaned.split(/[\\/]/)) {
    if (!seg) continue
    const base = seg.replace(/\.[^.]+$/, '').toUpperCase()
    if (RESERVED_NAMES.has(base)) {
      throw new PathError('E_BAD_PATH', `路径含 Windows 保留设备名 ${seg} -> ${input}`, { input })
    }
  }
}

function rejectTraversal(rest, input) {
  if (rest.split(/[\\/]/).includes('..')) {
    throw new PathError('E_TRAVERSAL', `路径含 .. 上行段，已拒绝（不做规范化洗白） -> ${input}`, { input })
  }
}

const stripQuotes = (s) => {
  let out = s.trim()
  while (
    out.length >= 2 &&
    ((out.startsWith('"') && out.endsWith('"')) || (out.startsWith("'") && out.endsWith("'")))
  ) {
    out = out.slice(1, -1).trim()
  }
  return out
}

/**
 * 创建路径解析器。
 * @param {{
 *   root?: string,                       // 项目根（别名 project:），默认 safefs 的 PROJECT_ROOT
 *   home?: string,                       // 别名 home:，默认 env.USERPROFILE / env.HOME
 *   desktop?: string|null,               // 别名 desktop:；给 null 则调用 desktopReader
 *   desktopReader?: () => string|null,   // 注入式读取器（测试用，构造"与 USERPROFILE 不同"的用例）
 *   env?: object,
 * }} options
 */
export function createPathResolver(options = {}) {
  const env = options.env || process.env
  const root = pathResolve(options.root || PROJECT_ROOT)
  const home = pathResolve(options.home || env.USERPROFILE || env.HOME || root)
  const desktopReader = options.desktopReader || (options.desktop === undefined ? readShellFolderDesktop : null)
  let cachedDesktop = options.desktop === undefined ? null : options.desktop
  let desktopResolved = options.desktop !== undefined

  /** 惰性解析桌面：只在真的用到 desktop: 时才去读注册表。 */
  function desktop() {
    if (desktopResolved) return cachedDesktop
    desktopResolved = true
    try {
      cachedDesktop = desktopReader ? desktopReader() : null
    } catch {
      cachedDesktop = null
    }
    if (cachedDesktop) cachedDesktop = pathResolve(cachedDesktop)
    return cachedDesktop || null
  }

  /**
   * 解析一个路径输入。
   * @param {string} input
   * @returns {{ok:boolean, path?:string, alias?:string|null, base?:string, source?:string, code?:string, message?:string}}
   */
  function resolveInput(input) {
    if (typeof input !== 'string' || input.trim() === '') {
      return { ok: false, code: 'E_EMPTY', message: '路径必须是非空字符串' }
    }
    const raw = stripQuotes(input)
    if (raw === '') return { ok: false, code: 'E_EMPTY', message: '路径必须是非空字符串' }
    if (raw.includes('\0')) return { ok: false, code: 'E_BAD_PATH', message: '路径含空字节' }
    if (raw.startsWith('\\\\') || raw.startsWith('//')) {
      return { ok: false, code: 'E_UNC', message: '拒绝 UNC 路径（网络位置不可审计）-> ' + raw }
    }
    try {
      const { alias, rest } = splitAlias(raw)
      if (alias && !ALIASES.includes(alias)) {
        return { ok: false, code: 'E_UNKNOWN_ALIAS', message: `未知路径别名 ${alias}:（可用：${ALIASES.join(' / ')}）` }
      }
      rejectIllegal(alias ? rest : raw, raw)
      rejectTraversal(alias ? rest : raw, raw)

      let base = null
      let source = null
      let tail = alias ? rest : raw
      if (alias === 'project' || (!alias && !pathIsAbsolute(raw))) {
        base = root
        source = alias || 'relative-to-root'
        // 相对路径统一按"相对项目根"处理（工具 Schema 已写明，避免歧义）
        tail = alias ? rest : raw
      } else if (alias === 'home') {
        base = home
        source = 'home'
      } else if (alias === 'desktop') {
        const d = desktop()
        if (!d) {
          return {
            ok: false,
            code: 'E_DESKTOP_UNRESOLVED',
            message: `读不到系统登记的桌面目录（${SHELL_FOLDERS_KEY} 的 Desktop）；拒绝回退到 %USERPROFILE%\\Desktop 猜测，请改用绝对路径`,
          }
        }
        base = d
        source = 'desktop'
      } else {
        base = null
        source = 'absolute'
      }

      let abs
      if (base) {
        abs = tail === '' || tail === '.' ? base : pathResolve(base, tail)
        // 别名/相对基底下再兜一次底：解析结果必须仍在 base 之内
        const rel = pathRelative(base, abs)
        if (rel.startsWith('..') || pathIsAbsolute(rel)) {
          return { ok: false, code: 'E_TRAVERSAL', message: `解析结果逃出基底 ${base} -> ${abs}` }
        }
      } else {
        abs = pathResolve(raw)
      }
      return { ok: true, path: abs, alias: alias || null, base: base || null, source, raw }
    } catch (err) {
      if (err instanceof PathError) return { ok: false, code: err.code, message: err.message }
      return { ok: false, code: 'E_BAD_PATH', message: String((err && err.message) || err) }
    }
  }

  /** 严格版：失败直接抛 PathError（executor 内部用）。 */
  function requirePath(input) {
    const r = resolveInput(input)
    if (!r.ok) throw new PathError(r.code, r.message, { input })
    return r.path
  }

  return {
    root,
    home,
    desktop,
    resolveInput,
    requirePath,
    aliases: [...ALIASES],
    describe: () => ({
      root,
      home,
      desktop: desktop(),
      desktopSource: SHELL_FOLDERS_KEY + '\\' + DESKTOP_VALUE_NAME,
      aliases: [...ALIASES],
      note: '相对路径按"相对项目根"处理；desktop: 走系统登记的桌面，不做 %USERPROFILE% 猜测',
    }),
    sep,
  }
}

export default { createPathResolver, readShellFolderDesktop, splitAlias, ALIASES, PathError, SHELL_FOLDERS_KEY }
