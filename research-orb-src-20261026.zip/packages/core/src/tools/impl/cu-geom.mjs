// packages/core/src/tools/impl/cu-geom.mjs
//
// S45·P2 第 3 条：**坐标换算只做一次**，做成纯函数 + 单测。
//
// 为什么单独一个文件：
//   · backend 的坐标是 **0–1000 相对 bounds**（bounds 是逻辑像素的全局矩形，多屏时原点可为负，
//     本机实测 {x:280,y:89,width:1360,height:871}）；而 UIA 桥给的是**绝对像素**。二者要互转，
//     且必须只在一个地方转 —— 散在各自的调用点里，多屏一倾斜就成玄学；
//   · **禁止二次乘 DPI**：PerMonitorV2 + MOUSEEVENTF_VIRTUALDESK 已由 backend 内部处理，
//     这里只做线性插值，谁再乘一次 scale 谁负责；
//   · 纯函数、零 IO、零 import —— 单测可以直接打真机那块负原点屏的坐标。
//
// 语义约定（与 backend 的 requireNormalizedPosition 保持一致那条"0–1000"）：
//   · 越界一律返回 **null**，绝不做 clamp —— clamp 会把"点到屏外"粉饰成"点到边上"，
//     而这里是发真鼠标事件的入口，静默纠正就是替用户点错了地方。

/** bounds 合法性：{x,y,width,height} 全为有限数，且宽高为正。 */
export function validBounds(bounds) {
  const b = bounds && typeof bounds === 'object' ? bounds : null
  if (!b) return null
  const nums = ['x', 'y', 'width', 'height'].map((k) => (Number.isFinite(b[k]) ? b[k] : null))
  if (nums.some((v) => v === null)) return null
  const [x, y, width, height] = nums
  if (!(width > 0) || !(height > 0)) return null
  return { x, y, width, height }
}

/** 归一化 0–1000 → 绝对屏幕像素（可为浮点，多屏负原点由 bounds.x/y 自然吸收）。 */
export function toAbsolute(bounds, nx, ny) {
  const b = validBounds(bounds)
  if (!b) return null
  if (!Number.isFinite(nx) || !Number.isFinite(ny)) return null
  if (nx < 0 || nx > 1000 || ny < 0 || ny > 1000) return null
  return [b.x + (nx / 1000) * b.width, b.y + (ny / 1000) * b.height]
}

/** 绝对屏幕像素 → 归一化 0–1000；越界返回 null（不 clamp）。 */
export function toNormalized(bounds, absX, absY) {
  const b = validBounds(bounds)
  if (!b) return null
  if (!Number.isFinite(absX) || !Number.isFinite(absY)) return null
  const nx = ((absX - b.x) / b.width) * 1000
  const ny = ((absY - b.y) / b.height) * 1000
  if (nx < 0 || nx > 1000 || ny < 0 || ny > 1000) return null
  return [nx, ny]
}

/** 矩形中心（UIA 给的 control rect → 可以直接点的一个点）。 */
export function centerOf(rect) {
  const r = rect && typeof rect === 'object' ? rect : null
  if (!r) return null
  const vals = ['x', 'y', 'width', 'height'].map((k) => (Number.isFinite(r[k]) ? r[k] : null))
  if (vals.some((v) => v === null)) return null
  const [x, y, width, height] = vals
  if (!(width >= 0) || !(height >= 0)) return null
  return [x + width / 2, y + height / 2]
}

/**
 * 这个绝对像素点在哪块屏？（多屏拼接时用）
 * @returns {{index:number, screen:object, normalized:number[]}|null}
 */
export function screenAt(screens, absX, absY) {
  const list = Array.isArray(screens) ? screens : []
  for (let i = 0; i < list.length; i += 1) {
    const s = list[i]
    const b = validBounds(s && s.bounds)
    if (!b) continue
    const n = toNormalized(b, absX, absY)
    if (n) return { index: typeof s.index === 'number' ? s.index : i, screen: s, normalized: n }
  }
  return null
}

/** 逆运算自检用：两边误差超过容差就是换算写歪了。 */
export function roundTripError(bounds, absX, absY, tolerance = 1e-6) {
  const n = toNormalized(bounds, absX, absY)
  if (!n) return null
  const back = toAbsolute(bounds, n[0], n[1])
  if (!back) return null
  const err = Math.max(Math.abs(back[0] - absX), Math.abs(back[1] - absY))
  return { ok: err <= tolerance, err, back }
}

export default { validBounds, toAbsolute, toNormalized, centerOf, screenAt, roundTripError }
