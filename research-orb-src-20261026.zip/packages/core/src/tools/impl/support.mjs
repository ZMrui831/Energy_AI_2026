// packages/core/src/tools/impl/support.mjs
//
// 工具实现的公共小工具（P-R7）。
// 纪律：
//   · **不 import electron**：core 层永远要能在纯 node 下被单测与 selftest 复用；
//     Electron 专有能力（窗口枚举/焦点/剪贴板/抓屏）由宿主注入 ctx.host.*，
//     没注入就走"诚实降级"，绝不假装成功。
//   · 输出一律截断（大小/条数），模型看到的是摘要而不是整块磁盘。

import { basename, dirname, extname, join } from 'node:path'
import { createRequire } from 'node:module'
import { PROJECT_ROOT } from '../../safefs.mjs'
import { runPython, runPythonFile } from '../py-runner.mjs'

const require_ = createRequire(import.meta.url)

/** 项目内受管 venv 的 python（唯一允许用的 python；禁止全局 pip）。 */
export const VENV_PYTHON = join(PROJECT_ROOT, '.venv', 'Scripts', 'python.exe')

export const LIMITS = Object.freeze({
  READ_BYTES: 200 * 1024, // fs.read 上限
  LIST_ENTRIES: 200, // fs.list 上限
  SEARCH_HITS: 100, // fs.search 上限
  SHELL_OUTPUT: 100 * 1024, // shell.run 输出上限（硬要求：100KB）
  TOOL_RESULT_CHARS: 8000, // 回给模型的工具结果字符上限
})

/** 截断文本并标注（不静默截断）。S29：横幅统一为 Found {shown} of {total}（lean-policy output.truncationBanner 口径，
 *  requireReportTotal=true——必须报真实总数 Y，不许把上限 X 当总数）。 */
export function truncate(text, max, unit = '字符') {
  const s = String(text == null ? '' : text)
  if (s.length <= max) return { text: s, truncated: false }
  return { text: s.slice(0, max) + `\nFound ${max} of ${s.length} ${unit}（已截断；总数为 ${s.length}，不得只依据已显示部分作答）`, truncated: true }
}

export function sha256Hex(data) {
  const { createHash } = require_('node:crypto')
  return createHash('sha256').update(data).digest('hex')
}

/**
 * 解析目标路径（走 paths 解析器，别名/桌面/穿越都在这里定型）。
 * @throws {Error} code = E_BAD_PATH / E_TRAVERSAL / ...
 */
export function resolvePath(ctx, raw, what = 'path') {
  const r = ctx.paths.resolveInput(raw)
  if (!r.ok) {
    const err = new Error(`[${what}] ${r.message}`)
    err.code = r.code
    throw err
  }
  return r.path
}

/** 统一的工具结果包装：给模型的结果必须带"你看到的是摘要"这种实话。 */
export function packedResult(obj) {
  const s = JSON.stringify(obj)
  const t = truncate(s, LIMITS.TOOL_RESULT_CHARS)
  return { ...obj, ...(t.truncated ? { _truncated: true, _note: '结果过长已截断，可缩小范围重试' } : {}) }
}

export function fileStat(fs, p) {
  try {
    const st = fs.statSync(p)
    return {
      path: p,
      name: basename(p),
      exists: true,
      isDirectory: st.isDirectory(),
      isFile: st.isFile(),
      size: st.size,
      mtime: st.mtime ? new Date(st.mtime).toISOString() : null,
    }
  } catch {
    return { path: p, name: basename(p), exists: false }
  }
}

/** 递归列目录（带条数上限与深度上限）。 */
export function walkDir(fs, rootPath, { max = LIMITS.LIST_ENTRIES, depth = 2, current = 0 } = {}) {
  const out = []
  if (current > depth) return out
  let names = []
  try {
    names = fs.readdirSync(rootPath, { withFileTypes: true })
  } catch {
    return out
  }
  for (const d of names) {
    if (out.length >= max) break
    const full = join(rootPath, d.name)
    out.push({ name: d.name, path: full, dir: d.isDirectory() })
    if (d.isDirectory() && current < depth) {
      for (const sub of walkDir(fs, full, { max: max - out.length, depth, current: current + 1 })) out.push(sub)
    }
  }
  return out.slice(0, max)
}

/** 简易通配匹配（只支持 * 与 ?，够用且可预测）。 */
export function globToRegExp(pattern) {
  let re = ''
  for (const ch of String(pattern || '*')) {
    if (ch === '*') re += '[^\\\\/]*'
    else if (ch === '?') re += '[^\\\\/]'
    else re += ch.replace(/[.+^${}()|[\]\\]/g, '\\$&')
  }
  return new RegExp('^' + re + '$', 'i')
}

/** 内容里是否像文本（决定 fs.read 能不能直接给字符串）。 */
export function looksText(buf) {
  const probe = buf.slice(0, 4096)
  let weird = 0
  for (const b of probe) {
    if (b === 0) return false
    if (b < 9 || (b > 13 && b < 32)) weird += 1
  }
  return weird / Math.max(1, probe.length) < 0.02
}

/**
 * 跑 python：一律走 tools/lib/run-python.mjs（UTF-8 纪律），禁止裸 spawnSync。
 * @returns {{ok:boolean, stdout:string, stderr:string, status:number|null}}
 */
export function python(pythonPath, code, args = [], opts = {}) {
  const r = runPython(pythonPath || VENV_PYTHON, code, args, opts)
  return {
    ok: r.status === 0,
    status: r.status,
    stdout: String(r.stdout || ''),
    stderr: String(r.stderr || ''),
  }
}

export function pythonFile(pythonPath, file, args = [], opts = {}) {
  const r = runPythonFile(pythonPath || VENV_PYTHON, file, args, opts)
  return {
    ok: r.status === 0,
    status: r.status,
    stdout: String(r.stdout || ''),
    stderr: String(r.stderr || ''),
  }
}

/** 检查 venv 里的某个包是否可用（决定"真实现"还是"降级"）。 */
export function hasPythonPackage(pythonPath, moduleName) {
  const r = python(pythonPath, `import ${moduleName}; print(getattr(${moduleName}, "__version__", "ok"))`)
  return r.ok ? { ok: true, version: r.stdout.trim() } : { ok: false, version: null, stderr: r.stderr.slice(0, 200) }
}

/** 宿主能力未注入时的诚实降级文案（绝不假装成功）。 */
export function unsupported(what, why) {
  const err = new Error(`${what}：当前环境不支持（${why}）。这不是失败，是能力边界；请换一种方式完成任务。`)
  err.code = 'E_UNSUPPORTED'
  return err
}

export { basename, dirname, extname, join, runPython, runPythonFile }
