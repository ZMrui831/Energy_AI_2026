// packages/core/src/tools/impl/clip.mjs
//
// 剪贴板工具（P-R7）：clip.get / clip.set
//
// 优先用宿主注入的能力（Electron 的 clipboard 模块，同步且无子进程）；
// 宿主没注入时退回 PowerShell（Get-Clipboard / Set-Clipboard），
// 输出编码一律按 UTF-8 约定处理（与 tools/lib/run-python.mjs 同一纪律）。
//
// 隐私边界：**读剪贴板 = 读用户刚复制的任何东西**（密码、令牌都有可能），
// 所以 clip.get 的档位是 auto 但每次都审计；clip.set 是 confirm。

import { createRequire } from 'node:module'
import { defineTool } from '../registry.mjs'
import { truncate } from './support.mjs'

const require_ = createRequire(import.meta.url)

const defaultChild = () => require_('node:child_process')

/** 读剪贴板默认上限：剪贴板内容可能很长，不能整块喂给模型。 */
export const CLIP_READ_LIMIT = 8000

/**
 * @param {object} registry
 * @param {{child?: object, host?: object}} [deps]
 */
export function registerClipTools(registry, deps = {}) {
  const child = deps.child || defaultChild()
  const host = deps.host || null

  function read() {
    if (host && host.clipboard && typeof host.clipboard.read === 'function') {
      const v = host.clipboard.read()
      return { text: String(v == null ? '' : v), source: 'host' }
    }
    const r = child.spawnSync(
      'powershell',
      ['-NoProfile', '-NonInteractive', '-STA', '-Command', '[Console]::OutputEncoding=[System.Text.Encoding]::UTF8; Get-Clipboard -Raw'],
      { encoding: 'utf8', windowsHide: true },
    )
    if (r.status !== 0) {
      const err = new Error(`读取剪贴板失败（PowerShell exit=${r.status}）：${String(r.stderr || '').slice(0, 200)}`)
      err.code = 'E_CLIP_READ'
      throw err
    }
    return { text: String(r.stdout || ''), source: 'powershell' }
  }

  function write(text) {
    if (host && host.clipboard && typeof host.clipboard.write === 'function') {
      host.clipboard.write(text)
      return { source: 'host' }
    }
    // 用 -Command 传值会有引号与注入问题，改用 stdin 喂给 $input 最稳
    const r = child.spawnSync(
      'powershell',
      ['-NoProfile', '-NonInteractive', '-STA', '-Command', '$t = [Console]::In.ReadToEnd(); Set-Clipboard -Value $t'],
      { encoding: 'utf8', input: text, windowsHide: true },
    )
    if (r.status !== 0) {
      const err = new Error(`写入剪贴板失败（PowerShell exit=${r.status}）：${String(r.stderr || '').slice(0, 200)}`)
      err.code = 'E_CLIP_WRITE'
      throw err
    }
    return { source: 'powershell' }
  }

  registry.register(
    defineTool({
      id: 'clip.get',
      label: '读取剪贴板',
      description: '读取剪贴板文本（最多回显 8000 字符；剪贴板可能含密码/令牌，只取需要的部分）。',
      params: { type: 'object', properties: {}, additionalProperties: false },
      targetsOf: () => [],
      run() {
        const got = read()
        const t = truncate(got.text, CLIP_READ_LIMIT)
        return { chars: got.text.length, text: t.text, truncated: t.truncated, source: got.source }
      },
    }),
  )

  registry.register(
    defineTool({
      id: 'clip.set',
      label: '写入剪贴板',
      description: '把一段文本写入剪贴板（会覆盖当前剪贴板内容）。',
      params: {
        type: 'object',
        properties: { text: { type: 'string', minLength: 1, maxLength: 200000, description: '要写入的文本' } },
        required: ['text'],
        additionalProperties: false,
      },
      targetsOf: () => [],
      run(args) {
        const text = String(args.text)
        const r = write(text)
        return { ok: true, chars: text.length, source: r.source }
      },
    }),
  )

  return registry
}

export default { registerClipTools, CLIP_READ_LIMIT }
