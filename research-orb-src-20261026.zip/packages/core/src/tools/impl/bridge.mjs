// packages/core/src/tools/impl/bridge.mjs
//
// 桥接工具（P-R7）：把**已经存在的内核能力**登记成工具，不重写一遍。
//
//   net.fetch        —— 经 core/net.mjs（域名白名单 + 令牌桶 + net.jsonl 审计）
//   screen.capture   —— 经宿主 screen 桥（P-R6.2 的 desktopCapturer，落在 data\shots\）
//   note.*           —— 项目根内的 Markdown 备忘（data\notes\），不依赖任何形态插件
//   timer.*          —— 经 core/timer.mjs 引擎（与面板/插件同一本账）
//
// 纪律：**宿主没注入就诚实降级**。宁可回答"做不到"，也不伪造一次成功的抓屏或计时。

import { basename, join } from 'node:path'
import { createRequire } from 'node:module'
import { defineTool } from '../registry.mjs'
import { LIMITS, packedResult, resolvePath, sha256Hex, truncate, walkDir } from './support.mjs'
import { PROJECT_ROOT, safeWrite, dataPath } from '../../safefs.mjs'
import { capOf } from '../../modes.mjs'

const require_ = createRequire(import.meta.url)

const defaultFs = () => require_('node:fs')

export const NOTES_DIR = dataPath('notes')

/**
 * @param {object} registry
 * @param {{host?: object, fs?: object}} [deps]
 */
export function registerBridgeTools(registry, deps = {}) {
  const host = deps.host || {}
  const fs = deps.fs || defaultFs()

  // ---------------------------------------------------------------- 网络

  registry.register(
    defineTool({
      id: 'net.fetch',
      label: '访问网络',
      description:
        '抓取一个网页/接口内容。**只走域名白名单**（授权数据源 / 学校网关等），' +
        '白名单外一律拒绝；出网全部落 net.jsonl 审计。',
      params: {
        type: 'object',
        properties: {
          url: { type: 'string', minLength: 8, description: '完整 URL，必须以 http(s):// 开头' },
          maxBytes: { type: 'integer', minimum: 1024, maximum: 1048576, description: '最多取多少字节，默认 200KB' },
        },
        required: ['url'],
        additionalProperties: false,
      },
      targetsOf: () => [],
      timeoutMs: 30000,
      async run(args) {
        if (!host.net || typeof host.net.request !== 'function') {
          throw Object.assign(new Error('net.fetch：宿主未注入网络能力，当前不可用'), { code: 'E_UNSUPPORTED' })
        }
        const url = String(args.url)
        if (!/^https?:\/\//i.test(url)) throw Object.assign(new Error('URL 必须以 http(s):// 开头'), { code: 'E_BAD_URL' })
        // S22：网页抓取封顶从模式读取（webFetchMaxChars），缺省回落 200KB
        const maxBytes = Number.isFinite(args.maxBytes) ? args.maxBytes : capOf('webFetchMaxChars')
        const res = await host.net.request(url, { method: 'GET', limitKey: 'tool:net.fetch' })
        if (!res || !res.ok) {
          throw Object.assign(new Error(`请求失败：HTTP ${res ? res.status : '?'}`), { code: 'E_HTTP_STATUS' })
        }
        const raw = await res.text()
        const t = truncate(raw, maxBytes, '字节')
        return { url, ok: true, bytes: raw.length, truncated: t.truncated, text: t.text }
      },
    }),
  )

  // ---------------------------------------------------------------- 屏幕

  registry.register(
    defineTool({
      id: 'screen.capture',
      label: '截取屏幕',
      description:
        '截取当前屏幕并落到项目内 data\\shots\\。注意：**本应用不接多模态模型，无法"看懂"截图内容**，' +
        '只能告诉你截图存到哪、多大；识图需要你自己看。',
      params: { type: 'object', properties: {}, additionalProperties: false },
      targetsOf: () => [],
      timeoutMs: 20000,
      async run() {
        if (!host.screen || typeof host.screen.captureScreen !== 'function') {
          throw Object.assign(new Error('screen.capture：宿主未注入抓屏能力，当前不可用'), { code: 'E_UNSUPPORTED' })
        }
        const got = await host.screen.captureScreen()
        return {
          ok: !!got && got.ok,
          path: got ? got.pngPath : null,
          bytes: got ? got.bytes : 0,
          hash: got ? got.hash : null,
          width: got ? got.width : null,
          height: got ? got.height : null,
          note: '截图只落在本机 data\\shots\\，不上传；本应用无法解读图像内容。',
        }
      },
    }),
  )

  // ---------------------------------------------------------------- 备忘

  registry.register(
    defineTool({
      id: 'note.write',
      label: '写备忘',
      description: '追加一条备忘到项目内 data\\notes\\（按日期分文件，Markdown，追加不覆盖）。',
      params: {
        type: 'object',
        properties: {
          text: { type: 'string', minLength: 1, description: '备忘正文' },
          title: { type: 'string', description: '小标题（可选）' },
          tags: { type: 'array', items: { type: 'string' }, description: '标签（可选）' },
        },
        required: ['text'],
        additionalProperties: false,
      },
      targetsOf: () => [NOTES_DIR],
      write: true,
      timeoutMs: 15000,
      run(args, ctx) {
        if (host.notes && typeof host.notes.write === 'function') {
          const r = host.notes.write(args)
          return { ...r, source: 'host' }
        }
        const day = new Date().toISOString().slice(0, 10)
        const file = join(NOTES_DIR, `notes-${day}.md`)
        const time = new Date().toISOString().slice(11, 19)
        const tags = (args.tags || []).map((t) => `\`${t}\``).join(' ')
        const lines = [`## ${time} ${args.title || ''}`.trim(), '', String(args.text)]
        if (tags) lines.push('', tags)
        lines.push('')
        const block = lines.join('\n')
        const prev = fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : `# ${day} 备忘\n\n`
        const next = prev + block
        safeWrite(file, next)
        return { path: file, appended: block.length, source: 'project-notes' }
      },
    }),
  )

  registry.register(
    defineTool({
      id: 'note.list',
      label: '列备忘',
      description: '列出项目内 data\\notes\\ 下的备忘文件。',
      params: { type: 'object', properties: {}, additionalProperties: false },
      targetsOf: () => [NOTES_DIR],
      run() {
        if (host.notes && typeof host.notes.list === 'function') return { ...host.notes.list(), source: 'host' }
        const files = walkDir(fs, NOTES_DIR, { max: 200, depth: 1 }).filter((e) => !e.dir)
        return packedResult({ dir: NOTES_DIR, count: files.length, files, source: 'project-notes' })
      },
    }),
  )

  registry.register(
    defineTool({
      id: 'note.read',
      label: '读备忘',
      description: '读取一个备忘文件的全部内容。',
      params: {
        type: 'object',
        properties: { name: { type: 'string', description: '文件名，如 notes-2026-10-17.md' } },
        required: ['name'],
        additionalProperties: false,
      },
      targetsOf: (a) => [join(NOTES_DIR, String(a.name || 'x'))],
      run(args) {
        if (host.notes && typeof host.notes.read === 'function') return { ...host.notes.read(args.name), source: 'host' }
        const name = basename(String(args.name || ''))
        const file = join(NOTES_DIR, name)
        if (!fs.existsSync(file)) throw Object.assign(new Error(`备忘不存在：${file}`), { code: 'E_NOT_FOUND' })
        const t = truncate(fs.readFileSync(file, 'utf8'), LIMITS.READ_BYTES, '字节')
        return { path: file, name, truncated: t.truncated, text: t.text, source: 'project-notes' }
      },
    }),
  )

  // ---------------------------------------------------------------- 计时

  registry.register(
    defineTool({
      id: 'timer.start',
      label: '开始计时',
      description: '开始一段专注计时（走内核 timer 引擎，与面板/插件同一本账）。',
      params: {
        type: 'object',
        properties: {
          minutes: { type: 'integer', minimum: 1, maximum: 240, description: '时长（分钟），默认 25' },
          label: { type: 'string', description: '这段时间在做什么（可选）' },
        },
        additionalProperties: false,
      },
      targetsOf: () => [],
      write: true,
      run(args) {
        if (!host.timer || typeof host.timer.start !== 'function') {
          throw Object.assign(new Error('timer.start：宿主未注入计时引擎，当前不可用'), { code: 'E_UNSUPPORTED' })
        }
        const r = host.timer.start({ minutes: args.minutes || 25, label: args.label || null })
        return { started: true, ...(r || {}) }
      },
    }),
  )

  registry.register(
    defineTool({
      id: 'timer.stop',
      label: '结束计时',
      description: '结束当前计时。',
      params: { type: 'object', properties: {}, additionalProperties: false },
      targetsOf: () => [],
      write: true,
      run() {
        if (!host.timer || typeof host.timer.stop !== 'function') {
          throw Object.assign(new Error('timer.stop：宿主未注入计时引擎，当前不可用'), { code: 'E_UNSUPPORTED' })
        }
        const r = host.timer.stop({ reason: 'tool' })
        return { stopped: true, ...(r || {}) }
      },
    }),
  )

  registry.register(
    defineTool({
      id: 'timer.status',
      label: '查看计时',
      description: '查看当前计时状态与剩余时间。',
      params: { type: 'object', properties: {}, additionalProperties: false },
      targetsOf: () => [],
      run() {
        if (!host.timer || typeof host.timer.status !== 'function') {
          throw Object.assign(new Error('timer.status：宿主未注入计时引擎，当前不可用'), { code: 'E_UNSUPPORTED' })
        }
        return host.timer.status()
      },
    }),
  )

  return registry
}

export default { registerBridgeTools, NOTES_DIR }
