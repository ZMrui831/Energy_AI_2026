// packages/core/src/tools/impl/shell.mjs
//
// 命令工具（P-R7）：shell.run
//
// 这是整套工具里**风险最高**的一个，所以闸门最多：
//   ① 可执行白名单：只认命令首词的 basename；不在名单里直接拒绝（E_CMD_NOT_ALLOWED）
//   ② 硬禁令清单：关机的、改注册表的、建计划任务的、下载执行的、批量杀进程的……
//      命中即拒（E_CMD_BANNED），**不接受"用户让我这么干"作为理由**
//   ③ 工作目录必须在授权根内（cwd 默认项目根）
//   ④ 命令里出现的任何绝对路径都要落在授权根内（防止"白名单命令 + 越界路径"）
//   ⑤ 30 秒超时，超时按 **PID 树** 杀（taskkill /PID <pid> /T /F，SAFETY.md §8 允许的唯一方式）
//   ⑥ 输出 100KB 硬上限，超出截断并如实标注
//
// 关于 taskkill 的非对称（写在这里，避免后来者"顺手放宽"）：
//   **模型不得调用 taskkill**（进硬禁令），但**我们清理自己拉起的进程时可以用
//   taskkill /PID /T /F** —— SAFETY.md §8 明确允许按 PID 树杀，禁止的是按进程名
//   `taskkill /IM` 批量杀（会误伤用户的浏览器）。这二者不矛盾。

import { dirname, join } from 'node:path'
import { createRequire } from 'node:module'
import { defineTool } from '../registry.mjs'
import { LIMITS, resolvePath, truncate } from './support.mjs'
import { PROJECT_ROOT } from '../../safefs.mjs'

const require_ = createRequire(import.meta.url)

const defaultChild = () => require_('node:child_process')

/**
 * S74c·P1-6：把 cmd.exe 的原始输出字节安全解码为字符串。
 * 先严格 UTF-8 解（无替换符才算成功）——git 等外部程序的 UTF-8 输出原样保留；
 * 失败则判为系统 OEM 码页（中文机 GBK/936），用内置 TextDecoder('gbk') 解。
 * 若运行环境是无 gbk 的小 ICU，则退回宽松 utf8（不抛，尽量可用）。
 * @param {Buffer} buf
 * @returns {string}
 */
export function decodeCommandOutput(buf) {
  if (!buf || buf.length === 0) return ''
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(buf)
  } catch {
    try {
      return new TextDecoder('gbk').decode(buf)
    } catch {
      return buf.toString('utf8')
    }
  }
}

/** 默认允许的命令（只读/检索类；不含任何能改系统状态或执行脚本的解释器）。 */
export const ALLOWED_COMMANDS = Object.freeze([
  'dir', 'type', 'echo', 'findstr', 'where', 'fc', 'git',
])

/**
 * 需要显式开启才可用的命令（解释器 = 事实上能执行任意代码）。
 * 开启方式：data\config.json -> tools.shell.extraAllow: ["node","python"]
 * 默认关闭；关着的时候调用会如实报 E_CMD_NOT_ALLOWED，而不是"帮你试试"。
 */
export const EXTRA_COMMANDS = Object.freeze(['node', 'npm', 'python', 'py'])

/**
 * 硬禁令（对整条命令做正则，大小写不敏感）。
 * 每条都对应一个真实事故类型，不要删条目。
 */
export const BANNED_PATTERNS = Object.freeze([
  { re: /\bshutdown\b/i, why: '关机/重启（SAFETY.md §3）' },
  { re: /\blogoff\b/i, why: '注销（SAFETY.md §3）' },
  { re: /\brestart(-computer)?\b/i, why: '重启' },
  { re: /\bstop-computer\b/i, why: '关机' },
  { re: /\btaskkill\b/i, why: '杀进程一律拒绝（含 /IM 批量杀；清理由本应用自己按 PID 树做）' },
  { re: /\bstop-process\b/i, why: '杀进程' },
  { re: /\bformat(\.com)?\b/i, why: '格式化' },
  { re: /\bdiskpart\b/i, why: '磁盘分区' },
  { re: /\breg\b\s+(add|delete|import|copy|save|restore|unload|load)\b/i, why: '改注册表' },
  { re: /\bregsvr32\b/i, why: '注册/反注册 DLL' },
  { re: /\bschtasks\b/i, why: '计划任务（SAFETY.md §3）' },
  { re: /\bnew-scheduledtask\b|\bregister-scheduledtask\b/i, why: '计划任务' },
  { re: /\bnetsh\b/i, why: '改网络策略' },
  { re: /\bnet\b\s+(user|localgroup|accounts|share|stop|start)\b/i, why: '改账户/服务' },
  { re: /\bsc\b\s+(create|delete|config|stop|start)\b/i, why: '改系统服务' },
  { re: /\bwmic\b[\s\S]*\bdelete\b/i, why: 'WMI 删除' },
  { re: /\brm\b[^\n]*\s-rf?\b/i, why: 'rm -rf' },
  { re: /\bremove-item\b[\s\S]*(-recurse|-r)\b/i, why: 'PowerShell 递归删除' },
  { re: /\bdel\b[^\n]*\s\/(f|s|q)\b/i, why: 'del /f /s /q 批量删除' },
  { re: /\b(curl|wget)\b[\s\S]*\|\s*(bash|sh|cmd|powershell|iex)\b/i, why: '下载后直接执行' },
  { re: /\b(iwr|invoke-webrequest|invoke-restmethod|start-bitstransfer)\b/i, why: '下载执行' },
  { re: /\biex\b|\binvoke-expression\b/i, why: '执行字符串（本应用禁止远程下载执行）' },
  { re: /\bdownloadstring\b|\bdownloadfile\b/i, why: '下载执行' },
  { re: /-encodedcommand\b/i, why: 'PowerShell 编码命令（规避审计）' },
  { re: /\bcertutil\b[^\n]*(-decode|-urlcache|-split)\b/i, why: 'certutil 落地/解码' },
  { re: /\bbitsadmin\b/i, why: '后台下载' },
  { re: /\bset-executionpolicy\b/i, why: '改执行策略' },
  { re: /\b(echo|type)\b[\s\S]*>\s*[a-z]:\\(windows|program)/i, why: '往系统目录写文件' },
  { re: /\bmklink\b/i, why: '建符号链接（会绕开路径边界）' },
  { re: /\battrib\b[^\n]*\s\+[shr]\b/i, why: '改文件属性（隐藏/系统/只读）' },
  { re: /\btakeown\b|\bicacls\b|\bcacls\b/i, why: '改所有权/ACL' },
  { re: /\bsetx\b|\bset\b\s+path=/i, why: '改环境变量（SAFETY.md §3）' },
  { re: /\bpowershell\b[^\n]*-command\b[\s\S]*\b(remove-item|stop-process|new-itemproperty)\b/i, why: 'PowerShell 危险子命令' },
])

/**
 * 高危 shell 元字符（cmd.exe 会解释为命令拼接/重定向/子shell/变量）：整体拒绝，不逐项放行。
 * 否则 `echo hi & del important.txt` 首词 echo 在白名单，cmd 仍会执行 `del`（S67·1-A 最高优先）。
 */
const SHELL_METACHAR_RE = /[&|;<>()\`$]/
export function hasShellMetachar(command) {
  const s = String(command || '')
  if (/[\r\n]/.test(s)) {
    return { ok: false, code: 'E_SHELL_METACHAR', reason: '命令含换行符（禁止跨行拼接执行）' }
  }
  if (SHELL_METACHAR_RE.test(s)) {
    return {
      ok: false,
      code: 'E_SHELL_METACHAR',
      reason: '命令含 shell 元字符（& | ; < > ( ) ` $），cmd.exe 会解释为命令拼接/重定向/子shell，一律拒绝',
    }
  }
  return null
}

/**
 * 明文禁用首词（无参数也拒）：删除/格式化/磁盘分区/改所有权/ACL。
 * 与 BANNED_PATTERNS 互补——后者按正则（可能要求带参数），这里按"命令首词"兜底，
 * 确保 `del foo` / `rd build` / `rmdir x` 这类裸危险命令被拦（不依赖参数）。
 */
export const BANNED_FIRST_TOKENS = Object.freeze(new Set(['del', 'rd', 'rmdir', 'format', 'diskpart', 'takeown', 'icacls']))

/** git 仅放行这些只读子命令（含 branch --list）；其余（push/clean/reset/rebase/commit/clone/checkout…）一律拒。 */
export const GIT_ALLOWED_SUBS = Object.freeze(['status', 'diff', 'log', 'show', 'rev-parse'])
export function isGitAllowed(command) {
  const token = firstToken(command)
  if (token !== 'git') return null
  const parts = String(command).trim().split(/\s+/)
  const sub = (parts[1] || '').toLowerCase()
  if (GIT_ALLOWED_SUBS.includes(sub)) return true
  if (sub === 'branch' && /\-\-list\b/.test(command)) return true
  return false
}

/**
 * 命令综合判定（纯函数，供 run() 与回归测试共用）。
 * 闸门顺序：元字符 → 硬禁令正则 → 明文禁用首词 → 白名单 → git 子命令降级。
 * @returns {{ok:true, token:string} | {ok:false, code:string, reason:string}}
 */
export function classifyCommand(command, opts = {}) {
  const meta = hasShellMetachar(command)
  if (meta) return meta
  const why = bannedReason(command)
  if (why) return { ok: false, code: 'E_CMD_BANNED', reason: `命中硬禁令（${why}）` }
  const token = firstToken(command)
  if (BANNED_FIRST_TOKENS.has(token)) {
    return { ok: false, code: 'E_CMD_BANNED', reason: `明文禁用命令（${token}：删除/格式化/磁盘分区/改所有权/ACL，无参数也拒）` }
  }
  const extra = new Set(opts.extraAllow || [])
  const allowed = ALLOWED_COMMANDS.includes(token) || (extra.has(token) && EXTRA_COMMANDS.includes(token))
  if (!allowed) {
    return { ok: false, code: 'E_CMD_NOT_ALLOWED', reason: `命令不在白名单内：${token}` }
  }
  if (token === 'git' && !isGitAllowed(command)) {
    const sub = String(command).trim().split(/\s+/)[1] || ''
    return { ok: false, code: 'E_CMD_BANNED', reason: `git 仅放行只读子命令（status/diff/log/show/rev-parse/branch --list），拒绝 ${sub}` }
  }
  return { ok: true, token }
}

/** 从命令里抓出所有像路径的片段（用于"白名单命令 + 越界路径"的兜底检查）。 */
export function extractPaths(command) {
  const out = []
  const re = /([A-Za-z]:[\\/][^\s"'`|&<>^()]*)|(\\\\[^\s"'`|&<>^()]+)/g
  let m
  while ((m = re.exec(command)) !== null) out.push(m[0].replace(/\/$/, ''))
  return out
}

/** 取命令首词的 basename（去引号、去路径、去扩展名）。 */
export function firstToken(command) {
  const s = String(command || '').trim().replace(/^@/, '').trim()
  const m = /^"([^"]+)"|^'([^']+)'|^([^\s"'|&<>]+)/.exec(s)
  const raw = (m && (m[1] || m[2] || m[3])) || ''
  const base = raw.replace(/[\\/]/g, '\\').split('\\').pop() || ''
  return base.replace(/\.(exe|com|bat|cmd|ps1)$/i, '').toLowerCase()
}

/** 硬禁令检查：返回第一条命中的原因，没命中返回 null。 */
export function bannedReason(command) {
  for (const b of BANNED_PATTERNS) if (b.re.test(command)) return b.why
  return null
}

/**
 * @param {object} registry
 * @param {{
 *   child?: object, roots?: string[], extraAllow?: string[],
 *   fs?: object, killTree?: Function,
 * }} [deps]
 */
export function registerShellTools(registry, deps = {}) {
  const child = deps.child || defaultChild()
  const roots = deps.roots || [PROJECT_ROOT]
  const extraAllow = new Set(deps.extraAllow || [])
  const killTree = deps.killTree || defaultKillTree(child)

  const isUnderRoot = (p) => {
    const low = String(p).replace(/\//g, '\\').toLowerCase()
    return roots.some((r) => {
      const rl = String(r).replace(/\//g, '\\').toLowerCase().replace(/\\+$/, '')
      return low === rl || low.startsWith(rl + '\\')
    })
  }

  registry.register(
    defineTool({
      id: 'shell.run',
      label: '运行命令',
      description:
        '在授权目录内运行一条**白名单内**的只读命令（dir / type / echo / findstr / where / fc / git）。' +
        '关机、改注册表、计划任务、杀进程、下载执行、递归删除等一律拒绝；输出上限 100KB；超时 30 秒。',
      params: {
        type: 'object',
        properties: {
          command: { type: 'string', minLength: 1, maxLength: 2000, description: '要执行的命令' },
          cwd: { type: 'string', description: '工作目录，默认项目根；必须在授权根内' },
        },
        required: ['command'],
        additionalProperties: false,
      },
      targetsOf: (a) => (a.cwd ? [a.cwd] : []),
      write: true,
      timeoutMs: 30000,
      async run(args, ctx) {
        const command = String(args.command || '')
        const cwd = args.cwd ? resolvePath(ctx, args.cwd, 'shell.run.cwd') : PROJECT_ROOT
        if (!isUnderRoot(cwd)) {
          throw Object.assign(new Error(`工作目录不在授权根内：${cwd}`), { code: 'E_OUTSIDE_ROOTS' })
        }

        // ① 元字符整体拒绝（cmd.exe 会把 & | ; < > ( ) ` $ 解释成拼接/重定向/子shell）
        const meta = hasShellMetachar(command)
        if (meta) throw Object.assign(new Error(`命令被拒绝：${meta.reason}`), { code: meta.code })

        // ② 综合判定（硬禁令 + 明文禁用首词 + 白名单 + git 子命令降级）
        const verdict = classifyCommand(command, { extraAllow: [...extraAllow] })
        if (!verdict.ok) {
          throw Object.assign(new Error(`命令被拒绝：${verdict.reason}`), { code: verdict.code })
        }

        // ③ 命令里的绝对路径不得越界
        for (const p of extractPaths(command)) {
          if (!isUnderRoot(p)) {
            throw Object.assign(new Error(`命令中的路径越界：${p}`), { code: 'E_OUTSIDE_ROOTS' })
          }
        }

        // ④ 执行
        return await new Promise((resolve, reject) => {
          let settled = false
          let proc = null
          const chunks = []
          const errChunks = []
          let total = 0
          let truncated = false

          const finish = (fn, value) => {
            if (settled) return
            settled = true
            if (ctx.signal && typeof ctx.signal.removeEventListener === 'function') {
              ctx.signal.removeEventListener('abort', onAbort)
            }
            fn(value)
          }
          const onAbort = () => {
            if (proc && proc.pid) {
              try {
                killTree(proc.pid)
              } catch {
                /* 杀不掉也要继续走超时返回 */
              }
            }
            finish(reject, Object.assign(new Error('命令执行超时，已按 PID 树终止'), { code: 'E_TIMEOUT' }))
          }

          // S74c·P1-6：cmd.exe 的内建命令按系统 OEM 码页（中文机 936/GBK）输出；Node 默认按 utf8 解码
          // → 中文乱码。实测 `chcp 65001>nul &` 对**管道输出**无效（仍是 GBK 字节），故改用
          // 「GBK→UTF-8 转码」：用 Node 内置 TextDecoder（full-ICU 提供 gbk，装 iconv 会违反"不装新依赖"）。
          // 解码策略：先严格 UTF-8 解（失败即判为 GBK）。这样 git 等外部程序输出的**真 UTF-8** 原样保留，
          // 只有 cmd 内建命令的 GBK 字节才走 GBK 分支，二者都不乱码。见 tests\shell-encoding.test.mjs。
          try {
            proc = child.spawn('cmd.exe', ['/d', '/c', command], {
              cwd,
              windowsHide: true,
              stdio: ['ignore', 'pipe', 'pipe'],
              env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' },
            })
          } catch (err) {
            finish(reject, Object.assign(new Error(`命令启动失败：${(err && err.message) || err}`), { code: 'E_SPAWN_FAILED' }))
            return
          }

          if (ctx.signal) {
            if (ctx.signal.aborted) return onAbort()
            ctx.signal.addEventListener('abort', onAbort)
          }

          const push = (arr, buf) => {
            const size = buf.length
            if (total + size > LIMITS.SHELL_OUTPUT) {
              const room = Math.max(0, LIMITS.SHELL_OUTPUT - total)
              if (room > 0) arr.push(buf.slice(0, room))
              total = LIMITS.SHELL_OUTPUT
              truncated = true
              return false
            }
            arr.push(buf)
            total += size
            return true
          }

          proc.stdout.on('data', (b) => {
            if (!push(chunks, b)) {
              try {
                proc.kill()
              } catch {
                /* 已经在退出了 */
              }
            }
          })
          proc.stderr.on('data', (b) => {
            push(errChunks, b)
          })
          proc.on('error', (err) => {
            finish(reject, Object.assign(new Error(`命令执行出错：${(err && err.message) || err}`), { code: 'E_SPAWN_FAILED' }))
          })
          proc.on('close', (code) => {
            // S74c·P1-6：GBK→UTF-8 转码（严格 UTF-8 优先，失败走 GBK），修中文乱码
            const out = decodeCommandOutput(Buffer.concat(chunks))
            const err = decodeCommandOutput(Buffer.concat(errChunks))
            // truncated 为 true 时 out 恰好等于上限（push 已截到上限），
            // 此时 truncate() 判定"不大于"从而不加标记 —— 于是"截断"这件事就没人告诉模型了。
            // 这里手工补上：**静默截断等于说谎**。
            const t = truncated
              ? { text: out + `\n…[已截断：输出超过 ${LIMITS.SHELL_OUTPUT} 字节上限]`, truncated: true }
              : truncate(out, LIMITS.SHELL_OUTPUT, '字节')
            resolve({
              command,
              cwd,
              exitCode: code,
              ok: code === 0,
              stdout: t.text,
              stderr: truncate(err, 4000, '字节').text,
              truncated: t.truncated,
            })
          })
        })
      },
    }),
  )

  return registry
}

/** 默认按 PID 树终止（SAFETY.md §8：只按 PID 树，绝不按进程名批量杀）。 */
function defaultKillTree(child) {
  return (pid) => {
    if (!pid || pid <= 0) return false
    const r = child.spawnSync('taskkill', ['/PID', String(pid), '/T', '/F'], { encoding: 'utf8', windowsHide: true })
    return r.status === 0
  }
}

export default {
  registerShellTools,
  ALLOWED_COMMANDS,
  EXTRA_COMMANDS,
  BANNED_PATTERNS,
  BANNED_FIRST_TOKENS,
  GIT_ALLOWED_SUBS,
  bannedReason,
  extractPaths,
  firstToken,
  hasShellMetachar,
  isGitAllowed,
  classifyCommand,
  decodeCommandOutput,
}
