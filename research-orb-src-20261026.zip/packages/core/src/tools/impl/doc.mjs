// packages/core/src/tools/impl/doc.mjs
//
// 文档工具（P-R7）：doc.docx / doc.xlsx / doc.pptx / doc.md
//
// 依赖事实（主管追加修订 1）：.venv 里原本只有 python-docx，xlsx/pptx 要么装进
// 项目 venv、要么降级。本机已**装进项目 venv**（openpyxl==3.1.5 / python-pptx==1.0.2），
// 并由 tools\setup-venv.mjs 一键可重建，所以这里产出的是**真 xlsx / 真 pptx，不降级**。
// 若哪天库缺失，走 E_NO_OPENPYXL / E_NO_PPTX 如实报错，**绝不偷偷生成一个改名的 HTML**。
//
// 执行方式：把规范（JSON）落到 data\tmp\，再调 tools\py\*_build.py。
//   · 规范走文件而不是命令行参数：中文正文动辄上千字，塞 argv 会被命令行长度与引号吃掉；
//   · Python 一律经 tools/lib/run-python.mjs（UTF-8 纪律），禁止裸 spawnSync；
//   · Python 的结果 JSON 打在**最后一行**，Node 只解析最后一行（前面的中文提示不污染解析）。
//
// 字体（doc.docx）：正文宋体、标题楷体，且必须同时设 w:eastAsia，否则中文不生效。

import { basename, join } from 'node:path'
import { createRequire } from 'node:module'
import { defineTool } from '../registry.mjs'
import { PROJECT_ROOT, safeWrite, dataPath } from '../../safefs.mjs'
import { VENV_PYTHON, pythonFile, resolvePath, sha256Hex } from './support.mjs'

const require_ = createRequire(import.meta.url)

const defaultFs = () => require_('node:fs')
const PY_DIR = join(PROJECT_ROOT, 'tools', 'py')
const TMP_DIR = dataPath('tmp')

const SECTIONS_SCHEMA = {
  type: 'array',
  description: '文档主体：若干节，每节可有标题、段落、项目符号',
  items: {
    type: 'object',
    properties: {
      heading: { type: 'string', description: '小节标题（楷体）' },
      paragraphs: { type: 'array', items: { type: 'string' }, description: '正文段落（宋体）' },
      bullets: { type: 'array', items: { type: 'string' }, description: '项目符号列表' },
    },
    additionalProperties: false,
  },
}

/** 写规范文件 → 调 python → 解析最后一行 JSON。 */
function runBuilder(deps, scriptName, spec, ctx) {
  const fs = deps.fs || defaultFs()
  const python = deps.python || VENV_PYTHON
  const stamp = new Date().toISOString().replace(/[:.]/g, '-')
  const specPath = join(TMP_DIR, `${scriptName.replace('.py', '')}-${stamp}.json`)
  safeWrite(specPath, JSON.stringify(spec, null, 2))

  let res
  try {
    res = pythonFile(python, join(PY_DIR, scriptName), [specPath], { timeout: 60000 })
  } finally {
    // 规范文件用完即删：正文属于用户内容，不该长期躺在工程里
    try {
      if (fs.existsSync(specPath)) fs.rmSync(specPath, { force: true })
    } catch {
      /* 删不掉不影响主流程，data\tmp 在项目根内且受审计 */
    }
  }

  const lines = String(res.stdout || '').split(/\r?\n/).filter((l) => l.trim())
  const last = lines[lines.length - 1] || ''
  let parsed = null
  try {
    parsed = JSON.parse(last)
  } catch {
    parsed = null
  }
  if (!parsed) {
    const err = new Error(
      `文档生成失败（${scriptName}）：exit=${res.status}；stdout=${String(res.stdout || '').slice(0, 300)}；stderr=${String(res.stderr || '').slice(0, 300)}`,
    )
    err.code = 'E_BUILD_FAILED'
    throw err
  }
  if (!parsed.ok) {
    const err = new Error(`文档生成失败：${parsed.message || parsed.code}`)
    err.code = parsed.code || 'E_BUILD_FAILED'
    throw err
  }
  return parsed
}

/**
 * @param {object} registry
 * @param {{fs?: object, python?: string}} [deps]
 */
export function registerDocTools(registry, deps = {}) {
  const fs = deps.fs || defaultFs()

  registry.register(
    defineTool({
      id: 'doc.docx',
      label: '生成 Word 文档',
      description:
        '生成 .docx 文档。排版固定为：标题楷体居中，正文宋体小四。' +
        '需要用户提供标题与正文内容（sections 可多节：heading / paragraphs / bullets）。',
      params: {
        type: 'object',
        properties: {
          path: { type: 'string', description: '目标文件路径，如 desktop:自我介绍.docx（必须是 .docx 结尾）' },
          title: { type: 'string', description: '文档标题（楷体居中）' },
          paragraphs: { type: 'array', items: { type: 'string' }, description: '标题下的顶层段落（可选）' },
          sections: SECTIONS_SCHEMA,
        },
        required: ['path', 'title'],
        additionalProperties: false,
      },
      targetsOf: (a) => [a.path],
      write: true,
      timeoutMs: 60000,
      run(args, ctx) {
        const p = resolvePath(ctx, args.path, 'doc.docx')
        if (!/\.docx$/i.test(p)) throw Object.assign(new Error('doc.docx 的目标必须是 .docx 结尾'), { code: 'E_BAD_EXT' })
        const built = runBuilder(deps, 'docx_build.py', { path: p, title: args.title, paragraphs: args.paragraphs, sections: args.sections || [] }, ctx)
        return { path: p, bytes: built.bytes, hash: built.sha256, fonts: built.fonts, kind: 'docx' }
      },
    }),
  )

  registry.register(
    defineTool({
      id: 'doc.xlsx',
      label: '生成表格',
      description:
        '生成**真正的 .xlsx 表格**（openpyxl，不降级为 CSV）。表头加粗、列宽自适应。' +
        '参数：header（表头数组，可选）+ rows（二维数据，必填）。',
      params: {
        type: 'object',
        properties: {
          path: { type: 'string', description: '目标文件路径，如 desktop:汇总.xlsx（必须是 .xlsx 结尾）' },
          sheet: { type: 'string', description: '工作表名，默认 Sheet1' },
          header: { type: 'array', items: { type: 'string' }, description: '表头（会自动加粗）' },
          rows: { type: 'array', items: { type: 'array' }, description: '数据行（二维数组），必填' },
        },
        required: ['path', 'rows'],
        additionalProperties: false,
      },
      targetsOf: (a) => [a.path],
      write: true,
      timeoutMs: 60000,
      run(args, ctx) {
        const p = resolvePath(ctx, args.path, 'doc.xlsx')
        if (!/\.xlsx$/i.test(p)) throw Object.assign(new Error('doc.xlsx 的目标必须是 .xlsx 结尾'), { code: 'E_BAD_EXT' })
        const built = runBuilder(deps, 'xlsx_build.py', { path: p, sheet: args.sheet, header: args.header || [], rows: args.rows }, ctx)
        return { path: p, bytes: built.bytes, hash: built.sha256, sheet: built.sheet, kind: 'xlsx' }
      },
    }),
  )

  registry.register(
    defineTool({
      id: 'doc.pptx',
      label: '生成演示文稿',
      description:
        '生成**真正的 .pptx 演示文稿**（python-pptx，不降级为 HTML）。' +
        '第一页是标题页，其后每页一个 slides 项（title + bullets）。',
      params: {
        type: 'object',
        properties: {
          path: { type: 'string', description: '目标文件路径，如 desktop:汇报.pptx（必须是 .pptx 结尾）' },
          title: { type: 'string', description: '演示文稿标题' },
          subtitle: { type: 'string', description: '副标题（可选）' },
          slides: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                title: { type: 'string', description: '本页标题' },
                bullets: { type: 'array', items: { type: 'string' }, description: '本页要点' },
                notes: { type: 'string', description: '演讲者备注（可选）' },
              },
              additionalProperties: false,
            },
          },
        },
        required: ['path', 'title'],
        additionalProperties: false,
      },
      targetsOf: (a) => [a.path],
      write: true,
      timeoutMs: 60000,
      run(args, ctx) {
        const p = resolvePath(ctx, args.path, 'doc.pptx')
        if (!/\.pptx$/i.test(p)) throw Object.assign(new Error('doc.pptx 的目标必须是 .pptx 结尾'), { code: 'E_BAD_EXT' })
        const built = runBuilder(deps, 'pptx_build.py', { path: p, title: args.title, subtitle: args.subtitle, slides: args.slides || [] }, ctx)
        return { path: p, bytes: built.bytes, hash: built.sha256, slides: built.slides, kind: 'pptx' }
      },
    }),
  )

  registry.register(
    defineTool({
      id: 'doc.md',
      label: '生成 Markdown',
      description: '生成 .md 文档（纯文本，不需要 Python）。适合备忘、README、提纲。',
      params: {
        type: 'object',
        properties: {
          path: { type: 'string', description: '目标文件路径，如 desktop:提纲.md（建议 .md 结尾）' },
          title: { type: 'string', description: '文档标题（渲染为一级标题）' },
          paragraphs: { type: 'array', items: { type: 'string' } },
          sections: SECTIONS_SCHEMA,
        },
        required: ['path', 'title'],
        additionalProperties: false,
      },
      targetsOf: (a) => [a.path],
      write: true,
      timeoutMs: 20000,
      run(args, ctx) {
        const p = resolvePath(ctx, args.path, 'doc.md')
        const lines = [`# ${args.title}`, '']
        for (const para of args.paragraphs || []) lines.push(String(para), '')
        for (const sec of args.sections || []) {
          if (sec.heading) lines.push(`## ${sec.heading}`, '')
          for (const para of sec.paragraphs || []) lines.push(String(para), '')
          for (const b of sec.bullets || []) lines.push(`- ${b}`)
          if ((sec.bullets || []).length > 0) lines.push('')
        }
        const text = lines.join('\n').replace(/\n{3,}/g, '\n\n').trimEnd() + '\n'
        const buf = Buffer.from(text, 'utf8')
        fs.writeFileSync(p, buf)
        return { path: p, bytes: buf.length, hash: sha256Hex(buf), kind: 'md' }
      },
    }),
  )

  return registry
}

export default { registerDocTools, TMP_DIR, PY_DIR }
