// packages/core/src/tools/impl/fs.mjs
//
// 文件系统工具（P-R7）：list / stat / search / read / write / mkdir / move / copy / delete
//
// 纪律：
//   1. **本文件不做权限判定**——那是 executor 的活。这里只管"怎么做"，不管"能不能做"。
//      若被绕过 executor 直接调用，路径解析仍会拦一道（resolvePath），但授权根不归它管。
//   2. 所有路径先经 ctx.paths 解析（desktop: / project: / home: 展开 + 穿越拒绝）。
//   3. **返回值约定**：产出单个文件的工具返回 {path, bytes, hash}，executor 据此做
//      "写后读回校验"；不产文件的工具（mkdir / delete / move）不带 bytes/hash，
//      于是跳过校验 —— 否则"文件被删了"会被误判成"写入失败"。
//   4. 删除不真删：先复制一份到项目内 data\trash\，executor 另有快照兜底，/undo 可复原。
//   5. 覆盖/移动遇到已存在的目标一律**拒绝**，不静默覆盖（覆盖请走 fs.write，它有快照）。

import { basename, join } from 'node:path'
import { createRequire } from 'node:module'
import { defineTool } from '../registry.mjs'
import {
  LIMITS,
  fileStat,
  globToRegExp,
  looksText,
  packedResult,
  resolvePath,
  sha256Hex,
  truncate,
  walkDir,
} from './support.mjs'
import { PROJECT_ROOT, dataPath } from '../../safefs.mjs'
import { capOf } from '../../modes.mjs'

const require_ = createRequire(import.meta.url)

/**
 * 统计全文件换行字节数 → 总行数（末行无换行也计一行）。
 * 仅 lean 档（readLimitLines>0）会调用，避免对标准档增加额外 I/O。
 */
function countTotalLines(fs, p, size) {
  if (!size || size <= 0) return 0
  const buf = Buffer.alloc(64 * 1024)
  let count = 0
  let pos = 0
  const fd = fs.openSync(p, 'r')
  try {
    while (pos < size) {
      const n = fs.readSync(fd, buf, 0, Math.min(buf.length, size - pos), pos)
      if (n <= 0) break
      for (let i = 0; i < n; i++) if (buf[i] === 0x0a) count += 1
      pos += n
    }
  } finally {
    fs.closeSync(fd)
  }
  return count + 1
}

const defaultFs = () => require_('node:fs')

export const TRASH_DIR = dataPath('trash')

const notFound = (p) => Object.assign(new Error(`文件不存在：${p}`), { code: 'E_NOT_FOUND' })
const already = (p) => Object.assign(new Error(`目标已存在，拒绝静默覆盖：${p}`), { code: 'E_EXISTS' })

/**
 * @param {object} registry
 * @param {{fs?: object, trashDir?: string}} [deps]
 */
export function registerFsTools(registry, deps = {}) {
  const fs = deps.fs || defaultFs()
  const trashDir = deps.trashDir || TRASH_DIR
  const ensureDir = (dir) => {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
  }

  // ---------------------------------------------------------------- 只读

  registry.register(
    defineTool({
      id: 'fs.list',
      label: '列目录',
      description: '列出目录下的文件与子目录。路径支持 project: / home: / desktop: 前缀。',
      params: {
        type: 'object',
        properties: {
          path: { type: 'string', description: '目录路径，如 desktop: 或 D:\\Desktop\\子目录' },
          depth: { type: 'integer', minimum: 0, maximum: 4, description: '递归层数，默认 1' },
        },
        required: ['path'],
        additionalProperties: false,
      },
      targetsOf: (a) => [a.path],
      run(args, ctx) {
        const p = resolvePath(ctx, args.path, 'fs.list')
        const depth = Number.isFinite(args.depth) ? args.depth : 1
        const entries = walkDir(fs, p, { max: LIMITS.LIST_ENTRIES, depth })
        return packedResult({ path: p, count: entries.length, entries })
      },
    }),
  )

  registry.register(
    defineTool({
      id: 'fs.stat',
      label: '查看文件信息',
      description: '查看文件/目录是否存在、大小、修改时间。',
      params: {
        type: 'object',
        properties: { path: { type: 'string', description: '路径' } },
        required: ['path'],
        additionalProperties: false,
      },
      targetsOf: (a) => [a.path],
      run(args, ctx) {
        const p = resolvePath(ctx, args.path, 'fs.stat')
        return packedResult(fileStat(fs, p))
      },
    }),
  )

  registry.register(
    defineTool({
      id: 'fs.search',
      label: '搜索文件',
      description: '按文件名通配符搜索（支持 * 与 ?），如 *.docx。',
      params: {
        type: 'object',
        properties: {
          path: { type: 'string', description: '起始目录' },
          pattern: { type: 'string', description: '文件名通配，如 *.docx、report-?.md' },
          max: { type: 'integer', minimum: 1, maximum: 500, description: '最多返回多少条，默认 100' },
        },
        required: ['path', 'pattern'],
        additionalProperties: false,
      },
      targetsOf: (a) => [a.path],
      run(args, ctx) {
        const p = resolvePath(ctx, args.path, 'fs.search')
        const re = globToRegExp(args.pattern)
        // S22：检索封顶从模式读取（grepMaxMatches），缺省回落 SEARCH_HITS=100
        const max = Number.isFinite(args.max) ? args.max : capOf('grepMaxMatches')
        const all = walkDir(fs, p, { max: 2000, depth: 3 }).filter((e) => re.test(e.name))
        const total = all.length
        const hits = all.slice(0, max)
        const found = total > max ? `Found ${hits.length} of ${total} (offset=0, next_offset=${hits.length})` : undefined
        return packedResult({ path: p, pattern: args.pattern, count: hits.length, total, hits, ...(found ? { found } : {}) })
      },
    }),
  )

  registry.register(
    defineTool({
      id: 'fs.read',
      label: '读取文件',
      description: '读取文本文件内容（二进制文件会如实说明"不是文本"，不会硬塞乱码）。',
      params: {
        type: 'object',
        properties: {
          path: { type: 'string', description: '文件路径' },
          maxBytes: { type: 'integer', minimum: 1, maximum: 1048576, description: '最多读多少字节，默认 200KB' },
        },
        required: ['path'],
        additionalProperties: false,
      },
      targetsOf: (a) => [a.path],
      run(args, ctx) {
        const p = resolvePath(ctx, args.path, 'fs.read')
        if (!fs.existsSync(p)) throw notFound(p)
        if (fs.statSync(p).isDirectory()) throw Object.assign(new Error('这是一个目录，请用 fs.list'), { code: 'E_IS_DIR' })
        const size = fs.statSync(p).size
        // S22：读文件封顶从模式读取（readMaxBytes），缺省回落 READ_BYTES=200KB
        const maxBytes = Number.isFinite(args.maxBytes) ? args.maxBytes : capOf('readMaxBytes')
        const want = Math.min(size, maxBytes)
        const buf = Buffer.alloc(want)
        const fd = fs.openSync(p, 'r')
        try {
          fs.readSync(fd, buf, 0, want, 0)
        } finally {
          fs.closeSync(fd)
        }
        if (!looksText(buf)) {
          return { path: p, isText: false, bytes: size, note: '这是二进制文件（或含大量非文本字节），不回显内容。' }
        }
        let text = buf.toString('utf8')
        const found = []

        // 行截断（readLimitLines>0 才生效；standard/readonly 该值为 0 → 不按行截断）
        const limitLines = capOf('readLimitLines')
        let shownLines = -1
        let totalLines = -1
        if (limitLines > 0) {
          const lines = text.split('\n')
          totalLines = countTotalLines(fs, p, size)
          if (lines.length > limitLines) {
            text = lines.slice(0, limitLines).join('\n')
            shownLines = limitLines
          }
        }

        // 行内字符截断（readMaxLineChars>0 才生效）
        const maxLine = capOf('readMaxLineChars')
        if (maxLine > 0) {
          const lines = text.split('\n')
          let changed = false
          const out = lines.map((ln) => {
            if (ln.length > maxLine) { changed = true; return ln.slice(0, maxLine) + ` Found ${maxLine} of ${ln.length} 字符（行内截断）` }
            return ln
          })
          if (changed) text = out.join('\n')
        }

        // 字节层面最终兜底；当「文件本身大于本档上限」时即使恰好读满上限也要报 Found X of Y
        const t = truncate(text, maxBytes, '字节')
        if (size > maxBytes || t.truncated) found.push(`Found ${text.length} of ${size} bytes (offset=0, next_offset=${text.length})`)
        if (limitLines > 0 && shownLines > 0) {
          const total = totalLines > 0 ? totalLines : text.split('\n').length
          found.push(`Found ${shownLines} of ${total} lines (offset=0, next_offset=${shownLines})`)
        }
        return {
          path: p,
          isText: true,
          bytes: size,
          truncated: t.truncated || shownLines > 0,
          text: t.text,
          ...(found.length ? { found } : {}),
        }
      },
    }),
  )

  // ---------------------------------------------------------------- 写入

  registry.register(
    defineTool({
      id: 'fs.write',
      label: '写入文件',
      description: '写入（覆盖）一个文本文件。覆盖已存在的文件时会先快照，可用 /undo 复原。',
      params: {
        type: 'object',
        properties: {
          path: { type: 'string', description: '目标文件绝对路径或别名路径，如 desktop:notes.md' },
          content: { type: 'string', description: '文件内容' },
          mkdir: { type: 'boolean', description: '目录不存在时是否自动创建，默认 true' },
        },
        required: ['path', 'content'],
        additionalProperties: false,
      },
      targetsOf: (a) => [a.path],
      write: true,
      timeoutMs: 20000,
      run(args, ctx) {
        const p = resolvePath(ctx, args.path, 'fs.write')
        if (args.mkdir !== false) ensureDir(join(p, '..'))
        const buf = Buffer.from(String(args.content), 'utf8')
        fs.writeFileSync(p, buf)
        return { path: p, bytes: buf.length, hash: sha256Hex(buf), written: true }
      },
    }),
  )

  registry.register(
    defineTool({
      id: 'fs.mkdir',
      label: '创建目录',
      description: '创建一个目录（已存在则幂等返回，不报错）。',
      params: {
        type: 'object',
        properties: { path: { type: 'string', description: '目录路径' } },
        required: ['path'],
        additionalProperties: false,
      },
      targetsOf: (a) => [a.path],
      write: true,
      run(args, ctx) {
        const p = resolvePath(ctx, args.path, 'fs.mkdir')
        const existed = fs.existsSync(p)
        ensureDir(p)
        return { path: p, created: !existed, existed }
      },
    }),
  )

  registry.register(
    defineTool({
      id: 'fs.move',
      label: '移动文件',
      description: '移动/重命名文件或目录。目标已存在时拒绝（不静默覆盖）。',
      params: {
        type: 'object',
        properties: {
          from: { type: 'string', description: '源路径' },
          to: { type: 'string', description: '目标路径' },
        },
        required: ['from', 'to'],
        additionalProperties: false,
      },
      targetsOf: (a) => [a.from, a.to],
      write: true,
      run(args, ctx) {
        const from = resolvePath(ctx, args.from, 'fs.move.from')
        const to = resolvePath(ctx, args.to, 'fs.move.to')
        if (!fs.existsSync(from)) throw notFound(from)
        if (fs.existsSync(to)) throw already(to)
        ensureDir(join(to, '..'))
        fs.renameSync(from, to)
        return { from, to, moved: true }
      },
    }),
  )

  registry.register(
    defineTool({
      id: 'fs.copy',
      label: '复制文件',
      description: '复制文件。目标已存在时拒绝（不静默覆盖）。',
      params: {
        type: 'object',
        properties: {
          from: { type: 'string', description: '源路径' },
          to: { type: 'string', description: '目标路径' },
        },
        required: ['from', 'to'],
        additionalProperties: false,
      },
      targetsOf: (a) => [a.from, a.to],
      write: true,
      run(args, ctx) {
        const from = resolvePath(ctx, args.from, 'fs.copy.from')
        const to = resolvePath(ctx, args.to, 'fs.copy.to')
        if (!fs.existsSync(from)) throw notFound(from)
        if (fs.existsSync(to)) throw already(to)
        ensureDir(join(to, '..'))
        fs.copyFileSync(from, to)
        return { from, to, bytes: fs.statSync(to).size, copied: true }
      },
    }),
  )

  registry.register(
    defineTool({
      id: 'fs.delete',
      label: '删除文件',
      description: '删除文件：先复制一份到项目内 data\\trash\\（不真删），executor 另有快照，/undo 可复原。拒绝删目录。',
      params: {
        type: 'object',
        properties: { path: { type: 'string', description: '要删除的文件路径' } },
        required: ['path'],
        additionalProperties: false,
      },
      targetsOf: (a) => [a.path],
      write: true,
      run(args, ctx) {
        const p = resolvePath(ctx, args.path, 'fs.delete')
        if (!fs.existsSync(p)) throw notFound(p)
        const st = fs.statSync(p)
        if (st.isDirectory()) throw Object.assign(new Error('拒绝删除目录（风险过高，请逐个删文件）'), { code: 'E_IS_DIR' })
        ensureDir(trashDir)
        const stamp = new Date().toISOString().replace(/[:.]/g, '-')
        const dest = join(trashDir, `${stamp}-${basename(p)}`)
        fs.copyFileSync(p, dest)
        fs.rmSync(p, { force: true })
        return { deleted: true, from: p, trashedTo: dest }
      },
    }),
  )

  return registry
}

export default { registerFsTools, TRASH_DIR }
