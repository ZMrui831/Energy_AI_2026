// packages/core/src/tools/impl/cu-backend.mjs
//
// S45·P2 computer use 二代：**加载器 + 安全闸 + 截图治理 + 键位释放兜底**。
//
// ── 加载铁律（任务书 + 仓库样例，堵死同一条错路）────────────────────
//   **禁止** import `<dsh-orb>/dist/computer-use/index.js` —— 那是 Cordis 插件入口，
//   会 import @deepseek-ai/schemastery（宿主持有）→ ERR_MODULE_NOT_FOUND。
//   **必须** 加载同目录 `backend-*.js`，并按**函数名**取导出（打包把名字压成别名）。
//
// ── 三条安全带（缺一条就不许发 HID）──────────────────────────────
//   ① 先查前台窗口，再查按键，最后才动手（顺序写死在 runHid 里，不许调换）；
//   ② guardHotkey 是**我们自己的**严白名单 —— 复核确认 dsh-orb 的
//      assertAllowedHotkey 只是窄禁区（只拦系统截图快捷键），win+r / ctrl+alt+delete
//      一类它照样放行，所以它**不能**当护栏，只能当第二层；
//   ③ 每次 HID 动作进 **finally** 复查 5 个修饰键；仍有按下就在 OS 层补发 KEYUP
//      （事故原型：abort / 异常 / 进程退出三条路上 Ctrl/Alt 卡死，之后全屏多选）。
//
// ── 截图双轨（不许混）────────────────────────────────────────────
//   审计留证 data\screens\ui-step\<run>\ —— 双格式取小，单张 ≤300KB，只留最近 3 轮；
//   演示素材 data\screens\demo\       —— PNG 原图不失真，不进 TTL，人工清。

import { randomUUID } from 'node:crypto'
import { existsSync, mkdirSync, readdirSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir, homedir } from 'node:os'
import { join } from 'node:path'
import { spawnSync } from 'node:child_process'
import { pathToFileURL } from 'node:url'

import { centerOf, screenAt, toAbsolute, toNormalized } from './cu-geom.mjs'
import { PROJECT_ROOT, appendJsonl, dataPath, logPath } from '../../safefs.mjs'

// ---------------------------------------------------------------- 常量

export const DEFAULT_PLUGIN = join(homedir(), '.dsh', 'profiles', 'desktop', 'node_modules', 'dsh-orb')
export const CU_SUBDIR = join('dist', 'computer-use')

/** 演示靶子的唯一标题前缀（补充条款第 5 条：不许拿系统记事本当靶子）。 */
export const SELF_TITLE_RE = /^orb-ui-demo-/

export const MAX_KEYS_PER_RUN = 200
export const KEEP_RUNS = 3
export const MAX_SHOT_KB = 300
export const AUDIT_LOG = 'cu.jsonl'
export const SHOT_AUDIT_SEG = ['screens', 'ui-step']
export const SHOT_DEMO_SEG = ['screens', 'demo']

export const DEFAULT_PYTHON = join(homedir(), '.workbuddy', 'binaries', 'python', 'versions', '3.13.12', 'python.exe')
export const KEY_STATE_PY = join(PROJECT_ROOT, 'tools', 'ui-step', 'key-state.py')
export const SHOT_STORE_PY = join(PROJECT_ROOT, 'tools', 'ui-step', 'shot-store.py')

/** 通用允许组合（不挑目标窗口）。 */
export const HOTKEY_ALLOW = Object.freeze([
  ['ctrl', 'a'], ['ctrl', 'c'], ['ctrl', 'v'], ['ctrl', 'x'], ['ctrl', 'z'], ['ctrl', 'f'],
  ['escape'], ['enter'], ['tab'], ['f2'], ['f5'],
])

/** 只允许对**自建演示窗口**使用 —— 关窗/关标签不可逆，必须 selfOwned。 */
export const HOTKEY_SELF_ONLY = Object.freeze([['alt', 'f4'], ['ctrl', 'w']])

/** 系统截图快捷键（与 dsh-orb 的窄禁区重叠，这里依旧显式拒 —— 两层不冲突）。 */
export const HOTKEY_SCREENSHOT = Object.freeze([
  ['printscreen'], ['print', 'screen'], ['prtsc'], ['prtscn'], ['ps'], ['snapshot'],
  ['alt', 'printscreen'], ['lwin', 'printscreen'], ['lwin', 'shift', 's'],
  ['cmd', 'shift', '3'], ['cmd', 'shift', '4'], ['cmd', 'shift', '5'],
])

// ---------------------------------------------------------------- 纯函数：按键与目标闸门

/** 归一化：小写、去 'key-' 前缀、排序后比对（ctrl+a 与 a+ctrl 是同一个组合）。 */
export function normalizeKeys(keys) {
  return (Array.isArray(keys) ? keys : [])
    .map((k) => String(k == null ? '' : k).trim().toLowerCase().replace(/^key[-_]/, ''))
    .filter(Boolean)
    .sort((a, b) => String(a).localeCompare(String(b)))
}

const sameSet = (a, b) => a.length === b.length && a.every((x, i) => x === b[i])

/**
 * **我们自己的**严白名单。返回 {ok, code, reason, selfOnly}。
 * 覆盖三条：未登记组合 → 拒；selfOnly 组合但目标不是自建窗口 → 拒；系统截图 → 拒。
 */
export function guardHotkey(keys, { selfOwned = false } = {}) {
  const norm = normalizeKeys(keys)
  if (norm.length === 0) return { ok: false, selfOnly: false, code: 'E_CU_HOTKEY_DENIED', reason: '按键组合为空' }

  for (const combo of HOTKEY_SCREENSHOT) {
    if (sameSet(norm, combo.slice().sort())) {
      return { ok: false, selfOnly: false, code: 'E_CU_HOTKEY_DENIED', reason: `系统截图快捷键（${combo.join('+')}）禁用：截屏只允许走受控 capture 通道` }
    }
  }
  // 一切带 win / meta / cmd 的组合都不碰（开始菜单、运行、任务视图都是不可逆的上下文切换）
  for (const k of norm) {
    if (k === 'win' || k === 'lwin' || k === 'rwin' || k === 'meta' || k === 'cmd' || k === 'super') {
      return { ok: false, selfOnly: false, code: 'E_CU_HOTKEY_DENIED', reason: `含系统键 ${k}：一律拒绝（win+r / alt+tab 类上下文切换不可逆）` }
    }
  }
  // 显式黑名单（双保险，避免白名单写漏）
  for (const combo of [['alt', 'tab'], ['ctrl', 'alt', 'delete'], ['ctrl', 'shift', 'esc'], ['ctrl', 's'], ['ctrl', 'alt', 'del']]) {
    if (sameSet(norm, combo.sort())) {
      return { ok: false, selfOnly: false, code: 'E_CU_HOTKEY_DENIED', reason: `${combo.join('+')} 在禁用清单（窗口切换 / 系统界面 / 保存=不可逆）` }
    }
  }
  for (const combo of HOTKEY_ALLOW) {
    if (sameSet(norm, combo.slice().sort())) return { ok: true, selfOnly: false, code: null, reason: '在通用允许清单内' }
  }
  for (const combo of HOTKEY_SELF_ONLY) {
    if (sameSet(norm, combo.slice().sort())) {
      if (selfOwned) return { ok: true, selfOnly: true, code: null, reason: `仅允许对自建窗口（前台已确认为 orb-ui-demo-*）` }
      return { ok: false, selfOnly: true, code: 'E_CU_HOTKEY_DENIED', reason: `${combo.join('+')} 只允许对自建演示窗口 orb-ui-demo-*，当前前台不是` }
    }
  }
  return { ok: false, selfOnly: false, code: 'E_CU_HOTKEY_DENIED', reason: `组合 ${norm.join('+')} 未在允许清单内（允许：${HOTKEY_ALLOW.map((c) => c.join('+')).join(' / ')}）` }
}

/** 前台窗口校验（顺序里最靠前的一道：先窗口，后按键）。 */
export function guardTarget(fg, { titleRe = SELF_TITLE_RE } = {}) {
  const title = String((fg && (fg.windowTitle || fg.title || fg.appName)) || '')
  const ok = titleRe.test(title)
  return {
    ok,
    code: ok ? null : 'E_CU_TARGET_MISMATCH',
    title,
    selfOwned: ok,
    reason: ok ? '前台窗口是自建演示窗口' : `前台窗口「${title || '（无标题）'}」不匹配 ^orb-ui-demo-，零动作`,
  }
}

// ---------------------------------------------------------------- python 小工具

/** 跑一次 python 脚本，取 stdout 最后一行 JSON。 */
export function runPy(python, script, args = [], timeoutMs = 20000) {
  const r = spawnSync(python, [script, ...args], { encoding: 'utf8', timeout: timeoutMs, windowsHide: true })
  if (r.error) return { ok: false, code: 'E_PY_SPAWN', error: String((r.error && r.error.message) || r.error) }
  const lines = String(r.stdout || '').split('\n').map((l) => l.trim()).filter(Boolean)
  const last = lines.length > 0 ? lines[lines.length - 1] : ''
  try {
    return JSON.parse(last)
  } catch {
    return { ok: false, code: 'E_PY_BAD_JSON', stdout: String(r.stdout || '').slice(0, 300), stderr: String(r.stderr || '').slice(0, 300) }
  }
}

/** 读 5 个修饰键（probe 侧）。 */
export function readKeyState(deps = {}) {
  const python = deps.python || DEFAULT_PYTHON
  if (!existsSync(KEY_STATE_PY)) return { ok: false, code: 'E_NO_PROBE', stuck: [] }
  const r = runPy(python, KEY_STATE_PY, [], 8000)
  if (!r || !r.ok) return { ok: false, code: (r && r.code) || 'E_KEYSTATE_FAILED', stuck: [] }
  return { ok: true, state: r.state || {}, stuck: Array.isArray(r.stuck) ? r.stuck : [] }
}

/** 补发 KEYUP（修复侧：只在 finally 检测到 stuck 时调用）。 */
export function releaseStuckKeys(deps = {}) {
  const python = deps.python || DEFAULT_PYTHON
  if (!existsSync(KEY_STATE_PY)) return { ok: false, code: 'E_NO_PROBE', released: [] }
  const r = runPy(python, KEY_STATE_PY, ['--release'], 8000)
  if (!r || !r.ok) return { ok: false, code: (r && r.code) || 'E_KEYSTATE_FAILED', released: [] }
  return { ok: true, released: Array.isArray(r.released) ? r.released : [], stillStuck: r.stillStuckAfterRelease || [] }
}

/**
 * **进程退出前的最后一道**（第 4 条断言④的依据）：
 * 实测八年级 NotImplemented：**Windows 不会在进程退出时释放它按下的键** ——
 * 子进程 keybd_event 按下 Ctrl 后 sys.exit(0)，父进程再查 GetAsyncKeyState(VK_CONTROL)
 * 依旧为 true（2026-10-24 本机实测）。也就是说"反正进程退出系统会收尾"是错的，
 * 只要进程被 abort / exit 前没自己 UP，Ctrl/Alt 就永久卡住。
 *
 * 所以这里注册 exit / SIGINT / SIGTERM 三个钩子；process.on('exit') 只能同步，
 * 因此走 spawnSync（runPy 本身就是同步的）。
 */
let _exitGuardInstalled = false
export function installExitGuard({ python = DEFAULT_PYTHON, audit = null } = {}) {
  if (_exitGuardInstalled) return { ok: true, installed: false, note: '已注册过，不重复挂' }
  const done = []
  const handler = (why) => {
    try {
      const before = readKeyState({ python })
      if (!(before.ok && (before.stuck || []).length > 0)) return
      const rel = releaseStuckKeys({ python })
      done.push({ why, stuck: before.stuck, released: rel.released || [], stillStuck: rel.stillStuck || [] })
      if (typeof audit === 'function') {
        audit({
          ts: new Date().toISOString(),
          toolId: 'cu',
          auditType: 'exit-release',
          why: why || 'exit',
          stuck: before.stuck,
          released: rel.released || [],
          stillStuck: rel.stillStuck || [],
        })
      }
    } catch {
      /* 退出钩子里任何失败都不能阻止进程退出 */
    }
  }
  process.on('exit', () => handler('exit'))
  process.on('SIGINT', () => { handler('SIGINT'); process.exit(130) })
  process.on('SIGTERM', () => { handler('SIGTERM'); process.exit(143) })
  _exitGuardInstalled = true
  return { ok: true, installed: true, done }
}

// ---------------------------------------------------------------- 加载器

/**
 * 按**函数名**加载 dsh-orb computer-use backend。
 * @returns {{ok:boolean, backend?:object, api?:object, pluginDir?:string, file?:string, code?:string, message?:string}}
 */
export async function loadCuBackend({ pluginDir = null, fs = null } = {}) {
  const dir = join(pluginDir || process.env.DSH_ORB_PLUGIN || DEFAULT_PLUGIN, CU_SUBDIR)
  let names = []
  try {
    names = readdirSync(dir)
  } catch {
    return { ok: false, code: 'E_CU_NO_BACKEND', message: `找不到 computer-use 目录：${dir}（可设 DSH_ORB_PLUGIN）` }
  }
  const hits = names.filter((f) => /^backend-.*\.js$/.test(f))
  if (hits.length === 0) return { ok: false, code: 'E_CU_NO_BACKEND', message: `${dir} 下没有 backend-*.js` }
  const file = join(dir, hits[0])

  let mod
  try {
    mod = await import(pathToFileURL(file).href)
  } catch (e) {
    return { ok: false, code: 'E_CU_LOAD_FAILED', message: `加载 ${file} 失败：${String((e && e.message) || e).slice(0, 200)}` }
  }
  const api = {}
  for (const name of ['createPlatformBackend', 'createWindowsDesktopBackend', 'assertAllowedHotkey', 'runWithCaptureExcludeWindowIds', 'modelPositionToHid', 'requireNormalizedPosition', 'requirePixelPosition', 'encodeBgraPng', 'delay']) {
    const fn = Object.values(mod).find((v) => typeof v === 'function' && v.name === name)
    if (fn) api[name] = fn
  }
  const create = api.createPlatformBackend || api.createWindowsDesktopBackend
  if (typeof create !== 'function') {
    return { ok: false, code: 'E_CU_LOAD_FAILED', message: 'backend-*.js 里既没有 createPlatformBackend 也没有 createWindowsDesktopBackend' }
  }
  return { ok: true, backend: create(), api, pluginDir: dir, file }
}

// ---------------------------------------------------------------- 主运行时

const zeroStats = () => ({
  shots: 0, bytes: 0, maxBytes: 0, formats: { png: 0, jpeg: 0 }, keysSent: 0,
  forbidden: { targetMismatch: 0, hotkeyDenied: 0, keyStorm: 0 }, stuckRecovered: 0,
})

/**
 * computer use 二代运行时。
 * @param {{pluginDir?:string, python?:string, audit?:Function, logFile?:string,
 *          excludeWindowIds?:number[], confirm?:Function, now?:Function, onEvent?:Function}} options
 */
export function createComputerUse(options = {}) {
  const python = options.python || DEFAULT_PYTHON
  const deps = { python }
  const excludeWindowIds = Array.isArray(options.excludeWindowIds) ? options.excludeWindowIds : []
  const emit = typeof options.onEvent === 'function' ? options.onEvent : () => {}
  const confirm = typeof options.confirm === 'function' ? options.confirm : null
  const now = options.now || (() => Date.now())
  const auditFile = options.logFile || logPath(AUDIT_LOG)
  const writeAudit =
    typeof options.audit === 'function'
      ? options.audit
      : (rec) => {
          try {
            appendJsonl(auditFile, rec)
          } catch (e) {
            process.stderr.write(`[research-orb/cu] 审计写入失败：${e && e.message}\n`)
          }
        }

  let loaded = null
  let backendRef = null
  let total = zeroStats()
  let perRun = zeroStats()
  let currentRun = null

  // 键位探测可注入：验收里要用内存替身跑"按键风暴"（真跑 200 次 python 探针太慢），
  // 生产默认是真的 OS 查询，不许依赖替身。
  const readStateFn = typeof options.readKeyState === 'function' ? options.readKeyState : () => readKeyState(deps)
  const releaseFn = typeof options.releaseStuck === 'function' ? options.releaseStuck : () => releaseStuckKeys(deps)

  // 进程退出前必须释放 —— 见 installExitGuard 上方的实测说明（默认安装，可 opt-out）
  const exitGuard = options.installExitGuard === false
    ? { ok: true, installed: false, reason: 'caller opted out' }
    : installExitGuard({ python, audit: writeAudit })

  async function ensureBackend() {
    if (backendRef) return { ok: true, backend: backendRef, api: loaded && loaded.api }
    if (loaded && loaded.backend) {
      backendRef = loaded.backend
      return { ok: true, backend: backendRef, api: loaded.api }
    }
    loaded = await loadCuBackend({ pluginDir: options.pluginDir })
    if (!loaded.ok) return loaded
    backendRef = loaded.backend
    return { ok: true, backend: backendRef, api: loaded.api }
  }

  // ---------------- 截图（双轨 + 双格式取小）
  async function captureShot(input = {}) {
    const t0 = now()
    const got = await ensureBackend()
    if (!got.ok) return { ok: false, code: got.code, message: got.message }
    const b = got.backend
    const screens = await b.listScreens()
    if (!Array.isArray(screens) || screens.length === 0) return { ok: false, code: 'E_CU_NO_SURFACE', message: '没有可操作的屏幕' }
    const screen = input.screen || screens[Number.isFinite(input.screenIndex) ? input.screenIndex : 0] || screens[0]

    let shot = null
    try {
      const api = got.api || {}
      const excludeFn = api.runWithCaptureExcludeWindowIds
      if (typeof excludeFn === 'function' && excludeWindowIds.length > 0) {
        // 必须排除自身窗口：否则把球/overlay 自己拍进留证，既是穿帮也是信息泄漏
        shot = await excludeFn(excludeWindowIds, async () => b.capture(screen))
      } else {
        shot = await b.capture(screen)
      }
    } catch (e) {
      return { ok: false, code: 'E_CU_CAPTURE_FAILED', message: String((e && e.message) || e).slice(0, 200) }
    }
    if (!shot || !shot.data) return { ok: false, code: 'E_CU_CAPTURE_FAILED', message: 'capture 未返回图像数据' }

    const demo = input.demo === true
    const root = demo ? dataPath(...SHOT_DEMO_SEG) : dataPath(...SHOT_AUDIT_SEG)
    const outdir = demo ? root : join(root, String(currentRun || 'no-run'))
    try {
      mkdirSync(outdir, { recursive: true })
    } catch {
      /* 目录已存在 */
    }
    const step = String(input.step || 'unknown')
    const phase = String(input.phase || 'before')
    const stem = `${step}-${phase}`
    const tmp = join(tmpdir(), `orb-cu-${randomUUID()}.png`)
    writeFileSync(tmp, Buffer.from(shot.data))

    const args = [SHOT_STORE_PY, '--src', tmp, '--outdir', outdir, '--stem', stem, '--maxkb', String(MAX_SHOT_KB)]
    if (demo) args.push('--lossless')
    const store = runPy(python, SHOT_STORE_PY, args.slice(1), 30000)
    try {
      rmSync(tmp, { force: true })
    } catch {
      /* 临时文件清理失败不致命 */
    }
    if (!store || !store.ok) {
      return { ok: false, code: (store && store.code) || 'E_CU_SHOT_STORE', message: '截图落盘治理失败', detail: store }
    }
    const bytes = store.bytes || 0
    const meta = {
      step, phase,
      bounds: screen.bounds || null,
      screenIndex: typeof screen.index === 'number' ? screen.index : 0,
      windowRect: input.windowRect || null,
      position: input.position || null,
      format: store.format,
      bytes,
      width: store.width, height: store.height,
      candidates: store.candidates || null,
      downscaled: store.downscaled,
      oversized: !!store.oversized,
      guardHotkey: input.guardHotkey || null,
      demo,
      run: currentRun,
      ms: now() - t0,
      ts: new Date().toISOString(),
    }
    try {
      writeFileSync(join(outdir, `${stem}.meta.json`), JSON.stringify(meta, null, 2), 'utf8')
    } catch {
      /* meta 写失败不影响主流程，但要在返回值里如实标出 */
      meta.metaWriteFailed = true
    }

    const bump = (bag) => {
      bag.shots += 1
      bag.bytes += bytes
      bag.maxBytes = Math.max(bag.maxBytes, bytes)
      const f = store.format === 'jpeg' ? 'jpeg' : 'png'
      bag.formats[f] += 1
    }
    bump(total)
    bump(perRun)
    emit({ type: 'cu:shot', demo, bytes, format: store.format, step, phase })
    return { ok: true, path: store.path, meta, ...meta }
  }

  // ---------------- HID 动作（三条安全带 + finally 释放）
  function withTimeout(promise, ms) {
    if (!Number.isFinite(ms) || ms <= 0) return Promise.resolve(promise)
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(Object.assign(new Error(`HID 动作超时（${ms}ms）已中止`), { code: 'E_TIMEOUT' })), ms)
      Promise.resolve(promise).then(
        (v) => { clearTimeout(timer); resolve(v) },
        (e) => { clearTimeout(timer); reject(e) },
      )
    })
  }

  async function callBackend(kind, args, api, b) {
    if (kind === 'hotkey') return b.hotkey({ keys: args.keys })
    if (kind === 'click') return b.click({ screen: args.screen, position: args.position, button: args.button || 'left', count: args.count || 1 })
    if (kind === 'typeText') return b.typeText({ screen: args.screen, position: args.position, text: args.text, replace: !!args.replace, submit: !!args.submit })
    if (kind === 'scroll') return b.scroll({ screen: args.screen, position: args.position, direction: args.direction || 'down', scrollLevel: args.scrollLevel || 1 })
    if (kind === 'drag') {
      if (typeof b.drag !== 'function') throw Object.assign(new Error('当前 backend 没有 drag 能力'), { code: 'E_CU_UNSUPPORTED' })
      return b.drag({ screen: args.screen, position: args.position, to: args.to })
    }
    throw Object.assign(new Error(`未知 HID 动作 ${kind}`), { code: 'E_CU_UNKNOWN_ACTION' })
  }

  /**
   * 唯一 HID 出口。顺序写死：① 前台窗口 ② 按键白名单 ③ 按键风暴 ④ 执行 ⑤ finally 复查释放。
   */
  async function runHid(input = {}) {
    const kind = String(input.kind || 'unknown')
    const keys = normalizeKeys(input.keys || [])
    const timeoutMs = Number.isFinite(input.timeoutMs) ? input.timeoutMs : 10000
    const args = input.args || {}
    const t0 = now()

    const got = await ensureBackend()
    if (!got.ok) return { ok: false, denied: true, code: got.code, message: got.message, kind }

    let fg = null
    try {
      fg = await got.backend.inspectForeground()
    } catch {
      fg = null
    }
    const target = guardTarget(fg, {})
    const guard = keys.length > 0 ? guardHotkey(keys, { selfOwned: target.selfOwned }) : { ok: true, selfOnly: false, code: null, reason: '本动作不含组合键' }
    const storm = keys.length > 0 && perRun.keysSent + keys.length > MAX_KEYS_PER_RUN

    const baseAudit = {
      ts: new Date().toISOString(),
      toolId: 'cu',
      kind,
      keys,
      run: currentRun,
      target: { title: target.title, selfOwned: target.selfOwned },
      hotkeyGuard: { ok: guard.ok, code: guard.code, reason: guard.reason, selfOnly: !!guard.selfOnly },
      timeoutMs,
    }
    const denied = (code, message, bucket) => {
      total.forbidden[bucket] += 1
      perRun.forbidden[bucket] += 1
      writeAudit({ ...baseAudit, decision: 'denied', result: code, reason: message, durationMs: now() - t0 })
      emit({ type: 'cu:denied', kind, code })
      return { ok: false, denied: true, notExecuted: true, code, message, target: target.title, kind }
    }

    // ① 先窗口
    if (!target.ok) return denied(target.code, target.reason, 'targetMismatch')
    // ①.5 坐标合法性：0–1000 之外一律拒，**不 clamp**（clamp 会把点到屏外粉饰成点到边上）
    if (args && Array.isArray(args.position)) {
      const [nx, ny] = args.position
      if (!Number.isFinite(nx) || !Number.isFinite(ny) || nx < 0 || nx > 1000 || ny < 0 || ny > 1000) {
        return denied('E_CU_BAD_POSITION', `position ${JSON.stringify(args.position)} 不在 0–1000 归一化空间内，拒绝执行`, 'targetMismatch')
      }
    }
    // ② 后按键
    if (!guard.ok) return denied(guard.code, guard.reason, 'hotkeyDenied')
    // ③ 按键风暴
    if (storm) return denied('E_CU_KEY_STORM', `本轮已发 ${perRun.keysSent} 个键，再加 ${keys.length} 超过上限 ${MAX_KEYS_PER_RUN}，已中止`, 'keyStorm')

    // ④ 执行。**坐标级兜底**动作（UIA 桥失败后改走 backend 坐标）必须先过确认卡 ——
    //    没有确认处理器就拒：headless 一律不放行（沿用 ui-step 六件套的第⑤条）。
    const isCoordFallback = input.fallback === true
    if (isCoordFallback) {
      if (!confirm) {
        return denied('E_CU_NEEDS_CONFIRM', '坐标级兜底动作需要用户确认，但当前没有确认处理器（headless 一律不执行）', 'targetMismatch')
      }
      if (confirm) {
        const ans = await confirm({ title: '需要批准：坐标级操作', what: `${kind} @ ${JSON.stringify(args.position || null)}`, target: target.title })
        if (!ans || !ans.approved) {
          writeAudit({ ...baseAudit, decision: 'not-executed', result: 'E_USER_DENIED', durationMs: now() - t0 })
          return { ok: false, denied: true, notExecuted: true, code: 'E_USER_DENIED', message: '用户未批准，未执行', kind }
        }
      }
    }

    perRun.keysSent += keys.length
    total.keysSent += keys.length
    const beforeState = readStateFn()
    let value = null
    let error = null
    let timedOut = false
    try {
      value = await withTimeout(callBackend(kind, args, got.api, got.backend), timeoutMs)
    } catch (e) {
      error = { code: (e && e.code) || 'E_CU_FAILED', message: String((e && e.message) || e).slice(0, 300) }
      timedOut = error.code === 'E_TIMEOUT'
    }
    // ⑤ finally 复查：这一句不许放进 try 里 —— abort / 异常 / 退出三条路都要走到
    const afterState = readStateFn()
    let recovered = null
    if (afterState.ok && (afterState.stuck || []).length > 0) {
      recovered = releaseFn()
      total.stuckRecovered += 1
      perRun.stuckRecovered += 1
    }
    writeAudit({
      ...baseAudit,
      decision: 'executed',
      result: error ? (timedOut ? 'timeout' : 'error') : 'ok',
      beforeStuck: beforeState.ok ? beforeState.stuck : 'probe-unavailable',
      afterStuck: afterState.ok ? afterState.stuck : 'probe-unavailable',
      releasedAtFinally: recovered ? recovered.released : [],
      stillStuck: recovered ? recovered.stillStuck : (afterState.stuck || []),
      error,
      durationMs: now() - t0,
    })
    if (error) return { ok: false, code: error.code, message: error.message, timedOut, kind, keysReleased: !!recovered }
    return { ok: true, kind, value, keysReleased: !!recovered, afterStuck: afterState.stuck || [] }
  }

  // ---------------- TTL
  function cleanupRuns(keep = KEEP_RUNS) {
    const root = dataPath(...SHOT_AUDIT_SEG)
    if (!existsSync(root)) return { removed: [], kept: [], root }
    const runs = readdirSync(root, { withFileTypes: true }).filter((d) => d.isDirectory()).map((d) => d.name).sort()
    const keepSet = new Set(runs.slice(Math.max(0, runs.length - keep)))
    const removed = []
    for (const name of runs) {
      if (keepSet.has(name)) continue
      try {
        rmSync(join(root, name), { recursive: true, force: true })
        removed.push(name)
      } catch {
        /* 清理失败如实留在返回里 */
      }
    }
    return { removed, kept: [...keepSet], root }
  }

  // ---------------- run 管理
  function startRun() {
    currentRun = `${Date.now()}-${String(randomUUID()).slice(0, 8)}`
    perRun = zeroStats()
    return currentRun
  }

  return {
    version: '0.8.0-cu',
    exitGuard: () => exitGuard,
    /** 注入替身 backend（验收用：不加载真 HID 也能验闸门与释放路径）。 */
    _setBackend(b, api = {}) {
      backendRef = b
      loaded = { ok: true, backend: b, api }
      return backendRef
    },
    ensureBackend,
    startRun,
    currentRun: () => currentRun,
    cleanupRuns,
    screens: async () => {
      const got = await ensureBackend()
      if (!got.ok) return got
      return { ok: true, screens: await got.backend.listScreens() }
    },
    screenAt: async (absX, absY) => {
      const got = await ensureBackend()
      if (!got.ok) return got
      const list = await got.backend.listScreens()
      return screenAt(Array.isArray(list) ? list : [], absX, absY)
    },
    inspect: async () => {
      const got = await ensureBackend()
      if (!got.ok) return got
      return { ok: true, foreground: await got.backend.inspectForeground() }
    },
    listApps: async () => {
      const got = await ensureBackend()
      if (!got.ok) return got
      return { ok: true, apps: await got.backend.listApps() }
    },
    capture: captureShot,
    keyState: readStateFn,
    releaseStuck: releaseFn,
    hotkey: ({ keys, ...rest } = {}) => runHid({ kind: 'hotkey', keys, ...rest }),
    click: (rest = {}) => runHid({ kind: 'click', ...rest }),
    typeText: (rest = {}) => runHid({ kind: 'typeText', ...rest }),
    scroll: (rest = {}) => runHid({ kind: 'scroll', ...rest }),
    drag: (rest = {}) => runHid({ kind: 'drag', ...rest }),
    runHid,
    stats: () => ({ run: currentRun, perRun, total }),
    geom: { toAbsolute, toNormalized, centerOf, screenAt },
  }
}

export default {
  DEFAULT_PLUGIN, CU_SUBDIR, SELF_TITLE_RE, MAX_KEYS_PER_RUN, KEEP_RUNS, MAX_SHOT_KB,
  HOTKEY_ALLOW, HOTKEY_SELF_ONLY, HOTKEY_SCREENSHOT,
  normalizeKeys, guardHotkey, guardTarget, installExitGuard,
  readKeyState, releaseStuckKeys, runPy, loadCuBackend, createComputerUse,
}
