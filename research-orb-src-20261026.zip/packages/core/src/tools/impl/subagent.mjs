// packages/core/src/tools/impl/subagent.mjs
//
// 【S45 · P1】只读子代理 spawn_researcher —— 把"翻资料"这件活派出去，
// 但不给它写权限、不给它猜的权利。
//
// 七条硬口径（与其它 impl 同一套纪律，写成注释是因为这里的每一条都是闸）：
//   1. **只读**：内部只用 fs 的读系列；零落盘 —— 除了一条审计行，什么都不往磁盘写；
//   2. **能力白名单**：只有 read / glob / grep / web_fetch（+read_image 形态占位）。
//      write / shell / net.post / spawn / task 一律拒绝（E_SUBAGENT_CAP_DENIED）；
//   3. **maxDepth:1**：目录只列一层、**子代理不可再派子代理**、相对路径只准一段；
//   4. **成本闸门**：预估读取字节 / 24576 < 1.5 → 不派（cheap-enough），审计 subagent-skip；
//      价不平的活自己干 —— 派一次的开销远大于主会话自己读两三个文件；
//   5. **回传封顶**：≤8192 token（按项目既有口径 中文≈0.5 token/字符 折算 16384 字符），
//      超了按节截断并回一行 "Found X of Y"，绝不让"没显示"偷偷变成"没有"；
//   6. **证据契约**：每条结论带 文件:行 或 URL；做不到就写【无法验证+原因】，**禁止猜**；
//   7. **抽查作废**：主会话用 verifyEvidence() 复核任意一条；抽不到 → 作废并审计 subagent-void。
//
// 纯 node 可测：不 import electron；fs / net / 审计出口全部可注入。

import { createRequire } from 'node:module'
import { basename, extname, join } from 'node:path'

import { defineTool } from '../registry.mjs'
import { looksText, sha256Hex } from './support.mjs'
import { appendJsonl, logPath } from '../../safefs.mjs'
import { ALLOWED_DOMAINS, hostOf, isAllowedUrl, redactUrl } from '../../net.mjs'

const require_ = createRequire(import.meta.url)
const defaultFs = () => require_('node:fs')

// ---------------------------------------------------------------- 常量

/** 工具 id：registry 硬性要求 小写.小写（TOOL_ID_RE 不接受下划线）。 */
export const SUBAGENT_TOOL_ID = 'researcher.spawn'
/** 对外俗称（文档/命令里叫它 spawn_researcher）。 */
export const SUBAGENT_TOOL_ALIAS = 'spawn_researcher'
export const SUBAGENT_LOG = 'subagent.jsonl'

/** 成本闸门的基准与倍率：预估字节 / CHEAP_BASE_BYTES < CHEAP_RATIO → 不派。 */
export const CHEAP_BASE_BYTES = 24576
export const CHEAP_RATIO = 1.5
export const CHEAP_THRESHOLD_BYTES = CHEAP_BASE_BYTES * CHEAP_RATIO // 36864

/** 回传封顶：≤8192 token；token 估算沿用四层记忆的口径（中文≈0.5 token/字符，非精确 tokenizer）。 */
export const MAX_OUTPUT_TOKENS = 8192
export const TOKEN_PER_CHAR = 0.5
export const MAX_OUTPUT_CHARS = Math.floor(MAX_OUTPUT_TOKENS / TOKEN_PER_CHAR) // 16384

/** 预算：默认最多读 2MB；单文件最多读 64KB；grep 命中最多留 200 行。 */
export const DEFAULT_BUDGET_BYTES = 2 * 1024 * 1024
export const READ_LIMIT_BYTES = 64 * 1024
export const MAX_LINE_MATCHES = 200
export const MAX_RETURNED_EVIDENCE = 80

/** maxDepth：目录一层、相对路径一段、不可再委派。 */
export const MAX_DEPTH = 1

export const MAX_PATHS = 20
export const MAX_URLS = 10
export const MAX_KEYWORDS = 10

/** 允许的能力白名单。多一个都不给。 */
export const ALLOWED_CAPABILITIES = Object.freeze(['read', 'glob', 'grep', 'web_fetch', 'read_image'])
/** 明确禁止的能力（命中就拒，用来挡住"顺便帮我写一下"这类请求）。 */
export const FORBIDDEN_CAPABILITIES = Object.freeze([
  'write', 'edit', 'delete', 'move', 'copy', 'shell', 'exec', 'bash', 'powershell',
  'spawn', 'task', 'agent', 'net.post', 'net.request', 'db',
])
export const READ_IMAGE_EXTS = Object.freeze(['.png', '.jpg', '.jpeg', '.gif', '.bmp', '.webp'])

/** 无法验证的固定前缀：**必须是这一句**，主会话与验收都按它识别。 */
export const UNVERIFIABLE_PREFIX = '【无法验证+原因：'

// ---------------------------------------------------------------- 小工具

const norm = (s) => String(s == null ? '' : s).replace(/\r/g, '').trim()

/** 引用格式：文件用 文件:行，网页用 URL。 */
function refOfFile(path, line) {
  return `${path}:${Number.isFinite(line) ? line : 0}`
}

/** 相对路径段数（绝对路径/UNC/别名前缀返回 null —— 交给调用方的授权根去把关）。 */
export function relDepth(raw) {
  const s = String(raw == null ? '' : raw).replace(/\//g, '\\')
  if (/^[A-Za-z]:\\/.test(s) || s.startsWith('\\\\')) return null
  if (/^[A-Za-z][A-Za-z0-9_-]+:/.test(s)) return null // project: / desktop: 等别名
  const segs = s.split('\\').filter((x) => x && x !== '.' && x !== '..')
  return segs.length
}

/**
 * maxDepth 校验（第三条口径的三张脸）。
 * @returns {null|{code:string, reason:string}}
 */
export function checkDepth({ maxDepth = MAX_DEPTH, capabilities = [], paths = [], requestedDepth = 1 } = {}) {
  if (requestedDepth > maxDepth) {
    return { code: 'E_SUBAGENT_DEPTH', reason: `委派深度 ${requestedDepth} 超过上限 ${maxDepth}（子代理不可再派子代理）` }
  }
  for (const c of capabilities) {
    const k = String(c).toLowerCase()
    if (k === 'spawn' || k === 'task' || k === 'agent') {
      return { code: 'E_SUBAGENT_DEPTH', reason: `能力 ${c} 意味着二次委派，maxDepth:${maxDepth} 下禁止` }
    }
  }
  for (const p of paths) {
    if (String(p).includes('**')) {
      return { code: 'E_SUBAGENT_DEPTH', reason: `路径 ${p} 含 ** 递归通配，maxDepth:${maxDepth} 下禁止` }
    }
    const d = relDepth(p)
    if (d !== null && d > maxDepth) {
      return { code: 'E_SUBAGENT_DEPTH', reason: `相对路径 ${p} 有 ${d} 层，超过 maxDepth:${maxDepth}` }
    }
  }
  return null
}

/** 能力白名单校验。越权一律拒，零执行。 */
export function checkCapabilities(capabilities = []) {
  if (!Array.isArray(capabilities)) return { code: 'E_SUBAGENT_CAP_DENIED', reason: 'capabilities 必须是数组' }
  for (const c of capabilities) {
    const k = String(c).toLowerCase()
    // spawn/task/agent 不是"越权"，是"二次委派" —— 由 checkDepth 统一报到 E_SUBAGENT_DEPTH
    if (k === 'spawn' || k === 'task' || k === 'agent') continue
    if (FORBIDDEN_CAPABILITIES.includes(k)) {
      return { code: 'E_SUBAGENT_CAP_DENIED', reason: `能力 ${c} 不在只读白名单内（允许：${ALLOWED_CAPABILITIES.join(' / ')}）` }
    }
    if (!ALLOWED_CAPABILITIES.includes(k)) {
      return { code: 'E_SUBAGENT_CAP_DENIED', reason: `未登记的能力 ${c}（允许：${ALLOWED_CAPABILITIES.join(' / ')}）` }
    }
  }
  return null
}

/** 路径自守：绕过 executor 直接调用时也要挡住穿越与 UNC。 */
export function checkPath(raw) {
  const s = String(raw == null ? '' : raw)
  if (!s) return { code: 'E_BAD_PATH', reason: '路径为空' }
  if (s.split(/[\\/]/).includes('..')) return { code: 'E_TRAVERSAL', reason: `${s} 含 .. 上行段` }
  if (s.startsWith('\\\\') || s.startsWith('//')) return { code: 'E_UNC', reason: `${s} 是 UNC 网络路径` }
  return null
}

// ---------------------------------------------------------------- 预估与闸门

/**
 * 预估"这次要读多少字节"。目录按一层累加（maxDepth:1，不递归）。
 * @returns {{estimatedBytes:number, items:Array, denied:Array}}
 */
export function estimateBytes(rawPaths = [], { fs = null, maxDepth = MAX_DEPTH } = {}) {
  const useFs = fs || defaultFs()
  const items = []
  const denied = []
  let estimatedBytes = 0
  for (const raw of rawPaths.slice(0, MAX_PATHS)) {
    const bad = checkPath(raw)
    if (bad) {
      denied.push({ path: raw, ...bad })
      continue
    }
    try {
      const st = useFs.statSync(raw)
      if (st.isDirectory()) {
        let kids = []
        try {
          kids = useFs.readdirSync(raw, { withFileTypes: true })
        } catch {
          kids = []
        }
        let dirBytes = 0
        let count = 0
        for (const k of kids) {
          if (count >= MAX_RETURNED_EVIDENCE) break
          const full = join(raw, k.name)
          let sub = null
          try {
            sub = useFs.statSync(full)
          } catch {
            sub = null
          }
          if (sub && sub.isFile()) {
            dirBytes += Math.min(sub.size, READ_LIMIT_BYTES)
            count += 1
          } else if (sub && sub.isDirectory()) {
            count += 1
          }
        }
        estimatedBytes += dirBytes
        items.push({ path: raw, kind: 'dir', entries: count, bytes: dirBytes })
      } else {
        estimatedBytes += Math.min(st.size, READ_LIMIT_BYTES)
        items.push({ path: raw, kind: 'file', bytes: Math.min(st.size, READ_LIMIT_BYTES), realBytes: st.size })
      }
    } catch {
      // 不存在/不可读：仍然算一条"会被读"的目标（0 字节），由采集阶段写成无法验证证据
      items.push({ path: raw, kind: 'missing', bytes: 0 })
    }
  }
  return { estimatedBytes, items, denied }
}

/**
 * 成本闸门：`预估字节 / 24576 < 1.5` → 不派。
 * 不是"省事"，是"派一次的开销（读时延+回传+抽查）不值这点量"。
 */
export function shouldDelegate(estimatedBytes) {
  const bytes = Number.isFinite(estimatedBytes) ? estimatedBytes : 0
  const ratio = bytes / CHEAP_BASE_BYTES
  const cheapEnough = ratio < CHEAP_RATIO
  return {
    delegate: !cheapEnough,
    cheapEnough,
    ratio: Math.round(ratio * 1000) / 1000,
    baseBytes: CHEAP_BASE_BYTES,
    thresholdRatio: CHEAP_RATIO,
    thresholdBytes: CHEAP_THRESHOLD_BYTES,
  }
}

// ---------------------------------------------------------------- 采集（只读）

/** 按行求关键词命中，行号必须真实 —— 抽查就按这个行号复核。 */
function grepLines(text, keywords) {
  const lines = text.split('\n')
  const kws = keywords.map((k) => String(k).toLowerCase()).filter(Boolean)
  const hits = []
  for (let i = 0; i < lines.length; i += 1) {
    const low = lines[i].toLowerCase()
    if (kws.some((k) => low.includes(k))) {
      hits.push({ line: i + 1, content: lines[i] })
      if (hits.length >= MAX_LINE_MATCHES) break
    }
  }
  return hits
}

/** 读文件：限定字节数，按最后一个换行补齐，保证行边界不撕裂。 */
function readTextLimited(fs, p, limitBytes = READ_LIMIT_BYTES) {
  const fd = fs.openSync(p, 'r')
  try {
    const st = fs.fstatSync(fd)
    const want = Math.min(st.size, limitBytes)
    const buf = Buffer.alloc(want)
    let readN = 0
    while (readN < want) {
      const n = fs.readSync(fd, buf, readN, want - readN, readN)
      if (n <= 0) break
      readN += n
    }
    const tailBuf = readN < want ? buf.subarray(0, readN) : buf
    const nl = tailBuf.lastIndexOf(0x0a)
    const cut = nl < 0 ? tailBuf : tailBuf.subarray(0, nl + 1)
    return { text: cut.toString('utf8'), bytes: cut.length, realBytes: st.size, truncated: st.size > cut.length }
  } finally {
    try {
      fs.closeSync(fd)
    } catch {
      /* 关闭失败不致命 */
    }
  }
}

/** 采一条本地路径：返回 evidence 数组。 */
function collectPath(raw, { fs, keywords, capabilities, maxDepth }) {
  const useFs = fs || defaultFs()
  const badPath = checkPath(raw)
  if (badPath) {
    return [{ ref: `${raw}:0`, kind: 'unverifiable', line: 0, path: raw, unverifiable: true, note: `${UNVERIFIABLE_PREFIX}${badPath.reason}】` }]
  }
  let st = null
  try {
    st = useFs.statSync(raw)
  } catch {
    st = null
  }
  if (!st) {
    return [{
      ref: `${raw}:0`, kind: 'unverifiable', line: 0, path: raw, unverifiable: true,
      note: `${UNVERIFIABLE_PREFIX}文件不存在或不可读 \`${raw}\`】`,
    }]
  }

  if (st.isDirectory()) {
    if (capabilities.length > 0 && !capabilities.includes('glob')) {
      return [{
        ref: `${raw}:0`, kind: 'unverifiable', unverifiable: true, path: raw,
        note: `${UNVERIFIABLE_PREFIX}目录需要 glob 能力，本轮未授权】`,
      }]
    }
    let kids = []
    try {
      kids = useFs.readdirSync(raw, { withFileTypes: true })
    } catch {
      kids = []
    }
    const names = kids.slice(0, MAX_RETURNED_EVIDENCE).map((k) => (k.isDirectory() ? `${k.name}/` : k.name))
    // maxDepth:1 —— 这里**只有一层**，绝不递归
    return [{
      ref: `${raw}:0`, kind: 'glob', line: 0, path: raw, unverifiable: false,
      lineContent: names.join(' '),
      note: `目录 ${raw} 一层共 ${kids.length} 项（maxDepth:${maxDepth}，未递归）`,
      entries: kids.length,
    }]
  }

  const ext = extname(raw).toLowerCase()
  if (READ_IMAGE_EXTS.includes(ext)) {
    if (!capabilities.includes('read_image')) {
      return [{
        ref: `${raw}:0`, kind: 'unverifiable', unverifiable: true, path: raw, line: 0,
        note: `${UNVERIFIABLE_PREFIX}read_image 能力未授权，\`${basename(raw)}\` 无法解读】`,
      }]
    }
    return [{
      ref: `${raw}:0`, kind: 'image', unverifiable: true, path: raw, line: 0,
      note: `${UNVERIFIABLE_PREFIX}本轮未接入图像解读模型，只能确认存在（${st.size} 字节），不能描述画面】`,
      bytes: st.size,
    }]
  }

  if (capabilities.length > 0 && !capabilities.includes('read') && !capabilities.includes('grep')) {
    return [{
      ref: `${raw}:0`, kind: 'unverifiable', unverifiable: true, path: raw, line: 0,
      note: `${UNVERIFIABLE_PREFIX}read/grep 能力未授权】`,
    }]
  }

  // 二进制不硬解释
  let head = null
  try {
    const fd = useFs.openSync(raw, 'r')
    try {
      const probe = Buffer.alloc(Math.min(4096, st.size))
      const n = useFs.readSync(fd, probe, 0, probe.length, 0)
      head = n <= 0 ? Buffer.alloc(0) : probe.subarray(0, n)
    } finally {
      useFs.closeSync(fd)
    }
  } catch {
    head = Buffer.alloc(0)
  }
  if (st.size > 0 && !looksText(head)) {
    let hash = null
    try {
      hash = sha256Hex(useFs.readFileSync(raw).subarray(0, Math.min(st.size, READ_LIMIT_BYTES)))
    } catch {
      hash = null
    }
    return [{
      ref: `${raw}:0`, kind: 'unverifiable', unverifiable: true, path: raw, line: 0,
      note: `${UNVERIFIABLE_PREFIX}疑似二进制内容（${st.size} 字节），无可读文本行】`,
      bytes: st.size, hash12: hash ? hash.slice(0, 12) : null,
    }]
  }

  const { text, bytes, realBytes, truncated } = readTextLimited(useFs, raw)
  const kws = (keywords || []).filter(Boolean)
  if (kws.length > 0) {
    // grep 模式：只给命中行，每行都带真实行号
    const hits = grepLines(text, kws)
    if (hits.length === 0) {
      return [{
        ref: `${raw}:0`, kind: 'grep', unverifiable: true, path: raw, line: 0,
        note: `${UNVERIFIABLE_PREFIX}已读 ${bytes} 字节（实际 ${realBytes} 字节${truncated ? '，已截断' : ''}），但关键词 ${kws.join(' / ')} 无命中】`,
        bytes,
      }]
    }
    if (capabilities.length > 0 && !capabilities.includes('grep')) {
      return [{
        ref: `${raw}:0`, kind: 'unverifiable', unverifiable: true, path: raw, line: 0,
        note: `${UNVERIFIABLE_PREFIX}命中行需要 grep 能力，本轮未授权】`,
      }]
    }
    return hits.map((h) => ({
      ref: refOfFile(raw, h.line), kind: 'grep', line: h.line, path: raw,
      lineContent: h.content, unverifiable: false,
      _readBytes: bytes, _realBytes: realBytes, _readTruncated: truncated,
    }))
  }

  const lines = text.split('\n')
  const firstLines = lines.slice(0, 40)
  return [{
    ref: refOfFile(raw, 1), kind: 'read', line: 1, path: raw,
    lineContent: firstLines[0] || '',
    note: `read ${basename(raw)}：${bytes}/${realBytes} 字节${truncated ? '（已截断）' : ''}，共 ${lines.length} 行`,
    bytes,
    _readBytes: bytes, _realBytes: realBytes, _readTruncated: truncated,
  }]
}

/** 采一个 URL：白名单外零请求；没出网能力就如实写无法验证。 */
async function collectUrl(url, { net, budgetLeft }) {
  const host = hostOf(url)
  if (!isAllowedUrl(url)) {
    return [{
      ref: url, kind: 'unverifiable', unverifiable: true,
      note: `${UNVERIFIABLE_PREFIX}域名 ${host ?? '<无法解析>'} 不在白名单（允许 ${ALLOWED_DOMAINS.length} 个域），已零请求拒绝】`,
    }]
  }
  if (!net || typeof net.request !== 'function') {
    return [{
      ref: url, kind: 'unverifiable', unverifiable: true,
      note: `${UNVERIFIABLE_PREFIX}本轮未注入出网能力，无法访问 ${redactUrl(url)}】`,
    }]
  }
  try {
    const res = await net.request(url, { method: 'GET', limitKey: 'tool:researcher.spawn' })
    if (!res || !res.ok) {
      return [{
        ref: url, kind: 'unverifiable', unverifiable: true,
        note: `${UNVERIFIABLE_PREFIX}HTTP ${res ? res.status : '?'} <- ${redactUrl(url)}】`,
      }]
    }
    const body = String((await res.text()) || '')
    const cut = body.slice(0, Math.min(8000, Math.max(0, budgetLeft)))
    return [{
      ref: url, kind: 'web', unverifiable: false, lineContent: cut,
      note: `web_fetch ${redactUrl(url)}：取回 ${cut.length}/${body.length} 字符`,
      bytes: Buffer.byteLength(cut, 'utf8'),
    }]
  } catch (err) {
    return [{
      ref: url, kind: 'unverifiable', unverifiable: true,
      note: `${UNVERIFIABLE_PREFIX}请求失败 ${String((err && err.message) || err).slice(0, 120)}】`,
    }]
  }
}

// ---------------------------------------------------------------- 组装输出

/**
 * 组装回传正文。**超了就砍**，并回一行 Found X of Y —— 绝不让"没显示"变成"没有"。
 */
export function buildOutput({ goal, evidence, keywords = [], scannedTotal = null, coverage = null }) {
  const head = []
  head.push(`# 子代理回传（${SUBAGENT_TOOL_ALIAS}）`)
  head.push('')
  head.push(`目标：${goal}`)
  if (keywords.length > 0) head.push(`关键词：${keywords.join(' / ')}`)
  if (coverage && coverage.readBytes > 0) {
    const c = coverage
    head.push(
      `覆盖：读了 ${c.targets} 个目标，实读 ${c.readBytes}/${c.realBytes} 字节` +
        `（单文件上限 ${READ_LIMIT_BYTES} 字节，超出部分本轮未读 —— 命中范围只覆盖已读部分）`,
    )
  }
  head.push('')

  const okEvidence = evidence.filter((e) => !e.unverifiable)
  const badEvidence = evidence.filter((e) => e.unverifiable)
  // Y 必须是**扫描到的真实总数**（返回条数被 MAX_RETURNED_EVIDENCE 截短时 Y≠X，
  // 否则"回传了 80 条"会被读成"一共只有 80 条"。见 docs\CTX-DISCIPLINE.md）
  const Y = Number.isFinite(scannedTotal) ? scannedTotal : evidence.length

  const body = []
  body.push(`## 带引用的证据 Found ${okEvidence.length} of ${Y}`)
  for (const e of okEvidence) {
    if (e.kind === 'glob') body.push(`- [${e.ref}] ${e.note}：${String(e.lineContent || '').slice(0, 300)}`)
    else if (e.kind === 'web') body.push(`- [${e.ref}] ${String(e.lineContent || '').slice(0, 600)}`)
    else body.push(`- [${e.ref}] ${String(e.lineContent == null ? e.note || '' : e.lineContent).replace(/\s+$/, '')}`)
  }
  body.push('')
  body.push(`## 无法验证（禁止据此作答）Found ${badEvidence.length} of ${Y}`)
  if (badEvidence.length === 0) body.push('- 无')
  else for (const e of badEvidence) body.push(`- [${e.ref}] ${e.note}`)

  const raw = head.concat(body).join('\n')
  // 截断横幅本身也占字符，所以先从预算里把它扣掉 —— 否则最后一 token 会被横幅挤出去，
  // 8192 的封顶就名不副实（实锤：横幅 ~60 字符 → 8192 变 8223）。
  const bannerOf = (shown) =>
    `\n\nFound ${shown} of ${raw.length} 字符（已截断；总数为 ${raw.length}，不得只依据已显示部分作答）`
  const keep = Math.max(0, MAX_OUTPUT_CHARS - bannerOf(MAX_OUTPUT_CHARS).length)
  const shown = Math.min(raw.length, keep)
  const truncated = raw.length > shown
  const text = truncated ? raw.slice(0, shown) + bannerOf(shown) : raw
  return {
    text,
    coverage: coverage || null,
    scannedTotal: Y,
    outputTokens: Math.ceil(text.length * TOKEN_PER_CHAR),
    evidenceCount: evidence.length,
    verifiedCount: okEvidence.length,
    unverifiableCount: badEvidence.length,
    truncated,
    rawChars: raw.length,
    shownChars: shown,
  }
}

// ---------------------------------------------------------------- 审计

/** 写一条审计。默认出口：data\logs\subagent.jsonl（ORB_LOG_DIR 隔离时跟着走）。 */
export function appendSubagentAudit(rec, deps = {}) {
  const file = deps.logFile || logPath(SUBAGENT_LOG)
  const write = typeof deps.audit === 'function' ? deps.audit : (entry) => {
    try {
      appendJsonl(file, entry)
    } catch (err) {
      process.stderr.write(`[research-orb/subagent] 审计写入失败：${err && err.message}\n`)
    }
  }
  write(rec)
  return file
}

/** 读审计（验收/面板用）。 */
export function readSubagentAudit({ logFile = null, fs = null } = {}) {
  const useFs = fs || defaultFs()
  const file = logFile || logPath(SUBAGENT_LOG)
  try {
    if (!useFs.existsSync(file)) return []
    return String(useFs.readFileSync(file, 'utf8'))
      .split('\n')
      .filter((l) => l.trim())
      .map((l) => {
        try {
          return JSON.parse(l)
        } catch {
          return null
        }
      })
      .filter(Boolean)
  } catch {
    return []
  }
}

// ---------------------------------------------------------------- 主入口

/**
 * 派一次只读研究员。**任何失败都不抛**——返回结构化结果，主会话照常继续。
 *
 * @param {{
 *   goal: string, paths?: string[], urls?: string[], keywords?: string[],
 *   budgetBytes?: number, maxDepth?: number, capabilities?: string[], sessionId?: string,
 * }} input
 * @param {{fs?: object, net?: object, audit?: Function, logFile?: string, now?: Function}} [deps]
 */
export async function spawnResearcher(input = {}, deps = {}) {
  const t0 = (deps.now || Date.now)()
  const fs = deps.fs || defaultFs()
  const net = deps.net || null
  const goal = String(input.goal || '').trim()
  const paths = Array.isArray(input.paths) ? input.paths.slice(0, MAX_PATHS) : []
  const urls = Array.isArray(input.urls) ? input.urls.slice(0, MAX_URLS) : []
  const keywords = Array.isArray(input.keywords) ? input.keywords.slice(0, MAX_KEYWORDS) : []
  const budgetBytes = Number.isFinite(input.budgetBytes) ? input.budgetBytes : DEFAULT_BUDGET_BYTES
  const maxDepth = Number.isFinite(input.maxDepth) ? input.maxDepth : MAX_DEPTH
  const capabilities = Array.isArray(input.capabilities) ? input.capabilities : []

  const auditBase = {
    ts: new Date().toISOString(),
    toolId: SUBAGENT_TOOL_ID,
    alias: SUBAGENT_TOOL_ALIAS,
    goal,
    paths,
    urls,
    budgetBytes,
    sessionId: input.sessionId || null,
    maxDepth,
    capabilities,
  }

  const finish = (payload, auditExtra) => {
    const rec = {
      ...auditBase,
      ok: !!payload.ok,
      skipped: !!payload.skipped,
      code: payload.code || null,
      skipReason: payload.skipReason || null,
      actualBytes: Number.isFinite(payload.actualBytes) ? payload.actualBytes : 0,
      outputTokens: Number.isFinite(payload.outputTokens) ? payload.outputTokens : 0,
      evidenceCount: payload.evidence ? payload.evidence.length : 0,
      scannedTotal: Number.isFinite(payload.scannedTotal) ? payload.scannedTotal : 0,
      voidReason: payload.voidReason || null,
      durationMs: (deps.now || Date.now)() - t0,
      ...auditExtra,
    }
    payload.audit = rec
    payload.auditFile = deps.logFile || null
    appendSubagentAudit(rec, deps)
    return payload
  }

  // ① 参数自守
  if (!goal) return finish({ ok: false, code: 'E_BAD_ARGS', evidence: [], output: '', outputTokens: 0, actualBytes: 0 })
  const capBad = checkCapabilities(capabilities)
  if (capBad) return finish({ ok: false, code: capBad.code, message: capBad.reason, evidence: [], output: '', outputTokens: 0, actualBytes: 0 })
  const depthBad = checkDepth({ maxDepth, capabilities, paths, requestedDepth: Number.isFinite(input.delegationDepth) ? input.delegationDepth : 1 })
  if (depthBad) return finish({ ok: false, code: depthBad.code, message: depthBad.reason, evidence: [], output: '', outputTokens: 0, actualBytes: 0 })

  // ② 预估 + 成本闸门
  const est = estimateBytes(paths, { fs, maxDepth })
  if (est.denied.length > 0) {
    const evidence = est.denied.map((d) => ({
      ref: `${d.path}:0`, kind: 'unverifiable', unverifiable: true, path: d.path, line: 0,
      note: `${UNVERIFIABLE_PREFIX}${d.reason}】`,
    }))
    const built = buildOutput({ goal, evidence, keywords })
    return finish({
      ok: false, code: est.denied[0].code, message: est.denied[0].reason,
      evidence, output: built.text, outputTokens: built.outputTokens, actualBytes: 0, estimatedBytes: est.estimatedBytes,
    })
  }
  const gate = shouldDelegate(est.estimatedBytes)
  if (!gate.delegate) {
    // 价不平：不派。主会话自己读。
    return finish({
      ok: true,
      skipped: true,
      skipReason: 'cheap-enough',
      code: null,
      evidence: [],
      output: '',
      outputTokens: 0,
      actualBytes: 0,
      estimatedBytes: est.estimatedBytes,
      gate,
    })
  }
  // ③ 预算
  if (est.estimatedBytes > budgetBytes) {
    return finish({
      ok: false, code: 'E_SUBAGENT_OVER_BUDGET',
      message: `预估要读 ${est.estimatedBytes} 字节，超过预算 ${budgetBytes} 字节（缩小范围或提高预算后再派）`,
      evidence: [], output: '', outputTokens: 0, actualBytes: 0, estimatedBytes: est.estimatedBytes, gate,
    })
  }

  // ④ 采集（只读）。scanned 是**扫描到的真实总数**，与回传条数分离：
  //    回传可能被 MAX_RETURNED_EVIDENCE 截短，但 Y 必须是真实的那个数。
  const evidence = []
  let actualBytes = 0
  let scanned = 0
  const seen = new Set()
  let readBytes = 0
  let realBytesTotal = 0
  for (const p of paths) {
    const evs = collectPath(p, { fs, keywords, capabilities, maxDepth })
    scanned += evs.length
    for (const e of evs) {
      // 覆盖口径按文件去重：同一文件的多条 grep 命中只计一次读取量
      if (e.path && !seen.has(e.path) && Number.isFinite(e._readBytes)) {
        seen.add(e.path)
        readBytes += e._readBytes
        realBytesTotal += Number.isFinite(e._realBytes) ? e._realBytes : e._readBytes
      }
      actualBytes += Math.min(Number.isFinite(e.bytes) ? e.bytes : 0, READ_LIMIT_BYTES)
      if (evidence.length < MAX_RETURNED_EVIDENCE) evidence.push(e)
    }
  }
  for (const u of urls) {
    const got = await collectUrl(u, { net, budgetLeft: budgetBytes - actualBytes })
    scanned += got.length
    for (const e of got) {
      actualBytes += Math.min(Number.isFinite(e.bytes) ? e.bytes : 0, READ_LIMIT_BYTES)
      if (evidence.length < MAX_RETURNED_EVIDENCE) evidence.push(e)
    }
  }

  // ⑤ 组装 + 封顶
  const built = buildOutput({
    goal,
    evidence,
    keywords,
    scannedTotal: scanned,
    coverage: { targets: seen.size, readBytes, realBytes: realBytesTotal },
  })
  return finish({
    ok: true,
    skipped: false,
    code: null,
    evidence,
    output: built.text,
    outputTokens: built.outputTokens,
    actualBytes,
    estimatedBytes: est.estimatedBytes,
    gate,
    scannedTotal: scanned,
    coverage: built.coverage,
    found: { returned: evidence.length, total: scanned, verified: built.verifiedCount, unverifiable: built.unverifiableCount },
    truncated: built.truncated,
    rawChars: built.rawChars,
    shownChars: built.shownChars,
  })
}

// ---------------------------------------------------------------- 抽查

/**
 * 主会话复核一条证据。**抽不到就作废**，并追加一行 subagent-void。
 * @param {{ref:string, lineContent?:string}} item
 * @param {{fs?:object, net?:object, audit?:Function, logFile?:string, now?:Function}} [deps]
 */
export async function verifyEvidence(item = {}, deps = {}) {
  const fs = deps.fs || defaultFs()
  const net = deps.net || null
  const ref = String(item.ref || '')
  const voidIt = (why, extra = {}) => {
    appendSubagentAudit({
      ts: new Date().toISOString(),
      toolId: SUBAGENT_TOOL_ID,
      alias: SUBAGENT_TOOL_ALIAS,
      auditType: 'subagent-void',
      ref,
      why,
      ...extra,
    }, deps)
    return { ok: false, ref, code: 'E_EVIDENCE_VOID', why, voided: true }
  }

  if (/^https?:\/\//i.test(ref)) {
    const allowed = isAllowedUrl(ref)
    if (!allowed) return voidIt(`URL 证据 ${redactUrl(ref)} 不在域名白名单`)
    if (!net || typeof net.request !== 'function') return voidIt('本轮未注入出网能力，无法复核 URL 证据')
    try {
      const res = await net.request(ref, { method: 'GET', limitKey: 'tool:researcher.spawn' })
      if (!res || !res.ok) return voidIt(`复核请求失败 HTTP ${res ? res.status : '?'}`)
      const body = String((await res.text()) || '')
      const probe = String(item.lineContent || '').slice(0, 200)
      const hit = !probe || body.includes(probe)
      if (!hit) return voidIt('URL 正文里找不到回传引用的那段内容')
      return { ok: true, ref, matched: true, voided: false }
    } catch (err) {
      return voidIt(`复核请求异常：${String((err && err.message) || err).slice(0, 120)}`)
    }
  }

  const m = /^([\s\S]*):(\d+)$/.exec(ref)
  if (!m) return voidIt('引用格式不是 文件:行，无法复核')
  const path = m[1]
  const line = Number(m[2])
  if (!Number.isFinite(line) || line <= 0) return voidIt('行号非法')

  try {
    if (!fs.existsSync(path)) return voidIt(`文件不存在 ${path}`)
  } catch {
    return voidIt(`文件不可访问 ${path}`)
  }
  let lines = []
  try {
    const st = fs.statSync(path)
    const { text } = readTextLimited(fs, path, Math.max(READ_LIMIT_BYTES, st.size))
    lines = text.split('\n')
  } catch (err) {
    return voidIt(`读取失败：${String((err && err.message) || err).slice(0, 120)}`)
  }
  if (line > lines.length) return voidIt(`第 ${line} 行不存在（文件只有 ${lines.length} 行）`)
  const got = lines[line - 1]
  const want = String(item.lineContent == null ? '' : item.lineContent)
  const g = norm(got)
  const w = norm(want)
  if (!w) return voidIt('回传没有记录行内容，无法复核')
  const matched = g === w || g.includes(w) || w.includes(g)
  if (!matched) return voidIt(`第 ${line} 行与回传内容不一致`, { got: g.slice(0, 200), expected: w.slice(0, 200) })
  return { ok: true, ref, line, matched: true, got: g, voided: false }
}

/** 便捷：抽查一次回传里的第一条可复核证据（任务书要求"抽查 ≥1 条"）。 */
export async function spotCheckReport(result = {}, deps = {}) {
  const list = Array.isArray(result.evidence) ? result.evidence : []
  const target = list.find((e) => e && !e.unverifiable && e.kind !== 'glob')
  if (!target) return { ok: false, code: 'E_NO_CHECKABLE', why: '回传里没有可复核的带引用证据' }
  const r = await verifyEvidence(target, deps)
  return { ...r, checkedRef: target.ref, totalEvidence: list.length }
}

// ---------------------------------------------------------------- 登记成工具

/**
 * @param {object} registry
 * @param {{fs?: object, net?: object, audit?: Function, logFile?: string}} [deps]
 */
export function registerSubagentTools(registry, deps = {}) {
  registry.register(
    defineTool({
      id: SUBAGENT_TOOL_ID,
      label: '派只读研究员',
      description:
        `派一个只读研究员去翻资料（俗称 ${SUBAGENT_TOOL_ALIAS}）：只能用 read/glob/grep/web_fetch，` +
        `不能写、不能跑命令、不能再派子代理（maxDepth:${MAX_DEPTH}）；` +
        `回传 ≤${MAX_OUTPUT_TOKENS} token，每条结论带 文件:行 或 URL，做不到写【无法验证+原因】。` +
        `预估读取量小于 ${CHEAP_THRESHOLD_BYTES} 字节时不派（cheap-enough），主会话自己读。`,
      params: {
        type: 'object',
        properties: {
          goal: { type: 'string', minLength: 4, maxLength: 400, description: '这一轮要回答的问题（越具体越好）' },
          paths: { type: 'array', maxItems: MAX_PATHS, items: { type: 'string' }, description: '要读的文件或一层目录' },
          urls: { type: 'array', maxItems: MAX_URLS, items: { type: 'string' }, description: '要抓的 https 地址（必须命中域名白名单）' },
          keywords: { type: 'array', maxItems: MAX_KEYWORDS, items: { type: 'string' }, description: '关键词；给了就走 grep 模式，只回命中行' },
          budgetBytes: { type: 'integer', minimum: 1, maximum: 8 * 1024 * 1024, description: `本次最多读多少字节，默认 ${DEFAULT_BUDGET_BYTES}` },
          maxDepth: { type: 'integer', minimum: 1, maximum: 1, description: '恒为 1：目录只列一层、不可二次委派' },
          capabilities: { type: 'array', items: { type: 'string', enum: [...ALLOWED_CAPABILITIES] }, description: '本次只开放哪些只读能力；留空=全部开放' },
        },
        required: ['goal'],
        additionalProperties: false,
      },
      targetsOf: (a) => (Array.isArray(a.paths) ? a.paths.slice(0, MAX_PATHS) : []),
      timeoutMs: 60000,
      async run(args, ctx) {
        const r = await spawnResearcher({ ...args, sessionId: ctx && ctx.sessionId ? ctx.sessionId : null }, deps)
        if (typeof ctx.emit === 'function') {
          ctx.emit({ type: 'subagent:done', ok: r.ok, skipped: r.skipped, evidenceCount: r.evidence ? r.evidence.length : 0 })
        }
        return r
      },
    }),
  )
}

export default {
  SUBAGENT_TOOL_ID, SUBAGENT_TOOL_ALIAS, SUBAGENT_LOG,
  CHEAP_BASE_BYTES, CHEAP_RATIO, CHEAP_THRESHOLD_BYTES,
  MAX_OUTPUT_TOKENS, TOKEN_PER_CHAR, MAX_OUTPUT_CHARS,
  DEFAULT_BUDGET_BYTES, READ_LIMIT_BYTES, MAX_DEPTH,
  ALLOWED_CAPABILITIES, FORBIDDEN_CAPABILITIES, UNVERIFIABLE_PREFIX,
  relDepth, checkDepth, checkCapabilities, checkPath,
  estimateBytes, shouldDelegate, buildOutput,
  appendSubagentAudit, readSubagentAudit,
  spawnResearcher, verifyEvidence, spotCheckReport, registerSubagentTools,
}
