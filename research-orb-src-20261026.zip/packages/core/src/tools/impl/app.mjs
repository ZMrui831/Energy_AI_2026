// packages/core/src/tools/impl/app.mjs
//
// 应用与窗口工具（P-R7）：app.launch / app.focus / app.list
//
// 边界：core 层**不 import electron**（否则单测与 selftest 全废）。
// Electron 专有能力由宿主注入 ctx.host.*：
//   ctx.host.windowTitles()          -> string[]          列出窗口标题
//   ctx.host.focusWindow(title)      -> {ok, title}       把某个窗口提到前台
//   ctx.host.clipboard = {read(), write(text)}
// 没有注入时走**诚实降级**：如实说"当前环境不支持"，绝不伪造窗口清单或假装已聚焦。
//
// app.launch 可执行是因为它只做一件事：把落点限定在授权根内的可执行文件/快捷方式
// 交给系统打开（detached、不接管、不注入参数）。它**不执行命令行字符串**。

import { extname } from 'node:path'
import { createRequire } from 'node:module'
import { defineTool } from '../registry.mjs'
import { resolvePath, unsupported } from './support.mjs'

const require_ = createRequire(import.meta.url)

const defaultChild = () => require_('node:child_process')
const defaultFs = () => require_('node:fs')

/** 允许被打开的文件类型（白名单；.lnk 允许，因为桌面上大多是快捷方式）。 */
export const LAUNCHABLE_EXT = Object.freeze(['.exe', '.lnk', '.bat', '.cmd', '.msc'])

/**
 * @param {object} registry
 * @param {{child?: object, fs?: object, host?: object}} [deps]
 */
export function registerAppTools(registry, deps = {}) {
  const child = deps.child || defaultChild()
  const fs = deps.fs || defaultFs()
  const host = deps.host || null

  const requireHost = (what, fnName) => {
    if (!host || typeof host[fnName] !== 'function') throw unsupported(what, `宿主未注入 ${fnName}()`)
    return host[fnName]
  }

  registry.register(
    defineTool({
      id: 'app.list',
      label: '列出窗口',
      description: '列出当前打开的窗口标题（用于确认某个应用是否已打开）。宿主未接入时如实说明不支持。',
      params: { type: 'object', properties: {}, additionalProperties: false },
      targetsOf: () => [],
      run() {
        const fn = requireHost('列出窗口', 'windowTitles')
        const titles = fn() || []
        return { count: titles.length, titles: titles.slice(0, 100), supported: true }
      },
    }),
  )

  registry.register(
    defineTool({
      id: 'app.focus',
      label: '切换窗口',
      description: '把指定标题的窗口提到前台（模糊匹配标题）。宿主未接入时如实说明不支持。',
      params: {
        type: 'object',
        properties: { title: { type: 'string', minLength: 1, description: '窗口标题或其中的一段文字' } },
        required: ['title'],
        additionalProperties: false,
      },
      targetsOf: () => [],
      run(args) {
        const fn = requireHost('切换窗口', 'focusWindow')
        const r = fn(String(args.title)) || null
        if (!r || r.ok === false) {
          const err = new Error(`没有找到标题包含「${args.title}」的窗口`)
          err.code = 'E_NOT_FOUND'
          throw err
        }
        return { ok: true, title: r.title || args.title, supported: true }
      },
    }),
  )

  registry.register(
    defineTool({
      id: 'app.launch',
      label: '打开应用',
      description:
        '打开一个应用/文档。**只接受授权根内的可执行文件、快捷方式或 bat**（.exe/.lnk/.bat/.cmd/.msc），' +
        '不接受命令行字符串 —— 避免"打开应用"变成"执行任意命令"。',
      params: {
        type: 'object',
        properties: {
          target: { type: 'string', description: '要打开的文件路径，如 desktop:某应用.lnk' },
        },
        required: ['target'],
        additionalProperties: false,
      },
      targetsOf: (a) => [a.target],
      write: true,
      timeoutMs: 20000,
      run(args, ctx) {
        const p = resolvePath(ctx, args.target, 'app.launch')
        const ext = (extname(p) || '').toLowerCase()
        if (!LAUNCHABLE_EXT.includes(ext)) {
          throw Object.assign(new Error(`只允许打开 ${LAUNCHABLE_EXT.join(' / ')} 文件，当前 ${ext || '(无扩展名)'}：${p}`), {
            code: 'E_BAD_EXT',
          })
        }
        if (!fs.existsSync(p)) throw Object.assign(new Error(`文件不存在：${p}`), { code: 'E_NOT_FOUND' })
        // detached + stdio ignore：打开后与本进程脱钩，退出球不会带走它
        const childProc = child.spawn(p, [], { detached: true, stdio: 'ignore', windowsHide: false })
        childProc.unref()
        return { launched: true, path: p, ext, pid: childProc.pid || null }
      },
    }),
  )

  return registry
}

export default { registerAppTools, LAUNCHABLE_EXT }
