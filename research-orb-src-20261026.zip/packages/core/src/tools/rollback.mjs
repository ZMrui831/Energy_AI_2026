// packages/core/src/tools/rollback.mjs
//
// 快照与回滚（P-R7）：**任何写操作之前先快照，出错或用户反悔都能复原**。
//
// 设计要点：
//   1. 快照落在 data\snapshots\<操作 id>\ 下（项目根内，随 safefs 一起受审计），
//      注意与工程快照 .snapshots\（阶段快照，另一个东西）区分开；
//   2. 快照记录里带 existed 标志：原来没有的文件，撤销时是"删掉新建的"，
//      而不是"恢复成不存在的空文件"；
//   3. 撤销按**逆序**执行，一次撤销一个操作（/undo），也支持按 id 精确撤销（/undo <id>）；
//   4. 删除类操作不真删：先快照原内容，删除动作照做，撤销即还原（等价于回收站语义）。
//
// 文件系统全部注入（默认实现才碰 node:fs），于是"写坏 → 撤销 → 内容一致"可以纯单测。

import { basename, join } from 'node:path'
import { createRequire } from 'node:module'

// 本文件是 ESM，但测试要注入假 fs，所以默认适配层延迟到真正用到时才 require。
const require_ = createRequire(import.meta.url)

export class RollbackError extends Error {
  constructor(code, message, extra = {}) {
    super(message)
    this.name = 'RollbackError'
    this.code = code
    Object.assign(this, extra)
  }
}

export const SNAPSHOT_DIRNAME = 'data/snapshots'

/** 默认文件系统适配层（真实运行时用；测试注入假实现）。 */
export function nodeFsAdapter() {
  const fsmod = require_('node:fs')
  return {
    existsSync: (p) => fsmod.existsSync(p),
    statSync: (p) => fsmod.statSync(p),
    readFileSync: (p) => fsmod.readFileSync(p),
    writeFileSync: (p, d) => fsmod.writeFileSync(p, d),
    mkdirSync: (p, o) => fsmod.mkdirSync(p, o),
    rmSync: (p, o) => fsmod.rmSync(p, o),
    copyFileSync: (a, b) => fsmod.copyFileSync(a, b),
    readdirSync: (p) => fsmod.readdirSync(p),
  }
}

/**
 * @param {{
 *   root?: string,          // 快照根（默认 data\snapshots）
 *   fs?: object,            // 注入的文件系统
 *   hash?: (buf:Buffer|string)=>string,
 * }} options
 */
export function createRollback(options = {}) {
  const fs = options.fs || nodeFsAdapter()
  const root = options.root || SNAPSHOT_DIRNAME
  const hash =
    options.hash ||
    ((data) => {
      const { createHash } = require_('node:crypto')
      return createHash('sha256').update(data).digest('hex')
    })

  /** 已登记的操作（可撤销清单），最新在最后。 */
  const entries = []
  let seq = 0

  function ensureDir(dir) {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
  }

  /**
   * 写操作之前调用：把目标现状原样抄进快照区。
   * @param {string[]} targets 绝对路径
   * @param {{toolId?: string, opId?: string}} [meta]
   * @returns {{id:string, dir:string, items:Array<{path:string, snapPath:string|null, existed:boolean, bytes:number, hash:string|null}>}}
   */
  function before(targets = [], meta = {}) {
    seq += 1
    const stamp = new Date().toISOString().replace(/[:.]/g, '-')
    const id = `${stamp}-${String(seq).padStart(3, '0')}`
    const dir = join(root, id)
    ensureDir(dir)
    const items = []
    let idx = 0
    for (const t of targets) {
      if (typeof t !== 'string' || !t) continue
      idx += 1
      let existed = false
      try {
        existed = fs.existsSync(t)
      } catch {
        existed = false
      }
      if (!existed) {
        items.push({ path: t, snapPath: null, existed: false, bytes: 0, hash: null })
        continue
      }
      try {
        const data = fs.readFileSync(t)
        const snapPath = join(dir, `${String(idx).padStart(2, '0')}-${basename(t) || 'target'}`)
        ensureDir(dir)
        fs.writeFileSync(snapPath, data)
        items.push({ path: t, snapPath, existed: true, bytes: data.length, hash: hash(data) })
      } catch (err) {
        // 快照失败 = 不能安全写入 -> 交给调用方拒绝这次操作（fail-closed）
        throw new RollbackError('E_SNAPSHOT_FAILED', `快照失败，已取消本次写入：${t} -> ${(err && err.message) || err}`, { path: t })
      }
    }
    const entry = { id, dir, toolId: meta.toolId || null, ts: new Date().toISOString(), items, undone: false }
    entries.push(entry)
    // 只留最近 50 个可撤销操作，避免快照无限膨胀
    while (entries.length > 50) entries.shift()
    return entry
  }

  /**
   * 撤销一个操作（按 id），不传 id 则撤销最后一个。
   * @param {string|null} id
   */
  function undo(id = null) {
    const entry = id ? entries.find((e) => e.id === id) : entries[entries.length - 1]
    if (!entry) throw new RollbackError('E_NOTHING_TO_UNDO', '没有可撤销的操作')
    if (entry.undone) throw new RollbackError('E_ALREADY_UNDONE', `操作 ${entry.id} 已撤销过`)
    const restored = []
    const removed = []
    for (const item of [...entry.items].reverse()) {
      if (item.existed) {
        if (!item.snapPath) throw new RollbackError('E_SNAPSHOT_MISSING', `快照丢失，无法还原 ${item.path}`)
        const data = fs.readFileSync(item.snapPath)
        fs.writeFileSync(item.path, data)
        restored.push(item.path)
      } else {
        try {
          if (fs.existsSync(item.path)) {
            fs.rmSync(item.path, { force: true })
            removed.push(item.path)
          }
        } catch (err) {
          throw new RollbackError('E_UNDO_DELETE_FAILED', `撤销时删除失败：${item.path} -> ${(err && err.message) || err}`)
        }
      }
    }
    entry.undone = true
    entry.undoneAt = new Date().toISOString()
    return { id: entry.id, toolId: entry.toolId, restored, removed }
  }

  function undoLast() {
    return undo(null)
  }

  /** 可撤销清单（最新在后）。 */
  function list() {
    return entries.map((e) => ({
      id: e.id,
      ts: e.ts,
      toolId: e.toolId,
      undone: !!e.undone,
      targets: e.items.map((i) => i.path),
      bytes: e.items.reduce((n, i) => n + (i.bytes || 0), 0),
    }))
  }

  function get(id) {
    return entries.find((e) => e.id === id) || null
  }

  return { before, undo, undoLast, list, get, root, size: () => entries.length }
}

export default { createRollback, RollbackError, nodeFsAdapter, SNAPSHOT_DIRNAME }
