// packages/core/src/modes.mjs
//
// 运行模式（S22）：把"省 token / 只读"做成可切换、可验证、可回退的数据驱动模式。
//
// 设计要点：
//   · 模式即数据：data/modes/<id>.json 声明 caps / rules / permissions，代码只从 JSON 读上限，
//     不写魔法数（禁止在逻辑里硬编码 65536/150/48000…）。
//   · 封顶值回落：capOf(name, fallback) 优先取当前模式的 caps，缺失时回落到今天既有的常量，
//     保证"standard 与今天行为完全一致"这一不变量。
//   · 切换可审计：setMode 写 data/config.json 的 mode 字段（经 settings，走 safefs 审计），
//     并单独在 data/logs/mode.jsonl 留一行切换轨迹。
//   · 只读叠加：currentModePermissions() 在权限评估前被 executor 读取，denyWrite/denyExec
//     命中即返回 E_MODE_READONLY（写盘/执行被拒），且落审计。
//
// 红线：本文件只读 data/modes 与 data/config.json；不碰其它共享状态、不新增依赖。
// 命名边界：参考 token-lean preset 的封顶参数与三条行为规则（offset 续读 / Found X of Y 报 Y /
// 引用截断区注明 offset 范围）；本实现为独立重写，不依赖、不兼容 DSH。

import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT, appendJsonl, logPath, dataPath } from './safefs.mjs'
import { loadSettings, saveSettings } from './settings.mjs'

export const MODES_DIR = dataPath('modes')
export const MODE_IDS = Object.freeze(['standard', 'lean', 'readonly'])

/**
 * 各 cap 的"今天兜底值"——与现有代码常量对齐，保证 capOf 永远有值、standard 与现状一致。
 * 0 表示"不限制"（如 readLimitLines=0 → 不按行数截断）。
 */
export const FALLBACK = Object.freeze({
  readMaxBytes: 200 * 1024,
  readLimitLines: 0,
  readMaxLineChars: 0,
  grepMaxMatches: 100,
  grepMaxLineChars: 0,
  webFetchMaxChars: 200 * 1024,
  webSearchMaxResults: 0,
  toolResultCapChars: 6000,
})

let _currentId = null
let _currentObj = null

function loadModeFile(id) {
  const p = join(MODES_DIR, `${id}.json`)
  if (!existsSync(p)) return null
  try {
    const m = JSON.parse(readFileSync(p, 'utf8'))
    return m && m.id ? m : null
  } catch {
    return null
  }
}

/** 列出所有可用模式（id/name/description），供 /mode list 用。 */
export function listModes() {
  const out = []
  for (const id of MODE_IDS) {
    const m = loadModeFile(id)
    if (m) out.push({ id: m.id, name: m.name, description: m.description || '' })
  }
  return out
}

/** 读取单个模式定义（缺失/损坏抛错）。 */
export function loadMode(id) {
  const m = loadModeFile(id)
  if (!m) throw new Error(`modes: 未知模式 -> ${id}（可用：${MODE_IDS.join('/')}）`)
  return m
}

function refreshCurrentId() {
  if (_currentId) return
  const s = loadSettings()
  const m = (s && typeof s.mode === 'string' && s.mode.trim())
    ? s.mode
    : (s && s.raw && typeof s.raw.mode === 'string' ? s.raw.mode : '')
  _currentId = MODE_IDS.includes(m) ? m : 'standard'
}

/** 当前模式 id（未设置或非法 → standard，保证不回归）。 */
export function currentModeId() {
  refreshCurrentId()
  return _currentId
}

/** 当前模式完整定义对象。 */
export function currentMode() {
  refreshCurrentId()
  if (!_currentObj || _currentObj.id !== _currentId) _currentObj = loadMode(_currentId)
  return _currentObj
}

/** 当前模式的权限叠加项；非 readonly 返回 null。 */
export function currentModePermissions() {
  const m = currentMode()
  if (!m || !m.permissions) return null
  return { denyWrite: m.permissions.denyWrite === true, denyExec: m.permissions.denyExec === true }
}

/**
 * 切换模式：模式本质是**运行时状态**，切换必须立即在本进程生效，因此先更新内存态，
 * 再尽力持久化（config.json 被占用时静默降级，不阻断切换），最后写切换轨迹审计。
 * @param {'standard'|'lean'|'readonly'} id
 */
export function setMode(id) {
  if (!MODE_IDS.includes(id)) throw new Error(`modes: 未知模式 -> ${id}（可用：${MODE_IDS.join('/')}）`)
  // 1) 先更新内存态：capOf / 权限叠加立刻按新档生效
  _currentId = id
  _currentObj = loadMode(id)
  // 2) 尽力持久化到 data/config.json（被占用/只读时静默降级；下次启动读上次成功值）
  try {
    saveSettings({ mode: id })
  } catch { /* config.json 被占用：本次会话内仍按新档运行 */ }
  // 3) 切换轨迹审计（mode.jsonl 通常可写；失败仅丢失轨迹，不阻断切换）
  try {
    appendJsonl(logPath('mode.jsonl'), {
      ts: new Date().toISOString(),
      kind: 'mode-switch',
      mode: id,
    })
  } catch { /* 审计尽力 */ }
  return _currentObj
}

/**
 * 取当前模式下的封顶值；模式缺失该字段时回落 fallback 参数，再回落 FALLBACK。
 * @param {string} name
 * @param {*} [fallback]
 */
export function capOf(name, fallback) {
  const m = currentMode()
  const v = m && m.caps ? m.caps[name] : undefined
  if (v === undefined || v === null) {
    if (fallback !== undefined) return fallback
    return FALLBACK[name] !== undefined ? FALLBACK[name] : undefined
  }
  return v
}

export default {
  MODES_DIR, MODE_IDS, FALLBACK,
  listModes, loadMode, currentModeId, currentMode, currentModePermissions, setMode, capOf,
}
