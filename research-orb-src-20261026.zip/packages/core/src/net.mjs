// packages/core/src/net.mjs
//
// 受控出网：本应用里【唯一】允许发起 HTTP 请求的地方。
//
// 契约（对应 SAFETY.md 第 4/5 节）：
//   1. 域名白名单，白名单外【直接拒绝】，连 DNS 都不碰；只允许 https;
//   2. 每域令牌桶限速（默认 3 req/s，burst 默认等于速率）；
//   3. deepseek-reasoner 严格 10 次/分钟，超限排队（不丢请求）;
//   4. 429 指数退避 2/4/8/16/32 秒，最多退避 5 次；5 次后原样返回 429 响应（由上层决策）;
//   5. 所有请求与拒绝写 data/logs/net.jsonl，URL 里的密钥类参数一律打码，请求头永不入库；
//      （阶段 3 → S67·3-D·D1）同一 host 的首次拒绝写一条 deny 行；重复拒绝【追加】
//      net-deny-repeat 行（count/firstTs/lastTs），历史审计行一律不改写；
//      stats.denied 仍逐次计数 —— 去重的是噪音，不是拒绝次数。
//
// 可测试性：now / sleep / fetchImpl 全部可注入。测试用虚拟时钟把
// "2+4+8+16+32=62 秒退避" 压成毫秒级，不依赖真实网络与真实等待。

import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

import { appendJsonl, logPath, safeWrite, PROJECT_ROOT } from './safefs.mjs'

/**
 * 白名单来源：`packages/core/src/domains.json`（数据文件，非源码）。
 * 底座零学科假设 —— core 的 .mjs 源码里不出现任何学科域名；换领域 pack 时
 * 只改这个 JSON（或由 pack 追加），`net.mjs` 一行不动。
 * 读取失败（文件缺失/损坏）时回落空集合：fail-closed，白名单外一律拒绝。
 */
export const DOMAINS_FILE = join(PROJECT_ROOT, 'packages', 'core', 'src', 'domains.json')

function readDomainsFile() {
  try {
    const doc = JSON.parse(readFileSync(DOMAINS_FILE, 'utf8'))
    const base = Array.isArray(doc.allowedDomains) ? doc.allowedDomains.map((d) => String(d).toLowerCase()).filter(Boolean) : []
    return [...new Set(base)]
  } catch {
    return []
  }
}

/** 白名单（SAFETY.md 第 5 节；来自 domains.json，见上方说明）。 */
export const ALLOWED_DOMAINS = Object.freeze(readDomainsFile())

/** 医学检索域（仅医学场景启用，默认不在白名单内）。 */
export const MEDICAL_DOMAINS = Object.freeze((() => {
  try {
    const doc = JSON.parse(readFileSync(DOMAINS_FILE, 'utf8'))
    return Array.isArray(doc.medicalDomains) ? [...new Set(doc.medicalDomains.map((d) => String(d).toLowerCase()))] : []
  } catch {
    return []
  }
})())

export const DEFAULT_NET_LOG = logPath('net.jsonl')
export const REASONER_MODEL = 'deepseek-reasoner'
export const BACKOFF_MS = Object.freeze([2000, 4000, 8000, 16000, 32000])

export class NetError extends Error {
  constructor(code, message, details = {}) {
    super(message)
    this.name = 'NetError'
    this.code = code
    Object.assign(this, details)
  }
}

/** 取主机名：小写、去尾点、去端口。解析失败返回 null。 */
export function hostOf(input) {
  try {
    const u = input instanceof URL ? input : new URL(String(input))
    return u.hostname.toLowerCase().replace(/\.$/, '')
  } catch {
    return null
  }
}

/**
 * 白名单判定：https + 主机名严格相等。
 * 故意不做后缀匹配 —— 否则 api.deepseek.com.evil.tld 会被当成白名单。
 */
export function isAllowedUrl(input) {
  let u
  try {
    u = input instanceof URL ? input : new URL(String(input))
  } catch {
    return false
  }
  if (u.protocol !== 'https:') return false
  return ALLOWED_DOMAINS.includes(hostOf(u))
}

const SECRETY_PARAM = /(key|token|secret|auth|password|passwd|pwd|mailto|email)/i

/** URL 脱敏：保留 origin+path 便于审计，query 中密钥类参数值替换为打码串。 */
export function redactUrl(input) {
  let u
  try {
    u = input instanceof URL ? new URL(input.toString()) : new URL(String(input))
  } catch {
    return '<unparsable-url>'
  }
  const out = new URL(u.origin + u.pathname)
  for (const [k, v] of u.searchParams) {
    out.searchParams.append(k, SECRETY_PARAM.test(k) ? maskSecret(v) : v)
  }
  return out.toString()
}

/** 密钥打码：前 4 位 + ***（SAFETY.md 第 4 节）。非字符串一律吃成 '***'。 */
export function maskSecret(value) {
  if (typeof value !== 'string' || value.length === 0) return '***'
  if (value.length <= 4) return '***'
  return value.slice(0, 4) + '***'
}

/**
 * HTTP 状态分类（阶段 1 追加）：provider 层据此判定错误码与是否可重试。
 * 只做映射，不改动任何既有断言与行为。
 */
export function classifyStatus(status) {
  if (typeof status !== 'number') return { code: 'E_UNKNOWN', retryable: false }
  if (status >= 200 && status < 300) return { code: 'OK', retryable: false }
  if (status === 401 || status === 403) return { code: 'E_AUTH', retryable: false }
  if (status === 404) return { code: 'E_NOT_FOUND', retryable: false }
  if (status === 408) return { code: 'E_TIMEOUT', retryable: true }
  if (status === 429) return { code: 'E_RATE_LIMITED', retryable: true }
  if (status === 400 || status === 422) return { code: 'E_BAD_REQUEST', retryable: false }
  if (status >= 500) return { code: 'E_SERVER', retryable: true }
  return { code: `E_HTTP_${status}`, retryable: false }
}

/** 拼接 baseUrl 与路径：去掉尾部斜杠，保证 provider 不手拼 URL。 */
export function joinUrl(baseUrl, path) {
  const base = String(baseUrl || '').replace(/\/+$/, '')
  const tail = String(path || '')
  return base + (tail.startsWith('/') ? tail : '/' + tail)
}

/**
 * provider 端点模板（阶段 1 追加）：provider 只能通过这里取 URL，
 * 于是"白名单审计"与"URL 组装"收敛到同一处，provider 无权绕开。
 */
export const ENDPOINTS = Object.freeze({
  deepseekChatCompletions: (baseUrl) => joinUrl(baseUrl, '/v1/chat/completions'),
  deepseekModels: (baseUrl) => joinUrl(baseUrl, '/v1/models'),
  anthropicMessages: (baseUrl) => joinUrl(baseUrl, '/v1/messages'),
})

/** 提前判定 baseUrl 是否在白名单内：不在就立刻拒绝，不发任何请求。 */
export function assertAllowedBaseUrl(baseUrl, label = 'baseUrl') {
  const host = hostOf(baseUrl)
  if (host === null) {
    throw new NetError('E_BAD_BASE_URL', `net: ${label} 不是合法 URL -> ${String(baseUrl)}`)
  }
  if (!ALLOWED_DOMAINS.includes(host)) {
    throw new NetError('E_DOMAIN_NOT_ALLOWED', `net: ${label} 主机不在白名单内 -> ${host}`, { host })
  }
  return host
}

/** 从 body / 显式 model 里取模型名（用于 reasoner 限速判定）。 */
export function modelOf(options = {}) {
  if (typeof options.model === 'string' && options.model) return options.model
  const body = options.body
  if (typeof body === 'string') {
    try {
      const parsed = JSON.parse(body)
      if (parsed && typeof parsed.model === 'string') return parsed.model
    } catch {
      return ''
    }
  } else if (body && typeof body === 'object' && typeof body.model === 'string') {
    return body.model
  }
  return ''
}

/** token bucket：容量 burst，按 ratePerSec 线性回填。now 可注入以便确定性测试。 */
export class TokenBucket {
  constructor({ ratePerSec = 3, burst = null, now = () => Date.now() } = {}) {
    if (!(ratePerSec > 0)) throw new NetError('E_BAD_RATE', 'ratePerSec 必须 > 0')
    this.ratePerSec = ratePerSec
    this.capacity = burst === null ? Math.max(1, ratePerSec) : burst
    this.now = now
    this.tokens = this.capacity
    this.last = now()
  }

  #refill(t) {
    const elapsedSec = Math.max(0, (t - this.last) / 1000)
    if (elapsedSec <= 0) return
    this.tokens = Math.min(this.capacity, this.tokens + elapsedSec * this.ratePerSec)
    this.last = t
  }

  /** 非阻塞取令牌。拿不到时给出建议等待毫秒数。 */
  take() {
    const t = this.now()
    this.#refill(t)
    if (this.tokens >= 1) {
      this.tokens -= 1
      return { ok: true, waitMs: 0 }
    }
    const waitMs = Math.ceil(((1 - this.tokens) / this.ratePerSec) * 1000)
    return { ok: false, waitMs: Math.max(1, waitMs) }
  }
}

/** 滑动窗口限流（用于 10 次/分钟这类"每分钟"约束）。 */
export class SlidingWindowLimiter {
  constructor({ limit, windowMs, now = () => Date.now() } = {}) {
    if (!(limit > 0) || !(windowMs > 0)) throw new NetError('E_BAD_LIMIT', 'limit/windowMs 必须 > 0')
    this.limit = limit
    this.windowMs = windowMs
    this.now = now
    this.hits = []
  }

  take() {
    const t = this.now()
    this.hits = this.hits.filter((h) => t - h < this.windowMs)
    if (this.hits.length < this.limit) {
      this.hits.push(t)
      return { ok: true, waitMs: 0 }
    }
    return { ok: false, waitMs: Math.max(1, this.windowMs - (t - this.hits[0]) + 1) }
  }
}

const sleepReal = (ms) => new Promise((r) => setTimeout(r, ms))

/**
 * 创建受控出网客户端。
 * @param {{
 *   fetchImpl?: typeof fetch,
 *   now?: () => number,
 *   sleep?: (ms: number) => Promise<void>,
 *   logFile?: string,
 *   ratePerSec?: number,
 *   burst?: number,
 *   reasonerPerMinute?: number,
 *   backoffMs?: number[],
 *   maxRetries?: number,
 * }} [settings]
 */
export function createNet(settings = {}) {
  const {
    fetchImpl = globalThis.fetch,
    now = () => Date.now(),
    sleep = sleepReal,
    logFile = DEFAULT_NET_LOG,
    ratePerSec = 3,
    burst = null,
    reasonerPerMinute = 10,
    backoffMs = BACKOFF_MS,
    maxRetries = 5,
  } = settings

  if (typeof fetchImpl !== 'function') {
    throw new NetError('E_NO_FETCH', 'createNet: 未提供 fetchImpl 且运行环境没有全局 fetch')
  }

  const buckets = new Map()
  const reasoner = new SlidingWindowLimiter({ limit: reasonerPerMinute, windowMs: 60_000, now })
  const stats = { allowed: 0, denied: 0, retried: 0, exhausted: 0, requests: 0, waiting: 0, limited: 0, failed: 0 }

  /**
   * deny 去重台账（S67·3-D·D1 **方案 A：追加式**）：
   *   同一 host 在【本 net 实例】内的**首次**拒绝 → 一条 deny 行
   *     （count:1，dedup:'first-per-host-per-process'）；
   *   之后每次重复拒绝 → **追加**一条 net-deny-repeat 行
   *     （count/firstTs/lastTs，dedup:'append-per-repeat'）。
   * 因此 **历史审计行一概不改写**（append-only 得以保持），
   * 且不再有「全文件读-改-写」（旧实现 O(n²)，已废弃，见 recordDenyRepeat 注释）。
   * 三条边界：
   *   1. stats.denied 仍然【逐次】计数 —— 去重的只是日志形态，不是拒绝次数；
   *   2. 行数随重复拒绝增长（1 + (n-1)），但**每次只追加一行**，成本 O(1)；
   *   3. 追加失败只写 stderr，不影响拒绝语义（该拒的仍然抛 E_DOMAIN_NOT_ALLOWED）。
   */
  const denyLedger = new Map() // key -> { count }

  const bucketFor = (key) => {
    let b = buckets.get(key)
    if (!b) {
      b = new TokenBucket({ ratePerSec, burst, now })
      buckets.set(key, b)
    }
    return b
  }

  const record = (entry) => {
    try {
      appendJsonl(logFile, entry)
    } catch (err) {
      process.stderr.write(`[research-orb/net] net log failed: ${err && err.message}\n`)
    }
  }

  /** deny 行的稳定标记：JSON 序列化后可直接按子串定位那一行。 */
  const denyKeyOf = (host) => (host === null ? '<unparsable>' : host)

  /**
   * S67·3-D·D1（方案 A·追加式）：同一 host 的重复拒绝【新增一行】net-deny-repeat
   * （含 count/firstTs/lastTs），历史 deny 行一概不动；聚合计数由进程内存的
   * denyLedger（Map<key,{count,firstTs}>）维护，不再全文件读-改-写
   * （旧实现 O(n²) 且与"历史审计行一律不改写"矛盾，已废弃）。
   * 审计完整性测试断言：本函数体内不得出现 readFileSync(logFile...)。
   */
  function recordDenyRepeat(key, count, url) {
    const seen = denyLedger.get(key)
    const lastTs = new Date().toISOString()
    record({
      ts: lastTs,
      kind: 'net-deny-repeat',
      decision: 'deny',
      reason: key === '<unparsable>' ? 'unparsable-url' : 'not-in-allowlist',
      host: key === '<unparsable>' ? null : key,
      url: typeof url === 'string' ? redactUrl(url) : '<non-string-url>',
      denyKey: key,
      dedup: 'append-per-repeat',
      count,
      firstTs: (seen && seen.firstTs) || lastTs,
      lastTs,
    })
  }

  async function awaitToken(limiter, label) {
    // 限流等待最多 400 次，避免注入的 now/sleep 不一致时把进程挂死。
    for (let i = 0; i < 400; i += 1) {
      const r = limiter.take()
      if (r.ok) return
      // 排队计数：面板要展示"当前限速队列长度"，所以第一次被拦就记一次等待。
      if (i === 0) {
        stats.limited += 1
        stats.waiting += 1
      }
      await sleep(r.waitMs)
    }
    stats.waiting = Math.max(0, stats.waiting - 1)
    throw new NetError('E_RATE_STALL', `createNet: ${label} 限流等待超时`)
  }

  /** 释放排队计数（成功拿到令牌或异常退出都要调用）。 */
  function releaseWaiting(marked) {
    if (marked) stats.waiting = Math.max(0, stats.waiting - 1)
  }

  /** 从 options 里剥离本模块自定义字段，避免泄漏进 fetch。 */
  function splitOptions(options = {}) {
    const { model, limitKey, ...fetchOptions } = options
    return { model, limitKey, fetchOptions }
  }

  /** 队列/限速快照：面板与 --selftest 都读这个。 */
  function queueState() {
    return {
      waiting: stats.waiting,
      limited: stats.limited,
      requests: stats.requests,
      retried: stats.retried,
      denied: stats.denied,
      exhausted: stats.exhausted,
      failed: stats.failed,
      // deny 去重后的分主机计数（阶段 3）：日志里每个 host 只剩一行，总次数在这里对账
      deniedByHost: [...denyLedger.entries()].map(([host, v]) => ({ host, count: v.count })),
      reasonerWindowUsed: reasoner.hits.filter((h) => now() - h < 60_000).length,
      reasonerLimitPerMinute: reasoner.limit,
      buckets: [...buckets.entries()].map(([key, bucket]) => ({
        key,
        ratePerSec: bucket.ratePerSec,
        capacity: bucket.capacity,
        tokens: Number(bucket.tokens.toFixed(3)),
      })),
    }
  }

  async function request(url, options = {}) {
    const { model, limitKey, fetchOptions } = splitOptions(options)
    const host = hostOf(url)
    const startedAt = now()

    if (!isAllowedUrl(url)) {
      stats.denied += 1
      const key = denyKeyOf(host)
      const seen = denyLedger.get(key)
      if (!seen) {
        // 该 host 在本进程内的第一次拒绝：写一条 deny 行（count 从 1 起，历史行此后不再改写）
        const firstTs = new Date().toISOString()
        denyLedger.set(key, { count: 1, firstTs })
        record({
          ts: firstTs,
          decision: 'deny',
          reason: host === null ? 'unparsable-url' : 'not-in-allowlist',
          host: host ?? null,
          url: typeof url === 'string' ? redactUrl(url) : '<non-string-url>',
          denyKey: key,
          dedup: 'first-per-host-per-process',
          count: 1,
        })
      } else {
        // S67·3-D·D1：重复拒绝追加 net-deny-repeat 行，历史行不动
        seen.count += 1
        recordDenyRepeat(key, seen.count, url)
      }
      throw new NetError('E_DOMAIN_NOT_ALLOWED', `net: 域名不在白名单内 -> ${host ?? url}`, { host })
    }

    const effectiveModel = typeof model === 'string' && model ? model : modelOf(fetchOptions)
    // 令牌桶键：默认按域；provider 可传 limitKey='providerId:model' 做"按 provider+model"限速。
    const bucketKey = typeof limitKey === 'string' && limitKey ? limitKey : host
    let queued = false
    // 单独标出"被 reasoner 每分钟窗口拦下"的那一次：面板/验收要能区分
    // 「排队等 10 次/分钟窗口」和「排队等普通令牌桶」，两者含义完全不同。
    let reasonerQueued = false
    try {
      if (effectiveModel === REASONER_MODEL) {
        const before = stats.waiting
        await awaitToken(reasoner, `${REASONER_MODEL} 每分钟限流`)
        if (stats.waiting > before) {
          queued = true
          reasonerQueued = true
        }
      }
      const beforeBucket = stats.waiting
      await awaitToken(bucketFor(bucketKey), `${bucketKey} 令牌桶`)
      if (stats.waiting > beforeBucket) queued = true
    } catch (err) {
      releaseWaiting(queued)
      throw err
    }

    // 拿到令牌即离开队列
    releaseWaiting(queued)

    const delays = []
    let response = null
    let attempts = 0
    for (;;) {
      attempts += 1
      stats.requests += 1
      try {
        response = await fetchImpl(url, fetchOptions)
      } catch (err) {
        // 【阶段 2 补的洞】fetch 自己抛（DNS 解析失败 / 连接被重置 / 代理空闲断链）时，
        // 过去的写法会让异常直接逃出 request()，**一行审计都不留** —— 事后看 net.jsonl
        // 完全看不出"曾经尝试过这次请求"。对"所有出网都可审计"这条要求来说这是漏洞，
        // 而且在阶段 2 的验收里真的复现了：三个源同时报 E_UNKNOWN 且 net.jsonl 窗口 0 行。
        // 现在补一条 decision:'error' 行再抛类型化错误。
        stats.failed += 1
        // 不 import provider 里的 shortMessage：provider.mjs 反过来 import net.mjs，会成环。
        // 这里就地截断（同一个函数只有三行，为它引一个环不划算）。
        // undici 抛出来的往往是笼统的 "fetch failed"，真正的原因在 err.cause 里
        // （AggregateError 或带 code 的系统错误）。审计行必须把 cause 也记下来，
        // 否则事后只看到 "fetch failed"，连是 DNS 还是连接被重置都分不清。
        const cause = err && err.cause
        const causeCode = (cause && cause.code) || (err && err.code) || 'E_NET'
        const causeMessage = (cause && cause.message) || (err && err.message) || String(err || '')
        const message = String(causeMessage).replace(/\s+/g, ' ').slice(0, 200)
        record({
          ts: new Date().toISOString(),
          decision: 'error',
          host,
          url: redactUrl(url),
          method: fetchOptions.method ?? 'GET',
          attempts,
          retries: delays.length,
          ms: now() - startedAt,
          model: effectiveModel || null,
          bucketKey,
          error: causeCode,
          message,
        })
        throw new NetError('E_NET', `net: 请求失败 -> ${host}：${causeCode} ${message}`, { host, cause: causeMessage })
      }
      if (response.status !== 429 || delays.length >= maxRetries) break
      const delayMs = backoffMs[Math.min(delays.length, backoffMs.length - 1)]
      delays.push(delayMs)
      stats.retried += 1
      record({
        ts: new Date().toISOString(),
        decision: 'retry',
        host,
        url: redactUrl(url),
        status: 429,
        attempt: delays.length,
        delayMs,
        model: effectiveModel || null,
      })
      await sleep(delayMs)
    }

    if (response.status === 429) stats.exhausted += 1
    else stats.allowed += 1

    record({
      ts: new Date().toISOString(),
      decision: response.status === 429 ? 'exhausted' : 'allow',
      host,
      url: redactUrl(url),
      method: fetchOptions.method ?? 'GET',
      status: response.status,
      attempts,
      retries: delays.length,
      delaysMs: delays,
      ms: now() - startedAt,
      model: effectiveModel || null,
      bucketKey,
      queued,
      reasonerQueued,
    })

    return response
  }

  /** 便捷方法：请求 + JSON 解析。非 2xx 直接抛 NetError。 */
  async function json(url, options = {}) {
    const res = await request(url, options)
    if (!res.ok) {
      throw new NetError('E_HTTP_STATUS', `net: HTTP ${res.status} <- ${redactUrl(url)}`, { status: res.status })
    }
    return res.json()
  }

  return {
    request,
    json,
    isAllowedUrl,
    hostOf,
    ALLOWED_DOMAINS,
    logFile,
    stats,
    buckets,
    reasoner,
    bucketFor,
    queueState,
  }
}

export default {
  ALLOWED_DOMAINS,
  DEFAULT_NET_LOG,
  REASONER_MODEL,
  BACKOFF_MS,
  ENDPOINTS,
  NetError,
  TokenBucket,
  SlidingWindowLimiter,
  createNet,
  hostOf,
  isAllowedUrl,
  joinUrl,
  classifyStatus,
  assertAllowedBaseUrl,
  maskSecret,
  redactUrl,
}
