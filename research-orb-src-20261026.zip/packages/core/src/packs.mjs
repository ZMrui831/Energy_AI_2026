// packages/core/src/packs.mjs
//
// Pack（形态包）加载器：把「领域能力集合」变成可切换的一等公民。
//
// 三层里的第三层：
//   shell（apps\desktop：球/托盘/面板容器/主题/IPC，零学科词）
//   core （packages\core：AgentCore/受控网络/安全写/插件宿主/计时进度引擎）
//   pack （packages\packs\*：领域能力集合 —— research / general / health / eldercare）
//
// pack.json 契约：
//   {
//     "id": "research",                 // 唯一 id
//     "name": "科研",
//     "description": "…",
//     "version": "0.6.0",
//     "entry": "index.mjs",             // 导出 activate(ctx)
//     "plugins": ["research-literature"],// 要启用的插件 id（packages\plugins\*）
//     "commands": ["find", "note"],     // 供面板/自检展示的命令名
//     "theme": "sky-blue",              // 切到本 pack 时的默认主题
//     "ui": ["ui/literature.js"],       // 领域渲染层脚本（相对 pack 目录，注入 renderer）
//     "dataRoot": "research"            // 数据隔离根 data\packs\<dataRoot>\
//   }
//
// 纪律：pack 只**声明与编排**，不重复实现能力（能力都在 packages\plugins\*）；
//       pack 不得写 packages\plugins\*；切换 pack = 改 data\config.json 的 activePack。

import { existsSync, readdirSync, readFileSync, statSync } from 'node:fs'
import { join, resolve, isAbsolute } from 'node:path'

import { PROJECT_ROOT } from './safefs.mjs'

export const PACKS_DIR = join(PROJECT_ROOT, 'packages', 'packs')

const PACK_ID_RE = /^[a-z0-9][a-z0-9._-]{1,63}$/i

export class PackError extends Error {
  constructor(code, message, details = {}) {
    super(message)
    this.name = 'PackError'
    this.code = code
    Object.assign(this, details)
  }
}

function readJson(path) {
  try {
    return JSON.parse(readFileSync(path, 'utf8'))
  } catch {
    return null
  }
}

/** 校验并归一 pack.json（id 非法直接拒；缺字段给默认）。 */
export function normalizePackManifest(raw, { dirName = null } = {}) {
  if (!raw || typeof raw !== 'object') {
    throw new PackError('E_BAD_PACK_MANIFEST', 'pack.json 必须是 JSON 对象')
  }
  const id = String(raw.id || dirName || '')
  if (!PACK_ID_RE.test(id)) {
    throw new PackError('E_BAD_PACK_ID', `packs: 非法 pack id -> ${id}`)
  }
  const entry = typeof raw.entry === 'string' && raw.entry ? raw.entry : 'index.mjs'
  if (entry.includes('..') || isAbsolute(entry)) {
    throw new PackError('E_BAD_PACK_ENTRY', `packs: entry 必须是 pack 目录内的相对路径 -> ${entry}`, { id })
  }
  const ui = Array.isArray(raw.ui)
    ? raw.ui.map((u) => String(u)).filter((u) => u && !u.includes('..') && !isAbsolute(u))
    : []
  return {
    id,
    name: typeof raw.name === 'string' && raw.name ? raw.name : id,
    description: typeof raw.description === 'string' ? raw.description : '',
    version: typeof raw.version === 'string' && raw.version ? raw.version : '0.0.0',
    entry,
    plugins: Array.isArray(raw.plugins) ? [...new Set(raw.plugins.map(String))].sort() : [],
    commands: Array.isArray(raw.commands) ? [...new Set(raw.commands.map(String))].sort() : [],
    theme: typeof raw.theme === 'string' && raw.theme ? raw.theme : null,
    ui,
    dataRoot: typeof raw.dataRoot === 'string' && raw.dataRoot ? raw.dataRoot : id,
  }
}

/** 扫描 packages\packs\，只读 manifest，不加载代码。 */
export function scanPacks(dir = PACKS_DIR) {
  let names = []
  try {
    names = readdirSync(dir)
  } catch {
    return []
  }
  const found = []
  for (const name of names) {
    if (name.startsWith('.')) continue
    const dirPath = join(dir, name)
    let st = null
    try {
      st = statSync(dirPath)
    } catch {
      continue
    }
    if (!st.isDirectory()) continue
    const raw = readJson(join(dirPath, 'pack.json'))
    let manifest = null
    let error = null
    try {
      manifest = normalizePackManifest(raw, { dirName: name })
    } catch (err) {
      error = { code: err.code || 'E_BAD_PACK_MANIFEST', message: String(err.message || err) }
      manifest = { id: name, name, version: '0.0.0', description: '', entry: 'index.mjs', plugins: [], commands: [], theme: null, ui: [], dataRoot: name }
    }
    found.push({ id: manifest.id, dir: dirPath, manifest, error })
  }
  return found
}

/**
 * 激活一个 pack：加载 entry 并调用 activate(ctx)，随后按 manifest.plugins
 * 启用这些插件（宿主 registry 负责真正的 enable/disable）。
 *
 * @param {string} packId
 * @param {{packsDir?:string, registry:object, core?:object, log?:Function, onEvent?:Function}} opts
 * @returns {Promise<{id, name, version, enabled:string[], disabled:string[], theme, instance, ui:string[]}>}
 */
export async function activatePack(packId, { packsDir = PACKS_DIR, registry, core = {}, log = null, onEvent = null } = {}) {
  if (!registry) throw new PackError('E_NO_REGISTRY', 'packs: 需要 registry 才能激活 pack')
  const scanned = scanPacks(packsDir)
  const entry = scanned.find((p) => p.id === packId)
  if (!entry) throw new PackError('E_NO_PACK', `packs: 未找到 pack -> ${packId}（可用：${scanned.map((p) => p.id).join(', ') || '无'}）`)
  if (entry.error) throw new PackError('E_BAD_PACK_MANIFEST', entry.error.message, { id: packId })

  const { manifest, dir } = entry
  const entryPath = resolve(dir, manifest.entry)
  if (!existsSync(entryPath)) {
    throw new PackError('E_NO_PACK_ENTRY', `packs(${packId}): entry 不存在 -> ${manifest.entry}`, { id: packId })
  }

  const mod = await import(new URL(`file://${entryPath.replace(/\\/g, '/')}`).href)
  if (typeof mod.activate !== 'function') {
    throw new PackError('E_NO_PACK_ACTIVATE', `packs(${packId}): ${manifest.entry} 未导出 activate(ctx)`, { id: packId })
  }

  const logline = typeof log === 'function' ? log : () => {}
  const ctx = Object.freeze({
    id: manifest.id,
    name: manifest.name,
    version: manifest.version,
    pack: manifest,
    dir,
    registry,
    core,
    log: {
      info: (m) => logline(`[pack:${manifest.id}] ${m}`),
      warn: (m) => logline(`[pack:${manifest.id}] warn ${m}`),
      error: (m) => logline(`[pack:${manifest.id}] error ${m}`),
    },
    ui: {
      /** 供 shell 注入 renderer 的领域 UI 脚本绝对路径。 */
      scripts: () => manifest.ui.map((u) => resolve(dir, u)).filter((p) => existsSync(p)),
    },
    ...(onEvent ? { onEvent } : {}),
  })

  const result = await mod.activate(ctx)
  const instance = typeof result === 'function' ? { deactivate: result } : result && typeof result === 'object' ? result : null

  // 按 manifest.plugins 精确启用（未在清单里的插件一律不启用 —— 底座零学科假设的运行时体现）
  const enabled = []
  for (const pid of manifest.plugins) {
    const r = await registry.enable(pid)
    if (r && r.enabled) enabled.push(pid)
  }

  logline(`pack ${manifest.id} 已激活：plugins=[${enabled.join(', ') || '-'}] commands=[${manifest.commands.join(', ') || '-'}] theme=${manifest.theme || '-'}`)
  return {
    id: manifest.id,
    name: manifest.name,
    version: manifest.version,
    enabled,
    theme: manifest.theme,
    ui: manifest.ui,
    instance,
  }
}

/** 列出所有可用 pack（供面板/自检）。 */
export function listPacks(packsDir = PACKS_DIR) {
  return scanPacks(packsDir).map((p) => ({
    id: p.id,
    name: p.manifest.name,
    description: p.manifest.description,
    version: p.manifest.version,
    plugins: p.manifest.plugins,
    commands: p.manifest.commands,
    theme: p.manifest.theme,
    dataRoot: p.manifest.dataRoot,
    error: p.error ? p.error.message : null,
  }))
}

export default { scanPacks, activatePack, listPacks, normalizePackManifest, PACKS_DIR }