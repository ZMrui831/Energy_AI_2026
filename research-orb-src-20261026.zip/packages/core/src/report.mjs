// packages/core/src/report.mjs
//
// 日报 / 周报（对应任务书交付 4）。
//
// 硬规则：
//   1. 【纯模板必生成】—— 没有任何计时记录、没有任何产出、LLM 完全不可用，
//      这三件事各自发生或同时发生时，报告文件都必须能生成（模板里有"今日暂无记录"）；
//   2. 【LLM 失败回落纯模板】—— 润色只是"复盘与建议"一小段，失败/超时/返回空
//      都只让那一段回落到模板文案，文档其余部分与文件落盘不受任何影响；
//   3. 报告是【派生品】：随时可删随时可重建，删掉不影响计时账本与卡片。

import { dayStartMs } from './timer-store.mjs'

const WEEKDAYS = ['周日', '周一', '周二', '周三', '周四', '周五', '周六']

/** 秒 -> "1 小时 25 分钟" / "50 分钟" / "45 秒" / "0 分钟"。 */
export function fmtDuration(sec) {
  const s = Math.max(0, Math.round(Number(sec) || 0))
  if (s === 0) return '0 分钟'
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const r = s % 60
  if (h > 0) return m > 0 ? `${h} 小时 ${m} 分钟` : `${h} 小时`
  if (m > 0) return r > 0 ? `${m} 分 ${r} 秒` : `${m} 分钟`
  return `${r} 秒`
}

function weekdayOf(dayKey) {
  return WEEKDAYS[new Date(dayStartMs(dayKey)).getDay()]
}

function projectRows(byProject) {
  if (!byProject || byProject.length === 0) return '（无计时记录）'
  return byProject
    .map((r) => {
      const lines = [`- ${r.name}：${fmtDuration(r.focusSec)}`]
      // 阶段细分：把时间归到"项目 / 阶段"（阶段 3.1：任务书验收①要求日报可见阶段归类）
      for (const s of r.stages || []) {
        lines.push(`  - ${s.stageName}：${fmtDuration(s.focusSec)}`)
      }
      return lines.join('\n')
    })
    .join('\n')
}

function outputBlock(title, group) {
  if (!group || group.count === 0) return `- ${title}：今日暂无`
  const files = (group.files || []).map((f) => `  \`${f}\``).join('\n')
  return `- ${title}：${group.count}\n${files}`
}

/**
 * 测试/加速数据区（timeScale≠1 的会话）：不计入上方任何统计，单独列一段，
 * 让"验收跑加速时日报专注时长没变脏"这件事在文档层可直接核对。
 * 没有加速会话时返回空串（模板里不出现这一段）。
 */
function scaledBlock(scaled) {
  if (!scaled || scaled.sessionCount <= 0) return ''
  return [
    '## 测试 / 加速数据（不计入上方统计）',
    '',
    `- 加速会话：${scaled.sessionCount} 个（RESEARCH_ORB_TIME_SCALE≠1 时产生，验收/演示用）`,
    `- 加速计时：${fmtDuration(scaled.focusSec)}（${scaled.segmentCount} 段计账，已从上方专注时长中排除）`,
    '',
  ].join('\n')
}

/** 日报纯模板（无 LLM 时就是最终文档）。 */
export function renderDailyTemplate(progress) {
  const p = progress
  return [
    `# 科研日报 · ${p.dayKey}（${weekdayOf(p.dayKey)}）`,
    '',
    `> research-orb 阶段 3 自动收纳 · 生成于 ${p.generatedAt} · 数据来源：data/timer（计时账本）、data/notes 与 data/exports（产出 mtime）`,
    '',
    '## 一、计时总览',
    '',
    `- 专注时长：**${fmtDuration(p.focusSec)}**（${p.segmentCount} 段计账）`,
    `- 计时会话：${p.sessionCount} 个（完成 ${p.completedCount} · 中断 ${p.interruptedCount}）`,
    '- 分项目：',
    projectRows(p.byProject),
    '',
    '## 二、当日产出（按文件 mtime 统计）',
    '',
    outputBlock('新增研究卡片', p.outputs.cards),
    outputBlock('新增引用导出', p.outputs.bib),
    '',
    // 加速区自带尾部空行；没有加速会话时整段不出现（模板与无加速时逐字一致）
    ...(p.scaled && p.scaled.sessionCount > 0 ? [scaledBlock(p.scaled)] : []),
    '## 三、复盘与建议',
    '',
    '（AI 复盘未启用或生成失败 —— 以上数据部分不受影响，可稍后用 /today 重试。）',
    '',
  ].join('\n')
}

/** 周报纯模板。 */
export function renderWeeklyTemplate(week) {
  const lines = [
    `# 科研周报 · ${week.from} ~ ${week.to}`,
    '',
    `> research-orb 阶段 3 自动收纳 · 生成于 ${week.generatedAt} · 口径：对本周逐日重算，不读中间文件`,
    '',
    '## 一、本周总览',
    '',
    `- 专注时长：**${fmtDuration(week.focusSec)}**（${week.activeDays}/7 天有记录）`,
    `- 计时会话：${week.sessionCount} 个（完成 ${week.completedCount} · 中断 ${week.interruptedCount}）`,
    '- 分项目累计：',
    projectRows(week.byProject),
    '',
    '## 二、每日明细',
    '',
    '| 日期 | 星期 | 专注 | 会话 | 完成 | 新增卡片 | 新增 bib |',
    '| --- | --- | --- | --- | --- | --- | --- |',
  ]
  for (const d of week.days) {
    lines.push(
      `| ${d.dayKey} | ${weekdayOf(d.dayKey)} | ${fmtDuration(d.focusSec)} | ${d.sessionCount} | ${d.completedCount} | ${d.outputs.cards.count} | ${d.outputs.bib.count} |`,
    )
  }
  lines.push(
    '',
    '## 三、本周产出汇总',
    '',
    outputBlock('新增研究卡片（去重）', week.outputs.cards),
    outputBlock('新增引用导出（去重）', week.outputs.bib),
    '',
    ...(week.scaled && week.scaled.sessionCount > 0 ? [scaledBlock(week.scaled)] : []),
    '## 四、复盘与建议',
    '',
    '（AI 复盘未启用或生成失败 —— 以上数据部分不受影响，可稍后用 /weekly 重试。）',
    '',
  )
  return lines.join('\n')
}

/** 复盘段落占位符：模板里固定出现，润色成功时整段替换。 */
const DAILY_PLACEHOLDER = '（AI 复盘未启用或生成失败 —— 以上数据部分不受影响，可稍后用 /today 重试。）'
const WEEKLY_PLACEHOLDER = '（AI 复盘未启用或生成失败 —— 以上数据部分不受影响，可稍后用 /weekly 重试。）'

/**
 * LLM 润色"复盘与建议"一段。任何失败都返回 null（调用方回落纯模板）。
 * @param {{kind:'daily'|'weekly', progress?: object, week?: object, ask?: Function, maxChars?: number}} args
 * @returns {Promise<{text: string, polished: boolean} | null>}
 */
export async function polishReview(args = {}) {
  const ask = args.ask
  if (typeof ask !== 'function') return null
  const maxChars = args.maxChars || 400
  const brief =
    args.kind === 'weekly'
      ? JSON.stringify({
          week: args.week && { from: args.week.from, to: args.week.to, focusSec: args.week.focusSec, sessionCount: args.week.sessionCount, byProject: args.week.byProject, outputs: args.week.outputs },
        })
      : JSON.stringify({
          day: args.progress && {
            dayKey: args.progress.dayKey,
            focusSec: args.progress.focusSec,
            sessionCount: args.progress.sessionCount,
            completedCount: args.progress.completedCount,
            byProject: args.progress.byProject,
            outputs: args.progress.outputs,
            scaled: args.progress.scaled && args.progress.scaled.sessionCount > 0 ? args.progress.scaled : undefined,
          },
        })
  try {
    const reply = await ask({
      messages: [
        {
          role: 'system',
          content:
            '你是科研计时助手。只根据用户给出的 JSON 数据写一段 80~150 字的中文复盘与建议，指出投入集中在哪、产出是否匹配、下一步最该做什么。不得编造数据里没有的事实；不要输出 Markdown 标题；直接给正文。',
        },
        { role: 'user', content: `数据：${brief}` },
      ],
    })
    const text = typeof reply === 'string' ? reply : reply && typeof reply.text === 'string' ? reply.text : ''
    const clean = text.replace(/\s+$/, '')
    if (!clean.trim()) return null
    return { text: clean.length > maxChars ? clean.slice(0, maxChars) + '…' : clean, polished: true }
  } catch {
    return null // 失败一律回落，绝不因此让报告生不成
  }
}

function replacePlaceholder(template, placeholder, review) {
  if (!review || !review.text) return template
  return template.replace(placeholder, review.text)
}

/**
 * 生成（或重建）日报并落盘。
 * @param {{progress: object, store: object, ask?: Function}} args
 * @returns {Promise<{path: string, markdown: string, polished: boolean}>}
 */
export async function buildDailyReport(args = {}) {
  const template = renderDailyTemplate(args.progress)
  const review = await polishReview({ kind: 'daily', progress: args.progress, ask: args.ask })
  const markdown = replacePlaceholder(template, DAILY_PLACEHOLDER, review)
  const path = args.store.paths.report('daily', args.progress.dayKey)
  args.store.writeReport('daily', args.progress.dayKey, markdown)
  return { path, markdown, polished: !!(review && review.polished) }
}

/**
 * 生成（或重建）周报并落盘。
 * @param {{week: object, store: object, ask?: Function}} args
 */
export async function buildWeeklyReport(args = {}) {
  const template = renderWeeklyTemplate(args.week)
  const review = await polishReview({ kind: 'weekly', week: args.week, ask: args.ask })
  const markdown = replacePlaceholder(template, WEEKLY_PLACEHOLDER, review)
  const path = args.store.paths.report('weekly', args.week.weekKey)
  args.store.writeReport('weekly', args.week.weekKey, markdown)
  return { path, markdown, polished: !!(review && review.polished) }
}

export default { fmtDuration, renderDailyTemplate, renderWeeklyTemplate, polishReview, buildDailyReport, buildWeeklyReport }
