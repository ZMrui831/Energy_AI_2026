// packages/core/src/query-scope.mjs —— S74·1-B Q6 统一查询作用域（ASTRA 方案，全采纳）
//
// 背景（已出事故）：召回靠"刚刚/昨天"字符串硬匹配取数，昨日内容混进"最近"答案。
// 方案：解析器**只**把自然语言映射成查询对象（scope + start/end + 开关），
//       取数逻辑**不再看字符串**，只按 scope 语义与窗口取数。
//
// scope 语义（**北京时间**，切日不依赖机器时区——与 session-rhythm 同一口径）：
//   current_session  仅当前会话
//   today            当日 00:00 → now（**禁止**出现非今日条目）
//   relative_day(-N) 目标日 00:00–24:00（**含归档**，条目标 archived:true，且必须带日期）
//   archive          仅归档
//   all              全部（仅调试用）
//
// 纪律：
//   · 归档可"提及"（archive_reference），但**不得**计入当日实时上下文/评分基数。
//   · 解析器不猜：识别不出就落默认 today（当日 00:00 → now），不扩大范围。

export const SCOPES = Object.freeze(['current_session', 'today', 'relative_day', 'archive', 'all'])

const BJ_OFFSET_MS = 8 * 3600 * 1000
const pad2 = (n) => String(n).padStart(2, '0')
const DAY = 24 * 3600 * 1000

/** 北京时间当日 00:00 的毫秒时间戳。 */
export function bjDayStart(ms) {
  const d = new Date(Number(ms) + BJ_OFFSET_MS)
  d.setUTCHours(0, 0, 0, 0)
  return d.getTime() - BJ_OFFSET_MS
}
/** 北京时间次日 00:00（即当日 24:00，开区间端点）。 */
export function bjDayEnd(ms) { return bjDayStart(ms) + DAY }
/** 北京时间日期串 YYYY-MM-DD。 */
export function bjDayLabel(ms) {
  const d = new Date(Number(ms) + BJ_OFFSET_MS)
  return `${d.getUTCFullYear()}-${pad2(d.getUTCMonth() + 1)}-${pad2(d.getUTCDate())}`
}
/** 北京时间 HH:MM。 */
export function bjHm(ms) {
  const d = new Date(Number(ms) + BJ_OFFSET_MS)
  return `${pad2(d.getUTCHours())}:${pad2(d.getUTCMinutes())}`
}
/** 某时间戳是否属于（北京时间的）某一天。 */
export function isBjSameDay(ms, dayAnchorMs) { return bjDayStart(ms) === bjDayStart(dayAnchorMs) }

/** 端点展示：恰好落在某日 00:00 且是"终点"→ 记 24:00（昨天 00:00–24:00），否则 HH:MM。 */
function endHm(ms, startMs) {
  if (Number(ms) > Number(startMs) && bjDayStart(ms) === Number(ms)) return '24:00'
  return bjHm(ms)
}

/**
 * 组装查询对象。字段（ASTRA 定稿）：
 *   referenceTime / scope / start / end / includeArchive / includePrevDaySummary
 * 另附：relativeDay(-N)、from/to(毫秒，兼容旧 range 消费方)、label(人类可读范围串)、sessionId。
 */
export function makeQuery({ scope, startMs, endMs, nowMs, includeArchive = false, includePrevDaySummary = false, relativeDay = null, sessionId = null, extra = {} }) {
  const q = {
    referenceTime: new Date(Number(nowMs)).toISOString(),
    scope,
    start: new Date(Number(startMs)).toISOString(),
    end: new Date(Number(endMs)).toISOString(),
    includeArchive: !!includeArchive,
    includePrevDaySummary: !!includePrevDaySummary,
    from: Number(startMs),
    to: Number(endMs),
    label: '',
    ...extra,
  }
  if (relativeDay !== null) q.relativeDay = relativeDay
  if (sessionId) q.sessionId = sessionId
  q.label = scopeLabel(q)
  return q
}

/** 顶部展示串：`今天 00:00–22:40` / `昨天 00:00–24:00` / `2026-10-20 00:00–24:00`。 */
export function scopeLabel(q) {
  const start = Date.parse(q.start)
  const end = Date.parse(q.end)
  const ref = Date.parse(q.referenceTime || new Date().toISOString())
  const day0 = bjDayStart(ref)
  let dayDesc = ''
  if (q.scope === 'today') dayDesc = '今天'
  else if (q.scope === 'relative_day') {
    const s = bjDayStart(start)
    if (s === day0 - DAY) dayDesc = '昨天'
    else if (s === day0 - 2 * DAY) dayDesc = '前天'
    else dayDesc = bjDayLabel(start)
  } else if (q.scope === 'current_session') dayDesc = '当前会话'
  else if (q.scope === 'archive') dayDesc = '归档'
  else dayDesc = '全部'
  return `${dayDesc} ${bjHm(start)}–${endHm(end, start)}`
}

/**
 * 自然语言 → 查询对象。**只做映射，不做取数**。
 * @param {string} text
 * @param {{nowMs?:number, sessionId?:string|null}} opts
 */
export function parseQueryScope(text, opts = {}) {
  const now = Number(opts.nowMs ?? Date.now())
  const sessionId = opts.sessionId || null
  const t = String(text || '')
  const day0 = bjDayStart(now)

  // ① 显式相对窗（"最近 N 分钟/小时/天"）：完全落在当日 → today；跨午夜 → relative_day(-1)（含归档、带日期）
  const m = t.match(/最近\s*(\d+)\s*(分钟|小时|天)/)
  if (m) {
    const n = Math.max(1, Number(m[1]) || 1)
    const unit = m[2] === '天' ? DAY : m[2] === '小时' ? 3600e3 : 60e3
    const start = now - n * unit
    if (start >= day0) return makeQuery({ scope: 'today', startMs: start, endMs: now, nowMs: now, sessionId })
    return makeQuery({ scope: 'relative_day', startMs: start, endMs: now, nowMs: now, includeArchive: true, relativeDay: -1, sessionId, extra: { spansMidnight: true } })
  }
  // ② 刚刚 → today 且 start = now-30min（ASTRA 定稿）
  if (/刚刚|刚才/.test(t)) return makeQuery({ scope: 'today', startMs: now - 30 * 60e3, endMs: now, nowMs: now, sessionId })
  // ③ 昨天 / 前天 → relative_day（含归档）
  if (/昨天|昨日/.test(t)) return makeQuery({ scope: 'relative_day', startMs: day0 - DAY, endMs: day0, nowMs: now, includeArchive: true, relativeDay: -1, sessionId })
  if (/前天/.test(t)) return makeQuery({ scope: 'relative_day', startMs: day0 - 2 * DAY, endMs: day0 - DAY, nowMs: now, includeArchive: true, relativeDay: -2, sessionId })
  // ④ 今日时段
  if (/上午/.test(t)) return makeQuery({ scope: 'today', startMs: day0, endMs: Math.min(now, day0 + 12 * 3600e3), nowMs: now, sessionId })
  if (/下午/.test(t)) return makeQuery({ scope: 'today', startMs: day0 + 12 * 3600e3, endMs: Math.max(Math.min(now, day0 + 18 * 3600e3), day0 + 12 * 3600e3), nowMs: now, sessionId })
  if (/晚上/.test(t)) return makeQuery({ scope: 'today', startMs: day0 + 18 * 3600e3, endMs: Math.max(now, day0 + 18 * 3600e3), nowMs: now, sessionId })
  // ⑤ 归档 / 全部（all 仅调试）
  if (/归档|历史记录/.test(t)) return makeQuery({ scope: 'archive', startMs: 0, endMs: day0, nowMs: now, includeArchive: true, sessionId })
  if (/^\s*(全部|所有)\s*$/.test(t)) return makeQuery({ scope: 'all', startMs: 0, endMs: now + 1, nowMs: now, includeArchive: true, sessionId })
  // ⑥ 默认：今天（当日 00:00 → now）
  return makeQuery({ scope: 'today', startMs: day0, endMs: now, nowMs: now, sessionId })
}

/**
 * 把旧式 {from,to,label} 或新查询对象归一成内部取数窗。
 * @returns {{from:number,to:number,scope:string,includeArchive:boolean,referenceTime:number,label:string,query:object}}
 */
export function normalizeQuery(rangeOrQuery) {
  const r = rangeOrQuery || {}
  const isQuery = typeof r.scope === 'string' && SCOPES.includes(r.scope)
  const from = Number.isFinite(Number(r.from)) ? Number(r.from) : Date.parse(r.start)
  const to = Number.isFinite(Number(r.to)) ? Number(r.to) : Date.parse(r.end)
  const ref = Number.isFinite(Number(r.referenceTime)) ? r.referenceTime : Date.parse(r.referenceTime)
  const scope = isQuery ? r.scope : 'today'
  const q = {
    referenceTime: new Date(Number.isFinite(ref) ? ref : Date.now()).toISOString(),
    scope,
    start: new Date(Number.isFinite(from) ? from : 0).toISOString(),
    end: new Date(Number.isFinite(to) ? to : Date.now()).toISOString(),
    includeArchive: !!(isQuery ? r.includeArchive : false),
    includePrevDaySummary: !!(r.includePrevDaySummary),
    from: Number.isFinite(from) ? from : 0,
    to: Number.isFinite(to) ? to : Date.now(),
    label: r.label || '',
  }
  if (r.relativeDay !== undefined) q.relativeDay = r.relativeDay
  if (r.sessionId) q.sessionId = r.sessionId
  if (!q.label) q.label = scopeLabel(q)
  return { from: q.from, to: q.to, scope: q.scope, includeArchive: q.includeArchive, referenceTime: Date.parse(q.referenceTime), label: q.label, query: q }
}

export default { SCOPES, parseQueryScope, normalizeQuery, scopeLabel, bjDayStart, bjDayEnd, bjDayLabel, bjHm, isBjSameDay, makeQuery }
