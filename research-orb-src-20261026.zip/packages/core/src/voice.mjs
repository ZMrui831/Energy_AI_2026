// packages/core/src/voice.mjs
//
// S37·C 语音最小闭环（路线 A 的可测子集）：
//   · ASR：按住说话录制的 wav → faster_whisper 一次性转写（spawnSync，跑完即退——零常驻进程）。
//   · TTS：文本 → 本地 wav（CosyVoice2 优先；不可用 → Windows SAPI 兜底并如实标注 fallback）。
//   · 契约：makeDraftFromTranscript() 产出 autoSend:false 的草稿（**文本入框不自动发，需人确认**）。
//   · 播后删：playAndCleanup() 播完即删 wav；wav 一律落在系统临时目录，不进项目数据树。
//   · 降级：模型不可用 → E_VOICE_UNAVAILABLE + 明确原因，不影响主流程（调用方只收 {ok:false, reason}）。
//   · 明确不做：常驻 VAD + 唤醒词；本模块绝不 spawn 常驻进程。
import { spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { tmpdir, homedir } from 'node:os'
import { join } from 'node:path'
import { PROJECT_ROOT } from './safefs.mjs'
import { FORCE_UTF8_ENV } from './tools/py-runner.mjs'

// S37：专用 voice venv（av 14.2.0 + faster_whisper 1.2.1，与受管默认环境隔离）+ 本地 tiny 模型。
const VOICE_ENV = join(homedir(), '.workbuddy', 'binaries', 'python', 'envs', 'voice', 'Scripts', 'python.exe')
const VOICE_MODEL_DIR = join(homedir(), '.workbuddy', 'binaries', 'python', 'envs', 'voice', 'models', 'faster-whisper-tiny')
const VENV_CANDIDATES = [
  process.env.RESEARCH_VOICE_PYTHON || '',
  VOICE_ENV,
  'D:\\AI_Workspace\\dsh-orb-cordis\\.venv\\Scripts\\python.exe',
  join(homedir(), '.workbuddy', 'binaries', 'python', 'versions', '3.13.12', 'python.exe'),
  'C:\\Program Files\\Python313\\python.exe',
].filter(Boolean)

const ASR_SCRIPT = join(PROJECT_ROOT, 'tools', 'voice-asr.py')

/** 探测可用 ASR 解释器（含 faster_whisper；首个成功者，进程内缓存）。 */
let asrPyCache = null
export function probeAsrPython() {
  if (asrPyCache) return asrPyCache
  for (const py of VENV_CANDIDATES) {
    if (!existsSync(py)) continue
    const r = spawnSync(py, ['-c', 'import faster_whisper; print("ok")'], { encoding: 'utf8', timeout: 60000 })
    if (r.status === 0 && /ok/.test(r.stdout || '')) {
      asrPyCache = py
      return py
    }
  }
  return null
}

/**
 * 真音频转写：wav → faster_whisper（一次性进程）。
 * @returns {{ok:true, text:string, audioSec:number, model:string, loadMs:number, provider:'faster_whisper'}
 *          |{ok:false, code:'E_VOICE_UNAVAILABLE', reason:string}}
 */
/**
 * 解析 Python 子进程 stdout（S67·4-D 编码修复，复用 py-runner 的 UTF-8 约定）：
 *   · 严格 UTF-8 解码；非法字节 → {ok:false, code:'E_VOICE_DECODE'}（绝不静默出乱码）
 *   · 逐行找 JSON 行（whisper 可能往 stdout 打进度/警告；stderr 单独分离）
 *   · 无 JSON 行 → {ok:false, code:'E_VOICE_NO_JSON'}
 * @param {Buffer|string} buf
 */
export function parseAsrStdout(buf) {
  let text
  try {
    const b = Buffer.isBuffer(buf) ? buf : Buffer.from(String(buf || ''), 'utf8')
    text = new TextDecoder('utf-8', { fatal: true }).decode(b)
  } catch {
    return { ok: false, code: 'E_VOICE_DECODE', reason: 'ASR 输出不是合法 UTF-8（疑似控制台码页/未强制 PYTHONIOENCODING）' }
  }
  const lines = String(text).split(/\r?\n/).map((s) => s.trim()).filter(Boolean)
  for (let i = lines.length - 1; i >= 0; i -= 1) {
    if (!lines[i].startsWith('{')) continue
    try {
      const o = JSON.parse(lines[i])
      if (o && typeof o === 'object') return { ok: true, parsed: o }
    } catch { /* 下一行 */ }
  }
  return { ok: false, code: 'E_VOICE_NO_JSON', reason: 'ASR stdout 未找到 JSON 行' }
}

export function transcribeAudio(wavPath, { model = existsSync(VOICE_MODEL_DIR) ? VOICE_MODEL_DIR : 'tiny', device = 'cpu', timeoutMs = 300000 } = {}) {
  if (!existsSync(wavPath)) return { ok: false, code: 'E_VOICE_UNAVAILABLE', reason: '音频文件不存在：' + wavPath }
  const py = probeAsrPython()
  if (!py) return { ok: false, code: 'E_VOICE_UNAVAILABLE', reason: 'faster_whisper 不可用：没有带 faster_whisper 的 Python 解释器（dsh-orb venv 损坏或未安装）；语音输入降级为手动输入，不影响主流程' }
  // S67·4-D：强制 UTF-8（-X utf8 + PYTHONUTF8/PYTHONIOENCODING，与 py-runner 同一约定）；不预先 utf8 解码，取 Buffer 严格判定
  const r = spawnSync(py, ['-X', 'utf8', ASR_SCRIPT, wavPath, model, device], { timeout: timeoutMs, env: { ...process.env, ...FORCE_UTF8_ENV } })
  const dec = parseAsrStdout(r.stdout || Buffer.alloc(0))
  if (!dec.ok) return { ok: false, code: dec.code, reason: dec.reason + '｜stderr=' + String(r.stderr || '').slice(0, 140) }
  const parsed = dec.parsed
  if (!parsed || parsed.ok !== true) {
    const reason = (parsed && parsed.reason) || String(r.stderr || '').slice(0, 160) || '未知原因'
    return { ok: false, code: (parsed && parsed.code) || 'E_VOICE_UNAVAILABLE', reason }
  }
  return { ok: true, text: parsed.text, audioSec: parsed.audioSec, model: parsed.model, loadMs: parsed.loadMs, provider: 'faster_whisper' }
}

/**
 * 文本 → 本地 wav（CosyVoice2 优先；不可用 → Windows SAPI 兜底并如实标注）。
 * wav 落系统临时目录；返回 {ok, wavPath, durationSec, provider, fallback}。
 */
export function synthesizeWav(text, { provider = 'auto', outDir = null } = {}) {
  const body = String(text || '').trim()
  if (!body) return { ok: false, code: 'E_EMPTY_TEXT', reason: '没有可合成的文本' }
  const dir = outDir || mkdtempSync(join(tmpdir(), 'orb-tts-'))
  mkdirSync(dir, { recursive: true })
  const wavPath = join(dir, `tts-${Date.now()}.wav`)

  if (provider === 'auto' || provider === 'cosyvoice') {
    const r = cosyVoiceWav(body, wavPath)
    if (r.ok) return { ...r, fallback: false }
    if (provider === 'cosyvoice') return { ok: false, code: 'E_VOICE_UNAVAILABLE', reason: r.reason }
  }
  // SAPI 兜底（Windows 自带，离线；如实标注 fallback）。
  // 中文经命令行传参会乱码/丢引号 → 文本写 UTF-8(BOM) 临时文件，PowerShell 按 UTF8 读入。
  const txtFile = join(dir, `tts-${Date.now()}.txt`)
  writeFileSync(txtFile, '\ufeff' + body, 'utf8')
  const ps = [
    "Add-Type -AssemblyName System.Speech",
    "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer",
    `$s.SetOutputToWaveFile('${wavPath.replace(/'/g, "''")}')`,
    `$t = Get-Content -LiteralPath '${txtFile.replace(/'/g, "''")}' -Encoding UTF8 -Raw`,
    '$s.Speak($t)',
    '$s.Dispose()',
  ].join('; ')
  const r2 = spawnSync('powershell', ['-NoProfile', '-Command', ps], { encoding: 'utf8', timeout: 120000 })
  try { rmSync(txtFile, { force: true }) } catch { /* 尽力 */ }
  if (r2.status !== 0 || !existsSync(wavPath)) {
    return { ok: false, code: 'E_VOICE_UNAVAILABLE', reason: 'CosyVoice2 与系统 TTS 均不可用：' + String(r2.stderr || '').slice(0, 120) }
  }
  return { ok: true, wavPath, durationSec: wavDurationSec(wavPath), provider: 'sapi', fallback: true }
}

/** CosyVoice2 一次性合成（dsh-orb venv；venv 损坏/模型缺失 → 如实失败）。 */
function cosyVoiceWav(text, wavPath) {
  const script = join(PROJECT_ROOT, 'tools', 'voice-cosy.py')
  if (!existsSync(script)) return { ok: false, reason: 'voice-cosy.py 缺失' }
  for (const py of VENV_CANDIDATES) {
    if (!existsSync(py)) continue
    const r = spawnSync(py, [script, text, wavPath], { encoding: 'utf8', timeout: 600000 })
    const line = String(r.stdout || '').trim().split('\n').pop()
    try {
      const parsed = JSON.parse(line)
      if (parsed.ok === true && existsSync(wavPath)) return { ok: true, wavPath, durationSec: wavDurationSec(wavPath), provider: 'cosyvoice2' }
      if (parsed) return { ok: false, reason: parsed.reason || 'cosyvoice 合成失败' }
    } catch { /* 下一个候选 */ }
  }
  return { ok: false, reason: 'CosyVoice2 不可用（venv 损坏或模型缺失）' }
}

/** wav 时长（秒）：解析 RIFF/fmt 头，不引依赖。 */
export function wavDurationSec(path) {
  try {
    const b = readFileSync(path)
    if (b.toString('ascii', 0, 4) !== 'RIFF') return 0
    let off = 12
    let byteRate = 176400 // 兜底（44.1k 16bit stereo）
    while (off + 8 <= b.length) {
      const id = b.toString('ascii', off, off + 4)
      const size = b.readUInt32LE(off + 4)
      if (id === 'fmt ') {
        const channels = b.readUInt16LE(off + 10)
        const sampleRate = b.readUInt32LE(off + 12)
        const bits = b.readUInt16LE(off + 22)
        byteRate = sampleRate * channels * (bits / 8)
      }
      if (id === 'data') return Number((size / byteRate).toFixed(2))
      off += 8 + size + (size % 2)
    }
    return 0
  } catch { return 0 }
}

/**
 * 契约：转写文本 → 输入框草稿（**autoSend:false——不自动发，需人确认**）。
 */
export function makeDraftFromTranscript(text, { sessionId = null } = {}) {
  return { text: String(text || '').trim(), autoSend: false, source: 'voice', sessionId }
}

/**
 * 播放 wav（播放器可注入；默认 PowerShell SoundPlayer 同步播放）→ 播完即删。
 * @returns {{played:boolean, removed:boolean, path:string}}
 */
export function playAndCleanup(wavPath, { player = null } = {}) {
  let played = false
  try {
    if (typeof player === 'function') {
      player(wavPath)
      played = true
    } else {
      const ps = [
        "Add-Type -AssemblyName System.Speech",
        "$p = New-Object System.Speech.Synthesis.SpeechSynthesizer",
        `$p.SetOutputToNull()`,
        `$p.SetOutputToDefaultAudioDevice()`,
        `$p.Speak('${String(wavPath).replace(/'/g, "''")} 不支持直接读文件时忽略')`,
      ].join('; ')
      // SoundPlayer 播文件更直接：
      const ps2 = [
        "Add-Type -AssemblyName System.Speech",
        "$pl = New-Object System.Speech.Synthesis.SoundPlayer",
        `$pl.SoundLocation = '${String(wavPath).replace(/'/g, "''")}'`,
        '$pl.PlaySync()',
      ].join('; ')
      const r = spawnSync('powershell', ['-NoProfile', '-Command', ps2], { encoding: 'utf8', timeout: 120000 })
      played = r.status === 0
    }
  } catch { played = false }
  let removed = false
  try { rmSync(wavPath, { force: true }); removed = !existsSync(wavPath) } catch { removed = false }
  return { played, removed, path: wavPath }
}

/** 录音（按住说话）：PowerShell + System.Speech 不支持录制——用 WASAPI 录制超出零依赖范围，
 *  本模块只定义录制契约：宿主接 Electron desktopCapturer/Web Audio；验收用预置 wav 代录音。 */
export function recordContract() {
  return { maxSec: 15, kind: 'push-to-talk', note: '宿主经 Electron Web Audio 录制 ≤15s wav；本模块负责转写与播报' }
}

export default { transcribeAudio, parseAsrStdout, synthesizeWav, makeDraftFromTranscript, playAndCleanup, wavDurationSec, probeAsrPython, recordContract }
