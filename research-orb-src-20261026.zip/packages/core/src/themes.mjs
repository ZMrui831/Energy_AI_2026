// packages/core/src/themes.mjs
//
// 主题系统（P-R6 块 B）：data\themes\<name>.theme.json
//
// 设计取舍（docs/THEMES.md 有完整评审）：
//   · **不引第三方主题/皮肤依赖**（OpenProps/UnoCSS/Tailwind 都要构建期工具链或联网安装），
//     改用 **CSS 自定义属性（CSS variables）+ 一份 JSON token 文件**自建：
//     vendor\orb-base\panel\floating.css 的 :root 已经是一套 token，我们覆盖同名 token
//     即可换肤，且**一个像素的几何都不动**（球 96×96 / 展开 420×620 / 右下锚点）。
//   · 导入必须过 schema 校验：缺字段 / 非法颜色 / 路径穿越 → 拒绝且不写盘。
//   · 主题文件是【数据】不是代码：换肤 = 换一个 JSON，core 源码零改动。

import { existsSync, readFileSync, readdirSync, writeFileSync, mkdirSync } from 'node:fs'
import { join, resolve, sep } from 'node:path'

import { safeWrite, PROJECT_ROOT, assertInsideRoot, dataPath } from './safefs.mjs'

export const THEMES_DIR = dataPath('themes')
export const FONTS_DIR = dataPath('fonts')
export const DEFAULT_THEME = 'teal'

/** 颜色：hex（#rgb/#rrggbb）或 rgb()/rgba()（每通道 0–255）。 */
const COLOR_RE = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i
const COLOR_FN_RE = /^rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})\s*(,\s*(0|1|0?\.\d+)\s*)?\)$/i
/** 字号缩放：0.5–2.0 的数字。 */
const SCALE_RE = /^\d+(\.\d+)?$/

/** token schema：键 → 校验器。缺任何一个都拒绝导入。 */
export const THEME_SCHEMA = Object.freeze({
  name: (v) => typeof v === 'string' && /^[a-z0-9][a-z0-9._-]{0,48}$/i.test(v),
  description: (v) => typeof v === 'string',
  colors: (v) => v && typeof v === 'object' && !Array.isArray(v),
  radius: (v) => typeof v === 'string' && v.length <= 40,
  spacing: (v) => typeof v === 'string' && v.length <= 40,
  shadow: (v) => typeof v === 'string' && v.length <= 80,
  font: (v) => v && typeof v === 'object' && !Array.isArray(v),
  ball: (v) => v && typeof v === 'object' && !Array.isArray(v),
})

const REQUIRED_COLORS = Object.freeze(['bg', 'bgAlt', 'panel', 'text', 'textDim', 'accent', 'border', 'hover', 'ballFrom', 'ballTo'])
const REQUIRED_FONT = Object.freeze(['body', 'heading', 'mono', 'sizeScale'])
const REQUIRED_BALL = Object.freeze(['size', 'ring'])

function isColor(v) {
  if (typeof v !== 'string') return false
  const s = v.trim()
  if (COLOR_RE.test(s)) return true
  const m = COLOR_FN_RE.exec(s)
  if (!m) return false
  // 每通道必须落在 0–255
  return [m[1], m[2], m[3]].every((n) => Number(n) >= 0 && Number(n) <= 255)
}

export class ThemeError extends Error {
  constructor(code, message, details = {}) {
    super(message)
    this.name = 'ThemeError'
    this.code = code
    Object.assign(this, details)
  }
}

/**
 * 校验一份主题对象（不含 name 字段——name 由文件名决定，导入时可显式给）。
 * @returns {{ok:true, theme:object} | {ok:false, code:string, errors:string[]}}
 */
export function validateTheme(doc, { name = null } = {}) {
  const errors = []
  if (!doc || typeof doc !== 'object' || Array.isArray(doc)) {
    return { ok: false, code: 'E_THEME_NOT_OBJECT', errors: ['主题必须是 JSON 对象'] }
  }
  const merged = { ...doc }
  if (name) merged.name = name

  for (const [key, check] of Object.entries(THEME_SCHEMA)) {
    if (merged[key] === undefined) {
      errors.push(`缺字段：${key}`)
      continue
    }
    if (!check(merged[key])) errors.push(`字段类型/取值非法：${key}`)
  }

  const colors = merged.colors || {}
  for (const k of REQUIRED_COLORS) {
    if (colors[k] === undefined) errors.push(`colors 缺字段：${k}`)
    else if (!isColor(colors[k])) errors.push(`colors.${k} 不是合法颜色：${JSON.stringify(colors[k])}`)
  }
  const font = merged.font || {}
  for (const k of REQUIRED_FONT) {
    if (font[k] === undefined) errors.push(`font 缺字段：${k}`)
  }
  if (font.sizeScale !== undefined && !(typeof font.sizeScale === 'number' && font.sizeScale >= 0.5 && font.sizeScale <= 2)) {
    errors.push('font.sizeScale 必须是 0.5–2 的数字')
  }
  const ball = merged.ball || {}
  for (const k of REQUIRED_BALL) {
    if (ball[k] === undefined) errors.push(`ball 缺字段：${k}`)
  }
  if (ball.size !== undefined && !(typeof ball.size === 'number' && ball.size >= 48 && ball.size <= 160)) {
    errors.push('ball.size 必须是 48–160 的数字（几何契约：球窗口尺寸由此派生）')
  }
  if (ball.ring !== undefined && !isColor(ball.ring)) errors.push('ball.ring 不是合法颜色')

  if (errors.length > 0) return { ok: false, code: 'E_THEME_SCHEMA', errors }
  return { ok: true, theme: merged }
}

/** 主题文件名 → 绝对路径（name 做路径穿越防护）。 */
export function themePath(name) {
  const n = String(name || '').trim()
  if (!/^[a-z0-9][a-z0-9._-]{0,48}$/i.test(n)) {
    throw new ThemeError('E_THEME_BAD_NAME', `themes: 非法主题名 -> ${n}`, { name: n })
  }
  return assertInsideRoot(join(THEMES_DIR, `${n}.theme.json`))
}

/** 列出可用主题（只读目录）。 */
export function listThemes(dir = THEMES_DIR) {
  let names = []
  try {
    names = readdirSync(dir).filter((f) => f.endsWith('.theme.json'))
  } catch {
    return []
  }
  const out = []
  for (const f of names) {
    const name = f.replace(/\.theme\.json$/, '')
    try {
      const doc = JSON.parse(readFileSync(join(dir, f), 'utf8'))
      const v = validateTheme(doc, { name })
      out.push({
        name,
        description: typeof doc.description === 'string' ? doc.description : '',
        ok: v.ok,
        errors: v.ok ? [] : v.errors,
      })
    } catch {
      out.push({ name, description: '', ok: false, errors: ['JSON 解析失败'] })
    }
  }
  return out.sort((a, b) => a.name.localeCompare(b.name))
}

/** 读一个主题（校验不过直接抛 ThemeError，绝不把坏主题喂给 UI）。 */
export function readTheme(name, dir = THEMES_DIR) {
  const p = themePath(name)
  if (!existsSync(p)) throw new ThemeError('E_THEME_NOT_FOUND', `themes: 主题不存在 -> ${name}`, { name })
  let doc
  try {
    doc = JSON.parse(readFileSync(p, 'utf8'))
  } catch {
    throw new ThemeError('E_THEME_BAD_JSON', `themes: 主题 JSON 解析失败 -> ${name}`, { name })
  }
  const v = validateTheme(doc, { name })
  if (!v.ok) throw new ThemeError('E_THEME_SCHEMA', `themes: 主题未通过 schema 校验 -> ${name}：${v.errors.join('；')}`, { name, errors: v.errors })
  return v.theme
}

/**
 * 导入主题（schema 校验通过才写盘；路径穿越/缺字段/非法色一律拒绝且不写）。
 * @param {string} name 目标主题名
 * @param {object} doc 主题对象
 */
export function importTheme(name, doc, dir = THEMES_DIR) {
  const p = themePath(name)
  const v = validateTheme(doc, { name })
  if (!v.ok) {
    throw new ThemeError('E_THEME_SCHEMA', `themes: 拒绝导入 -> ${name}：${v.errors.join('；')}`, { name, errors: v.errors })
  }
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true })
  safeWrite(p, `${JSON.stringify(v.theme, null, 2)}\n`)
  return v.theme
}

/** 导出主题（读回并序列化；不存在抛错）。 */
export function exportTheme(name, dir = THEMES_DIR) {
  return JSON.stringify(readTheme(name, dir), null, 2)
}

/** 把 #rrggbb 按比例变暗（用于球体渐变第三档，保持 sphere 立体感且随主题走）。 */
function darkenHex(hex, factor) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || '').trim())
  if (!m) return hex
  const n = parseInt(m[1], 16)
  const ch = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((x) =>
    Math.max(0, Math.min(255, Math.round(x * factor))).toString(16).padStart(2, '0')
  )
  return '#' + ch.join('')
}

/**
 * 主题 → CSS 自定义属性（覆盖 vendor :root 的同名 token，只改颜色/字体/圆角/阴影）。
 * 几何相关 token（--ball / --chrome / --panel-radius 之外的一切尺寸）**不在此列**，
 * 因此换肤不可能破坏几何契约。
 */
export function themeToCss(theme) {
  const c = theme.colors || {}
  const f = theme.font || {}
  const b = theme.ball || {}
  const scale = Number(f.sizeScale) || 1
  const lines = [
    ':root {',
    `  --black: ${c.text};`,
    `  --white: ${c.panel};`,
    `  --input-bg: ${c.bgAlt};`,
    `  --border: ${c.border};`,
    `  --pin: ${c.textDim};`,
    `  --error: ${c.accent};`,
    `  --hover-bg: ${c.hover};`,
    `  --ro-bg: ${c.bg};`,
    `  --ro-accent: ${c.accent};`,
    `  --ball-shadow: ${theme.shadow};`,
    `  --panel-shadow: ${theme.shadow};`,
    `  --panel-radius: ${theme.radius};`,
    `  --ro-spacing: ${theme.spacing};`,
    `  --ro-ring: ${b.ring};`,
    `  --ro-warn: ${c.warn || '#f59e0b'};`,
    `  --ro-danger: ${c.danger || '#ef4444'};`,
    `  --ro-info: ${c.info || c.accent};`,
    `  --ro-face: ${c.face || '#eafffb'};`,
    `  --ro-ball-from: ${c.ballFrom};`,
    `  --ro-ball-to: ${c.ballTo};`,
    `  --ro-ball-deep: ${darkenHex(c.ballTo, 0.62)};`,
    `  --ro-mono: ${f.mono};`,
    `  font-family: ${f.body};`,
    `  font-size: ${Math.round(13 * scale)}px;`,
    '}',
    'h1, h2, h3, h4, .ro-lit-title, .ro-timer-title, .ro-group-title, .ro-welcome-title {',
    `  font-family: ${f.heading};`,
    '}',
    'pre, code, .ro-timer-report {',
    `  font-family: ${f.mono};`,
    '}',
    `#ball { background: radial-gradient(circle at 35% 28%, var(--ro-ball-from), var(--ro-ball-to)); box-shadow: var(--ball-shadow), 0 0 0 1.5px ${b.ring}, 0 0 7px ${b.ring}; }`,
  ]
  return lines.join('\n')
}

/**
 * 字体回退链（绝不出现豆腐块）。
 * 正文默认宋体 SimSun，标题默认楷体 KaiTi（Windows 内置，无需下载）；
 * data/fonts\ 下用户自备的开源字体优先加载；最后始终落到系统通用族。
 */
export function fontStack(preferred, fallbacks) {
  const parts = []
  if (Array.isArray(preferred)) parts.push(...preferred.filter(Boolean))
  else if (typeof preferred === 'string' && preferred.trim()) parts.push(preferred.trim())
  for (const f of fallbacks || []) if (f) parts.push(f)
  return parts.join(', ')
}

export const BODY_FALLBACK = Object.freeze(['SimSun', '宋体', 'Songti SC', 'Noto Serif CJK SC', 'serif'])
export const HEADING_FALLBACK = Object.freeze(['KaiTi', '楷体', 'STKaiti', 'Noto Serif CJK SC', 'serif'])
export const MONO_FALLBACK = Object.freeze(['Consolas', 'Courier New', 'monospace'])

/** data/fonts 下用户自备字体（自动加载并优先；只列文件，不校验内容）。 */
export function userFonts(dir = FONTS_DIR) {
  try {
    return readdirSync(dir).filter((f) => /\.(ttf|otf|ttc|woff2?)$/i.test(f)).sort()
  } catch {
    return []
  }
}

/**
 * WCAG 相对亮度与对比度（可验收设计约束的判定依据）。
 * 正文对比度 ≥4.5:1、次要文字 ≥3:1（见 docs/THEMES.md 第 5 节）。
 */
export function relLuminance(hex) {
  const m = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i.exec(String(hex || '').trim())
  if (!m) return null
  let h = m[1].toLowerCase()
  if (h.length === 3) h = h.split('').map((c) => c + c).join('')
  const rgb = [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16) / 255)
  const lin = rgb.map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4))
  return 0.2126 * lin[0] + 0.7152 * lin[1] + 0.0722 * lin[2]
}

/** 两色对比度（1–21）。任一色无法解析返回 null。 */
export function contrastRatio(a, b) {
  const la = relLuminance(a)
  const lb = relLuminance(b)
  if (la === null || lb === null) return null
  const [hi, lo] = la >= lb ? [la, lb] : [lb, la]
  return (hi + 0.05) / (lo + 0.05)
}

export default {
  listThemes, readTheme, importTheme, exportTheme, validateTheme, themeToCss, themePath,
  THEMES_DIR, FONTS_DIR, DEFAULT_THEME, THEME_SCHEMA, fontStack, userFonts,
  BODY_FALLBACK, HEADING_FALLBACK, MONO_FALLBACK,
}