// packages/core/src/budget.mjs
//
// §5.5 硬预算与 7 级降级（纯函数 + 单测可覆盖）。
//
// 设计要点（主管模式 S2 策略子代理独占文件）：
//   1. 纯函数：evaluateBudget(metrics, opts) 输入当前指标 + 可配阈值，输出下一步降级级别。
//   2. 单调升级与恢复：每个级别有独立的 trigger(metrics) 判定；最终级别 = 所有被触发级别中的
//      最高级（因为高级别动作是低级别的超集）。指标好转时，最高触发级自然下降 → 自动恢复。
//   3. 级别越高越严重，动作逐级叠加（actions 数组包含 1..level 全部动作）。
//   4. 级别 0 = 正常，无降级。
//
// 7 级降级顺序（超限依次执行）：
//   1. 关远端视觉模型          — P95 CPU 超限
//   2. OCR 间隔 ×2             — 平均 CPU 超限（持续负载）
//   3. 截图间隔 ×2             — 内存超限
//   4. 停原图只留元数据        — 磁盘日增超限
//   5. 停云调用切规则摘要      — 内存严重超限（≥ 2×阈值，纯函数可调）
//   6. 磁盘 <1GB 立即停截图    — 磁盘剩余不足
//   7. 电量 <10% 且未充电只采元数据 — 电量危急
//
// 注意：级别判定用严格大于（>），因此恰等于阈值不算超限（边界单测见 tests/budget.test.mjs）。

import { safeWrite, appendJsonl } from './safefs.mjs'

/** 默认阈值（可被 opts 覆盖）。阈值语义：超过该值即触发对应级别。 */
export const DEFAULT_THRESHOLDS = {
  cpuP95: 12, // %   P95 CPU 上限
  cpuAvg: 3, //  %   平均 CPU 上限
  memMB: 300, // MB  内存上限
  diskAddGB: 0.5, // GB 磁盘日增上限
  memSevereMB: 600, // MB 内存严重上限（触发第 5 级：停云调用）
  diskFreeGB: 1, //  GB 磁盘剩余下限
  batteryPct: 10, // %  电量下限（且未充电）
}

// ---------------------------------------------------------------------------
// S58·P0-1：阈值改"相对自身基线"（绝对常数在正常机器上必然误触发 —— 本机曾常年 L5）
//   启动采样 60s 自身 P95/均值/内存 → data/budget-baseline.json → 阈值 = base × 系数。
//   极值兜底：内存 ≥ 3000MB 无条件升 L3/L5（基线异常高时仍能兜住真空失控）。
// ---------------------------------------------------------------------------
export const BASELINE_FACTORS = Object.freeze({ cpuP95: 2.5, cpuAvg: 2, memMB: 1.8 })
/** 内存极值兜底（MB）：任何情况下 memMB ≥ 该值都必须升 L3/L5。 */
export const MEM_ABS_CAP_MB = 3000
/** 阈值下限保护：基线采到 0 时阈值不能为 0（否则永远触发）。 */
const THRESHOLD_FLOOR = Object.freeze({ cpuP95: 1.5, cpuAvg: 0.8, memMB: 200 })

/** 首启无基线时的宽松兜底（**过渡期宁可完全不降级**；60s 基线建立后按 base×系数收紧）。
 *  S58 实测：本机采样本底可到 20–35%（Windows 桌面 + 验证脚本并发），任何"看起来正常"的
 *  固定阈值都会误报。因此首启兜底取 50%/90% 这种只有真失控才会碰到的值。 */
export const FALLBACK_THRESHOLDS = Object.freeze({
  cpuP95: 90,
  cpuAvg: 50,
  memMB: MEM_ABS_CAP_MB,
  memSevereMB: MEM_ABS_CAP_MB,
  diskAddGB: 0.5,
  diskFreeGB: 1,
  batteryPct: 10,
})

/**
 * 由基线生成阈值（相对自身基线）。缺字段用 DEFAULT_THRESHOLDS 对应值。
 * @param {{cpuP95?:number, cpuAvg?:number, memMB?:number}} baseline
 * @returns {object} 完整阈值对象
 */
export function thresholdsFromBaseline(baseline = {}) {
  const b = (v, dflt) => (Number.isFinite(Number(v)) && Number(v) > 0 ? Number(v) : dflt)
  const cpuP95 = Math.max(THRESHOLD_FLOOR.cpuP95, b(baseline.cpuP95, 0) * BASELINE_FACTORS.cpuP95)
  const cpuAvg = Math.max(THRESHOLD_FLOOR.cpuAvg, b(baseline.cpuAvg, 0) * BASELINE_FACTORS.cpuAvg)
  const memBase = b(baseline.memMB, 0) || 300
  // 内存：S58 起**只做极值兜底**（3000MB）——基线相对系数（1.8）在本机反而误触发；
  // 展示上 memMB 阈值即极值门槛，避免诊断页给出与实际判定不一致的数。
  const memMB = MEM_ABS_CAP_MB
  const memSevereMB = MEM_ABS_CAP_MB
  return { ...DEFAULT_THRESHOLDS, cpuP95, cpuAvg, memMB, memSevereMB, memBaselineRelaxed: Math.round(memBase * BASELINE_FACTORS.memMB) }
}

/** 每级动作（索引 [level] = 该级新增动作；actions 返回 1..level 的累积）。
 *  S58·P0-2：**永久移除 disable-visual-model** —— 视觉模型调用是免费的，关掉只有功能损失，
 *  而且此前根本没有消费者（审计写了 action 却没人执行 = 审计在撒谎）。L1 仅保留 level 语义（诊断可看 fired）。 */
const LEVEL_ACTIONS = [
  [], // 0 正常
  [], // 1 P95 CPU 超限（无动作；仅诊断可见，视觉不再关）
  ['ocr-interval-x2'], // 2
  ['shot-interval-x2'], // 3
  ['stop-original-images'], // 4
  ['stop-cloud-rule-summary'], // 5
  ['stop-screenshots-disk'], // 6
  ['metadata-only-battery'], // 7
]

export const MAX_LEVEL = LEVEL_ACTIONS.length - 1 // 7

/** 合并默认阈值与调用方 opts。 */
function resolveThresholds(opts = {}) {
  return { ...DEFAULT_THRESHOLDS, ...(opts.thresholds || {}) }
}

/**
 * 每级触发判定（纯函数）。返回 true 表示该级应被触发。
 * @param {number} level 1..7
 * @param {object} m 指标
 * @param {object} t 已解析的阈值
 */
export function trigger(level, m, t) {
  switch (level) {
    case 1: // P95 CPU 超限
      return num(m.cpuP95) > t.cpuP95
    case 2: // 平均 CPU 超限
      return num(m.cpuAvg) > t.cpuAvg
    case 3: // 内存超限 —— 阈值来自 thresholds.memMB（基线路径下恒为 3000 极值兜底；测试可显式覆盖）
      return num(m.memMB) > t.memMB
    case 4: // 磁盘日增超限
      return num(m.diskAddedGB) > t.diskAddGB
    case 5: // 内存严重超限 → 停云调用（同上，基线路径 = 3000）
      return num(m.memMB) > t.memSevereMB
    case 6: // 磁盘剩余不足（缺指标 = 未知 → 不触发；不能用 -Infinity 兜底，否则缺失反而触发）
      return has(m.diskFreeGB) && num(m.diskFreeGB) < t.diskFreeGB
    case 7: // 电量危急且未充电（充放电未知 → 不触发；charging 必须显式 === false）
      return has(m.batteryPct) && num(m.batteryPct) < t.batteryPct && m.charging === false
    default:
      return false
  }
}

/** 数值安全化：undefined/null/NaN → -Infinity（视为不触发）。 */
function has(v) { const n = Number(v); return Number.isFinite(n) }

function num(v) {
  const n = Number(v)
  return Number.isFinite(n) ? n : -Infinity
}

/**
 * 计算应处的降级级别（0..7）。
 * 取所有被触发级别中的最高级：因为高级别动作是低级别的超集，
 * 这样实现天然满足「单调升级」与「指标好转自动恢复」。
 */
export function levelFor(metrics, opts = {}) {
  const t = resolveThresholds(opts)
  let level = 0
  for (let lv = 1; lv <= MAX_LEVEL; lv++) {
    if (trigger(lv, metrics, t)) level = lv
  }
  return level
}

/** 累积动作列表：级别 lv 对应 1..lv 全部动作。 */
export function actionsFor(level) {
  const out = []
  for (let lv = 1; lv <= level; lv++) out.push(...LEVEL_ACTIONS[lv])
  return out
}

/**
 * S58·P0-3：诊断（只读）——各级 trigger 是否 fired + 当前 level + 生效阈值 + 动作。
 * 供诊断页展示（此前只能靠手写脚本才看得见）。
 * @returns {{level:number, actions:string[], thresholds:object, fired:Array<{level:number, fired:boolean}>}}
 */
export function diagnoseBudget(metrics, opts = {}) {
  const t = resolveThresholds(opts)
  const fired = []
  let level = 0
  for (let lv = 1; lv <= MAX_LEVEL; lv++) {
    const f = trigger(lv, metrics, t)
    fired.push({ level: lv, fired: f })
    if (f) level = lv
  }
  return { level, actions: actionsFor(level), thresholds: t, fired }
}

/**
 * 评估下一步预算级别与应执行动作。
 * @param {object} metrics 当前指标
 * @param {object} [opts] { thresholds?, current? }
 *   - current: 当前已处级别（用于判定 downgraded/recovered）；缺省 0。
 * @returns {{level:number, actions:string[], downgraded:boolean, recovered:boolean}}
 */
export function evaluateBudget(metrics, opts = {}) {
  const level = levelFor(metrics, opts)
  const current = typeof opts.current === 'number' ? opts.current : 0
  return {
    level,
    actions: actionsFor(level),
    downgraded: level > current,
    recovered: level < current,
  }
}

/**
 * 带当前级别的便捷封装（主管调用时传入 current）。
 */
export function nextBudgetLevel(current, metrics, opts = {}) {
  return evaluateBudget(metrics, { ...opts, current })
}

/**
 * 审计：把一次降级决策追加到数据目录日志（可选，由 E 在采集循环调用）。
 * 走 safefs，绝不直接落盘。测试可注入 writer。
 */
export function recordDecision(metrics, decision, opts = {}) {
  const writer = opts.writer || defaultWriter
  return writer('data/logs/budget.jsonl', {
    ts: new Date().toISOString(),
    level: decision.level,
    actions: decision.actions,
    metrics,
  })
}

function defaultWriter(path, record) {
  return appendJsonl(path, record)
}

export default {
  DEFAULT_THRESHOLDS,
  FALLBACK_THRESHOLDS,
  BASELINE_FACTORS,
  MEM_ABS_CAP_MB,
  thresholdsFromBaseline,
  diagnoseBudget,
  MAX_LEVEL,
  trigger,
  levelFor,
  actionsFor,
  evaluateBudget,
  nextBudgetLevel,
  recordDecision,
}
