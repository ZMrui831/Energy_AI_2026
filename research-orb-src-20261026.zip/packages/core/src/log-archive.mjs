// packages/core/src/log-archive.mjs
//
// S33·E 轮转与基线的张力：writes.jsonl 参与 rotateOnly 轮转会让 live 行数下降，
// 若基线只比 live，就会误报 E_AUDIT_LOSS（"轮转 = 丢档"）。
//
// 规则（写死）：
//   · 轮转必须**归档**到 data/logs/rotated/<name>.<ts>.jsonl（移动语义，不是复制）；
//   · 并在 data/logs/rotated/MANIFEST.json 记 {file, archivedLines, at, dest}；
//   · 基线比对口径 = live 行数 + 该文件全部归档行数（= 高水位），故轮转不再等于丢档。
//
// 本模块只做文件搬运与统计，不做策略判断；audit-preflight 消费 archiveStats()。
import { existsSync, readdirSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'

export const ARCHIVE_SUBDIR = 'rotated'
export const MANIFEST_NAME = 'MANIFEST.json'

export const rotatedDir = (logsDir) => join(logsDir, ARCHIVE_SUBDIR)
export const manifestPath = (logsDir) => join(rotatedDir(logsDir), MANIFEST_NAME)

function lineCount(p) {
  try { return readFileSync(p, 'utf8').split('\n').filter((l) => l.trim()).length } catch { return 0 }
}
function readLines(p) {
  try { return readFileSync(p, 'utf8').split('\n').filter((l) => l.trim()) } catch { return [] }
}
function tsStamp(now) {
  return (now ? new Date(now) : new Date()).toISOString().replace(/[-:]/g, '').replace(/\..*$/, '')
}
const escapeRe = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&')

/** 读取 MANIFEST（不存在/损坏 → []）。 */
export function readManifest(logsDir) {
  try {
    const j = JSON.parse(readFileSync(manifestPath(logsDir), 'utf8'))
    return Array.isArray(j) ? j : []
  } catch { return [] }
}
function writeManifest(logsDir, entries) {
  mkdirSync(rotatedDir(logsDir), { recursive: true })
  writeFileSync(manifestPath(logsDir), JSON.stringify(entries, null, 2) + '\n', 'utf8')
}

/**
 * 归档一个日志文件：live 内容搬到 rotated/<file>.<ts>.jsonl，live 清空，MANIFEST 记账。
 * 移动语义：live + archived 总量守恒（不复制、不重复计）。
 * @returns {{file:string, archivedLines:number, at:string|null, dest:string|null}}
 */
export function archiveFile(logsDir, file, { now } = {}) {
  const livePath = join(logsDir, file)
  if (!existsSync(livePath)) return { file, archivedLines: 0, at: null, dest: null }
  const arr = readLines(livePath)
  if (arr.length === 0) return { file, archivedLines: 0, at: null, dest: null }
  const ts = tsStamp(now)
  mkdirSync(rotatedDir(logsDir), { recursive: true })
  const destName = `${file}.${ts}.jsonl`
  const dest = join(rotatedDir(logsDir), destName)
  if (existsSync(dest)) writeFileSync(dest, readFileSync(dest, 'utf8').replace(/\n$/, '') + '\n' + arr.join('\n') + '\n', 'utf8')
  else writeFileSync(dest, arr.join('\n') + '\n', 'utf8')
  writeFileSync(livePath, '', 'utf8') // 清空 live（移动语义）
  const at = (now ? new Date(now) : new Date()).toISOString()
  const entries = readManifest(logsDir)
  entries.push({ file, archivedLines: arr.length, at, dest: destName })
  writeManifest(logsDir, entries)
  return { file, archivedLines: arr.length, at, dest: destName }
}

/**
 * 统计某文件的 live / archived / total。
 * archived 只按**物理文件**计一遍：
 *   (a) rotated/<file>.<ts>.jsonl（E 约定）
 *   (b) 同目录按天分片 <base>-YYYYMMDD[-N].jsonl（rotateLogs 既有产物）
 *   (c) 旧式 <base>-archived-<ts>.jsonl（rotateLogs 保留期归档）
 * @returns {{live:number, archived:number, total:number, detail:Array<{path,lines}>, manifest:Array}}
 */
export function archiveStats(logsDir, file) {
  const base = String(file).replace(/\.jsonl$/, '')
  const live = lineCount(join(logsDir, file))
  const detail = []

  const rot = rotatedDir(logsDir)
  if (existsSync(rot)) {
    const prefix = `${file}.`
    for (const n of readdirSync(rot)) {
      if (n === MANIFEST_NAME) continue
      if (n.startsWith(prefix) && n.endsWith('.jsonl')) {
        detail.push({ path: join(ARCHIVE_SUBDIR, n), lines: lineCount(join(rot, n)) })
      }
    }
  }

  if (existsSync(logsDir)) {
    const reDay = new RegExp(`^${escapeRe(base)}-\\d{8}(-\\d+)?\\.jsonl$`)
    const reArch = new RegExp(`^${escapeRe(base)}-archived-\\d+\\.jsonl$`)
    for (const n of readdirSync(logsDir)) {
      if (reDay.test(n) || reArch.test(n)) detail.push({ path: n, lines: lineCount(join(logsDir, n)) })
    }
  }

  const archived = detail.reduce((a, d) => a + d.lines, 0)
  return { live, archived, total: live + archived, detail, manifest: readManifest(logsDir).filter((e) => e && e.file === file) }
}

export default { ARCHIVE_SUBDIR, MANIFEST_NAME, rotatedDir, manifestPath, readManifest, archiveFile, archiveStats }
