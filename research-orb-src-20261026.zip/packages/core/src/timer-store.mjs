// packages/core/src/timer-store.mjs
//
// 阶段 3 数据模型（唯一可写根内的全部落点，对应任务书交付 1）：
//
//   data\projects\<id>.json          项目与阶段（/project 命令的操作对象）
//   data\timer\state.json            计时运行态（崩溃恢复的依据）
//   data\timer\settings.json         { notifications: true } 通知开关
//   data\timer\<YYYY-MM-DD>.jsonl    当日事件流（append-only：start/pause/resume/segment/stop/idle.*）
//   data\progress\<YYYY-MM-DD>.json  当日进度汇总（每 60s 与计时结束时刷新）
//   data\reports\daily-<date>.md     日报（纯模板必生成，LLM 失败回落）
//   data\reports\weekly-<monday>.md  周报（同上）
//
// 为什么引擎不直接碰 node:fs：timer.mjs / progress.mjs 只面对本文件定义的 store 接口，
// 于是"数据长什么样、落在哪儿"和"计时逻辑"可以分开单测 —— 测试注入内存 store，
// 真实运行用 safefs 版 store（断言在项目根内 + writes.jsonl 留痕）。
//
// 写入口径：
//   · state/settings/progress 是整体覆盖写（小文件，原子语义更重要）；
//   · state.json 用心跳式高频写，经 safeWrite(audit:false) —— 否则每 30s 一行
//     writes.jsonl 会把"谁改了工程文件"的审计淹掉（权威记录是 day jsonl）；
//   · day jsonl 是 appendJsonl（追加写，崩到一半前面的行仍然完整）。

import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs'
import { join } from 'node:path'

import { PROJECT_ROOT, appendJsonl, assertInsideRoot, safeWrite, dataPath } from './safefs.mjs'

/** data\ 下的四个新目录（全部在唯一可写根内）。 */
export const TIMER_DIR = dataPath('timer')
export const PROGRESS_DIR = dataPath('progress')
export const REPORTS_DIR = dataPath('reports')
export const PROJECTS_DIR = dataPath('projects')

export const STATE_FILE = join(TIMER_DIR, 'state.json')
export const SETTINGS_FILE = join(TIMER_DIR, 'settings.json')

/** 项目 id：只允许安全文件名字符（与插件 id 同规格，杜绝 ../ 之类路径花招）。 */
const ID_RE = /^[a-z0-9][a-z0-9._-]{1,63}$/i
/** 日期键：YYYY-MM-DD，且必须是真实存在的一天。 */
const DAY_RE = /^\d{4}-\d{2}-\d{2}$/

export class StoreError extends Error {
  constructor(code, message, details = {}) {
    super(message)
    this.name = 'StoreError'
    this.code = code
    Object.assign(this, details)
  }
}

export function assertId(id) {
  if (typeof id !== 'string' || !ID_RE.test(id)) {
    throw new StoreError('E_BAD_ID', `timer-store: 非法 id -> ${String(id)}`)
  }
  return id
}

export function assertDayKey(dayKey) {
  const s = String(dayKey || '')
  if (!DAY_RE.test(s)) throw new StoreError('E_BAD_DAY', `timer-store: 非法日期键 -> ${s}`)
  const [y, m, d] = s.split('-').map(Number)
  const dt = new Date(y, m - 1, d)
  if (dt.getFullYear() !== y || dt.getMonth() !== m - 1 || dt.getDate() !== d) {
    throw new StoreError('E_BAD_DAY', `timer-store: 日期不存在 -> ${s}`)
  }
  return s
}

/** 本地时区的日期键（应用与用户都在 UTC+8，用本地时间而不是 UTC，日报才不会跨天错位）。 */
export function dayKeyOf(ts) {
  const d = new Date(ts)
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}

/** 日期键 -> 本地午夜毫秒。 */
export function dayStartMs(dayKey) {
  assertDayKey(dayKey)
  const [y, m, d] = dayKey.split('-').map(Number)
  return new Date(y, m - 1, d).getTime()
}

export function dayEndMs(dayKey) {
  return dayStartMs(dayKey) + 86_400_000
}

/** 所在周的周一日期键（周报聚合单位）。 */
export function weekMondayOf(ts) {
  const d = new Date(ts)
  const shift = (d.getDay() + 6) % 7 // 周一=0 … 周日=6
  d.setDate(d.getDate() - shift)
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}

export function addDays(dayKey, n) {
  const d = new Date(dayStartMs(dayKey))
  d.setDate(d.getDate() + n)
  return dayKeyOf(d.getTime())
}

function readJsonFile(path) {
  try {
    if (!existsSync(path)) return null
    return JSON.parse(readFileSync(path, 'utf8'))
  } catch {
    return null
  }
}

function readJsonlFile(path) {
  try {
    if (!existsSync(path)) return []
    return readFileSync(path, 'utf8')
      .split('\n')
      .filter((l) => l.trim().length > 0)
      .map((l) => {
        try {
          return JSON.parse(l)
        } catch {
          return null // 坏行跳过：半行崩溃不该让整天记录报废
        }
      })
      .filter(Boolean)
  } catch {
    return []
  }
}

/**
 * 判断 data/notes 下的一级目录是不是某个插件的私有抽屉（packages/plugins/<name>/ 存在即是）。
 * 产出统计要排除它们 —— 插件自己的 state.json 不是用户的科研产出。
 * 用"目录名能否在 packages/plugins 下找到"做判据，而不是硬编码插件 id 清单。
 */
function isPluginDrawer(firstSegment) {
  if (!firstSegment || firstSegment.startsWith('.')) return true
  return existsSync(join(PROJECT_ROOT, 'packages', 'plugins', firstSegment))
}

/** 递归收集目录下符合条件的文件（带 mtimeMs）。depth 上限防止意外深目录。 */
function walk(dir, predicate, out = [], depth = 0) {
  if (depth > 6) return out
  let names = []
  try {
    names = readdirSync(dir)
  } catch {
    return out
  }
  for (const name of names) {
    const abs = join(dir, name)
    let st = null
    try {
      st = statSync(abs)
    } catch {
      continue
    }
    if (st.isDirectory()) {
      walk(abs, predicate, out, depth + 1)
    } else if (predicate(abs)) {
      out.push({ path: abs, mtimeMs: st.mtimeMs })
    }
  }
  return out
}

/** 相对项目根的展示路径（报表里只出现相对路径，不泄露绝对路径）。 */
function relOf(abs) {
  return abs.slice(PROJECT_ROOT.length + 1).replace(/\\/g, '/')
}

/**
 * 默认 store：safefs 版（真实运行用）。
 * 所有写都落在唯一可写根内；day jsonl 走 appendJsonl（无级联审计），
 * state/settings/progress/report 走 safeWrite。
 */
export function createDefaultStore() {
  const paths = {
    state: STATE_FILE,
    settings: SETTINGS_FILE,
    day: (dayKey) => assertInsideRoot(join(TIMER_DIR, `${assertDayKey(dayKey)}.jsonl`)),
    project: (id) => assertInsideRoot(join(PROJECTS_DIR, `${assertId(id)}.json`)),
    progress: (dayKey) => assertInsideRoot(join(PROGRESS_DIR, `${assertDayKey(dayKey)}.json`)),
    report: (kind, key) => assertInsideRoot(join(REPORTS_DIR, `${kind}-${assertDayKey(key)}.md`)),
  }
  return {
    paths,
    readState: () => readJsonFile(paths.state),
    writeState: (obj) => safeWrite(paths.state, JSON.stringify(obj, null, 2), { audit: false }),
    readSettings: () => readJsonFile(paths.settings),
    writeSettings: (obj) => safeWrite(paths.settings, JSON.stringify(obj, null, 2)),
    appendDay: (dayKey, record) => appendJsonl(paths.day(dayKey), record),
    readDay: (dayKey) => readJsonlFile(paths.day(dayKey)),
    readProject: (id) => readJsonFile(paths.project(id)),
    writeProject: (obj) => safeWrite(paths.project(obj.id), JSON.stringify(obj, null, 2)),
    listProjects: () => {
      let names = []
      try {
        names = readdirSync(PROJECTS_DIR)
      } catch {
        return []
      }
      return names
        .filter((n) => n.toLowerCase().endsWith('.json'))
        .map((n) => readJsonFile(join(PROJECTS_DIR, n)))
        .filter(Boolean)
    },
    readProgress: (dayKey) => readJsonFile(paths.progress(dayKey)),
    writeProgress: (dayKey, obj) => safeWrite(paths.progress(dayKey), JSON.stringify(obj, null, 2)),
    readReport: (kind, key) => {
      try {
        const p = paths.report(kind, key)
        return existsSync(p) ? readFileSync(p, 'utf8') : null
      } catch {
        return null
      }
    },
    writeReport: (kind, key, text) => safeWrite(paths.report(kind, key), text),
    /** 当日产出：data/notes/** 的 .md 卡片 + data/exports/** 的 .bib，按 mtime 落在这一天。 */
    outputs: (dayKey) => {
      const from = dayStartMs(dayKey)
      const to = dayEndMs(dayKey)
      const inDay = (mtimeMs) => mtimeMs >= from && mtimeMs < to
      const notes = walk(dataPath('notes'), (abs) => {
        if (!abs.toLowerCase().endsWith('.md')) return false
        const rel = relOf(abs)
        const first = rel.split('/')[2] // data/notes/<first>/...
        return !isPluginDrawer(first)
      })
        .filter((f) => inDay(f.mtimeMs))
        .map((f) => ({ rel: relOf(f.path), mtimeMs: f.mtimeMs }))
      const bibs = walk(dataPath('exports'), (abs) => abs.toLowerCase().endsWith('.bib'))
        .filter((f) => inDay(f.mtimeMs))
        .map((f) => ({ rel: relOf(f.path), mtimeMs: f.mtimeMs }))
      notes.sort((a, b) => a.rel.localeCompare(b.rel))
      bibs.sort((a, b) => a.rel.localeCompare(b.rel))
      return { cards: notes, bib: bibs }
    },
  }
}

/**
 * 内存 store：单测与探针用（不落盘、不碰 safefs）。
 * 接口与默认 store 一一对应；outputs 由测试自行喂数据。
 */
export function createMemoryStore(initial = {}) {
  const state = { value: initial.state || null }
  const settings = { value: initial.settings || { notifications: true } }
  const days = new Map() // dayKey -> record[]
  const projects = new Map() // id -> obj
  const outputs = initial.outputs || {} // dayKey -> {cards, bib}
  const progressFiles = new Map()
  const reportFiles = new Map()
  const ensureDay = (k) => {
    if (!days.has(k)) days.set(k, [])
    return days.get(k)
  }
  return {
    paths: {
      state: '<memory>/state.json',
      settings: '<memory>/settings.json',
      day: (k) => `<memory>/${k}.jsonl`,
      project: (id) => `<memory>/projects/${id}.json`,
      progress: (k) => `<memory>/progress/${k}.json`,
      report: (kind, key) => `<memory>/reports/${kind}-${key}.md`,
    },
    readState: () => state.value,
    writeState: (obj) => {
      state.value = JSON.parse(JSON.stringify(obj))
    },
    readSettings: () => settings.value,
    writeSettings: (obj) => {
      settings.value = JSON.parse(JSON.stringify(obj))
    },
    appendDay: (dayKey, record) => {
      ensureDay(dayKey).push(JSON.parse(JSON.stringify(record)))
    },
    readDay: (dayKey) => (days.has(dayKey) ? days.get(dayKey).map((r) => JSON.parse(JSON.stringify(r))) : []),
    readProject: (id) => (projects.has(id) ? JSON.parse(JSON.stringify(projects.get(id))) : null),
    writeProject: (obj) => projects.set(obj.id, JSON.parse(JSON.stringify(obj))),
    listProjects: () => [...projects.values()].map((p) => JSON.parse(JSON.stringify(p))),
    outputs: (dayKey) => outputs[dayKey] || { cards: [], bib: [] },
    readProgress: (dayKey) => progressFiles.get(dayKey) || null,
    writeProgress: (dayKey, obj) => progressFiles.set(dayKey, JSON.parse(JSON.stringify(obj))),
    readReport: (kind, key) => reportFiles.get(`${kind}-${key}`) || null,
    writeReport: (kind, key, text) => reportFiles.set(`${kind}-${key}`, text),
    // 内存版独有：供测试/探针直接塞产出数据
    _setOutputs: (dayKey, value) => {
      outputs[dayKey] = value
    },
  }
}

export default {
  TIMER_DIR,
  PROGRESS_DIR,
  REPORTS_DIR,
  PROJECTS_DIR,
  STATE_FILE,
  SETTINGS_FILE,
  StoreError,
  assertId,
  assertDayKey,
  dayKeyOf,
  dayStartMs,
  dayEndMs,
  weekMondayOf,
  addDays,
  createDefaultStore,
  createMemoryStore,
}
