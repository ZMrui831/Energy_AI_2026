// packages/core/src/version.mjs
//
// 版本单一来源（P-R4 块 3 必修）：package.json 是唯一真相，
// 托盘/设置页（main.mjs 的 APP_VERSION）、两个插件（RESEARCH_LITERATURE_VERSION /
// TIMER_VERSION）全部从这里派生 —— 谁再硬编码字面量，ui-bridge.test.mjs 的一致性钉会红。
//
// 用 readFileSync 而不是 import assertion：插件在宿主与裸注册表两种环境都会被加载，
// 同步读一次 ~200 字节的 json 成本可忽略，且不依赖 node 版本对 import attributes 的支持。

import { readFileSync } from 'node:fs'

// 本文件位于 packages/core/src/ → 项目根是上三级
const pkg = JSON.parse(readFileSync(new URL('../../../package.json', import.meta.url), 'utf8'))

export const APP_VERSION = String(pkg.version || '')

export default { APP_VERSION }
