// packages/core/src/projects.mjs
//
// 项目与阶段（数据模型的一半，对应任务书交付 1 的 data\projects\<id>.json）：
//
//   { id, name, createdAt, updatedAt, done,
//     stages: [{ id, name, done, createdAt }] }
//
// 计时会话通过 projectId / stageId 关联到这里；进度汇总按项目归集专注时长。
// 本模块只做"结构 + 校验 + 不可变语义"（改名字/加阶段/标记完成都是生成新对象），
// 全部落盘经注入的 store —— 单测用内存 store，真实运行用 safefs 版。

import { assertId, StoreError } from './timer-store.mjs'

/** 名称：1~60 字符，去掉首尾空白；不允许换行（会破坏单行展示）。 */
function assertName(name, label = '名称') {
  const s = String(name == null ? '' : name).replace(/\s+/g, ' ').trim()
  if (!s) throw new StoreError('E_BAD_NAME', `projects: ${label}不能为空`)
  if (s.length > 60) throw new StoreError('E_BAD_NAME', `projects: ${label}超过 60 字符`)
  return s
}

/** 稳定短哈希（FNV-1a 32 位）：中文项目名没有 ASCII 形态时用来生成 id。 */
function hash8(text) {
  let h = 0x811c9dc5
  const s = String(text)
  for (let i = 0; i < s.length; i += 1) {
    h ^= s.charCodeAt(i)
    h = Math.imul(h, 0x01000193)
  }
  return (h >>> 0).toString(16).padStart(8, '0')
}

/** 从名称推导 id：纯 ASCII 名称直接 slug 化；否则 p-<hash8>（保证文件名安全）。 */
export function deriveProjectId(name) {
  const slug = String(name || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 40)
  return slug || `p-${hash8(String(name) + ':' + Date.now())}`
}

function clone(obj) {
  return JSON.parse(JSON.stringify(obj))
}

function touch(project, now) {
  project.updatedAt = new Date(now).toISOString()
  return project
}

/**
 * 项目存储。store 只需 readProject/writeProject/listProjects（见 timer-store.mjs）。
 * @param {{ readProject: Function, writeProject: Function, listProjects: Function }} store
 * @param {{ now?: () => number }} [options]
 */
export function createProjects(store, options = {}) {
  const now = options.now || (() => Date.now())

  function get(id) {
    const p = store.readProject(assertId(id))
    if (!p) throw new StoreError('E_NO_PROJECT', `projects: 项目不存在 -> ${id}`, { id })
    return p
  }

  function list() {
    return store
      .listProjects()
      .map((p) => ({ ...p, stages: [...(p.stages || [])] }))
      .sort((a, b) => String(b.updatedAt || '').localeCompare(String(a.updatedAt || '')))
  }

  function find(ref) {
    // 允许用 id 或名称引用项目（命令里打名字比打 id 自然）
    const key = String(ref || '').trim()
    if (!key) return null
    const all = list()
    return all.find((p) => p.id === key) || all.find((p) => p.name === key) || null
  }

  function create({ name, id = null } = {}) {
    const cleanName = assertName(name)
    let pid = id ? assertId(String(id).replace(/^\/+/, '')) : deriveProjectId(cleanName)
    if (store.readProject(pid)) {
      throw new StoreError('E_PROJECT_EXISTS', `projects: 项目 id 已存在 -> ${pid}`, { id: pid })
    }
    const project = touch(
      {
        id: pid,
        name: cleanName,
        createdAt: new Date(now()).toISOString(),
        updatedAt: new Date(now()).toISOString(),
        done: false,
        stages: [],
      },
      now(),
    )
    store.writeProject(project)
    return clone(project)
  }

  function rename(id, name) {
    const p = get(id)
    p.name = assertName(name)
    store.writeProject(touch(p, now()))
    return clone(p)
  }

  function addStage(id, { name, stageId = null } = {}) {
    const p = get(id)
    const cleanName = assertName(name, '阶段名')
    const sid = stageId ? assertId(String(stageId)) : `s${(p.stages || []).length + 1}`
    if ((p.stages || []).some((s) => s.id === sid)) {
      throw new StoreError('E_STAGE_EXISTS', `projects: 阶段 id 已存在 -> ${p.id}/${sid}`, { id: p.id, stageId: sid })
    }
    if ((p.stages || []).some((s) => s.name === cleanName)) {
      throw new StoreError('E_STAGE_EXISTS', `projects: 阶段名已存在 -> ${p.id}/${cleanName}`, { id: p.id })
    }
    p.stages = [...(p.stages || []), { id: sid, name: cleanName, done: false, createdAt: new Date(now()).toISOString() }]
    store.writeProject(touch(p, now()))
    return clone(p)
  }

  /**
   * 标记完成。stageRef 为空 -> 整个项目完成；给了 -> 该阶段完成。
   * milestone（可选）：完成时的里程碑备注（如「完成 12 个阶段任务」），
   * 落在 stage.milestone / project.milestone 上，随项目文件持久化。
   */
  function markDone(ref, stageRef = null, milestone = null) {
    const p = find(ref) || get(ref)
    const milestoneText = milestone ? assertName(milestone, '里程碑') : null
    if (stageRef) {
      const stage = (p.stages || []).find((s) => s.id === stageRef || s.name === stageRef)
      if (!stage) {
        throw new StoreError('E_NO_STAGE', `projects: 阶段不存在 -> ${p.id}/${stageRef}`, { id: p.id, stageId: String(stageRef) })
      }
      stage.done = true
      stage.doneAt = new Date(now()).toISOString()
      if (milestoneText) stage.milestone = milestoneText
    } else {
      p.done = true
      p.doneAt = new Date(now()).toISOString()
      if (milestoneText) p.milestone = milestoneText
    }
    store.writeProject(touch(p, now()))
    return clone(p)
  }

  function reopen(ref) {
    const p = find(ref) || get(ref)
    p.done = false
    delete p.doneAt
    store.writeProject(touch(p, now()))
    return clone(p)
  }

  return { get, list, find, create, rename, addStage, markDone, reopen }
}

export default { createProjects, deriveProjectId }
