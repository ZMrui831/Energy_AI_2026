// packages/core/src/db.mjs
//
// S3 数据生命周期 —— 统一存储层 createStore()。
//
// 双 driver：
//   - 'sqlite'：node:sqlite DatabaseSync（需 Node>=23.4；本机用 D:\node.exe v24）。
//   - 'jsonl' ：<dataDir>/jsonl-store/ 下每表一个 .jsonl，启动全量加载进内存 Map，
//               写操作 append 行 + 内存更新。语义与 sqlite 实现严格同接口。
//   - 'auto'  ：动态 import('node:sqlite') 探测，可用 → sqlite，不可用 → jsonl。
//               探测结果写一条审计到 data/logs/lifecycle.jsonl（判据 7）。
//   强制 driver='sqlite' 而探测失败 → 抛错（诚实失败，不静默降级）。
//
// 写放大纪律与单写者：本实现的所有 store 方法均为**同步**实现（DatabaseSync 与
// node:fs 同步 API），JS 单线程下同步调用不存在 await 间隙交错，天然满足
// “单写者队列串行化”。批量提交（flush()）由调用方在 ≥5s / ≥50 条时触发：
//   sqlite → PRAGMA wal_checkpoint(TRUNCATE)；jsonl → appendJsonl 逐行同步落盘，
//   无缓冲 fd，flush 为幂等 no-op。
//
// 迁移器：读 ./db/migrations/NNNN_*.sql，按文件名排序逐个应用；每个迁移一个事务；
// checksum = 文件全文 sha256，存 schema_migration.checksum；已应用迁移的当前文件
// checksum 与库内记录不一致 → E_MIGRATION_CHECKSUM，先校验后执行，绝不改库。
//
// B 路子代理注入契约：createStore 返回对象的所有方法都是同步的，直接调用即可
// （await 一个同步返回值也无害）。

import { appendJsonl, assertInsideRoot, PROJECT_ROOT, logPath } from './safefs.mjs'
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, readdirSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

/** 默认生命周期配置（与 data/lifecycle-config.json 完全一致；该文件由主管收口时创建）。 */
export const DEFAULT_LIFECYCLE_CONFIG = Object.freeze({
  version: 1,
  retention: {
    rawFrameNormalHours: 6,
    rawFrameLearningMinutes: 20,
    rawFrameSensitive: 'never-persist',
    observationDays: 7,
    summaryDays: 90,
    audit: 'append-only',
  },
  cleanup: { batchSize: 500, maxConsecutiveFailures: 3 },
  // S67·3-D·G5：审计族（writes/net/tool/perception）只归档不删，避免"审计 14 天被删"。
  logs: { maxFileMB: 8, retainDays: 14, rotateOnly: ['writes.jsonl', 'net.jsonl', 'tool.jsonl', 'perception.jsonl'] },
  messages: {
    frameDeleted: '原图已按保留策略删除；保留时间、窗口、摘要与内容哈希，无法恢复画面。',
    evidenceExpired: '证据已过期：此结论仅保留摘要，不能再打开原图。',
    purging: '数据正在安全删除，期间不再被模型使用。',
  },
})

/** 生命周期审计日志（B 路的轮转记录也写这个文件；双方都只 append 单行 JSON）。 */
export const LIFECYCLE_LOG = logPath('lifecycle.jsonl')

/** 迁移目录（生产路径；测试可经 createStore 的 migrationsDir 注入替身）。 */
const MIGRATIONS_DIR = fileURLToPath(new URL('./db/migrations/', import.meta.url))

const MIGRATION_FILE_RE = /^(\d{4})_[\w.-]+\.sql$/

export class DbError extends Error {
  constructor(code, message) {
    super(message)
    this.name = 'DbError'
    this.code = code
  }
}

// ---------------------------------------------------------------------------
// node:sqlite 能力探测（进程内缓存）
// ---------------------------------------------------------------------------

let _sqliteMod = undefined // undefined=未探测, null=不可用, object=模块
let _probeAudited = false

/**
 * 探测 node:sqlite 可用性。裸 import 失败 / DatabaseSync 缺失都视为不可用。
 * @returns {Promise<object|null>} 可用返回模块对象，否则 null
 */
export async function detectSqlite() {
  if (_sqliteMod !== undefined) return _sqliteMod
  try {
    const mod = await import('node:sqlite')
    _sqliteMod = typeof mod.DatabaseSync === 'function' ? mod : null
  } catch {
    _sqliteMod = null
  }
  return _sqliteMod
}

function auditProbeOnce(driver) {
  if (_probeAudited) return
  _probeAudited = true
  try {
    appendJsonl(LIFECYCLE_LOG, {
      ts: new Date().toISOString(),
      kind: driver === 'sqlite' ? 'sqlite-ready' : 'sqlite-unavailable',
      driver,
      note: driver === 'sqlite' ? 'node:sqlite 可用' : 'node:sqlite 不可用，store 降级为 jsonl（判据 7）',
    })
  } catch {
    // 审计自身失败不能炸掉 store 创建
  }
}

// ---------------------------------------------------------------------------
// 配置合并
// ---------------------------------------------------------------------------

function mergeSection(base, over) {
  return { ...base, ...(over && typeof over === 'object' ? over : {}) }
}

/** 深度按节合并用户配置与默认值；非法输入静默回落默认。 */
export function mergeLifecycleConfig(user) {
  const d = DEFAULT_LIFECYCLE_CONFIG
  if (!user || typeof user !== 'object') return { ...d, retention: { ...d.retention }, cleanup: { ...d.cleanup }, logs: { ...d.logs }, messages: { ...d.messages } }
  return {
    ...d,
    ...user,
    retention: mergeSection(d.retention, user.retention),
    cleanup: mergeSection(d.cleanup, user.cleanup),
    logs: mergeSection(d.logs, user.logs),
    messages: mergeSection(d.messages, user.messages),
  }
}

// ---------------------------------------------------------------------------
// 纯函数：过期时间计算（判据 4）
// ---------------------------------------------------------------------------

/**
 * computeExpiry(sensitivity, mode, config?, now?) → ISO 时间串。
 * mode: 'normal' → now + rawFrameNormalHours(6h)；'learning' → now + rawFrameLearningMinutes(20min)。
 * sensitivity='sensitive' → 直接抛 E_SENSITIVE_NO_PERSIST：“永不落盘”从源头拒绝。
 * 注意：此分支为**后备/双保险**——常规路径中感知层（perception/index.mjs）硬编码
 * sensitivity:'normal'，且敏感窗口已在采集端经 skipped-sensitive 拒采，故**常规流程不触发**；
 * 仅当外部直接以 sensitivity='sensitive' 调用 insertRawFrame / computeExpiry 时才兜底生效。
 */
export function computeExpiry(sensitivity, mode, config = DEFAULT_LIFECYCLE_CONFIG, now = Date.now()) {
  if (sensitivity === 'sensitive') {
    throw new DbError('E_SENSITIVE_NO_PERSIST', '敏感窗口内容永不落盘：拒绝为 sensitivity=sensitive 计算保留期')
  }
  if (mode !== 'normal' && mode !== 'learning') {
    throw new DbError('E_BAD_MODE', `computeExpiry: mode 必须是 'normal'|'learning'，收到 ${JSON.stringify(mode)}`)
  }
  const r = mergeLifecycleConfig(config).retention
  const ms = mode === 'learning'
    ? (r.rawFrameLearningMinutes ?? 20) * 60_000
    : (r.rawFrameNormalHours ?? 6) * 3_600_000
  const base = typeof now === 'number' ? now : Date.parse(now)
  if (!Number.isFinite(base)) throw new DbError('E_BAD_TIME', `computeExpiry: now 无法解析为时间：${String(now)}`)
  return new Date(base + ms).toISOString()
}

function nowIso() {
  return new Date().toISOString()
}

function toIso(t) {
  if (t instanceof Date) return t.toISOString()
  if (typeof t === 'number') return new Date(t).toISOString()
  return String(t)
}

const SHA256_RE = /^[0-9a-fA-F]{64}$/

/** metadata → JSON 串；无法序列化 / 非法 JSON 字符串 → E_BAD_AUDIT_JSON（两 driver 一致）。 */
function auditMetadataToJson(metadata) {
  if (metadata === undefined || metadata === null) return '{}'
  if (typeof metadata === 'string') {
    try {
      JSON.parse(metadata)
    } catch {
      throw new DbError('E_BAD_AUDIT_JSON', `audit metadata 不是合法 JSON 字符串：${metadata.slice(0, 80)}`)
    }
    return metadata
  }
  try {
    const s = JSON.stringify(metadata)
    if (s === undefined) throw new Error('undefined')
    return s
  } catch (e) {
    throw new DbError('E_BAD_AUDIT_JSON', `audit metadata 无法序列化为 JSON：${e.message}`)
  }
}

// ---------------------------------------------------------------------------
// 迁移文件清单与 checksum
// ---------------------------------------------------------------------------

function sha256Of(text) {
  return createHash('sha256').update(text, 'utf8').digest('hex')
}

function listMigrationFiles(dir) {
  if (!existsSync(dir)) return []
  return readdirSync(dir)
    .filter((n) => MIGRATION_FILE_RE.test(n))
    .sort()
}

// ---------------------------------------------------------------------------
// sqlite 实现
// ---------------------------------------------------------------------------

class SqliteStore {
  constructor(mod, dbPath, config) {
    assertInsideRoot(dbPath)
    mkdirSync(dirname(dbPath), { recursive: true })
    this._cfg = config
    this._db = new mod.DatabaseSync(dbPath)
    this._db.exec('PRAGMA journal_mode=WAL;')
    this._db.exec('PRAGMA busy_timeout=3000;')
    this._db.exec('PRAGMA foreign_keys=ON;')
  }

  get driver() {
    return 'sqlite'
  }

  initMigrations(migrationsDir = MIGRATIONS_DIR) {
    // 迁移账本表先于一切迁移存在（0001 里也有同句，幂等）。
    this._db.exec('CREATE TABLE IF NOT EXISTS schema_migration(version TEXT PRIMARY KEY, checksum TEXT NOT NULL, applied_at TEXT NOT NULL);')
    let applied = 0
    let skipped = 0
    for (const name of listMigrationFiles(migrationsDir)) {
      const body = readFileSync(join(migrationsDir, name), 'utf8')
      const sum = sha256Of(body)
      const row = this._db.prepare('SELECT checksum FROM schema_migration WHERE version = ?').get(name)
      if (row) {
        if (row.checksum !== sum) {
          // fail-closed：先读 checksum 再决定是否执行，绝不修改库。
          throw new DbError('E_MIGRATION_CHECKSUM', `迁移 ${name} 当前文件 checksum 与库内已应用记录不一致（fail-closed，拒绝执行任何语句）`)
        }
        skipped += 1
        continue
      }
      this._db.exec('BEGIN')
      try {
        this._db.exec(body)
        this._db.prepare('INSERT INTO schema_migration(version, checksum, applied_at) VALUES (?, ?, ?)').run(name, sum, nowIso())
        this._db.exec('COMMIT')
        applied += 1
      } catch (e) {
        try { this._db.exec('ROLLBACK') } catch { /* 已回滚 */ }
        throw e
      }
    }
    return { applied, skipped }
  }

  insertRawFrame(f) {
    const sensitivity = f.sensitivity ?? 'normal'
    if (sensitivity === 'sensitive') {
      // 判据 4：敏感窗口永不落盘——先记账（blocked-sensitive-persist），再拒绝。
      // 后备分支：常规流程感知层硬编码 sensitivity:'normal' 且上游 skipped-sensitive 已拒采，此处不触发。
      this.insertAuditEvent({ ts: nowIso(), kind: 'blocked-sensitive-persist', metadata: { id: f.id, file_path: f.file_path, sha256: f.sha256 } })
      throw new DbError('E_SENSITIVE_NO_PERSIST', `敏感窗口内容拒绝落盘（raw_frame id=${f.id}）[后备分支，常规路径不触发]`)
    }
    if (!SHA256_RE.test(String(f.sha256 ?? ''))) {
      throw new DbError('E_BAD_SHA256', `raw_frame.sha256 必须是 64 位十六进制，收到 ${JSON.stringify(f.sha256)}`)
    }
    const created_at = f.created_at ?? nowIso()
    const expires_at = f.expires_at ?? computeExpiry(sensitivity, 'normal', this._cfg, Date.parse(created_at))
    this._db.prepare(
      'INSERT INTO raw_frame(id, file_path, sha256, sensitivity, status, error, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    ).run(f.id, f.file_path, f.sha256, sensitivity, 'ready', null, created_at, expires_at)
    return this.getRawFrame(f.id)
  }

  getRawFrame(id) {
    const r = this._db.prepare('SELECT id, file_path, sha256, sensitivity, status, error, created_at, expires_at FROM raw_frame WHERE id = ?').get(id)
    return r ?? null
  }

  listExpiredReady(now, limit = 500) {
    const iso = toIso(now)
    return this._db.prepare(
      "SELECT id, file_path, sha256, sensitivity, status, error, created_at, expires_at FROM raw_frame WHERE status = 'ready' AND expires_at <= ? ORDER BY expires_at ASC LIMIT ?",
    ).all(iso, limit)
  }

  markDeleting(ids) {
    if (!ids || ids.length === 0) return
    this._db.exec('BEGIN')
    try {
      const st = this._db.prepare("UPDATE raw_frame SET status = 'deleting' WHERE id = ? AND status = 'ready'")
      for (const id of ids) st.run(id)
      this._db.exec('COMMIT')
    } catch (e) {
      try { this._db.exec('ROLLBACK') } catch { /* 已回滚 */ }
      throw e
    }
  }

  listByStatus(status) {
    return this._db.prepare(
      'SELECT id, file_path, sha256, sensitivity, status, error, created_at, expires_at FROM raw_frame WHERE status = ? ORDER BY expires_at ASC',
    ).all(status)
  }

  setRawFrameStatus(id, status, errorMsg = null) {
    if (status !== 'deleted' && status !== 'error') {
      throw new DbError('E_BAD_STATUS', `setRawFrameStatus 只接受 'deleted'|'error'，收到 ${JSON.stringify(status)}（置 deleting 走 markDeleting）`)
    }
    // 'error' 时不触碰 file_path（判据 1：失败记录保留路径待排查）。
    this._db.prepare('UPDATE raw_frame SET status = ?, error = ? WHERE id = ?').run(status, errorMsg, id)
  }

  upsertObservation(o) {
    if (o.source_frame_id != null) {
      const f = this._db.prepare('SELECT id FROM raw_frame WHERE id = ?').get(o.source_frame_id)
      if (!f) throw new DbError('E_FK_VIOLATION', `observation.source_frame_id 引用不存在的 raw_frame：${o.source_frame_id}`)
    }
    const created_at = o.created_at ?? nowIso()
    this._db.prepare(
      `INSERT INTO observation(id, kind, source_frame_id, ocr_excerpt, status, created_at, deleted_at)
       VALUES (?, ?, ?, ?, ?, ?, NULL)
       ON CONFLICT(id) DO UPDATE SET kind = excluded.kind, source_frame_id = excluded.source_frame_id, ocr_excerpt = excluded.ocr_excerpt`,
    ).run(o.id, o.kind, o.source_frame_id ?? null, o.ocr_excerpt ?? null, o.status ?? 'active', created_at)
    return this.getObservation(o.id)
  }

  tombstoneObservation(id) {
    // 判据 3：墓碑化 = status='deleted' + 摘要清空 + deleted_at；行保留（evidence_item 引用不断）。
    this._db.prepare("UPDATE observation SET status = 'deleted', ocr_excerpt = NULL, deleted_at = ? WHERE id = ?").run(nowIso(), id)
  }

  getObservation(id) {
    const r = this._db.prepare('SELECT id, kind, source_frame_id, ocr_excerpt, status, created_at, deleted_at FROM observation WHERE id = ?').get(id)
    return r ?? null
  }

  listExpiredActiveObservations(cutoff) {
    const iso = toIso(cutoff)
    return this._db.prepare(
      "SELECT id, kind, source_frame_id, ocr_excerpt, status, created_at, deleted_at FROM observation WHERE status = 'active' AND created_at <= ? ORDER BY created_at ASC",
    ).all(iso)
  }

  insertSummary(s) {
    const created_at = s.created_at ?? nowIso()
    this._db.prepare('INSERT INTO summary(id, content, status, created_at) VALUES (?, ?, ?, ?)').run(s.id, s.content ?? null, s.status ?? 'draft', created_at)
    return this._db.prepare('SELECT id, content, status, created_at FROM summary WHERE id = ?').get(s.id)
  }

  insertEvidenceItem(e) {
    if (e.observation_id != null) {
      const o = this._db.prepare('SELECT id FROM observation WHERE id = ?').get(e.observation_id)
      if (!o) throw new DbError('E_FK_VIOLATION', `evidence_item.observation_id 引用不存在的 observation：${e.observation_id}`)
    }
    const created_at = e.created_at ?? nowIso()
    this._db.prepare('INSERT INTO evidence_item(id, observation_id, availability, created_at) VALUES (?, ?, ?, ?)').run(e.id, e.observation_id ?? null, e.availability ?? 'available', created_at)
    return this._db.prepare('SELECT id, observation_id, availability, created_at FROM evidence_item WHERE id = ?').get(e.id)
  }

  insertAuditEvent(ev) {
    const json = auditMetadataToJson(ev.metadata)
    const r = this._db.prepare('INSERT INTO audit_event(ts, kind, metadata_json) VALUES (?, ?, ?)').run(ev.ts ?? nowIso(), ev.kind, json)
    return Number(r.lastInsertRowid)
  }

  /** 扩展接口（两 driver 同步提供，测试与 worker 用）：按 kind 倒序列审计事件。 */
  listAuditEvents({ kind, limit = 100 } = {}) {
    if (kind) return this._db.prepare('SELECT id, ts, kind, metadata_json FROM audit_event WHERE kind = ? ORDER BY id DESC LIMIT ?').all(kind, limit)
    return this._db.prepare('SELECT id, ts, kind, metadata_json FROM audit_event ORDER BY id DESC LIMIT ?').all(limit)
  }

  counts() {
    const group = (sql) => {
      const m = {}
      for (const row of this._db.prepare(sql).all()) m[row.k] = Number(row.n)
      return m
    }
    const rf = group("SELECT status AS k, COUNT(*) AS n FROM raw_frame GROUP BY status")
    const ob = group("SELECT status AS k, COUNT(*) AS n FROM observation GROUP BY status")
    const one = (sql) => Number(this._db.prepare(sql).get().n)
    return {
      raw_frame: { ready: rf.ready ?? 0, deleting: rf.deleting ?? 0, deleted: rf.deleted ?? 0, error: rf.error ?? 0 },
      observation: { active: ob.active ?? 0, deleted: ob.deleted ?? 0 },
      summary: one('SELECT COUNT(*) AS n FROM summary'),
      evidence_item: one('SELECT COUNT(*) AS n FROM evidence_item'),
      audit_event: one('SELECT COUNT(*) AS n FROM audit_event'),
    }
  }

  flush() {
    // sqlite：WAL 截断检查点，把 -wal 里攒的写合并回主库文件（批量提交纪律）。
    this._db.exec('PRAGMA wal_checkpoint(TRUNCATE);')
  }

  close() {
    this._db.close()
  }
}

// ---------------------------------------------------------------------------
// jsonl 实现（同接口、同语义）
// ---------------------------------------------------------------------------

const JSONL_TABLES = ['raw_frame', 'observation', 'summary', 'evidence_item', 'audit_event']

class JsonlStore {
  constructor(dataDir, config) {
    assertInsideRoot(dataDir)
    this._cfg = config
    this._dir = join(resolve(dataDir), 'jsonl-store')
    mkdirSync(this._dir, { recursive: true })
    this._data = new Map() // table -> Map(id -> row)
    for (const t of JSONL_TABLES) this._data.set(t, new Map())
    this._load()
  }

  get driver() {
    return 'jsonl'
  }

  _file(table) {
    return join(this._dir, `${table}.jsonl`)
  }

  _load() {
    for (const t of JSONL_TABLES) {
      const map = this._data.get(t)
      const file = this._file(t)
      if (!existsSync(file)) continue
      const text = readFileSync(file, 'utf8')
      for (const line of text.split('\n')) {
        const s = line.trim()
        if (!s) continue
        let row
        try {
          row = JSON.parse(s)
        } catch {
          continue // 半行（崩溃残留）跳过，append-only 日志天然容忍
        }
        if (row && row.id != null) {
          map.set(String(row.id), row)
        }
      }
    }
  }

  _append(table, row) {
    // appendJsonl = safefs 的根内断言 + 逐行同步落盘，无缓冲 fd，flush 无需 fsync。
    appendJsonl(this._file(table), row)
  }

  initMigrations() {
    // jsonl driver 无迁移概念：no-op（判据 7 的降级路径不依赖 sqlite schema）。
    return { applied: 0, skipped: 0 }
  }

  insertRawFrame(f) {
    const sensitivity = f.sensitivity ?? 'normal'
    if (sensitivity === 'sensitive') {
      // 后备分支：常规流程感知层硬编码 sensitivity:'normal' 且上游 skipped-sensitive 已拒采，此处不触发。
      this.insertAuditEvent({ ts: nowIso(), kind: 'blocked-sensitive-persist', metadata: { id: f.id, file_path: f.file_path, sha256: f.sha256 } })
      throw new DbError('E_SENSITIVE_NO_PERSIST', `敏感窗口内容拒绝落盘（raw_frame id=${f.id}）[后备分支，常规路径不触发]`)
    }
    if (!SHA256_RE.test(String(f.sha256 ?? ''))) {
      throw new DbError('E_BAD_SHA256', `raw_frame.sha256 必须是 64 位十六进制，收到 ${JSON.stringify(f.sha256)}`)
    }
    const created_at = f.created_at ?? nowIso()
    const expires_at = f.expires_at ?? computeExpiry(sensitivity, 'normal', this._cfg, Date.parse(created_at))
    const row = { id: f.id, file_path: f.file_path, sha256: f.sha256, sensitivity, status: 'ready', error: null, created_at, expires_at }
    this._data.get('raw_frame').set(String(f.id), row)
    this._append('raw_frame', row)
    return { ...row }
  }

  getRawFrame(id) {
    const r = this._data.get('raw_frame').get(String(id))
    return r ? { ...r } : null
  }

  listExpiredReady(now, limit = 500) {
    const iso = toIso(now)
    return [...this._data.get('raw_frame').values()]
      .filter((r) => r.status === 'ready' && r.expires_at <= iso)
      .sort((a, b) => (a.expires_at < b.expires_at ? -1 : a.expires_at > b.expires_at ? 1 : 0))
      .slice(0, limit)
      .map((r) => ({ ...r }))
  }

  markDeleting(ids) {
    if (!ids || ids.length === 0) return
    // 单事务语义：先全部校验（必须处于 ready），再统一落盘。
    const updates = []
    for (const id of ids) {
      const row = this._data.get('raw_frame').get(String(id))
      if (row && row.status === 'ready') updates.push(row)
    }
    for (const row of updates) {
      row.status = 'deleting'
      this._append('raw_frame', { ...row })
    }
  }

  listByStatus(status) {
    return [...this._data.get('raw_frame').values()]
      .filter((r) => r.status === status)
      .sort((a, b) => (a.expires_at < b.expires_at ? -1 : a.expires_at > b.expires_at ? 1 : 0))
      .map((r) => ({ ...r }))
  }

  setRawFrameStatus(id, status, errorMsg = null) {
    if (status !== 'deleted' && status !== 'error') {
      throw new DbError('E_BAD_STATUS', `setRawFrameStatus 只接受 'deleted'|'error'，收到 ${JSON.stringify(status)}（置 deleting 走 markDeleting）`)
    }
    const row = this._data.get('raw_frame').get(String(id))
    if (!row) throw new DbError('E_NOT_FOUND', `raw_frame 不存在：${id}`)
    row.status = status
    row.error = errorMsg // 'error' 时不触碰 file_path（判据 1）
    this._append('raw_frame', { ...row })
  }

  upsertObservation(o) {
    if (o.source_frame_id != null && !this._data.get('raw_frame').has(String(o.source_frame_id))) {
      throw new DbError('E_FK_VIOLATION', `observation.source_frame_id 引用不存在的 raw_frame：${o.source_frame_id}`)
    }
    const prev = this._data.get('observation').get(String(o.id))
    const row = {
      id: o.id,
      kind: o.kind,
      source_frame_id: o.source_frame_id ?? null,
      ocr_excerpt: o.ocr_excerpt ?? null,
      status: o.status ?? prev?.status ?? 'active',
      created_at: prev?.created_at ?? o.created_at ?? nowIso(),
      deleted_at: prev?.deleted_at ?? null,
    }
    this._data.get('observation').set(String(o.id), row)
    this._append('observation', row)
    return { ...row }
  }

  tombstoneObservation(id) {
    const row = this._data.get('observation').get(String(id))
    if (!row) throw new DbError('E_NOT_FOUND', `observation 不存在：${id}`)
    row.status = 'deleted'
    row.ocr_excerpt = null
    row.deleted_at = nowIso()
    this._append('observation', { ...row })
  }

  getObservation(id) {
    const r = this._data.get('observation').get(String(id))
    return r ? { ...r } : null
  }

  listExpiredActiveObservations(cutoff) {
    const iso = toIso(cutoff)
    return [...this._data.get('observation').values()]
      .filter((r) => r.status === 'active' && r.created_at <= iso)
      .sort((a, b) => (a.created_at < b.created_at ? -1 : 1))
      .map((r) => ({ ...r }))
  }

  insertSummary(s) {
    const row = { id: s.id, content: s.content ?? null, status: s.status ?? 'draft', created_at: s.created_at ?? nowIso() }
    this._data.get('summary').set(String(s.id), row)
    this._append('summary', row)
    return { ...row }
  }

  insertEvidenceItem(e) {
    if (e.observation_id != null && !this._data.get('observation').has(String(e.observation_id))) {
      throw new DbError('E_FK_VIOLATION', `evidence_item.observation_id 引用不存在的 observation：${e.observation_id}`)
    }
    const row = { id: e.id, observation_id: e.observation_id ?? null, availability: e.availability ?? 'available', created_at: e.created_at ?? nowIso() }
    this._data.get('evidence_item').set(String(e.id), row)
    this._append('evidence_item', row)
    return { ...row }
  }

  insertAuditEvent(ev) {
    const map = this._data.get('audit_event')
    let maxId = 0
    for (const k of map.keys()) {
      const n = Number(k)
      if (Number.isFinite(n) && n > maxId) maxId = n
    }
    const row = { id: maxId + 1, ts: ev.ts ?? nowIso(), kind: ev.kind, metadata_json: auditMetadataToJson(ev.metadata) }
    map.set(String(row.id), row)
    this._append('audit_event', row)
    return row.id
  }

  listAuditEvents({ kind, limit = 100 } = {}) {
    let rows = [...this._data.get('audit_event').values()]
    if (kind) rows = rows.filter((r) => r.kind === kind)
    rows.sort((a, b) => b.id - a.id)
    return rows.slice(0, limit).map((r) => ({ ...r }))
  }

  counts() {
    const rf = { ready: 0, deleting: 0, deleted: 0, error: 0 }
    const ob = { active: 0, deleted: 0 }
    for (const r of this._data.get('raw_frame').values()) {
      if (rf[r.status] !== undefined) rf[r.status] += 1
    }
    for (const r of this._data.get('observation').values()) {
      if (ob[r.status] !== undefined) ob[r.status] += 1
    }
    return {
      raw_frame: rf,
      observation: ob,
      summary: this._data.get('summary').size,
      evidence_item: this._data.get('evidence_item').size,
      audit_event: this._data.get('audit_event').size,
    }
  }

  flush() {
    // appendJsonl 逐行同步写盘，无内存缓冲，flush 为幂等 no-op（语义上保证“此刻之前的写都已落盘”）。
  }

  close() {
    // 无打开的 fd，no-op。内存态即最新态。
  }
}

// ---------------------------------------------------------------------------
// createStore
// ---------------------------------------------------------------------------

/**
 * 创建 store（异步：driver 探测需要动态 import）。
 * @param {{driver?: 'auto'|'sqlite'|'jsonl', dbPath?: string, dataDir?: string, migrationsDir?: string, config?: object}} opts
 *   - sqlite 需要 dbPath；jsonl 需要 dataDir（store 落在 <dataDir>/jsonl-store/）。
 *   - config 为用户生命周期配置（与 DEFAULT_LIFECYCLE_CONFIG 按节合并）。
 */
export async function createStore({ driver = 'auto', dbPath, dataDir, migrationsDir, config } = {}) {
  if (driver !== 'auto' && driver !== 'sqlite' && driver !== 'jsonl') {
    throw new DbError('E_BAD_DRIVER', `createStore: driver 必须是 'auto'|'sqlite'|'jsonl'，收到 ${JSON.stringify(driver)}`)
  }
  const cfg = mergeLifecycleConfig(config)

  if (driver === 'sqlite') {
    const mod = await detectSqlite()
    if (!mod) {
      // 判据 7 的反向面：强制 sqlite 但环境不支持 → 诚实失败，不静默降级。
      auditProbeOnce('jsonl')
      throw new DbError('E_SQLITE_UNAVAILABLE', '强制 driver=sqlite 但 node:sqlite 不可用（需要 Node>=23.4，请改用 D:\\node.exe 运行）')
    }
    if (!dbPath) throw new DbError('E_BAD_PATH', "createStore: driver='sqlite' 需要提供 dbPath")
    auditProbeOnce('sqlite')
    const store = new SqliteStore(mod, dbPath, cfg)
    if (migrationsDir) store.initMigrations(migrationsDir)
    return store
  }

  if (driver === 'jsonl') {
    if (!dataDir) throw new DbError('E_BAD_PATH', "createStore: driver='jsonl' 需要提供 dataDir")
    auditProbeOnce('jsonl')
    const store = new JsonlStore(dataDir, cfg)
    if (migrationsDir) store.initMigrations(migrationsDir)
    return store
  }

  // auto：探测决定
  const mod = await detectSqlite()
  if (mod && dbPath) {
    auditProbeOnce('sqlite')
    const store = new SqliteStore(mod, dbPath, cfg)
    if (migrationsDir) store.initMigrations(migrationsDir)
    return store
  }
  if (!dataDir) throw new DbError('E_BAD_PATH', 'createStore: driver=auto 降级 jsonl 时需要提供 dataDir（或提供 dbPath 走 sqlite）')
  auditProbeOnce('jsonl')
  const store = new JsonlStore(dataDir, cfg)
  if (migrationsDir) store.initMigrations(migrationsDir)
  return store
}

export default { DEFAULT_LIFECYCLE_CONFIG, computeExpiry, createStore, detectSqlite, mergeLifecycleConfig, DbError, LIFECYCLE_LOG }
