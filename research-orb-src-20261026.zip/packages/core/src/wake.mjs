// packages/core/src/wake.mjs —— 唤醒词匹配（纯函数，零依赖）
//
// S74·3-B：语音只做唤醒词（总管 2026-10-26 裁定），不做转写展示/播报。
// 设计参照两份实盘经验（dsh-orb / 萌源）：
//   ① 变体多拼写 + 近音展开（中文同音字多，全串相等必漏）
//   ② **包含匹配**而非全等；长变体优先，避免短词抢先
//   ③ 核心词兜底（去掉"在吗/在哪/呢/啊"）
//   ④ 复读幻觉过滤（tiny 会输出"千千千千"）
//   ⑤ 人声量闸门（人声 <400ms 不出识别结果，防 whisper 对短音编词）
//   ⑥ 禁止编辑距离模糊匹配（中文同音字→大量误触）
// 本模块**只管匹配**；采集（PCM 环形缓冲/门限/预卷）与 STT 调用在渲染层与 voice.mjs。

/** 电平/切句参数（照抄实盘值，可直接调） */
export const WAKE_PARAMS = Object.freeze({
  tickMs: 120,            // 电平检测周期
  rmsDefault: 0.03,       // 门限默认
  rmsFloor: 0.03,         // 门限下限
  rmsCap: 0.05,           // 门限上限（必须有上限，否则正常说话被当噪声）
  onsetMs: 120,           // 起始判定
  preRollMs: 1500,        // 预卷（否则首字被切）
  maxUtteranceMs: 4000,   // 超过视为普通说话，跳过
  silenceMs: 1200,        // 静音判句
  cooldownMs: 700,        // 一次发声只触发一次
  probeBudgetPerMin: 8,   // tiny(CPU) 比 small+CUDA 慢，预算下调
  minSpokenMs: 400,       // 人声量闸门：短于此不出结果
  maxArmMinutes: 5,       // 监听自动关闭
})

/** 唤醒词变体（多拼写 + 常见误识别）；长变体在前，匹配时长优先 */
export const WAKE_VARIANTS = Object.freeze([
  // 长短语（3–4 字）：tiny 实测 5/5 命中，**首选**——说完整一句最稳
  '问源在吗', '问源在哪', '问源出来', '问源你好',
  // 2 字核心：单独说时 tiny 不稳（实测「问源」被听成「慧源」0/5），靠下面变体兜底
  '问源', '问元', '问原', '问缘', '问远', '文源', '文元', '文员',
  // 实测误识别（2026-10-26 TTS 连测 5 次得出）：tiny 把 wen 听成 hui / yuan 听成 yuan 变体
  '慧源', '会源', '惠源', '汇源', '惠元', '慧元',
  // 小名
  '小源', '小球', '小元',
])

/** 近音展开表：核心字 → 同音/近音字（手写，避免引拼音库） */
const PHONETIC = Object.freeze({
  // 实测：tiny 把「问(wen)」稳定听成「慧(hui)」——跨音错，必须手工补
  '问': ['文', '闻', '温', '稳', '慧', '会', '惠', '汇', 'w'],
  '源': ['元', '原', '缘', '远', '园', '圆', '员', 'y'],
  '小': ['晓', '筱', '效'],
  '球': ['求', '秋', '丘'],
})

/** 语气词与句末助词：匹配前剥掉，避免"问源啊""问源呢"漏命中 */
const TONE_TAIL = /[啊呀呢吧吗嘛哦噢喔啦咯哈诶欸~～]+$/u
const PUNCT = /[\s,.!?;:'"()\[\]{}<>，、。！？；：""''（）【】《》…·—\-_/\\|]+/gu

/** 繁→简（只覆盖唤醒词可能涉及的少数几个字） */
const TRAD = Object.freeze({ '問': '问', '源': '源', '員': '员', '園': '园', '圓': '圆', '遠': '远', '緣': '缘', '曉': '晓', '勻': '匀', '麗': '丽' })

/** 基础归一：繁→简、去标点空白、小写（**不剥尾巴**，供复读判定与核心词用） */
export function normalizeBasic(input) {
  let s = String(input == null ? '' : input)
  s = s.replace(/[問會員園圓遠緣曉勻麗]/gu, (c) => TRAD[c] || c)
  s = s.replace(PUNCT, '')
  return s.toLowerCase()
}

/** 尾巴片段：疑问尾/寒暄/语气词（可连续剥离，最多 3 轮） */
const TAIL_CLUSTER = /(在吗|在哪|在不在|出来吧|出来|你好|喂|[啊呀呢吧吗嘛哦噢喔啦咯诶欸~～]+)$/u

/** 归一化（用于匹配）：基础归一 + 剥尾巴 */
export function normalizeText(input) {
  let s = normalizeBasic(input)
  for (let i = 0; i < 3; i += 1) {
    const next = s.replace(TAIL_CLUSTER, '')
    if (next === s) break
    s = next
  }
  return s
}

/** 近音展开：把核心词展开成变体集合（去重 + 限额，防组合爆炸） */
export function expandVariants(words = ['问源'], limit = 40) {
  const out = new Set()
  for (const w of words) {
    const base = normalizeText(w)
    if (!base) continue
    out.add(base)
    // 逐字替换，每次只换一个字（笛卡尔积会爆炸，单字替换足够）
    for (let i = 0; i < base.length; i += 1) {
      const ch = base[i]
      const alts = PHONETIC[ch] || []
      for (const a of alts) {
        if (/^[a-z]$/.test(a)) continue // 单字母标记跳过
        out.add(base.slice(0, i) + a + base.slice(i + 1))
      }
    }
  }
  return [...out].filter((v) => v.length >= 2).sort((a, b) => b.length - a.length).slice(0, limit)
}

/** 核心词：去掉"在吗/在哪/出来/呢/啊"等尾巴，得到 2–4 字核心 */
export function coreOf(text) {
  let s = normalizeBasic(text)
  for (let i = 0; i < 3; i += 1) {
    const next = s.replace(TAIL_CLUSTER, '')
    if (next === s) break
    s = next
  }
  return s
}

/**
 * 复读幻觉过滤：tiny 对短音/噪声常输出重复串（"千千千千""哈哈哈哈哈"）。
 * 规则：去重后长度 ≤2 且原长 ≥3 → 判为幻觉。
 */
export function isRepetitionHallucination(text) {
  const s = normalizeBasic(text)
  if (s.length < 3) return false
  const uniq = new Set([...s]).size
  return uniq <= 2
}

/** 人声量闸门：说话时长短于 minSpokenMs 不出结果（防对短音编词） */
export function passEnergyGate({ spokenMs = 0, rms = 0, minSpokenMs = WAKE_PARAMS.minSpokenMs } = {}) {
  if (!Number.isFinite(spokenMs) || spokenMs < minSpokenMs) return { ok: false, reason: 'too-short' }
  if (!Number.isFinite(rms) || rms < WAKE_PARAMS.rmsFloor) return { ok: false, reason: 'too-quiet' }
  return { ok: true }
}

/**
 * 匹配唤醒词。返回 {hit, word, variant, rest, source:'variant'|'core'}
 * 顺序：① 变体包含（长优先）② 核心词兜底。禁止模糊匹配。
 */
export function matchWake(transcript, opts = {}) {
  const variants = opts.variants || WAKE_VARIANTS
  const raw = String(transcript == null ? '' : transcript)
  if (isRepetitionHallucination(raw)) return { hit: false, reason: 'hallucination' }
  // 关键：变体与输入都用**基础归一**（保留"在吗/出来"等长尾巴），
  // 否则长变体会被剥成核心词、彻底失去"长优先"优势（W-3 实测踩到）。
  const normB = normalizeBasic(raw)
  if (!normB) return { hit: false, reason: 'empty' }
  const list = [...variants].map(normalizeBasic).filter((v) => v.length >= 2).sort((a, b) => b.length - a.length)
  // ① 变体包含匹配（长优先）
  for (const v of list) {
    const at = normB.indexOf(v)
    if (at >= 0) {
      return { hit: true, word: v, variant: v, source: 'variant', rest: normB.slice(at + v.length) }
    }
  }
  // ② 核心词兜底：输入与变体都剥尾巴后再比（处理"问源呢""小球啊"）
  const coreIn = normalizeText(raw)
  for (const v of list) {
    const vc = normalizeText(v)
    if (vc.length >= 2 && coreIn.includes(vc)) {
      return { hit: true, word: vc, variant: v, source: 'core', rest: coreIn.slice(coreIn.indexOf(vc) + vc.length) }
    }
  }
  return { hit: false, reason: 'no-match' }
}

/** 从转写里剪掉唤醒词，剩下的是指令（本期只开面板，指令留待后续） */
export function stripWakeWord(transcript, match = null) {
  const m = match || matchWake(transcript)
  if (!m || !m.hit) return normalizeText(transcript)
  const normB = normalizeBasic(transcript)
  const idx = normB.indexOf(m.word)
  if (idx < 0) return normalizeText(transcript)
  return (normB.slice(0, idx) + normB.slice(idx + m.word.length)).replace(TAIL_CLUSTER, '')
}

export default { WAKE_PARAMS, WAKE_VARIANTS, normalizeBasic, normalizeText, expandVariants, coreOf, isRepetitionHallucination, passEnergyGate, matchWake, stripWakeWord }