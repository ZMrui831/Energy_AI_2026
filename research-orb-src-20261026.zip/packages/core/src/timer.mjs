// packages/core/src/timer.mjs
//
// 番茄钟与计时账本（对应任务书交付 2）。
//
// 设计约束（全部可单测，不依赖真实时钟与真实等待）：
//   · now / timeScale / store 全部注入；测试用虚拟时钟把 25 分钟压成毫秒级；
//   · 时间源只有一个：now()。任何"过了多久"都由 (now - 锚点) * timeScale 推导，
//     不读 second Date.now()、不 setInterval（节拍由调用方驱动，见 apps/desktop/main.mjs）；
//   · 落盘只经 store（默认 safefs 版，见 timer-store.mjs）；
//   · 崩溃恢复【不静默改写】：恢复口径是"上一个进程最后一次心跳之前"，
//     心跳之后的未知间隔作为 gap 如实报告，不猜、不补。
//
// 事件流（data\timer\<YYYY-MM-DD>.jsonl，append-only）：
//   {type:'start'|'pause'|'resume'|'stop'|'segment'|'idle.prompt'|'idle.resolve'|'interrupted', ...}
//   segment 是专注时长的【唯一计账单位】：pause/stop/跨午夜/空闲扣除都会先落 segment 行，
//   于是"当天专注多少秒"就是对当天 segment.sec 求和，重算永远一致。
//
// timeScale（RESEARCH_ORB_TIME_SCALE）：验收/演示加速。60 表示 1 真实秒 = 60 计时秒，
// 15 分钟番茄 15 秒真实时间走完。scale=1 即真实时长路径，两者共用同一套代码。

import { dayEndMs, dayKeyOf, dayStartMs } from './timer-store.mjs'
import { stamp } from './session.mjs'

/** 番茄预设（分钟）。自定义时长走 start({minutes: N})，1~MAX_MINUTES。 */
export const POMODORO_PRESETS = Object.freeze([15, 25, 45])
export const MAX_MINUTES = 180
/** 空闲超过这么多秒才询问（任务书：>5 分钟）。 */
export const IDLE_ASK_SEC = 300
/** 心跳间隔（真实毫秒）：崩溃恢复用"最后一次心跳"界定已记录时间。 */
export const HEARTBEAT_MS = 30_000
/** ts 校验容忍（时钟跳变 / 时区调整的宽容度）。 */
const TS_SKEW_MS = 60_000

export class TimerError extends Error {
  constructor(code, message, details = {}) {
    super(message)
    this.name = 'TimerError'
    this.code = code
    Object.assign(this, details)
  }
}

const isTs = (v) => typeof v === 'number' && Number.isFinite(v) && v > 0
const isNum = (v) => typeof v === 'number' && Number.isFinite(v) && v >= 0

function newSessionId(nowMs) {
  const suffix = Math.floor(Math.random() * 0x10000)
    .toString(16)
    .padStart(4, '0')
  return `t-${stamp(new Date(nowMs))}-${suffix}`
}

/**
 * 创建计时引擎。
 * @param {{
 *   store: object,               // timer-store.mjs 的 store（默认 store 或内存 store）
 *   now?: () => number,          // 注入时间源（毫秒）
 *   timeScale?: number,          // 计时秒 / 真实秒，默认 1
 * }} options
 */
export function createTimer(options = {}) {
  const store = options.store
  if (!store || typeof store.readState !== 'function') {
    throw new TimerError('E_NO_STORE', 'timer: 必须注入 store（见 timer-store.mjs）')
  }
  const now = options.now || (() => Date.now())
  const timeScale = Number.isFinite(options.timeScale) && options.timeScale > 0 ? options.timeScale : 1

  /** 内存态：损坏标记只留在内存里（磁盘上的损坏现场一个字节都不改）。 */
  let corrupt = null
  let revision = 0

  const scaledSec = (realMs) => (realMs * timeScale) / 1000

  function readState() {
    return store.readState() || null
  }

  function writeState(patch) {
    const base = readState() || {}
    const next = { ...base, ...patch, ts: new Date(now()).toISOString() }
    store.writeState(next)
    revision += 1
    return next
  }

  function settings() {
    const s = store.readSettings()
    return { notifications: s && s.notifications === false ? false : true }
  }

  /**
   * 把 [fromMs, toMs] 按本地午夜切分，逐日落 segment 行。
   * @returns {{records: object[], totalSec: number}}
   */
  function emitSegments(fromMs, toMs, meta = {}) {
    const records = []
    let totalSec = 0
    if (!(toMs > fromMs)) return { records, totalSec }
    let cursor = fromMs
    // 上限 8 段：一次暂停不可能横跨 8 天以上，防注入 now 乱跳时死循环
    for (let guard = 0; guard < 8 && cursor < toMs; guard += 1) {
      const dk = dayKeyOf(cursor)
      const partEnd = Math.min(toMs, dayEndMs(dk))
      const sec = Math.round(scaledSec(partEnd - cursor))
      const record = {
        type: 'segment',
        ts: new Date(cursor).toISOString(),
        dayKey: dk,
        from: new Date(cursor).toISOString(),
        to: new Date(partEnd).toISOString(),
        sec,
        kind: meta.kind || 'focus',
        sessionId: meta.sessionId || null,
        projectId: meta.projectId || null,
        stageId: meta.stageId || null,
      }
      store.appendDay(dk, record)
      records.push(record)
      totalSec += sec
      cursor = partEnd
    }
    return { records, totalSec }
  }

  function snapshot(extra = {}) {
    const st = readState() || {}
    const t = now()
    const running = st.status === 'running'
    const elapsedSec = running ? scaledSec(t - (st.segmentStartedAt || t)) : 0
    return {
      status: st.status || 'idle',
      sessionId: st.sessionId || null,
      projectId: st.projectId || null,
      stageId: st.stageId || null,
      mode: st.mode || null,
      plannedSec: st.plannedSec || 0,
      accumulatedSec: st.accumulatedSec || 0,
      elapsedSec: Math.round(elapsedSec),
      remainingSec: Math.max(0, Math.round((st.plannedSec || 0) - (st.accumulatedSec || 0) - elapsedSec)),
      startedAt: st.startedAt || null,
      segmentStartedAt: st.segmentStartedAt || null,
      dayKey: st.dayKey || null,
      timeScale,
      idlePrompt: st.idlePrompt || null,
      lastStop: st.lastStop || null,
      lastInterrupted: st.lastInterrupted || null,
      corrupt,
      settings: settings(),
      revision,
      ts: t,
      ...extra,
    }
  }

  function assertMinutes(minutes) {
    const m = Number(minutes)
    if (!Number.isFinite(m) || m < 1 || m > MAX_MINUTES || !Number.isInteger(m)) {
      throw new TimerError('E_BAD_MINUTES', `timer: 时长必须是 1~${MAX_MINUTES} 的整数分钟 -> ${minutes}`, { minutes })
    }
    return m
  }

  function modeOf(minutes) {
    return POMODORO_PRESETS.includes(minutes) ? `pomodoro-${minutes}` : 'custom'
  }

  // -------------------------------------------------------------------------
  // 开始 / 暂停 / 恢复 / 停止
  // -------------------------------------------------------------------------

  /**
   * 开始一个计时会话。已有进行中（含暂停）的会话时拒绝，避免两本账。
   *
   * 例外：本进程检出过状态损坏（corrupt）时放行 —— 磁盘上的坏状态不能让用户
   * 永远开不了新账（插件 /status 的文案承诺" /start 将开新账"）。坏状态里的
   * day jsonl 一行不动（append-only 历史不丢），新会话用新 sessionId 重开。
   * @param {{projectId?: string|null, stageId?: string|null, minutes?: number, mode?: string}} args
   */
  function start(args = {}) {
    const st = readState() || {}
    if (!corrupt && st.status === 'running') {
      throw new TimerError('E_TIMER_RUNNING', 'timer: 已有正在进行的计时（先 /stop 或 /pause）', { snapshot: snapshot() })
    }
    if (!corrupt && st.status === 'paused') {
      throw new TimerError('E_TIMER_PAUSED', 'timer: 有暂停中的计时（先 /resume 或 /stop）', { snapshot: snapshot() })
    }
    const minutes = assertMinutes(args.minutes === undefined ? 25 : args.minutes)
    const t = now()
    const sessionId = newSessionId(t)
    const plannedSec = minutes * 60
    const record = {
      type: 'start',
      ts: new Date(t).toISOString(),
      sessionId,
      projectId: args.projectId || null,
      stageId: args.stageId || null,
      mode: args.mode || modeOf(minutes),
      plannedSec,
      minutes,
      timeScale,
    }
    store.appendDay(dayKeyOf(t), record)
    // 显式开始新会话 = 用户动作，顺带清掉内存里的损坏标记（磁盘坏文件已被本写入覆盖）
    corrupt = null
    writeState({
      status: 'running',
      sessionId,
      projectId: record.projectId,
      stageId: record.stageId,
      mode: record.mode,
      plannedSec,
      minutes,
      startedAt: t,
      segmentStartedAt: t,
      accumulatedSec: 0,
      dayKey: dayKeyOf(t),
      heartbeatAt: t,
      idlePrompt: null,
      lastStop: null,
      lastInterrupted: null,
    })
    return snapshot()
  }

  /** 暂停：把当前段落账（跨午夜则切分），累计进 accumulatedSec。 */
  function pause() {
    const st = readState() || {}
    if (st.status !== 'running') {
      throw new TimerError('E_TIMER_NOT_RUNNING', 'timer: 当前没有正在进行的计时', { status: st.status || 'idle' })
    }
    const t = now()
    const { totalSec } = emitSegments(st.segmentStartedAt, t, {
      kind: 'pause',
      sessionId: st.sessionId,
      projectId: st.projectId,
      stageId: st.stageId,
    })
    const accumulatedSec = (st.accumulatedSec || 0) + totalSec
    store.appendDay(dayKeyOf(t), {
      type: 'pause',
      ts: new Date(t).toISOString(),
      sessionId: st.sessionId,
      segmentSec: totalSec,
      accumulatedSec,
    })
    writeState({ status: 'paused', accumulatedSec, heartbeatAt: t, idlePrompt: null })
    return snapshot()
  }

  /** 恢复：只有暂停中的会话能恢复。 */
  function resume() {
    const st = readState() || {}
    if (st.status !== 'paused') {
      throw new TimerError('E_TIMER_NOT_PAUSED', 'timer: 当前没有暂停中的计时', { status: st.status || 'idle' })
    }
    const t = now()
    store.appendDay(dayKeyOf(t), { type: 'resume', ts: new Date(t).toISOString(), sessionId: st.sessionId })
    writeState({ status: 'running', segmentStartedAt: t, heartbeatAt: t })
    return snapshot()
  }

  /**
   * 停止并收尾。返回本次会话汇总（总秒数、是否完成、超时部分）。
   * @param {{reason?: string}} [args] reason: 'user' | 'completed'
   */
  function stop(args = {}) {
    const st = readState() || {}
    if (!st.sessionId || (st.status !== 'running' && st.status !== 'paused')) {
      throw new TimerError('E_TIMER_NOT_RUNNING', 'timer: 当前没有进行中的计时', { status: st.status || 'idle' })
    }
    const t = now()
    let finalSec = 0
    if (st.status === 'running') {
      const { totalSec } = emitSegments(st.segmentStartedAt, t, {
        kind: 'final',
        sessionId: st.sessionId,
        projectId: st.projectId,
        stageId: st.stageId,
      })
      finalSec = totalSec
    }
    const totalSec = (st.accumulatedSec || 0) + finalSec
    const completed = totalSec >= (st.plannedSec || 0)
    const summary = {
      type: 'stop',
      ts: new Date(t).toISOString(),
      sessionId: st.sessionId,
      projectId: st.projectId || null,
      stageId: st.stageId || null,
      mode: st.mode || null,
      plannedSec: st.plannedSec || 0,
      totalSec,
      completed,
      overrunSec: Math.max(0, totalSec - (st.plannedSec || 0)),
      reason: args.reason || 'user',
    }
    store.appendDay(dayKeyOf(t), summary)
    writeState({
      status: 'idle',
      sessionId: null,
      projectId: null,
      stageId: null,
      mode: null,
      plannedSec: 0,
      accumulatedSec: 0,
      segmentStartedAt: null,
      idlePrompt: null,
      heartbeatAt: t,
      lastStop: { ...summary, ts: undefined, at: summary.ts },
    })
    return { ...snapshot(), justStopped: true, summary }
  }

  // -------------------------------------------------------------------------
  // 节拍（由主进程每秒驱动）：跨午夜切分 + 完成判定 + 心跳
  // -------------------------------------------------------------------------

  /**
   * 每秒调用一次。返回值里的 justCompleted 供主进程发通知与刷新进度。
   * 本函数在 idle 时几乎零开销（只读内存态）。
   */
  function tick() {
    const st = readState() || {}
    if (st.status !== 'running') return snapshot()
    const t = now()

    // 跨午夜：把跨过去的部分先落账，段起点挪到今天的 00:00
    if (dayKeyOf(t) !== dayKeyOf(st.segmentStartedAt || t)) {
      const midnight = dayStartMs(dayKeyOf(t))
      emitSegments(st.segmentStartedAt, midnight, {
        kind: 'midnight',
        sessionId: st.sessionId,
        projectId: st.projectId,
        stageId: st.stageId,
      })
      writeState({ segmentStartedAt: midnight })
      return snapshot({ justMidnight: true })
    }

    const elapsedSec = scaledSec(t - st.segmentStartedAt)
    const remainingSec = (st.plannedSec || 0) - (st.accumulatedSec || 0) - elapsedSec

    // 到点自动收尾（完成）
    if (remainingSec <= 0) {
      const out = stop({ reason: 'completed' })
      return { ...out, justCompleted: true }
    }

    // 心跳：崩溃恢复的时间边界（30s 真实时间一次，audit:false 不污染 writes.jsonl）
    if (t - (st.heartbeatAt || 0) >= HEARTBEAT_MS) {
      writeState({ heartbeatAt: t })
    }
    return snapshot()
  }

  // -------------------------------------------------------------------------
  // 崩溃恢复
  // -------------------------------------------------------------------------

  /**
   * 启动时调用：发现上次进程留下未正常结束的会话时，按"最后一次心跳"收尾，
   * 心跳之后的未知间隔作为 gap 报告（不猜、不补、不静默改写）。
   * 状态损坏（ts 非法 / 数值非法）时【不写任何字节】，只返回 corrupt 结果。
   * @returns {{recovered: boolean, corrupt?: boolean, problems?: string[], record?: object}}
   */
  function recover() {
    const st = readState()
    if (!st || !st.sessionId || st.status === 'idle') return { recovered: false, reason: 'no-active-session' }

    const problems = []
    for (const f of ['startedAt', 'segmentStartedAt', 'heartbeatAt', 'plannedSec', 'accumulatedSec']) {
      const v = st[f]
      const ok = f === 'accumulatedSec' ? isNum(v) : f === 'plannedSec' ? isNum(v) && v > 0 : isTs(v)
      if (!ok) problems.push(f)
    }
    if (isTs(st.startedAt) && isTs(st.heartbeatAt) && st.startedAt > st.heartbeatAt + TS_SKEW_MS) {
      problems.push('ts-order')
    }
    if (problems.length > 0) {
      // 磁盘上的坏状态一个字节都不改；标记只进内存，/status 会报出来，
      // 直到用户显式 /start（那是明确的用户动作）才覆盖。
      corrupt = { at: now(), problems, state: { ...st } }
      return { recovered: false, corrupt: true, problems }
    }

    const t = now()
    // 已记录时间的上界 = 最后一次心跳（进程确实活着的最晚证据）；
    // 时钟跳回时兜底用 now，避免段终点早于起点。
    const closeAt = Math.min(t, st.heartbeatAt)
    const gapSec = Math.max(0, Math.round((t - closeAt) / 1000))

    let recordedSec = 0
    if (st.status === 'running') {
      const { totalSec } = emitSegments(st.segmentStartedAt, closeAt, {
        kind: 'interrupted',
        sessionId: st.sessionId,
        projectId: st.projectId,
        stageId: st.stageId,
      })
      recordedSec = totalSec
    }
    const totalSec = (st.accumulatedSec || 0) + recordedSec
    const remainingSec = Math.max(0, (st.plannedSec || 0) - totalSec)

    const record = {
      type: 'interrupted',
      ts: new Date(closeAt).toISOString(),
      sessionId: st.sessionId,
      projectId: st.projectId || null,
      stageId: st.stageId || null,
      status: st.status,
      plannedSec: st.plannedSec,
      recordedSec,
      totalSec,
      remainingSec,
      gapSec,
      recoveredAt: new Date(t).toISOString(),
    }
    store.appendDay(dayKeyOf(closeAt), record)

    writeState({
      status: 'idle',
      sessionId: null,
      projectId: null,
      stageId: null,
      mode: null,
      plannedSec: 0,
      accumulatedSec: 0,
      segmentStartedAt: null,
      idlePrompt: null,
      heartbeatAt: t,
      lastInterrupted: record,
    })
    return { recovered: true, record }
  }

  // -------------------------------------------------------------------------
  // 空闲询问（>5 分钟）：只询问、不静默改写
  // -------------------------------------------------------------------------

  /** 主进程探测到系统空闲超过阈值时调用：记下询问起点，等用户回答。 */
  function noteIdle(idleSec) {
    const st = readState() || {}
    if (st.status !== 'running' || st.idlePrompt) return snapshot()
    const t = now()
    store.appendDay(dayKeyOf(t), { type: 'idle.prompt', ts: new Date(t).toISOString(), sessionId: st.sessionId, idleSec })
    writeState({ idlePrompt: { askedAt: t, idleSec } })
    return snapshot()
  }

  /**
   * 用户回答空闲询问。
   * @param {{keep: boolean}} args keep=true 保留（空闲时间照常计为专注）；
   *        keep=false 扣除（把 [询问起点, 现在] 从当前段里剪掉，先落账再续跑）。
   */
  function resolveIdle(args = {}) {
    const st = readState() || {}
    if (!st.idlePrompt) return snapshot()
    const t = now()
    const keep = args.keep !== false
    if (keep) {
      store.appendDay(dayKeyOf(t), {
        type: 'idle.resolve',
        ts: new Date(t).toISOString(),
        sessionId: st.sessionId,
        keep: true,
      })
      writeState({ idlePrompt: null, heartbeatAt: t })
      return snapshot()
    }
    // 扣除：保留 [段起点, 询问起点]（先落账成 segment），段起点挪到 now
    const askedAt = st.idlePrompt.askedAt
    const { totalSec } = emitSegments(st.segmentStartedAt, askedAt, {
      kind: 'idle-trim',
      sessionId: st.sessionId,
      projectId: st.projectId,
      stageId: st.stageId,
    })
    const discardSec = Math.round(scaledSec(t - askedAt))
    store.appendDay(dayKeyOf(t), {
      type: 'idle.resolve',
      ts: new Date(t).toISOString(),
      sessionId: st.sessionId,
      keep: false,
      keptSec: totalSec,
      discardSec,
    })
    writeState({
      idlePrompt: null,
      accumulatedSec: (st.accumulatedSec || 0) + totalSec,
      segmentStartedAt: t,
      heartbeatAt: t,
    })
    return snapshot()
  }

  // -------------------------------------------------------------------------
  // 设置
  // -------------------------------------------------------------------------

  function getSettings() {
    return settings()
  }

  function setNotifications(on) {
    const next = { notifications: on !== false }
    store.writeSettings(next)
    revision += 1
    return next
  }

  return {
    start,
    pause,
    resume,
    stop,
    tick,
    status: () => snapshot(),
    recover,
    noteIdle,
    resolveIdle,
    getSettings,
    setNotifications,
    POMODORO_PRESETS,
    IDLE_ASK_SEC,
    // 计时倍速（宿主从 RESEARCH_ORB_TIME_SCALE 读一次注入）。插件层靠它做
    // "加速测试模式"的显式提示 —— 插件自己不读 process.env。
    timeScale,
  }
}

export default { createTimer, POMODORO_PRESETS, MAX_MINUTES, IDLE_ASK_SEC, HEARTBEAT_MS, TimerError }
