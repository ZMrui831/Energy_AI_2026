// packages/core/src/voice-settings.mjs
//
// S39·F4 语音隐私开关 + 状态卡：voice.enabled（默认 false）/ voice.retainAudio（默认 false）。
// 纪律（红线）：
//   · 默认全关；关闭时拒录并明确提示；开启首弹一次说明（explainedOn 记忆位）。
//   · 音频不落盘（retainAudio=false → 播后删/转写不留档）；开关切换留审计行。
import { existsSync, readFileSync } from 'node:fs'
import { dataPath, safeWrite, appendJsonl, logPath } from './safefs.mjs'

const VOICE_DEFAULTS = Object.freeze({ enabled: false, retainAudio: false, explainedOn: false })

function audit(rec) {
  try { appendJsonl(logPath('coach.jsonl'), { ts: new Date().toISOString(), ...rec }) } catch { /* 尽力 */ }
}

export function readVoiceConfig(doc = null) {
  const d = doc || (() => { try { return existsSync(dataPath('config.json')) ? JSON.parse(readFileSync(dataPath('config.json'), 'utf8')) : {} } catch { return {} } })()
  const v = (d && typeof d === 'object' && d.voice && typeof d.voice === 'object') ? d.voice : {}
  return {
    enabled: v.enabled === true,
    retainAudio: v.retainAudio === true,
    explainedOn: v.explainedOn === true,
  }
}

export function writeVoiceConfig(patch = {}) {
  const cur = (() => { try { return existsSync(dataPath('config.json')) ? JSON.parse(readFileSync(dataPath('config.json'), 'utf8')) : {} } catch { return {} } })()
  const next = { ...cur, voice: { ...readVoiceConfig(cur), ...patch } }
  safeWrite(dataPath('config.json'), JSON.stringify(next, null, 2), 'utf8')
  return readVoiceConfig(next)
}

/** 开/关语音（首次开启返回一次性说明文案）。 */
export function setVoiceEnabled(enabled, { brief = '开启后：按住说话→本地转写（音频不出本机）；播报为本地合成、播后即删。语音默认关闭，随时可关。' } = {}) {
  const prev = readVoiceConfig()
  const firstTime = enabled && !prev.explainedOn
  const cfg = writeVoiceConfig({ enabled: enabled === true, explainedOn: prev.explainedOn || enabled === true })
  audit({ kind: 'voice-toggle', enabled: cfg.enabled })
  return { ok: true, config: cfg, firstTime, briefing: firstTime ? brief : null }
}

/** 语音闸：关 → 拒录（明确提示），开 → 放行给注入的转写器。 */
export function gatedTranscribe(input = {}, deps = {}) {
  const cfg = readVoiceConfig(deps.configDoc)
  if (!cfg.enabled) {
    audit({ kind: 'voice-refused', why: 'voice-disabled' })
    return { ok: false, code: 'E_VOICE_DISABLED', reason: '语音输入已关闭（默认关）。要使用请先开启：开启后麦克风仅在按住说话时工作，音频不出本机。' }
  }
  const transcribe = deps.transcribe || (() => { throw new Error('gatedTranscribe 需要注入 deps.transcribe') })
  return transcribe(input)
}

/** 语音状态卡文案。 */
export function voiceStatusCard(cfg = readVoiceConfig()) {
  return [
    '语音状态卡',
    `- 麦克风：${cfg.enabled ? '按住说话时开（push-to-talk，≤15s）' : '关闭（默认）'}`,
    `- 音频：${cfg.retainAudio ? '本地保留（retainAudio=true，不推荐）' : '不落盘（转写/播报后即删，不出本机）'}`,
    `- 唤醒/常驻监听：无（明确不做）`,
  ].join('\n')
}

export default { readVoiceConfig, writeVoiceConfig, setVoiceEnabled, gatedTranscribe, voiceStatusCard, VOICE_DEFAULTS }
