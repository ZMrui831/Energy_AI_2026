// packages/core/src/voice-oneshot.mjs
//
// S42·A3 语音唤起即说：按下即录 → 静音 1.2s 自动结束 → 转写 → 文本入框（不自动发）。
// 纪律（红线）：
//   · 状态卡四态：待命(idle)/录音中(recording)/转写中(transcribing)/完成(done)（+error）。
//   · 默认关（复用 voice.enabled）；未触发不加载模型（转写器只在停止时注入调用）；零常驻（纯状态机，无 spawn）。
//   · 失败降级不影响键盘：任何异常返回 {ok:false}，不抛出。
import { readVoiceConfig } from './voice-settings.mjs'

export const SILENCE_MS_DEFAULT = 1200

/** RMS（16bit PCM buffer）。 */
export function rmsOf(buf) {
  let sum = 0
  const n = Math.floor(buf.length / 2)
  if (!n) return 0
  for (let i = 0; i < n; i++) {
    const v = buf.readInt16LE(i * 2)
    sum += v * v
  }
  return Math.sqrt(sum / n)
}

/**
 * 一次性语音会话（按住即说状态机）。
 * @param {{enabled?:boolean, configDoc?:object, transcribe?:Function, silenceMs?:number, rmsThreshold?:number, onState?:Function}} opts
 *   transcribe(blob) → {ok, text}；由宿主注入（未触发绝不加载模型）。
 */
export function createOneShotSession(opts = {}) {
  const cfg = readVoiceConfig(opts.configDoc)
  const silenceMs = Number.isFinite(opts.silenceMs) ? opts.silenceMs : SILENCE_MS_DEFAULT
  const rmsThreshold = Number.isFinite(opts.rmsThreshold) ? opts.rmsThreshold : 300
  const states = []
  let state = 'idle'
  let chunks = []
  let silenceAccumMs = 0
  let autoStopped = false
  const setState = (s) => { state = s; states.push(s); if (typeof opts.onState === 'function') { try { opts.onState(s) } catch { /* 尽力 */ } } }

  return {
    get state() { return state },
    states,
    get autoStopped() { return autoStopped },
    /** 触发开始（按下）：默认关 → 拒绝。 */
    start() {
      if (!cfg.enabled) {
        states.push('refused')
        return { ok: false, code: 'E_VOICE_DISABLED', state, reason: '语音输入已关闭（默认关）。请先开启：开启后按下即录、静音自动结束、文本入框需人确认。' }
      }
      chunks = []
      silenceAccumMs = 0
      autoStopped = false
      setState('recording')
      return { ok: true, state }
    },
    /** 推入一块 PCM（16bit）；静音 1.2s 自动结束。 */
    push(chunk, { chunkMs = 100 } = {}) {
      if (state !== 'recording') return { ok: false, state, reason: '未在录音态' }
      chunks.push(chunk)
      const loud = rmsOf(chunk) >= rmsThreshold
      if (loud) {
        silenceAccumMs = 0
      } else {
        silenceAccumMs += chunkMs
        if (silenceAccumMs >= silenceMs) {
          autoStopped = true
          return this.stop()
        }
      }
      return { ok: true, state, silenceAccumMs }
    },
    /** 结束（静音自动或手动）→ 转写 → 草稿（不自动发）。 */
    stop() {
      if (state !== 'recording') return { ok: false, state, reason: '未在录音态' }
      const blob = Buffer.concat(chunks)
      chunks = []
      if (!blob.length) {
        setState('error')
        return { ok: false, state: 'error', code: 'E_EMPTY_AUDIO', reason: '没有录到音频' }
      }
      setState('transcribing')
      try {
        const r = (typeof opts.transcribe === 'function')
          ? opts.transcribe(blob)
          : { ok: false, reason: '转写器未注入（宿主 IPC 注入；未触发前不加载模型）' }
        if (!r || r.ok !== true) {
          setState('error')
          return { ok: false, state: 'error', code: (r && r.code) || 'E_TRANSCRIBE', reason: (r && r.reason) || '转写失败（键盘输入不受影响）' }
        }
        setState('done')
        return { ok: true, state: 'done', text: r.text, draft: { text: String(r.text || ''), autoSend: false, source: 'voice-oneshot' }, autoStopped }
      } catch (e) {
        setState('error')
        return { ok: false, state: 'error', code: 'E_TRANSCRIBE', reason: '转写异常（键盘输入不受影响）：' + String((e && e.message) || e).slice(0, 80) }
      }
    },
  }
}

export default { createOneShotSession, rmsOf, SILENCE_MS_DEFAULT }
