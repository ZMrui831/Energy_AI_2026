-- 0001_init.sql —— S3 数据生命周期：初始 schema（任务书 §5 DDL，逐字采用）
-- checksum 说明：本文件内容的 sha256 由 packages/core/src/db.mjs 的迁移器在应用时
-- 计算并写入 schema_migration.checksum；再次启动时重新计算比对，不一致即
-- fail-closed（E_MIGRATION_CHECKSUM），绝不修改库。

CREATE TABLE IF NOT EXISTS schema_migration(version TEXT PRIMARY KEY, checksum TEXT NOT NULL, applied_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS app_meta(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS consent_grant(id TEXT PRIMARY KEY, mode TEXT NOT NULL, granted_at TEXT, expires_at TEXT, policy_version TEXT, displays TEXT, window_whitelist TEXT);
CREATE TABLE IF NOT EXISTS raw_frame(id TEXT PRIMARY KEY, file_path TEXT NOT NULL, sha256 TEXT NOT NULL CHECK(length(sha256)=64), sensitivity TEXT NOT NULL CHECK(sensitivity IN ('normal','sensitive','blocked')), status TEXT NOT NULL DEFAULT 'ready' CHECK(status IN ('ready','deleting','deleted','error')), error TEXT, created_at TEXT NOT NULL, expires_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_raw_frame_status_expires ON raw_frame(status, expires_at);
CREATE TABLE IF NOT EXISTS observation(id TEXT PRIMARY KEY, kind TEXT NOT NULL, source_frame_id TEXT REFERENCES raw_frame(id) ON DELETE SET NULL, ocr_excerpt TEXT, status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','deleted')), created_at TEXT NOT NULL, deleted_at TEXT);
CREATE TABLE IF NOT EXISTS summary(id TEXT PRIMARY KEY, content TEXT, status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','published','deleted')), created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS evidence_item(id TEXT PRIMARY KEY, observation_id TEXT REFERENCES observation(id) ON DELETE SET NULL, availability TEXT NOT NULL DEFAULT 'available' CHECK(availability IN ('available','expired','deleted','missing')), created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit_event(id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, kind TEXT NOT NULL, metadata_json TEXT NOT NULL CHECK(json_valid(metadata_json)));
