-- 0002_claim_evidence.sql —— S6 证据闸（CONTRACT §6）：claim 与证据关联结构
-- + "无证据的结论不得发布"的**数据层强制**（触发器，不是应用层 if）。
--
-- 设计口径（CONTRACT §6/§1.4/§2）：
--   · 证据 ID：ev_<kind>_<utc_ms>_<rand>（由 publish.mjs 生成；claim_evidence.evidence_id
--     既接受该格式，也接受跨层既有身份：raw_frame.id / observation.id / summary.id /
--     evidence_item.id / audit_event.id —— layer 列声明它指哪一层）。
--   · 跨层链路：raw_frame → observation → summary → claim_evidence（relation: direct/derived/none）。
--   · `none`（无直接证据）不得发布：触发器只认 relation<>'none' 的证据；publish 流程另有
--     E_NONE_EVIDENCE 明确拒绝（应用层可解释，数据层是最终强制）。
--   · claim 必须 draft 创建 → 经证据闸更新为 published（禁止直插 published，§1.4 状态机）。
--   · 原图被清理后行不删（§2）：claim_evidence.sha256 留存可回指的身份与内容哈希，
--     resolveEvidence() 据此给出固定降级文案，绝不伪装可查看。
--
-- 迁移安全（§7）：全语句 IF [NOT] EXISTS 幂等；db.mjs 迁移器对每个文件包
-- BEGIN/COMMIT + 失败 ROLLBACK，且应用前校验 checksum（不一致整体拒绝，不半途改库）。

-- ---- claim：结论本体（§1.4: draft→published|deleted；published 必须过证据闸）----
CREATE TABLE IF NOT EXISTS claim(
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL CHECK(kind IN ('observation','session','literature','perception','manual')),
  text TEXT NOT NULL,
  evidence_mode TEXT NOT NULL DEFAULT 'direct' CHECK(evidence_mode IN ('direct','derived','none')),
  status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','published','deleted')),
  created_at TEXT NOT NULL,
  published_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_claim_status ON claim(status, created_at);

-- ---- claim_evidence：结论 ↔ 证据关联（可回指的最小单元）----
CREATE TABLE IF NOT EXISTS claim_evidence(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  claim_id TEXT NOT NULL REFERENCES claim(id) ON DELETE CASCADE,
  evidence_id TEXT NOT NULL,
  layer TEXT NOT NULL CHECK(layer IN ('raw_frame','observation','summary','evidence_item','audit')),
  relation TEXT NOT NULL DEFAULT 'direct' CHECK(relation IN ('direct','derived','none')),
  sha256 TEXT CHECK(sha256 IS NULL OR length(sha256) = 64),
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_claim_evidence_claim ON claim_evidence(claim_id, relation);
CREATE INDEX IF NOT EXISTS idx_claim_evidence_evid ON claim_evidence(evidence_id);

-- ---- summary_evidence：summary 发布的证据关联（§6: summary draft→published 必须有证据）----
CREATE TABLE IF NOT EXISTS summary_evidence(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  summary_id TEXT NOT NULL REFERENCES summary(id) ON DELETE CASCADE,
  evidence_id TEXT NOT NULL,
  layer TEXT NOT NULL CHECK(layer IN ('raw_frame','observation','summary','evidence_item','audit')),
  relation TEXT NOT NULL DEFAULT 'direct' CHECK(relation IN ('direct','derived','none')),
  sha256 TEXT CHECK(sha256 IS NULL OR length(sha256) = 64),
  created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_summary_evidence_summary ON summary_evidence(summary_id, relation);

-- =====================================================================
-- 数据层强制（CONTRACT §6）：无证据的结论不得发布
-- =====================================================================

-- (a) claim 禁止直插 published：必须 draft 创建，走"草稿 → 证据校验 → 发布"。
DROP TRIGGER IF EXISTS trg_claim_no_direct_published_insert;
CREATE TRIGGER trg_claim_no_direct_published_insert BEFORE INSERT ON claim
WHEN NEW.status = 'published'
BEGIN
  SELECT RAISE(ABORT, 'CLAIM_EVIDENCE_DIRECT_INSERT_FORBIDDEN: claim 必须以 draft 创建并经证据闸发布（CONTRACT §6/§1.4）');
END;

-- (b) CLAIM_EVIDENCE_REQUIRED：claim 发布更新时，非 none 证据为 0 → 整体拒绝。
DROP TRIGGER IF EXISTS CLAIM_EVIDENCE_REQUIRED;
CREATE TRIGGER CLAIM_EVIDENCE_REQUIRED BEFORE UPDATE OF status ON claim
WHEN NEW.status = 'published' AND OLD.status <> 'published'
BEGIN
  SELECT RAISE(ABORT, 'CLAIM_EVIDENCE_REQUIRED: 无证据的结论不得发布（claim.id=' || NEW.id || '，非 none 证据 0 条；CONTRACT §6）')
  WHERE (SELECT COUNT(*) FROM claim_evidence WHERE claim_id = NEW.id AND relation <> 'none') = 0;
END;

-- (c) summary 同样两层：禁止直插 published；发布更新必须有非 none 证据。
DROP TRIGGER IF EXISTS trg_summary_no_direct_published_insert;
CREATE TRIGGER trg_summary_no_direct_published_insert BEFORE INSERT ON summary
WHEN NEW.status = 'published'
BEGIN
  SELECT RAISE(ABORT, 'CLAIM_EVIDENCE_DIRECT_INSERT_FORBIDDEN: summary 必须以 draft 创建并经证据闸发布（CONTRACT §6）');
END;

DROP TRIGGER IF EXISTS SUMMARY_EVIDENCE_REQUIRED;
CREATE TRIGGER SUMMARY_EVIDENCE_REQUIRED BEFORE UPDATE OF status ON summary
WHEN NEW.status = 'published' AND OLD.status <> 'published'
BEGIN
  SELECT RAISE(ABORT, 'CLAIM_EVIDENCE_REQUIRED: summary 发布缺少证据（summary.id=' || NEW.id || '，非 none 证据 0 条；CONTRACT §6）')
  WHERE (SELECT COUNT(*) FROM summary_evidence WHERE summary_id = NEW.id AND relation <> 'none') = 0;
END;
