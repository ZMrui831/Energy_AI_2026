// packages/core/src/profile-context.mjs
//
// S20·A：把用户画像 digest 注入对话 system 片段的【宿主侧只读读取器】。
// 设计约束（红线）：
//   · 不改 agent.mjs 内部逻辑——只读取 data/profile.json + data/profile-digest.txt，
//     由宿主（main.mjs）把结果拼到 agent 既有的 system 参数上。
//   · 本模块纯读取、全程 try/catch，任何异常都返回 ''（绝不拖停主进程）。
//   · 只有 profile.json.personalization === true 且 digest 文件存在时才返回非空。
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { DATA_DIR, dataPath } from './safefs.mjs'

/**
 * 读取画像 system 片段。
 * @param {{ root?: string }} [opts]
 * @returns {string} 非空表示要追加到 system 的画像片段；否则 ''
 */
export function readProfileSystemContext({ root = DATA_DIR } = {}) {
  try {
    const pj = dataPath('profile.json')
    if (!existsSync(pj)) return ''
    const prof = JSON.parse(readFileSync(pj, 'utf8'))
    if (!prof || prof.personalization !== true) return ''
    const dg = dataPath('profile-digest.txt')
    if (!existsSync(dg)) return ''
    const txt = readFileSync(dg, 'utf8').toString().trim()
    return txt || ''
  } catch {
    return ''
  }
}


/**
 * 宿主拼装 system：有画像片段则追加到默认 system 之后；否则原样返回默认。
 * 与 main.mjs 中的拼装逻辑一致，供测试确定性复现。
 */
export function composeSystemPrompt(defaultSystem, profileSys) {
  const s = (profileSys || '').trim()
  if (!s) return defaultSystem || ''
  return (defaultSystem || '') + '\n' + s
}

export default { readProfileSystemContext, composeSystemPrompt }
