// packages/core/src/session-index.mjs —— S57·T8 多会话索引（按主管裁定实现）
//
// 裁定：**抽屉 / 只删不改名（软删到回收区）/ 索引 200 但分页 50 / 默认关**。
//
// 纪律：
//   · 不改任何既有 JSONL 行格式；索引是**派生**（删掉也能重建）。
//   · 老会话无 title → deriveTitle(首条 user) **现算只读，不回写**（文件 mtime 不变）。
//   · 删除 = 软删：移到 data/trash/sessions/，可从回收区恢复。
//   · 坏文件（首行非 meta / 解析失败）跳过并计入 bad，列表底部提示，不影响其它项。
//   · 上限 INDEX_MAX=200 条（按 updatedAt 降序），页大小 PAGE_SIZE=50。

import { existsSync, mkdirSync, readdirSync, statSync, readFileSync, renameSync, openSync, readSync, closeSync } from 'node:fs'
import { join, basename } from 'node:path'
import { isDayDirName } from './session-rhythm.mjs'

export const INDEX_MAX = 200
export const PAGE_SIZE = 50
const SID_RE = /^[a-z0-9][a-z0-9_-]{2,63}$/i

/** 从会话文件现算标题（只读；meta.title 为空时用首条 user 文本，仍空则"新会话"）。
 *  S58·P1 性能：只读前 maxBytes（默认 64KB）——标题/turns 都在文件头部，避免全量读；
 *  turns 由头部行数给出（超长会话可能少计，只影响列表展示的"轮"，不影响会话本身）。 */
export function titleOfFile(filePath, maxBytes = 65536) {
  try {
    const fd = openSync(filePath, 'r')
    let text = ''
    try {
      const buf = Buffer.alloc(maxBytes)
      const n = readSync(fd, buf, 0, maxBytes, 0)
      text = buf.slice(0, n).toString('utf8')
    } finally {
      closeSync(fd)
    }
    let metaTitle = null
    let firstUser = null
    let turns = 0
    let validRows = 0
    for (const line of text.split('\n')) {
      const s = line.trim()
      if (!s) continue
      let row = null
      try { row = JSON.parse(s) } catch { continue }
      if (!row || typeof row !== 'object') continue
      if (row.type === 'session') { validRows += 1; if (row.title) metaTitle = String(row.title) }
      else if (row.type === 'user') { validRows += 1; turns += 1; if (!firstUser) firstUser = String(row.text || '') }
      else if (row.type === 'assistant') { validRows += 1; turns += 1 }
    }
    // 读不出任何合法行 → 坏文件（跳过并计入 bad，不猜测内容）
    if (validRows === 0) return { title: null, turns: 0, ok: false }
    const clean = (v) => String(v || '').replace(/\s+/g, ' ').trim()
    let title = clean(metaTitle)
    if (!title) title = clean(firstUser)
    if (!title) title = '新会话'
    if (title.length > 40) title = title.slice(0, 40) + '…'
    return { title, turns, ok: true }
  } catch {
    return { title: null, turns: 0, ok: false }
  }
}

/**
 * 扫描会话索引（分页）。
 * @param {{dir:string, offset?:number, pageSize?:number, max?:number}} opts
 * @returns {{ok:boolean, items:Array, total:number, hasMore:boolean, bad:Array<{id:string,reason:string}>, code?:string}}
 */
export function scanSessions({ dir, offset = 0, pageSize = PAGE_SIZE, max = INDEX_MAX }) {
  if (!existsSync(dir)) return { ok: true, items: [], total: 0, hasMore: false, bad: [] }
  let names = []
  try { names = readdirSync(dir) } catch (e) {
    return { ok: false, items: [], total: 0, hasMore: false, bad: [], code: 'E_LIST' }
  }
  // S58·P1 性能：两阶段 —— ① readdir+stat 全量排序（不读内容）② 只读**窗口内**文件头部。
  // 6648 条会话下首屏 50 条必须 <300ms（全量读文件会超时）。
  // S70·2A：根目录平铺（旧，只读兼容）+ 一层日目录 <yyyymmdd>/*.jsonl（新）合并扫描。
  const entries = []
  const addFile = (base, name) => {
    const id = name.slice(0, -'.jsonl'.length)
    if (!SID_RE.test(id)) return
    let st = null
    try { st = statSync(join(base, name)) } catch { return }
    entries.push({ id, name, base, mtimeMs: st.mtimeMs })
  }
  for (const n of names) {
    if (n.toLowerCase().endsWith('.jsonl')) { addFile(dir, n); continue }
    if (isDayDirName(n)) {
      try { for (const sn of readdirSync(join(dir, n))) if (sn.toLowerCase().endsWith('.jsonl')) addFile(join(dir, n), sn) } catch { /* skip */ }
    }
  }
  entries.sort((a, b) => b.mtimeMs - a.mtimeMs)
  const capped = entries.slice(0, Math.max(0, max))
  const window = capped.slice(offset, offset + pageSize)
  const items = []
  const bad = []
  for (const e of window) {
    const t = titleOfFile(join(e.base, e.name))
    if (!t.ok) { bad.push({ id: e.id, reason: 'unreadable' }); continue }
    items.push({ id: e.id, title: t.title, turns: t.turns, updatedAt: new Date(e.mtimeMs).toISOString() })
  }
  return {
    ok: true,
    items,
    total: capped.length,
    hasMore: offset + window.length < capped.length,
    bad, // 只报当前窗口内的坏文件（全量检测代价高；翻到那一页会看到）
  }
}

/** 软删：移到回收区（data/trash/sessions/<id>-<ts>.jsonl）。 */
export function softDeleteSession({ dir, trashDir, id }) {
  if (!SID_RE.test(String(id || ''))) return { ok: false, code: 'E_BAD_ID' }
  const src = join(dir, id + '.jsonl')
  if (!existsSync(src)) return { ok: false, code: 'E_NOT_FOUND' }
  try {
    mkdirSync(trashDir, { recursive: true })
    const ts = new Date().toISOString().replace(/[:.]/g, '-')
    const dst = join(trashDir, `${id}-${ts}.jsonl`)
    renameSync(src, dst)
    return { ok: true, file: basename(dst) }
  } catch (e) {
    return { ok: false, code: 'E_MOVE' }
  }
}

/** 回收区列表（可恢复）。 */
export function listTrashSessions({ trashDir }) {
  if (!existsSync(trashDir)) return { ok: true, items: [] }
  let names = []
  try { names = readdirSync(trashDir).filter((n) => n.toLowerCase().endsWith('.jsonl')) } catch {
    return { ok: false, items: [], code: 'E_LIST' }
  }
  const items = []
  for (const name of names) {
    const m = /^(.+?)-(\d{4}-\d{2}-\d{2}T[0-9T-]+Z)\.jsonl$/.exec(name)
    const id = m ? m[1] : name.replace(/\.jsonl$/, '')
    let st = null
    try { st = statSync(join(trashDir, name)) } catch { continue }
    items.push({ id, file: name, deletedAt: new Date(st.mtimeMs).toISOString() })
  }
  items.sort((a, b) => (a.deletedAt < b.deletedAt ? 1 : -1))
  return { ok: true, items }
}

/** 从回收区恢复（文件回到 sessions 目录；同 id 已存在则拒绝，不覆盖）。 */
export function restoreSession({ dir, trashDir, file }) {
  const name = String(file || '')
  const src = join(trashDir, name)
  if (!existsSync(src)) return { ok: false, code: 'E_NOT_FOUND' }
  const m = /^(.+?)-\d{4}-\d{2}-\d{2}T[0-9T-]+Z\.jsonl$/.exec(name)
  const id = m ? m[1] : name.replace(/\.jsonl$/, '')
  if (!SID_RE.test(id)) return { ok: false, code: 'E_BAD_ID' }
  const dst = join(dir, id + '.jsonl')
  if (existsSync(dst)) return { ok: false, code: 'E_EXISTS' }
  try {
    mkdirSync(dir, { recursive: true })
    renameSync(src, dst)
    return { ok: true, id }
  } catch { return { ok: false, code: 'E_MOVE' } }
}
