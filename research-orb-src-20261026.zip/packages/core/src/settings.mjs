// packages/core/src/settings.mjs
//
// 应用级配置（唯一读写入口）：data\config.json
//
// 为什么单独一个文件：ROADMAP v2 三原则第 1 条「可修改性」——换 pack / 换主题 /
// 换版本形态都应该是**改配置即可**，不动核心代码。配置与密钥分开：
//   · data\secrets.json  —— 密钥（SAFETY.md §4，只读，绝不写回）
//   · data\config.json   —— 本文件管的应用配置（可写，但只在用户显式操作时写）
//
// 铁律：写必走 safefs（→ writes.jsonl 留痕）；读失败/损坏回落默认值，不抛。
//       默认值保证「没有 config.json 时行为与历史版本完全一致」。

import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

import { safeWrite, PROJECT_ROOT, dataPath } from './safefs.mjs'

export const CONFIG_PATH = dataPath('config.json')

/** S35·B：日报双维权重（work/life）。默认 0.7/0.3 且 confirmed=false（待用户确认）。 */
export const WEIGHTS_DEFAULT = Object.freeze({ work: 0.7, life: 0.3, confirmed: false })

export function readWeights(doc = null) {
  const w = (doc && typeof doc === 'object' && doc.weights && typeof doc.weights === 'object') ? doc.weights : {}
  const num = (v, dflt) => (Number.isFinite(Number(v)) && Number(v) >= 0 && Number(v) <= 1 ? Number(v) : dflt)
  return {
    work: num(w.work, WEIGHTS_DEFAULT.work),
    life: num(w.life, WEIGHTS_DEFAULT.life),
    confirmed: w.confirmed === true,
  }
}

/** 默认配置：无 config.json 时等价于「research 包 + teal 主题 + personal 版」。 */
export const DEFAULT_SETTINGS = Object.freeze({
  activePack: 'research',
  enabledPacks: ['research'],
  theme: 'teal',
  edition: 'personal',
  demo: false,
})

const VALID_EDITIONS = Object.freeze(['personal', 'enterprise'])

function readJson(path) {
  if (!path || !existsSync(path)) return null
  try {
    return JSON.parse(readFileSync(path, 'utf8'))
  } catch {
    return null
  }
}

/**
 * 读配置并归一（损坏/缺字段回落默认）。绝不抛。
 * @param {string} [configPath]
 * @returns {{activePack:string, enabledPacks:string[], theme:string, edition:string, demo:boolean, raw:object}}
 */
export function loadSettings(configPath = CONFIG_PATH) {
  const doc = readJson(configPath) || {}
  const str = (v, dflt) => (typeof v === 'string' && v.trim() ? v.trim() : dflt)

  const enabledRaw = Array.isArray(doc.enabledPacks)
    ? doc.enabledPacks.map((x) => String(x)).filter(Boolean)
    : []
  const active = str(doc.activePack, DEFAULT_SETTINGS.activePack)
  const enabled = [...new Set(enabledRaw.length > 0 ? enabledRaw : [active])]
  if (!enabled.includes(active)) enabled.push(active)

  const edition = VALID_EDITIONS.includes(String(doc.edition)) ? String(doc.edition) : DEFAULT_SETTINGS.edition

  return {
    activePack: active,
    enabledPacks: enabled.sort(),
    theme: str(doc.theme, DEFAULT_SETTINGS.theme),
    edition,
    demo: doc.demo === true,
    mode: str(doc.mode, 'standard'),
    // S57·T8：多会话开关（默认关；关时行为与旧版完全一致）
    multiSession: { enabled: !!(doc.multiSession && doc.multiSession.enabled === true) },
    raw: doc && typeof doc === 'object' ? doc : {},
  }
}

/**
 * 合并写回配置（只改传入字段，其余保留；走 safefs 审计）。
 * @param {Partial<{activePack:string, enabledPacks:string[], theme:string, edition:string, demo:boolean}>} patch
 * @param {string} [configPath]
 */
export function saveSettings(patch = {}, configPath = CONFIG_PATH) {
  const cur = loadSettings(configPath)
  const next = { ...cur.raw }
  const set = (k, v) => { if (v !== undefined) next[k] = v }

  if (patch.activePack !== undefined) next.activePack = String(patch.activePack)
  if (patch.enabledPacks !== undefined) {
    next.enabledPacks = [...new Set([...patch.enabledPacks].map(String))].sort()
  }
  if (patch.theme !== undefined) next.theme = String(patch.theme)
  if (patch.edition !== undefined) {
    if (!VALID_EDITIONS.includes(String(patch.edition))) {
      throw new Error(`settings: 非法 edition -> ${patch.edition}（只允许 ${VALID_EDITIONS.join('/')}）`)
    }
    next.edition = String(patch.edition)
  }
  if (patch.demo !== undefined) next.demo = patch.demo === true
  // 运行模式（S22）：仅透传字符串，校验在 modes.setMode 完成；读回由 loadSettings 回落 'standard'
  if (patch.mode !== undefined) next.mode = String(patch.mode)

  safeWrite(configPath, `${JSON.stringify(next, null, 2)}\n`)
  return loadSettings(configPath)
}

/** 企业版开关：企业版下 L2/L3/L4 图形层与 headless 临时 profile 一律禁用。 */
export function isEnterprise(settings) {
  return (settings && settings.edition) === 'enterprise'
}

export default { loadSettings, saveSettings, isEnterprise, DEFAULT_SETTINGS, CONFIG_PATH, VALID_EDITIONS }