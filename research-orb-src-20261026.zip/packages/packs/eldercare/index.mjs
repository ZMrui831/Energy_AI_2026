// packages/packs/eldercare/index.mjs
//
// eldercare pack（P-R6）：只做声明与编排；能力实现在 packages\plugins\*。
// activate(ctx) 由 packages\core\src\packs.mjs 的 activatePack 调用，
// 之后按 pack.json 的 plugins 精确启用这些插件，并停用不在清单里的插件。

export const PACK_ID = 'eldercare'

export async function activate(ctx) {
  ctx.log.info(`${ctx.pack.name} pack 已激活：plugins=${ctx.pack.plugins.join(',')} theme=${ctx.pack.theme || '-'}`)
  return {
    pack: PACK_ID,
    deactivate() { ctx.log.info(`${ctx.pack.name} pack 已停用`) },
  }
}

export default { activate, PACK_ID }
