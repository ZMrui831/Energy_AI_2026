// packages/packs/research/ui/music.js
//
// S13「音乐律动光环」· B 路领域渲染层（pack UI）。
//
// 架构纪律（与 home.js/literature.js/timer.js 一致）：
//   · 自包含注入体：由主进程按 pack.json 的 ui 清单 executeJavaScript 注入，
//     不写 import / export，只经 window.__ro（R）工具箱取用底座能力。
//   · R 尚未就绪 / 重复注入时安静退出（幂等）：不叠按钮、不叠光环、不重复订阅。
//   · 本文件只渲染 + 上行意图，不读写文件、不出网、不弹通知。
//
// 视觉契约（S13-COMPONENT-CONTRACT §4）：
//   · 光环 <svg class="ro-music-halo" viewBox="0 0 96 96"> append 到 body（不是 #ball 内），
//     z-index:0 在 #ball（z-index:1）之下、pointer-events:none 不抢点击；画在 12px
//     padding 带（r 42±3）内，几何契约（球 96×96 / 面板 420×620 / 右下锚点）零改动。
//   · 三层：主环（radialGradient 三停走 --ro-ball-from / --ro-accent / --ro-face，
//     零硬编码色值）+ 彗尾（dasharray 亮弧，转速受 --ro-lvl 驱动）+ 16 段频谱刻度
//     （scaleY 受各段 --ro-band-i 驱动）。
//   · 电平：订阅 R.onMsg('music:level')；JS 侧 attack/release 包络跟随 + 双阈值
//     （起振 0.02 / 停振 0.008）消自激；每帧只写 --ro-lvl / --ro-peak 两个变量
//     （外加 16 个刻度变量一次性循环，禁止逐帧改 DOM 属性）。
//   · 静止纪律：@media (prefers-reduced-motion: reduce) 与 body.ro-frozen 下
//     动画与逐帧 transform 全部关闭（静态帧保证 12 态基线 SSIM 可比）。
//   · 降级（degraded / on:false / 无消息）：光环回落静态微呼吸，静音时不死，
//     不报错、不弹通知。
//   · 安全：音频元数据只经 textContent 呈现；本文件不拼任何 HTML，也不做动态 HTML 注入。

;(function (R) {
  'use strict'

  // ---- 防御式启动：R 未就绪 / 重复注入 → 安静退出 ----
  if (!R || typeof R.onMsg !== 'function') return
  const doc = R.doc || null
  if (!doc || typeof doc.getElementById !== 'function') return
  if (doc.getElementById('ro-music-btn')) return // 幂等：按钮已在 → 不重复注册
  if (typeof doc.querySelector === 'function' && doc.querySelector('.ro-music-halo')) return

  const NS = 'http://www.w3.org/2000/svg'
  const BAND_COUNT = 16
  const START_THRESHOLD = 0.02 // 起振阈值（WASAPI 峰值表会听见自己 → 双阈值消自激）
  const STOP_THRESHOLD = 0.008 // 停振阈值
  const PEAK_THRESHOLD = 0.85 // 峰值脉冲阈值
  const PULSE_MS = 460 // > 脉冲动画时长（420ms），保证动画放完再摘 class

  function clamp01(v) {
    const n = Number(v)
    if (!Number.isFinite(n) || n <= 0) return 0
    return n >= 1 ? 1 : n
  }

  // ------------------------------------------------------------------
  // 样式层（R.addStyle；颜色全部走主题 token，零硬编码色值）
  // ------------------------------------------------------------------
  const css = [
    // —— 顶栏按钮：照 vendor #history/#new-conversation 视觉语言（28px 圆钮 / input-bg / black），
    //    落在 #new-conversation（right:12px, 28px 宽）左侧；伪元素把点击热区扩到 32px，
    //    不占布局、不改几何。严禁 focus()（§5 不抢前台）。
    '#ro-music-btn {',
    '  position: absolute; top: var(--ro-topbar-top, 12px); right: 46px; z-index: 2;',
    '  display: grid; place-items: center; width: 28px; height: 28px;',
    '  border: 0; border-radius: 999px; padding: 0;',
    '  color: var(--black); background: var(--input-bg); cursor: pointer;',
    '}',
    'body.expand-down #ro-music-btn { top: auto; bottom: var(--ro-topbar-top, 12px); }',
    '#ro-music-btn::after { content: ""; position: absolute; inset: -2px; }',
    '#ro-music-btn svg { width: 16px; height: 16px; display: block; }',
    '#ro-music-btn[aria-pressed="true"] { color: var(--ro-ball-from); }',

    // —— 光环容器：body 级叠加层（不在 #ball 内），贴在收起态悬浮球所在的 96×96 角上，
    //    z-index:0 位于 #ball（z-index:1）之下；pointer-events:none 不扩大点击热区。
    //    展开态面板有完整视觉，光环只属于收起态球（display:none，零干扰面板）。
    '.ro-music-halo {',
    '  position: absolute; right: 0; bottom: 0; width: 96px; height: 96px;',
    '  z-index: 0; pointer-events: none;',
    '}',
    'body.expand-right .ro-music-halo { right: auto; left: 0; }',
    'body.expand-down .ro-music-halo { bottom: auto; top: 0; }',
    'body.expanded .ro-music-halo { display: none; }',

    // —— 主环：radialGradient 三停全走主题 token（青绿 / 黄方向 / 暖白）——
    '.ro-music-halo .ro-halo-s0 { stop-color: var(--ro-ball-from); }',
    '.ro-music-halo .ro-halo-s1 { stop-color: var(--ro-accent); }',
    '.ro-music-halo .ro-halo-s2 { stop-color: var(--ro-face); }',
    '.ro-music-halo .ro-halo-ring {',
    '  fill: none; stroke: url(#ro-halo-grad); stroke-width: 3; opacity: 0.38;',
    '  animation: ro-halo-breathe 3.6s ease-in-out infinite;',
    '}',
    '.ro-music-halo.ro-live .ro-halo-ring {',
    '  animation: none;',
    '  opacity: calc(0.4 + 0.6 * var(--ro-lvl, 0));',
    '}',

    // —— 彗尾：pathLength=100 → dasharray 24 76 = 24% 亮弧；转速受电平驱动 ——
    '.ro-music-halo .ro-halo-comet {',
    '  fill: none; stroke: url(#ro-halo-grad); stroke-linecap: round;',
    '  stroke-width: calc(3px + var(--ro-peak, 0) * 1.5px);',
    '  stroke-dasharray: 24 76; opacity: 0;',
    '  transform-box: view-box; transform-origin: 48px 48px;',
    '  animation: ro-halo-spin calc(6s - var(--ro-lvl, 0) * 4.5s) linear infinite;',
    '  animation-play-state: paused;',
    '}',
    '.ro-music-halo.ro-live .ro-halo-comet {',
    '  opacity: calc(0.25 + 0.75 * var(--ro-lvl, 0));',
    '  animation-play-state: running;',
    '}',

    // —— 频谱刻度：16 段径向短线（外端 r≈45.4，内端 r=42）——
    '.ro-music-halo .ro-halo-band {',
    '  stroke: var(--ro-ball-from); stroke-width: 2.4; stroke-linecap: round;',
    '  transform-box: view-box; transform-origin: 48px 6px;',
    '}',

    // —— 峰值脉冲：一次性外发光（drop-shadow 走主题 token）——
    '@keyframes ro-halo-pulse {',
    '  0% { filter: drop-shadow(0 0 2px var(--ro-ball-from)); }',
    '  40% { filter: drop-shadow(0 0 7px var(--ro-ball-from)); }',
    '  100% { filter: drop-shadow(0 0 0 var(--ro-ball-from)); }',
    '}',
    '.ro-music-halo.ro-peak .ro-halo-ring { animation: ro-halo-pulse 420ms ease-out 1; }',

    '@keyframes ro-halo-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }',
    '@keyframes ro-halo-breathe { 0%, 100% { opacity: 0.22; } 50% { opacity: 0.5; } }',

    // —— 静止纪律（沿用 ui-bridge 既有规则写法）：reduced-motion 与冻结基线完全静止 ——
    //    只针对"会动"的元素（环/彗尾/刻度）；<g> 上的静态 rotate 是几何不是动画，保留。
    '@media (prefers-reduced-motion: reduce) {',
    '  .ro-music-halo .ro-halo-ring, .ro-music-halo .ro-halo-comet, .ro-music-halo .ro-halo-band {',
    '    animation: none !important; transform: none !important;',
    '  }',
    '}',
    'body.ro-frozen .ro-music-halo .ro-halo-ring,',
    'body.ro-frozen .ro-music-halo .ro-halo-comet,',
    'body.ro-frozen .ro-music-halo .ro-halo-band {',
    '  animation: none !important; transform: none !important;',
    '}',
  ]
  // 各段自己的刻度变量（CSS 无法动态下标，故静态生成 16 条规则）
  for (let i = 0; i < BAND_COUNT; i += 1) {
    css.push('.ro-music-halo .ro-halo-b' + i + ' { transform: scaleY(calc(0.1 + 0.9 * var(--ro-band-' + i + ', 0))); }')
  }
  if (typeof R.addStyle === 'function') R.addStyle(css.join('\n'))

  // ------------------------------------------------------------------
  // 顶栏按钮：#new-conversation 前 insertBefore；点击只上行意图，不抢焦点
  // ------------------------------------------------------------------
  let btn = null
  let btnOn = false
  function buildButton() {
    const host = doc.getElementById('new-conversation')
    if (!host || !host.parentNode) return
    const b = doc.createElement('button')
    b.id = 'ro-music-btn'
    b.type = 'button'
    b.setAttribute('aria-pressed', 'false')
    b.title = '音乐律动光环：已关闭（点击开启）'
    const svg = doc.createElementNS(NS, 'svg')
    svg.setAttribute('viewBox', '0 0 16 16')
    svg.setAttribute('aria-hidden', 'true')
    svg.setAttribute('focusable', 'false')
    const stems = doc.createElementNS(NS, 'path')
    stems.setAttribute('d', 'M5.9 11.9V4.0L11.9 4.9V10.5')
    stems.setAttribute('fill', 'none')
    stems.setAttribute('stroke', 'currentColor')
    stems.setAttribute('stroke-width', '1.5')
    stems.setAttribute('stroke-linecap', 'round')
    stems.setAttribute('stroke-linejoin', 'round')
    svg.appendChild(stems)
    const head1 = doc.createElementNS(NS, 'circle')
    head1.setAttribute('cx', '4')
    head1.setAttribute('cy', '12')
    head1.setAttribute('r', '1.9')
    const head2 = doc.createElementNS(NS, 'circle')
    head2.setAttribute('cx', '10')
    head2.setAttribute('cy', '10.8')
    head2.setAttribute('r', '1.9')
    for (const h of [head1, head2]) {
      h.setAttribute('fill', 'none')
      h.setAttribute('stroke', 'currentColor')
      h.setAttribute('stroke-width', '1.5')
      svg.appendChild(h)
    }
    b.appendChild(svg)
    b.addEventListener('click', () => {
      // 意图上行：主进程转交 /music toggle（plugin:command 的 args 是字符串，见 main.mjs）。
      if (typeof R.send === 'function') R.send('plugin:command', { name: 'music', args: 'toggle' })
    })
    host.parentNode.insertBefore(b, host)
    btn = b
    // 归属登记：点击走 pack 自己的语义，不进底座匿名按钮审计
    if (typeof R.claimRoot === 'function') R.claimRoot(b)
  }

  // ------------------------------------------------------------------
  // 光环：body 级叠加层（三层：主环 / 彗尾 / 16 段频谱刻度）
  // ------------------------------------------------------------------
  let halo = null
  function buildHalo() {
    if (!doc.body || typeof doc.createElementNS !== 'function') return
    const svg = doc.createElementNS(NS, 'svg')
    svg.setAttribute('class', 'ro-music-halo')
    svg.setAttribute('viewBox', '0 0 96 96')
    svg.setAttribute('aria-hidden', 'true')

    const defs = doc.createElementNS(NS, 'defs')
    const grad = doc.createElementNS(NS, 'radialGradient')
    grad.setAttribute('id', 'ro-halo-grad')
    grad.setAttribute('cx', '50%')
    grad.setAttribute('cy', '50%')
    grad.setAttribute('r', '50%')
    const stops = [[0, 'ro-halo-s0'], [0.55, 'ro-halo-s1'], [1, 'ro-halo-s2']]
    for (const [offset, cls] of stops) {
      const stop = doc.createElementNS(NS, 'stop')
      stop.setAttribute('offset', String(offset))
      stop.setAttribute('class', cls)
      grad.appendChild(stop)
    }
    defs.appendChild(grad)
    svg.appendChild(defs)

    const ring = doc.createElementNS(NS, 'circle')
    ring.setAttribute('class', 'ro-halo-ring')
    ring.setAttribute('cx', '48')
    ring.setAttribute('cy', '48')
    ring.setAttribute('r', '42')
    ring.setAttribute('fill', 'none')
    ring.setAttribute('stroke', 'url(#ro-halo-grad)')
    svg.appendChild(ring)

    const comet = doc.createElementNS(NS, 'circle')
    comet.setAttribute('class', 'ro-halo-comet')
    comet.setAttribute('cx', '48')
    comet.setAttribute('cy', '48')
    comet.setAttribute('r', '42')
    comet.setAttribute('pathLength', '100') // dasharray 24 76 = 24% 亮弧
    comet.setAttribute('fill', 'none')
    comet.setAttribute('stroke', 'url(#ro-halo-grad)')
    svg.appendChild(comet)

    const bands = doc.createElementNS(NS, 'g')
    bands.setAttribute('class', 'ro-halo-bands')
    for (let i = 0; i < BAND_COUNT; i += 1) {
      const g = doc.createElementNS(NS, 'g')
      g.setAttribute('transform', 'rotate(' + i * (360 / BAND_COUNT) + ' 48 48)')
      const line = doc.createElementNS(NS, 'line')
      line.setAttribute('class', 'ro-halo-band ro-halo-b' + i)
      line.setAttribute('x1', '48')
      line.setAttribute('y1', '2.6')
      line.setAttribute('x2', '48')
      line.setAttribute('y2', '6')
      g.appendChild(line)
      bands.appendChild(g)
    }
    svg.appendChild(bands)

    doc.body.appendChild(svg)
    halo = svg
  }

  // ------------------------------------------------------------------
  // 电平驱动：onMsg 订阅 + 包络跟随 + 双阈值 + 峰值脉冲（rising-edge）
  // ------------------------------------------------------------------
  const latest = { level: 0, peak: 0, on: false, degraded: false, bands: null }
  const bandEnv = new Array(BAND_COUNT).fill(0)
  let lvl = 0
  let peakEnv = 0
  let prevRawPeak = 0
  let live = false
  let pulsing = false
  let idle = true
  let rafId = 0

  function onLevel(msg) {
    if (!msg || typeof msg !== 'object') return
    latest.level = clamp01(msg.level)
    latest.peak = clamp01(msg.peak)
    latest.on = msg.on === true
    latest.degraded = msg.degraded === true
    latest.bands = Array.isArray(msg.bands) ? msg.bands : null
    syncButton()
    if (idle) {
      idle = false
      rafId = requestAnimationFrame(tick)
    }
  }

  function syncButton() {
    if (!btn) return
    const on = latest.on === true
    if (on !== btnOn) {
      btnOn = on
      btn.setAttribute('aria-pressed', on ? 'true' : 'false')
      btn.title = on ? '音乐律动光环：播放中（点击关闭）' : '音乐律动光环：已关闭（点击开启）'
    }
  }

  function pulse() {
    if (!halo) return
    pulsing = true
    halo.classList.add('ro-peak')
    setTimeout(() => {
      pulsing = false
      if (halo) halo.classList.remove('ro-peak')
    }, PULSE_MS)
  }

  function tick() {
    if (!halo) { idle = true; return }
    // 目标电平：关闭或降级 → 0（光环回落微呼吸，不报错不弹通知）
    const target = latest.on && !latest.degraded ? latest.level : 0
    // attack/release 双时间常数：起振快、回落慢，30Hz 抖动不直接传到光环
    lvl += (target - lvl) * (target > lvl ? 0.35 : 0.12)
    if (lvl < 0.0005) lvl = 0
    // 双阈值消自激（起振 0.02 / 停振 0.008）
    if (!live && lvl > START_THRESHOLD) { live = true; halo.classList.add('ro-live') }
    else if (live && lvl < STOP_THRESHOLD) { live = false; halo.classList.remove('ro-live') }
    // 峰值包络（驱动彗尾粗细）+ rising-edge 一次性脉冲
    const rawPeak = latest.on && !latest.degraded ? latest.peak : 0
    peakEnv += (rawPeak - peakEnv) * (rawPeak > peakEnv ? 0.6 : 0.08)
    if (peakEnv < 0.0005) peakEnv = 0
    if (!pulsing && live && prevRawPeak <= PEAK_THRESHOLD && rawPeak > PEAK_THRESHOLD) pulse()
    prevRawPeak = rawPeak
    // 每帧只写两个电平变量到 halo 根（CSS 用 calc() 派生转速/亮度/粗细）
    halo.style.setProperty('--ro-lvl', lvl.toFixed(3))
    halo.style.setProperty('--ro-peak', peakEnv.toFixed(3))
    // 16 个刻度变量一次性循环（不是逐帧改 DOM 属性；契约允许）
    const useBands = live && latest.bands
    let anyBand = false
    for (let i = 0; i < BAND_COUNT; i += 1) {
      const t = useBands ? clamp01(latest.bands[i]) : 0
      bandEnv[i] += (t - bandEnv[i]) * (t > bandEnv[i] ? 0.5 : 0.18)
      if (bandEnv[i] < 0.0005) bandEnv[i] = 0
      if (bandEnv[i] > 0) anyBand = true
      halo.style.setProperty('--ro-band-' + i, bandEnv[i].toFixed(3))
    }
    // 完全静止（停振 + 刻度归零）→ 停帧节电；微呼吸是纯 CSS，不耗 JS
    if (!live && !anyBand && lvl === 0 && peakEnv === 0) { idle = true; return }
    rafId = requestAnimationFrame(tick)
  }

  // ------------------------------------------------------------------
  // 启动
  // ------------------------------------------------------------------
  buildButton()
  buildHalo()
  R.onMsg('music:level', onLevel)
})(window.__ro)
