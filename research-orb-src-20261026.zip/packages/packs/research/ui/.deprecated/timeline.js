// packages/packs/research/ui/timeline.js
//
// S4 · 学习轨迹页（最小版）：列出当天片段（时间/状态/时长/置信度/证据数/保留倒计时），
// 点击展开可回指 evidence_id；原图已被保留策略清理的，如实显示"原图已按保留策略删除"。
//
// 架构纪律与 literature.js/timer.js 一致：领域渲染层，由 shell 注入 renderer，
// 不写 import/export，只经 window.__ro 工具箱渲染 + 上行命令，不读写文件、不出网。
// 不改任何几何契约（球 96×96 / 面板 420×620）——只在既有 panel 内追加自建 DOM。

;(function (R) {
  'use strict'
  const { doc, panel, el, send } = R

  const root = doc.createElement('div')
  root.id = 'ro-timeline'
  root.setAttribute('role', 'region')
  root.setAttribute('aria-label', '学习轨迹')
  root.style.display = 'none'
  if (panel) panel.appendChild(root)

  const head = el('div', 'ro-lit-head')
  head.appendChild(el('h3', 'ro-lit-title', '学习轨迹'))
  const refreshBtn = el('button', 'ro-btn', '刷新')
  refreshBtn.type = 'button'
  const closeBtn = el('button', 'ro-settings-close', '关闭')
  closeBtn.type = 'button'
  head.appendChild(refreshBtn)
  head.appendChild(closeBtn)
  root.appendChild(head)

  const list = el('div', 'ro-lit-list')
  root.appendChild(list)

  let expandedId = null
  let lastPayload = null

  function fmtDur(ms) {
    if (ms == null) return '进行中'
    const s = Math.round(ms / 1000)
    return s >= 60 ? Math.floor(s / 60) + 'm' + (s % 60) + 's' : s + 's'
  }

  function evidRow(e) {
    const row = el('div', 'ro-lit-item')
    row.style.paddingLeft = '14px'
    row.style.fontSize = '11px'
    const label =
      e.status === 'deleted'
        ? '⚠ ' + e.label
        : e.status === 'available'
          ? '🖼 ' + e.label
          : '· ' + e.label
    row.textContent = `${e.evidence_id} — ${label}`
    row.title = 'evidence_id=' + e.evidence_id
    return row
  }

  function segRow(s) {
    const wrap = el('div', 'ro-lit-item')
    const t = s.startedAt ? new Date(s.startedAt).toTimeString().slice(0, 5) : '--:--'
    const outcomeLabel = { promoted: '已晋升', discarded: '已丢弃', rejected: '已婉拒', pending: '草稿' }[s.outcome] || s.outcome
    const main = el('div', 'ro-tl-row')
    main.textContent =
      `${t} [${outcomeLabel}] ${fmtDur(s.durationMs)} · 置信度=${s.confidence ?? '-'} · 证据=${s.evidenceCount}`
    main.style.cursor = 'pointer'
    main.addEventListener('click', () => {
      expandedId = expandedId === s.id ? null : s.id
      renderPayload(lastPayload)
    })
    wrap.appendChild(main)
    if (expandedId === s.id) {
      const det = el('div', 'ro-tl-detail')
      det.style.paddingLeft = '14px'
      det.style.fontSize = '11px'
      det.textContent =
        `片段 ${s.id} · 状态=${s.state} · 停留=${s.dwellLabel || '-'}` +
        (s.notePath ? ` · 正式笔记=${s.notePath.split('\\').pop()}` : '') +
        (s.draftPath && s.outcome === 'pending' ? ` · 草稿=${s.draftPath.split('\\').pop()}` : '')
      wrap.appendChild(det)
      for (const e of s.evidence || []) wrap.appendChild(evidRow(e))
    }
    return wrap
  }

  function render(day) {
    list.textContent = ''
    // 上行取数：复用 plugin:command 通道（主进程转交 /timeline，下行经 plugin:panel 回来）
    send('plugin:command', { name: 'timeline', args: day ? String(day) : '' })
    const hint = el('div', 'ro-lit-item')
    hint.textContent = '加载中…（/timeline）'
    list.appendChild(hint)
  }

  function renderPayload(ui) {
    lastPayload = ui
    list.textContent = ''
    if (!ui.segments || ui.segments.length === 0) {
      const empty = el('div', 'ro-lit-item')
      empty.textContent = ui.degraded ? '今天还没有片段（lifecycle store 未接入，证据状态无法对账）。' : '今天还没有片段。点「开始学习」产生第一段。'
      list.appendChild(empty)
      return
    }
    for (const s of ui.segments) list.appendChild(segRow({ ...s, day: ui.day }))
  }

  refreshBtn.addEventListener('click', () => render(''))
  closeBtn.addEventListener('click', () => { root.style.display = 'none' })

  // 面板打开即拉一次（下行 plugin:panel 的 pluginId === 'timeline'）
  R.onPanel('timeline', (payload) => {
    root.style.display = ''
    if (payload && payload.ui) renderPayload(payload.ui)
  })
})(window.__ro)
