// packages/packs/research/ui/home.js
//
// S5 · 信息架构（IA）主文件：首页 + 二级页（对话/轨迹/笔记）+ 开始学习 + 主动询问卡
// + 拒绝冷却 UI + 12 态调试矩阵。
//
// 架构纪律（与 literature.js/timer.js 一致）：领域渲染层，由 shell 注入 renderer，
// 不写 import/export，只经 window.__ro 工具箱渲染 + 上行命令，不读写文件、不出网。
// **不改几何契约**：球 96×96 / 面板 420×620 / 右下锚点一律不动；只往 panel 内加 DOM。
// **不抢前台**：本文件没有任何 focus()/show() 调用。
//
// 设计 token（tools/accept-ui-matrix.mjs 实测）：
//   间距 4/8（--s5-sp1/--s5-sp2）；字号 12/14/16/20；点击目标 ≥32px（关键 ≥40px）；
//   正文色 var(--black) 于 var(--white) 之上（主题保证对比度 ≥4.5:1）。
//
// 调试入口（截图回归用）：window.__s5 = { page, currentPage, setState, refresh }。

;(function (R) {
  'use strict'
  const { doc, panel, el, send, addNotice, transcript, fmtDur, VERSION, PATHS, scrollToEnd } = R

  // ------------------------------------------------------------------
  // 页面状态（记忆：JS 变量扛收起/展开；localStorage 扛重载/切 pack）
  // ------------------------------------------------------------------
  const PAGE_KEY = 'ro.s5.page'
  const PAGES = ['home', 'chat', 'trajectory', 'notes', 'publish']
  let page = 'home'
  try {
    const saved = localStorage.getItem(PAGE_KEY)
    if (saved && PAGES.includes(saved)) page = saved
  } catch { /* 无 localStorage 按首页 */ }

  // 12 态调试矩阵（与 timeline/logic.mjs UI_STATES 对齐）
  const STATES = [
    'default', 'monitoring', 'paused', 'no-consent', 'learning-candidate', 'learning',
    'silent', 'needs-confirm', 'success', 'failure', 'offline', 'deleted',
  ]
  let uiState = 'default'
  let statusData = null

  // ------------------------------------------------------------------
  // 样式层（token）
  // ------------------------------------------------------------------
  R.addStyle(`
    #ro-s5-topbar { display:flex; align-items:center; gap: var(--s5-sp1, 4px); padding: var(--s5-sp1, 4px) var(--s5-sp2, 8px); font-size: 14px; }
    #ro-s5-topbar .s5-crumb { font-size: 12px; color: var(--black); flex: 1; }
    #ro-s5-topbar .s5-back { min-height: 32px; min-width: 32px; font-size: 14px; padding: 4px 8px; }
    #ro-s5 .ro-btn { font-size: 14px; padding: 4px 8px; }
    .s5-page { display:none; padding: var(--s5-sp2, 8px); overflow-y:auto; font-size: 14px; }
    .s5-page.s5-on { display:block; }
    .s5-status { display:flex; flex-wrap:wrap; gap: var(--s5-sp1, 4px); margin-bottom: var(--s5-sp2, 8px); font-size: 12px; }
    .s5-chip { font-size: 12px; padding: 4px var(--s5-sp2, 8px); border:1px solid var(--border);
               border-radius: 10px; background: var(--input-bg, var(--white)); color: var(--black); }
    .s5-chip.s5-strong { background: var(--black); color: var(--white); }
    .s5-actions { display:grid; grid-template-columns: 1fr 1fr; gap: var(--s5-sp2, 8px); margin-bottom: var(--s5-sp2, 8px); font-size: 14px; }
    .s5-act { min-height: 40px; font-size: 14px; display:flex; align-items:center; justify-content:center; }
    .s5-act.s5-wide { grid-column: 1 / -1; }
    .s5-sec { font-size: 12px; color: var(--black); margin: var(--s5-sp2, 8px) 0 var(--s5-sp1, 4px); }
    .s5-list { font-size: 14px; color: var(--black); }
    .s5-row { display:flex; align-items:center; gap: var(--s5-sp1, 4px); padding: var(--s5-sp1, 4px) 0;
              border-bottom: 1px solid var(--border); min-height: 32px; cursor: pointer; font-size: 14px; }
    .s5-row:hover { background: var(--input-bg, var(--white)); }
    .s5-row .s5-grow { flex: 1; font-size: 14px; }
    .s5-row .s5-sub { font-size: 12px; color: var(--black); }
    .s5-ask { border:1px solid var(--black); border-radius: 8px; padding: var(--s5-sp2, 8px); margin-bottom: var(--s5-sp2, 8px); font-size: 14px; }
    .s5-ask h4 { margin: 0 0 var(--s5-sp1, 4px); font-size: 16px; color: var(--black); }
    .s5-ask p { margin: 0 0 var(--s5-sp1, 4px); font-size: 12px; color: var(--black); }
    .s5-ask .s5-ask-btns { display:flex; gap: var(--s5-sp2, 8px); margin-top: var(--s5-sp2, 8px); font-size: 14px; }
    .s5-ask .s5-ask-btns button { flex:1; min-height: 40px; min-width: 120px; font-size: 14px; }
    .s5-evidence { font-size: 12px; color: var(--black); padding-left: var(--s5-sp2, 8px); }
    .s5-note { font-size: 12px; color: var(--black); padding: var(--s5-sp2, 8px); }
    .s5-failure { border: 2px solid var(--black); font-weight: bold; }
    #ro-s5 button:disabled { cursor: not-allowed; border-style: dashed; }
    #s5-notice { border:1px solid var(--border); border-radius: 8px; margin-bottom: var(--s5-sp2, 8px); }
    .s5-badge { font-size: 12px; padding: 0 var(--s5-sp1, 4px); border:1px solid var(--border); border-radius: 8px; color: var(--black); }
    .s5-none { border-style: dashed; opacity: 0.92; }
    .s5-deleted { font-weight: bold; }
    .s5-input { width: 100%; box-sizing: border-box; font-size: 14px; font-family: inherit; color: var(--black);
                background: var(--input-bg, var(--white)); border: 1px solid var(--border); border-radius: 8px;
                padding: var(--s5-sp2, 8px); margin-bottom: var(--s5-sp2, 8px); resize: vertical; }
    .s5-toclaim { min-height: 32px; font-size: 12px; margin-left: var(--s5-sp2, 8px); padding: 4px 8px; }
    #ro-s5 :focus-visible { outline: 2px solid var(--black); outline-offset: 1px; }
  `)

  // ------------------------------------------------------------------
  // DOM
  // ------------------------------------------------------------------
  const root = doc.createElement('div')
  root.id = 'ro-s5'
  if (panel) panel.appendChild(root)
  if (R.claimRoot) R.claimRoot(root)

  const topbar = el('div', '')
  topbar.id = 'ro-s5-topbar'
  const backBtn = el('button', 'ro-btn s5-back', '← 首页')
  backBtn.type = 'button'
  backBtn.title = '返回首页（Esc 同效）'
  const crumb = el('div', 's5-crumb', '首页')
  const chatBtn = el('button', 'ro-btn s5-back', '对话')
  chatBtn.type = 'button'
  chatBtn.title = '进入对话页'
  topbar.appendChild(backBtn)
  topbar.appendChild(crumb)
  topbar.appendChild(chatBtn)
  root.appendChild(topbar)

  // 首页
  const homePage = el('div', 's5-page')
  homePage.id = 's5-home'
  const statusStrip = el('div', 's5-status')
  const actions = el('div', 's5-actions')
  const pending = el('div', 's5-pending')
  const homeBody = el('div', 's5-list')
  homePage.appendChild(statusStrip)
  homePage.appendChild(actions)
  homePage.appendChild(pending)
  homePage.appendChild(homeBody)
  root.appendChild(homePage)

  // 二级页容器
  const trajPage = el('div', 's5-page')
  trajPage.id = 's5-trajectory'
  const trajBody = el('div', 's5-list')
  trajPage.appendChild(trajBody)
  root.appendChild(trajPage)

  // 发布页（S7：结论发布面板——证据清单/编辑措辞/发布；证据不足不得发布）
  const publishPage = el('div', 's5-page')
  publishPage.id = 's5-publish'
  const pubNew = el('div', 's5-actions')
  const pubLists = el('div', 's5-list')
  publishPage.appendChild(pubNew)
  publishPage.appendChild(pubLists)
  root.appendChild(publishPage)
  let pubClaims = null
  let pubDetail = null
  let pubSegments = []

  const notesPage = el('div', 's5-page')
  notesPage.id = 's5-notes'
  const notesBody = el('div', 's5-list')
  notesPage.appendChild(notesBody)
  root.appendChild(notesPage)

  // 主动询问卡（全局浮层，任何页面都可出现）
  const askCard = el('div', 's5-ask')
  askCard.id = 's5-ask'
  askCard.style.display = 'none'
  const askTitle = el('h4', '', '需要帮助吗？')
  const askReason = el('p', '')
  const askEvidence = el('p', '')
  const askBtns = el('div', 's5-ask-btns')
  const helpBtn = el('button', 'ro-btn', '需要帮助')
  helpBtn.type = 'button'
  const noBtn = el('button', 'ro-btn', '不用了')
  noBtn.type = 'button'
  askBtns.appendChild(helpBtn)
  askBtns.appendChild(noBtn)
  askCard.appendChild(askTitle)
  askCard.appendChild(askReason)
  askCard.appendChild(askEvidence)
  askCard.appendChild(askBtns)
  root.appendChild(askCard)

  // shell 的对话页元素（二级页：显示/隐藏由本文件控制）
  const chatEls = ['transcript', 'prompt', 'ro-welcome-base', 'page-title', 'input-label', 'history', 'new-conversation']
    .map((id) => doc.getElementById(id))
    .filter(Boolean)

  // ------------------------------------------------------------------
  // 动作按钮（≤5 主动作）
  // ------------------------------------------------------------------
  const learnBtn = el('button', 'ro-btn s5-act s5-wide', '开始学习')
  learnBtn.type = 'button'
  learnBtn.dataset.act = 'learn'
  const askScreenBtn = el('button', 'ro-btn s5-act', '问屏幕')
  askScreenBtn.type = 'button'
  const draftBtn = el('button', 'ro-btn s5-act', '新建草稿')
  draftBtn.type = 'button'
  const trajBtn = el('button', 'ro-btn s5-act', '今日轨迹')
  trajBtn.type = 'button'
  const sitesBtn = el('button', 'ro-btn s5-act', '最近网站')
  sitesBtn.type = 'button'
  actions.appendChild(learnBtn)
  actions.appendChild(askScreenBtn)
  actions.appendChild(draftBtn)
  actions.appendChild(trajBtn)
  actions.appendChild(sitesBtn)

  // 开始/结束学习：四态由 setLearnState 驱动（busy 期间禁用，禁止重复点击）
  learnBtn.addEventListener('click', () => {
    if (learnBusy) return
    clearFailureNotice() // 重新尝试即清除上一条失败原因
    learnStarting = learnBtn.textContent === '开始学习'
    setLearnState('busy')
    sendCmd('learn', learnStarting ? 'start' : 'stop')
  })

  // ------------------------------------------------------------------
  // 镜 4：对话页每条助手回复挂"转为结论"入口（真实 IPC → /claim new session）
  // ------------------------------------------------------------------
  const transcriptEl = doc.getElementById('transcript')
  if (transcriptEl && typeof MutationObserver === 'function') {
    const decorateAssistant = () => {
      for (const node of transcriptEl.querySelectorAll('.ro-msg.ro-assistant')) {
        if (node.dataset.claimDecorated === '1') continue
        node.dataset.claimDecorated = '1'
        const btn = el('button', 'ro-btn s5-toclaim', '转为结论')
        btn.type = 'button'
        btn.title = '把这条回复建成结论草稿；证据不足时会说明缺什么'
        btn.addEventListener('click', (ev) => {
          ev.stopPropagation()
          const text = (node.textContent || '').replace(/转为结论$/, '').trim().slice(0, 400)
          if (!text) { showAskNotice('这条回复是空的，无法建结论。'); return }
          sendCmd('claim', 'new session ' + text)
          go('publish')
        })
        node.appendChild(btn)
      }
    }
    new MutationObserver(decorateAssistant).observe(transcriptEl, { childList: true, subtree: true })
    decorateAssistant()
  }

  // ------------------------------------------------------------------
  // D4：等待态四态（进行中 / 禁用（说明原因）/ 成功 / 失败（原因+下一步））
  // ------------------------------------------------------------------
  let learnBusy = false
  let learnStarting = true
  let learningActive = false

  function setLearnState(state, reason) {
    learnBusy = state === 'busy'
    learnBtn.dataset.state = state
    learnBtn.disabled = learnBusy
    if (state === 'busy') {
      learnBtn.textContent = learnStarting ? '开始中…' : '结束中…'
      learnBtn.title = '进行中：请稍候，不要重复点击'
      return
    }
    if (state === 'idle') {
      learnBtn.textContent = learningActive ? '结束学习' : '开始学习'
      learnBtn.title = ''
      return
    }
    if (state === 'success') {
      learnBtn.textContent = learningActive ? '结束学习' : '开始学习'
      learnBtn.title = ''
      return
    }
    // failure：按钮保持可点（下一步动作），标题带原因；通知条给完整原因+下一步
    learnBtn.textContent = learningActive ? '结束学习' : '开始学习'
    learnBtn.title = reason || '操作失败'
  }

  // ------------------------------------------------------------------
  // D3：易变内容冻结（截图基线可比：状态条/通知条打桩，轮询暂停）
  // ------------------------------------------------------------------
  let frozen = false
  function freezeVolatile() {
    frozen = true
    document.body.classList.add('ro-frozen')
    statusStrip.textContent = ''
    statusStrip.appendChild(el('span', 's5-chip s5-strong', '● 本地感知中'))
    statusStrip.appendChild(el('span', 's5-chip', '状态：learning'))
    statusStrip.appendChild(el('span', 's5-chip', '同意：session'))
    statusStrip.appendChild(el('span', 's5-chip', '今日学习 N 分钟'))
    statusStrip.appendChild(el('span', 's5-chip', '原图剩余 N 分钟'))
    noticeBar.style.display = 'none'
    return true
  }
  function unfreezeVolatile() {
    frozen = false
    document.body.classList.remove('ro-frozen')
    sendCmd('ui', 'status')
    return true
  }
  askScreenBtn.addEventListener('click', () => sendCmd('ui', 'help'))
  draftBtn.addEventListener('click', () => sendCmd('ui', 'newdraft'))
  trajBtn.addEventListener('click', () => go('trajectory'))
  sitesBtn.addEventListener('click', () => sendCmd('ui', 'sites'))
  backBtn.addEventListener('click', () => go('home'))
  chatBtn.addEventListener('click', () => go('chat'))
  const pubBtn = el('button', 'ro-btn s5-back', '发布')
  pubBtn.type = 'button'
  pubBtn.title = '结论发布（证据闸）'
  pubBtn.addEventListener('click', () => go('publish'))
  topbar.appendChild(pubBtn)

  helpBtn.addEventListener('click', () => {
    hideAsk()
    sendCmd('ui', 'help')
  })
  noBtn.addEventListener('click', () => {
    hideAsk()
    sendCmd('ui', 'reject')
  })

  function sendCmd(name, args) {
    send('ui', { type: 'plugin:command', name, args })
  }

  // ------------------------------------------------------------------
  // 页面切换（含对话二级页的 shell 元素显隐 + 页面记忆）
  // ------------------------------------------------------------------
  function go(next) {
    if (!PAGES.includes(next)) next = 'home'
    page = next
    clearFailureNotice()
    try { localStorage.setItem(PAGE_KEY, page) } catch { /* noop */ }
    render()
  }

  function render() {
    const onChat = page === 'chat'
    homePage.classList.toggle('s5-on', page === 'home')
    trajPage.classList.toggle('s5-on', page === 'trajectory')
    notesPage.classList.toggle('s5-on', page === 'notes')
    publishPage.classList.toggle('s5-on', page === 'publish')
    // 对话页 = shell 自己的元素（二级页）
    for (const n of chatEls) {
      try { n.style.display = onChat ? '' : 'none' } catch { /* noop */ }
    }
    // 首页自己收起来时，顶栏只留面包屑（对话页由底座自己管）
    topbar.style.display = onChat ? 'flex' : 'flex'
    crumb.textContent = { home: '首页', chat: '对话', trajectory: '轨迹', notes: '笔记', publish: '发布' }[page] || '首页'
    backBtn.style.visibility = page === 'home' ? 'hidden' : 'visible'
    if (page === 'trajectory') sendCmd('timeline', '')
    if (page === 'notes') sendCmd('ui', 'drafts')
    if (page === 'home') sendCmd('ui', 'status')
    if (page === 'publish') { sendCmd('claim', 'claims'); sendCmd('timeline', '') }
    if (onChat && scrollToEnd) scrollToEnd()
  }

  // ------------------------------------------------------------------
  // 首页渲染（状态条 / 待处理区）
  // ------------------------------------------------------------------
  function renderStatus(d) {
    statusData = d
    if (d && d.learning) learningActive = !!d.learning.active
    if (frozen) return // D3：冻结期保持打桩值，任何 status 下行都不覆盖
    statusStrip.textContent = ''
    if (!d) {
      statusStrip.appendChild(el('span', 's5-chip', '状态加载中…'))
      return
    }
    const p = d.perception || {}
    const live = p.running === true
    statusStrip.appendChild(el('span', 's5-chip' + (live ? ' s5-strong' : ''), live ? '● 本地感知中' : '○ 已暂停'))
    if (p.state) statusStrip.appendChild(el('span', 's5-chip', `状态：${p.state}`))
    if (p.mode) statusStrip.appendChild(el('span', 's5-chip', `同意：${p.mode}`))
    if (d.learning && d.learning.active) {
      statusStrip.appendChild(el('span', 's5-chip s5-strong', '学习中'))
    }
    statusStrip.appendChild(el('span', 's5-chip', `今日学习 ${fmtDur(Math.round((d.learning ? d.learning.todayMs : 0) / 1000))}`))
    if (d.frameRemainingMs != null && d.frameRemainingMs > 0) {
      statusStrip.appendChild(el('span', 's5-chip', `原图剩余 ${Math.max(1, Math.round(d.frameRemainingMs / 60000))} 分钟`))
    }
    if (d.storeReady === false) statusStrip.appendChild(el('span', 's5-chip', '生命周期库未接入'))
    // 待处理区
    pending.textContent = ''
    pending.appendChild(el('div', 's5-sec', '待处理'))
    const drafts = d.drafts || []
    const cooldown = d.cooldown || {}
    const rows = [
      { label: '草稿待确认', value: drafts.length ? `${drafts.length} 个` : '无', act: () => go('notes') },
      { label: '主动建议', value: cooldown.cooling ? `冷却中（剩余 ${cooldown.remainingHours} 小时）` : '可按需询问', act: () => sendCmd('ui', 'ask') },
    ]
    for (const r of rows) {
      const row = el('div', 's5-row')
      row.appendChild(el('span', 's5-grow', r.label))
      row.appendChild(el('span', 's5-sub', r.value))
      row.addEventListener('click', r.act)
      pending.appendChild(row)
    }
    learnBtn.textContent = d.learning && d.learning.active ? '结束学习' : '开始学习'
    learningActive = !!(d.learning && d.learning.active)
    // D4：failure 是粘滞态（保留原因标题），不被轮询重置；busy 时任何刷新都不碰按钮
    if (!learnBusy && learnBtn.dataset.state !== 'failure') { learnBtn.dataset.state = 'idle'; learnBtn.disabled = false; learnBtn.title = '' }
  }

  // ------------------------------------------------------------------
  // 12 态调试渲染（/ui state <name>；window.__s5.setState 同效）
  // ------------------------------------------------------------------
  function setState(name) {
    if (!STATES.includes(name)) return false
    uiState = name
    go('home')
    statusStrip.textContent = ''
    const map = {
      'default': ['● 待机', '默认态：未开始感知。'],
      'monitoring': ['● 本地感知中', '监控中：1Hz 廉价信号采集中。'],
      'paused': ['○ 已暂停', '已暂停采集（同意保持）。'],
      'no-consent': ['⚠ 未同意', '未同意：需授予 session 同意才能抓屏。'],
      'learning-candidate': ['◇ 学习候选', '停留接近阈值，候选学习片段。'],
      'learning': ['◆ 学习中', 'learning 态：1Hz + 差分抑制截图。'],
      'silent': ['− 静默', '静默：不提示、不打扰。'],
      'needs-confirm': ['? 需确认', '需确认：有待你决定的草稿或授权。'],
      'success': ['✓ 成功', '成功：操作完成（草稿已晋升/学习已落账）。'],
      'failure': ['✗ 失败', '失败：原因见下，按下一步操作重试。'],
      'offline': ['☂ 离线', '离线：出网被拒，白名单外不可用。'],
      'deleted': ['⌫ 已删除', '已删除：原图按保留策略清理，仅剩摘要与哈希。'],
    }
    const [chip, desc] = map[name] || map['default']
    statusStrip.appendChild(el('span', 's5-chip s5-strong', chip))
    homeBody.textContent = ''
    homeBody.appendChild(el('div', 's5-note', `【调试态 ${name}】${desc}`))
    if (name === 'deleted') {
      homeBody.appendChild(el('div', 's5-note', '原图已按保留策略删除；保留时间、窗口、摘要与内容哈希，无法恢复画面。'))
    }
    return true
  }

  // ------------------------------------------------------------------
  // 主动询问卡
  // ------------------------------------------------------------------
  function showAsk(d) {
    hideAsk()
    if (!d || d.phase !== 'asking') return
    askReason.textContent = `为什么现在提示：${d.reason || '（未给出）'}`
    askEvidence.textContent = `用了哪些证据：evidence_id=${d.evidenceId || '（无）'}`
    askCard.style.display = ''
    if (R.setOrbExpression) R.setOrbExpression('need-help') // 球面表情：请求帮助
  }
  function hideAsk() {
    askCard.style.display = 'none'
    if (R.setOrbExpression) R.setOrbExpression('clear') // 询问卡收起 → 清除粘滞表情
  }
  // 首页可见通知条（addNotice 只进对话页的 transcript；首页必须也能看见）
  const noticeBar = el('div', 's5-note')
  noticeBar.id = 's5-notice'
  noticeBar.style.display = 'none'
  noticeBar.setAttribute('role', 'status')
  homePage.appendChild(noticeBar)
  let noticeTimer = null

  function showAskNotice(text) {
    hideAsk()
    clearFailureNotice()
    if (addNotice) addNotice('info', text)
    // 首页可见条（6s 自动收起）
    noticeBar.textContent = text
    noticeBar.style.display = ''
    noticeBar.className = 's5-note'
    if (noticeTimer) clearTimeout(noticeTimer)
    noticeTimer = setTimeout(() => { noticeBar.style.display = 'none' }, 6000)
  }

  /** D4 失败态：原因 + 下一步动作。**粘滞**（不自动消失）——失败信息不得让用户错过；
   *  直到下一次用户动作（切页/点任何主动作/新通知）才清除。 */
  function showFailure(text) {
    hideAsk()
    if (addNotice) addNotice('error', text)
    noticeBar.textContent = '⚠ ' + text
    noticeBar.style.display = ''
    noticeBar.className = 's5-note s5-failure'
    noticeBar.dataset.failure = '1'
    if (noticeTimer) { clearTimeout(noticeTimer); noticeTimer = null }
    if (R.setOrbExpression) R.setOrbExpression('error') // 球面表情：出错（粘滞）
  }

  /** 清除粘滞失败通知（用户动作/切页时）。 */
  function clearFailureNotice() {
    if (noticeBar.dataset.failure === '1') {
      noticeBar.dataset.failure = ''
      noticeBar.className = 's5-note'
      noticeBar.style.display = 'none'
      if (R.setOrbExpression) R.setOrbExpression('clear') // 失败表情随用户动作清除
    }
  }

  // ------------------------------------------------------------------
  // 轨迹页（日→片段→事件 三级）
  // ------------------------------------------------------------------
  function renderTrajectory(d) {
    trajBody.textContent = ''
    if (!d || !d.segments || d.segments.length === 0) {
      trajBody.appendChild(el('div', 's5-note', d && d.degraded ? '今天还没有片段（生命周期库未接入，证据状态无法对账）。' : '今天还没有片段。'))
      return
    }
    trajBody.appendChild(el('div', 's5-sec', `轨迹（${d.day}）`))
    for (const s of d.segments) {
      const wrap = el('div', '')
      const row = el('div', 's5-row')
      const t = s.startedAt ? new Date(s.startedAt).toTimeString().slice(0, 5) : '--:--'
      const outcome = { promoted: '已晋升', discarded: '已丢弃', rejected: '已婉拒', stopped: '已结束', pending: '进行中/草稿' }[s.outcome] || s.outcome
      row.appendChild(el('span', 's5-grow', `${t} [${outcome}] ${fmtDur(Math.round((s.durationMs || 0) / 1000))}`))
      row.appendChild(el('span', 's5-sub', `置信度=${s.confidence ?? '-'} 证据=${s.evidenceCount}`))
      const expanded = { done: false }
      row.addEventListener('click', () => {
        expanded.done = !expanded.done
        det.style.display = expanded.done ? '' : 'none'
      })
      wrap.appendChild(row)
      const det = el('div', 's5-evidence')
      det.style.display = 'none'
      det.appendChild(el('div', '', `片段 ${s.id} · 状态=${s.state} · 事件=${s.eventCount != null ? s.eventCount : 0} 条`))
      if (s.notePath) det.appendChild(el('div', '', `正式笔记：${s.notePath.split('\\').pop()}`))
      for (const e of s.evidence || []) {
        const line = el('div', '', `${e.evidence_id} — ${e.status === 'deleted' ? '⚠ ' : e.status === 'available' ? '🖼 ' : '· '}${e.label}`)
        det.appendChild(line)
      }
      for (const ev of (s.events || []).slice(0, 8)) {
        det.appendChild(el('div', '', `· 事件 ${ev.type || '-'}${ev.title ? '（' + ev.title + '）' : ''}`))
      }
      wrap.appendChild(det)
      trajBody.appendChild(wrap)
    }
  }

  // ------------------------------------------------------------------
  // 发布页（S7：结论发布面板）+ 统一证据标签（D9）
  // ------------------------------------------------------------------

  /** 统一证据标签（D9）：direct/derived/none 同一套视觉与文案；none 一律降级。 */
  function evBadge(relation, mode) {
    if (relation === 'none' || mode === 'none') {
      const b = el('span', 's5-badge s5-none', '⚠ 无直接证据（不得作为事实）')
      b.title = 'CONTRACT §6：none 证据不得用事实语气、不得晋升长期记忆、不得触发自动工具'
      return b
    }
    return el('span', 's5-badge', relation === 'derived' ? '派生证据' : '直接证据')
  }

  function renderPublishNew() {
    pubNew.textContent = ''
    pubNew.appendChild(el('div', 's5-sec', '新建结论（从轨迹片段 / 笔记 / 自由文本）'))
    const segBtn = el('button', 'ro-btn s5-act', '从轨迹片段建')
    segBtn.type = 'button'
    segBtn.addEventListener('click', () => {
      pubLists.textContent = ''
      pubLists.appendChild(el('div', 's5-sec', '选一个今天的片段建结论（证据=该片段的原图）'))
      if (!pubSegments.length) pubLists.appendChild(el('div', 's5-note', '今天还没有片段（先跑一次学习主线）。'))
      for (const s of pubSegments.slice(-8).reverse()) {
        const row = el('div', 's5-row')
        row.appendChild(el('span', 's5-grow', `${s.id} · ${fmtDur(Math.round((s.durationMs || 0) / 1000))} · 证据${s.evidenceCount}`))
        row.appendChild(el('span', 's5-sub', s.outcome || ''))
        row.addEventListener('click', () => sendCmd('claim', 'new seg ' + s.id))
        pubLists.appendChild(row)
      }
    })
    const noteBtn = el('button', 'ro-btn s5-act', '从笔记建')
    noteBtn.type = 'button'
    noteBtn.addEventListener('click', () => {
      pubLists.textContent = ''
      pubLists.appendChild(el('div', 's5-sec', '从笔记建结论（笔记无证据链 → 无直接证据，不可发布）'))
      const row = el('div', 's5-row')
      row.appendChild(el('span', 's5-grow', 'data/notes/（正式笔记）'))
      row.addEventListener('click', () => sendCmd('claim', 'new note notes-root'))
      pubLists.appendChild(row)
    })
    const textBtn = el('button', 'ro-btn s5-act', '自由文本')
    textBtn.type = 'button'
    textBtn.addEventListener('click', () => {
      pubLists.textContent = ''
      const ta = doc.createElement('textarea')
      ta.className = 's5-input'
      ta.rows = 3
      ta.placeholder = '输入结论文本（无证据链 → 无直接证据，不可发布）'
      const ok = el('button', 'ro-btn', '建成草稿')
      ok.type = 'button'
      ok.style.minHeight = '40px'
      ok.addEventListener('click', () => { if (ta.value.trim()) sendCmd('claim', 'new text ' + ta.value.trim()) })
      pubLists.appendChild(ta)
      pubLists.appendChild(ok)
    })
    pubNew.appendChild(segBtn)
    pubNew.appendChild(noteBtn)
    pubNew.appendChild(textBtn)
  }

  function renderClaims(d) {
    pubClaims = (d && d.claims) || []
    renderPublishNew()
    pubLists.textContent = ''
    pubLists.appendChild(el('div', 's5-sec', `结论（${pubClaims.length}）`))
    if (!pubClaims.length) pubLists.appendChild(el('div', 's5-note', '还没有结论。用上面的入口从轨迹片段建一条（带原图证据）。'))
    for (const c of pubClaims) {
      const wrap = el('div', '')
      const row = el('div', 's5-row')
      row.appendChild(el('span', 's5-grow', `${c.id} [${c.status}] ${String(c.text || '').slice(0, 24)}`))
      row.appendChild(evBadge(c.evidenceMode === 'none' ? 'none' : 'direct', c.evidenceMode))
      row.appendChild(el('span', 's5-sub', `证据${c.publishableEvidence}`))
      row.addEventListener('click', () => sendCmd('claim', c.id))
      wrap.appendChild(row)
      pubLists.appendChild(wrap)
    }
  }

  function renderClaimDetail(d) {
    pubDetail = d
    renderPublishNew()
    pubLists.textContent = ''
    pubLists.appendChild(el('div', 's5-sec', `结论 ${d.claimId} [${d.status}]`))
    // 措辞编辑（仅草稿；已发布不可改——保持发布时快照）
    if (d.status === 'draft') {
      const ta = doc.createElement('textarea')
      ta.className = 's5-input'
      ta.rows = 3
      ta.value = d.text || ''
      ta.setAttribute('aria-label', '结论措辞')
      const save = el('button', 'ro-btn', '保存措辞')
      save.type = 'button'
      save.style.minHeight = '32px'
      save.addEventListener('click', () => { if (ta.value.trim()) sendCmd('claim', d.claimId + ' text ' + ta.value.trim()) })
      pubLists.appendChild(ta)
      pubLists.appendChild(save)
    } else {
      pubLists.appendChild(el('div', 's5-note', `已发布（${d.publishedAt || ''}），措辞锁定为发布时快照。`))
      // 镜 4：导出（md + docx；文件落在 data/exports/，验收可核内容）
      const exportBtn = el('button', 'ro-btn s5-act', '导出结论（md+docx）')
      exportBtn.type = 'button'
      exportBtn.title = '导出结论正文 + evidence_id 清单 + 每条证据当前可用性 + 导出时间与版本'
      exportBtn.addEventListener('click', () => sendCmd('claim', 'export ' + d.claimId))
      pubLists.appendChild(exportBtn)
    }
    // 证据清单（evidence_id + 类型 + 当前可用性）
    pubLists.appendChild(el('div', 's5-sec', `证据 ${d.evidence.length} 条（可发布 ${d.publishableEvidence}）`))
    for (const e of d.evidence) {
      const row = el('div', 's5-row')
      row.style.cursor = 'default'
      row.appendChild(el('span', 's5-grow', `${e.evidence_id}`))
      row.appendChild(evBadge(e.relation, d.evidenceMode))
      const st = el('span', 's5-sub', e.label)
      if (e.status === 'deleted') st.className = 's5-sub s5-deleted'
      row.appendChild(st)
      pubLists.appendChild(row)
    }
    // 补证据（镜 4：缺证据 → 补 → 发布）；已发布结论不可改
    if (d.status === 'draft') {
      const attachBox = el('div', 's5-actions')
      const attachFrame = el('button', 'ro-btn s5-act', '关联今日原图')
      attachFrame.type = 'button'
      attachFrame.title = '把今天采集到的一帧原图挂为直接证据'
      attachFrame.addEventListener('click', () => sendCmd('claim', 'attach ' + d.claimId + ' frame'))
      const attachSeg = el('button', 'ro-btn s5-act', '关联今日片段')
      attachSeg.type = 'button'
      attachSeg.title = '把今天最近一个学习片段的原图挂为直接证据'
      attachSeg.addEventListener('click', () => sendCmd('claim', 'attach ' + d.claimId + ' latest-seg'))
      attachBox.appendChild(attachFrame)
      attachBox.appendChild(attachSeg)
      pubLists.appendChild(attachBox)
    }
    // 发布区
    if (d.status === 'draft') {
      if (d.canPublish) {
        const pub = el('button', 'ro-btn s5-act s5-wide', '发布')
        pub.type = 'button'
        pub.addEventListener('click', () => sendCmd('claim', 'publish ' + d.claimId))
        pubLists.appendChild(pub)
      } else {
        const why = d.evidenceMode === 'none'
          ? '不可发布：该结论无直接证据（evidence_mode=none）。契约 §6 禁止以事实语气发布——请补直接/派生证据，或改成假设语气另存为草稿。'
          : `不可发布：缺可回指证据（非 none 证据 ${d.publishableEvidence} 条）。请先从轨迹片段/原图关联证据。`
        pubLists.appendChild(el('div', 's5-note s5-none', '⚠ ' + why))
      }
    }
  }

  // ------------------------------------------------------------------
  // 笔记页（草稿 + 晋升/丢弃）
  // ------------------------------------------------------------------
  function renderNotes(d) {
    notesBody.textContent = ''
    notesBody.appendChild(el('div', 's5-sec', '草稿（data/drafts，与正式笔记物理隔离）'))
    const drafts = (d && d.drafts) || []
    if (drafts.length === 0) {
      notesBody.appendChild(el('div', 's5-note', '没有待确认草稿。'))
    }
    for (const name of drafts) {
      const row = el('div', 's5-row')
      row.appendChild(el('span', 's5-grow', name))
      const promoteBtn = el('button', 'ro-btn', '晋升')
      promoteBtn.type = 'button'
      promoteBtn.style.minHeight = '32px'
      const discardBtn = el('button', 'ro-btn', '丢弃')
      discardBtn.type = 'button'
      discardBtn.style.minHeight = '32px'
      promoteBtn.addEventListener('click', (ev) => { ev.stopPropagation(); sendCmd('ui', 'promote ' + name) })
      discardBtn.addEventListener('click', (ev) => { ev.stopPropagation(); sendCmd('ui', 'discard ' + name) })
      row.appendChild(promoteBtn)
      row.appendChild(discardBtn)
      notesBody.appendChild(row)
    }
  }

  // ------------------------------------------------------------------
  // 下行：plugin:panel（timeline 插件的所有 ui payload 都走这条）
  // ------------------------------------------------------------------
  R.onPanel('timeline', (message) => {
    const ui = message && message.ui
    if (!ui) return
    if (ui.kind === 'status') renderStatus(ui)
    else if (ui.kind === 'state') setState(ui.state)
    else if (ui.kind === 'ask') {
      if (ui.phase === 'asking') showAsk(ui)
      else if (ui.phase === 'rejected') showAskNotice('已减少此类提醒（24 小时内不再询问）。')
      else if (ui.phase === 'cooling') showAskNotice(`冷却中（剩余 ${ui.remainingHours} 小时）：不再询问。`)
      else if (ui.phase === 'helped') {
        showAskNotice(`已抓一帧并生成草稿（evidence_id=${ui.evidenceId}），去「笔记」页确认晋升或丢弃。`)
        go('notes')
      }
    } else if (ui.kind === 'timeline') {
      pubSegments = (ui.segments || []).slice()
      if (page === 'publish') renderPublishNew()
      else { renderTrajectory(ui); go('trajectory') }
    }
    else if (ui.kind === 'drafts') { renderNotes(ui) }
    else if (ui.kind === 'claims') { renderClaims(ui) }
    else if (ui.kind === 'claim-detail') { renderClaimDetail(ui) }
    else if (ui.kind === 'claim') {
      if (ui.phase === 'created') {
        showAskNotice(`已建草稿 ${ui.claimId}（${ui.evidenceMode === 'none' ? '无直接证据' : ui.evidenceMode === 'derived' ? '派生证据' : '直接证据'} ${ui.evidenceCount} 条）。`)
        go('publish')
        // 只渲染详情（claim-detail）；不要再发 'claims'——它会与详情竞争 pubLists 且列表后到会覆盖详情，
        // 导致"证据不足不许发布"的 blocked 说明被冲掉（S10-C2）。列表在下次进入发布页时自然刷新。
        sendCmd('claim', ui.claimId)
      } else if (ui.phase === 'attached') {
        showAskNotice(ui.attached > 0 ? `已关联 ${ui.attached} 条证据，去发布。` : '这些证据都已关联过。')
        sendCmd('claim', ui.claimId)
      } else if (ui.phase === 'exported') {
        showAskNotice(`已导出：${(ui.md || '').split('\\').pop()}${ui.docx ? ' + ' + ui.docx.split('\\').pop() : ''}（data/exports/）`)
        sendCmd('claim', ui.claimId)
      } else if (ui.phase === 'blocked') {
        if (pubDetail) renderClaimDetail({ ...pubDetail, canPublish: false })
        showAskNotice(ui.reason || '发布被拒')
      } else if (ui.phase === 'published') {
        showAskNotice(`已发布：${ui.claimId}（证据 ${ui.evidenceCount} 条）。`)
        sendCmd('claim', ui.claimId)
        sendCmd('claim', 'claims')
      }
    }
    else if (ui.kind === 'learn') {
      if (ui.phase === 'started') {
        learningActive = true
        setLearnState('success')
        showAskNotice('已开始学习：计时开始（/today 可查）。')
      }
      if (ui.phase === 'stopped') {
        learningActive = false
        setLearnState('success')
        // fmtDur 入参是**秒**（ui-bridge 契约）；durationMs 是毫秒 → 先换算
        showAskNotice(`已结束学习：${fmtDur(Math.round((ui.durationMs || 0) / 1000))} 已落账（/today 可查）。`)
      }
      if (ui.phase === 'need-consent') {
        learningActive = false
        setLearnState('failure', '需要重新授权：consent 非有效 session')
        showFailure('需要重新授权：当前 consent 不是有效 session（已被撤销或过期）。下一步：重新授予 session 同意，再点「开始学习」。')
      }
      if (ui.phase === 'already' || ui.phase === 'idle') setLearnState('idle')
      sendCmd('ui', 'status')
    } else if (ui.kind === 'page') { go(ui.page || 'home') }
    else if (ui.kind === 'sites') {
      homeBody.textContent = ''
      homeBody.appendChild(el('div', 's5-sec', '最近网站'))
      if (!ui.sites || ui.sites.length === 0) homeBody.appendChild(el('div', 's5-note', '暂无记录。'))
      for (const s of ui.sites || []) {
        const row = el('div', 's5-row')
        row.appendChild(el('span', '', `${s.host}（${s.count} 篇）`))
        homeBody.appendChild(row)
      }
    }
  })

  // 展开/收起不重载渲染进程 → 页面变量天然保持；这里只做状态刷新（10s 轻轮询；冻结期暂停）
  setInterval(() => { if (page === 'home' && !frozen) sendCmd('ui', 'status') }, 10_000)

  // 输入框一聚焦即视为进入对话页（对话是二级页：从首页进入）
  const promptEl = doc.getElementById('prompt')
  if (promptEl) {
    promptEl.addEventListener('focus', () => { if (page === 'home') go('chat') })
  }

  // Esc：二级页 → 回首页（与底座 Esc 语义衔接：先问领域钩子）
  R.onEscape(() => {
    if (page !== 'home') { go('home'); return true }
    return false
  })

  // ------------------------------------------------------------------
  // 调试入口（验收工具经 CDP 调用）
  // ------------------------------------------------------------------
  window.__s5 = {
    page: go,
    currentPage: () => page,
    setState: (name) => setState(name),
    refresh: () => sendCmd('ui', 'status'),
    states: () => STATES.slice(),
    freeze: freezeVolatile,
    unfreeze: unfreezeVolatile,
    isFrozen: () => frozen,
    learnState: () => ({ state: learnBtn.dataset.state || 'idle', text: learnBtn.textContent, disabled: learnBtn.disabled, busy: learnBusy }),
  }

  // 首屏：按记忆的页面渲染
  render()
  if (page === 'home') sendCmd('ui', 'status')
})(window.__ro)
