// packages/packs/research/ui/literature.js
//
// 科研 · 文献面板 + 卡片编辑弹层（P-R2 阶段 2 起；P-R6 抽离出 shell）。
//
// 【架构纪律 · P-R6】本文件是**领域渲染层**：由 shell（apps/desktop/ui-bridge.mjs）
// 在注入 bridge 之后、由主进程按 pack.json 的 "ui" 清单读取并 executeJavaScript 注入。
// 因此这里同样不写 import / export（会被 executeJavaScript 拒绝），只通过
// window.__ro（shell 暴露的工具箱）取用底座能力。
//
// 工具箱（window.__ro）提供：
//   doc/panel/ball/el/send/addNotice/setStatus/state/transcript/historyList/
//   toggleSettings/fmtClock/fmtDur/VERSION/PATHS/api/scrollToEnd
//   ballRing/ballBadge/ballRingFg/RING_C（球的角标/圆环槽位，由 pack 填充语义）
//   onPanel(pluginId, fn) / onPanelFallback(fn) / onMsg(type, fn) / onSettings(fn)
//   cardActions(fn) / closePanels(fn) / statusExtras(fn) / appendWelcome(lines)
//
// 纪律：领域 UI 只渲染 + 上行命令，不读写文件、不出网 —— 与 shell 的通道纪律一致。

;(function (R) {
  'use strict'
  const {
    doc, panel, ball, el, send, addNotice, state, transcript, historyList,
    toggleSettings, fmtClock, fmtDur, VERSION, PATHS, api,
    ballRing, ballBadge, ballRingFg, RING_C, scrollToEnd,
  } = R

  // --- 5b. 自建 DOM：文献面板 + 卡片编辑弹层（阶段 2）---
  const lit = doc.createElement('div')
  lit.id = 'ro-lit'
  lit.setAttribute('role', 'dialog')
  lit.setAttribute('aria-label', '文献')
  lit.hidden = false
  if (panel) panel.appendChild(lit)

  // 镜 2：行内 DOI 可信标记样式（vendor CSS 冻结，徽章样式由 pack 自建；对比度随主题 token）
  if (R.addStyle) {
    R.addStyle(`
      .ro-cand-trust { display:inline-block; font-size:12px; margin-left:8px; padding:0 6px; border:1px solid var(--border); border-radius:8px; color:var(--black); }
      .ro-trust-dual { border-style: solid; }
      .ro-trust-single { border-style: dashed; }
      .ro-trust-none { border-style: dotted; font-weight: bold; }
      .ro-trust-no-doi { border-style: none; }
    `)
  }

  const litBody = el('div', 'ro-lit-list')
  const litSearchInput = doc.createElement('input')
  litSearchInput.className = 'ro-idxinput'
  litSearchInput.type = 'text'
  litSearchInput.placeholder = '对已归档卡片做混合检索…'
  const litSearchBtn = el('button', 'ro-btn', '检索')
  litSearchBtn.type = 'button'
  const litCloseBtn = el('button', 'ro-settings-close', '关闭')
  litCloseBtn.type = 'button'
  const litHead = el('div', 'ro-lit-head')
  litHead.appendChild(el('h3', 'ro-lit-title', '文献'))
  litHead.appendChild(litCloseBtn)
  const litSearchRow = el('div', 'ro-lit-controls')
  litSearchRow.appendChild(litSearchInput)
  litSearchRow.appendChild(litSearchBtn)
  lit.appendChild(litHead)
  lit.appendChild(litSearchRow)
  lit.appendChild(litBody)

  const editor = doc.createElement('div')
  editor.id = 'ro-editor'
  editor.setAttribute('role', 'dialog')
  editor.setAttribute('aria-label', '编辑卡片')
  if (panel) panel.appendChild(editor)


  // --- 10b. 渲染：文献面板（阶段 2）---
  //
  // 面板只是**渲染器**：候选列表、卡片内容、bib 自检结果、问答出处全都来自
  // 插件命令返回的 ui payload。面板自己不检索、不读文件、不写文件 ——
  // 它把用户的选择拼成一条 /card 或 /card.update 参数，交回主进程执行。
  //
  // 这样做的理由很实际：面板一旦能直接读写文件，就会出现"绕过 schema 校验改卡片"
  // 和"绕过 net 白名单出网"两条暗路。把动作全部收回命令层，这两条路就不存在。
  function toggleLit(next) {
    const open = next === undefined ? !state.litOpen : !!next
    state.litOpen = open
    lit.classList.toggle('ro-open', open)
    if (open) {
      if (transcript) transcript.hidden = true
      if (historyList) historyList.hidden = true
      if (state.settingsOpen) toggleSettings(false)
    } else if (transcript && historyList) {
      transcript.hidden = !historyList.hidden
    }
  }


  function sourceLine(sources) {
    return (sources || [])
      .map((s) => {
        if (s.skipped) return s.source + ' 跳过(' + s.reason + ')'
        if (!s.ok) return s.source + ' 失败(' + ((s.error && s.error.code) || '?') + ')'
        return s.source + ' ' + s.entries + ' 条' + (s.usedFallback ? '(无分类回退)' : '')
      })
      .join(' · ')
  }

  function renderLiterature(payload) {
    if (!payload || !payload.ui) return
    const ui = payload.ui
    state.literature = ui
    toggleLit(true)
    litBody.textContent = ''
    if (ui.kind === 'candidates') return renderCandidates(ui)
    if (ui.kind === 'bib') return renderBib(ui)
    if (ui.kind === 'recall') return renderRecall(ui)
    if (ui.kind === 'cards-batch') return renderBatch(ui)
    if (ui.kind === 'card') return renderCardResult(ui)
    litBody.appendChild(el('p', 'ro-note', ui.message || payload.code || '（无可显示内容）'))
  }

  function renderCandidates(ui) {
    const info = el('div', 'ro-group')
    info.appendChild(el('h4', 'ro-group-title', '候选 ' + ui.candidates.length + ' 条（按 venue + 年份 + 引用数打分）'))
    info.appendChild(el('p', 'ro-note', '检索式：' + ui.query + (ui.clusterName ? '（主题簇：' + ui.clusterName + '）' : '')))
    info.appendChild(el('p', 'ro-note', '源状态：' + sourceLine(ui.sources)))
    info.appendChild(
      el('p', 'ro-note', '去重：原始 ' + ui.stats.raw + ' → ' + ui.stats.deduped + ' 条（合并 ' + ui.stats.duplicates + ' 条跨源重复）'),
    )
    litBody.appendChild(info)

    const controls = el('div', 'ro-lit-controls')
    const selAll = el('button', 'ro-btn', '全选')
    selAll.type = 'button'
    selAll.addEventListener('click', () => {
      for (const cb of litBody.querySelectorAll('input[data-idx]')) cb.checked = true
    })
    const selNone = el('button', 'ro-btn', '清空')
    selNone.type = 'button'
    selNone.addEventListener('click', () => {
      for (const cb of litBody.querySelectorAll('input[data-idx]')) cb.checked = false
    })
    const topicInput = doc.createElement('input')
    topicInput.className = 'ro-idxinput'
    topicInput.placeholder = '归档主题目录（默认 inbox）'
    topicInput.value = state.topic || 'inbox'
    controls.appendChild(selAll)
    controls.appendChild(selNone)
    controls.appendChild(topicInput)
    litBody.appendChild(controls)

    const list = el('div', 'ro-lit-list')
    ui.candidates.forEach((c, i) => {
      const row = el('label', 'ro-cand')
      const cb = doc.createElement('input')
      cb.type = 'checkbox'
      cb.dataset.idx = String(i + 1)
      row.appendChild(cb)
      const main = el('div', 'ro-cand-main')
      main.appendChild(el('div', 'ro-cand-title', i + 1 + '. ' + (c.title || '(无标题)')))
      main.appendChild(
        el(
          'div',
          'ro-cand-meta',
          [c.authors, c.venue, c.year, c.citations === null || c.citations === undefined ? '引用未知' : c.citations + ' 引用', (c.sources || []).join('/'), c.doi]
            .filter(Boolean)
            .join(' · '),
        ),
      )
      // 镜 2：行内 DOI 可信标记（判定源=引用校验同一套 connectors；标签由插件下发）
      if (c.doiTrust) {
        const badge = el('span', 'ro-cand-trust ro-trust-' + (c.doiTrust.status || 'unverifiable'), c.doiTrust.label || '? 校验未完成')
        badge.title = c.doiTrust.doi
          ? `DOI ${c.doiTrust.doi}：${(c.doiTrust.sources || []).map((s) => `${s.source}=${s.ok ? '收录' : '未收录'}`).join('，') || '判定明细不可用'}（校验于 ${c.doiTrust.checkedAt || '?'}）`
          : '该条无 DOI，无法做双源校验'
        main.appendChild(badge)
      }
      if (c.abstract) main.appendChild(el('div', 'ro-cand-meta', String(c.abstract).slice(0, 180)))
      row.appendChild(main)
      row.appendChild(el('span', 'ro-cand-score', c.score === null || c.score === undefined ? '-' : Number(c.score).toFixed(3)))
      list.appendChild(row)
    })
    litBody.appendChild(list)

    const gen = el('button', 'ro-btn', '生成选中卡片')
    gen.type = 'button'
    gen.addEventListener('click', () => {
      const picks = []
      for (const cb of litBody.querySelectorAll('input[data-idx]')) if (cb.checked) picks.push(cb.dataset.idx)
      if (picks.length === 0) {
        addNotice('warn', '请先勾选至少一条候选，再点「生成选中卡片」。')
        return
      }
      const topic = String(topicInput.value || '').trim() || 'inbox'
      state.topic = topic
      send('plugin:command', { name: 'card', args: '--find ' + picks.join(',') + ' --topic ' + topic })
    })
    litBody.appendChild(gen)
  }

  function renderBib(ui) {
    const g = el('div', 'ro-group')
    g.appendChild(el('h4', 'ro-group-title', '引用导出'))
    g.appendChild(el('p', 'ro-note', '文件：data/exports/' + ui.file + '（' + ui.count + ' 条 / ' + ui.bytes + ' 字节）'))
    const c = ui.check || {}
    g.appendChild(
      el('p', 'ro-note', 'citation-js 自检：' + (c.ok ? '通过' : '未通过') + ' —— 解析 ' + c.parsed + '/' + c.expected + ' 条，DOI 保留 ' + ((c.dois && c.dois.parsed.length) || 0) + '/' + ((c.dois && c.dois.expected.length) || 0)),
    )
    if (c.error) g.appendChild(el('p', 'ro-note', '说明：' + c.error))
    litBody.appendChild(g)
    if (ui.sample) {
      const pre = el('pre', 'ro-pre', ui.sample)
      litBody.appendChild(pre)
    }
  }

  function renderRecall(ui) {
    const g = el('div', 'ro-group')
    g.appendChild(el('h4', 'ro-group-title', '卡片问答（命中 ' + ui.hitCount + ' 张，检索模式 ' + ui.searchMode + '）'))
    if (ui.expansion) {
      g.appendChild(el('p', 'ro-note', '中文别名声明的英文检索式：' + ui.expansion.query + '（' + (ui.expansion.matched || []).join('、') + '）'))
    }
    litBody.appendChild(g)
    litBody.appendChild(el('pre', 'ro-pre', ui.answer || ''))
    if ((ui.citations || []).length > 0) {
      const cg = el('div', 'ro-group')
      cg.appendChild(el('h4', 'ro-group-title', '出处'))
      for (const c of ui.citations) {
        const row = el('div', 'ro-cite')
        row.appendChild(el('span', 'ro-cite-n', '[' + c.n + ']'))
        row.appendChild(el('span', null, (c.title || '') + ' · ' + (c.venue || '未标注') + (c.year ? ' ' + c.year : '') + ' · ' + (c.doi ? 'doi:' + c.doi : c.url || '无链接') + ' · 卡片 ' + (c.rel || '')))
        cg.appendChild(row)
      }
      litBody.appendChild(cg)
    }
  }

  function cardList(rows) {
    const list = el('div', 'ro-lit-list')
    for (const r of rows) {
      const row = el('div', 'ro-cand')
      const main = el('div', 'ro-cand-main')
      main.appendChild(el('div', 'ro-cand-title', r.title || r.rel || '(未命名)'))
      main.appendChild(el('p', 'ro-cand-meta', r.rel + ' · 字段来源：' + (r.generatedBy || '?')))
      row.appendChild(main)
      if (r.card && r.rel) {
        const edit = el('button', 'ro-btn', '编辑')
        edit.type = 'button'
        edit.addEventListener('click', () => openEditor(r.rel, r.card))
        row.appendChild(edit)
      } else if (r.code) {
        row.appendChild(el('span', 'ro-cand-score', r.code))
      }
      list.appendChild(row)
    }
    return list
  }

  function renderBatch(ui) {
    const g = el('div', 'ro-group')
    const okCount = (ui.results || []).filter((r) => r.ok).length
    g.appendChild(el('h4', 'ro-group-title', '批量生成（成功 ' + okCount + '/' + (ui.results || []).length + '）'))
    g.appendChild(el('p', 'ro-note', '来源检索：' + (ui.query || '—') + ' · 索引当前 ' + ui.indexCount + ' 条'))
    g.appendChild(el('p', 'ro-note', '点「编辑」可直接改字段；保存会经 schema 校验后写回同一张卡片。'))
    litBody.appendChild(g)
    litBody.appendChild(cardList(ui.results || []))
  }

  function renderCardResult(ui) {
    const g = el('div', 'ro-group')
    g.appendChild(el('h4', 'ro-group-title', ui.updated ? '卡片已更新' : '卡片已生成'))
    g.appendChild(el('p', 'ro-note', ui.rel + ' · 索引 ' + ui.indexCount + ' 条'))
    litBody.appendChild(g)
    litBody.appendChild(cardList([{ rel: ui.rel, card: ui.card, generatedBy: ui.generatedBy, title: ui.card && ui.card.title }]))
    if (ui.updated) closeEditor()
  }

  // 卡片编辑弹层：字段表从卡片自身的键顺序来（16 个），改完整体回传。
  const NUMERIC_FIELDS = ['year', '读数（0-5）']
  const ARRAY_FIELDS = ['authors', 'tags']

  function openEditor(rel, card) {
    if (!card) return
    // 插件返回的 rel 有时带 `data/notes/` 前缀、有时不带（单张卡片与批量结果两条路径不同来源）。
    // 在面板这一层统一剥掉，避免出现 "data/notes/data/notes/..." 这种把前缀拼两次的显示。
    const shown = String(rel || '').replace(/^data[\\/]notes[\\/]/i, '')
    state.editingRel = shown
    editor.textContent = ''
    const head = el('div', 'ro-lit-head')
    head.appendChild(el('h3', 'ro-lit-title', '编辑卡片'))
    const close = el('button', 'ro-settings-close', '取消')
    close.type = 'button'
    close.addEventListener('click', closeEditor)
    head.appendChild(close)
    editor.appendChild(head)
    editor.appendChild(el('p', 'ro-note', '文件：data/notes/' + shown + '（保存后 front-matter 会被重新校验，读数必须 0-5）'))

    const inputs = {}
    for (const key of Object.keys(card)) {
      const value = card[key]
      const row = el('div', 'ro-editor-row')
      row.appendChild(el('label', null, key))
      let input = null
      if (key === '问题' || key === '方法' || key === '数据与算例' || key === '结论与局限' || key === '可复用点' || key === '待验证点' || key === '与我课题的关系') {
        input = doc.createElement('textarea')
        input.rows = 3
      } else {
        input = doc.createElement('input')
        input.type = NUMERIC_FIELDS.indexOf(key) >= 0 ? 'number' : 'text'
      }
      if (ARRAY_FIELDS.indexOf(key) >= 0) input.value = (value || []).join(', ')
      else input.value = value === null || value === undefined ? '' : String(value)
      inputs[key] = input
      row.appendChild(input)
      editor.appendChild(row)
    }

    const actions = el('div', 'ro-editor-actions')
    const save = el('button', 'ro-btn', '保存')
    save.type = 'button'
    save.addEventListener('click', () => {
      const patch = {}
      for (const key of Object.keys(card)) {
        const raw = inputs[key].value
        if (ARRAY_FIELDS.indexOf(key) >= 0) {
          patch[key] = String(raw).split(',').map((s) => s.trim()).filter(Boolean)
        } else if (NUMERIC_FIELDS.indexOf(key) >= 0) {
          const t = String(raw).trim()
          patch[key] = t === '' ? null : Number(t)
        } else {
          patch[key] = String(raw)
        }
      }
      send('plugin:command', { name: 'card.update', args: JSON.stringify({ rel: shown, patch: patch }) })
    })
    const cancel = el('button', 'ro-btn', '取消')
    cancel.type = 'button'
    cancel.addEventListener('click', closeEditor)
    actions.appendChild(save)
    actions.appendChild(cancel)
    editor.appendChild(actions)
    editor.classList.add('ro-open')
  }

  function closeEditor() {
    state.editingRel = null
    editor.classList.remove('ro-open')
    editor.textContent = ''
  }


  // --- 注册：领域面板动作 / 关面板 / 欢迎语 ---
  R.cardActions((card, acts) => {
    if (card.id === 'research.literature') {
      const open = el('button', 'ro-btn', '打开文献面板')
      open.type = 'button'
      open.addEventListener('click', () => { toggleSettings(false); toggleLit(true) })
      acts.appendChild(open)
    }
  })
  R.claimRoot(lit)
  R.claimRoot(editor)
  // P-R6.1 评审①：今日概览 · 文献卡（真实数据来自最近一次 /note --list 的 payload；
  // 没有数据时显示"未归档卡片"提示行，不造占位假数据）
  R.onOverview(() => {
    const ui = state.literature
    const rows = (ui && Array.isArray(ui.cards) ? ui.cards : []).slice(0, 3)
    return [{
      title: '今日概览 · 文献卡',
      rows: rows.length
        ? rows.map((r) => ({ label: r.title || r.rel || '(未命名)', value: r.rel || '' }))
        : [{ label: '最近卡片', value: '暂无（/note --list 可查看已归档卡片）' }],
    }]
  })
  R.onEscape(() => {
    if (!editor.classList.contains('ro-open')) return false
    closeEditor()
    return true
  })
  R.closePanels(() => { toggleLit(false); closeEditor() })
  R.appendWelcome([
    { text: '本期：文献检索与引用级校验（四源检索 / 卡片 / bib 导出 / DOI 双源校验 / PDF 引文逐字命中）' },
    { text: '试一句：`/find` 主题；`/note --list` 看卡片；`/verify` 校验引用真实性。', sub: true },
  ])
  // 时序：bridge 先注入、pack UI 后注入 —— 这里补渲染领域欢迎行 + 概览卡
  R.renderPackWelcome()
})(window.__ro)
