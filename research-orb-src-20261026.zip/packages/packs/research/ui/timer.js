// packages/packs/research/ui/timer.js
//
// 科研 · 计时面板 + 球角标/圆环（P-R3 阶段 3 起；P-R6 抽离出 shell）。
//
// 【架构纪律 · P-R6】本文件是**领域渲染层**：由 shell（apps/desktop/ui-bridge.mjs）
// 在注入 bridge 之后、由主进程按 pack.json 的 "ui" 清单读取并 executeJavaScript 注入。
// 因此这里同样不写 import / export（会被 executeJavaScript 拒绝），只通过
// window.__ro（shell 暴露的工具箱）取用底座能力。
//
// 工具箱（window.__ro）提供：
//   doc/panel/ball/el/send/addNotice/setStatus/state/transcript/historyList/
//   toggleSettings/fmtClock/fmtDur/VERSION/PATHS/api/scrollToEnd
//   ballRing/ballBadge/ballRingFg/RING_C（球的角标/圆环槽位，由 pack 填充语义）
//   onPanel(pluginId, fn) / onPanelFallback(fn) / onMsg(type, fn) / onSettings(fn)
//   cardActions(fn) / closePanels(fn) / statusExtras(fn) / appendWelcome(lines)
//
// 纪律：领域 UI 只渲染 + 上行命令，不读写文件、不出网 —— 与 shell 的通道纪律一致。

;(function (R) {
  'use strict'
  const {
    doc, panel, ball, el, send, addNotice, state, transcript, historyList,
    toggleSettings, fmtClock, fmtDur, VERSION, PATHS, api,
    ballRing, ballBadge, ballRingFg, RING_C, scrollToEnd,
  } = R

  /** 主进程每次下行 {type:'timer', snapshot} 时调用：刷新圆环与角标。 */
  function updateBallTimer() {
    if (!ballRing || !ballBadge) return
    const snap = state.timer
    if (!snap || snap.status === 'idle' || !snap.status) {
      ballRing.style.display = 'none'
      ballBadge.classList.remove('ro-on', 'ro-paused', 'ro-idleask')
      return
    }
    ballRing.style.display = ''
    const planned = Number(snap.plannedSec) || 0
    const done = (Number(snap.accumulatedSec) || 0) + (Number(snap.elapsedSec) || 0)
    const remainFrac = planned > 0 ? Math.max(0, Math.min(1, (planned - done) / planned)) : 0
    ballRingFg.style.strokeDashoffset = String(RING_C * (1 - remainFrac))
    ballRingFg.style.stroke = snap.status === 'paused' ? 'var(--ro-warn)' : snap.idlePrompt ? 'var(--ro-danger)' : 'var(--ro-info)'
    ballBadge.classList.add('ro-on')
    ballBadge.classList.toggle('ro-paused', snap.status === 'paused' && !snap.idlePrompt)
    ballBadge.classList.toggle('ro-idleask', !!snap.idlePrompt)
    ballBadge.textContent = snap.idlePrompt ? '空闲?' : fmtClock(snap.remainingSec)
    ballBadge.title = snap.idlePrompt
      ? '检测到空闲，等待回答：保留还是扣除'
      : (snap.status === 'running' ? '计时中 · 剩余 ' : '已暂停 · 剩余 ') + fmtClock(snap.remainingSec)
  }

  // --- 5c. 自建 DOM：计时面板（阶段 3）---
  //
  // 与文献面板同一纪律：面板只渲染 + 上行命令，不读写任何文件。
  // 布局：状态区（每秒刷新）/ 控制区（静态，输入框不因刷新失焦）/
  //       空闲询问区 / 项目区 / 报告区。
  const timerPanel = doc.createElement('div')
  timerPanel.id = 'ro-timer'
  timerPanel.setAttribute('role', 'dialog')
  timerPanel.setAttribute('aria-label', '计时')
  if (panel) panel.appendChild(timerPanel)

  const timerHead = el('div', 'ro-timer-head')
  timerHead.appendChild(el('h3', 'ro-timer-title', '计时'))
  const timerCloseBtn = el('button', 'ro-settings-close', '关闭')
  timerCloseBtn.type = 'button'
  timerCloseBtn.addEventListener('click', () => toggleTimer(false))
  timerHead.appendChild(timerCloseBtn)
  timerPanel.appendChild(timerHead)

  const timerStatus = el('div', 'ro-timer-status')
  timerPanel.appendChild(timerStatus)

  const timerControls = el('div', 'ro-timer-controls')
  timerPanel.appendChild(timerControls)

  const timerIdle = el('div', 'ro-timer-idle')
  timerPanel.appendChild(timerIdle)

  const timerProject = el('div', 'ro-group')
  timerPanel.appendChild(timerProject)

  const timerReport = el('div', 'ro-group')
  timerReport.appendChild(el('h4', 'ro-group-title', '日报 / 周报'))
  const reportRow = el('div', 'ro-lit-controls')
  const todayBtn = el('button', 'ro-btn', '今日日报')
  todayBtn.type = 'button'
  todayBtn.addEventListener('click', () => send('plugin:command', { name: 'today', args: '' }))
  const weeklyBtn = el('button', 'ro-btn', '本周周报')
  weeklyBtn.type = 'button'
  weeklyBtn.addEventListener('click', () => send('plugin:command', { name: 'weekly', args: '' }))
  const copyBtn = el('button', 'ro-btn', '复制 Markdown')
  copyBtn.type = 'button'
  copyBtn.addEventListener('click', async () => {
    const text = reportPre.textContent || ''
    if (!text) {
      addNotice('warn', '还没有可复制的报告内容：先点「今日日报」或「本周周报」。')
      return
    }
    let ok = false
    try {
      await navigator.clipboard.writeText(text)
      ok = true
    } catch {
      // 沙箱/无焦点时 clipboard API 可能不可用：退回调 textarea + execCommand
      try {
        const ta = doc.createElement('textarea')
        ta.value = text
        ta.style.position = 'fixed'
        ta.style.opacity = '0'
        doc.body.appendChild(ta)
        ta.select()
        ok = doc.execCommand('copy')
        doc.body.removeChild(ta)
      } catch {
        ok = false
      }
    }
    addNotice(ok ? 'info' : 'warn', ok ? '报告 Markdown 已复制到剪贴板。' : '复制失败：请从上方文本框手动选取复制。')
  })
  reportRow.appendChild(todayBtn)
  reportRow.appendChild(weeklyBtn)
  reportRow.appendChild(copyBtn)
  timerReport.appendChild(reportRow)
  const reportPath = el('p', 'ro-note', '')
  reportPath.style.display = 'none'
  timerReport.appendChild(reportPath)
  const reportPre = el('pre', 'ro-timer-report', '')
  reportPre.style.display = 'none'
  timerReport.appendChild(reportPre)
  timerPanel.appendChild(timerReport)


  // --- 5d. 计时控制区（静态 DOM：输入框不因每秒刷新而失焦）---
  //
  // 所有按钮都只是把一条插件命令上行（/start /pause /resume /stop …），
  // 主进程转交 research-timer 插件执行；结果经 plugin:panel 回来渲染。
  for (const m of [15, 25, 45]) {
    const b = el('button', 'ro-btn', String(m))
    b.type = 'button'
    b.title = '开始 ' + m + ' 分钟番茄'
    b.addEventListener('click', () => send('plugin:command', { name: 'start', args: String(m) }))
    timerControls.appendChild(b)
  }
  const customInput = doc.createElement('input')
  customInput.className = 'ro-timer-num'
  customInput.type = 'number'
  customInput.min = '1'
  customInput.max = '180'
  customInput.value = '25'
  customInput.title = '自定义分钟（1~180）'
  timerControls.appendChild(customInput)
  const startBtn = el('button', 'ro-btn ro-primary', '开始')
  startBtn.type = 'button'
  startBtn.addEventListener('click', () => {
    const n = Number(customInput.value)
    if (!Number.isInteger(n) || n < 1 || n > 180) {
      addNotice('warn', '自定义时长必须是 1~180 的整数分钟。')
      return
    }
    send('plugin:command', { name: 'start', args: String(n) })
  })
  timerControls.appendChild(startBtn)
  const pauseBtn = el('button', 'ro-btn', '暂停')
  pauseBtn.type = 'button'
  pauseBtn.addEventListener('click', () => send('plugin:command', { name: 'pause', args: '' }))
  const resumeBtn = el('button', 'ro-btn', '恢复')
  resumeBtn.type = 'button'
  resumeBtn.addEventListener('click', () => send('plugin:command', { name: 'resume', args: '' }))
  const stopBtnTimer = el('button', 'ro-btn', '停止')
  stopBtnTimer.type = 'button'
  stopBtnTimer.addEventListener('click', () => send('plugin:command', { name: 'stop', args: '' }))
  timerControls.appendChild(pauseBtn)
  timerControls.appendChild(resumeBtn)
  timerControls.appendChild(stopBtnTimer)
  const notifyLabel = el('label', 'ro-choice')
  notifyLabel.title = '关闭后计时完成不再弹系统通知（不影响计时本身）'
  const notifyCb = doc.createElement('input')
  notifyCb.type = 'checkbox'
  notifyCb.checked = true
  notifyCb.addEventListener('change', () => send('timer:notify', { on: notifyCb.checked }))
  notifyLabel.appendChild(notifyCb)
  notifyLabel.appendChild(el('span', null, '完成提醒'))
  timerControls.appendChild(notifyLabel)


  // --- 10c. 渲染：计时面板（阶段 3）---
  //
  // 面板分区刷新：状态区每秒跟着下行快照重画；控制区/项目区/报告区只在
  // 对应 payload 到达时重画 —— 用户正在输入框里打字不会被打断。
  function toggleTimer(next) {
    const open = next === undefined ? !state.timerOpen : !!next
    const wasOpen = state.timerOpen
    state.timerOpen = open
    timerPanel.classList.toggle('ro-open', open)
    if (open && !wasOpen) {
      if (transcript) transcript.hidden = true
      if (historyList) historyList.hidden = true
      if (state.settingsOpen) toggleSettings(false)
      if (state.litOpen) toggleLit(false)
      // 拉一份最新状态与项目列表（面板只是渲染器，数据一律来自主进程）。
      // **只在关→开的跳变上拉取**：renderTimer 收到下行 payload 时也会调 toggleTimer(true)，
      // 若每次都重发 status/project，就会形成「payload → 重发命令 → 新 payload」的死循环
      // （实测每秒刷屏 ~60 次命令，GUI 截图取证时暴露）。已开状态下的内容重画走
      // renderTimerStatus / renderTimerProjects，不再回头要数据。
      send('plugin:command', { name: 'status', args: '' })
      send('plugin:command', { name: 'project', args: 'list' })
    } else if (!open && wasOpen && transcript && historyList) {
      transcript.hidden = !historyList.hidden
    }
  }

  function syncNotifyCheckboxes() {
    if (state.notifyCbTimer) state.notifyCbTimer.checked = state.timerNotify !== false
    if (state.notifyCbSettings) state.notifyCbSettings.checked = state.timerNotify !== false
  }

  /** 状态区：优先用最新下行快照（state.timer），项目名/今日汇总取最近一次 status payload。 */
  function renderTimerStatus() {
    timerStatus.textContent = ''
    const snap = state.timer || {}
    const ui = state.timerUi && state.timerUi.kind === 'status' ? state.timerUi : {}
    const label = { running: '运行中', paused: '已暂停', idle: '空闲' }[snap.status] || '空闲'
    const clock = el(
      'div',
      'ro-timer-clock' + (snap.status === 'paused' ? ' ro-paused' : ''),
      snap.status === 'idle' || !snap.status ? '空闲' : fmtClock(snap.remainingSec),
    )
    timerStatus.appendChild(clock)
    if (snap.status && snap.status !== 'idle') {
      const doneSec = (Number(snap.accumulatedSec) || 0) + (Number(snap.elapsedSec) || 0)
      timerStatus.appendChild(
        el('div', 'ro-timer-line', label + ' · 已专注 ' + fmtDur(doneSec) + ' / 计划 ' + Math.round((Number(snap.plannedSec) || 0) / 60) + ' 分钟'),
      )
    } else {
      timerStatus.appendChild(el('div', 'ro-timer-line', '点上方预设或自定义时长开始一个番茄（15/25/45 或 1~180 分钟）。'))
    }
    const pn = ui.projectName || snap.projectId || ''
    const sn = ui.stageName || ''
    timerStatus.appendChild(el('div', 'ro-timer-line', '项目：' + (pn || '未归类') + (sn ? ' / ' + sn : '')))
    if (ui.today) {
      timerStatus.appendChild(
        el(
          'div',
          'ro-timer-line',
          '今日（' + ui.today.dayKey + '）：专注 ' + fmtDur(ui.today.focusSec) + ' · 会话 ' + ui.today.sessionCount + '（完成 ' + ui.today.completedCount + '）· 卡片 +' + ui.today.cards + ' · bib +' + ui.today.bib,
        ),
      )
    }
    if (snap.idlePrompt) showTimerIdle(snap.idlePrompt)
    else hideTimerIdle()
    if (snap.corrupt) {
      timerStatus.appendChild(el('div', 'ro-timer-line', '⚠ 上次状态文件损坏（' + (snap.corrupt.problems || []).join('、') + '）：磁盘原样未改，开始新计时即开新账。'))
    }
    if (snap.lastInterrupted) {
      const li = snap.lastInterrupted
      timerStatus.appendChild(
        el('div', 'ro-timer-line', '上次中断恢复：记录 ' + fmtDur(li.totalSec) + '，未记录间隔 ' + fmtDur(li.gapSec) + '（进程中断，不猜不补）。'),
      )
    }
    timerStatus.appendChild(el('div', 'ro-timer-line', '完成提醒：' + (state.timerNotify === false ? '关' : '开') + '（上方复选框可一键切换）'))
  }

  function showTimerIdle(prompt) {
    timerIdle.textContent = ''
    timerIdle.appendChild(
      el('p', 'ro-note', '检测到已空闲约 ' + fmtDur(prompt.idleSec) + '（超过 5 分钟）：这段时间算专注吗？不操作则不做任何改动。'),
    )
    const row = el('div', 'ro-lit-controls')
    const keep = el('button', 'ro-btn', '保留（照常计为专注）')
    keep.type = 'button'
    keep.addEventListener('click', () => send('timer:idle-resolve', { keep: true }))
    const cut = el('button', 'ro-btn ro-danger', '扣除（剪掉这段）')
    cut.type = 'button'
    cut.addEventListener('click', () => send('timer:idle-resolve', { keep: false }))
    row.appendChild(keep)
    row.appendChild(cut)
    timerIdle.appendChild(row)
    timerIdle.classList.add('ro-open')
  }

  function hideTimerIdle() {
    timerIdle.classList.remove('ro-open')
    timerIdle.textContent = ''
  }

  function renderTimerProjects() {
    timerProject.textContent = ''
    timerProject.appendChild(el('h4', 'ro-group-title', '项目与阶段'))
    const snap = state.timer || {}
    const curName = (state.timerUi && state.timerUi.projectName) || snap.projectId || ''
    timerProject.appendChild(el('p', 'ro-note', '当前归类：' + (curName || '未归类（开始计时时可用 --project 归类）')))

    const newRow = el('div', 'ro-lit-controls')
    const newInput = doc.createElement('input')
    newInput.className = 'ro-idxinput'
    newInput.placeholder = '新项目名称'
    const newBtn = el('button', 'ro-btn', '新建项目')
    newBtn.type = 'button'
    newBtn.addEventListener('click', () => {
      const name = String(newInput.value || '').trim()
      if (!name) {
        addNotice('warn', '先填项目名称。')
        return
      }
      send('plugin:command', { name: 'project', args: 'new ' + name })
    })
    newRow.appendChild(newInput)
    newRow.appendChild(newBtn)
    timerProject.appendChild(newRow)

    const stageRow = el('div', 'ro-lit-controls')
    const stageInput = doc.createElement('input')
    stageInput.className = 'ro-idxinput'
    stageInput.placeholder = '新阶段名称'
    const stageBtn = el('button', 'ro-btn', '加阶段')
    stageBtn.type = 'button'
    stageBtn.addEventListener('click', () => {
      const name = String(stageInput.value || '').trim()
      if (!name) {
        addNotice('warn', '先填阶段名称。')
        return
      }
      if (!snap.projectId) {
        addNotice('warn', '当前没有归类项目：先用上方「用它计时」开始一个归类计时，或 /start 25 --project <名>。')
        return
      }
      send('plugin:command', { name: 'project', args: 'add-stage ' + snap.projectId + ' ' + name })
    })
    const doneBtn = el('button', 'ro-btn', '标记完成')
    doneBtn.type = 'button'
    doneBtn.addEventListener('click', () => {
      if (!snap.projectId) {
        addNotice('warn', '当前没有归类项目。')
        return
      }
      send('plugin:command', { name: 'project', args: 'done ' + snap.projectId })
    })
    stageRow.appendChild(stageInput)
    stageRow.appendChild(stageBtn)
    stageRow.appendChild(doneBtn)
    timerProject.appendChild(stageRow)

    const list = state.timerProjects || []
    if (list.length === 0) {
      timerProject.appendChild(el('p', 'ro-note', '还没有项目。新建一个，之后 /start 25 --project <名> 就能把专注时间归类到它下面。'))
    }
    for (const p of list) {
      const row = el('div', 'ro-cand')
      const main = el('div', 'ro-cand-main')
      main.appendChild(el('div', 'ro-cand-title', (p.done ? '✓ ' : '') + p.name + '（' + p.id + '）'))
      const stages = (p.stages || []).map((s) => (s.done ? '✓ ' : '· ') + s.name)
      main.appendChild(el('p', 'ro-cand-meta', stages.length ? stages.join('；') : '（无阶段，「加阶段」可添加）'))
      row.appendChild(main)
      const use = el('button', 'ro-btn', '用它计时')
      use.type = 'button'
      use.title = '以该项目开始 25 分钟计时'
      use.addEventListener('click', () => send('plugin:command', { name: 'start', args: '25 --project ' + p.id }))
      row.appendChild(use)
      timerProject.appendChild(row)
    }
  }

  function renderTimerReport(ui) {
    reportPath.textContent = (ui.scope === 'weekly' ? '周报' : '日报') + '：' + (ui.reportPath || '—') + (ui.polished ? '（含 AI 复盘）' : '（纯模板，AI 复盘未启用或失败）')
    reportPath.style.display = ''
    reportPre.textContent = ui.markdown || ''
    reportPre.style.display = ''
  }

  /** plugin:panel 下行里 research-timer 的那一路。 */
  function renderTimer(payload) {
    if (!payload || !payload.ui) return
    const ui = payload.ui
    state.timerUi = ui
    if (ui.kind === 'status') {
      if (ui.snapshot) {
        state.timer = ui.snapshot
        updateBallTimer()
      }
      toggleTimer(true)
      renderTimerStatus()
      return
    }
    if (ui.kind === 'projects') {
      state.timerProjects = ui.projects || []
      toggleTimer(true)
      renderTimerProjects()
      return
    }
    if (ui.kind === 'report') {
      toggleTimer(true)
      renderTimerReport(ui)
      return
    }
    // 其它（错误等）：落到计时面板里显示，不打扰对话流
    toggleTimer(true)
    timerStatus.textContent = ''
    timerStatus.appendChild(el('p', 'ro-note', ui.message || payload.code || '（命令未返回内容）'))
  }


  /** 下行计时消息统一入口（球角标 + 面板状态区）。 */
  function onTimerMsg(message) {
    state.timer = message.snapshot || state.timer
    updateBallTimer()
    if (message.type === 'timer:notify') {
      if (message.settings && typeof message.settings.notifications === 'boolean') {
        state.timerNotify = message.settings.notifications
        syncNotifyCheckboxes()
      }
      if (state.timerOpen) renderTimerStatus()
      return
    }
    if (message.type === 'timer:idle-resolve') hideTimerIdle()
    if (state.timerOpen) renderTimerStatus()
  }

  // --- 注册：下行消息 / 设置钩子 / 关面板 / 状态胶囊 / 欢迎语 ---
  R.onPanel('research-timer', renderTimer)
  R.onMsg('timer', onTimerMsg)
  R.onMsg('timer:idle', onTimerMsg)
  R.onMsg('timer:notify', onTimerMsg)
  R.onMsg('timer:idle-resolve', onTimerMsg)
  R.onSettings(() => syncNotifyCheckboxes())
  R.closePanels(() => toggleTimer(false))
  R.claimRoot(timerPanel)
  R.onEscape(() => {
    if (!state.timerOpen) return false
    toggleTimer(false)
    return true
  })
  // P-R6.1 评审⑥：占位文案语境化（research pack）
  R.onPlaceholder(() => '问点什么…（试 /start 25 或 /find 主题）')
  R.applyPlaceholder()
  // P-R6.1 评审①：今日概览（真实数据：来自主进程下行的 timer 快照 / status payload；
  // 无数据时字段显示 —，不造占位假数据）。文献卡由 literature.js 各自注册 onOverview。
  R.onOverview(() => {
    const t = state.timer || {}
    const ui = state.timerUi && state.timerUi.kind === 'status' ? state.timerUi : {}
    const today = ui.today || null
    const label = { running: '进行中', paused: '已暂停', idle: '空闲' }[t.status] || '空闲'
    return [{
      title: '今日概览 · 专注',
      rows: [
        { label: '专注状态', value: label },
        { label: '今日专注', value: today ? fmtDur(today.focusSec) : '—' },
        { label: '会话', value: today ? `${today.sessionCount}（完成 ${today.completedCount}）` : '—' },
        { label: '当前项目', value: (ui.projectName || t.projectId || '') || '未归类' },
      ],
    }]
  })
  // 设置页里的本领域分组（shell 只提供通用分组）
  R.onSettingsGroups((host) => {
    const tg = el('div', 'ro-group')
    tg.appendChild(el('h4', 'ro-group-title', '计时'))
    const trow = el('label', 'ro-choice')
    const tcb = doc.createElement('input')
    tcb.type = 'checkbox'
    tcb.checked = state.timerNotify !== false
    tcb.addEventListener('change', () => send('timer:notify', { on: tcb.checked }))
    state.notifyCbSettings = tcb
    trow.appendChild(tcb)
    trow.appendChild(el('span', null, '计时完成提醒（系统通知）'))
    tg.appendChild(trow)
    tg.appendChild(el('p', 'ro-hint', '番茄钟 15/25/45 分钟 + 自定义；空闲超过 5 分钟会询问「保留还是扣除」，不静默改写；进程中断后按最后一次心跳收尾，未记录间隔如实报告。'))
    host.appendChild(tg)
    syncNotifyCheckboxes()
  })
  R.statusExtras((host) => {
    const t = state.timer
    if (t && t.status && t.status !== 'idle') {
      const warn = t.status === 'paused' || t.idlePrompt
      host.appendChild(el('span', 'ro-pill' + (warn ? ' ro-warn' : ''), t.idlePrompt ? '计时 · 空闲待确认' : '计时 ' + fmtClock(t.remainingSec)))
    }
  })
  R.appendWelcome([
    { text: '本期：番茄钟计时 + 项目/阶段归类 + 日报周报（球上角标实时显示剩余时间）' },
    { text: '试一句：`/start` 25 --project 项目名；`/today` 看今日汇总。右上「设置 → 插件卡片 → 打开计时面板」可图形化操作。', sub: true },
  ])
  R.renderPackWelcome()
})(window.__ro)
