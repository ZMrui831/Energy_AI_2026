// packages/packs/research/ui/home.js
//
// S5 · 信息架构（IA）主文件：首页 + 二级页（对话/轨迹/笔记）+ 开始学习 + 主动询问卡
// + 拒绝冷却 UI + 12 态调试矩阵。
//
// 架构纪律（与 literature.js/timer.js 一致）：领域渲染层，由 shell 注入 renderer，
// 不写 import/export，只经 window.__ro 工具箱渲染 + 上行命令，不读写文件、不出网。
// **不改几何契约**：球 96×96 / 面板 420×620 / 右下锚点一律不动；只往 panel 内加 DOM。
// **不抢前台**：本文件没有任何 focus()/show() 调用。
//
// 设计 token（tools/accept-ui-matrix.mjs 实测）：
//   间距 4/8（--s5-sp1/--s5-sp2）；字号 12/14/16/20；点击目标 ≥32px（关键 ≥40px）；
//   正文色 var(--black) 于 var(--white) 之上（主题保证对比度 ≥4.5:1）。
//
// 调试入口（截图回归用）：window.__s5 = { page, currentPage, setState, refresh }。

;(function (R) {
  'use strict'
  const { doc, panel, el, send, addNotice, transcript, fmtDur, VERSION, PATHS, scrollToEnd } = R

  // ------------------------------------------------------------------
  // 页面状态（记忆：JS 变量扛收起/展开；localStorage 扛重载/切 pack）
  // ------------------------------------------------------------------
  const PAGE_KEY = 'ro.s5.page'
  // S47·P1：第 6 页「隐私」——DESIGN-UI §6 要求导航固定 6 项。
  const PAGES = ['home', 'chat', 'trajectory', 'notes', 'publish', 'settings']
  let page = 'home'
  try {
    const saved = localStorage.getItem(PAGE_KEY)
    if (saved && PAGES.includes(saved)) page = saved
  } catch { /* 无 localStorage 按首页 */ }

  // 12 态调试矩阵（与 timeline/logic.mjs UI_STATES 对齐）
  const STATES = [
    'default', 'monitoring', 'paused', 'no-consent', 'learning-candidate', 'learning',
    'silent', 'needs-confirm', 'success', 'failure', 'offline', 'deleted',
  ]
  let uiState = 'default'
  let statusData = null
  // S66·P0-1：待处理卡「查看计划」展开态（收起/展开不重载渲染进程，与页面变量同思路）
  let plansExpanded = false

  // ------------------------------------------------------------------
  // 样式层（token）
  // ------------------------------------------------------------------
  R.addStyle(`
    #ro-s5-topbar { display:flex; align-items:center; gap: var(--s5-sp1, 4px); padding: var(--s5-sp1, 4px) var(--s5-sp2, 8px); font-size: 14px; }
    #ro-s5-topbar .s5-crumb { font-size: 12px; color: var(--black); flex: 1; }
    #ro-s5-topbar .s5-back { min-height: 32px; min-width: 32px; font-size: 14px; padding: 4px 8px; }
    #ro-s5 .ro-btn { font-size: 14px; padding: 4px 8px; }
    .s5-page { display:none; padding: var(--s5-sp2, 8px); overflow-y:auto; font-size: 14px; }
    .s5-page.s5-on { display:block; }
    .s5-status { display:flex; flex-wrap:wrap; gap: var(--s5-sp1, 4px); margin-bottom: var(--s5-sp2, 8px); font-size: 12px; }
    .s5-chip { font-size: 12px; padding: 4px var(--s5-sp2, 8px); border:1px solid var(--border);
               border-radius: 10px; background: var(--input-bg, var(--white)); color: var(--black); }
    .s5-chip.s5-strong { background: var(--black); color: var(--white); }
    .s5-actions { display:grid; grid-template-columns: 1fr 1fr; gap: var(--s5-sp2, 8px); margin-bottom: var(--s5-sp2, 8px); font-size: 14px; }
    .s5-act { min-height: 40px; font-size: 14px; display:flex; align-items:center; justify-content:center; }
    .s5-act.s5-wide { grid-column: 1 / -1; }
    .s5-sec { font-size: 12px; color: var(--black); margin: var(--s5-sp2, 8px) 0 var(--s5-sp1, 4px); }
    .s5-list { font-size: 14px; color: var(--black); }
    .s5-row { display:flex; align-items:center; gap: var(--s5-sp1, 4px); padding: var(--s5-sp1, 4px) 0;
              border-bottom: 1px solid var(--border); min-height: 32px; cursor: pointer; font-size: 14px; }
    .s5-row:hover { background: var(--input-bg, var(--white)); }
    .s5-row .s5-grow { flex: 1; font-size: 14px; }
    .s5-row .s5-sub { font-size: 12px; color: var(--black); }
    .s5-ask { border:1px solid var(--black); border-radius: 8px; padding: var(--s5-sp2, 8px); margin-bottom: var(--s5-sp2, 8px); font-size: 14px; }
    .s5-ask h4 { margin: 0 0 var(--s5-sp1, 4px); font-size: 16px; color: var(--black); }
    .s5-ask p { margin: 0 0 var(--s5-sp1, 4px); font-size: 12px; color: var(--black); }
    .s5-ask .s5-ask-btns { display:flex; gap: var(--s5-sp2, 8px); margin-top: var(--s5-sp2, 8px); font-size: 14px; }
    .s5-ask .s5-ask-btns button { flex:1; min-height: 40px; min-width: 120px; font-size: 14px; }
    .s5-evidence { font-size: 12px; color: var(--black); padding-left: var(--s5-sp2, 8px); }
    .s5-note { font-size: 12px; color: var(--black); padding: var(--s5-sp2, 8px); }
    .s5-failure { border: 2px solid var(--black); font-weight: bold; }
    #ro-s5 button:disabled { cursor: not-allowed; border-style: dashed; }
    #s5-notice { border:1px solid var(--border); border-radius: 8px; margin-bottom: var(--s5-sp2, 8px); }
    .s5-badge { font-size: 12px; padding: 0 var(--s5-sp1, 4px); border:1px solid var(--border); border-radius: 8px; color: var(--black); }
    .s5-none { border-style: dashed; opacity: 0.92; }
    .s5-deleted { font-weight: bold; }
    .s5-input { width: 100%; box-sizing: border-box; font-size: 14px; font-family: inherit; color: var(--black);
                background: var(--input-bg, var(--white)); border: 1px solid var(--border); border-radius: 8px;
                padding: var(--s5-sp2, 8px); margin-bottom: var(--s5-sp2, 8px); resize: vertical; }
    .s5-toclaim { min-height: 32px; font-size: 12px; margin-left: var(--s5-sp2, 8px); padding: 4px 8px; }
    #ro-s5 :focus-visible { outline: 2px solid var(--black); outline-offset: 1px; }
  `)

  // ------------------------------------------------------------------
  // DOM
  // ------------------------------------------------------------------
  const root = doc.createElement('div')
  root.id = 'ro-s5'
  // S47·P1：左侧 44px 图标导航（绝对定位，不参与 vendor 的 column 流）+ 主列。
  // vendor 的 #panel 一个字节都不动；导航只是浮在左边缘，由 design-v1.js 的
  // padding-left:64px 给它让位。
  const nav = el('nav', '')
  nav.id = 'ro-ds-nav'
  nav.setAttribute('aria-label', '主导航')
  // 固定 6 项、label 唯一（这一条同时解决"两个发布"）：页面上只出现图标，
  // 文字只进 title/aria-label，视觉上不会再撞名。
  // S52：第 6 项改成「设置」（齿轮）—— 诊断/隐私/实验室功能都收进设置页，
  // 主面板只留直接交互的四个页。用户原话："设置应当放在左下角、齿轮形式"。
  const NAV_ITEMS = [
    { page: 'home', label: '首页', icon: '◈' },
    { page: 'chat', label: '对话', icon: '◌' },
    { page: 'trajectory', label: '轨迹', icon: '⌁' },
    { page: 'notes', label: '笔记', icon: '▤' },
    { page: 'publish', label: '发布', icon: '⤴' },
    { page: 'settings', label: '设置', icon: '⚙' },
  ]
  const navBtns = new Map()
  for (const item of NAV_ITEMS) {
    const b = el('button', 'ds-nav-btn', item.icon)
    b.type = 'button'
    b.title = item.label
    b.setAttribute('aria-label', item.label)
    b.dataset.page = item.page
    b.addEventListener('click', () => go(item.page))
    nav.appendChild(b)
    navBtns.set(item.page, b)
  }
  if (panel) {
    panel.appendChild(nav)
    panel.appendChild(root)
  }
  if (R.claimRoot) R.claimRoot(root)

  const topbar = el('div', '')
  topbar.id = 'ro-s5-topbar'
  const backBtn = el('button', 'ro-btn s5-back', '← 首页')
  backBtn.type = 'button'
  backBtn.title = '返回首页（Esc 同效）'
  const crumb = el('div', 's5-crumb ds-page-name', '首页')
  const chatBtn = el('button', 'ro-btn s5-back', '对话')
  chatBtn.type = 'button'
  chatBtn.title = '进入对话页'
  // S47·P1：顶栏只留「页面名 + 状态点 ●」。返回/对话/发布三个按钮都不再挂顶栏 ——
  // 它们正是"导航重复（两个发布）"与"顶栏塞指标"的来源；导航统一由左侧 6 项承担。
  const dsDot = el('span', 'ds-dot')
  dsDot.title = '就绪'
  topbar.appendChild(crumb)
  topbar.appendChild(dsDot)
  root.appendChild(topbar)

  // 底部状态行（28px）：**只写用户语义**（就绪/离线/需授权），技术指标一律进诊断折叠区。
  const dsFoot = el('div', '', '就绪')
  dsFoot.id = 'ro-ds-foot'
  dsFoot.setAttribute('role', 'status')

  // 首页
  const homePage = el('div', 's5-page')
  homePage.id = 's5-home'
  const statusStrip = el('div', 's5-status')
  const actions = el('div', 's5-actions')
  const pending = el('div', 's5-pending')
  // S66·P0-2 卡片规则机器化：每张卡都可枚举（data-card）、可标注标题（data-card-title），
  // 验收脚本 accept-s66-cards.mjs 靠这两个属性逐卡判定"有标题没内容"。
  pending.dataset.card = 'pending'
  pending.dataset.cardTitle = '待处理'
  const homeBody = el('div', 's5-list')
  // S56·T9 会话回声可发现提示（首页顶部）：启动检测到待清理项才出现；
  // 两段式确认（点一次→"将关闭应用并清理"，再点→执行），清理在退出时做，结果下次启动显示。
  const t9Bar = el('div', 'ro-t9-bar')
  t9Bar.id = 'ro-t9-bar'
  t9Bar.style.display = 'none'
  let t9Count = 0
  let t9Armed = false
  function renderT9() {
    if (!t9Count) { t9Bar.style.display = 'none'; return }
    t9Bar.textContent = t9Armed
      ? `将关闭应用并清理 ${t9Count} 项历史回声（先导出备份再删）——确认请再点一次`
      : `有 ${t9Count} 项历史回声待清理，点此处理`
    t9Bar.style.display = ''
  }
  t9Bar.addEventListener('click', () => {
    if (!t9Armed) { t9Armed = true; renderT9(); return }
    t9Armed = false
    t9Count = 0
    renderT9()
    send('ui', { type: 't9:purge' })
  })
  if (typeof R.onMsg === 'function') {
    R.onMsg('t9:pending', (m) => { t9Count = Number(m && m.count) || 0; t9Armed = false; renderT9() })
    R.onMsg('t9:done', (m) => { if (m && m.purged > 0) showAskNotice(`上次启动已清理 ${m.purged} 项历史回声（备份在 data/db）。`) })
    R.onMsg('t9:queued', (m) => { showAskNotice((m && m.message) || '将在退出时清理。') })
  }
  // 修复断链：原 `sendCmd('timer','start 25')` —— 命令表里没有 'timer'（实测 0 条），
  // 正确命令是 research-timer 的 'start'（/start [25] [--project learn]）—— 该入口此前从未工作过。
  const pomodoroCard = el('div', 'ro-pomodoro-card')
  pomodoroCard.id = 'ro-pomodoro-card'
  pomodoroCard.dataset.card = 'pomodoro' // S66·P0-2
  pomodoroCard.dataset.cardTitle = '番茄钟'
  const POMO_TOTAL = 25 * 60
  let pomoLeft = POMO_TOTAL
  let pomoTimer = null
  let pomoState = 'idle' // idle | running | paused | ended
  const pomoTimeEl = el('span', 'ro-pomo-time', '25:00')
  const pomoStateEl = el('span', 'ro-pomo-state', '待机')
  const pomoHead = el('div', 'ro-pomo-head')
  pomoHead.appendChild(el('span', 'ro-pomo-title', '番茄钟'))
  pomoHead.appendChild(pomoTimeEl)
  pomodoroCard.appendChild(pomoHead)
  pomodoroCard.appendChild(pomoStateEl)
  const pomoBar = el('div', 'ro-pomo-bar')
  const pomoStartBtn = el('button', 'ro-btn s5-act', '开始')
  const pomoPauseBtn = el('button', 'ro-btn s5-act', '暂停')
  const pomoStopBtn = el('button', 'ro-btn s5-act', '结束')
  for (const b of [pomoStartBtn, pomoPauseBtn, pomoStopBtn]) { b.type = 'button'; pomoBar.appendChild(b) }
  pomodoroCard.appendChild(pomoBar)
  function fmtPomo(sec) {
    const m = Math.floor(sec / 60)
    const s = sec % 60
    return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0')
  }
  function renderPomo() {
    pomoTimeEl.textContent = fmtPomo(Math.max(0, pomoLeft))
    pomoStateEl.textContent = { idle: '待机（还没有开始专注）', running: '运行中', paused: '已暂停', ended: '结束 · 休息一下' }[pomoState] || '待机'
    pomoStartBtn.disabled = pomoState === 'running'
    pomoPauseBtn.disabled = pomoState !== 'running'
    pomoStopBtn.disabled = pomoState === 'idle' || pomoState === 'ended'
  }
  function pomoClear() { if (pomoTimer) { clearInterval(pomoTimer); pomoTimer = null } }
  function pomoRun() {
    pomoState = 'running'
    renderPomo()
    pomoClear()
    pomoTimer = setInterval(() => {
      pomoLeft -= 1
      if (pomoLeft <= 0) {
        pomoLeft = 0
        pomoState = 'ended'
        pomoClear()
        sendCmd('stop', '')
        showAskNotice('25 分钟专注完成——站起来伸个懒腰，5 分钟后我提醒你回来。')
      }
      renderPomo()
    }, 1000)
  }
  pomoStartBtn.addEventListener('click', () => {
    if (pomoState === 'paused') { sendCmd('resume', ''); pomoRun(); return }
    pomoLeft = POMO_TOTAL
    sendCmd('start', '25')
    pomoRun()
    showAskNotice('番茄钟已开始：25 分钟。完成后会提醒你休息。')
  })
  pomoPauseBtn.addEventListener('click', () => {
    pomoClear()
    pomoState = 'paused'
    sendCmd('pause', '')
    renderPomo()
  })
  pomoStopBtn.addEventListener('click', () => {
    pomoClear()
    sendCmd('stop', '')
    pomoLeft = POMO_TOTAL
    pomoState = 'idle'
    renderPomo()
    showAskNotice('已结束计时，时长已记账（/today 可查）。')
  })
  renderPomo()
  // S47·P1：技术指标（感知状态/同意方式/今日时长/原图剩余…）收进「设置→高级→诊断」，
  // 默认折叠 —— 面板默认态一个技术词都不露。
  const diag = doc.createElement('details')
  diag.id = 'ro-ds-diag'
  diag.dataset.card = 'diagnostics' // S66·P0-2（默认折叠 → 详情区不可见时整卡跳过）
  diag.dataset.cardTitle = '诊断'
  const diagSum = doc.createElement('summary')
  diagSum.textContent = '设置 · 高级 · 诊断'
  const diagBody = el('div', 'ds-diag-body')
  diagBody.appendChild(statusStrip)
  // S58·P0-3：预算诊断（metrics / 生效阈值 / 各级 trigger 是否 fired）——真数据，不再靠手写脚本
  const budgetDiag = el('div', 'ro-budget-diag')
  budgetDiag.id = 'ro-budget-diag'
  budgetDiag.appendChild(el('div', 'ds-t11', '预算诊断：等待首次采样…'))
  diagBody.appendChild(budgetDiag)
  // S60·P0-4：视觉 provider 诊断行（zhipu · glm-5.3-flash 就绪/未就绪 + 最近一次延迟）
  const visionDiag = el('div', 'ro-vision-diag')
  visionDiag.id = 'ro-vision-diag'
  visionDiag.appendChild(el('div', 'ds-t11', '视觉 provider：读取中…'))
  diagBody.appendChild(visionDiag)
  diag.appendChild(diagSum)
  diag.appendChild(diagBody)
  homePage.appendChild(actions)
  homePage.insertBefore(t9Bar, actions) // S56·T9：提示条在首页最顶部
  // S55·C1 首启引导（3 步，可跳过且记住；设置页可重看）。内嵌卡片不遮其它交互。
  const ONBOARD_KEY = 'ro-onboard-done-v1'
  const onboardCard = el('div', 'ro-onboard-card')
  onboardCard.id = 'ro-onboard-card'
  onboardCard.dataset.card = 'onboard' // S66·P0-2（未看完引导前 display:none → 跳过）
  onboardCard.dataset.cardTitle = '新手引导'
  onboardCard.style.display = 'none'
  const ONBOARD_STEPS = [
    ['我记住你的目标', '在对话里说一次你的目标，我记进长期记忆，不用反复提醒。'],
    ['我看你的屏幕（需你授权，原图最多保留 6 小时、到期即删）', '只为生成学习轨迹；截取后立即压缩送模，原件最多保留 6 小时、到期即删，只留文本与哈希。'],
    ['我给你的结论带证据', '每条结论都标来源：直接证据 / 推导 / 无直接证据。'],
  ]
  let onboardStep = 0
  function renderOnboard() {
    onboardCard.textContent = ''
    const [title, desc] = ONBOARD_STEPS[onboardStep] || ONBOARD_STEPS[0]
    const head = el('div', 'ro-onboard-head')
    head.appendChild(el('span', 'ro-onboard-step', `第 ${onboardStep + 1} / ${ONBOARD_STEPS.length} 步`))
    head.appendChild(el('span', 'ro-onboard-title', title))
    onboardCard.appendChild(head)
    onboardCard.appendChild(el('div', 'ro-onboard-desc', desc))
    const bar = el('div', 'ro-onboard-bar')
    const skip = el('button', 'ro-btn s5-act', '跳过，不再提示')
    skip.type = 'button'
    skip.addEventListener('click', () => finishOnboard(true))
    const next = el('button', 'ro-btn s5-act s5-strong', onboardStep >= ONBOARD_STEPS.length - 1 ? '开始' : '下一步')
    next.type = 'button'
    next.addEventListener('click', () => {
      if (onboardStep >= ONBOARD_STEPS.length - 1) { finishOnboard(false); return }
      onboardStep += 1
      renderOnboard()
    })
    bar.appendChild(skip)
    bar.appendChild(next)
    onboardCard.appendChild(bar)
  }
  function showOnboard() { onboardStep = 0; renderOnboard(); onboardCard.style.display = '' }
  function hideOnboard() { onboardCard.style.display = 'none' }
  function finishOnboard(skipped) {
    try { localStorage.setItem(ONBOARD_KEY, skipped ? 'skipped' : 'done') } catch { /* 存储不可用也不阻断 */ }
    hideOnboard()
    if (!skipped) showAskNotice('提示：随时可在「设置」里重看这份引导。')
  }
  try { if (!localStorage.getItem(ONBOARD_KEY)) showOnboard() } catch { /* 存储不可用时首次即显示一次 */ showOnboard() }
  homePage.appendChild(onboardCard)
  // S66·P0-1：待处理卡移到番茄钟**之前** —— 它是"现在要处理什么"的最高优先级表面。
  // 旧顺序（actions→番茄钟→感知→待处理）把待处理内容挤到折叠线以下：标题看得见、
  // 空态/计划行永远在视口外，用户截图就是"有标题没内容"（S66 用户定案的那起）。
  homePage.appendChild(pending)
  homePage.appendChild(pomodoroCard)
  // S54·D1 感知状态卡：七项真实审计指标（番茄钟入口旁）。缺数据显示 —，不装 0。
  const percepCard = el('div', 'ro-percep-card')
  percepCard.id = 'ro-percep-card'
  percepCard.dataset.card = 'perception' // S66·P0-2
  percepCard.dataset.cardTitle = '感知与记录'
  const percepRows = el('div', 'ro-percep-rows')
  percepCard.appendChild(el('div', 'ro-percep-title', '感知与记录'))
  percepCard.appendChild(percepRows)
  homePage.appendChild(percepCard)
  homePage.appendChild(homeBody)
  root.appendChild(homePage)

  // 二级页容器
  const trajPage = el('div', 's5-page')
  trajPage.id = 's5-trajectory'
  const trajBody = el('div', 's5-list')
  trajBody.dataset.card = 'trajectory' // S66·P0-2
  trajBody.dataset.cardTitle = '今日轨迹'
  trajPage.appendChild(trajBody)
  root.appendChild(trajPage)

  // 发布页（S7：结论发布面板——证据清单/编辑措辞/发布；证据不足不得发布）
  const publishPage = el('div', 's5-page')
  publishPage.id = 's5-publish'
  const pubNew = el('div', 's5-actions')
  pubNew.dataset.card = 'publish-new' // S66·P0-2
  pubNew.dataset.cardTitle = '新建结论'
  const pubLists = el('div', 's5-list')
  publishPage.appendChild(pubNew)
  publishPage.appendChild(pubLists)
  root.appendChild(publishPage)
  let pubClaims = null
  let pubDetail = null
  let pubSegments = []

  const notesPage = el('div', 's5-page')
  notesPage.id = 's5-notes'
  const notesBody = el('div', 's5-list')
  notesBody.dataset.card = 'notes' // S66·P0-2
  notesBody.dataset.cardTitle = '草稿'
  notesPage.appendChild(notesBody)
  root.appendChild(notesPage)

  // S47·P1：第 6 页「隐私」——只讲用户语义（哪些数据留、留多久），不放技术指标。
  // S52·设置页：诊断（高级）+ 隐私 + 实验室功能都收在这里；
  // 主面板只留直接交互的四个页。用户："设置应当放在左下角、齿轮形式"。
  const settingsPage = el('div', 's5-page')
  settingsPage.id = 's5-settings'
  const settingsBody = el('div', 's5-list')
  settingsPage.appendChild(settingsBody)
  root.appendChild(settingsPage)
  root.appendChild(dsFoot)

  // 主动询问卡（全局浮层，任何页面都可出现）
  const askCard = el('div', 's5-ask')
  askCard.id = 's5-ask'
  askCard.dataset.card = 'ask' // S66·P0-2（默认 display:none → 未弹出时跳过）
  askCard.dataset.cardTitle = '需要帮助吗'
  askCard.style.display = 'none'
  const askTitle = el('h4', '', '需要帮助吗？')
  const askReason = el('p', '')
  const askEvidence = el('p', '')
  const askBtns = el('div', 's5-ask-btns')
  const helpBtn = el('button', 'ro-btn', '需要帮助')
  helpBtn.type = 'button'
  const noBtn = el('button', 'ro-btn', '不用了')
  noBtn.type = 'button'
  askBtns.appendChild(helpBtn)
  askBtns.appendChild(noBtn)
  askCard.appendChild(askTitle)
  askCard.appendChild(askReason)
  askCard.appendChild(askEvidence)
  askCard.appendChild(askBtns)
  root.appendChild(askCard)

  // shell 的对话页元素（二级页：显示/隐藏由本文件控制）
  // S49：把 composer 也纳进来 —— 它 364×72 + 底部内边距 ≈ 90px，在首页一直挂着，
  // 就是"底部那块"；输入区本来就只属于对话页。
  const chatEls = ['transcript', 'prompt', 'composer', 'ro-welcome-base', 'page-title', 'input-label', 'history', 'new-conversation']
    .map((id) => doc.getElementById(id))
    .filter(Boolean)

  // ------------------------------------------------------------------
  // 动作按钮（≤5 主动作）
  // ------------------------------------------------------------------
  const learnBtn = el('button', 'ro-btn s5-act s5-wide', '开始学习')
  learnBtn.type = 'button'
  learnBtn.dataset.act = 'learn'
  const askScreenBtn = el('button', 'ro-btn s5-act', '问屏幕')
  askScreenBtn.type = 'button'
  const draftBtn = el('button', 'ro-btn s5-act', '新建草稿')
  draftBtn.type = 'button'
  const trajBtn = el('button', 'ro-btn s5-act', '今日轨迹')
  trajBtn.type = 'button'
  const sitesBtn = el('button', 'ro-btn s5-act', '最近网站')
  sitesBtn.type = 'button'
  actions.appendChild(learnBtn)
  actions.appendChild(askScreenBtn)
  actions.appendChild(draftBtn)
  actions.appendChild(trajBtn)
  actions.appendChild(sitesBtn)

  // 开始/结束学习：四态由 setLearnState 驱动（busy 期间禁用，禁止重复点击）
  learnBtn.addEventListener('click', () => {
    if (learnBusy) return
    clearFailureNotice() // 重新尝试即清除上一条失败原因
    learnStarting = learnBtn.textContent === '开始学习'
    setLearnState('busy')
    sendCmd('learn', learnStarting ? 'start' : 'stop')
  })

  // ------------------------------------------------------------------
  // 镜 4：对话页每条助手回复挂"转为结论"入口（真实 IPC → /claim new session）
  // ------------------------------------------------------------------
  const transcriptEl = doc.getElementById('transcript')
  if (transcriptEl && typeof MutationObserver === 'function') {
    const decorateAssistant = () => {
      for (const node of transcriptEl.querySelectorAll('.ro-msg.ro-assistant')) {
        if (node.dataset.claimDecorated === '1') continue
        node.dataset.claimDecorated = '1'
        const btn = el('button', 'ro-btn s5-toclaim', '转为结论')
        btn.type = 'button'
        btn.title = '把这条回复建成结论草稿；证据不足时会说明缺什么'
        btn.addEventListener('click', (ev) => {
          ev.stopPropagation()
          const text = (node.textContent || '').replace(/转为结论$/, '').trim().slice(0, 400)
          if (!text) { showAskNotice('这条回复是空的，无法建结论。'); return }
          sendCmd('claim', 'new session ' + text)
          go('publish')
        })
        node.appendChild(btn)
      }
    }
    new MutationObserver(decorateAssistant).observe(transcriptEl, { childList: true, subtree: true })
    decorateAssistant()
  }

  // ------------------------------------------------------------------
  // D4：等待态四态（进行中 / 禁用（说明原因）/ 成功 / 失败（原因+下一步））
  // ------------------------------------------------------------------
  let learnBusy = false
  let learnStarting = true
  let learningActive = false

  function setLearnState(state, reason) {
    learnBusy = state === 'busy'
    learnBtn.dataset.state = state
    learnBtn.disabled = learnBusy
    if (state === 'busy') {
      learnBtn.textContent = learnStarting ? '开始中…' : '结束中…'
      learnBtn.title = '进行中：请稍候，不要重复点击'
      return
    }
    if (state === 'idle') {
      learnBtn.textContent = learningActive ? '结束学习' : '开始学习'
      learnBtn.title = ''
      return
    }
    if (state === 'success') {
      learnBtn.textContent = learningActive ? '结束学习' : '开始学习'
      learnBtn.title = ''
      return
    }
    // failure：按钮保持可点（下一步动作），标题带原因；通知条给完整原因+下一步
    learnBtn.textContent = learningActive ? '结束学习' : '开始学习'
    learnBtn.title = reason || '操作失败'
  }

  // ------------------------------------------------------------------
  // D3：易变内容冻结（截图基线可比：状态条/通知条打桩，轮询暂停）
  // ------------------------------------------------------------------
  let frozen = false
  function freezeVolatile() {
    frozen = true
    document.body.classList.add('ro-frozen')
    statusStrip.textContent = ''
    statusStrip.appendChild(el('span', 's5-chip s5-strong', '● 本地感知中'))
    statusStrip.appendChild(el('span', 's5-chip', '状态：learning'))
    statusStrip.appendChild(el('span', 's5-chip', '同意：session'))
    statusStrip.appendChild(el('span', 's5-chip', '今日学习 N 分钟'))
    statusStrip.appendChild(el('span', 's5-chip', '原图剩余 N 分钟'))
    noticeBar.style.display = 'none'
    return true
  }
  function unfreezeVolatile() {
    frozen = false
    document.body.classList.remove('ro-frozen')
    sendCmd('panel', 'status')
    return true
  }
  askScreenBtn.addEventListener('click', () => sendCmd('panel', 'help'))
  draftBtn.addEventListener('click', () => sendCmd('panel', 'newdraft'))
  trajBtn.addEventListener('click', () => go('trajectory'))
  sitesBtn.addEventListener('click', () => sendCmd('panel', 'sites'))
  backBtn.addEventListener('click', () => go('home'))
  chatBtn.addEventListener('click', () => go('chat'))
  const pubBtn = el('button', 'ro-btn s5-back', '发布')
  pubBtn.type = 'button'
  pubBtn.title = '结论发布（证据闸）'
  pubBtn.addEventListener('click', () => go('publish'))
  // S47·P1：不再挂到顶栏（导航由左侧 6 项承担）；元素保留，既有逻辑仍可引用。

  // ------------------------------------------------------------------
  // S52·B3：主动作**不许静默**。用户实测「开始学习/问屏幕/新建草稿/最近网站」点了没反应。
  // /learn 确实有实现（timeline 插件重激活 perception），但反馈不可见；其余命令未确认接入。
  // 统一包一层：点击后 1.2s 给一句明确说法，不依赖后端是否回包。
  // 「今日轨迹」不加 —— 它自己会切页，有可见反馈。
  // ------------------------------------------------------------------
  function wireAction(btn, label, hint) {
    if (!btn) return
    btn.addEventListener('click', () => {
      const t0 = Date.now()
      setTimeout(() => {
        if (frozen) return
        // S55：1.2s 内若已有真回包（回包处理里写 btn.dataset.repliedAt），不再兜底 ——
        // 兜底文案会覆盖真实结果/错误提示（R-7 实测：need-consent 的"需要授权"被"已触发"盖掉）。
        if (Number(btn.dataset.repliedAt || 0) >= t0) return
        showAskNotice(`「${label}」${hint || '已触发。'}`)
      }, 1200)
    })
  }
  wireAction(learnBtn, '开始学习', '已触发：开始/结束本地感知，状态会同步到诊断区。')
  wireAction(askScreenBtn, '问屏幕', '已发送。若几秒内没有新草稿，说明该功能尚未开放。')
  wireAction(draftBtn, '新建草稿', '已发送。新草稿会出现在「笔记」页。')
  wireAction(sitesBtn, '最近网站', '已发送。若列表为空，说明今天还没有采样到站点。')

  helpBtn.addEventListener('click', () => {
    hideAsk()
    sendCmd('panel', 'help')
  })
  noBtn.addEventListener('click', () => {
    hideAsk()
    sendCmd('panel', 'reject')
  })

  function sendCmd(name, args) {
    send('ui', { type: 'plugin:command', name, args })
  }

  // ------------------------------------------------------------------
  // 页面切换（含对话二级页的 shell 元素显隐 + 页面记忆）
  // ------------------------------------------------------------------
  function go(next) {
    if (!PAGES.includes(next)) next = 'home'
    // S54·D5 导航审计：每次 go() 记录 { 时间, from, to, 调用栈 6 帧 } 到 window.__navTrail。
    // 诊断/E2E 脚本经 CDP 读取后落 nav-calls.jsonl（不经 IPC，真实 data 零写入）。
    // 价值长期保留：任何"莫名切页"类缺陷，取证直接看这里，不用再猜。
    try {
      const stack = String(new Error().stack || '').split('\n').slice(2, 8).map((s) => s.trim()).join(' <- ')
      const trail = (globalThis.__navTrail = globalThis.__navTrail || [])
      trail.push({ t: Date.now(), from: page, to: next, stack })
      if (trail.length > 200) trail.shift()
    } catch { /* 审计失败不影响导航 */ }
    page = next
    clearFailureNotice()
    try { localStorage.setItem(PAGE_KEY, page) } catch { /* noop */ }
    render()
  }

  // S54·D5 自激循环守卫：render() 的数据拉取只在"页真正切换"时发。
  // 真凶链（diag-b2-nav 实测 199 条 trajectory→trajectory）：
  //   go('trajectory') → render() → sendCmd('timeline') → 回包 → go('trajectory') 重渲染
  //   → render() 又 sendCmd('timeline') → 无限自激（CPU 空转 + 审计涨满）。
  // S51 只守了"非轨迹页不切页"（B2 表面症状），这条守卫断掉循环本体。
  // 初始 mount 时 was=null ≠ 'home' → 首次拉取行为不变；__s5.refresh 是纯拉取不受影响。
  let lastRenderedPage = null
  function render() {
    const was = lastRenderedPage
    lastRenderedPage = page
    const onChat = page === 'chat'
    homePage.classList.toggle('s5-on', page === 'home')
    trajPage.classList.toggle('s5-on', page === 'trajectory')
    notesPage.classList.toggle('s5-on', page === 'notes')
    publishPage.classList.toggle('s5-on', page === 'publish')
    // 对话页 = shell 自己的元素（二级页）
    for (const n of chatEls) {
      try { n.style.display = onChat ? '' : 'none' } catch { /* noop */ }
    }
    // 首页自己收起来时，顶栏只留面包屑（对话页由底座自己管）
    topbar.style.display = onChat ? 'flex' : 'flex'
    settingsPage.classList.toggle('s5-on', page === 'settings')
    if (page === 'settings') renderSettings()
    // S47·P1：导航高亮（6 项、label 唯一）+ 底栏用户语义同步
    for (const [navPage, navBtn] of navBtns) {
      if (navPage === page) navBtn.setAttribute('aria-current', 'page')
      else navBtn.removeAttribute('aria-current')
    }
    syncChrome()
    crumb.textContent = { home: '首页', chat: '对话', trajectory: '轨迹', notes: '笔记', publish: '发布', settings: '设置' }[page] || '首页'
    backBtn.style.visibility = page === 'home' ? 'hidden' : 'visible'
    if (page === 'trajectory' && was !== 'trajectory') sendCmd('timeline', '')
    if (page === 'notes' && was !== 'notes') sendCmd('panel', 'drafts')
    if (page === 'home' && was !== 'home') sendCmd('panel', 'status')
    if (page === 'publish' && was !== 'publish') { sendCmd('claim', 'claims'); sendCmd('timeline', '') }
    if (onChat && scrollToEnd) scrollToEnd()
  }

  // ------------------------------------------------------------------
  // 首页渲染（状态条 / 待处理区）
  // ------------------------------------------------------------------
  function renderStatus(d) {
    statusData = d
    if (d && d.learning) learningActive = !!d.learning.active
    if (frozen) return // D3：冻结期保持打桩值，任何 status 下行都不覆盖
    statusStrip.textContent = ''
    if (!d) {
      statusStrip.appendChild(el('span', 's5-chip', '状态加载中…'))
      return
    }
    const p = d.perception || {}
    const live = p.running === true
    statusStrip.appendChild(el('span', 's5-chip' + (live ? ' s5-strong' : ''), live ? '● 本地感知中' : '○ 已暂停'))
    if (p.state) statusStrip.appendChild(el('span', 's5-chip', `状态：${p.state}`))
    if (p.mode) statusStrip.appendChild(el('span', 's5-chip', `同意：${p.mode}`))
    if (d.learning && d.learning.active) {
      statusStrip.appendChild(el('span', 's5-chip s5-strong', '学习中'))
    }
    statusStrip.appendChild(el('span', 's5-chip', `今日学习 ${fmtDur(Math.round((d.learning ? d.learning.todayMs : 0) / 1000))}`))
    if (d.frameRemainingMs != null && d.frameRemainingMs > 0) {
      statusStrip.appendChild(el('span', 's5-chip', `原图剩余 ${Math.max(1, Math.round(d.frameRemainingMs / 60000))} 分钟`))
    }
    if (d.storeReady === false) statusStrip.appendChild(el('span', 's5-chip', '生命周期库未接入'))
    // S66·P0-1 待处理区：计划驱动（到期行+完成按钮 / 分状态空态+可点按钮）。
    // 旧的"草稿待确认/主动建议"两行是退化内容（值只有"无/可按需询问"）且被折叠在视口外，
    // 是"有标题没内容"的最后一起；现由 renderPending 统一供给（见下方契约注释）。
    renderPending(d)
    learnBtn.textContent = d.learning && d.learning.active ? '结束学习' : '开始学习'
    learningActive = !!(d.learning && d.learning.active)
    // D4：failure 是粘滞态（保留原因标题），不被轮询重置；busy 时任何刷新都不碰按钮
    if (!learnBusy && learnBtn.dataset.state !== 'failure') { learnBtn.dataset.state = 'idle'; learnBtn.disabled = false; learnBtn.title = '' }
    // S54·D1 感知状态卡（七项真实审计指标；缺数据 —，不装 0）
    renderPerceptionCard(d.perceptionCard || null)
    // S58·P0-3：预算诊断（level / metrics / 阈值 / 各级 fired）
    renderBudgetDiag(d.budget || null)
    // S60·P0-4：视觉 provider 诊断
    renderVisionDiag(d.vision || null)
    updateTrajEmpty()
  }

  // ------------------------------------------------------------------
  // S66·P0-1 待处理卡（计划闭环在首页的唯一入口）
  // 契约（与任务书逐条对应）：
  //   ① 有到期计划 → 计划行（文本 + 到期标注 + [完成] 按钮 → /panel plans-done <id>，真勾销）
  //   ② 有计划未到期 → [data-empty-state]「有 N 条计划待办，最近一条 HH:MM 到期」+ [查看计划] 按钮
  //   ③ 无计划 → [data-empty-state]「今天没有待办。日报会在这里给你 1–3 条建议。」+ [看日报] 按钮
  // 三种形态都满足"标题 + 内容或空态节点 + 空态必带可点按钮"（accept-s66-cards.mjs 逐卡断言）。
  // 数据源：timeline /panel status 回包的 plans/report 字段（读 coach 计划账与今日日报文件，只读）。
  // ------------------------------------------------------------------
  function hhmm(iso) {
    const t = iso ? Date.parse(iso) : NaN
    return Number.isFinite(t) ? new Date(t).toTimeString().slice(0, 5) : '--:--'
  }
  function dueLabel(p, nowMs) {
    const t = p.dueAt ? Date.parse(p.dueAt) : NaN
    if (!Number.isFinite(t)) return '未设到期'
    return t <= nowMs ? '已到期' : `${hhmm(p.dueAt)} 到期`
  }
  function planRow(p, nowMs) {
    const row = el('div', 's5-row s5-plan-row')
    row.appendChild(el('span', 's5-grow', p.text || p.id))
    const sub = el('span', 's5-sub', dueLabel(p, nowMs))
    if (p.dueAt && Date.parse(p.dueAt) <= nowMs) row.classList.add('s5-plan-over')
    row.appendChild(sub)
    const doneBtn = el('button', 'ro-btn', '完成')
    doneBtn.type = 'button'
    doneBtn.title = `勾销计划 ${p.id}（写入 coach 计划账，只勾一次）`
    doneBtn.addEventListener('click', (ev) => {
      ev.stopPropagation() // 不触发行点击（行无动作也要防冒泡到列表容器）
      doneBtn.disabled = true
      sendCmd('panel', 'plans-done ' + p.id)
    })
    row.appendChild(doneBtn)
    return row
  }
  /** 看日报：进对话页给一句真摘要（评分/轨迹/建议数）；今天没有日报就明说。 */
  function onSeeReport() {
    const rep = statusData && statusData.report
    if (rep && rep.exists) {
      go('chat')
      // score 口径：readDailyReport 原样捕获评分行（"82 / 100" 或 "unavailable（…）"），此处不再拼 "/ 100"
      const bits = [`今日日报：评分 ${rep.score != null ? rep.score : '—'}`]
      if (rep.trajectoryTotal != null) bits.push(`轨迹 ${rep.trajectoryTotal} 条`)
      bits.push(`建议 ${(rep.advice || []).length} 条`)
      const first = (rep.advice || [])[0]
      showAskNotice(bits.join(' · ') + (first ? `。第一条：${first}` : '。'))
    } else {
      showAskNotice('今天还没有生成日报——学习结束后运行日报，这里会出现 1–3 条建议。')
    }
  }
  /** 今日建议（来自日报文件，≤3 条；没有日报就不渲染这一段）。 */
  function appendAdvice(rep) {
    if (!rep || !rep.exists || !Array.isArray(rep.advice) || !rep.advice.length) return
    pending.appendChild(el('div', 's5-sec', '今日建议（来自日报）'))
    for (const a of rep.advice.slice(0, 3)) {
      const row = el('div', 's5-row')
      row.appendChild(el('span', 's5-grow', a))
      row.addEventListener('click', onSeeReport)
      pending.appendChild(row)
    }
  }
  function renderPending(d) {
    pending.textContent = ''
    pending.appendChild(el('div', 's5-sec', '待处理'))
    const plans = (d && d.plans) || { due: [], upcoming: [], pendingCount: 0, nextDueAt: null }
    const nowMs = Date.now()
    const due = Array.isArray(plans.due) ? plans.due : []
    const upcoming = Array.isArray(plans.upcoming) ? plans.upcoming : []
    const rep = (d && d.report) || null
    if (due.length) {
      // ① 现在就要处理的：每条一个完成按钮
      for (const p of due) pending.appendChild(planRow(p, nowMs))
      if (upcoming.length) {
        const more = el('div', 's5-row')
        more.appendChild(el('span', 's5-grow', `还有 ${upcoming.length} 条计划待办，最近一条 ${hhmm(upcoming[0].dueAt)} 到期`))
        more.addEventListener('click', () => { plansExpanded = !plansExpanded; renderPending(statusData) })
        pending.appendChild(more)
        if (plansExpanded) for (const p of upcoming) pending.appendChild(planRow(p, nowMs))
      }
      appendAdvice(rep)
      return
    }
    if (upcoming.length) {
      // ② 有计划但都未到期：空态给摘要 + 查看计划（展开看不到期行）
      const box = emptyState(`有 ${upcoming.length} 条计划待办，最近一条 ${hhmm(upcoming[0].dueAt)} 到期`, '查看计划', () => {
        plansExpanded = !plansExpanded
        renderPending(statusData)
      })
      pending.appendChild(box)
      if (plansExpanded) for (const p of upcoming) pending.appendChild(planRow(p, nowMs))
      appendAdvice(rep)
      return
    }
    // ③ 一条计划都没有：空态说明日报会补建议 + 看日报
    pending.appendChild(emptyState('今天没有待办。日报会在这里给你 1–3 条建议。', '看日报', onSeeReport))
    appendAdvice(rep)
  }

  /** 视觉 provider 诊断行（真实配置 + 最近一次调用延迟；不写假数）。 */
  function renderVisionDiag(v) {
    if (!visionDiag) return
    visionDiag.textContent = ''
    if (!v) { visionDiag.appendChild(el('div', 'ds-t11', '视觉 provider：未知')); return }
    if (!v.configured) {
      visionDiag.appendChild(el('div', 'ds-t11', `视觉 provider：未配置（${v.reason || '—'}）`))
      return
    }
    const ready = v.ready ? '就绪' : '未就绪'
    const last = v.lastMs != null ? `最近 ${Math.round(v.lastMs)} ms` : '尚无调用'
    visionDiag.appendChild(el('div', 'ds-t11', `视觉 provider：${v.providerId || '—'} · ${v.model || '—'}（${ready}；${last}）`))
  }

  /** 预算诊断渲染（只展示真实采样值；无数据写"等待采样"，不写假数）。 */
  function renderBudgetDiag(b) {
    if (!budgetDiag) return
    budgetDiag.textContent = ''
    if (!b || !b.metrics) {
      budgetDiag.appendChild(el('div', 'ds-t11', '预算诊断：等待首次采样（约 60s 一轮）…'))
      return
    }
    const n1 = (v, u) => (Number.isFinite(Number(v)) ? Number(v).toFixed(1) + u : '—')
    const m = b.metrics || {}
    const t = b.thresholds || {}
    budgetDiag.appendChild(el('div', 'ds-t12',
      `预算 L${b.level} ｜ cpuAvg ${n1(m.cpuAvg, '%')}/≤${n1(t.cpuAvg, '%')} ｜ cpuP95 ${n1(m.cpuP95, '%')}/≤${n1(t.cpuP95, '%')} ｜ mem ${n1(m.memMB, 'MB')}/≤${n1(t.memMB, 'MB')}`))
    const fired = Array.isArray(b.fired) ? b.fired : []
    budgetDiag.appendChild(el('div', 'ds-t11',
      '各级 trigger：' + (fired.length ? fired.map((f) => `L${f.level}${f.fired ? '✔' : '✘'}`).join(' ') : '—') +
      (b.at ? `（${new Date(b.at).toTimeString().slice(0, 5)}）` : '')))
  }

  // S55·C3：轨迹空态文案随感知状态切换（关："自动记录已关闭" / 开："今天没检出学习片段"）。
  function updateTrajEmpty() {
    try {
      const box = trajBody.nextElementSibling
      if (!box || !box.hasAttribute || !box.hasAttribute('data-empty-state')) return
      const on = !!(statusData && statusData.perception && statusData.perception.running === true)
      const t = box.querySelector('.ds-empty-text')
      if (t) t.textContent = on ? '今天没有检出学习片段（你可能在调试工具）。' : '自动记录已关闭，所以今天没有轨迹。'
      const b = box.querySelector('button')
      if (b) b.textContent = on ? '手动记一条' : '开启记录'
      box.setAttribute('data-perception-on', on ? '1' : '0')
    } catch { /* 空态不在或结构变了都不影响主渲染 */ }
  }

  // 感知状态卡：perceptionCard 字段全来自审计/文件系统（timeline 插件聚合），UI 只做人话渲染。
  function renderPerceptionCard(card) {
    if (!percepRows) return
    const rows = []
    const live = statusData && statusData.perception && statusData.perception.running === true
    rows.push(['感知', live === true ? '● 开' : live === false ? '○ 关' : '—'])
    const n = (v) => (Number.isFinite(Number(v)) ? String(v) : '—')
    rows.push(['今日采样', card && card.samplesToday != null ? `${card.samplesToday} 次` : '—'])
    // S56：主指标名实一致 —— "已压缩送模"= sent-to-model 审计事件数，括号内是真实字节差；
    // 副标"原图已删"是另一件事（零明文留存），不混成一个数。
    const sentN = card && card.compressedSentToday != null ? `${card.compressedSentToday} 张` : '—'
    const savedMb = card && card.compressedSentToday > 0 && Number.isFinite(Number(card.savedBytesEstimate))
      ? `（省 ${(card.savedBytesEstimate / 1048576).toFixed(1)} MB）`
      : ''
    rows.push(['已压缩送模', sentN + savedMb])
    rows.push(['原图已删', card && card.originalsDeletedToday != null ? `${card.originalsDeletedToday} 张` : '—', 'sub'])
    rows.push(['今日片段', card && card.segmentsToday != null ? `${card.segmentsToday} 条` : '—'])
    rows.push(['最近采样', card && card.lastSampleTs > 0 ? new Date(card.lastSampleTs).toTimeString().slice(0, 5) : '—'])
    // S56：省 MB 已并入「已压缩送模」括号，不再单列（避免同一件事出现两个数）
    rows.push(['本次会话轨迹', card && card.sessionSegments != null ? `${card.sessionSegments} 条` : '—'])
    percepRows.textContent = ''
    for (const [k, v, kind] of rows) {
      const r = el('div', 'ro-percep-row' + (kind === 'sub' ? ' ro-percep-sub' : ''))
      r.appendChild(el('span', 'ro-percep-k', k))
      r.appendChild(el('span', 'ro-percep-v', v))
      percepRows.appendChild(r)
    }
  }

  // ------------------------------------------------------------------
  // 12 态调试渲染（/ui state <name>；window.__s5.setState 同效）
  // ------------------------------------------------------------------
  function setState(name) {
    if (!STATES.includes(name)) return false
    uiState = name
    go('home')
    statusStrip.textContent = ''
    const map = {
      'default': ['● 待机', '默认态：未开始感知。'],
      'monitoring': ['● 本地感知中', '监控中：1Hz 廉价信号采集中。'],
      'paused': ['○ 已暂停', '已暂停采集（同意保持）。'],
      'no-consent': ['⚠ 未同意', '未同意：需授予 session 同意才能抓屏。'],
      'learning-candidate': ['◇ 学习候选', '停留接近阈值，候选学习片段。'],
      'learning': ['◆ 学习中', 'learning 态：1Hz + 差分抑制截图。'],
      'silent': ['− 静默', '静默：不提示、不打扰。'],
      'needs-confirm': ['? 需确认', '需确认：有待你决定的草稿或授权。'],
      'success': ['✓ 成功', '成功：操作完成（草稿已晋升/学习已落账）。'],
      'failure': ['✗ 失败', '失败：原因见下，按下一步操作重试。'],
      'offline': ['☂ 离线', '离线：出网被拒，白名单外不可用。'],
      'deleted': ['⌫ 已删除', '已删除：原图按保留策略清理，仅剩摘要与哈希。'],
    }
    const [chip, desc] = map[name] || map['default']
    statusStrip.appendChild(el('span', 's5-chip s5-strong', chip))
    homeBody.textContent = ''
    homeBody.appendChild(el('div', 's5-note', `【调试态 ${name}】${desc}`))
    if (name === 'deleted') {
      homeBody.appendChild(el('div', 's5-note', '原图已按保留策略删除；保留时间、窗口、摘要与内容哈希，无法恢复画面。'))
    }
    return true
  }

  // ------------------------------------------------------------------
  // 主动询问卡
  // ------------------------------------------------------------------
  function showAsk(d) {
    hideAsk()
    if (!d || d.phase !== 'asking') return
    askReason.textContent = `为什么现在提示：${d.reason || '（未给出）'}`
    askEvidence.textContent = `用了哪些证据：evidence_id=${d.evidenceId || '（无）'}`
    askCard.style.display = ''
    if (R.setOrbExpression) R.setOrbExpression('need-help') // 球面表情：请求帮助
  }
  function hideAsk() {
    askCard.style.display = 'none'
    if (R.setOrbExpression) R.setOrbExpression('clear') // 询问卡收起 → 清除粘滞表情
  }
  // 首页可见通知条（addNotice 只进对话页的 transcript；首页必须也能看见）
  const noticeBar = el('div', 's5-note')
  noticeBar.id = 's5-notice'
  noticeBar.style.display = 'none'
  noticeBar.setAttribute('role', 'status')
  homePage.appendChild(noticeBar)
  let noticeTimer = null

  function showAskNotice(text) {
    hideAsk()
    clearFailureNotice()
    if (addNotice) addNotice('info', text)
    // 首页可见条（6s 自动收起）
    noticeBar.textContent = text
    noticeBar.style.display = ''
    noticeBar.className = 's5-note'
    if (noticeTimer) clearTimeout(noticeTimer)
    noticeTimer = setTimeout(() => { noticeBar.style.display = 'none' }, 6000)
  }

  /** D4 失败态：原因 + 下一步动作。**粘滞**（不自动消失）——失败信息不得让用户错过；
   *  直到下一次用户动作（切页/点任何主动作/新通知）才清除。 */
  function showFailure(text) {
    hideAsk()
    if (addNotice) addNotice('error', text)
    noticeBar.textContent = '⚠ ' + text
    noticeBar.style.display = ''
    noticeBar.className = 's5-note s5-failure'
    noticeBar.dataset.failure = '1'
    if (noticeTimer) { clearTimeout(noticeTimer); noticeTimer = null }
    if (R.setOrbExpression) R.setOrbExpression('error') // 球面表情：出错（粘滞）
  }

  /** 清除粘滞失败通知（用户动作/切页时）。 */
  function clearFailureNotice() {
    if (noticeBar.dataset.failure === '1') {
      noticeBar.dataset.failure = ''
      noticeBar.className = 's5-note'
      noticeBar.style.display = 'none'
      if (R.setOrbExpression) R.setOrbExpression('clear') // 失败表情随用户动作清除
    }
  }

  // ------------------------------------------------------------------
  // 轨迹页（日→片段→事件 三级）
  // ------------------------------------------------------------------
  function renderTrajectory(d) {
    trajBody.textContent = ''
    // S66·P0-2：卡片标题常驻（空态也有标题，杜绝"有标题没内容"的判定歧义）
    trajBody.appendChild(el('div', 's5-sec', '今日轨迹'))
    if (!d || !d.segments || d.segments.length === 0) {
      trajBody.appendChild(el('div', 's5-note', d && d.degraded ? '今天还没有片段（生命周期库未接入，证据状态无法对账）。' : '今天还没有片段。'))
      return
    }
    trajBody.appendChild(el('div', 's5-sec', `片段（${d.day}）`))
    for (const s of d.segments) {
      const wrap = el('div', '')
      const row = el('div', 's5-row')
      const t = s.startedAt ? new Date(s.startedAt).toTimeString().slice(0, 5) : '--:--'
      const outcome = { promoted: '已晋升', discarded: '已丢弃', rejected: '已婉拒', stopped: '已结束', pending: '进行中/草稿' }[s.outcome] || s.outcome
      row.appendChild(el('span', 's5-grow', `${t} [${outcome}] ${fmtDur(Math.round((s.durationMs || 0) / 1000))}`))
      row.appendChild(el('span', 's5-sub', `置信度=${s.confidence ?? '-'} 证据=${s.evidenceCount}`))
      const expanded = { done: false }
      row.addEventListener('click', () => {
        expanded.done = !expanded.done
        det.style.display = expanded.done ? '' : 'none'
      })
      wrap.appendChild(row)
      const det = el('div', 's5-evidence')
      det.style.display = 'none'
      det.appendChild(el('div', '', `片段 ${s.id} · 状态=${s.state} · 事件=${s.eventCount != null ? s.eventCount : 0} 条`))
      if (s.notePath) det.appendChild(el('div', '', `正式笔记：${s.notePath.split('\\').pop()}`))
      for (const e of s.evidence || []) {
        const line = el('div', '', `${e.evidence_id} — ${e.status === 'deleted' ? '⚠ ' : e.status === 'available' ? '🖼 ' : '· '}${e.label}`)
        det.appendChild(line)
      }
      for (const ev of (s.events || []).slice(0, 8)) {
        det.appendChild(el('div', '', `· 事件 ${ev.type || '-'}${ev.title ? '（' + ev.title + '）' : ''}`))
      }
      wrap.appendChild(det)
      trajBody.appendChild(wrap)
    }
  }

  // ------------------------------------------------------------------
  // 发布页（S7：结论发布面板）+ 统一证据标签（D9）
  // ------------------------------------------------------------------

  /** 统一证据标签（D9）：direct/derived/none 同一套视觉与文案；none 一律降级。 */
  function evBadge(relation, mode) {
    if (relation === 'none' || mode === 'none') {
      const b = el('span', 's5-badge s5-none', '⚠ 无直接证据（不得作为事实）')
      b.title = 'CONTRACT §6：none 证据不得用事实语气、不得晋升长期记忆、不得触发自动工具'
      return b
    }
    return el('span', 's5-badge', relation === 'derived' ? '派生证据' : '直接证据')
  }

  function renderPublishNew() {
    pubNew.textContent = ''
    pubNew.appendChild(el('div', 's5-sec', '新建结论（从轨迹片段 / 笔记 / 自由文本）'))
    const segBtn = el('button', 'ro-btn s5-act', '从轨迹片段建')
    segBtn.type = 'button'
    segBtn.addEventListener('click', () => {
      pubLists.textContent = ''
      pubLists.appendChild(el('div', 's5-sec', '选一个今天的片段建结论（证据=该片段的原图）'))
      if (!pubSegments.length) pubLists.appendChild(el('div', 's5-note', '今天还没有片段（先跑一次学习主线）。'))
      for (const s of pubSegments.slice(-8).reverse()) {
        const row = el('div', 's5-row')
        row.appendChild(el('span', 's5-grow', `${s.id} · ${fmtDur(Math.round((s.durationMs || 0) / 1000))} · 证据${s.evidenceCount}`))
        row.appendChild(el('span', 's5-sub', s.outcome || ''))
        row.addEventListener('click', () => sendCmd('claim', 'new seg ' + s.id))
        pubLists.appendChild(row)
      }
    })
    const noteBtn = el('button', 'ro-btn s5-act', '从笔记建')
    noteBtn.type = 'button'
    noteBtn.addEventListener('click', () => {
      pubLists.textContent = ''
      pubLists.appendChild(el('div', 's5-sec', '从笔记建结论（笔记无证据链 → 无直接证据，不可发布）'))
      const row = el('div', 's5-row')
      row.appendChild(el('span', 's5-grow', 'data/notes/（正式笔记）'))
      row.addEventListener('click', () => sendCmd('claim', 'new note notes-root'))
      pubLists.appendChild(row)
    })
    const textBtn = el('button', 'ro-btn s5-act', '自由文本')
    textBtn.type = 'button'
    textBtn.addEventListener('click', () => {
      pubLists.textContent = ''
      const ta = doc.createElement('textarea')
      ta.className = 's5-input'
      ta.rows = 3
      ta.placeholder = '输入结论文本（无证据链 → 无直接证据，不可发布）'
      const ok = el('button', 'ro-btn', '建成草稿')
      ok.type = 'button'
      ok.style.minHeight = '40px'
      ok.addEventListener('click', () => { if (ta.value.trim()) sendCmd('claim', 'new text ' + ta.value.trim()) })
      pubLists.appendChild(ta)
      pubLists.appendChild(ok)
    })
    pubNew.appendChild(segBtn)
    pubNew.appendChild(noteBtn)
    pubNew.appendChild(textBtn)
  }

  function renderClaims(d) {
    pubClaims = (d && d.claims) || []
    renderPublishNew()
    pubLists.textContent = ''
    pubLists.appendChild(el('div', 's5-sec', `结论（${pubClaims.length}）`))
    if (!pubClaims.length) pubLists.appendChild(el('div', 's5-note', '还没有结论。用上面的入口从轨迹片段建一条（带原图证据）。'))
    for (const c of pubClaims) {
      const wrap = el('div', '')
      const row = el('div', 's5-row')
      row.appendChild(el('span', 's5-grow', `${c.id} [${c.status}] ${String(c.text || '').slice(0, 24)}`))
      row.appendChild(evBadge(c.evidenceMode === 'none' ? 'none' : 'direct', c.evidenceMode))
      row.appendChild(el('span', 's5-sub', `证据${c.publishableEvidence}`))
      row.addEventListener('click', () => sendCmd('claim', c.id))
      wrap.appendChild(row)
      pubLists.appendChild(wrap)
    }
  }

  function renderClaimDetail(d) {
    pubDetail = d
    renderPublishNew()
    pubLists.textContent = ''
    pubLists.appendChild(el('div', 's5-sec', `结论 ${d.claimId} [${d.status}]`))
    // 措辞编辑（仅草稿；已发布不可改——保持发布时快照）
    if (d.status === 'draft') {
      const ta = doc.createElement('textarea')
      ta.className = 's5-input'
      ta.rows = 3
      ta.value = d.text || ''
      ta.setAttribute('aria-label', '结论措辞')
      const save = el('button', 'ro-btn', '保存措辞')
      save.type = 'button'
      save.style.minHeight = '32px'
      save.addEventListener('click', () => { if (ta.value.trim()) sendCmd('claim', d.claimId + ' text ' + ta.value.trim()) })
      pubLists.appendChild(ta)
      pubLists.appendChild(save)
    } else {
      pubLists.appendChild(el('div', 's5-note', `已发布（${d.publishedAt || ''}），措辞锁定为发布时快照。`))
      // 镜 4：导出（md + docx；文件落在 data/exports/，验收可核内容）
      const exportBtn = el('button', 'ro-btn s5-act', '导出结论（md+docx）')
      exportBtn.type = 'button'
      exportBtn.title = '导出结论正文 + evidence_id 清单 + 每条证据当前可用性 + 导出时间与版本'
      exportBtn.addEventListener('click', () => sendCmd('claim', 'export ' + d.claimId))
      pubLists.appendChild(exportBtn)
    }
    // 证据清单（evidence_id + 类型 + 当前可用性）
    pubLists.appendChild(el('div', 's5-sec', `证据 ${d.evidence.length} 条（可发布 ${d.publishableEvidence}）`))
    for (const e of d.evidence) {
      const row = el('div', 's5-row')
      row.style.cursor = 'default'
      row.appendChild(el('span', 's5-grow', `${e.evidence_id}`))
      row.appendChild(evBadge(e.relation, d.evidenceMode))
      const st = el('span', 's5-sub', e.label)
      if (e.status === 'deleted') st.className = 's5-sub s5-deleted'
      row.appendChild(st)
      pubLists.appendChild(row)
    }
    // 补证据（镜 4：缺证据 → 补 → 发布）；已发布结论不可改
    if (d.status === 'draft') {
      const attachBox = el('div', 's5-actions')
      const attachFrame = el('button', 'ro-btn s5-act', '关联今日原图')
      attachFrame.type = 'button'
      attachFrame.title = '把今天采集到的一帧原图挂为直接证据'
      attachFrame.addEventListener('click', () => sendCmd('claim', 'attach ' + d.claimId + ' frame'))
      const attachSeg = el('button', 'ro-btn s5-act', '关联今日片段')
      attachSeg.type = 'button'
      attachSeg.title = '把今天最近一个学习片段的原图挂为直接证据'
      attachSeg.addEventListener('click', () => sendCmd('claim', 'attach ' + d.claimId + ' latest-seg'))
      attachBox.appendChild(attachFrame)
      attachBox.appendChild(attachSeg)
      pubLists.appendChild(attachBox)
    }
    // 发布区
    if (d.status === 'draft') {
      if (d.canPublish) {
        const pub = el('button', 'ro-btn s5-act s5-wide', '发布')
        pub.type = 'button'
        pub.addEventListener('click', () => sendCmd('claim', 'publish ' + d.claimId))
        pubLists.appendChild(pub)
      } else {
        const why = d.evidenceMode === 'none'
          ? '不可发布：该结论无直接证据（evidence_mode=none）。契约 §6 禁止以事实语气发布——请补直接/派生证据，或改成假设语气另存为草稿。'
          : `不可发布：缺可回指证据（非 none 证据 ${d.publishableEvidence} 条）。请先从轨迹片段/原图关联证据。`
        pubLists.appendChild(el('div', 's5-note s5-none', '⚠ ' + why))
      }
    }
  }

  // ------------------------------------------------------------------
  // 笔记页（草稿 + 晋升/丢弃）
  // ------------------------------------------------------------------
  function renderNotes(d) {
    notesBody.textContent = ''
    notesBody.appendChild(el('div', 's5-sec', '草稿（data/drafts，与正式笔记物理隔离）'))
    const drafts = (d && d.drafts) || []
    if (drafts.length === 0) {
      notesBody.appendChild(el('div', 's5-note', '没有待确认草稿。'))
    }
    for (const name of drafts) {
      const row = el('div', 's5-row')
      row.appendChild(el('span', 's5-grow', name))
      const promoteBtn = el('button', 'ro-btn', '晋升')
      promoteBtn.type = 'button'
      promoteBtn.style.minHeight = '32px'
      const discardBtn = el('button', 'ro-btn', '丢弃')
      discardBtn.type = 'button'
      discardBtn.style.minHeight = '32px'
      promoteBtn.addEventListener('click', (ev) => { ev.stopPropagation(); sendCmd('panel', 'promote ' + name) })
      discardBtn.addEventListener('click', (ev) => { ev.stopPropagation(); sendCmd('panel', 'discard ' + name) })
      row.appendChild(promoteBtn)
      row.appendChild(discardBtn)
      notesBody.appendChild(row)
    }
  }

  // ------------------------------------------------------------------
  // 下行：plugin:panel（timeline 插件的所有 ui payload 都走这条）
  // ------------------------------------------------------------------
  // S55·D：面板消息按 pluginId 路由（dispatchPanel：byId || fallback）。home-v1 此前只注册了
  // timeline，其他插件（如 perception 的授权回执 ui.kind='consent'）全部被静默丢弃。
  // fallback 只处理已知 kind，其余忽略 —— 不改 timeline 的正常路径。
  if (typeof R.onPanelFallback === 'function') {
    R.onPanelFallback((message) => {
      const ui = message && message.ui
      if (!ui || typeof ui !== 'object') return
      if (ui.kind === 'consent') {
        showAskNotice(ui.phase === 'granted'
          ? '已授权屏幕记录：4 小时内有效，应用重启后需重新授权。现在点「开始学习」即可记录轨迹。'
          : '授权状态已更新。')
      }
    })
  }
  R.onPanel('timeline', (message) => {
    const ui = message && message.ui
    if (!ui) return
    if (ui.kind === 'status') renderStatus(ui)
    else if (ui.kind === 'state') setState(ui.state)
    else if (ui.kind === 'ask') {
      if (ui.phase === 'asking') showAsk(ui)
      else if (ui.phase === 'rejected') showAskNotice('已减少此类提醒（24 小时内不再询问）。')
      else if (ui.phase === 'cooling') showAskNotice(`冷却中（剩余 ${ui.remainingHours} 小时）：不再询问。`)
      else if (ui.phase === 'helped') {
        showAskNotice(`已抓一帧并生成草稿（evidence_id=${ui.evidenceId}），去「笔记」页确认晋升或丢弃。`)
        go('notes')
      }
    } else if (ui.kind === 'timeline') {
      pubSegments = (ui.segments || []).slice()
      if (page === 'publish') renderPublishNew()
      // S51·B2：回包不得把用户拽回轨迹（原来无条件 go('trajectory')，"点哪都回轨迹"）。
      // S54·D5：删掉冗余重入 —— page 已在轨迹页时 renderTrajectory(ui) 已完成数据渲染，
      // 再 go('trajectory') 只是重复渲染 + 审计噪音（diag 实测：每进页一次多 1 条重入）。
      else { renderTrajectory(ui) }
    }
    else if (ui.kind === 'drafts') { renderNotes(ui) }
    else if (ui.kind === 'plans') {
      // S66·P0-1：/panel plans-done 回执。成功 → 拉一次 status 让待处理卡即时反映；
      // 失败 → 粘滞失败态（D4：原因不自动消失）。
      if (ui.action === 'done') {
        showAskNotice(`计划已勾销：${ui.id}。`)
        sendCmd('panel', 'status')
      } else if (ui.action === 'error') {
        showFailure(`勾销失败：${ui.message || '未知原因'}（计划 ${ui.id}）。下一步：回对话页用 /coach plans list 核对 id 后再试。`)
      }
    }
    else if (ui.kind === 'claims') { renderClaims(ui) }
    else if (ui.kind === 'claim-detail') { renderClaimDetail(ui) }
    else if (ui.kind === 'claim') {
      if (ui.phase === 'created') {
        showAskNotice(`已建草稿 ${ui.claimId}（${ui.evidenceMode === 'none' ? '无直接证据' : ui.evidenceMode === 'derived' ? '派生证据' : '直接证据'} ${ui.evidenceCount} 条）。`)
        go('publish')
        // 只渲染详情（claim-detail）；不要再发 'claims'——它会与详情竞争 pubLists 且列表后到会覆盖详情，
        // 导致"证据不足不许发布"的 blocked 说明被冲掉（S10-C2）。列表在下次进入发布页时自然刷新。
        sendCmd('claim', ui.claimId)
      } else if (ui.phase === 'attached') {
        showAskNotice(ui.attached > 0 ? `已关联 ${ui.attached} 条证据，去发布。` : '这些证据都已关联过。')
        sendCmd('claim', ui.claimId)
      } else if (ui.phase === 'exported') {
        showAskNotice(`已导出：${(ui.md || '').split('\\').pop()}${ui.docx ? ' + ' + ui.docx.split('\\').pop() : ''}（data/exports/）`)
        sendCmd('claim', ui.claimId)
      } else if (ui.phase === 'blocked') {
        if (pubDetail) renderClaimDetail({ ...pubDetail, canPublish: false })
        showAskNotice(ui.reason || '发布被拒')
      } else if (ui.phase === 'published') {
        showAskNotice(`已发布：${ui.claimId}（证据 ${ui.evidenceCount} 条）。`)
        sendCmd('claim', ui.claimId)
        sendCmd('claim', 'claims')
      }
    }
    else if (ui.kind === 'learn') {
      learnBtn.dataset.repliedAt = String(Date.now()) // S55：标记真回包，压制 wireAction 兜底
      if (ui.phase === 'started') {
        learningActive = true
        setLearnState('success')
        showAskNotice('已开始学习：计时开始（/today 可查）。')
      }
      if (ui.phase === 'stopped') {
        learningActive = false
        setLearnState('success')
        // fmtDur 入参是**秒**（ui-bridge 契约）；durationMs 是毫秒 → 先换算
        showAskNotice(`已结束学习：${fmtDur(Math.round((ui.durationMs || 0) / 1000))} 已落账（/today 可查）。`)
      }
      if (ui.phase === 'need-consent') {
        learningActive = false
        setLearnState('failure', '需要重新授权：consent 非有效 session')
        showFailure('需要重新授权：当前 consent 不是有效 session（已被撤销或过期）。下一步：到「设置 → 授权屏幕记录（本次会话）」授予一次，再点「开始学习」。')
      }
      if (ui.phase === 'already' || ui.phase === 'idle') setLearnState('idle')
      sendCmd('panel', 'status')
    } else if (ui.kind === 'page') { go(ui.page || 'home') }
    else if (ui.kind === 'consent') {
      // S55·D：授权回执（session 4h / 重启失效），首页可见
      showAskNotice(ui.phase === 'granted'
        ? '已授权屏幕记录：4 小时内有效，应用重启后需重新授权。现在点「开始学习」即可记录轨迹。'
        : '授权状态已更新。')
    }
    else if (ui.kind === 'sites') {
      sitesBtn.dataset.repliedAt = String(Date.now()) // S55：压制 wireAction 兜底
      homeBody.textContent = ''
      homeBody.appendChild(el('div', 's5-sec', '最近网站'))
      if (!ui.sites || ui.sites.length === 0) homeBody.appendChild(el('div', 's5-note', '暂无记录。'))
      for (const s of ui.sites || []) {
        const row = el('div', 's5-row')
        row.appendChild(el('span', '', `${s.host}（${s.count} 篇）`))
        homeBody.appendChild(row)
      }
    }
  })

  // 展开/收起不重载渲染进程 → 页面变量天然保持；这里只做状态刷新（10s 轻轮询；冻结期暂停）
  setInterval(() => { if (page === 'home' && !frozen) sendCmd('panel', 'status') }, 10_000)

  // 输入框一聚焦即视为进入对话页（对话是二级页：从首页进入）
  const promptEl = doc.getElementById('prompt')
  if (promptEl) {
    promptEl.addEventListener('focus', () => { if (page === 'home') go('chat') })
  }

  // Esc：二级页 → 回首页（与底座 Esc 语义衔接：先问领域钩子）
  R.onEscape(() => {
    if (page !== 'home') { go('home'); return true }
    return false
  })

  // ------------------------------------------------------------------
  // 调试入口（验收工具经 CDP 调用）
  // ------------------------------------------------------------------
  window.__s5 = {
    page: go,
    currentPage: () => page,
    setState: (name) => setState(name),
    refresh: () => sendCmd('panel', 'status'),
    states: () => STATES.slice(),
    freeze: freezeVolatile,
    unfreeze: unfreezeVolatile,
    isFrozen: () => frozen,
    learnState: () => ({ state: learnBtn.dataset.state || 'idle', text: learnBtn.textContent, disabled: learnBtn.disabled, busy: learnBusy }),
  }

  // ------------------------------------------------------------------
  // S47·P1：底栏语义、空态、隐私页
  // ------------------------------------------------------------------
  function syncChrome() {
    try {
      doc.body.classList.add('ds-v1')
      // S53：给 body 打"当前在对话页"标记，让 CSS 能强制隐藏底栏（双保险，
      // 修复用户截图里"底栏压输入框"的遮挡）。
      doc.body.classList.toggle('ds-chat', page === 'chat')
    } catch { /* noop */ }
    const p = (statusData && statusData.perception) || null
    const needAuth = !!(statusData && statusData.storeReady === false)
    const offline = !!(statusData && statusData.offline === true)
    let text = '就绪'
    let state = 'ready'
    if (offline) { text = '离线'; state = 'offline' }
    else if (needAuth) { text = '需授权'; state = 'needs-auth' }
    // 底栏只写三种用户语义；learning/同意/分钟数/剩余时间一律留在诊断折叠区
    // 底栏只写三种用户语义（12px）；后面跟一段 11px 的元信息，凑齐 DESIGN 的四档字阶。
    dsFoot.textContent = ''
    dsFoot.appendChild(el('span', 'ds-t12', text))
    dsFoot.appendChild(el('span', 'ds-t11', '· 本地'))
    dsDot.setAttribute('data-state', state)
    dsDot.title = text
    // 对话页把底栏让给 composer，避免两条底边叠在一起
    dsFoot.style.display = page === 'chat' ? 'none' : 'flex'
    void p
  }

  function emptyState(text, actionLabel, onAction) {
    const box = el('div', '')
    box.setAttribute('data-empty-state', '')
    // DESIGN-UI §7：空态图标「24」是**尺寸** 24，不是字号 24。
    // 之前用 font-size:24 画字符，直接把字阶集合污染成 {13,14,24}（U-2 失败）。
    const NS = 'http://www.w3.org/2000/svg'
    const icon = doc.createElementNS(NS, 'svg')
    icon.setAttribute('width', '24')
    icon.setAttribute('height', '24')
    icon.setAttribute('viewBox', '0 0 24 24')
    icon.setAttribute('aria-hidden', 'true')
    icon.setAttribute('class', 'ds-empty-icon')
    const ring = doc.createElementNS(NS, 'circle')
    ring.setAttribute('cx', '12')
    ring.setAttribute('cy', '12')
    ring.setAttribute('r', '8')
    ring.setAttribute('fill', 'none')
    ring.setAttribute('stroke', 'currentColor')
    ring.setAttribute('stroke-width', '1.5')
    icon.appendChild(ring)
    box.appendChild(icon)
    box.appendChild(el('div', 'ds-empty-text', text))
    if (actionLabel) {
      const act = el('button', 'ro-btn ds-primary ds-empty-act', actionLabel)
      act.type = 'button'
      if (onAction) act.addEventListener('click', onAction)
      box.appendChild(act)
    }
    return box
  }

  /** 列表空了就显示空态；用 MutationObserver 跟随既有渲染函数，不改它们的写法。 */
  function attachEmpty(list, text, label, onAct) {
    if (!list || !list.parentNode) return null
    const box = emptyState(text, label, onAct)
    box.hidden = true
    list.parentNode.insertBefore(box, list.nextSibling)
    const sync = () => { box.hidden = list.childElementCount > 0 }
    try { new MutationObserver(sync).observe(list, { childList: true }) } catch { /* 老内核无 MO */ }
    sync()
    return box
  }

  // S55·C3 轨迹空态说原因（按感知状态区分）。原按钮被批量改名误伤成 panel learn（非法 sub），一并修。
  attachEmpty(trajBody, '自动记录已关闭，所以今天没有轨迹。', '开启记录', () => {
    const on = statusData && statusData.perception && statusData.perception.running === true
    if (on) { go('chat'); showAskNotice('在对话里说一句要记的内容，我把它记成一条轨迹。') }
    else sendCmd('learn', 'start') // 真命令；无授权时会给出 need-consent 明确提示
  })
  attachEmpty(notesBody, '这里空是因为还没有笔记——在对话里「转为结论」，或在轨迹晋升一段。', '去对话', () => go('chat'))
  attachEmpty(pubLists, '这里空是因为结论要从轨迹片段或笔记生成，目前两者都是空的。建一条草稿开始。', '新建草稿', () => sendCmd('panel', 'newdraft'))
  // homeBody（最近网站）的空态：文案与列表语义对齐（S66 修——原来是"感知开着但还没有新片段"，
  // 与"最近网站"列表不对题）。sites 回包自己也会渲染「暂无记录。」，两者不重复：
  // attachEmpty 只在列表还没有任何子节点（未拉取过）时显示。
  attachEmpty(homeBody, '今天还没有网站记录。点按钮刷新一次。', '最近网站', () => sendCmd('panel', 'sites'))

  const PRIVACY_ROWS = [
    ['原图与截图', '只在本机留存，按保留期到期删除；删除后只保留时间、窗口与内容哈希。'],
    ['笔记与结论', '存在本机数据目录；导出时才生成文件，导出内容不含个人信息与明文路径。'],
    ['语音', '默认关闭；按下说话才开麦，转写在本机完成，播报完即删。'],
    ['出网', '只访问白名单域名；每次请求都留审计，请求头与密钥永不入库。'],
  ]

  // S47·P1：ui-bridge 注入的「限速队列 · reasoner」「未降级」胶囊属于内部指标 ——
  // 默认由 design-v1.js 藏起来，展开诊断时把它们**搬进**诊断区（DOM 移动，不改桥）。
  function adoptPills() {
    try {
      // S51·B5：ui-bridge 会把同一批状态胶囊重复注入（实测 3 份），这里按**文本**去重：
      // 首次见到的搬进诊断区，重复的直接从 DOM 移除（不是藏起来 —— 留着还会被其它查询数到）。
      const seen = new Set()
      for (const pill of panel.querySelectorAll('.ro-pill')) {
        const key = (pill.textContent || '').trim()
        if (seen.has(key)) { pill.remove(); continue }
        seen.add(key)
        if (pill.closest('#ro-ds-diag')) continue
        diagBody.appendChild(pill)
      }
      // S49：`#permission` 是 vendor 的权限下拉，按钮上直接写着 provider 原始 id
      // （school-gateway · deepseek-chat）——DESIGN §9 禁止面板里出现 provider id。
      // 它同时是顶部那条 28px 亮块。搬进诊断区：默认不显示，展开诊断才出现。
      const perm = doc.getElementById('permission')
      if (perm && !perm.closest('#ro-ds-diag')) {
        perm.setAttribute('data-ds-perm', '')
        diagBody.appendChild(perm)
      }
    } catch { /* noop */ }
  }
  // 首次就搬（不等展开）：否则"默认态"里它还在顶栏上露 provider id
  adoptPills()
  try {
    diag.addEventListener('toggle', () => { if (diag.open) adoptPills() })
  } catch { /* noop */ }
  function renderSettings() {
    // diag 在这里才挂进来：它在源码里先于 settingsBody 创建，提前 appendChild 会 TDZ
    // （"Cannot access 'settingsBody' before initialization"，结构自测抓到过）。
    if (diag && diag.parentNode !== settingsBody) settingsBody.appendChild(diag)
    // 清掉旧的动态卡，但**保留诊断折叠区**
    for (const n of Array.from(settingsBody.children)) {
      if (n !== diag) settingsBody.removeChild(n)
    }
    settingsBody.appendChild(el('div', 's5-sec', '隐私与数据'))
    for (const [title, desc] of PRIVACY_ROWS) {
      const card = el('div', 'ds-card s5-card')
      card.dataset.card = 'privacy' // S66·P0-2
      card.dataset.cardTitle = title
      card.appendChild(el('div', 'ds-t13', title))
      card.appendChild(el('div', 'ds-t12', desc))
      settingsBody.appendChild(card)
    }
    // 实验室功能：环境音开关（用户反馈"不知道干什么"）与诊断折叠开关
    settingsBody.appendChild(el('div', 's5-sec', '实验室功能'))
    const lab = el('div', 's5-actions')
    const musicBtn = el('button', 'ro-btn s5-act', '环境音开关')
    musicBtn.type = 'button'
    musicBtn.title = '背景环境音（实验）：程序生成，不播放外部音乐'
    musicBtn.addEventListener('click', () => {
      sendCmd('music', '')
      showAskNotice('已发送环境音开关。说明：这是背景环境音（实验），不播放外部音乐。')
    })
    const diagBtn = el('button', 'ro-btn s5-act', '诊断折叠开关')
    diagBtn.type = 'button'
    diagBtn.addEventListener('click', () => { diag.open = !diag.open })
    // S55·C1：重看新手引导（清掉已看标记 → 回首页显示；判据"重置后可重看"）
    const onboardAgainBtn = el('button', 'ro-btn s5-act', '重看新手引导')
    onboardAgainBtn.type = 'button'
    onboardAgainBtn.addEventListener('click', () => {
      try { localStorage.removeItem(ONBOARD_KEY) } catch { /* 忽略 */ }
      go('home')
      showOnboard()
    })
    // S74·3-B：语音唤醒开关（默认关；喊「问源」→ 打开面板）
    const wakeBtn = el('button', 'ro-btn s5-act', '语音唤醒开关')
    wakeBtn.type = 'button'
    wakeBtn.title = '默认关闭。开启后监听 5 分钟（说「问源」→ 打开面板）；只做唤醒，不展示转写、不播报'
    wakeBtn.addEventListener('click', () => { window.__wake && window.__wake.toggle() })
    lab.appendChild(musicBtn)
    lab.appendChild(diagBtn)
    lab.appendChild(onboardAgainBtn)
    lab.appendChild(wakeBtn)
    // S55·C4 推荐收听：经主进程 openExternal（https + 域名白名单），不自动播放、不后台音频。
    const listenBtn = el('button', 'ro-btn s5-act', '推荐收听（会打开浏览器）')
    listenBtn.type = 'button'
    listenBtn.title = '在系统浏览器里打开推荐收听页（music.163.com）；本应用不自动播放、不放后台音频'
    listenBtn.addEventListener('click', async () => {
      try {
        const r = window.researchOrb && window.researchOrb.openExternal
          ? await window.researchOrb.openExternal('https://music.163.com/')
          : { ok: false, error: '当前版本不支持打开浏览器' }
        showAskNotice(r && r.ok ? '已在浏览器打开推荐收听页（本应用不会自动播放）。' : `没有打开：${(r && r.error) || '未知原因'}`)
      } catch (e) {
        showAskNotice('打开浏览器失败：' + String((e && e.message) || e))
      }
    })
    lab.appendChild(listenBtn)
    // S55·D：授权屏幕记录（此前应用内无任何授权入口，教练线根本走不通）
    const consentBtn = el('button', 'ro-btn s5-act', '授权屏幕记录（本次会话）')
    consentBtn.type = 'button'
    consentBtn.title = '授予本次会话的屏幕记录同意（4 小时 / 重启失效）；原图最多保留 6 小时、到期即删，只留文本与哈希'
    consentBtn.addEventListener('click', () => {
      sendCmd('perception', 'grant session')
      showAskNotice('已发送授权请求…')
    })
    lab.appendChild(consentBtn)
    settingsBody.appendChild(lab)
  }

  // 首屏：按记忆的页面渲染
  render()
  // S66·P0-1：status 回包到达前，待处理卡先给"加载中"占位——不留无标题无内容的空白卡
  // （卡片规则：每张卡随时满足"标题 + 内容或空态"）。
  pending.appendChild(el('div', 's5-sec', '待处理'))
  pending.appendChild(el('div', 's5-note', '正在读取计划与日报…'))
  if (page === 'home') sendCmd('panel', 'status')

  // S54·D1 感知卡 30s 轮询：仅面板展开 + 当前在首页 + 页面可见时拉取（面板收缩/隐藏即停，不后台空转）。
  // 拉的是 ui status —— 顺带刷新整个状态条，感知卡跟着 status 回包一起更新。
  setInterval(() => {
    try {
      const expanded = doc.body.classList.contains('expand-up')
      if (expanded && page === 'home' && doc.visibilityState === 'visible') sendCmd('panel', 'status')
    } catch { /* 轮询失败静默，不影响 UI */ }
  }, 30000)

  // ==================================================================
  // S74·3-B 唤醒词引擎（渲染层采集 → 主进程判定）
  // 参照 dsh-orb / 萌源实盘：PCM 环形缓冲 + 120ms RMS + 预卷 1.5s + 自封 WAV
  // 四件套：探测预算 / 长音频跳过 / 冷却 / 门限上限
  // 纪律：默认关；只在开启的会话期内采集；5 分钟自动关；录音不落盘（主进程判完即删）
  // 调试入口：window.__wake = { start, stop, toggle, state }
  // ==================================================================
  const WAKE = {
    P: {
      tickMs: 120, rmsFloor: 0.03, rmsCap: 0.05, preRollMs: 1500, maxUtteranceMs: 4000,
      silenceMs: 1200, cooldownMs: 700, minSpokenMs: 700, maxArmMinutes: 5, budgetPerMin: 12,
      // 实测（2026-10-26 用户真机）：环境噪音反复越过 0.03 → 8 次/分预算被垃圾探测打满，
      // 每次烧 1–8s CPU。改：最短语音 700ms + 预算 12 + 噪声底自适应（见 wakeOnAudio）。
      noiseFloor: 0.02,
      targetRate: 16000,
    },
    on: false, ctx: null, stream: null, proc: null, src: null,
    ring: [], ringRate: 0, capturing: false, buf: [], spokenMs: 0, quietMs: 0,
    lastFire: 0, probeTimes: [], armedAt: 0, autoTimer: null, tickTimer: null, banner: null,
    lastResult: null,
  }

  function wakeBanner() {
    if (WAKE.banner) return WAKE.banner
    const b = el('div', 's5-note', '🎙 正在监听…')
    b.id = 's5-wake-banner'
    b.style.cssText = 'position:sticky;top:0;z-index:9;margin:4px 0;padding:4px 8px;border-radius:6px;' +
      'background:rgba(31,157,143,.14);border:1px solid rgba(31,157,143,.45);font-size:12px'
    WAKE.banner = b
    return b
  }

  function wakeTickBanner() {
    const b = wakeBanner()
    if (!WAKE.on) { if (b.parentNode) b.parentNode.removeChild(b); return }
    const left = Math.max(0, WAKE.P.maxArmMinutes * 60000 - (Date.now() - WAKE.armedAt))
    const mm = Math.floor(left / 60000)
    const ss = Math.floor((left % 60000) / 1000)
    b.textContent = `🎙 正在监听（说「问源」打开面板）｜剩余 ${mm}:${String(ss).padStart(2, '0')}（到点自动关）`
  }

  function wakeResample(input, inRate, outRate) {
    if (inRate === outRate) return Array.from(input)
    const ratio = inRate / outRate
    const outLen = Math.floor(input.length / ratio)
    const out = new Array(outLen)
    for (let i = 0; i < outLen; i += 1) {
      const pos = i * ratio
      const i0 = Math.floor(pos)
      const i1 = Math.min(input.length - 1, i0 + 1)
      const frac = pos - i0
      out[i] = input[i0] * (1 - frac) + input[i1] * frac
    }
    return out
  }

  function wakeEncodeWav(samples, sampleRate) {
    const bytes = samples.length * 2
    const ab = new ArrayBuffer(44 + bytes)
    const v = new DataView(ab)
    const ws = (off, str) => { for (let i = 0; i < str.length; i += 1) v.setUint8(off + i, str.charCodeAt(i)) }
    ws(0, 'RIFF'); v.setUint32(4, 36 + bytes, true); ws(8, 'WAVE'); ws(12, 'fmt ')
    v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true)
    v.setUint32(24, sampleRate, true); v.setUint32(28, sampleRate * 2, true)
    v.setUint16(32, 2, true); v.setUint16(34, 16, true)
    ws(36, 'data'); v.setUint32(40, bytes, true)
    let off = 44
    for (let i = 0; i < samples.length; i += 1) {
      const s = Math.max(-1, Math.min(1, samples[i]))
      v.setInt16(off, s < 0 ? s * 0x8000 : s * 0x7FFF, true)
      off += 2
    }
    return ab
  }

  function wakeB64(arrayBuffer) {
    const bytes = new Uint8Array(arrayBuffer)
    let bin = ''
    const CH = 0x8000
    for (let i = 0; i < bytes.length; i += CH) {
      bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CH))
    }
    return window.btoa(bin)
  }

  function wakeBudgetOk() {
    const now = Date.now()
    WAKE.probeTimes = WAKE.probeTimes.filter((t) => now - t < 60000)
    return WAKE.probeTimes.length < WAKE.P.budgetPerMin
  }

  function wakeFinish(reason) {
    const spokenMs = WAKE.spokenMs
    const samples = WAKE.buf.slice()
    WAKE.capturing = false
    WAKE.buf = []
    WAKE.spokenMs = 0
    WAKE.quietMs = 0
    if (reason !== 'silence') return
    if (spokenMs < WAKE.P.minSpokenMs) return // 人声量闸门
    if (!wakeBudgetOk()) { showAskNotice('唤醒探测已达每分钟上限，稍后再试', 'info'); return }
    if (Date.now() - WAKE.lastFire < WAKE.P.cooldownMs) return
    WAKE.lastFire = Date.now()
    WAKE.probeTimes.push(WAKE.lastFire)
    try {
      const wav = wakeEncodeWav(samples, WAKE.P.targetRate)
      const rms = 0.04
      send('ui', { type: 'wake:probe', wavBase64: wakeB64(wav), spokenMs, rms })
    } catch (e) {
      showAskNotice('唤醒采集编码失败：' + String((e && e.message) || e), 'error')
    }
  }

  function wakeOnAudio(ev) {
    if (!WAKE.on) return
    // 噪声底自适应：前 2 秒静默期取最小 RMS 作为底，门限 = max(floor, 底×2.5)，上限 cap
    let gate = WAKE.P.rmsFloor
    if (WAKE.noiseFloor > 0) gate = Math.min(WAKE.P.rmsCap, Math.max(WAKE.P.rmsFloor, WAKE.noiseFloor * 2.5))
    const ch = ev.inputBuffer.getChannelData(0)
    const inRate = WAKE.ctx.sampleRate
    const pcm = wakeResample(ch, inRate, WAKE.P.targetRate)
    let sum = 0
    for (let i = 0; i < pcm.length; i += 1) sum += pcm[i] * pcm[i]
    const rms = Math.sqrt(sum / Math.max(1, pcm.length))
    const ms = (ch.length / inRate) * 1000

    // 环形缓冲（保留 ~3s，供预卷）
    WAKE.ring.push(pcm)
    WAKE.ring.push({ __ms: ms })
    let totalMs = 0
    for (let i = 0; i < WAKE.ring.length; i += 1) if (WAKE.ring[i] && WAKE.ring[i].__ms) totalMs += WAKE.ring[i].__ms
    while (totalMs > 3000 && WAKE.ring.length > 2) {
      const f = WAKE.ring.shift()
      if (f && f.__ms) totalMs -= f.__ms
    }

    WAKE.lastRms = rms
    if (!WAKE.capturing) {
      // 静默期持续更新噪声底（只降不升，避免把人声当噪声）
      if (rms < WAKE.P.noiseFloor) WAKE.P.noiseFloor = Math.max(0.006, rms)
      if (rms > gate && ms >= 60) {
        // 起句：把预卷塞进 buf
        WAKE.capturing = true
        WAKE.buf = []
        for (const f of WAKE.ring) if (Array.isArray(f)) WAKE.buf.push(...f)
        WAKE.spokenMs = ms
        WAKE.quietMs = 0
      }
      return
    }
    // 采集中
    WAKE.buf.push(...pcm)
    WAKE.spokenMs += ms
    if (rms < Math.max(0.008, WAKE.P.noiseFloor * 1.6)) WAKE.quietMs += ms; else WAKE.quietMs = 0
    if (WAKE.quietMs >= WAKE.P.silenceMs) { wakeFinish('silence'); return }
    if (WAKE.spokenMs >= WAKE.P.maxUtteranceMs) wakeFinish('too-long') // 长音频跳过
  }

  async function wakeStart() {
    if (WAKE.on) return { ok: true, already: true }
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        return { ok: false, reason: 'E_NO_MEDIA_DEVICES' }
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      })
      const AC = window.AudioContext || window.webkitAudioContext
      const ctx = new AC()
      const src = ctx.createMediaStreamSource(stream)
      const proc = ctx.createScriptProcessor(4096, 1, 1)
      proc.onaudioprocess = wakeOnAudio
      src.connect(proc)
      proc.connect(ctx.destination)
      WAKE.stream = stream; WAKE.ctx = ctx; WAKE.src = src; WAKE.proc = proc
      WAKE.on = true; WAKE.armedAt = Date.now()
      WAKE.ring = []; WAKE.capturing = false; WAKE.buf = []
      send('ui', { type: 'wake:arm', on: true, ms: WAKE.P.maxArmMinutes * 60000 })
      WAKE.autoTimer = setTimeout(() => { wakeStop('auto-off') }, WAKE.P.maxArmMinutes * 60000)
      WAKE.tickTimer = setInterval(wakeTickBanner, 1000)
      try { panel.insertBefore(wakeBanner(), panel.firstChild) } catch { /* noop */ }
      wakeTickBanner()
      showAskNotice(`语音唤醒已开启（${WAKE.P.maxArmMinutes} 分钟后自动关闭）。说「问源」→ 打开面板。`, 'info')
      return { ok: true }
    } catch (e) {
      // 失败必须释放已拿到的音轨/上下文（否则麦克风指示灯常亮 = 隐私事故）
      try { if (WAKE.proc) WAKE.proc.disconnect() } catch { /* noop */ }
      try { if (WAKE.src) WAKE.src.disconnect() } catch { /* noop */ }
      try { if (WAKE.stream) WAKE.stream.getTracks().forEach((t) => t.stop()) } catch { /* noop */ }
      try { if (WAKE.ctx && WAKE.ctx.close) WAKE.ctx.close() } catch { /* noop */ }
      if (WAKE.autoTimer) { clearTimeout(WAKE.autoTimer); WAKE.autoTimer = null }
      if (WAKE.tickTimer) { clearInterval(WAKE.tickTimer); WAKE.tickTimer = null }
      WAKE.on = false; WAKE.ctx = null; WAKE.stream = null; WAKE.proc = null; WAKE.src = null
      return { ok: false, reason: String((e && e.message) || e) }
    }
  }

  function wakeStop(why) {
    if (!WAKE.on) return
    WAKE.on = false
    try { if (WAKE.proc) WAKE.proc.disconnect() } catch { /* noop */ }
    try { if (WAKE.src) WAKE.src.disconnect() } catch { /* noop */ }
    try { if (WAKE.stream) WAKE.stream.getTracks().forEach((t) => t.stop()) } catch { /* noop */ }
    try { if (WAKE.ctx && WAKE.ctx.close) WAKE.ctx.close() } catch { /* noop */ }
    WAKE.ctx = null; WAKE.stream = null; WAKE.proc = null; WAKE.src = null
    if (WAKE.autoTimer) { clearTimeout(WAKE.autoTimer); WAKE.autoTimer = null }
    if (WAKE.tickTimer) { clearInterval(WAKE.tickTimer); WAKE.tickTimer = null }
    try { if (WAKE.banner && WAKE.banner.parentNode) WAKE.banner.parentNode.removeChild(WAKE.banner) } catch { /* noop */ }
    send('ui', { type: 'wake:arm', on: false, ms: 0 })
    showAskNotice(why === 'auto-off' ? '语音唤醒已自动关闭（5 分钟到）。' : '语音唤醒已关闭。', 'info')
  }

  window.__wake = {
    start: wakeStart,
    stop: () => wakeStop('manual'),
    toggle: () => (WAKE.on ? wakeStop('manual') : wakeStart()),
    state: () => ({
      on: WAKE.on, armedAt: WAKE.armedAt, capturing: WAKE.capturing,
      probeTimes: WAKE.probeTimes.length, lastResult: WAKE.lastResult,
      lastHeard: WAKE.lastHeard || '', lastMiss: WAKE.lastMiss || '',
      lastRms: Number(WAKE.lastRms || 0), noiseFloor: Number(WAKE.P.noiseFloor || 0),
    }),
    // 调试：用最近 3 秒环形缓冲立刻判定一次（不依赖门限，验证链路用）
    probeNow: () => {
      let samples = []
      for (const f of WAKE.ring) if (Array.isArray(f)) samples = samples.concat(f)
      if (!samples.length) return { ok: false, reason: 'no-ring' }
      try {
        const wav = wakeEncodeWav(samples, WAKE.P.targetRate)
        send('ui', { type: 'wake:probe', wavBase64: wakeB64(wav), spokenMs: (samples.length / WAKE.P.targetRate) * 1000, rms: WAKE.lastRms || 0.04 })
        return { ok: true, samples: samples.length }
      } catch (e) { return { ok: false, reason: String((e && e.message) || e) } }
    },
  }

  if (typeof R.onMsg === 'function') {
    R.onMsg('wake:result', (m) => {
      WAKE.lastResult = m || null
      WAKE.lastHeard = (m && m.heard) || ''
      if (m && m.hit) {
        try { send('window', { action: 'expand' }) } catch { /* noop */ }
        // 用户实测反馈：面板本来就展开 → expand 无视觉变化，「不动 = 没命中」的错觉。
        // 因此命中必须有**本地可见**反馈：横幅变绿 + 文案 + 3 秒后恢复倒计时。
        try {
          const b = wakeBanner()
          b.textContent = `✅ 已唤醒（听到「${m.word || '唤醒词'}」）`
          b.style.background = 'rgba(31,157,143,.32)'
          b.style.borderColor = 'rgba(31,157,143,.85)'
          if (!b.parentNode) { try { panel.insertBefore(b, panel.firstChild) } catch { /* noop */ } }
          setTimeout(() => { if (WAKE.on) { b.style.background = 'rgba(31,157,143,.14)'; b.style.borderColor = 'rgba(31,157,143,.45)'; wakeTickBanner() } }, 3000)
        } catch { /* noop */ }
        showAskNotice(`已唤醒（听到「${m.word || '唤醒词'}」）。`, 'ok')
      } else if (m && m.reason && m.reason !== 'empty' && m.reason !== 'no-audio') {
        // 未命中不打扰用户，只留调试痕迹
        WAKE.lastMiss = m.reason
      }
    })
  }
})(window.__ro)
