// packages/packs/research/ui/design-v1.js
//
// S47·P1 · DESIGN-UI v1 的领域样式层（docs/DESIGN-UI.md）。
//
// 为什么是这里而不是 vendor：
//   `vendor\orb-base` 是冻结快照（safefs 的 PROTECTED_ZONES 里写着 frozen-vendor-snapshot），
//   任务书也把 vendor 列进"不许动"。所以视觉重做一律走 pack 的 `addStyle()` 领域层 ——
//   与 literature.js / timer.js 同一套注入通道，vendor 一个字节不动。
//
// 六条硬伤里，本文件负责"看起来"的四条：
//   ① 半透明叠花壁纸 → 面板 rgba(18,23,26,0.94) + blur(14px)，卡片实色
//   ③ 字阶混乱     → 全局面板只允许 11/12/13/14（!important 兜底，防止 vendor 主题回冲）
//   ④ 底部空黑区   → 空态样式（图标 24 + ≤40 字 + 一个主按钮）
//   ⑤ 圆角/描边    → 只允许 8/10/14/999
// "结构"的两条（导航 6 项、指标收进诊断）在 home.js 里做。
//
// 纪律：不写 import/export（领域渲染层），只经 window.__ro 拿工具箱。

;(function (R) {
  'use strict'
  const { doc } = R

  // ------------------------------------------------------------------
  // 设计 token（与 DESIGN-UI.md 逐项对齐；变量名统一 ds- 前缀，避免与主题变量打架）
  // ------------------------------------------------------------------
  R.addStyle(`
    :root, #panel {
      --ds-bg-app: #0E1215;
      /* S49：0.965 仍能看见 IDE 代码行 → 改成**完全不透明**实底。
         computedStyle 只证明"设了多少 alpha"，证明不了"屏幕上透不透"；
         实底之后双壁纸差分才可能是 0（验收 accept-s49-opacity 用像素比对）。 */
      --ds-bg-panel: #12171A;
      --ds-bg-card: #171E22;
      --ds-bg-card-hover: #1D262B;
      --ds-line: #263035;
      --ds-text-primary: #E7EFF2;
      --ds-text-secondary: #9AA7AE;
      --ds-text-tertiary: #6B7780;
      --ds-accent: #2DD4BF;
      --ds-accent-hover: #5EEAD4;
      --ds-danger: #F87171;
      --ds-warn: #FBBF24;
      --ds-ok: #34D399;
      --ds-r-8: 8px;
      --ds-r-10: 10px;
      --ds-r-14: 14px;
      --ds-r-full: 999px;
    }

    /* ---------- ① 面板不透明：壁纸不得透字 ---------- */
    #panel {
      /* S51：窗口是透明的，而 vendor 的 --chrome=12px 让面板四周留了一圈空隙，
         我加的 box-shadow 正好落在那圈空隙里 → 看起来就是"半透明灰色边"。
         两刀一起下：inset 归零（面板填满窗口，圆角由 border-radius 裁出）+ 去掉阴影。
         窗口透明时，任何外阴影都会变成灰边，这是必然的。 */
      inset: 0 !important;
      box-shadow: none !important;
      background: var(--ds-bg-panel) !important;
      backdrop-filter: blur(14px) !important;
      -webkit-backdrop-filter: blur(14px) !important;
      border: 1px solid var(--ds-line) !important;
      /* S51：四个角都圆，半径与球一致（球 72 → 36px）。必须配 overflow:hidden ——
         否则底栏 #ro-ds-foot 贴在 bottom:0，会把下沿两个角盖成直角（用户实测截图）。 */
      border-radius: 36px !important;
      overflow: hidden !important;
      /* S51：窗口是透明的，外阴影只会渲染成"半透明灰色边"（用户实测）。不设阴影。 */
      box-shadow: none !important;
      color: var(--ds-text-primary) !important;
      font-family: "Segoe UI Variable Text", "Microsoft YaHei UI", system-ui, sans-serif !important;
      font-variant-numeric: tabular-nums;
      /* 左内边距给 44px 导航让位；**不改** flex-direction —— vendor 的
         column 布局还管着 transcript / composer，横排会把它们挤成一列。 */
      padding-left: 64px !important;
    }

    /* ---------- ③ 字阶 + 文字分层（!important 兜底 vendor 主题 --black 回冲） ----------
       分层口径（DESIGN §2/§9）：primary 只给标题与行首，secondary 给说明/正文，
       tertiary 只给 11px 元信息。全局兜底故意设成 secondary —— 正文占多数。 */
    #panel :where(*):not(svg):not(path):not(circle):not(rect):not(g):not(img) {
      font-size: 13px !important;
      line-height: 18px !important;
      color: var(--ds-text-secondary) !important;
    }
    #panel .ds-t14, #panel #ro-s5-topbar .ds-page-name, #panel h1, #panel h2 { font-size: 14px !important; line-height: 20px !important; font-weight: 600 !important; color: var(--ds-text-primary) !important; }
    #panel .ds-t13, #panel h3, #panel h4, #panel .s5-row, #panel .s5-row .s5-grow, #panel .s5-card > div:first-child { font-size: 13px !important; line-height: 18px !important; font-weight: 500 !important; color: var(--ds-text-primary) !important; }
    #panel .ds-t12, #panel .s5-sub, #panel .s5-note, #panel .s5-sec { font-size: 12px !important; line-height: 16px !important; color: var(--ds-text-secondary) !important; }
    #panel .ds-t11, #panel .s5-badge, #panel .ds-meta { font-size: 11px !important; line-height: 14px !important; color: var(--ds-text-tertiary) !important; }
    #panel button.ro-btn, #panel .s5-act, #panel .s5-ask h4 { color: var(--ds-text-primary) !important; }
    #panel .s5-crumb, #panel .s5-list, #panel .s5-pending { color: var(--ds-text-secondary) !important; }
    #panel .ds-secondary { color: var(--ds-text-secondary) !important; }
    #panel .ds-tertiary { color: var(--ds-text-tertiary) !important; }

    /* ---------- ⑤ 圆角：只允许 8/10/14/999 ---------- */
    #panel :where(button), #panel :where(input), #panel :where(textarea) { border-radius: var(--ds-r-8) !important; }
    #panel .ds-card, #panel .s5-card, #panel .s5-ask, #panel #s5-notice { border-radius: var(--ds-r-10) !important; }
    #panel .ds-round, #panel .ds-dot { border-radius: var(--ds-r-full) !important; }

    /* ---------- 卡片：实色，不加阴影 ---------- */
    #panel .ds-card, #panel .s5-ask, #panel #s5-notice {
      background: var(--ds-bg-card) !important;
      border: 1px solid var(--ds-line) !important;
      box-shadow: none !important;
      padding: 12px !important;
      margin-bottom: 8px !important;
    }
    #panel .s5-row {
      background: transparent;
      border-bottom: 1px solid var(--ds-line) !important;
      min-height: 44px !important;
      padding: 8px 10px !important;
    }
    #panel .s5-row:hover { background: var(--ds-bg-card-hover) !important; }
    #panel .s5-chip {
      background: var(--ds-bg-card) !important;
      border: 1px solid var(--ds-line) !important;
      color: var(--ds-text-secondary) !important;
      border-radius: var(--ds-r-8) !important;
      height: 22px;
      padding: 0 8px !important;
      display: inline-flex; align-items: center;
    }
    #panel .s5-chip.s5-strong { background: rgba(45,212,191,.14) !important; color: var(--ds-accent) !important; border-color: rgba(45,212,191,.35) !important; }

    /* ---------- 按钮：主=accent，次=描边 ---------- */
    #panel button.ro-btn, #panel .s5-act {
      height: 32px !important;
      padding: 0 12px !important;
      border-radius: var(--ds-r-8) !important;
      background: transparent !important;
      color: var(--ds-text-primary) !important;
      border: 1px solid var(--ds-line) !important;
      font-size: 13px !important;
      transition: background-color 120ms ease-out, border-color 120ms ease-out;
    }
    #panel button.ro-btn:hover, #panel .s5-act:hover { background: var(--ds-bg-card-hover) !important; }
    #panel button.ro-btn.ds-primary, #panel .s5-act.ds-primary {
      background: var(--ds-accent) !important; color: #06201D !important; border-color: transparent !important;
    }
    #panel button.ro-btn.ds-primary:hover { background: var(--ds-accent-hover) !important; }
    #panel button:focus-visible, #panel .s5-row:focus-visible {
      outline: 2px solid var(--ds-accent) !important; outline-offset: 2px !important;
    }
    #panel button:disabled { opacity: .55; cursor: not-allowed; }

    /* ---------- 左侧 44px 图标导航（6 项，绝对定位，不参与 vendor 的 column 流） ---------- */
    #ro-ds-nav {
      position: absolute; left: 0; top: 0; bottom: 0; width: 44px; z-index: 6;
      display: flex; flex-direction: column; align-items: center; gap: 4px;
      padding: 8px 0; background: #0B0F12; border-right: 1px solid var(--ds-line);
    }
    #ro-ds-nav .ds-nav-btn {
      width: 32px; height: 32px; min-height: 32px; padding: 0 !important;
      display: flex; align-items: center; justify-content: center;
      background: transparent !important; border: none !important; color: var(--ds-text-secondary) !important;
      border-radius: var(--ds-r-8) !important; cursor: pointer;
    }
    #ro-ds-nav .ds-nav-btn:hover { background: var(--ds-bg-card-hover) !important; color: var(--ds-text-primary) !important; }
    #ro-ds-nav .ds-nav-btn[aria-current="page"] { background: rgba(45,212,191,.14) !important; color: var(--ds-accent) !important; }

    /* ---------- 顶部 40：页面名 + 状态点 ---------- */
    #ro-s5-topbar {
      height: 40px !important; min-height: 40px !important;
      display: flex; align-items: center; gap: 8px;
      padding: 0 16px !important;
      background: #12171A !important;
      border-bottom: 1px solid var(--ds-line);
    }
    #ro-s5-topbar .ds-page-name { flex: 1; }
    #ro-s5-topbar .ds-dot {
      width: 8px; height: 8px; border-radius: var(--ds-r-full);
      background: var(--ds-ok); flex: 0 0 auto;
    }
    #ro-s5-topbar .ds-dot[data-state="offline"] { background: var(--ds-text-tertiary); }
    #ro-s5-topbar .ds-dot[data-state="needs-auth"] { background: var(--ds-warn); }

    /* ---------- S52·P0-3：面板态球缩为 28px 圆点，吸附标题栏右端 ----------
       上一版试过"窗口加高给球让位"，实测是 112px 不可点死区（更糟）；也不让球压内容。
       现在：展开态把球缩成 28px 圆点，钉在标题栏右侧，与内容区矩形不相交；
       收起态恢复 96px 回右下角（vendor 原状，不动）。 */
    body.expanded #ball {
      width: 28px !important; height: 28px !important; min-width: 28px !important; min-height: 28px !important;
      top: 22px !important; bottom: auto !important; left: auto !important; right: 14px !important;
      border-radius: var(--ds-r-full) !important;
      background: rgba(45, 212, 191, .16) !important;
      border: 1px solid rgba(45, 212, 191, .45) !important;
      box-shadow: none !important;
      overflow: hidden !important;
      z-index: 8 !important;
    }
    body.expanded #ball #ball-gif { display: none !important; }
    body.expanded #ball::after {
      content: ''; position: absolute; left: 50%; top: 50%; width: 8px; height: 8px;
      transform: translate(-50%, -50%); border-radius: var(--ds-r-full);
      background: var(--ds-accent);
    }

    /* ---------- S52：齿轮按钮沉到导航底部（左下角） ---------- */
    #ro-ds-nav .ds-nav-btn:last-child { margin-top: auto; }

    /* ---------- S53：遮挡修复（用户截图：底栏压输入框、滚动条压字）----------
       根因：#ro-ds-foot 与 #composer 都贴 bottom:0，对话页里必然重叠。
       JS 已在切页时隐藏底栏，这里用 body.ds-chat 再加一层 CSS 双保险；
       滚动条收窄到 6px 并配色，不再压文字。 */
    body.ds-chat #ro-ds-foot { display: none !important; }
    #panel #prompt::-webkit-scrollbar,
    #panel #transcript::-webkit-scrollbar,
    #panel .s5-page::-webkit-scrollbar { width: 6px !important; }
    #panel #prompt::-webkit-scrollbar-thumb,
    #panel #transcript::-webkit-scrollbar-thumb { background: var(--ds-line) !important; border-radius: 999px !important; }

    /* ---------- T1：遮挡修复第二轮（用户反馈"遮挡没被消除"）----------
       第一轮（S53）只隐藏了对话页底栏 + 收窄滚动条；用**窗口坐标命中栈 + 伪元素扫描**
       重测（tools/diag-t1-occlusion.mjs），仍有五处外来层压盖，逐条修：
       T1-a 左导航（z=6）盖住 composer 左缘 28px、prompt 左缘 16px —— 点输入框左侧
             实际命中导航。composer 让到内容列（left:64），与 transcript 左对齐。
       T1-b 标题行右侧：球（z=8）盖住「+」新建会话钮；#history 整个藏在导航身后
             （left:12 < 导航右缘 45）。三钮让位：history→left:50，+→right:46，
             音乐钮→right:82，全部避开球（x 380..408）与导航（x 1..45）。
       T1-c 三个 28px 圆钮在 teal 主题是 --input-bg 薄荷绿亮块（#d1fae5），
             钉在暗面板标题行 —— 用户投诉的"顶部亮块"。统一改深色卡片语言。
       T1-d 对话页顶栏被挤到输入框上方：#ro-s5 是 panel 最后一个流内子元素，
             transcript 满高后顶栏落在 composer 正上方（设计骨架要求顶栏在标题行）。
             对话页顶栏改绝对定位回顶部；顶栏背景改透明（否则 opaque 背景会
             盖住同行的 chrome 按钮），状态点改成紧跟页面名（不被 flex:1 推到右端）。
       T1-e 输入框常驻滚动条：本文件给 #prompt 加的 1px 边框使内容盒 = 72-2-24 = 46，
             而占位 ::after 高 48（vendor 按无边框算的）→ 永久溢出 2px → 滚动条常亮。
             占位高/行高按 -2px 修正。
       T1-f 主动询问卡 #s5-ask 是流内元素，对话页会落在 composer 上（ latent 遮挡）；
             改成悬浮在输入框上方的绝对定位层（vendor #voiceprint-hint 同款位置）。
       T1-g 历史列表行是 --white 白底（teal 下纯白），打开历史就是几块白卡；
             current 行是薄荷绿。统一深色卡片语言。 */
    #panel #composer { left: 64px !important; right: 16px !important; }
    #panel #history { left: 50px !important; }
    #panel #new-conversation { right: 46px !important; }
    #panel #ro-music-btn { right: 82px !important; }
    #panel #history, #panel #new-conversation, #panel #ro-music-btn {
      background: var(--ds-bg-card) !important;
      border: 1px solid var(--ds-line) !important;
      color: var(--ds-text-secondary) !important;
    }
    #panel #history:hover, #panel #new-conversation:hover, #panel #ro-music-btn:hover {
      background: var(--ds-bg-card-hover) !important;
      color: var(--ds-text-primary) !important;
    }
    body.ds-chat #ro-s5-topbar {
      position: absolute !important; top: 0 !important; left: 64px !important; right: 0 !important;
      z-index: 5 !important; height: 40px !important; min-height: 40px !important;
      background: transparent !important;
    }
    #ro-s5-topbar { background: transparent !important; }
    /* 顶栏只是标签行（页面名 + 状态点），不可交互；但它与 chrome 按钮同行，
       若不排除命中，透明背景照样拦截点击（命中栈实测：点「+」命中顶栏）。 */
    #ro-s5-topbar { pointer-events: none !important; }
    #ro-s5-topbar .s5-crumb, #ro-s5-topbar .ds-dot { pointer-events: auto !important; }
    #ro-s5-topbar .s5-crumb { flex: 0 0 auto !important; }
    #panel #prompt.prompt-empty::after {
      height: calc(var(--composer-height) - 2 * var(--prompt-pad) - 2px) !important;
      line-height: calc(var(--composer-height) - 2 * var(--prompt-pad) - 2px) !important;
    }
    #panel #s5-ask {
      position: absolute !important; left: 65px !important; right: 16px !important;
      bottom: calc(var(--composer-height) + 10px) !important;
      z-index: 4 !important; margin: 0 !important;
    }
    #panel .history-row {
      background: var(--ds-bg-card) !important;
      border: 1px solid var(--ds-line) !important;
      border-radius: var(--ds-r-10) !important;
      color: var(--ds-text-primary) !important;
    }
    #panel .history-row.current {
      background: rgba(45, 212, 191, .14) !important;
      border-color: rgba(45, 212, 191, .35) !important;
    }
    #panel #ro-ds-diag #permission-button, #panel #permission[data-ds-perm] #permission-button {
      background: var(--ds-bg-card) !important;
      border: 1px solid var(--ds-line) !important;
      color: var(--ds-text-secondary) !important;
    }

    /* ---------- S52·B6：说明/设置类面板必须有滚动上限，内容再长也能看完 ---------- */
    #panel .ro-welcome-body,
    #panel .ro-choice,
    #panel #ro-ds-diag .ds-diag-body,
    #panel #ro-ds-diag #permission { max-height: 460px !important; overflow-y: auto !important; }

    /* ---------- 底部 28：只写用户语义 ---------- */
    #ro-ds-foot {
      position: absolute; left: 44px; right: 0; bottom: 0; height: 28px;
      display: flex; align-items: center;
      padding: 0 16px; border-top: 1px solid var(--ds-line);
      background: #0B0F12;
      color: var(--ds-text-tertiary) !important; font-size: 11px !important; line-height: 14px !important;
    }

    /* ---------- 诊断折叠区（技术指标的去处） ---------- */
    #ro-ds-diag { margin: 0 0 12px; border: 1px solid var(--ds-line); border-radius: var(--ds-r-10); background: var(--ds-bg-card); }
    #ro-ds-diag > summary {
      list-style: none; cursor: pointer; padding: 8px 12px; color: var(--ds-text-secondary) !important;
      font-size: 12px !important; line-height: 16px !important; display: flex; align-items: center; gap: 8px;
    }
    #ro-ds-diag > summary::-webkit-details-marker { display: none; }
    #ro-ds-diag > summary::before { content: '▸'; color: var(--ds-text-tertiary); }
    #ro-ds-diag[open] > summary::before { content: '▾'; }
    #ro-ds-diag .ds-diag-body { padding: 0 12px 12px; display: flex; flex-wrap: wrap; gap: 4px; }

    /* ---------- S52·B4：内容容器一律深色 ----------
       用户原话："外部暗内部亮，这叫验收？" —— 对话气泡/说明卡是 vendor 的白色底。
       这里在领域层统一压成 --bg-card + --line 描边（vendor 不动）。 */
    #panel #transcript > *,
    #panel .ro-welcome, #panel .ro-tool, #panel .ro-msg, #panel .ro-live,
    #panel .question-card, #panel #s5-ask, #panel .s5-ask {
      background: var(--ds-bg-card) !important;
      color: var(--ds-text-primary) !important;
      border: 1px solid var(--ds-line) !important;
      border-radius: var(--ds-r-10) !important;
      box-shadow: none !important;
    }
    #panel #prompt, #panel #composer, #panel #composer-input-row {
      background: transparent !important;
      color: var(--ds-text-primary) !important;
    }
    #panel #prompt { background: var(--ds-bg-card) !important; border: 1px solid var(--ds-line) !important; }
    #panel #prompt:focus { outline: 2px solid var(--ds-accent) !important; outline-offset: 2px !important; }
    #panel #transcript { background: transparent !important; }
    #panel .ro-pill { display: none !important; }
    #panel #ro-ds-diag[open] .ro-pill { display: inline-flex !important; }

    /* S49：权限下拉（按钮上写着 provider 原始 id）搬进诊断后要脱离绝对定位，
       且默认不显示 —— 顶部那条 28px 亮块与 provider id 泄漏是同一个元素。 */
    #panel #ro-ds-diag #permission, #panel #permission[data-ds-perm] {
      position: static !important; display: none !important; margin: 0 !important;
    }
    #panel #ro-ds-diag[open] #permission {
      display: flex !important; align-items: center; gap: 8px;
    }

    /* ---------- ④ 空态：图标 24 + ≤40 字说明 + 一个主按钮 ---------- */
    /* S66·P0-2 修：上面这条 display:flex 是**作者样式**，会击穿 UA 的 [hidden]{display:none}
       （级联起源：author > UA，与特异性无关）→ attachEmpty 的 box.hidden 从来没能藏住空态，
       列表有内容时空态照样挂在下面（实测轨迹/笔记/发布三页）。补这条让 hidden 恢复语义。 */
    #panel [data-empty-state] {
      display: flex; flex-direction: column; align-items: center; justify-content: center;
      gap: 8px; padding: 24px 16px; text-align: center; border: none !important; background: transparent !important;
    }
    #panel [data-empty-state][hidden] { display: none !important; }
    #panel [data-empty-state] .ds-empty-icon { width: 24px; height: 24px; color: var(--ds-text-tertiary) !important; }
    #panel [data-empty-state] .ds-empty-text { font-size: 13px !important; line-height: 18px !important; color: var(--ds-text-secondary) !important; max-width: 280px; }
    #panel [data-empty-state] .ds-empty-act { margin-top: 4px; }

    /* ---------- 页面容器：内边距 16 ---------- */
    #panel .s5-page { padding: 16px !important; }
    #panel .s5-page.s5-on { display: block !important; }
    #panel .s5-status { gap: 4px !important; margin-bottom: 12px !important; }

    /* ---------- T1-h：非对话页的页面区必须可滚，而不是被 panel 的 overflow:hidden 裁掉 ----------
       #ro-s5 是 panel 的流内子元素，.s5-page 只有 overflow-y:auto 但没有高度约束，
       内容一超高就被裁掉（滚不动）。非对话页把 #ro-s5 拉成填满内容区的 flex 列，
       可见页面 flex:1 + min-height:0 → 超高时在页面内滚动。
       对话页不走这套（ds-chat）：#ro-s5 只含绝对定位的顶栏，零高度不占位。 */
    body:not(.ds-chat) #ro-s5 { display: flex; flex-direction: column; flex: 1 1 auto; min-height: 0; }
    body:not(.ds-chat) #ro-s5-topbar { flex: 0 0 auto; }
    body:not(.ds-chat) #ro-s5 .s5-page.s5-on { flex: 1 1 auto; min-height: 0; }
    body.ds-chat #ro-s5 { display: block; }
    /* T1-i：shell 状态行（#status）的 pill 已被 adoptPills 搬进诊断区，本体恒空；
       它 6px 的上 margin 只是把首页内容整体压低 6px（与对话页内容起点不齐）。清零。 */
    #panel #status { margin-top: 0 !important; }

    body.ds-v1.ro-frozen #ro-ds-pill { visibility: hidden; }

    /* ---------- S50：vendor 的 #panel::after 是那条"薄荷绿带" ----------
       它是 #panel **自己的伪元素**：left:0/right:0 满宽、height:--composer-height(~72px)、
       border-radius: 球半径、background: var(--input-bg)。默认主题下是深色所以看不见；
       在 teal 主题里 --input-bg = #d1fae5 → 就是用户看到的那条满宽圆角薄荷绿带。
       **它不是 DOM 元素**，所以在子元素里遍历永远扫不到（我踩过这个坑）。
       纯装饰，去掉；对话页的输入框自己有 --bg-card 实底。 */
    #panel::after { display: none !important; }
    /* S51 回退：窗框已改为与面板等高（见 main.mjs 的 EXPANDED_FRAME），
       这条"面板定高 620 + 底部留空"的规则不再需要，反而会把面板顶出窗口。
       留注释说明来历：曾经用「窗口 732 / 面板 620」给球让位，实测得到一条不可点的透明死区，
       且发送键漂在死区里 —— 已撤销。 */

    /* ---------- S54·D1 感知状态卡（首页，番茄钟入口旁） ----------
       深色卡片语言，与 T1-g 历史行一致；不露技术词，数字缺省显示 —。 */
    #panel #ro-percep-card {
      background: var(--ds-bg-card) !important;
      border: 1px solid var(--ds-line) !important;
      border-radius: var(--ds-r-10) !important;
      padding: 8px 10px !important;
      margin: 0 0 8px !important;
    }
    #panel #ro-percep-card .ro-percep-title {
      font-size: 13px !important; font-weight: 600 !important;
      color: var(--ds-text-primary) !important; margin: 0 0 4px !important;
    }
    #panel #ro-percep-card .ro-percep-row {
      display: flex; justify-content: space-between; align-items: baseline;
      font-size: 12px !important; line-height: 18px !important;
    }
    #panel #ro-percep-card .ro-percep-k { color: var(--ds-text-secondary) !important; }
    #panel #ro-percep-card .ro-percep-v { color: var(--ds-text-primary) !important; font-variant-numeric: tabular-nums; }
    /* S55·A 副标（原图已删）：比主指标小一档，语义是"主指标的其中一部分" */
    #panel #ro-percep-card .ro-percep-sub .ro-percep-k,
    #panel #ro-percep-card .ro-percep-sub .ro-percep-v {
      font-size: 11px !important; line-height: 15px !important;
      color: var(--ds-text-tertiary) !important;
    }
    /* S55·C1 首启引导卡（内嵌，不遮其它交互） */
    #panel #ro-onboard-card {
      background: var(--ds-bg-card) !important;
      border: 1px solid var(--ds-line) !important;
      border-radius: var(--ds-r-10) !important;
      padding: 10px 12px !important;
      margin: 0 0 8px !important;
    }
    #panel #ro-onboard-card .ro-onboard-head { display: flex; flex-direction: column; margin: 0 0 6px !important; }
    #panel #ro-onboard-card .ro-onboard-step { font-size: 11px !important; line-height: 14px !important; color: var(--ds-text-tertiary) !important; }
    #panel #ro-onboard-card .ro-onboard-title { font-size: 14px !important; line-height: 20px !important; font-weight: 600 !important; color: var(--ds-text-primary) !important; }
    #panel #ro-onboard-card .ro-onboard-desc { font-size: 12px !important; line-height: 17px !important; color: var(--ds-text-secondary) !important; margin: 0 0 8px !important; }
    #panel #ro-onboard-card .ro-onboard-bar { display: flex; gap: 8px; justify-content: flex-end; }
    /* S55·C2 番茄钟卡（与感知卡并排） */
    #panel #ro-pomodoro-card {
      background: var(--ds-bg-card) !important;
      border: 1px solid var(--ds-line) !important;
      border-radius: var(--ds-r-10) !important;
      padding: 8px 10px !important;
      margin: 0 0 8px !important;
    }
    #panel #ro-pomodoro-card .ro-pomo-head { display: flex; justify-content: space-between; align-items: baseline; }
    #panel #ro-pomodoro-card .ro-pomo-title { font-size: 13px !important; font-weight: 600 !important; color: var(--ds-text-primary) !important; }
    #panel #ro-pomodoro-card .ro-pomo-time {
      font-size: 14px !important; font-weight: 600 !important; color: var(--ds-text-primary) !important;
      font-variant-numeric: tabular-nums;
    }
    #panel #ro-pomodoro-card .ro-pomo-state { font-size: 11px !important; color: var(--ds-text-tertiary) !important; }
    #panel #ro-pomodoro-card .ro-pomo-bar { display: flex; gap: 8px; margin: 6px 0 0 !important; }
    /* S56·T9 会话回声清理提示（首页顶部，可点；两段式确认） */
    #panel #ro-t9-bar {
      background: var(--ds-bg-card) !important;
      border: 1px solid var(--ds-warn, #fbbf24) !important;
      border-radius: var(--ds-r-8, 8px) !important;
      padding: 6px 10px !important;
      margin: 0 0 8px !important;
      font-size: 12px !important; line-height: 17px !important;
      color: var(--ds-text-primary) !important;
      cursor: pointer;
    }
    /* S66·P0-1 待处理计划行：计划文本左、到期标注右、「完成」按钮定宽不抢行。
       .s5-row 默认不是 flex（历史行是标签/值两行堆叠），计划行要单行三段式。 */
    #panel .s5-plan-row { display: flex !important; align-items: center; gap: 8px; }
    #panel .s5-plan-row .s5-grow { flex: 1 1 auto; min-width: 0; }
    #panel .s5-plan-row .s5-sub { flex: 0 0 auto; white-space: nowrap; }
    #panel .s5-plan-row .ro-btn { flex: 0 0 auto; min-height: 28px !important; padding: 0 10px !important; }
    #panel .s5-plan-over .s5-sub { color: var(--ds-warn, #fbbf24) !important; }
  `)

  // 给 body 打标记：nav/diagnostics 的显隐与字阶兜底都挂在这个类上
  try {
    doc.body.classList.add('ds-v1')
  } catch {
    /* 极早期调用时 body 可能还没就绪，home.js 会在 render 时再补一次 */
  }

  R.dsVersion = 'v1'
})(window.__ro)
