// packages/packs/research/index.mjs
//
// 科研 pack（P-R6）：只做【声明与编排】，不重复实现能力。
//   能力实现 → packages\plugins\research-literature / research-browser / research-timer / skill-installer
//   领域 UI  → ui\literature.js / ui\timer.js（由 shell 注入 renderer）
//
// activate(ctx) 里可以做的：注册 pack 级命令、登记默认主题、写 pack 级日志。
// 不能做的：写 packages\plugins\*、改 shell、出网（出网由插件经受控 net）。

import { existsSync, mkdirSync } from 'node:fs'
import { APP_VERSION } from '../../../packages/core/src/version.mjs'
import { join } from 'node:path'

export const PACK_ID = 'research'
export const PACK_VERSION = APP_VERSION

export async function activate(ctx) {
  const log = ctx.log
  // S5：把 ctx.registry 挂到 globalThis，供 timeline 插件的 /learn 重激活 perception
  // （插件 ctx 没有 registry——插件体系的公开边界；pack ctx 才有。与 S3.1 的
  // globalThis.researchOrbLifecycle 同一交接模式，不改任何已验收内部。）
  globalThis.__researchRegistry = ctx.registry
  const root = join(ctx.dir, '..', '..', 'data', 'packs', ctx.pack.dataRoot)
  // pack 自己的数据根：data/packs/research/（领域插件另有自己的数据目录）
  try {
    if (!existsSync(root)) mkdirSync(root, { recursive: true })
  } catch {
    /* 目录创建失败不影响 pack 激活（插件自身有 scopes 夹逼） */
  }

  log.info(`科研 pack 已激活：plugins=${ctx.pack.plugins.join(',')} theme=${ctx.pack.theme} ui=${ctx.pack.ui.join(',')}`)

  // pack 级命令：报告当前形态与可用能力（用于演示"换 pack = 换形态"）
  ctx.registry.list() // 触发一次 scan，保证 list 反映真实状态
  return {
    pack: PACK_ID,
    version: PACK_VERSION,
    deactivate() { log.info('科研 pack 已停用') },
  }
}

export default { activate, PACK_ID, PACK_VERSION }
