# render_chart.py -- S17 chart-skill PNG renderer (Pillow only, zero new deps).
#
# Input : argv[1] = path to a UTF-8 JSON payload:
#   {
#     "out": "<abs path>.png",
#     "title": "...", "subtitle": "...",
#     "xLabel": "...", "yLabel": "...",
#     "annotation": "来源：... evidence_id=a, b ...",   # drawn INSIDE the image
#     "bars": [ {"label": "原图仍在", "value": 6, "tier": "原图仍在" } ],
#     "tiers": { "原图仍在": "#0f766e", "引用断链": "#d97706" },
#     "metric": "evidence-status", "varianceOk": true
#   }
# Output: writes the PNG at payload["out"] and a sibling "<out>.drawn.json"
#   recording what was actually drawn (title / wrapped annotation lines /
#   canvas size / bar values / variance flag / fonts used) so tests can
#   verify in-image content without eyeballing pixels.
#
# Discipline: Chinese text via system msyh.ttc (fallback simhei.ttf), font
# sizes >= 22px for labels/ticks on the 1600px canvas, annotation >= 18px,
# no network, no paths inside the image.

import json
import os
import sys

from PIL import Image, ImageDraw, ImageFont

FONT_CANDIDATES = [
    "C:/Windows/Fonts/msyh.ttc",
    "C:/Windows/Fonts/simhei.ttf",
]

W, H = 1600, 1000
# t=214：给「两行论点标题 + 副标题 + 图例」留出三条互不重叠的基线（此前图例压副标题、标题被截断）
PLOT = {"l": 130, "t": 214, "r": 1540, "b": 780}


def emit_fatal(reason):
    sys.stderr.write(reason + "\n")
    sys.exit(1)


def load_font(size, cache={}):
    key = size
    if key in cache:
        return cache[key]
    for p in FONT_CANDIDATES:
        if os.path.exists(p):
            try:
                f = ImageFont.truetype(p, size)
                cache[key] = (f, p)
                return cache[key]
            except Exception:
                continue
    emit_fatal("E_FONT")


def trunc(draw, text, font, maxw):
    text = str(text)
    if draw.textlength(text, font=font) <= maxw:
        return text
    while text and draw.textlength(text + "…", font=font) > maxw:
        text = text[:-1]
    return text + "…"


def wrap(draw, text, font, maxw, max_lines):
    words = str(text).split(" ")
    lines = []
    cur = ""
    for w in words:
        trial = (cur + " " + w).strip()
        if draw.textlength(trial, font=font) <= maxw or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = w
            if len(lines) == max_lines - 1:
                break
    if cur:
        lines.append(cur)
    # overflow tail -> collapse into last line with ellipsis
    if len(lines) == max_lines and words and " ".join(lines) != str(text).strip():
        last = lines[-1]
        rest = str(text).strip()
        idx = rest.rfind(last)
        if idx >= 0:
            overflow = rest[idx + len(last):].strip()
            if overflow:
                while last and draw.textlength(last + " …", font=font) > maxw:
                    last = last[:-1]
                lines[-1] = last + " …"
    return lines


def nice_step(ymax):
    raw = ymax / 5.0
    mag = 1
    while raw >= 10:
        raw /= 10.0
        mag *= 10
    while raw < 1:
        raw *= 10
        mag /= 10
    for m in (1, 2, 2.5, 5, 10):
        if raw <= m:
            return m * mag
    return 10 * mag


def fmt_num(v):
    if isinstance(v, float) and not v.is_integer():
        return ("%g" % v)
    return str(int(v))


def main():
    if len(sys.argv) < 2:
        emit_fatal("E_NO_PAYLOAD")
    with open(sys.argv[1], encoding="utf-8") as fh:
        payload = json.load(fh)

    out = payload.get("out")
    kind = payload.get("kind", "bars")
    bars = payload.get("bars") or []
    series = payload.get("series") or []
    tiers = payload.get("tiers") or {}
    if not out or (kind == "line" and not series) or (kind != "line" and not bars):
        emit_fatal("E_BAD_PAYLOAD")

    img = Image.new("RGB", (W, H), "#ffffff")
    d = ImageDraw.Draw(img)

    f_title, used1 = load_font(40)
    f_sub, used2 = load_font(24)
    f_label, used3 = load_font(22)
    f_tick, used4 = load_font(20)
    f_note, used5 = load_font(18)
    f_legend, used6 = load_font(20)
    fonts_used = sorted(set([used1, used2, used3, used4, used5, used6]))

    # ---- title / subtitle -------------------------------------------------
    # 标题是论点句（"10 条证据引用中，6 条…、3 条…、1 条…"）：必须完整可读，
    # 所以按 2 行折行而不是 trunc 截成 "…"；副标题仍单行（口径说明，可截）。
    ty = 24
    title_lines = wrap(d, payload.get("title", ""), f_title, W - 120, 2)
    for line in title_lines:
        d.text((60, ty), line, font=f_title, fill="#134e4a")
        ty += 48
    sub = payload.get("subtitle", "")
    if sub:
        d.text((60, ty + 4), trunc(d, sub, f_sub, W - 120), font=f_sub, fill="#475569")

    # ---- scales -----------------------------------------------------------
    l, t, r, b = PLOT["l"], PLOT["t"], PLOT["r"], PLOT["b"]
    vals = [float(x.get("value", 0)) for x in (series if kind == "line" else bars) if x.get("value") is not None]
    ymax = max(vals + [1.0])
    ycap = payload.get("yMax")
    top = float(ycap) if ycap is not None else ymax * 1.12
    step = nice_step(top)
    # 整数口径数据（证据条数）优先整数刻度，避免 2.5 这类小数刻度
    if kind != "line" and all(float(x.get("value", 0)).is_integer() for x in bars) and top <= 8:
        step = 1.0
    y_top = 0.0
    while y_top < top - 1e-9:
        y_top += step

    def ypix(v):
        return b - (b - t) * (v / y_top)

    # ---- grid + y ticks ---------------------------------------------------
    gv = 0.0
    while gv <= y_top + 1e-9:
        y = ypix(gv)
        d.line([(l, y), (r, y)], fill="#e2e8f0", width=1)
        d.text((l - 14 - d.textlength(fmt_num(gv), font=f_tick), y - 12),
               fmt_num(gv), font=f_tick, fill="#475569")
        gv += step

    # ---- axes -------------------------------------------------------------
    d.line([(l, t - 10), (l, b)], fill="#64748b", width=2)
    d.line([(l, b), (r, b)], fill="#64748b", width=2)

    # ---- bars / line -------------------------------------------------------
    if kind == "line":
        n = len(series)
        slot = (r - l) / float(n) if n else (r - l)
        color = payload.get("color", "#0f766e")
        series2 = payload.get("series2") or []  # S39·F3：第二条曲线（lifeScore），与 series 同长
        color2 = payload.get("color2", "#d97706")
        series_avg = payload.get("seriesAvg") or []  # S39·F3：平均线（虚线）
        color_avg = payload.get("colorAvg", "#64748b")

        def line_points(ss):
            pts = []
            for i, s in enumerate(ss):
                v = s.get("value")
                cx = l + slot * (i + 0.5)
                if i == 0 or ss is not series:
                    pass
                pts.append((cx, None if v is None else ypix(float(v))))
            return pts

        pts = []
        for i, s in enumerate(series):
            v = s.get("value")
            cx = l + slot * (i + 0.5)
            lab = trunc(d, s.get("label", ""), f_label, slot - 8)
            d.text((cx - d.textlength(lab, font=f_label) / 2, b + 12),
                   lab, font=f_label, fill="#334155")
            if v is None:
                pts.append((cx, None))
                continue
            y = ypix(float(v))
            pts.append((cx, y))
        # 连点：相邻两枚都有值才连线（缺日不连点，如实留缺口）
        for i in range(1, n):
            (x0, y0), (x1, y1) = pts[i - 1], pts[i]
            if y0 is not None and y1 is not None:
                d.line([(x0, y0), (x1, y1)], fill=color, width=3)
        # 画点 + 数值标签
        for i, (cx, y) in enumerate(pts):
            if y is None:
                continue
            d.ellipse([cx - 6, y - 6, cx + 6, y + 6], fill=color)
            label = fmt_num(float(series[i].get("value", 0)))
            d.text((cx - d.textlength(label, font=f_label) / 2, y - 32),
                   label, font=f_label, fill="#0f172a")
        # S39·F3：第二条曲线（workScore/lifeScore 双维）
        p2 = line_points(series2) if series2 else []
        for i in range(1, len(series2)):
            (x0, y0), (x1, y1) = p2[i - 1], p2[i]
            if y0 is not None and y1 is not None:
                d.line([(x0, y0), (x1, y1)], fill=color2, width=3)
        for cx, y in p2:
            if y is not None:
                d.ellipse([cx - 5, y - 5, cx + 5, y + 5], fill=color2)
        # S39·F3：平均线（虚线，不画点）
        pa = line_points(series_avg) if series_avg else []
        for i in range(1, len(series_avg)):
            (x0, y0), (x1, y1) = pa[i - 1], pa[i]
            if y0 is not None and y1 is not None:
                step = 14
                seg = max(2, int(abs(x1 - x0) / step))
                for k in range(seg):
                    if k % 2 == 0:
                        xa = x0 + (x1 - x0) * k / seg
                        xb = x0 + (x1 - x0) * (k + 1) / seg
                        ya = y0 + (y1 - y0) * k / seg
                        yb = y0 + (y1 - y0) * (k + 1) / seg
                        d.line([(xa, ya), (xb, yb)], fill=color_avg, width=2)
        # 图例（画在图内右上）
        if series2 or series_avg:
            lx, ly = r - 300, t + 8
            d.ellipse([lx, ly + 4, lx + 10, ly + 14], fill=color)
            d.text((lx + 16, ly), "workScore", font=f_label, fill="#0f172a")
            if series2:
                d.ellipse([lx + 120, ly + 4, lx + 130, ly + 14], fill=color2)
                d.text((lx + 136, ly), "lifeScore", font=f_label, fill="#0f172a")
            if series_avg:
                d.line([(lx, ly + 34), (lx + 34, ly + 34)], fill=color_avg, width=2)
                d.text((lx + 42, ly + 24), "平均", font=f_label, fill="#0f172a")
    else:
        n = len(bars)
        slot = (r - l) / float(n)
        barw = min(slot * 0.62, 140.0)
        for i, bar in enumerate(bars):
            v = float(bar.get("value", 0))
            cx = l + slot * (i + 0.5)
            x0 = cx - barw / 2
            color = tiers.get(bar.get("tier"), "#0f766e")
            if v > 0:
                y0 = ypix(v)
                d.rectangle([x0, y0, x0 + barw, b], fill=color)
                label = fmt_num(v)
                d.text((cx - d.textlength(label, font=f_label) / 2, y0 - 30),
                       label, font=f_label, fill="#0f172a")
            # x tick label (id tail kept readable; truncated to slot)
            lab = trunc(d, bar.get("label", ""), f_label, slot - 8)
            d.text((cx - d.textlength(lab, font=f_label) / 2, b + 12),
                   lab, font=f_label, fill="#334155")

    # ---- axis labels ------------------------------------------------------
    yl = payload.get("yLabel", "")
    if yl:
        # 下移到 PLOT.t-30：给上面的图例行腾位置（原 t-44 会与图例叠字）
        d.text((l, t - 30), yl, font=f_label, fill="#0f172a")
    xl = payload.get("xLabel", "")
    if xl:
        d.text((l + (r - l) / 2 - d.textlength(xl, font=f_label) / 2, b + 52),
               xl, font=f_label, fill="#0f172a")

    # ---- legend (only tiers actually present) ------------------------------
    # 单独占一行（y=158），左对齐从 60 起排：此前右对齐画在 y=104，直接压在副标题上。
    present = []
    for x in bars:
        tier = x.get("tier")
        if tier and tier not in present:
            present.append(tier)
    lx = 60
    for tier in present:
        d.rectangle([lx, 160, lx + 18, 178], fill=tiers.get(tier, "#0f766e"))
        lx += 26
        d.text((lx, 156), tier, font=f_legend, fill="#334155")
        lx += d.textlength(tier, font=f_legend) + 34

    # ---- in-image source annotation (REQUIRED, bottom band) ---------------
    d.line([(60, 900), (W - 60, 900)], fill="#cbd5e1", width=1)
    ann_lines = wrap(d, payload.get("annotation", ""), f_note, W - 140, 3)
    ay = 916
    for line in ann_lines:
        d.text((70, ay), line, font=f_note, fill="#334155")
        ay += 26

    img.save(out, "PNG")

    drawn = {
        # 匿名纪律：只记文件名，不把绝对路径写进产物目录的任何文本文件
        "out": os.path.basename(out),
        "kind": kind,
        "width": W,
        "height": H,
        "title": payload.get("title", ""),
        "annotationLines": ann_lines,
        "tiers": present,
        "bars": len(bars),
        # S18：把实际画上去的柱值与方差标记落进 meta，验收/复算不靠肉眼球
        "barValues": [float(x.get("value", 0)) for x in bars],
        "barLabels": [str(x.get("label", "")) for x in bars],
        # S32：折线模式的点值（null = 缺日，不连点）
        "lineValues": [None if x.get("value") is None else float(x.get("value")) for x in series],
        "line2Values": [None if x.get("value") is None else float(x.get("value")) for x in (payload.get("series2") or [])],
        "avgValues": [None if x.get("value") is None else float(x.get("value")) for x in (payload.get("seriesAvg") or [])],
        "lineLabels": [str(x.get("label", "")) for x in series],
        "metric": payload.get("metric", ""),
        "varianceOk": bool(payload.get("varianceOk", False)),
        "fonts": fonts_used,
    }
    with open(out + ".drawn.json", "w", encoding="utf-8") as fh:
        json.dump(drawn, fh, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
