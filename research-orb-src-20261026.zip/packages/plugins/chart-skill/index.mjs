// packages/plugins/chart-skill/index.mjs
//
// S17「图与表」：把核验过的数据（claim / claim_evidence）变成一张能见人的图
// 和一张能带走的表，图与表都自带来源标注（可对回 evidence_id）。
//
// 纪律（CONTRACT §2/§6）：
//   · 只读 claim / claim_evidence，不写 claim 状态，不改证据链主流程。
//   · 零新增依赖：图 = 本机 Python 3.13.6 + Pillow 13（已装，解释器探测）；
//     表 = 复用 research-literature 的 docx 懒加载管线。
//   · 没有真实证据输入 → 明确错误码（E_NO_EVIDENCE），绝不编数据。
//   · 产物只落 data/artifacts（默认）或调用方给定目录；落盘走直接写 + chart.jsonl 审计
//     （与 vault-notes 同一先例）。
import { appendJsonl, PROJECT_ROOT, logPath } from '../../core/src/safefs.mjs'
import { join } from 'node:path'
import { ChartError } from './lib/data.mjs'
import { buildBarsArtifact, buildTableArtifact } from './lib/chart.mjs'

export const PLUGIN_ID = 'chart-skill'
export const VERSION = '0.7.0'
export const DEFAULT_OUTDIR = 'data/artifacts'

const USAGE = [
  '图表用法（数据只来自真实 claim / claim_evidence / raw_frame，无证据会明确拒绝）：',
  '  /chart bars [claimId|trust]   画「证据当前状态分布」柱状图（PNG ≥1600×1000，图内含来源标注；标题为论点句）',
  '  /chart table [claimId|claims] 出结论证据表（claim_id/状态/证据档位/证据数/证据编号 → .md + .docx）',
].join('\n')

function resolveStore(ctx) {
  // ctx.core.lifecycle 优先（测试/显式注入）；应用内用 globalThis 桥——注意桥上是 { store, config, … }，
  // 必须取 .store，且只能在**调用时**取（宿主在异步 bootstrap 里才建单例，activate 时还拿不到）。
  const direct = (ctx && ctx.core && ctx.core.lifecycle) || null
  if (direct) return direct
  const bridge = globalThis.researchOrbLifecycle
  const store = bridge && bridge.store ? bridge.store : null
  if (!store) throw new ChartError('E_NO_STORE', '没有可用 store（宿主未接入）')
  return store
}

function resolveOutDir(arg) {
  // 安全：只允许相对 data/ 的目录（路径夹逼），拒绝绝对路径与越级。
  const raw = String(arg || '').trim()
  if (!raw) return join(PROJECT_ROOT, DEFAULT_OUTDIR)
  if (/^([a-zA-Z]:|[\\/])/.test(raw) || raw.includes('..')) {
    throw new ChartError('E_BAD_OUTDIR', '产物目录必须是 data/ 下的相对路径')
  }
  const normalized = raw.replace(/\\/g, '/').replace(/^\/+/, '')
  return join(PROJECT_ROOT, normalized.startsWith('data/') ? normalized : join('data', normalized))
}

export async function activate(ctx) {
  const log = (ctx && ctx.log) || console
  if (ctx && ctx.ui && typeof ctx.ui.registerCard === 'function') {
    ctx.ui.registerCard({
      id: 'chart.status',
      title: '证据图表',
      body: '把已发布结论的证据链画成图（证据当前状态分布）/ 出成表（图内自带 evidence_id 来源标注）。/chart bars｜/chart table',
    })
  }
  if (!(ctx && ctx.ui && typeof ctx.ui.registerCommand === 'function')) {
    log.warn('chart-skill: 宿主未提供 ui.registerCommand')
    return { ok: false }
  }
  ctx.ui.registerCommand({
    name: 'chart',
    title: '证据图表（图 + 表）',
    description: USAGE,
    run: async (rest = '') => {
      const parts = String(rest || '').trim().split(/\s+/).filter(Boolean)
      const sub = (parts[0] || '').toLowerCase()
      const argRaw = parts[1] || ''
      // trust/claims = 聚合全量视图；其余非空参数按 claimId 处理
      const isAggregate = !argRaw || argRaw === 'trust' || argRaw === 'claims'
      const claimId = isAggregate ? null : argRaw
      const argOut = parts[2] || ''
      try {
        const store = resolveStore(ctx)
        if (sub === 'bars') {
          const outDir = resolveOutDir(argOut)
          const r = await buildBarsArtifact({ store, claimId, outDir, version: VERSION })
          try {
            appendJsonl(logPath('chart.jsonl'), {
              kind: 'chart-bars', png: r.pngPath, claimIds: r.sidecar.claimIds, evidenceCount: r.sidecar.evidenceIds.length,
            })
          } catch { /* 审计尽力 */ }
          return {
            ok: true,
            text: `已出图：${r.pngPath}（${r.size.width}×${r.size.height}，图内含来源标注，证据 ${r.sidecar.evidenceIds.length} 条）`,
            ui: { kind: 'chart', pngPath: r.pngPath, sidecar: r.sidecar },
          }
        }
        if (sub === 'table') {
          const outDir = resolveOutDir(argOut)
          const r = await buildTableArtifact({ store, claimId, outDir, version: VERSION })
          try {
            appendJsonl(logPath('chart.jsonl'), {
              kind: 'chart-table', md: r.mdPath, docx: r.docxPath, claimIds: r.sidecar.claimIds, evidenceCount: r.sidecar.evidenceIds.length,
            })
          } catch { /* 审计尽力 */ }
          const preview = r.md.split('\n').filter((l) => l.startsWith('| ')).slice(2, 6).map((l) => l.replace(/\s+/g, ' ').slice(0, 90))
          return {
            ok: true,
            text: `已出表：\n${r.mdPath}\n${r.docxPath}\n（列：claim_id/状态/证据档位/证据数/证据编号，共 ${r.sidecar.claimIds.length} 行）\n${preview.join('\n')}`,
            ui: { kind: 'chart-table', mdPath: r.mdPath, docxPath: r.docxPath, sidecar: r.sidecar },
          }
        }
        return { ok: false, text: USAGE, code: 'E_USAGE' }
      } catch (e) {
        return { ok: false, text: String((e && e.message) || e), code: (e && e.code) || 'E_CHART', error: String((e && e.message) || e) }
      }
    },
  })
  return { ok: true, commands: ['chart'] }
}

export default { activate, PLUGIN_ID, VERSION, DEFAULT_OUTDIR }
