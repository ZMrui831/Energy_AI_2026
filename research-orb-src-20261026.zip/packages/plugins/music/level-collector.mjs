// packages/plugins/music/level-collector.mjs
//
// S13 "music halo" Track C - audio level collection sub-agent (Node side,
// pure ESM, zero electron).
//
// Responsibilities (mirrors packages/plugins/perception/collector.mjs):
//   1. start() spawns the long-lived PowerShell helper (level-collector.ps1)
//      EXACTLY ONCE per start():
//        powershell.exe -NoProfile -NonInteractive -File <ps1> <parentPid> <pollMs>
//      (argv order is fixed on both sides - change it in both files or neither).
//   2. Read its stdout line-by-line (robust against BOM / partial / multi-line
//      chunks). {"ts":..,"peak":..} -> options.onSample({ts, peak}).
//   3. {"ts":..,"error":".."} means the helper hit a fatal collection error
//      (no audio endpoint / COM failure) and exited: counted as ONE failure
//      and triggers an exponential-backoff restart
//      (delay = min(maxDelay, baseDelay * 2^failures), defaults 500/30000).
//   4. stop() kills ONLY our own spawned PID tree (taskkill /PID <pid> /T /F,
//      synchronous execFileSync) and makes every further spawn impossible --
//      four race gates plus a generation guard (spawn-after-stop = orphan,
//      see docs/PERCEPTION.md 7.1).
//   5. The helper itself carries a parent-PID guardian (ps1 side), so even a
//      SIGKILLed / crashed Node cannot orphan the powershell child.
//
// Sampling contract: WASAPI render-endpoint peak only (never opens capture).
// Default ~30 Hz (pollMs 33, clamped [10,1000]).
//
// This module is intentionally injectable: tests pass options.spawnImpl /
// options.killTreeImpl / options.isAlive so they never touch real PowerShell,
// real processes, or Electron.

import { spawn, execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

// Safe write path for optional restart audit (only used when options.auditFile set).
import { appendJsonl, logPath } from '../../core/src/safefs.mjs'

const __dirname = dirname(fileURLToPath(import.meta.url))

/** Absolute path to the bundled level-collector.ps1 (real helper). */
export const levelCollectorPath = join(__dirname, 'level-collector.ps1')

/** Default sample interval (ms) ~= 30 Hz; always clamped into [10, 1000]. */
export const DEFAULT_POLL_MS = 33

const POLL_MIN_MS = 10
const POLL_MAX_MS = 1000

/** Required sample fields (fixed schema) and their expected JSON types. */
const REQUIRED_FIELDS = ['ts', 'peak']
const FIELD_TYPES = {
  ts: 'number',
  peak: 'number',
}

const BOM = '\ufeff'

/** Clamp the sample interval into the ps1's accepted range (same bounds). */
function clampPollMs(value) {
  const n = Number(value)
  if (!Number.isFinite(n)) return DEFAULT_POLL_MS
  return Math.min(POLL_MAX_MS, Math.max(POLL_MIN_MS, Math.round(n)))
}

/**
 * Pure: parse a single line of collector output.
 * Never throws. Returns {ok:true, sample:{ts, peak}} or {ok:false, reason}.
 * A helper error line ({"ts":..,"error":".."}) is classified as
 * reason:'error-line' (with the reason attached) so the controller can count
 * one failure and restart with backoff -- it is NOT valid sample data.
 * Tolerant of leading/trailing whitespace and a stray UTF-8 BOM.
 * @param {string} line
 * @returns {{ok:true, sample:{ts:number, peak:number}} | {ok:false, reason:string, error?:string}}
 */
export function parseLine(line) {
  if (typeof line !== 'string') return { ok: false, reason: 'not-string' }
  let s = line.trim()
  if (s.length === 0) return { ok: false, reason: 'empty' }
  if (s.charCodeAt(0) === 0xfeff) s = s.slice(1) // strip BOM
  if (s.length === 0) return { ok: false, reason: 'empty-after-bom' }

  let obj
  try {
    obj = JSON.parse(s)
  } catch {
    return { ok: false, reason: 'invalid-json' }
  }
  if (obj === null || typeof obj !== 'object' || Array.isArray(obj)) {
    return { ok: false, reason: 'not-object' }
  }

  // Helper fatal-error line: classified, never forwarded as a sample.
  if (typeof obj.error === 'string') {
    return { ok: false, reason: 'error-line', error: obj.error }
  }

  const missing = REQUIRED_FIELDS.filter((k) => !(k in obj))
  if (missing.length > 0) {
    return { ok: false, reason: `missing-fields:${missing.join(',')}` }
  }
  for (const k of REQUIRED_FIELDS) {
    if (typeof obj[k] !== FIELD_TYPES[k]) {
      return { ok: false, reason: `bad-type:${k}` }
    }
  }
  if (!Number.isFinite(obj.ts) || !Number.isFinite(obj.peak)) {
    return { ok: false, reason: 'non-finite' }
  }
  if (obj.peak < 0 || obj.peak > 1) {
    return { ok: false, reason: 'peak-out-of-range' }
  }
  return { ok: true, sample: { ts: obj.ts, peak: obj.peak } }
}

/**
 * Pure residue self-check. Given a list of pids (our spawned subtree) and an
 * injectable isAlive predicate, report whether every one of them has exited.
 * Real default probes the OS via process.kill(pid, 0).
 * @param {number|number[]} pids
 * @param {(pid:number)=>boolean} [isAlive]
 * @returns {{allExited:boolean, alive:number[], pids:number[]}}
 */
export function listOwnPowershell(pids, isAlive = defaultIsAlive) {
  const arr = Array.isArray(pids) ? pids : pids == null ? [] : [pids]
  const alive = arr.filter((p) => {
    try {
      return isAlive(p)
    } catch {
      return false
    }
  })
  return { allExited: alive.length === 0, alive, pids: arr }
}

/** Default liveness probe: process.kill(pid, 0) throws ESRCH when absent. */
function defaultIsAlive(pid) {
  try {
    process.kill(pid, 0)
    return true
  } catch {
    return false
  }
}

/**
 * taskkill argv for killing ONLY our own spawned PID tree: /T (tree) /F (force),
 * never by process name. Exported so tests can pin the exact argv.
 * @param {number} pid
 * @returns {string[]}
 */
export function killTreeArgs(pid) {
  return ['/PID', String(pid), '/T', '/F']
}

/**
 * Default tree kill: ONLY our own PID, never by process name.
 * MUST be synchronous (execFileSync): callers historically did
 * `collector.stop(); process.exit()` immediately after -- an async execFile
 * spawn request could be aborted by process.exit() before taskkill.exe ever
 * launched, leaving an orphaned powershell (the orphan root cause, see
 * docs/PERCEPTION.md 7.1). execSync is injectable for tests; failures
 * (already dead) are swallowed and never thrown out of stop().
 * @param {number} pid
 * @param {typeof execFileSync} [execSync]
 */
export function defaultKillTree(pid, execSync = execFileSync) {
  try {
    execSync('taskkill', killTreeArgs(pid), {
      windowsHide: true,
      timeout: 10_000,
      stdio: 'ignore',
    })
  } catch {
    /* taskkill non-zero (already dead) is fine; never throw from stop() */
  }
}

/**
 * Create the level collector controller.
 *
 * @param {object} [options]
 * @param {(sample:{ts:number, peak:number})=>void} [options.onSample] each valid sample
 * @param {(info:{restarts:number, delay:number})=>void} [options.onRestart] backoff callback
 * @param {typeof spawn} [options.spawnImpl] injectable spawn (test)
 * @param {(pid:number)=>void} [options.killTreeImpl] injectable tree kill (test)
 * @param {(pid:number)=>boolean} [options.isAlive] injectable liveness probe
 * @param {string} [options.scriptPath] powershell script (default levelCollectorPath)
 * @param {number} [options.parentPid] guardian PID passed as argv[0] (default process.pid)
 * @param {number} [options.pollMs] sample interval ms, clamped [10,1000] (default 33)
 * @param {number} [options.baseDelay] backoff base ms (default 500)
 * @param {number} [options.maxDelay] backoff cap ms (default 30000)
 * @param {number} [options.healthMs] reset failures after this healthy uptime (default 5000)
 * @param {string|null} [options.auditFile] optional safefs log filename for restart audit
 * @returns {{
 *   start: () => object,
 *   stop: () => {pid:number|null},
 *   isRunning: () => boolean,
 *   pid: () => number|null,
 *   on: (event:string, cb:Function) => Function,
 *   restartCount: () => number,
 * }}
 */
export function createLevelCollector(options = {}) {
  const spawnImpl = options.spawnImpl || spawn
  const killTreeImpl = options.killTreeImpl || defaultKillTree
  const isAlive = options.isAlive || defaultIsAlive
  const onSample = options.onSample || (() => {})
  const onRestart = options.onRestart || null
  const scriptPath = options.scriptPath || levelCollectorPath
  const parentPid = options.parentPid != null ? options.parentPid : process.pid
  const pollMs = clampPollMs(options.pollMs != null ? options.pollMs : DEFAULT_POLL_MS)
  const baseDelay = options.baseDelay ?? 500
  const maxDelay = options.maxDelay ?? 30000
  const healthMs = options.healthMs ?? 5000
  const auditFile = options.auditFile || null

  let child = null
  let running = false
  let started = false
  let stopped = false
  let failures = 0 // consecutive failures so far (drives 2^failures)
  let restarts = 0
  let restartTimer = null
  let stableTimer = null
  let lineLeftover = ''
  let failureCounted = false // one backoff step per dead child (error line + exit = 1)
  let generation = 0 // start/stop cycles; stale child events are ignored
  const listeners = { restart: [] }

  function emit(event, payload) {
    for (const cb of listeners[event] || []) {
      try {
        cb(payload)
      } catch {
        /* listener errors must not break the loop */
      }
    }
  }

  function handleChunk(chunk) {
    lineLeftover += chunk
    let idx
    while ((idx = lineLeftover.indexOf('\n')) !== -1) {
      const raw = lineLeftover.slice(0, idx)
      lineLeftover = lineLeftover.slice(idx + 1)
      const parsed = parseLine(raw)
      if (parsed.ok) {
        onSample(parsed.sample)
      } else if (parsed.reason === 'error-line') {
        // Helper hit a fatal collection error (no endpoint / COM failure) and
        // is about to exit: count ONE failure and back off. No retry storm.
        countFailure()
      }
    }
  }

  function countFailure() {
    if (stopped) return
    if (failureCounted) return // error line + exit of the same child = one step
    failureCounted = true
    scheduleRestart()
  }

  function spawnChild() {
    // Race gate 1 (entry): a stop() that ran between scheduling and firing
    // must prevent any further spawn (spawn-after-stop = orphan, 7.1).
    if (stopped || !started) return null
    failureCounted = false
    // Race gate 2 (pre-spawn re-check): defense in depth right before the
    // actual spawn call -- deliberately no yield between gate 1 and gate 2.
    if (stopped || !started) return null
    // -ExecutionPolicy Bypass: the helper is a local, unsigned .ps1; do not let a
    // RemoteSigned/AllSigned host policy decide whether level sampling runs.
    const args = ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', scriptPath, String(parentPid), String(pollMs)]
    let c
    try {
      c = spawnImpl('powershell.exe', args, { windowsHide: true })
    } catch {
      // Spawn failed outright: count as a failure and back off.
      scheduleRestart()
      return null
    }
    child = c
    running = true
    const myGen = ++generation

    if (stableTimer) {
      clearTimeout(stableTimer)
      stableTimer = null
    }
    stableTimer = setTimeout(() => {
      // If this child survived healthMs, treat the streak as healthy and reset backoff.
      if (child === c && running && !stopped) failures = 0
    }, healthMs)

    if (c.stdout) {
      c.stdout.setEncoding('utf8')
      c.stdout.on('data', (chunk) => handleChunk(chunk))
    }
    if (c.stderr) {
      c.stderr.on('data', () => { /* ignore helper stderr noise */ })
    }
    c.on('exit', () => {
      // Stale child from a previous start/stop cycle: ignore entirely.
      if (myGen !== generation) return
      if (stableTimer) {
        clearTimeout(stableTimer)
        stableTimer = null
      }
      running = false
      if (stopped) return // intentional shutdown: no restart
      countFailure()
    })
    c.on('error', () => {
      if (myGen !== generation) return
      if (stableTimer) {
        clearTimeout(stableTimer)
        stableTimer = null
      }
      running = false
      if (stopped) return
      countFailure()
    })
    return c
  }

  function scheduleRestart() {
    // Race gate 3 (entry): never (re)schedule after stop().
    if (stopped) return
    // Backoff uses the count of PRIOR failures: 500, 1000, 2000, ... capped
    // at maxDelay; a healthy run past healthMs resets failures to 0.
    const delay = Math.min(maxDelay, baseDelay * Math.pow(2, failures))
    failures += 1
    if (restartTimer) clearTimeout(restartTimer)
    restartTimer = setTimeout(() => {
      restartTimer = null
      // Race gate 4 (timer callback): the callback may already have been
      // dequeued before stop() ran; this is the last line of defense.
      if (stopped) return
      restarts += 1
      const info = { restarts, delay }
      emit('restart', info)
      if (onRestart) {
        try {
          onRestart(info)
        } catch {
          /* ignore */
        }
      }
      if (auditFile) {
        try {
          appendJsonl(logPath(auditFile), { ts: Date.now(), source: 'music-level-collector', event: 'restart', ...info })
        } catch {
          /* ignore */
        }
      } else {
        // Structured stderr audit line (no disk write by default).
        console.error(JSON.stringify({ ts: Date.now(), source: 'music-level-collector', event: 'restart', ...info }))
      }
      spawnChild()
    }, delay)
  }

  function start() {
    if (started) return api // idempotent: never double-spawn
    started = true
    stopped = false
    failures = 0
    spawnChild()
    return api
  }

  function stop() {
    // Order matters: flip `stopped` FIRST so any already-dequeued restart-timer
    // callback (or in-flight exit handler) sees it, then clear the pending
    // restart timer, then kill the child tree synchronously.
    stopped = true
    started = false
    if (restartTimer) {
      clearTimeout(restartTimer)
      restartTimer = null
    }
    if (stableTimer) {
      clearTimeout(stableTimer)
      stableTimer = null
    }
    const c = child
    const pid = c ? c.pid : null
    if (c) {
      try {
        c.kill()
      } catch {
        /* ignore */
      }
      if (pid != null) {
        try {
          killTreeImpl(pid)
        } catch {
          /* ignore */
        }
      }
    }
    running = false
    return { pid }
  }

  function isRunning() {
    return running && started && !stopped
  }

  function pid() {
    return child ? child.pid : null
  }

  function restartCount() {
    return restarts
  }

  function on(event, cb) {
    if (!listeners[event]) listeners[event] = []
    listeners[event].push(cb)
    return () => {
      listeners[event] = (listeners[event] || []).filter((f) => f !== cb)
    }
  }

  const api = { start, stop, isRunning, pid, on, restartCount }
  return api
}

export default {
  createLevelCollector,
  parseLine,
  listOwnPowershell,
  killTreeArgs,
  defaultKillTree,
  levelCollectorPath,
  DEFAULT_POLL_MS,
}
