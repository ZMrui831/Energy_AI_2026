// packages/plugins/music/index.mjs
//
// S13「音乐律动光环」· B 路插件入口。
//
// 职责边界（契约 §3/§7）：
//   · 本插件只做**意图转发 + 状态呈现**：把 /music 子命令转给 ctx.core.music
//     （A 路 music-driver 的受控暴露面），把 driver.state() 摊成纯文本。
//   · 真正执行（起播/停播/拉电台/电平采集）一律在 driver 里；本插件不出网、
//     不落盘、不碰 DOM、不起定时器 —— activate 零副作用，禁用即完全干净。
//   · ctx.core.music 可能为 null（裸 registry 测试 / 宿主未装配 driver）：
//     此时所有子命令返回 { ok:false, code:'E_MUSIC_NO_DRIVER' }，**不抛异常**，
//     光环侧（ui/music.js）自行回落静态呼吸。
//
// 安全纪律（契约 §8 红线 6）：driver 状态里的电台名等音频元数据一律视为不可信
// 数据 —— 只做"截断 + 去控制符"后进入纯文本返回值；面板渲染走 textContent，
// 本文件不拼任何 HTML。

import { APP_VERSION } from '../../core/src/version.mjs'

export const PLUGIN_ID = 'music'
export const MUSIC_VERSION = APP_VERSION
export const MUSIC_CARD_ID = 'music.status'

const USAGE = [
  '音乐律动光环用法：',
  '  /music status      查看音源 / 播放 / 联网 / 电台数 / 降级状态',
  '  /music on          开启音乐（默认程序生成环境音，零网络）',
  '  /music off         关闭音乐并停止播放',
  '  /music toggle      开 / 关切换',
  '  /music ambient     播放程序生成环境音（T0，零网络）',
  '  /music network on  开启联网电台（默认关闭；仅白名单镜像与清单主机）',
  '  /music network off 关闭联网（立即拒绝任何出网与电台播放）',
  '  /music stations    列出精选电台（需联网开关已打开）',
  '  /music play <uuid> 播放指定电台',
].join('\n')

const NO_DRIVER_TEXT =
  '音乐驱动器未装配（ctx.core.music 为空）：命令未执行，光环回落静态呼吸，不发声、不联网。'

/** 取 driver（每次命令现取，容忍宿主晚于插件装配）。 */
function driverOf(ctx) {
  const core = ctx && ctx.core ? ctx.core : null
  const m = core ? core.music : null
  return m && typeof m === 'object' ? m : null
}

/** 读 driver 状态快照；任何失败都回落 null（调用方按"无状态"呈现，不抛）。 */
function readState(music) {
  if (!music || typeof music.state !== 'function') return null
  try {
    const s = music.state()
    return s && typeof s === 'object' ? s : null
  } catch {
    return null
  }
}

/** 音频元数据视为不可信：截断 + 去控制符（渲染侧仍是 textContent，双保险）。 */
function safeText(v, max = 80) {
  return String(v === undefined || v === null ? '' : v)
    .replace(/[\u0000-\u001f\u007f]/g, ' ')
    .trim()
    .slice(0, max)
}

/** 源的人话名称（电台台名/ID 同样过 safeText）。 */
function sourceLabel(s) {
  const st = s || {}
  const src = safeText(st.source, 32) || 'ambient'
  if (src === 'radio') {
    const station = safeText(st.station, 48)
    return station ? '电台 ' + station : '电台（未指定）'
  }
  if (src === 'ambient') return '程序生成环境音'
  return src
}

/** 纯文本状态行（卡片正文与 status 命令同一口径）。 */
function stateLines(s) {
  const st = s || {}
  return [
    '音乐状态：',
    '· 开关：' + (st.enabled ? '开' : '关'),
    '· 当前源：' + sourceLabel(st),
    '· 播放中：' + (st.playing ? '是' : '否'),
    '· 联网电台：' + (st.networkEnabled ? '已开启' : '关闭（默认不联网）'),
    '· 精选电台数：' + (Number(st.stationCount) || 0),
    '· 降级：' + (st.degraded ? '是（' + safeText(st.reason, 60) + '）' : '否'),
  ].join('\n')
}

function noDriver() {
  return { ok: false, code: 'E_MUSIC_NO_DRIVER', text: NO_DRIVER_TEXT }
}

function failed(err) {
  return { ok: false, code: 'E_MUSIC_COMMAND_FAILED', text: '音乐命令执行失败：' + safeText(err && err.message ? err.message : err, 120) }
}

/** 逐个调用 driver 动作：单个失败不影响同命令里的其它意图，也绝不向上抛。 */
function tryCall(music, name, arg) {
  const fn = music && typeof music[name] === 'function' ? music[name] : null
  if (!fn) return { ok: false, code: 'E_MUSIC_NO_DRIVER' }
  try {
    const r = arg === undefined ? fn.call(music) : fn.call(music, arg)
    return { ok: true, value: r }
  } catch (err) {
    return { ok: false, code: 'E_MUSIC_COMMAND_FAILED', error: err }
  }
}

/** 开：启用 + 默认源 T0 程序生成环境音（零网络，契约决策 §0）。 */
function turnOn(music) {
  const a = tryCall(music, 'setEnabled', true)
  if (!a.ok) return a
  const st = readState(music)
  if (!st || !st.playing) tryCall(music, 'playAmbient')
  return { ok: true }
}

/** 关：停播 + 停用（两个意图都转发，失败分别兜底）。 */
function turnOff(music) {
  const a = tryCall(music, 'stopMusic')
  const b = tryCall(music, 'setEnabled', false)
  return a.ok && b.ok ? { ok: true } : { ok: false, code: a.ok ? b.code : a.code, error: a.ok ? b.error : a.error }
}

function stationRows(list) {
  const rows = Array.isArray(list) ? list : list && Array.isArray(list.stations) ? list.stations : []
  const lines = ['精选电台（' + rows.length + ' 台）：']
  if (rows.length === 0) lines.push('（列表为空：联网开关可能未打开，或镜像暂不可用）')
  for (const s of rows.slice(0, 20)) {
    const name = safeText(s && (s.name || s.title), 48) || '（未命名台）'
    const uuid = safeText(s && s.uuid, 48)
    const codec = s && s.codec ? ' · ' + safeText(s.codec, 12) : ''
    lines.push('· ' + name + (uuid ? ' [' + uuid + ']' : '') + codec)
  }
  if (rows.length > 20) lines.push('……其余 ' + (rows.length - 20) + '台从略')
  return lines.join('\n')
}

/**
 * 命令主体：意图转发 + 状态呈现。所有返回都是普通对象，任何路径不抛。
 * @param {object|null} music ctx.core.music（A 路 driver）
 * @param {string} rest 子命令串
 * @returns {Promise<{ok:boolean, code?:string, text:string}>}
 */
export async function musicCommand(music, rest = '') {
  const tokens = String(rest || '').trim().split(/\s+/).filter(Boolean)
  const sub = tokens[0] || ''
  const arg = tokens.slice(1).join(' ')

  if (sub === 'status' || sub === '') {
    if (!music) return noDriver()
    const st = readState(music)
    if (!st) return failed(new Error('driver.state() 不可用'))
    return { ok: true, text: stateLines(st) }
  }

  if (sub === 'on' || sub === 'off' || sub === 'toggle' || sub === 'ambient') {
    if (!music) return noDriver()
    if (sub === 'ambient') {
      const r = tryCall(music, 'playAmbient')
      if (!r.ok) return r.error ? failed(r.error) : noDriver()
      return { ok: true, text: '已切到程序生成环境音（T0，零网络）。\n' + stateLines(readState(music)) }
    }
    if (sub === 'toggle') {
      const st = readState(music)
      const wantOff = !!(st && st.enabled)
      const r = wantOff ? turnOff(music) : turnOn(music)
      if (!r.ok) return r.error ? failed(r.error) : noDriver()
      return { ok: true, text: (wantOff ? '音乐已关闭。' : '音乐已开启（程序生成环境音）。') + '\n' + stateLines(readState(music)) }
    }
    const r = sub === 'on' ? turnOn(music) : turnOff(music)
    if (!r.ok) return r.error ? failed(r.error) : noDriver()
    return { ok: true, text: (sub === 'on' ? '音乐已开启（程序生成环境音）。' : '音乐已关闭。') + '\n' + stateLines(readState(music)) }
  }

  if (sub === 'network') {
    if (!music) return noDriver()
    if (typeof music.setNetworkEnabled !== 'function') return noDriver()
    const want = arg === 'on' || arg === 'true' || arg === '1' ? true : arg === 'off' || arg === 'false' || arg === '0' ? false : null
    if (want === null) {
      return { ok: false, code: 'E_MUSIC_BAD_ARGS', text: '用法：/music network on｜off（默认关闭，只允许白名单主机）' }
    }
    const r = tryCall(music, 'setNetworkEnabled', want)
    if (!r.ok) return r.error ? failed(r.error) : noDriver()
    const st = readState(music)
    if (!want && st && st.source === 'radio') tryCall(music, 'stopMusic')
    return {
      ok: true,
      text: (want ? '联网电台已开启（仅白名单镜像 + 逐条加入的清单主机）。' : '联网电台已关闭：拒绝任何出网与电台播放。') + '\n' + stateLines(st),
    }
  }

  if (sub === 'stations') {
    if (!music) return noDriver()
    if (typeof music.listStations !== 'function') return noDriver()
    let list = null
    try {
      list = await music.listStations()
    } catch (err) {
      return failed(err)
    }
    return { ok: true, text: stationRows(list) }
  }

  if (sub === 'play') {
    if (!music) return noDriver()
    const uuid = safeText(arg, 64)
    if (!uuid) return { ok: false, code: 'E_MUSIC_BAD_ARGS', text: '用法：/music play <uuid>（uuid 见 /music stations）' }
    if (typeof music.playStation !== 'function') return noDriver()
    try {
      await music.playStation(uuid)
    } catch (err) {
      return failed(err)
    }
    return { ok: true, text: '已开始播放电台 [' + uuid + ']。\n' + stateLines(readState(music)) }
  }

  return { ok: true, text: USAGE }
}

export async function activate(ctx) {
  const log = (ctx && ctx.log) || console
  const ui = ctx && ctx.ui ? ctx.ui : null

  if (ui && typeof ui.registerCard === 'function') {
    // 卡片正文 = activate 时的纯文本快照（源/播放/联网/电台数/降级）；
    // 动态状态走 /music status。driver 不在时如实呈现降级态，不报错、不弹通知。
    const snap = readState(driverOf(ctx))
    ui.registerCard({
      id: MUSIC_CARD_ID,
      title: '音乐律动光环',
      body: snap
        ? stateLines(snap) + '\n· 提示：/music on 开启（默认程序生成环境音，零网络）；/music status 看实时状态。'
        : '音乐律动光环：驱动器未装配（降级态）。光环保持静态微呼吸，不发声、不联网；装配后可用 /music on 开启。',
    })
  }

  if (ui && typeof ui.registerCommand === 'function') {
    ui.registerCommand({
      name: PLUGIN_ID,
      title: '音乐律动光环',
      description: '用法：/music on｜off｜status｜ambient｜stations｜play <uuid>',
      run: async (rest = '') => musicCommand(driverOf(ctx), rest),
    })
  }

  if (!driverOf(ctx)) {
    log.info('[music] ctx.core.music 未装配（裸注册表/宿主未接线）：命令返回 E_MUSIC_NO_DRIVER，光环静态呼吸')
  }

  return {
    // 本插件无自有进程/定时器/订阅，deactivate 只做日志；ctx 原样交回宿主
    // （plugins.test.mjs 的 handle.ctx 断言要它能核对能力面）。
    deactivate() {
      log.info('[music] 已停用（纯意图转发，无自有资源需要回收）')
    },
    ctx,
  }
}

export default { activate, musicCommand, PLUGIN_ID, MUSIC_VERSION, MUSIC_CARD_ID }
