# level-collector.ps1
#
# Long-lived audio level helper (S13 "music halo", Track C). Node spawns this
# EXACTLY ONCE; it loops forever and prints ONE JSON object per sample to
# stdout (JSONL):
#
#   {"ts":<unix_ms>,"peak":<0..1>}
#
# peak = WASAPI render-endpoint peak level (IAudioMeterInformation::GetPeakValue).
# RENDER ENDPOINT ONLY: no capture / recording API is referenced anywhere in
# this file (hard red line -- never open the microphone, never record).
#
# Contract:
#   - Windows PowerShell 5.1 compatible (no 7+ only cmdlets / syntax).
#   - UTF-8 output, NO BOM.
#   - ASCII comments only (no Chinese) to avoid encoding pitfalls.
#   - Never steals focus, never shows a window, never makes sound.
#   - Exits cleanly when the parent (Node controller) dies or on kill.
#
# Why the loop lives in C# (Add-Type): a PowerShell pipeline round-trip per
# sample at 30 Hz would eat the CPU budget; a C# loop with Thread.Sleep costs
# close to zero. JSON lines are hand-built strings (never ConvertTo-Json).
#
# Known fact (no special handling needed): in exclusive-mode output the
# software meter table reads a constant 0; the upper layer applies its own
# double-threshold hysteresis.
#
# argv (fixed order -- keep in sync with level-collector.mjs):
#   argv[0] = parent PID (Node controller; absent or 0 = no guardian)
#   argv[1] = sample interval in ms (optional; default 33, clamped [10,1000])
#
# Fatal errors (no audio endpoint / COM activation failure / Add-Type blocked)
# print ONE {"ts":..,"error":"<ascii>"} line and exit -- no retry storm here;
# the Node side owns the exponential-backoff restart.

$ErrorActionPreference = 'Stop'

# Force UTF-8 WITHOUT BOM on stdout.
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = $utf8NoBom

# ---------------------------------------------------------------------------
# argv parsing: parent PID (guardian) + sample interval (ms).
# ---------------------------------------------------------------------------
$parentPid = 0
if ($args.Count -ge 1 -and $args[0] -match '^\d+$') { $parentPid = [int]$args[0] }

$pollMs = 33
if ($args.Count -ge 2 -and $args[1] -match '^\d+$') {
  $pollMs = [int]$args[1]
  if ($pollMs -lt 10) { $pollMs = 10 }
  elseif ($pollMs -gt 1000) { $pollMs = 1000 }
}

# One-line fatal reporter: hand-built JSON, ASCII reason, no BOM.
function Emit-Fatal {
  param([string]$Reason)
  $line = '{"ts":' + [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() + ',"error":"' + $Reason + '"}'
  [Console]::Out.Write($line + [char]10)
  [Console]::Out.Flush()
}

# ---------------------------------------------------------------------------
# The collector itself: COM contracts + sampling loop, all sunk into C#.
# ---------------------------------------------------------------------------
$csSource = @"
using System;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

public class MusicLevel {
  // Win32: parent-PID guardian. OpenProcess(SYNCHRONIZE) + WaitForSingleObject
  // doubles as "sleep pollMs AND detect parent death" -- it returns the
  // instant the parent process object is signaled, covering SIGKILL / power
  // loss within milliseconds. No handle available -> Thread.Sleep + liveness
  // polling fallback (same degradation as the perception collector).
  [DllImport("kernel32.dll")] static extern IntPtr OpenProcess(uint access, bool inherit, uint pid);
  [DllImport("kernel32.dll")] static extern uint WaitForSingleObject(IntPtr handle, uint ms);
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
  [DllImport("ole32.dll")] static extern int CoCreateInstance(ref Guid clsid, IntPtr outer, uint context, ref Guid iid, out IntPtr result);

  const uint SYNCHRONIZE = 0x00100000;
  const uint CLSCTX_ALL = 23;

  static readonly Guid CLSID_MMDeviceEnumerator = new Guid("BCDE0395-E52F-467C-8E3D-C4579291692E");
  static readonly Guid IID_IMMDeviceEnumerator = new Guid("A95664D2-9614-4F35-A746-DE8DB63617E6");
  // NOTE: IID_IAudioMeterInformation is ...D008E73E0064 (NOT ...D008E73CE006,
  // which was the original bug: Activate returned E_NOINTERFACE 0x80004002).
  // Verified against winapi.rs / go-wca / working MinGW sample.
  static readonly Guid IID_IAudioMeterInformation = new Guid("C02216F6-8C67-4B5B-9D00-D008E73E0064");

  // COM contracts. Method ORDER is the vtable order and must not change;
  // methods this collector never calls are declared as order placeholders.
  // Render-endpoint meter only: dataFlow 0 = render, role 1 = multimedia.
  [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  public interface IMMDeviceEnumerator {
    [PreserveSig] int EnumAudioEndpoints(int dataFlow, int stateMask, out object devices);
    [PreserveSig] int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice device);
    [PreserveSig] int GetDevice([MarshalAs(UnmanagedType.LPWStr)] string id, out object device);
    [PreserveSig] int RegisterEndpointNotificationCallback(IntPtr client);
    [PreserveSig] int UnregisterEndpointNotificationCallback(IntPtr client);
  }

  [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  public interface IMMDevice {
    [PreserveSig] int Activate(ref Guid iid, int clsCtx, IntPtr activationParams, out IntPtr iface);
    [PreserveSig] int OpenPropertyStore(int access, out object store);
    [PreserveSig] int GetId(out IntPtr id);
    [PreserveSig] int GetState(out int state);
  }

  [ComImport, Guid("C02216F6-8C67-4B5B-9D00-D008E73E0064"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
  public interface IAudioMeterInformation {
    [PreserveSig] int GetPeakValue(out float peak);
    [PreserveSig] int GetMeteringChannelCount(out uint count);
    [PreserveSig] int GetChannelsPeakValues(uint count, IntPtr values);
    [PreserveSig] int QueryHardwareSupport(out uint mask);
  }

  // Returns 0 on clean exit (parent died / killed), 1 on fatal collection
  // error (one {"ts":..,"error":".."} line already emitted in that case).
  public static int Run(int parentPid, int pollMs) {
    if (pollMs < 10) { pollMs = 10; }
    if (pollMs > 1000) { pollMs = 1000; }

    // Parent-PID guardian: one OpenProcess(SYNCHRONIZE) up front. If the
    // handle cannot be opened AND the parent is already gone, exit at once;
    // otherwise fall back to sleep + liveness polling (no handle available).
    IntPtr hParent = IntPtr.Zero;
    if (parentPid > 0) {
      hParent = OpenProcess(SYNCHRONIZE, false, (uint)parentPid);
      if (hParent == IntPtr.Zero && !ParentAlive(parentPid)) {
        EmitError("parent-gone");
        return 0;
      }
    }

    // COM setup: default render endpoint -> audio meter interface.
    IMMDeviceEnumerator enumerator = null;
    IMMDevice device = null;
    IAudioMeterInformation meter = null;
    try {
      // NOTE: C# forbids passing a static readonly field as a ref/out argument,
      // so the GUIDs are copied into locals first (this was the original bug:
      // Add-Type failed to compile -> trap{exit 0} swallowed it -> silent death).
      Guid clsid = CLSID_MMDeviceEnumerator;
      Guid iidEnum = IID_IMMDeviceEnumerator;
      IntPtr pEnum = IntPtr.Zero;
      int hr = CoCreateInstance(ref clsid, IntPtr.Zero, CLSCTX_ALL, ref iidEnum, out pEnum);
      if (hr != 0 || pEnum == IntPtr.Zero) { EmitError("com-enumerator:" + Hex(hr)); return 1; }
      enumerator = (IMMDeviceEnumerator)Marshal.GetObjectForIUnknown(pEnum);

      hr = enumerator.GetDefaultAudioEndpoint(0, 1, out device);
      if (hr != 0 || device == null) { EmitError("no-endpoint:" + Hex(hr)); return 1; }

      Guid iidMeter = IID_IAudioMeterInformation;
      IntPtr pMeter = IntPtr.Zero;
      hr = device.Activate(ref iidMeter, (int)CLSCTX_ALL, IntPtr.Zero, out pMeter);
      if (hr != 0 || pMeter == IntPtr.Zero) { EmitError("meter-activate:" + Hex(hr)); return 1; }
      meter = (IAudioMeterInformation)Marshal.GetObjectForIUnknown(pMeter);
    } catch (Exception ex) {
      EmitError("com-setup:" + Ascii(ex.Message));
      return 1;
    }

    // Sampling loop: one JSONL line per round, flushed immediately.
    try {
      while (true) {
        if (hParent != IntPtr.Zero) {
          uint w = WaitForSingleObject(hParent, (uint)pollMs);
          if (w == 0U) { return 0; }   // parent died: self-terminate
        } else {
          Thread.Sleep(pollMs);
          if (parentPid > 0 && !ParentAlive(parentPid)) { return 0; }
        }
        float peak = 0f;
        int hr2 = meter.GetPeakValue(out peak);
        if (hr2 != 0) { EmitError("get-peak:" + Hex(hr2)); return 1; }
        if (!(peak >= 0f)) { peak = 0f; }   // NaN / negative -> 0
        if (peak > 1f) { peak = 1f; }
        long ts = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        Console.Out.Write("{\"ts\":" + ts.ToString(CultureInfo.InvariantCulture) + ",\"peak\":" + peak.ToString("F4", CultureInfo.InvariantCulture) + "}\n");
        Console.Out.Flush();
      }
    } catch (Exception ex) {
      EmitError("loop:" + Ascii(ex.Message));
      return 1;
    } finally {
      if (hParent != IntPtr.Zero) { CloseHandle(hParent); }
    }
  }

  // Fallback guardian probe (only used when no parent handle is available).
  static bool ParentAlive(int pid) {
    try {
      System.Diagnostics.Process p = System.Diagnostics.Process.GetProcessById(pid);
      return !p.HasExited;
    } catch {
      return false;
    }
  }

  static string Hex(int hr) {
    return hr.ToString("X8", CultureInfo.InvariantCulture);
  }

  // Keep error reasons ASCII and JSON-safe (no quotes / backslashes / controls).
  static string Ascii(string s) {
    if (string.IsNullOrEmpty(s)) { return "unknown"; }
    StringBuilder sb = new StringBuilder();
    int n = 0;
    foreach (char c in s) {
      if (n >= 80) { break; }
      if (c == '"') { sb.Append('\''); n++; }
      else if (c == '\\') { sb.Append('/'); n++; }
      else if (c < ' ' || c > '~') { sb.Append('?'); n++; }
      else { sb.Append(c); n++; }
    }
    return sb.ToString();
  }

  static void EmitError(string reason) {
    try {
      long ts = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
      Console.Out.Write("{\"ts\":" + ts.ToString(CultureInfo.InvariantCulture) + ",\"error\":\"" + reason + "\"}\n");
      Console.Out.Flush();
    } catch {
      // stdout already closed: nothing to report, just exit.
    }
  }
}
"@

try {
  Add-Type -TypeDefinition $csSource
} catch {
  Emit-Fatal 'add-type-blocked'
  exit 1
}
if (-not ('MusicLevel' -as [type])) {
  Emit-Fatal 'type-missing'
  exit 1
}

# Clean exit on Ctrl-C / terminate. NOTE: emit a fatal line first -- a bare
# `trap { exit 0 }` silently swallows real errors (that is how the original
# ref-argument compile failure hid: zero output, child just died).
trap { Emit-Fatal 'trapped'; exit 0 }

$rc = 1
try {
  $rc = [MusicLevel]::Run($parentPid, $pollMs)
} catch {
  Emit-Fatal 'run-threw'
  exit 1
}
exit $rc
