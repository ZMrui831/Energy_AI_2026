// packages/plugins/health-log/index.mjs
//
// 健康（health）pack 的能力实现：/health log <项目> <状态>。
//
// 纪律：
//   · 数据只落 data/packs/health/journal.jsonl（声明式 scopes: ["packs"]）；
//   · **零联网**：健康数据不外发（企业版与个人版都适用）；
//   · 只做记录与统计，不给任何医疗建议（免责声明写进命令输出）。

import { join } from 'node:path'
import { APP_VERSION } from '../../core/src/version.mjs'

export const HEALTH_LOG_VERSION = APP_VERSION
const PACK_ROOT = 'health'

const DISCLAIMER = '（本工具只做本地记录与统计，不构成任何医疗建议）'

function today() {
  const d = new Date()
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}

export async function activate(ctx) {
  const log = ctx.log
  const packs = ctx.fs.scope('packs')
  const journalPath = join(PACK_ROOT, 'journal.jsonl')

  const readJournal = () => {
    if (!packs.exists(journalPath)) return []
    return packs.read(journalPath).split('\n').filter(Boolean).map((l) => {
      try { return JSON.parse(l) } catch { return null }
    }).filter(Boolean)
  }

  log.info(`health-log 已激活（v${HEALTH_LOG_VERSION}），数据根 data/packs/${PACK_ROOT}/`)

  ctx.ui.registerCard({
    id: 'health.log',
    title: '健康记录',
    body: `今日 ${readJournal().filter((e) => String(e.at).slice(0, 10) === today()).length} 条｜数据目录 data/packs/${PACK_ROOT}/`,
    actions: ['health'],
  })

  ctx.ui.registerCommand({
    name: 'health',
    title: '健康记录',
    description: '记录一条健康日志。用法：/health log <项目> <状态>｜/health list｜/health today',
    run: async (rest = '') => {
      const tokens = String(rest || '').trim().split(/\s+/).filter(Boolean)
      const sub = tokens[0]

      if (sub === 'list') {
        const rows = readJournal().slice(-50).reverse()
        return {
          ok: true,
          text: rows.length
            ? `最近 ${rows.length} 条健康记录：\n` + rows.map((e) => `· [${String(e.at).slice(5, 16)}] ${e.item} → ${e.state}`).join('\n')
            : '暂无健康记录（写入：/health log <项目> <状态>）',
        }
      }

      if (sub === 'today') {
        const rows = readJournal().filter((e) => String(e.at).slice(0, 10) === today())
        const byItem = {}
        for (const e of rows) byItem[e.item] = (byItem[e.item] || 0) + 1
        const lines = [
          `# 健康记录（${today()}）`,
          '',
          `- 今日记录：${rows.length} 条`,
          ...Object.entries(byItem).map(([k, v]) => `- ${k}：${v} 次`),
          '',
          DISCLAIMER,
        ]
        return { ok: true, text: lines.join('\n'), ui: { kind: 'report', title: `健康记录 ${today()}`, markdown: lines.join('\n') } }
      }

      if (sub === 'log') {
        const item = tokens[1]
        const state = tokens.slice(2).join(' ').trim()
        if (!item || !state) {
          return { ok: false, code: 'E_BAD_ARGS', text: '用法：/health log <项目> <状态>（例：/health log 睡眠 7小时）' }
        }
        const entry = { at: new Date().toISOString(), item, state }
        packs.append(journalPath, `${JSON.stringify(entry)}\n`)
        log.info(`健康记录：${item} → ${state}`)
        return { ok: true, text: `已记录：${item} → ${state}（落 data/packs/${PACK_ROOT}/journal.jsonl）${DISCLAIMER}` }
      }

      return {
        ok: true,
        text: [
          '健康记录用法：',
          '  /health log <项目> <状态>   记录一条（例：/health log 血压 120/80）',
          '  /health list                最近 50 条',
          '  /health today               当日汇总',
          DISCLAIMER,
        ].join('\n'),
      }
    },
  })

  return { deactivate() { log.info('health-log 已停用') } }
}

export default { activate }
