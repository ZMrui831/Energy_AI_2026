// packages/plugins/research-browser/index.mjs
//
// 非影响性浏览器插件（L1）：/web <url> 抽取结构化结果与引用元数据；
// /web auth <domain> 提供「按任务临时授权」显式通道；/web list 查看已落盘证据。
// 合规红线（ROADMAP-v2 §3.3）在 engine / compliance 层强制：白名单 + 临时授权 + 黑名单硬拒。

import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, dataPath } from '../../core/src/safefs.mjs'
import { loadSettings, isEnterprise } from '../../core/src/settings.mjs'
import { createBrowserEngine } from './lib/engine.mjs'
import { createYieldGuard } from './lib/yield-guard.mjs'

/** 从 data/secrets.json 读取代理（仅本应用密钥来源）。值绝不打印/审计。 */
function loadProxy() {
  try {
    const p = dataPath('secrets.json')
    if (!existsSync(p)) return null
    const obj = JSON.parse(readFileSync(p, 'utf8'))
    return obj && typeof obj.proxy === 'string' && obj.proxy ? obj.proxy : null
  } catch {
    return null
  }
}

function parseArgs(rest) {
  const tokens = String(rest || '').trim().split(/\s+/).filter(Boolean)
  const flags = {}
  const positional = []
  for (let i = 0; i < tokens.length; i += 1) {
    const t = tokens[i]
    if (t === '--temp') flags.temp = true
    else if (t === '--auth') { flags.auth = tokens[i + 1]; i += 1 }
    else positional.push(t)
  }
  return { positional, flags }
}

export async function activate(ctx) {
  const proxy = loadProxy() // 已打码语义：值不进日志
  // 默认让路钩子为「视为空闲」（headless 不抢前台）。真实桌面环境应注入 powerMonitor 版。
  const yieldGuard = createYieldGuard({ getIdleSec: () => Number.POSITIVE_INFINITY, isForegroundOurs: () => true })
  // P-R6：企业版门禁。edition 每次 browse 时现读（用户在面板里改完即刻生效，无需重启插件）。
  const engine = createBrowserEngine({
    net: ctx.net || null,
    proxy,
    yieldGuard,
    isEnterpriseFn: () => isEnterprise(loadSettings()),
  })

  const run = async (rest = '') => {
    const { positional, flags } = parseArgs(rest)
    const sub = positional[0]

    if (!sub) {
      return {
        ok: true,
        text: [
          '非影响性浏览器（L1）用法：',
          '  /web <url>              抽取结构化结果与引用元数据（白名单或已授权域）',
          '  /web <url> --temp       使用一次性临时 profile（不落 cookie/历史）',
          '  /web auth <domain>       按任务临时授权一个域名（审计留痕）',
          '  /web list               列出已落盘证据（data/browser/）',
        ].join('\n'),
      }
    }

    if (sub === 'list') {
      const files = engine.listEvidence()
      return { ok: true, text: files.length ? `已落盘 ${files.length} 份：\n` + files.join('\n') : '暂无证据（data/browser/ 为空）' }
    }

    if (sub === 'auth') {
      const domain = positional[1]
      if (!domain) return { ok: false, code: 'E_BAD_ARGS', text: '/web auth <domain>' }
      const list = engine.authorizeTemp(domain)
      return { ok: true, text: `已临时授权：${domain}（当前 ${list.length} 个）。行为会被审计，且不覆盖白名单/黑名单规则。` }
    }

    // 其余：视为 URL
    const url = sub
    const r = await engine.browse({ url, opts: { temp: !!flags.temp } })
    if (!r.ok) {
      return { ok: false, code: r.code, text: `未执行：${r.reason}` }
    }
    const d = r.data
    const lines = [
      `已抽取并落盘：${r.path}`,
      `标题：${d.title}`,
      d.authors.length ? `作者：${d.authors.join(', ')}` : null,
      d.year ? `年份：${d.year}` : null,
      d.doi ? `DOI：${d.doi}` : null,
      d.journal ? `来源：${d.journal}` : null,
      d.abstract ? `摘要：${d.abstract.slice(0, 200)}` : null,
      `正文片段：${d.snippet.slice(0, 200)}`,
    ].filter(Boolean)
    return { ok: true, text: lines.join('\n') }
  }

  ctx.ui.registerCommand({
    name: 'web',
    title: '非影响性网页抽取（L1）',
    description: '无头打开 URL，抽取标题/作者/年份/DOI/摘要/正文片段并落 data/browser/。合规：白名单+临时授权，sci-hub/libgen 硬拒。',
    run,
  })

  return { engine, deactivate: () => engine.dispose() }
}

export default { activate }
