// packages/plugins/kb/index.mjs
//
// S23·A 本地知识库命令（/kb add|find|cite|list|rm）。
// 纪律：
//   · 只调用 engine.mjs 的纯能力；不改证据链主流程（cite 产出的引用可经
//     lifecycle.attachEvidence 挂链 —— 与 vault-notes 同一 store 解析模式）。
//   · 零网络、零新依赖（PDF 走既有 unpdf）；写盘全部在项目根内 data\kb\。
//   · 命名边界：本实现是本地文献的"可检索化 + 可回指"，不声称"语义检索/全文理解"。
import { join } from 'node:path'
import { attachEvidence } from '../../core/src/lifecycle/publish.mjs'
import { PROJECT_ROOT, dataPath } from '../../core/src/safefs.mjs'
import { createKb, KbError, KB_DEFAULT_TOPN } from './engine.mjs'

export const PLUGIN_ID = 'kb'
export const KB_DIR = dataPath('kb')

const USAGE = '用法：/kb add <目录|文件>｜/kb find <关键词> [--top N]｜/kb cite <docId> [页码] [--claim <claimId>]｜/kb list｜/kb rm <docId>'

/** 取 lifecycle store：与 vault-notes 同一模式（调用时取，宿主异步 bootstrap 后桥上才有）。 */
function resolveStore(ctx) {
  const direct = (ctx && ctx.core && ctx.core.lifecycle) || null
  if (direct) return direct
  const bridge = globalThis.researchOrbLifecycle
  return bridge && bridge.store ? bridge.store : null
}

function fmtDoc(d) {
  return `· ${d.docId}  ${d.fileName}（${d.kind}，${d.pages} 页 / ${d.blocks} 块 / ${d.chars} 字${d.truncated ? '，超档截断' : ''}）`
}

function parseFlags(rest) {
  const flags = {}
  const parts = []
  for (let i = 0; i < rest.length; i++) {
    const p = rest[i]
    if (p.startsWith('--') && i + 1 < rest.length) { flags[p.slice(2)] = rest[i + 1]; i++ }
    else parts.push(p)
  }
  return { flags, args: parts }
}

export async function activate(ctx) {
  const log = (ctx && ctx.log) || console

  if (ctx && ctx.ui && typeof ctx.ui.registerCard === 'function') {
    ctx.ui.registerCard({ id: 'kb.status', title: '本地知识库', body: '把本地 PDF/MD/TXT 做成可检索、可回指的库：/kb add 入库，/kb find 检索，/kb cite 生成 kb:docId#page=N 证据引用。' })
  }

  if (!(ctx && ctx.ui && typeof ctx.ui.registerCommand === 'function')) {
    log.warn('kb: 宿主未提供 ui.registerCommand')
    return { ok: false }
  }

  ctx.ui.registerCommand({
    name: 'kb',
    title: '本地知识库',
    description: USAGE,
    run: async (rest = '') => {
      const parts = String(rest || '').trim().split(/\s+/).filter(Boolean)
      const sub = (parts[0] || '').toLowerCase()
      try {
        const kb = createKb({ dir: KB_DIR })
        if (sub === 'add') {
          const target = String(rest).trim().slice(('add').length).trim()
          if (!target) return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '需要目录或文件路径。\n' + USAGE } }
          const r = await kb.addPath(target)
          const lines = [`入库完成：新增 ${r.added.length}，跳过 ${r.skipped.length}，失败 ${r.errors.length}`]
          for (const d of r.added) lines.push(fmtDoc(d))
          for (const s of r.skipped) lines.push(`· 跳过 ${s.file}：${s.reason}（${s.note}）`)
          for (const e of r.errors) lines.push(`· 失败 ${e.file}：${e.code}（${e.message}）`)
          return { ok: r.errors.length === 0, text: lines.join('\n'), ui: { kind: 'text', message: lines.join('\n') } }
        }
        if (sub === 'find') {
          const { flags, args } = parseFlags(parts.slice(1))
          const query = args.join(' ').trim()
          if (!query) return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '需要检索词。\n' + USAGE } }
          const topN = Number.isFinite(Number(flags.top)) ? Number(flags.top) : KB_DEFAULT_TOPN
          const r = kb.find(query, { topN })
          const lines = [`检索「${query}」：命中 ${r.hits.length} 条（库内 ${r.totalChunks} 块，topN=${r.topN}）`]
          r.hits.forEach((h, i) => lines.push(`${i + 1}. ${h.docId} ${h.fileName} p${h.page} score=${h.score}\n   ${h.snippet}`))
          if (r.hits.length === 0) lines.push('（无命中——可换个关键词或先 /kb add）')
          return { ok: true, text: lines.join('\n'), ui: { kind: 'text', message: lines.join('\n') } }
        }
        if (sub === 'cite') {
          const { flags, args } = parseFlags(parts.slice(1))
          const docId = args[0]
          if (!docId) return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '需要 docId（/kb list 可查）。\n' + USAGE } }
          const page = Number.isFinite(Number(args[1])) ? Number(args[1]) : 1
          const c = kb.cite(docId, page)
          const lines = [
            `证据引用：${c.ref}`,
            `证据卡：本地文件 ${c.fileName} · 第 ${c.page} 页 · sha256=${String(c.sha256 || '').slice(0, 16)}…`,
          ]
          if (flags.claim) {
            const store = resolveStore(ctx)
            if (!store) {
              lines.push('挂链失败：宿主未接入 lifecycle store（E_NO_STORE）；引用已生成，可稍后重试 --claim。')
              return { ok: false, code: 'E_NO_STORE', text: lines.join('\n') }
            }
            // layer 受 0002 迁移 CHECK 约束 → kb 引用走通用 evidence_item 层；
            // "本地文件+页码"由 evidenceId（kb_<docId>_p<page>）与 kb.jsonl 审计承载。
            const at = attachEvidence(store, { claimId: flags.claim, evidenceId: c.evidenceId, layer: 'evidence_item', relation: 'direct', sha256: c.sha256 })
            if (!at || at.ok !== true) {
              lines.push(`挂链失败：${(at && at.code) || 'E_ATTACH'}（${(at && at.reason) || '未知'}）`)
              return { ok: false, code: (at && at.code) || 'E_ATTACH', text: lines.join('\n') }
            }
            lines.push(`已挂到结论 ${flags.claim}（evidence_id=${c.evidenceId}，layer=evidence_item）。`)
          }
          return { ok: true, text: lines.join('\n'), ui: { kind: 'kb-cite', ref: c.ref, evidenceId: c.evidenceId } }
        }
        if (sub === 'list') {
          const all = kb.list()
          const lines = [`库内文档 ${all.length} 份：`]
          for (const d of all) lines.push(fmtDoc(d))
          if (all.length === 0) lines.push('（空库——用 /kb add <目录|文件> 入库）')
          return { ok: true, text: lines.join('\n'), ui: { kind: 'text', message: lines.join('\n') } }
        }
        if (sub === 'rm') {
          const docId = parts[1]
          if (!docId) return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '需要 docId。\n' + USAGE } }
          const r = kb.rm(docId)
          return { ok: true, text: `已移除 ${r.docId}（${r.fileName}）及其全部分块。`, ui: { kind: 'text', message: '已移除 ' + r.docId } }
        }
        return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: USAGE } }
      } catch (e) {
        const code = e instanceof KbError ? e.code : ((e && e.code) || 'E_KB')
        return { ok: false, code, ui: { kind: 'error', message: String((e && e.message) || e) } }
      }
    },
  })
  return { ok: true }
}

export default { activate, PLUGIN_ID, KB_DIR }
