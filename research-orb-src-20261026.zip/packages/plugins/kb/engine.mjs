// packages/plugins/kb/engine.mjs
//
// S23·A 本地知识库 v1（禁 embedding）：关键词倒排 + 简化 BM25，纯 JS 零依赖。
//
// 纪律：
//   · 与 research-literature/lib/pdf.mjs 同一立场：读用户显式给出的路径即意图（读不受
//     safefs 管辖）；**写**一律落在项目根内 data\kb\（safeWrite/appendJsonl，根内断言+审计）。
//   · PDF 抽取复用既有 unpdf 依赖（不新增依赖）；MD/TXT 直读。
//   · 分块：段落优先 + 800 字/块、重叠 80 字；每块保留 docId+page+blockIndex。
//   · 单库上限受 mode caps 约束：每文件抽取文本 cap = capOf('readMaxBytes')，
//     全库抽取文本总量 cap = capOf('readMaxBytes')（standard 200KB / lean 64KB，不写死数字）。
//   · 落审计 data\logs\kb.jsonl：kb-add / kb-cite / kb-rm。
//   · /kb cite 生成 `kb:<docId>#page=<n>` 形式的证据引用，可经 lifecycle.attachEvidence 挂链。

import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs'
import { join, basename, extname, resolve as resolvePath } from 'node:path'

import { PROJECT_ROOT, safeWrite, appendJsonl, logPath, dataPath } from '../../core/src/safefs.mjs'
import { capOf } from '../../core/src/modes.mjs'

export const KB_BLOCK_CHARS = 800
export const KB_OVERLAP_CHARS = 80
export const KB_SNIPPET_CHARS = 160
export const KB_DEFAULT_TOPN = 10
export const KB_EXTS = Object.freeze(['.pdf', '.md', '.markdown', '.txt'])
export const KB_SCHEMA_VERSION = 1

/** BM25 经典参数（ robertson/sparck-jones 口径，非业务魔法数）。 */
const BM25_K1 = 1.2
const BM25_B = 0.75

export class KbError extends Error {
  constructor(code, message) { super(message); this.name = 'KbError'; this.code = code }
}

// ---------------------------------------------------------------------------
// 文本处理：分词 / 分块
// ---------------------------------------------------------------------------

/**
 * 检索分词：latin/digit 词 + CJK 双字组（bigram）。中文无分词依赖，bigram 是零依赖下
 * 召回/精度折中（v1 口径，索引与查询用同一函数保证一致）。
 */
export function tokenize(text) {
  const s = String(text || '').toLowerCase()
  const out = []
  for (const m of s.matchAll(/[a-z0-9][a-z0-9+#.\-]*/g)) out.push(m[0])
  for (const m of s.matchAll(/[\u3400-\u4dbf\u4e00-\u9fff]+/g)) {
    const run = m[0]
    if (run.length === 1) { out.push(run); continue }
    for (let i = 0; i < run.length - 1; i++) out.push(run.slice(i, i + 2))
  }
  return out
}

/**
 * 分块：段落（空行分隔）优先；超过 800 字的段落滑窗切 800/80。
 * @returns {Array<{page:number, blockIndex:number, text:string}>} blockIndex 由调用方续号
 */
export function chunkPageText(text, page, startBlockIndex = 0) {
  const src = String(text || '').replace(/\r\n/g, '\n').trim()
  if (!src) return []
  const paragraphs = src.split(/\n{2,}/).map((p) => p.trim()).filter(Boolean)
  const out = []
  let idx = startBlockIndex
  for (const para of paragraphs) {
    if (para.length <= KB_BLOCK_CHARS) {
      out.push({ page, blockIndex: idx++, text: para })
      continue
    }
    let start = 0
    while (start < para.length) {
      const end = Math.min(start + KB_BLOCK_CHARS, para.length)
      out.push({ page, blockIndex: idx++, text: para.slice(start, end) })
      if (end >= para.length) break
      start = end - KB_OVERLAP_CHARS
    }
  }
  return out
}

/** 生成命中片段：以第一个命中词为中心取 KB_SNIPPET_CHARS 窗口。 */
export function makeSnippet(text, terms, maxChars = KB_SNIPPET_CHARS) {
  const src = String(text || '').replace(/\s+/g, ' ').trim()
  if (!src) return ''
  let at = -1
  for (const t of terms) {
    const i = src.indexOf(t)
    if (i !== -1 && (at === -1 || i < at)) at = i
  }
  if (at === -1) return src.slice(0, maxChars)
  const start = Math.max(0, at - 40)
  const body = src.slice(start, start + maxChars)
  return (start > 0 ? '…' : '') + body + (start + maxChars < src.length ? '…' : '')
}

function fileHash(bytes) {
  return createHash('sha256').update(bytes).digest('hex')
}

// ---------------------------------------------------------------------------
// 引擎
// ---------------------------------------------------------------------------

/**
 * @param {{ dir?: string, log?: Function }} [opts]
 * dir 默认 <项目根>\data\kb；测试可注入 data\tmp\...（仍在根内，safeWrite 放行）。
 */
export function createKb(opts = {}) {
  const dir = resolvePath(opts.dir || dataPath('kb'))
  const docsFile = join(dir, 'docs.json')
  const chunksFile = join(dir, 'chunks.jsonl')
  const indexFile = join(dir, 'index.json')
  const auditLog = () => logPath('kb.jsonl')

  /** @type {Map<string, object>} */
  const docs = new Map()
  /** @type {Array<{docId:string, page:number, blockIndex:number, text:string}>} */
  const chunks = []
  /** 倒排：term -> Map(chunkKey -> tf)；chunkKey = `${docId}:${blockIndex}` */
  const terms = new Map()
  const chunkLen = new Map()

  function load() {
    if (existsSync(docsFile)) {
      try {
        const raw = JSON.parse(readFileSync(docsFile, 'utf8'))
        for (const d of (raw && raw.docs) || []) docs.set(d.docId, d)
      } catch { /* 损坏按空库重建 */ }
    }
    if (existsSync(chunksFile)) {
      try {
        for (const line of readFileSync(chunksFile, 'utf8').split('\n')) {
          const t = line.trim()
          if (!t) continue
          try { chunks.push(JSON.parse(t)) } catch { /* 跳过坏行 */ }
        }
      } catch { /* 同上 */ }
    }
    rebuildIndex()
  }

  function chunkKey(c) { return `${c.docId}:${c.blockIndex}` }

  function rebuildIndex() {
    terms.clear()
    chunkLen.clear()
    for (const c of chunks) {
      const toks = tokenize(c.text)
      chunkLen.set(chunkKey(c), toks.length)
      for (const t of toks) {
        let m = terms.get(t)
        if (!m) { m = new Map(); terms.set(t, m) }
        m.set(chunkKey(c), (m.get(chunkKey(c)) || 0) + 1)
      }
    }
  }

  function persist() {
    mkdirSync(dir, { recursive: true })
    safeWrite(docsFile, JSON.stringify({ version: KB_SCHEMA_VERSION, docs: [...docs.values()] }, null, 2))
    safeWrite(chunksFile, chunks.map((c) => JSON.stringify(c)).join('\n') + (chunks.length ? '\n' : ''))
    const docLen = {}
    let totalLen = 0
    for (const [k, n] of chunkLen) { docLen[k] = n; totalLen += n }
    const nChunks = chunkLen.size
    const termsObj = {}
    for (const [t, m] of terms) {
      const o = {}
      for (const [k, tf] of m) o[k] = tf
      termsObj[t] = o
    }
    safeWrite(indexFile, JSON.stringify({
      version: KB_SCHEMA_VERSION,
      totalDocs: docs.size,
      totalChunks: nChunks,
      avgChunkLen: nChunks ? totalLen / nChunks : 0,
      docLen,
      terms: termsObj,
    }))
  }

  function audit(record) {
    try { appendJsonl(auditLog(), record) } catch { /* 审计尽力 */ }
  }

  function totalChars() {
    let n = 0
    for (const c of chunks) n += c.text.length
    return n
  }

  /** 递归收集目标扩展名文件（跳过隐藏目录 / node_modules）。 */
  function collectFiles(input, out = [], depth = 0) {
    const abs = resolvePath(String(input || ''))
    let st = null
    try { st = statSync(abs) } catch {
      throw new KbError('E_KB_NOT_FOUND', `路径不存在：${abs}`)
    }
    if (st.isFile()) {
      if (KB_EXTS.includes(extname(abs).toLowerCase())) out.push(abs)
      else throw new KbError('E_KB_UNSUPPORTED', `不支持的文件类型（仅 ${KB_EXTS.join('/')}）：${basename(abs)}`)
      return out
    }
    if (depth > 8) return out
    for (const name of readdirSync(abs)) {
      if (name.startsWith('.') || name === 'node_modules') continue
      const child = join(abs, name)
      let cst = null
      try { cst = statSync(child) } catch { continue }
      if (cst.isDirectory()) collectFiles(child, out, depth + 1)
      else if (cst.isFile() && KB_EXTS.includes(extname(child).toLowerCase())) out.push(child)
    }
    return out
  }

  /** PDF 按页抽取（复用既有 unpdf 依赖）。 */
  async function extractPdfPages(abs) {
    const bytes = readFileSync(abs)
    const { getDocumentProxy, extractText } = await import('unpdf')
    const pdf = await getDocumentProxy(new Uint8Array(bytes))
    const res = await extractText(pdf, { mergePages: false })
    const pages = Array.isArray(res.text) ? res.text.map((t) => String(t || '')) : [String((res && res.text) || '')]
    return { bytes, pages }
  }

  /**
   * 登记一个文件/目录。
   * @returns {Promise<{added:object[], skipped:object[], errors:object[]}>}
   */
  async function addPath(input) {
    const files = collectFiles(input)
    const perFileCap = capOf('readMaxBytes')
    const libCap = capOf('readMaxBytes')
    const added = []
    const skipped = []
    const errors = []
    for (const abs of files) {
      const name = basename(abs)
      try {
        let bytes
        let pages
        const ext = extname(abs).toLowerCase()
        if (ext === '.pdf') {
          const r = await extractPdfPages(abs)
          bytes = r.bytes
          pages = r.pages
        } else {
          bytes = readFileSync(abs)
          pages = [bytes.toString('utf8')]
        }
        // 单文件抽取上限：超限截断并如实标注
        let truncated = false
        const cappedPages = []
        let fileChars = 0
        for (const t of pages) {
          if (fileChars >= perFileCap) { truncated = true; break }
          const room = perFileCap - fileChars
          const piece = t.length > room ? t.slice(0, room) : t
          if (piece.length < t.length) truncated = true
          fileChars += piece.length
          cappedPages.push(piece)
        }
        const hash = fileHash(bytes)
        const docId = 'kb-' + hash.slice(0, 12)
        if (docs.has(docId)) { skipped.push({ file: name, docId, reason: 'E_KB_DUPLICATE', note: '同内容文件已在库' }); continue }
        const docChars = cappedPages.reduce((n, t) => n + t.length, 0)
        if (totalChars() + docChars > libCap) {
          skipped.push({ file: name, reason: 'E_KB_CAP', note: `全库抽取文本已达本档上限（${libCap} 字符，随 mode caps 变化）` })
          continue
        }
        const startBlock = chunks.filter((c) => c.docId === docId).length
        let blockIndex = startBlock
        for (let p = 0; p < cappedPages.length; p++) {
          const text = cappedPages[p]
          if (!text || !text.trim()) continue
          for (const c of chunkPageText(text, p + 1, blockIndex)) { chunks.push({ docId, ...c }); blockIndex = c.blockIndex + 1 }
        }
        const meta = {
          docId,
          fileName: name,
          path: abs,
          kind: ext === '.pdf' ? 'pdf' : 'text',
          pages: cappedPages.length,
          blocks: chunks.filter((c) => c.docId === docId).length,
          chars: docChars,
          bytes: bytes.length,
          sha256: hash,
          truncated,
          addedAt: new Date().toISOString(),
        }
        docs.set(docId, meta)
        added.push(meta)
        audit({ ts: new Date().toISOString(), kind: 'kb-add', docId, file: name, pages: meta.pages, blocks: meta.blocks, chars: docChars, truncated })
      } catch (err) {
        errors.push({ file: name, code: (err && err.code) || 'E_KB_EXTRACT', message: String((err && err.message) || err).slice(0, 200) })
      }
    }
    if (added.length > 0) { rebuildIndex(); persist() }
    return { added, skipped, errors }
  }

  /**
   * 检索（简化 BM25，块级打分）。
   * @returns {{query:string, topN:number, totalChunks:number, hits:Array}}
   */
  function find(query, { topN = KB_DEFAULT_TOPN } = {}) {
    const qTerms = tokenize(query)
    const cap = capOf('grepMaxMatches')
    const n = Math.max(1, Math.min(Number.isFinite(topN) ? topN : KB_DEFAULT_TOPN, cap, 50))
    const N = chunkLen.size
    const avg = N > 0 ? [...chunkLen.values()].reduce((a, b) => a + b, 0) / N : 0
    const scores = new Map()
    for (const t of new Set(qTerms)) {
      const posting = terms.get(t)
      if (!posting) continue
      const df = posting.size
      const idf = Math.log(1 + (N - df + 0.5) / (df + 0.5))
      for (const [k, tf] of posting) {
        const dl = chunkLen.get(k) || 0
        const norm = tf * (BM25_K1 + 1) / (tf + BM25_K1 * (1 - BM25_B + BM25_B * (avg ? dl / avg : 0)))
        scores.set(k, (scores.get(k) || 0) + idf * norm)
      }
    }
    const hits = [...scores.entries()]
      .sort((a, b) => b[1] - a[1])
      .slice(0, n)
      .map(([k, score]) => {
        const [docId, blockStr] = k.split(':')
        const blockIndex = Number(blockStr)
        const chunk = chunks.find((c) => c.docId === docId && c.blockIndex === blockIndex)
        const doc = docs.get(docId) || {}
        return {
          docId,
          fileName: doc.fileName || '(未知)',
          page: chunk ? chunk.page : null,
          blockIndex,
          score: Number(score.toFixed(4)),
          snippet: makeSnippet(chunk ? chunk.text : '', qTerms),
        }
      })
    return { query: String(query || ''), topN: n, totalChunks: N, hits }
  }

  /** 证据引用：`kb:<docId>#page=<n>`，可 attachEvidence。 */
  function cite(docId, page = 1) {
    const doc = docs.get(docId)
    if (!doc) throw new KbError('E_KB_NO_DOC', `知识库中没有该文档：${docId}`)
    const p = Number.isFinite(page) && page >= 1 ? Math.floor(page) : 1
    const ref = `kb:${docId}#page=${p}`
    const evidenceId = `kb_${docId}_p${p}`
    audit({ ts: new Date().toISOString(), kind: 'kb-cite', docId, page: p, ref, evidenceId, fileName: doc.fileName })
    return { ref, evidenceId, docId, page: p, fileName: doc.fileName, sha256: doc.sha256, doc }
  }

  function list() {
    return [...docs.values()].map((d) => ({ ...d }))
  }

  function rm(docId) {
    if (!docs.has(docId)) throw new KbError('E_KB_NO_DOC', `知识库中没有该文档：${docId}`)
    const doc = docs.get(docId)
    docs.delete(docId)
    for (let i = chunks.length - 1; i >= 0; i--) {
      if (chunks[i].docId === docId) chunks.splice(i, 1)
    }
    rebuildIndex()
    persist()
    audit({ ts: new Date().toISOString(), kind: 'kb-rm', docId, fileName: doc.fileName })
    return { removed: docId, fileName: doc.fileName }
  }

  function stats() {
    return { dir, docs: docs.size, chunks: chunks.length, chars: totalChars(), cap: capOf('readMaxBytes') }
  }

  load()
  return { addPath, find, cite, list, rm, stats, _docs: docs, _chunks: chunks }
}

export default { createKb, tokenize, chunkPageText, makeSnippet, KbError, KB_BLOCK_CHARS, KB_OVERLAP_CHARS, KB_DEFAULT_TOPN, KB_EXTS }
