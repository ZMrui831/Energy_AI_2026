// packages/plugins/office-notes/index.mjs
//
// 通用（general）pack 的能力实现：本地笔记 + .docx 导出 + 当日小结。
//
// 设计纪律：
//   · 这是【能力实现】，由 packages\packs\general 引用；pack 只做编排。
//   · 数据落在 data\packs\general\（声明式 scopes: ["packs"]），与 research pack 的数据隔离。
//   · docx 走懒加载（activate 不 import 'docx'），与 research-literature 同一纪律。
//   · 本文件不得出现科研词（arxiv/doi/文献/论文/citation/bibtex/笔记之外的学科概念）。

import { join } from 'node:path'
import { APP_VERSION } from '../../core/src/version.mjs'

export const OFFICE_NOTES_VERSION = APP_VERSION
export const PLUGIN_ID = 'office-notes'
const PACK_ROOT = 'general' // data/packs/general/

/** 懒加载 docx 包（MIT，纯 JS OOXML；运行期零联网）。 */
async function loadDocx(loader = null) {
  if (typeof loader === 'function') return loader()
  return import('docx')
}

/** 极简 docx 大纲组装（通用，无任何学科字段）。 */
async function buildOutlineDocx(title, blocks, { loader = null } = {}) {
  const docx = await loadDocx(loader)
  const { Document, Packer, Paragraph, HeadingLevel, TextRun } = docx
  const children = [new Paragraph({ text: title, heading: HeadingLevel.TITLE })]
  for (const b of blocks) {
    if (b.h) children.push(new Paragraph({ text: b.h, heading: HeadingLevel.HEADING_1 }))
    for (const line of b.lines || []) {
      children.push(new Paragraph({ children: [new TextRun({ text: line })] }))
    }
  }
  const doc = new Document({ creator: 'research-orb', title, sections: [{ children }] })
  const buffer = await Packer.toBuffer(doc)
  return { buffer: Buffer.from(buffer) }
}

function today() {
  const d = new Date()
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`
}

function parseArgs(rest) {
  const tokens = String(rest || '').trim().split(/\s+/).filter(Boolean)
  const flags = {}
  const positional = []
  for (let i = 0; i < tokens.length; i += 1) {
    const t = tokens[i]
    if (t === '--docx') flags.docx = true
    else if (t === '--list') flags.list = true
    else if (t === '--append') { flags.append = tokens[i + 1]; i += 1 }
    else positional.push(t)
  }
  return { positional, flags }
}

export async function activate(ctx) {
  const log = ctx.log
  // data/packs/general/（声明式 scopes 已授予 packs）
  const packs = ctx.fs.scope('packs')
  const notesDir = PACK_ROOT
  const journalPath = join(notesDir, 'journal.jsonl')

  const readJournal = () => {
    if (!packs.exists(journalPath)) return []
    return packs
      .read(journalPath)
      .split('\n')
      .filter(Boolean)
      .map((l) => {
        try { return JSON.parse(l) } catch { return null }
      })
      .filter(Boolean)
  }

  const notesToday = () => readJournal().filter((e) => String(e.at || '').slice(0, 10) === today())

  log.info(`office-notes 已激活（v${OFFICE_NOTES_VERSION}），数据根 data/packs/${PACK_ROOT}/`)

  ctx.ui.registerCard({
    id: 'office.notes',
    title: '通用笔记',
    body: `今日 ${notesToday().length} 条｜数据目录 data/packs/${PACK_ROOT}/`,
    actions: ['note', 'today'],
  })

  // /note [文本] [--list] [--docx] [--append <文件>]
  ctx.ui.registerCommand({
    name: 'note',
    title: '通用笔记',
    description: '写入/列出本地笔记并导出 .docx。用法：/note <文本>｜/note --list｜/note export --docx',
    run: async (rest = '') => {
      const { positional, flags } = parseArgs(rest)
      const sub = positional[0]

      if (flags.list || sub === 'list') {
        const rows = readJournal().slice(-50).reverse()
        if (rows.length === 0) return { ok: true, text: `暂无笔记（写入：/note <文本>；数据目录 data/packs/${PACK_ROOT}/）` }
        return {
          ok: true,
          text: `最近 ${rows.length} 条：\n` + rows.map((e) => `· [${String(e.at).slice(5, 16)}] ${e.text}`).join('\n'),
        }
      }

      if (sub === 'export') {
        const rows = readJournal()
        const blocks = [{ h: `本地笔记导出（共 ${rows.length} 条）`, lines: rows.map((e) => `[${e.at}] ${e.text}`) }]
        const { buffer } = await buildOutlineDocx('通用笔记导出', blocks)
        const file = `notes-${today()}.docx`
        const exports = ctx.fs.scope('exports')
        exports.write(file, buffer)
        log.info(`已导出 data/exports/${file}（${buffer.length} 字节）`)
        return { ok: true, text: `已导出：data/exports/${file}（${rows.length} 条，${buffer.length} 字节）`, path: `data/exports/${file}` }
      }

      const text = positional.join(' ').trim()
      if (!text) {
        return {
          ok: true,
          text: [
            '通用笔记用法：',
            '  /note <文本>        追加一条本地笔记（落 data/packs/general/journal.jsonl）',
            '  /note --list        列出最近 50 条',
            '  /note export --docx 导出为 data/exports/notes-<日期>.docx',
          ].join('\n'),
        }
      }
      packs.append(journalPath, `${JSON.stringify({ at: new Date().toISOString(), text })}\n`)
      const n = notesToday().length
      return { ok: true, text: `已记录（今日第 ${n} 条）：${text}` }
    },
  })

  // /today —— 当日小结（纯本地统计，无 LLM 依赖也可用）
  ctx.ui.registerCommand({
    name: 'today',
    title: '当日小结',
    description: '按 pack 数据目录生成本日小结（条目数 + 清单）。',
    run: async () => {
      const rows = notesToday()
      const all = readJournal()
      const lines = [
        `# 当日小结（${today()}）`,
        '',
        `- 今日新增：${rows.length} 条`,
        `- 累计总数：${all.length} 条`,
        `- 数据目录：data/packs/${PACK_ROOT}/`,
        '',
        '## 今日清单',
        ...(rows.length ? rows.map((e) => `- [${String(e.at).slice(11, 16)}] ${e.text}`) : ['- （暂无）']),
        '',
      ]
      return { ok: true, text: lines.join('\n'), ui: { kind: 'report', title: `当日小结 ${today()}`, markdown: lines.join('\n') } }
    },
  })

  return {
    deactivate() { log.info('office-notes 已停用') },
  }
}

export default { activate }
