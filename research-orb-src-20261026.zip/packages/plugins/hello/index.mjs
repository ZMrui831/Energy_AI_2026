// packages/plugins/hello/index.mjs
//
// 最小可验证插件：证明「宿主 → 插件 → 受限 ctx」这条链路真的通了。
//
// 覆盖的契约点：
//   · activate(ctx) 被调用，且返回 { deactivate } 能被宿主收回；
//   · ctx.log 写进 data/logs/plugins.jsonl；
//   · ctx.fs 只能落在 data/notes/hello/ 之内（越界会抛，可现场自证）；
//   · ctx.ui 注册的卡片与命令能被宿主 list/commands 读到；
//   · ctx.state 重启后仍在。
//
// 刻意【不】在 activate 里发任何网络请求 —— 启用插件必须是零副作用的。

import { APP_VERSION } from '../../core/src/version.mjs'

export const HELLO_VERSION = APP_VERSION

const NOTE_FILE = 'hello.md'

export async function activate(ctx) {
  const log = ctx.log
  const visits = Number(ctx.state.get('activations', 0)) + 1
  ctx.state.set('activations', visits)

  log.info(`hello 插件已激活（第 ${visits} 次），capabilities=${ctx.capabilities.join(',')}`)

  // 1) 私有笔记：写进 data/notes/hello/hello.md
  const stamp = new Date().toISOString()
  ctx.fs.write(
    NOTE_FILE,
    [
      '---',
      'plugin: hello',
      `version: ${HELLO_VERSION}`,
      `updated: ${stamp}`,
      '---',
      '',
      '# Hello 插件笔记',
      '',
      `这是由 hello 插件通过受限 ctx.fs 写入的笔记，落在 \`data/notes/hello/\` 之内。`,
      `激活次数：${visits}`,
      '',
    ].join('\n'),
  )
  log.info(`已写入私有笔记 ${NOTE_FILE}（root=${ctx.fs.root}）`)

  // 2) 面板卡片
  ctx.ui.registerCard({
    id: 'hello.status',
    title: 'Hello 插件',
    body: `版本 ${HELLO_VERSION}｜激活 ${visits} 次｜笔记：data/notes/hello/${NOTE_FILE}`,
    actions: ['hello.greet', 'hello.selfcheck'],
  })

  // 3) 命令：/hello [名字]
  ctx.ui.registerCommand({
    name: 'hello',
    title: 'Hello',
    description: '打招呼并返回插件自检信息。用法：/hello [名字]',
    run: async (rest = '') => {
      const who = String(rest || '').trim() || 'research-orb'
      const note = ctx.fs.exists(NOTE_FILE) ? ctx.fs.read(NOTE_FILE) : ''
      return {
        text: `Hello, ${who}!（hello 插件 v${HELLO_VERSION}，激活 ${visits} 次，笔记 ${note.length} 字节）`,
        activations: visits,
        noteBytes: note.length,
      }
    },
  })

  // 4) 第二条命令：现场自证沙箱是真的
  ctx.ui.registerCommand({
    name: 'hello.selfcheck',
    title: 'Hello 自检',
    description: '检查 priv 私有目录与网络白名单可用性（不发请求）。',
    run: async () => {
      let sandboxOk = false
      let sandboxError = null
      try {
        ctx.fs.write('../../../escape.md', 'should never happen')
      } catch (err) {
        sandboxOk = true
        sandboxError = err.code || String(err.name)
      }
      return {
        text: `沙箱拦截越界写入：${sandboxOk ? 'OK (' + sandboxError + ')' : '失败！'}`,
        pluginId: ctx.id,
        notesRoot: ctx.fs.root,
        netAvailable: !!ctx.net.available,
        allowedDomains: (ctx.net.ALLOWED_DOMAINS || []).length,
      }
    },
  })

  log.info('hello 插件注册完成：1 张卡片 + 2 条命令')

  return {
    deactivate() {
      log.info('hello 插件已停用')
    },
  }
}

export default { activate }
