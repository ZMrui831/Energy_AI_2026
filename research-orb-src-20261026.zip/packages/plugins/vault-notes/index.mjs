// packages/plugins/vault-notes/index.mjs
//
// 任务 1：笔记软件集成（Obsidian 优先）。vault 本质是本地 markdown 目录，接入不需要客户端。
// 纪律：
//   · 只写【已发布】结论；草稿/无证据一律拒绝（与证据链纪律一致，绝不把 draft 当结论外发）。
//   · 零网络、零新依赖；写入本仓库外路径需显式配置 vaultRoot，默认落在 data\vault-demo（受审计）。
//   · 不改证据链主流程：只读 claim/claim_evidence，不写 claim 状态。
import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join, dirname, resolve } from 'node:path'
import { PROJECT_ROOT, appendJsonl, logPath } from '../../core/src/safefs.mjs'

export const PLUGIN_ID = 'vault-notes'
export const DEFAULT_VAULT = 'data/vault-demo'

export class VaultError extends Error {
  constructor(code, message) { super(message); this.name = 'VaultError'; this.code = code }
}

/** 解析 vault 根目录：config > 默认（均相对项目根）。 */
export function resolveVaultRoot(opts = {}) {
  const raw = opts.vaultRoot || DEFAULT_VAULT
  const abs = resolve(PROJECT_ROOT, raw)
  return abs
}

function readStoreClaim(store, claimId) {
  if (!store) throw new VaultError('E_NO_STORE', '没有可用 store（宿主未接入）')
  const row = store._db
    ? store._db.prepare('SELECT id, kind, text, evidence_mode, status, created_at, published_at FROM claim WHERE id = ?').get(claimId)
    : null
  if (!row) throw new VaultError('E_NOT_FOUND', '结论不存在：' + claimId)
  return row
}

function readEvidenceIds(store, claimId) {
  if (!store || !store._db) return []
  try {
    return store._db.prepare('SELECT evidence_id, relation FROM claim_evidence WHERE claim_id = ?').all(claimId).map((r) => r.evidence_id)
  } catch { return [] }
}

/** 把一个已发布结论写成 markdown（含 front-matter）。返回 {path, evidenceIds, bytes}。 */
export function writeClaimToVault({ store, claimId, vaultRoot = null, subdir = '研究结论' }) {
  const root = resolveVaultRoot({ vaultRoot })
  const claim = readStoreClaim(store, claimId)
  if (String(claim.status) !== 'published') {
    throw new VaultError('E_NOT_PUBLISHED', '只允许把已发布结论写入笔记库（当前 status=' + claim.status + '）')
  }
  const evIds = readEvidenceIds(store, claimId)
  if (!evIds.length) throw new VaultError('E_NO_EVIDENCE', '已发布结论居然没有证据行，拒绝外发')
  const fm = [
    '---',
    'claim_id: ' + claim.id,
    'status: ' + claim.status,
    'evidence_mode: ' + (claim.evidence_mode || 'direct'),
    'evidence_ids: [' + evIds.join(', ') + ']',
    'published_at: ' + (claim.published_at || claim.created_at || ''),
    'source: research-orb',
    '---',
    '',
  ].join('\n')
  const body = [
    '# 结论 · ' + claim.id,
    '',
    claim.text || '(空)',
    '',
    '## 证据',
    ...evIds.map((id) => '- `' + id + '`'),
    '',
  ].join('\n')
  const outDir = join(root, subdir)
  mkdirSync(outDir, { recursive: true })
  const path = join(outDir, claim.id + '.md')
  writeFileSync(path, fm + body, 'utf8')
  try { appendJsonl(logPath('vault.jsonl'), { kind: 'note-written', claimId: claim.id, path, evidenceIds: evIds }) } catch { /* 审计尽力 */ }
  return { path, evidenceIds: evIds, bytes: Buffer.byteLength(fm + body, 'utf8') }
}

/** 读回一条笔记（供问答引用）：返回 {path, frontMatter, text}。 */
export function readVaultNote({ claimId = null, path = null, vaultRoot = null }) {
  const root = resolveVaultRoot({ vaultRoot })
  let p = path
  if (!p && claimId) p = join(root, '研究结论', String(claimId) + '.md')
  if (!p || !existsSync(p)) throw new VaultError('E_NOT_FOUND', '笔记不存在：' + (p || '(未给路径)'))
  const raw = readFileSync(p, 'utf8')
  const m = raw.match(/^---\r?\n([\s\S]*?)\r?\n---\r?\n?([\s\S]*)$/)
  const fmText = m ? m[1] : ''
  const body = m ? m[2] : raw
  const frontMatter = {}
  for (const line of fmText.split(/\r?\n/)) {
    const i = line.indexOf(':')
    if (i > 0) frontMatter[line.slice(0, i).trim()] = line.slice(i + 1).trim()
  }
  return { path: p, frontMatter, text: body.trim() }
}

export function listVaultNotes({ vaultRoot = null, subdir = '研究结论' } = {}) {
  const root = resolveVaultRoot({ vaultRoot })
  const d = join(root, subdir)
  if (!existsSync(d)) return []
  return readdirSync(d).filter((n) => n.endsWith('.md')).map((n) => ({ name: n, path: join(d, n) }))
}

/** 取 store：ctx.core.lifecycle 优先；应用内走 globalThis 桥的 .store。
 *  必须**调用时**取——宿主在异步 bootstrap 里才建单例，activate 时桥上还是空的（曾因此报 E_NO_STORE）。 */
function resolveStore(ctx) {
  const direct = (ctx && ctx.core && ctx.core.lifecycle) || null
  if (direct) return direct
  const bridge = globalThis.researchOrbLifecycle
  return bridge && bridge.store ? bridge.store : null
}

const USAGE = '用法：/vault init｜/vault write <claimId>｜/vault read <claimId>｜/vault list'

export async function activate(ctx) {
  const log = (ctx && ctx.log) || console
  if (ctx && ctx.ui && typeof ctx.ui.registerCard === 'function') {
    ctx.ui.registerCard({ id: 'vault.status', title: '笔记库', body: '把已发布结论写成 Markdown 笔记（带 evidence_id），可读回引用；只写已发布，草稿一律拒绝。' })
  }
  if (!(ctx && ctx.ui && typeof ctx.ui.registerCommand === 'function')) { log.warn('vault-notes: 宿主未提供 ui.registerCommand'); return { ok: false } }
  ctx.ui.registerCommand({
    name: 'vault',
    title: '写入/读取笔记库',
    description: USAGE,
    run: async (rest = '') => {
      const parts = String(rest || '').trim().split(/\s+/).filter(Boolean)
      const sub = (parts[0] || '').toLowerCase()
      const arg = parts[1] || ''
      try {
        if (sub === 'init') {
          const root = resolveVaultRoot({})
          mkdirSync(join(root, '研究结论'), { recursive: true })
          mkdirSync(join(root, '.obsidian'), { recursive: true })
          return { ok: true, text: '笔记库已就绪：' + root }
        }
        if (sub === 'write') {
          if (!arg) return { ok: false, text: USAGE, code: 'E_USAGE' }
          const r = writeClaimToVault({ store: resolveStore(ctx), claimId: arg })
          return { ok: true, text: '已写入笔记：' + r.path + '（证据 ' + r.evidenceIds.length + ' 条）', ui: { kind: 'vault', path: r.path } }
        }
        if (sub === 'read') {
          if (!arg) return { ok: false, text: USAGE, code: 'E_USAGE' }
          const n = readVaultNote({ claimId: arg })
          return { ok: true, text: n.text.slice(0, 600), ui: { kind: 'vault', frontMatter: n.frontMatter } }
        }
        if (sub === 'ask') {
          const cid = arg
          if (!cid) return { ok: false, text: USAGE, code: 'E_USAGE' }
          const n = readVaultNote({ claimId: cid })
          const fm = n.frontMatter || {}
          const evIds = String(fm.evidence_ids || '').replace(/[[\]]/g, '').split(',').map((x) => x.trim()).filter(Boolean)
          const answer =
            '依据笔记 ' + cid + '（证据 ' + evIds.join('、') + '）：' + String(n.text).split('\n').filter((l) => l.trim() && !l.startsWith('#')).join(' ').slice(0, 300)
          return {
            ok: true,
            text: answer,
            ui: { kind: 'vault-answer', claimId: cid, evidenceIds: evIds, answerMode: 'extractive', notePath: n.path },
          }
        }
        if (sub === 'list') {
          const list = listVaultNotes({})
          return { ok: true, text: list.length ? list.map((x) => x.name).join('\n') : '（空）' }
        }
        return { ok: false, text: USAGE, code: 'E_USAGE' }
      } catch (e) {
        return { ok: false, text: String(e.message || e), code: e.code || 'E_VAULT', error: String(e.message || e) }
      }
    },
  })
  return { ok: true, commands: ['vault'] }
}

export default { activate, PLUGIN_ID, DEFAULT_VAULT }