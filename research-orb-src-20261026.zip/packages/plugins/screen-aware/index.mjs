// packages/plugins/screen-aware/index.mjs
//
// P-R6.2 任务三：屏幕感知命令层。
//
// 纪律：
//   · 像素捕获/覆盖层都在主进程（desktopCapturer / BrowserWindow 是 electron 能力），
//     本插件经 ctx.core.screen 调用（main.mjs 注入的能力桥）。
//   · **隐私铁律**：截图只落 data\shots\（本地），本插件没有任何把像素发给模型的代码 ——
//     当前 provider（deepseek/school-gateway）都不支持图像输入，诚实降级而不是假装能看。
//   · 回答"屏幕上有什么"：能给的 = 可见窗口标题清单（PowerShell 枚举，只取标题不读内容）
//     + 最近一帧的尺寸/哈希/路径；给不出像素描述时**明确说明降级原因**。

export const SCREEN_AWARE_VERSION = '0.6.0'

function parse(rest) {
  const tokens = String(rest || '').trim().split(/\s+/).filter(Boolean)
  return { sub: tokens[0] || '', rest: tokens.slice(1).join(' ') }
}

function fmtBytes(n) {
  if (!Number.isFinite(n)) return '—'
  if (n >= 1024 * 1024) return (n / 1024 / 1024).toFixed(2) + ' MB'
  if (n >= 1024) return (n / 1024).toFixed(1) + ' KB'
  return n + ' B'
}

export async function activate(ctx) {
  const log = ctx.log
  const screen = ctx.core && ctx.core.screen
  if (!screen) {
    log.warn('screen-aware：宿主未注入 ctx.core.screen（旧宿主？），命令将报降级')
  }

  log.info(`screen-aware 已激活（v${SCREEN_AWARE_VERSION}），multimodalModel=${screen ? screen.capabilities().multimodalModel : 'unknown'}`)

  ctx.ui.registerCard({
    id: 'screen.aware',
    title: '屏幕感知',
    body: '抓屏自证 / 彩色边框 / 屏幕内容问答（诚实降级）。截图只落本地 data/shots/，不外发。',
    actions: ['screen'],
  })

  ctx.ui.registerCommand({
    name: 'screen',
    title: '屏幕感知',
    description: '用法：/screen self-test｜/screen what｜/screen state｜/screen hide',
    run: async (rest = '') => {
      const { sub } = parse(rest)

      if (!screen) {
        return { ok: false, code: 'E_NO_SCREEN_BRIDGE', text: '宿主未注入屏幕能力（ctx.core.screen 缺失）。这不是"我看不到"，是能力桥缺失——请检查 main.mjs 的 createScreenBridge 注入。' }
      }

      // ---- /screen self-test：先证明"能看到屏幕" ----
      if (sub === 'self-test' || sub === '') {
        await screen.showOverlay('idle', { displayLabel: '显示器1', sizeLabel: '', timeoutMs: 1200 })
        await new Promise((r) => setTimeout(r, 500))
        await screen.showOverlay('observing', { displayLabel: '显示器1', timeoutMs: 2500 })
        const cap = await screen.captureScreen()
        if (!cap.ok) {
          await screen.showOverlay('error', { timeoutMs: 1600 })
          const hide = () => screen.hideOverlay('self-test-error')
          setTimeout(hide, 1600)
          return { ok: false, code: cap.code, text: `屏幕自证失败：${cap.reason}\n（这是能力/授权问题，不是"我不愿意看"）`, ui: { kind: 'screen-error', reason: cap.reason } }
        }
        setTimeout(() => screen.hideOverlay('self-test-done'), 900)
        const lines = [
          '屏幕自证通过（我能看到屏幕）：',
          `· 分辨率：${cap.width} × ${cap.height}`,
          `· 文件：${cap.pngPath.replace(/\\/g, '/')}`,
          `· 大小：${fmtBytes(cap.bytes)}`,
          `· SHA-256：${cap.hash.slice(0, 32)}…`,
          `· 显示器：id=${cap.display.id} 缩放=${cap.display.scaleFactor}`,
          `· 时间戳：${cap.ts}`,
          '',
          '注：截图只落本地 data/shots/，未发送给任何模型（当前模型不支持图像输入，像素不出本机）。',
        ]
        return {
          ok: true,
          text: lines.join('\n'),
          ui: { kind: 'screen-shot', path: cap.pngPath.replace(/\\/g, '/'), width: cap.width, height: cap.height, hash: cap.hash },
        }
      }

      // ---- /screen what：屏幕上有什么（诚实降级路径）----
      if (sub === 'what') {
        const cap = await screen.captureScreen()
        if (!cap.ok) {
          await screen.showOverlay('error', { timeoutMs: 1600 })
          return { ok: false, code: cap.code, text: `无法取屏：${cap.reason}` }
        }
        const titles = await screen.enumerateWindowTitles()
        const caps = screen.capabilities()
        const lines = [
          `我取到了屏幕（${cap.width} × ${cap.height}，SHA-256 ${cap.hash.slice(0, 12)}…，已落 ${cap.pngPath.replace(/\\/g, '/')}）。`,
          '',
          '但要说实话：当前模型（deepseek-chat / school-gateway）**不支持图像输入**，所以我看不了像素内容 ——',
          '这不是"我看不到屏幕"，是"看懂像素"这一步还没有多模态模型。降级路径给出我能确定的部分：',
          '',
        ]
        if (titles.ok && titles.titles.length) {
          lines.push('可见窗口标题（最多 12 个）：')
          for (const t of titles.titles) lines.push(`· ${t}`)
        } else {
          lines.push(`可见窗口标题枚举失败：${titles.ok ? '无可见窗口' : titles.reason}`)
        }
        lines.push('')
        lines.push('想让我针对某块内容回答，可以把文字直接贴给我，或选中后走底座的选中询问路径。')
        return { ok: true, text: lines.join('\n'), ui: { kind: 'screen-degraded', width: cap.width, height: cap.height, titles: titles.titles || [] } }
      }

      // ---- /screen state：三态演示（待机/观察中/出错 各 1.2s）----
      if (sub === 'state') {
        const seq = ['idle', 'observing', 'error']
        const shown = []
        for (const st of seq) {
          const okShow = await screen.showOverlay(st, { displayLabel: '显示器1', sizeLabel: st === 'error' ? '演示' : '', timeoutMs: 1200 })
          shown.push({ state: st, okShow })
          await new Promise((r) => setTimeout(r, 1250))
        }
        screen.hideOverlay('state-demo-done')
        return { ok: true, text: `覆盖层三态演示完成：${shown.map((s) => `${s.state}=${s.okShow ? 'shown' : 'failed'}`).join('、')}；已隐藏。`, ui: { kind: 'screen-states', shown } }
      }

      if (sub === 'hide') {
        screen.hideOverlay('manual')
        return { ok: true, text: '覆盖层已隐藏。' }
      }

      return { ok: true, text: '屏幕感知用法：\n  /screen self-test   抓一帧自证（尺寸/哈希/路径）\n  /screen what        屏幕上有什么（诚实降级：窗口标题路径）\n  /screen state       彩色边框三态演示（蓝/绿/红）\n  /screen hide        隐藏覆盖层' }
    },
  })

  return { deactivate() { log.info('screen-aware 已停用') } }
}

export default { activate }
