// packages/plugins/skill-installer/index.mjs
//
// skill 适配性安装器（P-R4 块 4）的对外命令层。
// 真正的校验/复制/审计在宿主 registry（packages/plugins/registry.mjs）与
// packages/core/src/skill-installer.mjs；本文件只是面板入口——
// 宿主只把 skillAdmin 授给声明了 `skill.admin` 能力的插件（目前仅本内置插件）。
//
// 两段式确认是硬要求：`/skill install <目录>` 只做校验与权限清单（零写入），
// 用户必须在面板上 `/skill confirm <token>` 才真正安装；`/skill cancel` 或
// 10 分钟超时即中止。绝不提供"一步安装"的快路。

const USAGE =
  '用法：/skill install <本地skill目录>（校验 + 列权限，不装）→ /skill confirm <token>（确认安装）｜/skill cancel <token>；/skill list（已装清单）；/skill retire <id>（只移不删）'

export async function activate(ctx) {
  const admin = ctx.skillAdmin || null
  const log = ctx.log
  if (!admin) {
    log.warn('宿主未授予 skillAdmin（缺 skill.admin 能力或旧宿主）——/skill 命令将只给提示')
  }

  async function skill(rest) {
    const parts = String(rest || '').split(/\s+/).filter(Boolean)
    const sub = (parts[0] || '').toLowerCase()
    const arg = parts.slice(1).join(' ').trim()
    if (!admin) {
      return { ok: false, code: 'E_NO_ADMIN', text: '宿主未授予 skill 管理能力（需要 skill.admin 能力与新版宿主）' }
    }
    if (sub === 'install') {
      if (!arg) return { ok: false, code: 'E_BAD_ARGS', text: USAGE }
      const r = await admin.prepare(arg)
      if (!r.ok) {
        const lines = [`拒绝：${r.error}`]
        if (Array.isArray(r.details) && r.details.length > 0) {
          lines.push('校验明细：', ...r.details.map((d) => `  · ${d}`))
          lines.push('（被篡改或未声明的 skill 必须拒绝安装——本次安装已中止，且已写审计日志）')
        }
        return { ok: false, code: r.code, text: lines.join('\n') }
      }
      return {
        ok: true,
        text: [
          `候选 skill：${r.name}（${r.id}）v${r.version}`,
          `来源：${arg}｜待装文件：${r.files} 个（sha256 白名单逐文件校验通过）`,
          '',
          '声明的权限：',
          ...r.permissions.lines.map((l) => `  ${l}`),
          '',
          r.note,
        ].join('\n'),
        ui: { kind: 'skill', sub: 'prepare', token: r.token, id: r.id, permissions: r.permissions },
      }
    }
    if (sub === 'confirm') {
      if (!arg) return { ok: false, code: 'E_BAD_ARGS', text: '用法：/skill confirm <token>（token 来自 /skill install 的输出）' }
      const r = await admin.commit(arg)
      if (!r.ok) return { ok: false, code: r.code, text: `安装失败：${r.error}${Array.isArray(r.details) ? '\n  ' + r.details.join('\n  ') : ''}` }
      log.info(`/skill confirm：${r.id} 安装完成（${r.files} 文件）`)
      return { ok: true, text: `安装完成：${r.id}（${r.files} 个文件，含 plugin.json 与 hash 白名单）\n${r.note}`, ui: { kind: 'skill', sub: 'commit', id: r.id } }
    }
    if (sub === 'cancel') {
      const r = await admin.cancel(arg)
      return r.ok ? { ok: true, text: r.note, ui: { kind: 'skill', sub: 'cancel' } } : { ok: false, code: r.code, text: r.error }
    }
    if (sub === 'list') {
      const rows = await admin.list()
      const lines = [`已装插件 ${rows.length} 个：`]
      for (const p of rows) {
        lines.push(
          `  ${p.enabled ? '●' : '○'} ${p.id} v${p.version}${p.source ? `｜来源: ${p.source}` : '｜来源: 未记录（内置或旧装）'}${p.hashFiles ? `｜hash 白名单: ${p.hashFiles} 文件` : ''}${p.error ? `｜异常: ${p.error}` : ''}`,
        )
      }
      lines.push(`待确认安装：${admin.pendingCount()} 个`)
      return { ok: true, text: lines.join('\n'), ui: { kind: 'skill', sub: 'list', rows } }
    }
    if (sub === 'retire') {
      if (!arg) return { ok: false, code: 'E_BAD_ARGS', text: '用法：/skill retire <id>（卸载 = 移入 .retired 退休目录，只移不删）' }
      const r = await admin.retire(arg)
      if (!r.ok) return { ok: false, code: r.code, text: `退休失败：${r.error}` }
      log.info(`/skill retire：${r.id} → ${r.retiredTo}`)
      return { ok: true, text: `已退休：${r.id}\n${r.note}`, ui: { kind: 'skill', sub: 'retire', id: r.id, to: r.retiredTo } }
    }
    return { ok: false, code: 'E_BAD_ARGS', text: USAGE }
  }

  function cardBody() {
    return [
      '## skill 安装器（块 4）',
      '',
      '本地 skill 目录 → 权限确认 → sha256 白名单逐文件校验 → 安装（全程审计）。',
      '',
      '- 安装两段式：`/skill install <目录>` 只校验不落盘，面板确认 `/skill confirm <token>` 才装',
      '- 卸载只移不删：`/skill retire <id>` → `packages/plugins/.retired/<id>-<时间戳>/`',
      '- 红线：禁自动更新、禁远程下载执行；哈希不符/白名单外文件一律拒绝',
    ].join('\n')
  }

  ctx.ui.registerCard({
    id: 'skill.installer',
    title: 'Skill',
    body: cardBody(),
    actions: ['skill'],
  })

  ctx.ui.registerCommand({
    name: 'skill',
    title: 'Skill 安装器',
    description:
      'skill 适配性安装（块 4）：install（校验+列权限，两段式确认）/ confirm / cancel / list / retire（只移不删）。禁止自动更新与远程下载执行。',
    run: async (rest = '') => {
      const r = await skill(rest)
      return { text: r.text, ui: r.ui, ok: r.ok, code: r.code || null }
    },
  })

  return {
    cardBody,
    skill,
    statusPayload: () => ({ granted: !!admin }),
    deactivate() {
      log.info('skill-installer 已停用（已安装的插件不受影响，registry 的记录独立存在）')
    },
  }
}

export default { activate }
