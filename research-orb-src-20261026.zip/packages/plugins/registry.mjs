// packages/plugins/registry.mjs
//
// 插件宿主（PluginRegistry）：扫描 / 加载 / 启用 / 禁用 / 列出。
//
// 契约（见 docs/ARCH.md）：
//   <插件目录>/plugin.json  ->  { id, name, version, capabilities[], permissions[], entry }
//   <插件目录>/index.mjs    ->  export async function activate(ctx) { ... }
//
// ctx 只给【受控】能力，插件拿不到裸 node:fs / fetch / electron：
//   log   —— 写 data/logs/plugins.jsonl（自动带 pluginId）
//   fs    —— 被夹在 data/notes/<pluginId>/ 之内，越界即抛（复用 safefs 的根断言 + 二次前缀断言）
//   net   —— 复用 core 的 net 实例（白名单/令牌桶/429 退避/net.jsonl 一律生效，插件绕不开）
//   llm   —— 复用 core 的 provider 与 agent（同样受限速与降级控制）
//   ui    —— 注册面板卡片与命令（宿主收集，面板渲染）
//   state —— 插件自己的小 KV（落在 data/notes/<pluginId>/state.json）
//   timer / progress —— 阶段 3：宿主装配的计时与进度引擎（core-host.mjs 注入）。
//     插件不 import node:fs 也能落账：所有持久化由引擎经 safefs 完成。
//     引擎在 core 而不在插件里，因此插件禁用不影响已开始的计时收尾。
//
// 权限字段（permissions）按命题要求【只是元数据】：不在运行时做开关，
// 真正的边界由宿主白名单强制执行（路径夹逼 + 网络白名单 + provider 限速）。
// 面板会把 permissions 原样展示，让用户知道这个插件"声称"要什么。
//
// 【阶段 2 追加】声明式数据作用域（scopes）：
//   上面那条 fs 夹逼只给插件一个私有抽屉（data/notes/<pluginId>/）。但科研插件按
//   DOMAIN-smart-energy.md 的数据布局必须写到 data/pdf / data/notes/<topic> / data/index
//   / data/exports —— 都在私有抽屉之外。与其让插件自己 import safefs 绕开宿主（那就等于
//   没有边界），不如把口子做成**声明的、可审计的**：
//     · plugin.json 里写 "scopes": ["pdf", "index", "exports", "notes"]；
//     · 宿主只放行声明过的名字（未声明调用 ctx.fs.scope('pdf') 直接抛 E_SCOPE_NOT_GRANTED）；
//     · 每个作用域仍然 assertInsideRoot + 二次前缀断言，写操作仍然走 safeWrite → writes.jsonl；
//     · notes 作用域额外禁止写进别的插件的私有目录（防止 topic 恰好叫 hello 就把人家的抽屉占了）。
//   于是"插件能写到哪儿"这件事，从源码里看不见的 import 变成了 manifest 里可审的一行。

import { existsSync, mkdirSync, readFileSync, readdirSync, renameSync, statSync } from 'node:fs'
import { isAbsolute, join, relative, resolve, sep } from 'node:path'

import { PROJECT_ROOT, DATA_DIR, appendJsonl, assertInsideRoot, safeWrite, logPath, dataPath } from '../core/src/safefs.mjs'
import { shortMessage, stripSecrets } from '../core/src/providers/provider.mjs'
import { RETIRED_DIR, readSkillManifest, sha256, summarizePermissions, verifySource } from '../core/src/skill-installer.mjs'

/** 插件根目录：packages\plugins（每个子目录一个插件）。 */
export const PLUGINS_DIR = join(PROJECT_ROOT, 'packages', 'plugins')
/** 插件私有数据根：data\notes（ARCH.md 规定的数据布局）。 */
export const NOTES_DIR = dataPath('notes')
export const PLUGIN_LOG = logPath('plugins.jsonl')

const PLUGIN_ID_RE = /^[a-z0-9][a-z0-9._-]{1,63}$/i
const DEFAULT_ENTRY = 'index.mjs'

/**
 * 允许插件按声明访问的项目数据目录（相对 PROJECT_ROOT）。
 * 加新作用域必须改这里 —— 也就是说"插件能碰哪些目录"是宿主的一个常量，
 * 不是插件能自己发明的东西。
 */
export const DATA_SCOPES = Object.freeze({
  notes: 'notes',
  pdf: 'pdf',
  index: 'index',
  exports: 'exports',
  fixtures: 'fixtures',
  // P-R6：pack 数据隔离根。插件写 data/packs/<dataRoot>/... 需在 manifest 声明 "packs"。
  packs: 'packs',
})

/** 合法作用域名（manifest 里写错的会被静默丢掉，而不是偷偷生效）。 */
export const DATA_SCOPE_NAMES = Object.freeze(Object.keys(DATA_SCOPES))

export class PluginError extends Error {
  constructor(code, message, details = {}) {
    super(message)
    this.name = 'PluginError'
    this.code = code
    Object.assign(this, details)
  }
}

export function assertPluginId(id) {
  if (typeof id !== 'string' || !PLUGIN_ID_RE.test(id)) {
    throw new PluginError('E_BAD_PLUGIN_ID', `plugins: 非法插件 id -> ${String(id)}`)
  }
  return id
}

/** 校验并归一 plugin.json（缺字段给默认值，id 非法直接拒）。 */
export function normalizeManifest(raw, { dirName = null } = {}) {
  if (!raw || typeof raw !== 'object') {
    throw new PluginError('E_BAD_MANIFEST', 'plugin.json 必须是 JSON 对象')
  }
  const id = assertPluginId(String(raw.id || dirName || ''))
  const entry = typeof raw.entry === 'string' && raw.entry ? raw.entry : DEFAULT_ENTRY
  if (entry.includes('..') || isAbsolute(entry)) {
    throw new PluginError('E_BAD_ENTRY', `plugins: entry 必须是插件目录内的相对路径 -> ${entry}`, { id })
  }
  return {
    id,
    name: typeof raw.name === 'string' && raw.name ? raw.name : id,
    version: typeof raw.version === 'string' && raw.version ? raw.version : '0.0.0',
    description: typeof raw.description === 'string' ? raw.description : '',
    capabilities: Array.isArray(raw.capabilities) ? raw.capabilities.map(String) : [],
    permissions: Array.isArray(raw.permissions) ? raw.permissions.map(String) : [],
    // 只保留宿主认识的作用域名（写错的静默丢弃 + 由 list() 暴露出来供审查）
    scopes: Array.isArray(raw.scopes) ? [...new Set(raw.scopes.map(String).filter((s) => s in DATA_SCOPES))].sort() : [],
    entry,
    // 块 4：skill 安装器契约扩展。source = 安装来源（本地目录或 builtin）；hash = skill 作者
    // 声明的 sha256 白名单（{ 相对路径: sha256 }，plugin.json 自身除外）。这里只存不校验——
    // 校验发生在安装时（skill-installer.verifySource），两个字段随 manifest 持久化供复核。
    source: typeof raw.source === 'string' && raw.source ? raw.source : null,
    hash: raw.hash && typeof raw.hash === 'object' && !Array.isArray(raw.hash) ? raw.hash : null,
  }
}

/** 插件目录必须在 packages\plugins 之下。 */
function assertPluginDir(dir) {
  const abs = assertInsideRoot(dir)
  const rel = relative(PLUGINS_DIR, abs)
  if (rel === '' || rel.startsWith('..' + sep) || rel === '..' || isAbsolute(rel)) {
    throw new PluginError('E_OUTSIDE_PLUGINS', `plugins: 插件目录必须在 ${PLUGINS_DIR} 之下 -> ${abs}`)
  }
  return abs
}

/** 把插件私有数据路径夹到 data\notes\<pluginId>\ 之内。 */
export function pluginDataPath(id, rel = '') {
  assertPluginId(id)
  const root = assertInsideRoot(join(NOTES_DIR, id))
  const target = resolve(root, String(rel || ''))
  const relCheck = relative(root, target)
  if (relCheck.startsWith('..' + sep) || relCheck === '..' || isAbsolute(relCheck)) {
    // 两道门：既出私有目录、又出数据/日志根 → 宿主门先拦；仅跨目录但仍在数据树内 → 插件门。
    let hostErr = null
    try { assertInsideRoot(target) } catch (e) { hostErr = e }
    if (hostErr) throw hostErr
    throw new PluginError('E_PLUGIN_FS_OUTSIDE', `plugins(${id}): 拒绝写到私有目录之外 -> ${target}`, { id })
  }
  return target
}

/** 某个数据作用域的根目录（绝对路径）；未知作用域名直接抛。 */
export function scopeRoot(scope) {
  const key = String(scope || '')
  if (!Object.prototype.hasOwnProperty.call(DATA_SCOPES, key)) {
    throw new PluginError('E_SCOPE_UNKNOWN', `plugins: 未知数据作用域 -> ${key}`, {
      scope: key,
      allowed: [...DATA_SCOPE_NAMES],
    })
  }
  return assertInsideRoot(join(DATA_DIR, DATA_SCOPES[key]))
}

/**
 * 把路径夹到某个数据作用域之内。
 * 注意本函数只做"路径数学 + 根断言"，不做授权 —— 授权由 ctx.fs.scope() 依据
 * manifest.scopes 判定。两者分开是为了让测试能单独验证"夹逼确实生效"。
 */
export function scopeDataPath(id, scope, rel = '') {
  assertPluginId(id)
  const root = scopeRoot(scope)
  const target = resolve(root, String(rel || ''))
  const relCheck = relative(root, target)
  if (relCheck.startsWith('..' + sep) || relCheck === '..' || isAbsolute(relCheck)) {
    // 两道门：既出作用域、又出数据/日志根 → 宿主门先拦（E_OUTSIDE_ROOT，更外层违规）；
    // 仅跨作用域但仍落在数据树内 → 插件语义门（E_PLUGIN_FS_OUTSIDE）。
    let hostErr = null
    try { assertInsideRoot(target) } catch (e) { hostErr = e }
    if (hostErr) throw hostErr
    throw new PluginError('E_PLUGIN_FS_OUTSIDE', `plugins(${id}): 拒绝写到作用域 ${scope} 之外 -> ${target}`, {
      id,
      scope,
    })
  }
  return target
}

function readJson(path) {
  try {
    return JSON.parse(readFileSync(path, 'utf8'))
  } catch {
    return null
  }
}/**
 * 创建插件注册表。
 * @param {{
 *   dir?: string,
 *   core?: { net?, providers?, sessions?, agent?, timer?, progress? },
 *   logger?: (line: string) => void,
 * }} options
 */
export function createRegistry({ dir = PLUGINS_DIR, core = {}, logger = null } = {}) {
  const root = assertInsideRoot(dir)
  /** id -> { id, dir, manifest, module, instance, state, commands, cards, error } */
  const records = new Map()
  const logto = (line) => {
    if (typeof logger === 'function') logger(line)
  }

  /** 统一写审计：插件任何动作都进 plugins.jsonl，且正文先过密钥打码。 */
  function audit(id, event, detail = {}) {
    try {
      appendJsonl(PLUGIN_LOG, { ts: new Date().toISOString(), pluginId: id, event, ...detail })
    } catch (err) {
      process.stderr.write(`[research-orb/plugins] audit failed: ${err && err.message}\n`)
    }
  }

  function makeLogger(id) {
    const emit = (level) => (msg, extra = {}) => {
      const text = shortMessage(stripSecrets(typeof msg === 'string' ? msg : JSON.stringify(msg)), 400)
      audit(id, 'log', { level, message: text, ...extra })
      logto(`[plugin:${id}] ${level} ${text}`)
    }
    return { info: emit('info'), warn: emit('warn'), error: emit('error'), debug: emit('debug') }
  }

  /** 受限 fs：全部落在 data\notes\<id>\ 之内。 */
  function makeFs(id) {
    const root2 = pluginDataPath(id, '')
    const rel = (p) => {
      const abs = pluginDataPath(id, p)
      return relative(root2, abs)
    }
    return {
      root: root2,
      path: (p) => pluginDataPath(id, p),
      exists: (p) => existsSync(pluginDataPath(id, p)),
      read: (p) => {
        const abs = pluginDataPath(id, p)
        if (!existsSync(abs)) throw new PluginError('E_PLUGIN_FS_NOT_FOUND', `plugins(${id}): 文件不存在 -> ${rel(p)}`, { id })
        return readFileSync(abs, 'utf8')
      },
      readJson: (p) => readJson(pluginDataPath(id, p)),
      write: (p, data) => {
        const r = safeWrite(pluginDataPath(id, p), data)
        audit(id, 'fs.write', { path: rel(p), bytes: r.bytes })
        return r
      },
      append: (p, data) => {
        const r = safeWrite(pluginDataPath(id, p), data, { append: true })
        audit(id, 'fs.append', { path: rel(p), bytes: r.bytes })
        return r
      },
      writeJson: (p, obj) => {
        const r = safeWrite(pluginDataPath(id, p), JSON.stringify(obj, null, 2))
        audit(id, 'fs.writeJson', { path: rel(p), bytes: r.bytes })
        return r
      },
      list: (p = '') => {
        const abs = pluginDataPath(id, p)
        if (!existsSync(abs)) return []
        const st = statSync(abs)
        if (!st.isDirectory()) return [relative(root2, abs)]
        return readdirSync(abs).map((n) => (p ? `${p}/${n}` : n))
      },
    }
  }

  /**
   * 声明式数据作用域：ctx.fs.scope('pdf') 之类。
   * 只有 manifest.scopes 里写过的名字才放行；每次写仍然走 safeWrite（→ writes.jsonl）。
   */
  function makeScopedFs(id) {
    const rec = records.get(id)
    const granted = new Set(rec ? rec.manifest.scopes : [])
    const cache = new Map()

    /** notes 作用域是共享的，禁止写进别的插件的私有抽屉（data/notes/<otherId>/）。 */
    function assertNotForeignNotes(rel0) {
      const first = String(rel0 || '').split(/[\\/]/).filter(Boolean)[0]
      if (!first) return
      if (first.startsWith('.')) return // .meta 这类隐藏目录不算插件抽屉
      for (const other of records.keys()) {
        if (other === id) continue
        if (other.toLowerCase() === first.toLowerCase()) {
          throw new PluginError(
            'E_SCOPE_FOREIGN_NOTES',
            `plugins(${id}): 作用域 notes 不允许写进插件 ${other} 的私有目录 -> ${first}/`,
            { id, scope: 'notes', foreign: other },
          )
        }
      }
    }

    function scopeApi(key) {
      let api = cache.get(key)
      if (api) return api
      const root = scopeDataPath(id, key, '')
      const rel = (p) => relative(root, scopeDataPath(id, key, p))
      const resolveRel = (p) => {
        if (key === 'notes') assertNotForeignNotes(rel(p))
        return scopeDataPath(id, key, p)
      }
      api = Object.freeze({
        name: key,
        root,
        path: (p) => resolveRel(p),
        exists: (p) => existsSync(resolveRel(p)),
        read: (p) => {
          const abs = resolveRel(p)
          if (!existsSync(abs)) {
            throw new PluginError('E_PLUGIN_FS_NOT_FOUND', `plugins(${id}): 文件不存在 -> ${key}/${rel(p)}`, { id })
          }
          return readFileSync(abs, 'utf8')
        },
        readJson: (p) => readJson(resolveRel(p)),
        write: (p, data) => {
          const r = safeWrite(resolveRel(p), data)
          audit(id, 'fs.write', { scope: key, path: rel(p), bytes: r.bytes })
          return r
        },
        append: (p, data) => {
          const r = safeWrite(resolveRel(p), data, { append: true })
          audit(id, 'fs.append', { scope: key, path: rel(p), bytes: r.bytes })
          return r
        },
        writeJson: (p, obj) => {
          const r = safeWrite(resolveRel(p), JSON.stringify(obj, null, 2))
          audit(id, 'fs.writeJson', { scope: key, path: rel(p), bytes: r.bytes })
          return r
        },
        list: (p = '') => {
          const dir = p ? `${String(p).replace(/[\\/]+$/, '')}` : ''
          const abs = resolveRel(dir)
          if (!existsSync(abs)) return []
          if (!statSync(abs).isDirectory()) return [rel(dir)]
          return readdirSync(abs)
            .filter((n) => !n.startsWith('.'))
            .map((n) => (dir ? `${dir}/${n}` : n))
        },
      })
      cache.set(key, api)
      return api
    }

    const scope = (name) => {
      const key = String(name || '')
      if (!(key in DATA_SCOPES)) {
        throw new PluginError('E_SCOPE_UNKNOWN', `plugins(${id}): 未知数据作用域 -> ${key}`, {
          id,
          scope: key,
          allowed: [...DATA_SCOPE_NAMES],
        })
      }
      if (!granted.has(key)) {
        throw new PluginError('E_SCOPE_NOT_GRANTED', `plugins(${id}): plugin.json 未声明作用域 -> ${key}`, {
          id,
          scope: key,
          granted: [...granted],
        })
      }
      return scopeApi(key)
    }
    scope.granted = () => [...granted]
    return scope
  }

  /** 受限 net：直接用 core 的 net 实例（白名单/限速/审计一个不少）。 */
  function makeNet(id) {
    const net = core.net || null
    if (!net || typeof net.request !== 'function') {
      const fail = () => {
        throw new PluginError('E_PLUGIN_NO_NET', `plugins(${id}): 宿主未注入 net，插件无法出网`, { id })
      }
      return { available: false, request: fail, json: fail, isAllowedUrl: () => false, ALLOWED_DOMAINS: [] }
    }
    const wrap = async (url, options = {}) => {
      audit(id, 'net.request', { host: net.hostOf(url), url: String(url).split('?')[0] })
      // 强制把限速桶键挂上插件名，避免插件与主程序抢同一个桶还查不出是谁
      const opts = { ...options, limitKey: options.limitKey || `plugin:${id}` }
      return net.request(url, opts)
    }
    return {
      available: true,
      request: wrap,
      json: async (url, options = {}) => {
        const res = await wrap(url, options)
        if (!res.ok) throw new PluginError('E_PLUGIN_HTTP', `plugins(${id}): HTTP ${res.status}`, { id, status: res.status })
        return res.json()
      },
      isAllowedUrl: (u) => net.isAllowedUrl(u),
      ALLOWED_DOMAINS: net.ALLOWED_DOMAINS,
      hostOf: (u) => net.hostOf(u),
    }
  }

  /** 受限 llm：复用 provider / agent，限速与降级照样生效。 */
  function makeLlm(id) {
    const providers = core.providers || null
    return {
      available: !!(providers && typeof providers.byId === 'function'),
      providers: () => (providers ? providers.list().map((p) => p.describe()) : []),
      /** 直接走 provider 的流式接口。 */
      chat: ({ providerId, messages, model, tools, signal } = {}) => {
        if (!providers) throw new PluginError('E_PLUGIN_NO_LLM', `plugins(${id}): 宿主未注入 providers`, { id })
        const p = providerId ? providers.byId(providerId) : providers.list()[0]
        if (!p) throw new PluginError('E_PLUGIN_NO_PROVIDER', `plugins(${id}): provider 不存在 -> ${providerId}`, { id })
        audit(id, 'llm.chat', { providerId: p.id, model: model || p.defaultModel })
        return p.chat({ messages, model, tools, signal })
      },
      /** 一次性取完整回复（走 agent，享受降级与落盘）。 */
      ask: async ({ providerId, message, messages, model, sessionId = null } = {}) => {
        const agent = core.agent || null
        if (!agent) throw new PluginError('E_PLUGIN_NO_LLM', `plugins(${id}): 宿主未注入 agent`, { id })
        audit(id, 'llm.ask', { providerId: providerId || null, model: model || null })
        return agent.runTurn({ sessionId, message, messages, providerId, model })
      },
    }
  }

  /** ui：宿主收集，面板读取；插件只声明，不接触 DOM。 */
  function makeUi(id) {
    const rec = records.get(id)
    return {
      registerCard: (spec = {}) => {
        const card = {
          pluginId: id,
          id: String(spec.id || `${id}.card`),
          title: String(spec.title || spec.id || id),
          body: String(spec.body ?? ''),
          actions: Array.isArray(spec.actions) ? spec.actions.map(String) : [],
        }
        rec.cards.push(card)
        audit(id, 'ui.card', { id: card.id })
        return card
      },
      registerCommand: (spec = {}) => {
        if (typeof spec.run !== 'function') {
          throw new PluginError('E_PLUGIN_BAD_COMMAND', `plugins(${id}): registerCommand 需要 run 函数`, { id })
        }
        const cmd = {
          pluginId: id,
          name: String(spec.name || '').replace(/^\/+/, ''),
          title: String(spec.title || spec.name || ''),
          description: String(spec.description || ''),
          run: spec.run,
        }
        if (!cmd.name) throw new PluginError('E_PLUGIN_BAD_COMMAND', `plugins(${id}): 命令必须有 name`, { id })
        rec.commands.push(cmd)
        audit(id, 'ui.command', { name: cmd.name })
        return cmd
      },
      listCards: () => rec.cards.map((c) => ({ ...c })),
      listCommands: () => rec.commands.map((c) => ({ pluginId: c.pluginId, name: c.name, title: c.title, description: c.description })),
    }
  }

  /** 小 KV：存 data\notes\<id>\state.json。 */
  function makeState(id) {
    const fsApi = makeFs(id)
    const cache = { data: null }
    const load = () => {
      if (cache.data === null) cache.data = fsApi.readJson('state.json') || {}
      return cache.data
    }
    return {
      get: (key, fallback = null) => {
        const d = load()
        return Object.prototype.hasOwnProperty.call(d, key) ? d[key] : fallback
      },
      set: (key, value) => {
        const d = load()
        d[key] = value
        fsApi.writeJson('state.json', d)
        return value
      },
      all: () => ({ ...load() }),
    }
  }

  function buildContext(rec) {
    const fsApi = makeFs(rec.id)
    fsApi.scope = makeScopedFs(rec.id)
    return Object.freeze({
      id: rec.id,
      version: rec.manifest.version,
      name: rec.manifest.name,
      dir: rec.dir,
      capabilities: [...rec.manifest.capabilities],
      permissions: [...rec.manifest.permissions],
      scopes: [...rec.manifest.scopes],
      log: makeLogger(rec.id),
      fs: fsApi,
      net: makeNet(rec.id),
      llm: makeLlm(rec.id),
      ui: makeUi(rec.id),
      state: makeState(rec.id),
      // 阶段 3：计时/进度引擎。宿主没装配（如裸注册表测试）时为 null，
      // 插件侧会自行用默认 store 兜底（见 research-timer 的 createEngine）。
      timer: core.timer || null,
      progress: core.progress || null,
      // P-R6.2：宿主注入的**白名单**核心能力（受控暴露，不整体开放 core 对象——
      // 整体开放会绕过 net/llm 的能力门禁）。screen = 屏幕感知桥（main.mjs 注入）。
      core: Object.freeze({
        timer: core.timer || null,
        progress: core.progress || null,
        screen: core.screen || null,
        // S13：音乐律动光环驱动器（宿主注入；裸注册表测试下为 null，插件须降级）。
        music: core.music || null,
      }),
      // 块 4：skill 安装能力。**只授予声明了 skill.admin 能力的插件**（目前仅内置
      // skill-installer）——安装/退休是宿主级权力，不能随任意插件下发。
      skillAdmin: rec.manifest.capabilities.includes('skill.admin') ? skillAdminApi() : null,
    })
  }

  /** 扫描插件目录，只读 manifest，不加载代码。 */
  function scan() {
    let names = []
    try {
      names = readdirSync(root)
    } catch {
      return []
    }
    const found = []
    for (const name of names) {
      if (name.startsWith('.')) continue // .retired（退休区）等宿主自留目录不是插件
      const dirPath = join(root, name)
      let st = null
      try {
        st = statSync(dirPath)
      } catch {
        continue
      }
      if (!st.isDirectory()) continue
      const manifestPath = join(dirPath, 'plugin.json')
      if (!existsSync(manifestPath)) continue
      const raw = readJson(manifestPath)
      let manifest = null
      let error = null
      try {
        manifest = normalizeManifest(raw, { dirName: name })
      } catch (err) {
        error = { code: err.code || 'E_BAD_MANIFEST', message: String(err.message || err) }
        manifest = { id: name, name, version: '0.0.0', description: '', capabilities: [], permissions: [], entry: DEFAULT_ENTRY }
      }
      const existing = records.get(manifest.id)
      if (existing) continue // 已登记（可能是启用中的），不覆盖
      const rec = {
        id: manifest.id,
        dir: assertPluginDir(dirPath),
        manifest,
        manifestError: error,
        module: null,
        instance: null,
        enabled: false,
        loadedAt: null,
        cards: [],
        commands: [],
        error: error ? error.message : null,
      }
      records.set(manifest.id, rec)
      found.push(rec.id)
    }
    return found
  }

  /** 取记录；没扫过就先扫一次（面板/自检的调用顺序不该成为使用者的负担）。 */
  function recordOf(id) {
    assertPluginId(id)
    if (!records.has(id)) scan()
    const rec = records.get(id)
    if (!rec) throw new PluginError('E_NO_PLUGIN', `plugins: 未找到插件 -> ${id}`, { id })
    return rec
  }

  /** 加载 entry 模块（不激活）。 */
  async function load(id) {
    const rec = recordOf(id)
    if (rec.manifestError) throw new PluginError('E_BAD_MANIFEST', rec.manifestError.message, { id })
    if (rec.module) return rec.module
    const entryPath = assertPluginDir(join(rec.dir, rec.manifest.entry))
    if (!existsSync(entryPath)) {
      rec.error = `entry 不存在 -> ${rec.manifest.entry}`
      throw new PluginError('E_NO_ENTRY', `plugins(${id}): ${rec.error}`, { id })
    }
    const mod = await import(new URL(`file://${entryPath.replace(/\\/g, '/')}`).href)
    if (typeof mod.activate !== 'function') {
      rec.error = 'index.mjs 未导出 activate(ctx)'
      throw new PluginError('E_NO_ACTIVATE', `plugins(${id}): ${rec.error}`, { id })
    }
    rec.module = mod
    audit(id, 'load', { entry: rec.manifest.entry })
    return mod
  }

  /** 启用：加载 + activate(ctx)。失败只记录，不抛给调用方（避免一个坏插件拖垮应用）。 */
  async function enable(id) {
    const rec = recordOf(id)
    if (rec.enabled) return { id, enabled: true, already: true }
    // 每次启用前清空上一轮的注册项，重复启用不会重复叠加
    rec.cards = []
    rec.commands = []
    try {
      const mod = await load(id)
      const ctx = buildContext(rec)
      const result = typeof mod.activate === 'function' ? await mod.activate(ctx) : null
      rec.instance = typeof result === 'function' ? { deactivate: result } : result && typeof result === 'object' ? result : null
      rec.enabled = true
      rec.loadedAt = new Date().toISOString()
      rec.error = null
      audit(id, 'enable', { version: rec.manifest.version, cards: rec.cards.length, commands: rec.commands.length })
      return { id, enabled: true, cards: rec.cards.length, commands: rec.commands.length }
    } catch (err) {
      rec.enabled = false
      rec.error = shortMessage(err && err.message ? err.message : String(err))
      audit(id, 'enable.failed', { error: rec.error })
      return { id, enabled: false, error: rec.error }
    }
  }

  /** 禁用：调 deactivate（若有）+ 清注册项。 */
  async function disable(id) {
    const rec = recordOf(id)
    let error = null
    try {
      if (rec.instance && typeof rec.instance.deactivate === 'function') await rec.instance.deactivate()
    } catch (err) {
      error = shortMessage(err && err.message ? err.message : String(err))
    }
    rec.enabled = false
    rec.instance = null
    rec.cards = []
    rec.commands = []
    audit(id, 'disable', { error })
    return { id, enabled: false, error }
  }

  async function enableAll() {
    scan()
    const out = []
    for (const id of records.keys()) {
      const r = await enable(id)
      if (!r.already) out.push(r)
    }
    return out
  }

  /** 列表：把 manifest 与运行态一起摊平（面板/自检都用这个）。 */
  function list() {
    return [...records.values()].map((rec) => ({
      id: rec.id,
      name: rec.manifest.name,
      version: rec.manifest.version,
      description: rec.manifest.description,
      capabilities: [...rec.manifest.capabilities],
      permissions: [...rec.manifest.permissions],
      scopes: [...rec.manifest.scopes],
      entry: rec.manifest.entry,
      dir: rec.dir,
      enabled: rec.enabled,
      loadedAt: rec.loadedAt,
      cards: rec.cards.length,
      commands: rec.commands.map((c) => c.name),
      error: rec.error || null,
    }))
  }

  function get(id) {
    return list().find((p) => p.id === id) || null
  }

  /** 面板用：所有已启用插件的卡片。 */
  function cards() {
    return [...records.values()].filter((r) => r.enabled).flatMap((r) => r.cards.map((c) => ({ ...c })))
  }

  /** 面板用：所有已启用插件的命令（不含 run，避免跨上下文泄漏）。 */
  function commands() {
    return [...records.values()].filter((r) => r.enabled).flatMap((r) =>
      r.commands.map((c) => ({ pluginId: c.pluginId, name: c.name, title: c.title, description: c.description })),
    )
  }

  /** 执行命令：/hello args... */
  async function runCommand(name, rest = '', extra = {}) {
    const clean = String(name || '').replace(/^\/+/, '')
    for (const rec of records.values()) {
      if (!rec.enabled) continue
      const cmd = rec.commands.find((c) => c.name === clean)
      if (!cmd) continue
      try {
        const value = await cmd.run(rest, extra)
        audit(rec.id, 'command.run', { name: clean })
        return { ok: true, pluginId: rec.id, name: clean, value }
      } catch (err) {
        const message = shortMessage(err && err.message ? err.message : String(err))
        audit(rec.id, 'command.failed', { name: clean, error: message })
        return { ok: false, pluginId: rec.id, name: clean, error: message }
      }
    }
    return { ok: false, pluginId: null, name: clean, error: 'E_NO_COMMAND' }
  }

  async function disposeAll() {
    for (const id of [...records.keys()]) {
      const rec = records.get(id)
      if (rec.enabled) await disable(id)
    }
  }

  // --- 块 4：skill 适配性安装器 ---------------------------------------------
  //
  // 两段式确认：prepare（校验 + 列权限，**零写入**）→ 用户在面板确认 → commit（复制 + 审计 + 重扫）。
  // 红线（沿事故教训）：只认本地目录（无 URL/网络参数，禁远程下载执行）；来源哈希校验失败必须拒绝；
  // 目标已存在即拒绝（更新 = 显式"先退休再装"，禁自动更新）；卸载 = 移入 .retired（只移不删）。

  const pendingSkills = new Map() // token -> { sourceDir, raw, perms, at }
  const PENDING_TTL = 10 * 60 * 1000

  /** 组装授给 skill.admin 插件的管理 API（只含这几个动作，不给 registry 本体）。 */
  function skillAdminApi() {
    return {
      prepare: prepareSkillInstall,
      commit: commitSkillInstall,
      cancel: cancelSkillInstall,
      retire: retireSkill,
      list: listInstalledSkills,
      pendingCount: () => pendingSkills.size,
    }
  }

  function listInstalledSkills() {
    scan()
    return [...records.values()].map((r) => ({
      id: r.id,
      version: r.manifest.version,
      enabled: r.enabled,
      source: r.manifest.source || null,
      hashFiles: r.manifest.hash ? Object.keys(r.manifest.hash).length : 0,
      scopes: r.manifest.scopes,
      error: r.error,
    }))
  }

  function prepareSkillInstall(sourceDir) {
    const src = String(sourceDir || '').trim()
    if (!src) return { ok: false, code: 'E_BAD_ARGS', error: '需要本地 skill 目录路径' }
    if (!existsSync(src) || !statSync(src).isDirectory()) return { ok: false, code: 'E_NOT_FOUND', error: `目录不存在 -> ${src}` }
    const raw = readSkillManifest(src)
    if (!raw || typeof raw.id !== 'string' || !raw.id) {
      return { ok: false, code: 'E_NO_MANIFEST', error: '目录下没有含合法 id 的 plugin.json' }
    }
    // id 形态先过宿主断言（防 `../evil` 一类 id 在 commit 时被当路径用）
    try {
      assertPluginId(raw.id)
    } catch (err) {
      audit('skill-installer', 'install.rejected', { source: src, code: 'E_BAD_PLUGIN_ID' })
      return { ok: false, code: 'E_BAD_PLUGIN_ID', error: String(err.message || err) }
    }
    const verify = verifySource(src, raw)
    if (!verify.ok) {
      audit('skill-installer', 'install.rejected', { source: src, code: verify.code, details: verify.details })
      return { ok: false, code: verify.code, error: verify.message, details: verify.details }
    }
    const now = Date.now()
    for (const [k, v] of pendingSkills) if (now - v.at > PENDING_TTL) pendingSkills.delete(k)
    const perms = summarizePermissions(raw)
    const token = sha256(`${src}|${now}|${Math.random()}|${verify.files}`).slice(0, 12)
    pendingSkills.set(token, { sourceDir: src, raw, perms, at: now })
    audit('skill-installer', 'install.prepare', { source: src, id: raw.id, token, files: verify.files, scopes: perms.scopes, permissions: perms.permissions })
    return { ok: true, token, id: raw.id, name: typeof raw.name === 'string' ? raw.name : raw.id, version: typeof raw.version === 'string' ? raw.version : '0.0.0', files: verify.files, permissions: perms, note: `等待用户确认：/skill confirm ${token}（拒绝或 10 分钟超时即中止）` }
  }

  function commitSkillInstall(token) {
    const p = pendingSkills.get(String(token || '').trim())
    if (!p) return { ok: false, code: 'E_NO_PENDING', error: '没有这个待确认的安装（可能已过期、已取消或未 prepare）' }
    pendingSkills.delete(String(token).trim())
    const id = p.raw.id
    const target = join(root, id)
    if (existsSync(target)) {
      return { ok: false, code: 'E_ALREADY_INSTALLED', error: `插件目录已存在：packages/plugins/${id}（更新 = 先 /skill retire 旧的再装；禁止自动更新）` }
    }
    // commit 前复核一次来源（防确认窗口期内文件被改）
    const verify = verifySource(p.sourceDir, p.raw)
    if (!verify.ok) {
      audit('skill-installer', 'install.rejected', { source: p.sourceDir, code: verify.code, stage: 'commit', details: verify.details })
      return { ok: false, code: verify.code, error: verify.message, details: verify.details }
    }
    // 逐文件复制，全走 safeWrite（→ writes.jsonl 审计；路径夹逼在项目根内）
    const manifestText = `${JSON.stringify({ ...p.raw, source: p.sourceDir }, null, 2)}\n`
    safeWrite(join(target, 'plugin.json'), manifestText)
    const rels = Object.keys(p.raw.hash).sort()
    for (const rel of rels) {
      safeWrite(join(target, rel), readFileSync(join(p.sourceDir, rel)))
    }
    audit(id, 'install.commit', { source: p.sourceDir, files: rels.length + 1, scopes: p.perms.scopes, permissions: p.perms.permissions, at: new Date().toISOString() })
    scan()
    return { ok: true, id, files: rels.length + 1, note: `已安装到 packages/plugins/${id}；重扫完成（启用走 enable 流程）` }
  }

  function cancelSkillInstall(token) {
    const key = String(token || '').trim()
    const p = pendingSkills.get(key)
    if (!p) return { ok: false, code: 'E_NO_PENDING', error: '没有这个待确认的安装' }
    pendingSkills.delete(key)
    audit('skill-installer', 'install.cancelled', { source: p.sourceDir, token: key })
    return { ok: true, note: '已取消：什么都没装' }
  }

  async function retireSkill(id) {
    assertPluginId(id)
    const rec = records.get(id)
    if (!rec) return { ok: false, code: 'E_NO_PLUGIN', error: `没有这个插件：${id}` }
    if (rec.enabled) await disable(id)
    const stamp = new Date().toISOString().replace(/[:.]/g, '-')
    const dest = join(root, RETIRED_DIR, `${id}-${stamp}`)
    mkdirSync(join(root, RETIRED_DIR), { recursive: true })
    // 只移不删：整个目录原样搬进退休区（用户内容永不因卸载消失）
    renameSync(rec.dir, dest)
    records.delete(id)
    audit(id, 'retire', { from: relative(PROJECT_ROOT, rec.dir), to: relative(PROJECT_ROOT, dest), mode: 'move-only' })
    return { ok: true, id, retiredTo: relative(PROJECT_ROOT, dest), note: '已移入退休目录（只移不删）；恢复 = 手动移回 packages/plugins/<id>/' }
  }

  return {
    dir: root,
    scan,
    load,
    enable,
    disable,
    enableAll,
    disposeAll,
    list,
    get,
    cards,
    commands,
    runCommand,
    audit,
    prepareSkillInstall,
    commitSkillInstall,
    cancelSkillInstall,
    retireSkill,
    listInstalledSkills,
    _records: records,
  }
}

export default { createRegistry, PLUGINS_DIR, NOTES_DIR, PLUGIN_LOG, DATA_SCOPES, DATA_SCOPE_NAMES, normalizeManifest, pluginDataPath, scopeRoot, scopeDataPath }
