// packages/plugins/mode/index.mjs
//
// S22·B.3：运行模式切换命令（/mode）。
// 纪律（红线）：
//   · 只调用 core/modes.mjs 的纯函数（listModes / currentMode / setMode / capOf），
//     不重写任何封顶逻辑；封顶值一律来自 data/modes/<id>.json。
//   · setMode 已走 settings.safeWrite 审计，并在 data/logs/mode.jsonl 留切换轨迹；
//     本命令不另写审计，避免重复。
//   · 几何契约不变：复用宿主既有命令卡 / 状态卡样式，不引入新几何、不破面板布局。
//   · 命名边界：参考 token-lean preset 的封顶参数与三条行为规则；本实现独立重写，不依赖 DSH。
import { listModes, currentModeId, currentMode, setMode } from '../../core/src/modes.mjs'

export const PLUGIN_ID = 'mode'

const MODE_NAMES = Object.freeze({ standard: '标准', lean: '省钱', readonly: '只读' })
const MODE_DETAIL = Object.freeze({
  standard: '封顶沿用现有默认值，行为与今日完全一致。',
  lean: '省 token：读文件 / 检索 / 抓取 / 工具结果一律按本档封顶，适合长会话。',
  readonly: '只读：禁止一切写盘与命令执行，仅可查看与检索。',
})

/** 把当前模式的封顶值压成可读摘要。 */
export function capsSummary(m) {
  if (!m || !m.caps) return ''
  const c = m.caps
  const lines = [
    `· 读文件上限：${c.readMaxBytes} 字节` +
      (c.readLimitLines ? ` / ${c.readLimitLines} 行` : '') +
      (c.readMaxLineChars ? ` / 行内 ${c.readMaxLineChars} 字符` : ''),
    `· 检索上限：${c.grepMaxMatches} 条`,
    `· 网页抓取上限：${c.webFetchMaxChars} 字节`,
    `· 工具结果上限：${c.toolResultCapChars} 字符`,
    `· 写盘：${m.permissions && m.permissions.denyWrite ? '禁止' : '允许'}；命令执行：${m.permissions && m.permissions.denyExec ? '禁止' : '允许'}`,
  ]
  return lines.join('\n')
}

const USAGE = '用法：/mode [list｜show｜set <standard|lean|readonly>]'

export async function activate(ctx) {
  const log = (ctx && ctx.log) || console

  // 面板状态卡：复用既有卡片样式，让模式可见（几何契约不变）。
  // 标题直接呈现当前模式（如「模式：省钱」），满足面板可见性要求；切换后重新激活即刷新。
  if (ctx && ctx.ui && typeof ctx.ui.registerCard === 'function') {
    const cid = currentModeId()
    ctx.ui.registerCard({
      id: 'mode.status',
      title: `模式：${MODE_NAMES[cid] || cid}`,
      body: '用 /mode 切换运行模式：standard（标准）/ lean（省钱）/ readonly（只读）。切换走审计，可回退。',
    })
  }

  if (!(ctx && ctx.ui && typeof ctx.ui.registerCommand === 'function')) {
    log.warn('mode: 宿主未提供 ui.registerCommand')
    return { ok: false }
  }

  ctx.ui.registerCommand({
    name: 'mode',
    title: '运行模式切换',
    description: USAGE,
    run: async (rest = '') => {
      const parts = String(rest || '').trim().split(/\s+/).filter(Boolean)
      const sub = (parts[0] || '').toLowerCase()
      try {
        if (sub === 'list') {
          const list = listModes().map(
            (m) => `· ${m.id}（${MODE_NAMES[m.id] || m.id}）：${MODE_DETAIL[m.id] || m.description || ''}`,
          )
          return { ok: true, ui: { kind: 'text', message: '可用模式：\n' + list.join('\n') } }
        }
        if (sub === 'set') {
          const id = (parts[1] || '').toLowerCase()
          if (!['standard', 'lean', 'readonly'].includes(id)) {
            return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: USAGE } }
          }
          const m = setMode(id)
          return { ok: true, ui: { kind: 'text', message: `已切换到模式：${id}（${MODE_NAMES[id] || id}）\n` + capsSummary(m) } }
        }
        // 默认：show 当前
        const id = currentModeId()
        const m = currentMode()
        return { ok: true, ui: { kind: 'text', message: `当前模式：${id}（${MODE_NAMES[id] || id}）\n` + capsSummary(m) } }
      } catch (e) {
        return { ok: false, code: e.code || 'E_MODE', ui: { kind: 'error', message: e.message || String(e) } }
      }
    },
  })
  return { ok: true }
}

export default { activate, PLUGIN_ID, MODE_NAMES, capsSummary }
