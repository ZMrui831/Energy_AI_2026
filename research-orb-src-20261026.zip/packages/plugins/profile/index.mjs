// packages/plugins/profile/index.mjs
//
// S20·A：用户画像与个性化。
// 纪律（红线）：
//   · 字段白名单——绝不落盘姓名/学号/单位/邮箱等身份信息（IDENTITY_KEYS 黑名单兜底）。
//   · 所有画像输入一律用演示值（专业=计算机科学、方向=信息检索…），默认占位。
//   · 落盘走 safefs 审计（appendJsonl 到 writes.jsonl），不绕过边界。
//   · digest 注入走宿主（main.mjs）已有的 agent system 参数，本插件不改 agent.mjs 内部。
//   · 面板复用宿主既有卡片样式，不引入新几何/新 12 态，不破几何契约。
import { existsSync, mkdirSync, readFileSync, writeFileSync, rmSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, appendJsonl, logPath, dataPath } from '../../core/src/safefs.mjs'

export const PLUGIN_ID = 'profile'

// 问卷维度（≤8 题）；每项带演示默认值，全部可跳过。
export const FIELD_SCHEMA = {
  major: { label: '专业', demo: '计算机科学', q: '你的专业方向是？' },
  direction: { label: '细分方向', demo: '信息检索', q: '具体研究/细分方向？' },
  stage: { label: '学业阶段', demo: '本科', q: '当前阶段？' },
  literatureTypes: { label: '常读文献类型', demo: '期刊论文/综述', q: '常读哪些文献类型？' },
  goal: { label: '近期目标', demo: '完成一篇文献综述', q: '近期最想被帮上忙的事？' },
  weeklyHours: { label: '每周投入(小时)', demo: '10', q: '每周能投入多少小时？' },
  language: { label: '偏好语言', demo: '中文', q: '回复用什么语言？' },
  reminderIntensity: { label: '提醒强度', demo: '中', q: '提醒强度（强/中/弱/关）？' },
}

// 本地感知是独立授权项（默认关），不在画像白名单里混用。
export const LOCAL_PERCEPTION_DEFAULT = '关'

// 身份类字段黑名单：落盘前若发现即拒绝（兜底，正常流程不会传入）。
const IDENTITY_KEYS = [
  'name', 'studentid', 'school', 'affiliation', 'email', 'phone', 'id', 'realname',
  '姓名', '学号', '单位', '邮箱', '电话', '真实姓名',
]

const PROFILE_PATH = () => dataPath('profile.json')
const DIGEST_PATH = () => dataPath('profile-digest.txt')

/** 中文≈2字/token 的保守估计，用于 ≤300 token 断言。 */
export function estimateTokens(s) {
  return Math.max(0, Math.ceil((s || '').length / 2))
}

/** 演示默认值（未作答时填充，保证"全可跳过"且不含真实身份）。 */
export function demoFields() {
  const f = {}
  for (const [k, v] of Object.entries(FIELD_SCHEMA)) f[k] = v.demo
  return f
}

function audit(kind, extra = {}) {
  try {
    appendJsonl(logPath('profile.jsonl'), { kind, plugin: PLUGIN_ID, ...extra })
  } catch { /* 审计尽力 */ }
}

function validateFields(obj) {
  const out = {}
  for (const k of Object.keys(FIELD_SCHEMA)) out[k] = (obj && obj[k] != null) ? String(obj[k]) : FIELD_SCHEMA[k].demo
  // 黑名单兜底
  for (const bad of IDENTITY_KEYS) {
    if (Object.prototype.hasOwnProperty.call(obj || {}, bad)) {
      throw new ProfileError('E_IDENTITY_FIELD', '画像禁止写入身份字段：' + bad)
    }
  }
  return out
}

export class ProfileError extends Error {
  constructor(code, message) { super(message); this.name = 'ProfileError'; this.code = code }
}

/** 把画像压缩成 ≤300 token 的 profileDigest（规则化、可注入 system）。 */
export function buildDigest(prof) {
  const f = (prof && prof.fields) || demoFields()
  const lp = (prof && prof.localPerception) || LOCAL_PERCEPTION_DEFAULT
  const lines = [
    `【用户画像·演示值】专业=${f.major}；方向=${f.direction}；阶段=${f.stage}；常读=${f.literatureTypes}；目标=${f.goal}；每周投入≈${f.weeklyHours}h；偏好语言=${f.language}；提醒强度=${f.reminderIntensity}；本地感知=${lp}。`,
    `回复约定：不使用任何真实身份信息；优先贴合其专业方向与${f.language}表达；涉及文献时遵守撤稿标记与双源校验纪律。`,
  ]
  let digest = lines.join('\n')
  // 硬上限：超过则截断到安全长度（正常演示值远小于此）。
  if (estimateTokens(digest) > 300) digest = digest.slice(0, 600)
  return digest
}

export function readProfile() {
  try {
    const p = PROFILE_PATH()
    if (!existsSync(p)) return null
    return JSON.parse(readFileSync(p, 'utf8'))
  } catch { return null }
}

export function writeProfile({ fields, localPerception = LOCAL_PERCEPTION_DEFAULT, personalization = true, source = 'questionnaire' }) {
  const clean = validateFields(fields)
  if (IDENTITY_KEYS.some((k) => k in (fields || {}))) {
    throw new ProfileError('E_IDENTITY_FIELD', '画像禁止写入身份字段')
  }
  const prof = {
    version: 1,
    updatedAt: new Date().toISOString(),
    source,
    personalization: personalization === true,
    localPerception: String(localPerception),
    fields: clean,
  }
  const p = PROFILE_PATH()
  mkdirSync(dataPath(), { recursive: true })
  writeFileSync(p, JSON.stringify(prof, null, 2), 'utf8')
  const digest = buildDigest(prof)
  writeFileSync(DIGEST_PATH(), digest, 'utf8')
  audit('profile-written', { personalization: prof.personalization, tokens: estimateTokens(digest) })
  return prof
}

export function resetProfile() {
  for (const p of [PROFILE_PATH(), DIGEST_PATH()]) {
    if (existsSync(p)) { try { rmSync(p) } catch { /* ignore */ } }
  }
  audit('profile-reset')
  return true
}

export function profileDigestText() {
  const p = DIGEST_PATH()
  return existsSync(p) ? readFileSync(p, 'utf8').trim() : ''
}

// --------------------------------------------------------------------------
// 命令解析
// --------------------------------------------------------------------------
function parseFlags(rest) {
  const out = {}
  const re = /--([a-zA-Z_]+)\s+("([^"]*)"|'([^']*)'|(\S+))/g
  let m
  while ((m = re.exec(rest)) !== null) {
    const val = m[3] ?? m[4] ?? m[5]
    out[m[1]] = val
  }
  return out
}

const USAGE = '用法：/profile setup [--major X --direction X --stage X --types X --goal X --weekly X --lang X --reminder X --perception on|off --personalization on|off]｜/profile show｜/profile digest｜/profile reset'

export async function activate(ctx) {
  const log = (ctx && ctx.log) || console
  if (ctx && ctx.ui && typeof ctx.ui.registerCard === 'function') {
    ctx.ui.registerCard({
      id: 'profile.status',
      title: '用户画像',
      body: '把悬浮球"认得你"：/profile setup 填问卷（全可跳过，默认演示值）→ 可注入对话 system；/profile show 查看；/profile reset 清空。只存维度，不存姓名/学号/单位/邮箱。',
    })
  }
  if (!(ctx && ctx.ui && typeof ctx.ui.registerCommand === 'function')) {
    log.warn('profile: 宿主未提供 ui.registerCommand')
    return { ok: false }
  }
  ctx.ui.registerCommand({
    name: 'profile',
    title: '用户画像与个性化',
    description: USAGE,
    run: async (rest = '') => {
      const parts = String(rest || '').trim().split(/\s+/).filter(Boolean)
      const sub = (parts[0] || '').toLowerCase()
      const argStr = parts.slice(1).join(' ')
      try {
        if (sub === 'setup') {
          const fl = parseFlags(argStr)
          // 把 --types / --lang / --perception / --personalization 映射到字段
          const fields = {}
          for (const k of Object.keys(FIELD_SCHEMA)) {
            if (fl[k] != null) fields[k] = fl[k]
          }
          if (fl.types != null) fields.literatureTypes = fl.types
          if (fl.lang != null) fields.language = fl.lang
          if (fl.reminder != null) fields.reminderIntensity = fl.reminder
          if (fl.weekly != null) fields.weeklyHours = fl.weekly
          const lp = fl.perception === 'on' ? '开' : (fl.perception === 'off' ? '关' : LOCAL_PERCEPTION_DEFAULT)
          const pers = fl.personalization === 'off' ? false : true
          const prof = writeProfile({ fields, localPerception: lp, personalization: pers, source: 'questionnaire' })
          return { ok: true, ui: { kind: 'text', message: '画像已保存（演示值，无身份信息）。\n' + profileDigestText() } }
        }
        if (sub === 'show') {
          const prof = readProfile()
          if (!prof) return { ok: true, ui: { kind: 'text', message: '尚未设置画像。运行 /profile setup 填写（可全跳过）。' } }
          const lines = Object.entries(prof.fields).map(([k, v]) => `· ${FIELD_SCHEMA[k]?.label || k}：${v}`)
          lines.push(`· 本地感知：${prof.localPerception}`)
          lines.push(`· 个性化注入：${prof.personalization ? '开' : '关'}`)
          return { ok: true, ui: { kind: 'text', message: lines.join('\n') } }
        }
        if (sub === 'digest') {
          const d = profileDigestText()
          if (!d) return { ok: true, ui: { kind: 'text', message: '尚无 digest。先 /profile setup。' } }
          return { ok: true, ui: { kind: 'text', message: `（${estimateTokens(d)} token）\n${d}` } }
        }
        if (sub === 'reset') {
          resetProfile()
          return { ok: true, ui: { kind: 'text', message: '画像已清空（profile.json 与 digest 已删除）。' } }
        }
        return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: USAGE } }
      } catch (e) {
        return { ok: false, code: e.code || 'E_PROFILE', ui: { kind: 'error', message: e.message || String(e) } }
      }
    },
  })
  return { ok: true }
}

export default { activate, readProfile, writeProfile, resetProfile, buildDigest, estimateTokens, demoFields, profileDigestText, PLUGIN_ID }
