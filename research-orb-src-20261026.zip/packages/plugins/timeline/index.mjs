// packages/plugins/timeline/index.mjs
//
// S4/S5 学习轨迹插件 —— 轨迹页数据出口 + 学习会话 + UI 状态矩阵调试入口。
// 不做采样/抓屏引擎（那些在 S1/S2/S3 与演示主线里），本插件只编排公开 API：
//   · /timeline [日期]          轨迹页 payload（日→片段→事件三级 + 证据保留对账）
//   · /learn start|stop         开始/结束学习（切 perception learning 态 + 计时落账）
//   · /ui state <12态之一>      调试入口：确定性切 UI 状态（截图回归用）
//   · /ui ask                   触发一次主动询问卡（调试/演示用；冷却期自动抑制）
//   · /ui home                  回首页
//
// 权限与接线（均不改任何已验收内部）：
//   · store：主进程 S3.1 单例经 globalThis.researchOrbLifecycle 桥（ctx.core 冻结白名单）
//   · registry：pack activate 时挂 globalThis.__researchRegistry（pack ctx 才有 registry；
//     插件 ctx 没有——这是插件体系的公开边界，不是内部 hack）
//   · perception 的 learning 态：经 registry.enable/disable 重激活 + PERCEPTION_STATE 环境变量
//     （S2 resolveState 文档化注入点：ctx.state → argv --state → env PERCEPTION_STATE）
//   · 同意检查：直接调用 S2 公开 consent API（isActive/allowsScreenCapture）
//   · 计时落账：/start --project 学习 → /stop → /today 可查（timer 插件公开命令）

import { existsSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from 'node:fs'
import { createHash } from 'node:crypto'
import { join } from 'node:path'

import { appendJsonl, logPath, safeWrite, PROJECT_ROOT, dataPath } from '../../core/src/safefs.mjs'
import { isActive as consentActive } from '../perception/consent.mjs'
import {
  createClaim, attachEvidence, publishClaim, resolveEvidence, buildClaimExport,
} from '../../core/src/lifecycle/publish.mjs'
import { trashStats } from '../../core/src/lifecycle/cleaner.mjs'
import { countExternalCaptures } from '../../core/src/lifecycle/capture-registry.mjs'
import {
  DRAFTS_DIR, FORMAL_DIR, PROACTIVE_INTENT, UI_STATES,
  appendSegment, buildAskText, buildTimelinePayload, computeConfidence,
  getProactiveState, isCooling, listDirFiles, pendingPlans, readDailyReport,
  readLearningSession, readSegments,
  recordRejection, timelineText, todayLearningMs, writeDraftFromCapture, writeDwellEvidence,
  writeLearningSession, writeUiState,
} from './logic.mjs'

export const TIMELINE_VERSION = '0.7.0'
const AUDIT = logPath('timeline.jsonl')
const LEARNING_PROJECT_ID = 'learn'
const LEARNING_PROJECT_NAME = '学习'
const TRASH_DIR = dataPath('trash')
// S2 同意语义的 processStartedAt：本插件激活时刻（应用启动后不久）——晚于此的
// session 授权有效，早于此的（上一进程遗留）失效。与 perception 控制器构造时刻同口径。
const PROCESS_STARTED_AT = Date.now()

/** runCommand 的传输层 ok 恒为 true；命令成败看 value.ok。 */
function cmdOk(r) {
  return !!(r && r.ok && r.value && r.value.ok !== false)
}
function cmdText(r) {
  return r && r.value && r.value.text ? String(r.value.text) : ''
}

/** 把文件复制进 data/trash 再删原件（与 S1 fs.delete 同口径：不真删，可恢复）。 */
function trashFile(abs) {
  try {
    mkdirSync(TRASH_DIR, { recursive: true })
    const stamp = new Date().toISOString().replace(/[:.]/g, '-')
    const dest = join(TRASH_DIR, `${stamp}-${abs.split('\\').pop()}`)
    writeFileSync(dest, readFileSync(abs))
    rmFile(abs)
    return dest
  } catch { return null }
}
function rmFile(abs) {
  try {
    rmSync(abs, { force: true })
  } catch { /* 调用方按存在性另行判断 */ }
}

function lifecycleStore() {
  const bridge = globalThis.researchOrbLifecycle
  return bridge && bridge.store ? bridge.store : null
}

function hostRegistry() {
  return globalThis.__researchRegistry || null
}

async function runHostCommand(name, args) {
  const reg = hostRegistry()
  if (!reg || typeof reg.runCommand !== 'function') return null
  try {
    return await reg.runCommand(name, args)
  } catch (e) {
    return { ok: false, error: String((e && e.message) || e) }
  }
}

// ---------------------------------------------------------------------------
// S54·D1 感知状态卡（七项，全部真实数据；缺数据显示 null → UI 显示 —）
//   口径（审计为证，不发明）：
//   ② 今日采样次数   = perception.jsonl 今日 frame-registered（成功采样并注册的帧）
//   ③ 今日已压缩张数 = lifecycle.jsonl 今日 frame-deleted + trash-expired（原图确已删除的张数）
//   ④ 今日片段数     = readSegments()（今日 segments-YYYYMMDD.jsonl，latest-wins）
//   ⑤ 最近采样时间   = perception.jsonl 今日最新 frame-registered ts
//   ⑥ 预估节省 MB    = 今日 trash-expired 释放字节 + trash 目录现存字节（待释放）
//   ⑦ 会话轨迹条数   = 今日片段中 startedAt ≥ 本进程启动时刻（PROCESS_STARTED_AT）的条数
// ---------------------------------------------------------------------------
const LIFECYCLE_AUDIT = logPath('lifecycle.jsonl')

/** 今日清理审计统计（frame-deleted/trash-expired 的张数与释放字节；文件缺失按 0，不抛）。 */
function cleanupToday(now = Date.now()) {
  const out = { framesDeleted: 0, trashExpired: 0, bytesFreed: 0 }
  try {
    const d0 = new Date(now)
    d0.setHours(0, 0, 0, 0)
    const t0 = d0.getTime()
    if (existsSync(LIFECYCLE_AUDIT)) {
      for (const line of readFileSync(LIFECYCLE_AUDIT, 'utf8').split('\n')) {
        const s = line.trim()
        if (!s) continue
        try {
          const row = JSON.parse(s)
          if (!row || typeof row.ts !== 'number' || row.ts < t0) continue
          if (row.kind === 'frame-deleted') out.framesDeleted += 1
          else if (row.kind === 'trash-expired') {
            out.trashExpired += 1
            const b = row.metadata && Number(row.metadata.bytes)
            if (Number.isFinite(b)) out.bytesFreed += b
          }
        } catch { /* 半行跳过 */ }
      }
    }
  } catch { /* 读不了按 0 */ }
  return out
}

/** S60·P0-4：视觉 provider 诊断（配置是否就绪 + 最近一次实测延迟）。
 *  只读 providers.json / secrets.json / usage.jsonl —— 不写任何文件。 */
function visionDiagnostics() {
  try {
    const doc = JSON.parse(readFileSync(dataPath('providers.json'), 'utf8'))
    const v = doc && doc.vision
    if (!v) return { configured: false, ready: false, reason: 'providers.json 无 vision 段' }
    let sec = {}
    try { sec = JSON.parse(readFileSync(dataPath('secrets.json'), 'utf8')) || {} } catch { /* 读不到按无密钥 */ }
    const keyName = String(v.authRef || '').replace(/^secrets:/, '')
    const hasKey = !!(sec && sec[keyName])
    let lastMs = null
    let lastAt = null
    try {
      const p = logPath('usage.jsonl')
      if (existsSync(p)) {
        const lines = readFileSync(p, 'utf8').trim().split('\n')
        for (let i = lines.length - 1; i >= 0 && i > Math.max(-1, lines.length - 120); i--) {
          const s = lines[i].trim()
          if (!s) continue
          try {
            const r = JSON.parse(s)
            if (r && r.tier === 'vision') { lastMs = r.ms ?? null; lastAt = r.ts || null; break }
          } catch { /* 半行跳过 */ }
        }
      }
    } catch { /* usage 不可读不影响就绪判定 */ }
    return {
      configured: true,
      ready: hasKey,
      providerId: v.providerId || null,
      model: v.model || null,
      lastMs,
      lastAt,
      reason: hasKey ? null : `密钥缺失（secrets:${keyName}）`,
    }
  } catch (e) {
    return { configured: false, ready: false, reason: String((e && e.message) || e).slice(0, 80) }
  }
}

function buildPerceptionCard({ perception, perToday, processStartedAt }) {
  try {
    const seg = readSegments()
    const todayTrash = trashStats(TRASH_DIR)
    const cl = cleanupToday()
    const trashLiveBytes = (todayTrash && Number(todayTrash.bytes)) || 0
    return {
      running: perception && typeof perception.running === 'boolean' ? perception.running : null,
      samplesToday: perToday ? perToday.samples : null,
      // S55·A：口径拆成两个数（不混）
      //   主指标③ 已压缩送模 = **sent-to-model 审计事件数**（coach/extract.mjs 在 640 降采样
      //     送模那一刻写 {kind,frameId,bytesBefore,bytesAfter,ts}）——名字与数据一致
      //   副标 原图已删 = lifecycle 审计 frame-deleted + trash-expired（零明文留存的证据）
      compressedSentToday: perToday ? perToday.sentToModel : null,
      originalsDeletedToday: cl.framesDeleted + cl.trashExpired,
      segmentsToday: seg.length,
      lastSampleTs: perToday ? perToday.lastSampleTs : 0,
      // ⑥ 预估省 = Σ(bytesBefore − bytesAfter)（真实字节差，来自 sent-to-model 审计）
      savedBytesEstimate: perToday
        ? Math.max(0, (perToday.sentBytesBefore || 0) - (perToday.sentBytesAfter || 0))
        : 0,
      sessionSegments: seg.filter((x) => Number(x.startedAt || 0) >= processStartedAt).length,
    }
  } catch {
    return null // 任何统计失败 → UI 显示全 —（缺数据不装 0）
  }
}

/** 今日压缩落盘字节（data/perception/shots 目录中 mtime 属于今天的文件 size 和）。 */function shotsBytesToday(now = Date.now()) {
  let bytes = 0
  try {
    const dir = dataPath('perception', 'shots')
    if (!existsSync(dir)) return 0
    const d0 = new Date(now)
    d0.setHours(0, 0, 0, 0)
    const t0 = d0.getTime()
    for (const name of readdirSync(dir)) {
      try {
        const st = statSync(join(dir, name))
        if (st.isFile() && st.mtimeMs >= t0) bytes += st.size
      } catch { /* 跳过 */ }
    }
  } catch { /* 目录不可读按 0 */ }
  return bytes
}


export async function activate(ctx) {
  const log = (ctx && ctx.log) || console
  const screen = (ctx && ctx.core && ctx.core.screen) || null

  if (ctx && ctx.ui && typeof ctx.ui.registerCard === 'function') {
    ctx.ui.registerCard({
      id: 'timeline.status',
      title: '学习轨迹',
      body: '当天学习片段：时间/状态/时长/置信度/证据数/保留倒计时；点开可回指 evidence_id。原图被保留策略清理后如实标注，绝不假装还能看。',
    })
  }

  // ---- /timeline：轨迹页数据（日→片段→事件三级）----
  if (ctx && ctx.ui && typeof ctx.ui.registerCommand === 'function') {
    ctx.ui.registerCommand({
      name: 'timeline',
      title: '学习轨迹页',
      description: '用法：/timeline [YYYY-MM-DD]——查看当天（或指定日）的学习片段与证据保留状态。',
      run: async (rest = '') => {
        const arg = String(rest || '').trim()
        let day = Date.now()
        if (/^\d{4}-\d{2}-\d{2}$/.test(arg)) {
          const t = Date.parse(arg + 'T00:00:00')
          if (Number.isFinite(t)) day = t
        }
        const store = lifecycleStore()
        const payload = buildTimelinePayload({ store, day })
        const st = getProactiveState()
        const text =
          timelineText(payload) +
          (st.intent === PROACTIVE_INTENT && st.nextAllowedAt > Date.now()
            ? `\n（主动询问冷却中：intent=${st.intent}，至 ${new Date(st.nextAllowedAt).toISOString()}）`
            : '')
        return { ok: true, text, ui: payload }
      },
    })

    // ---- /learn：开始/结束学习 ----
    ctx.ui.registerCommand({
      name: 'learn',
      title: '开始/结束学习',
      description: '用法：/learn start｜/learn stop——learning 态学习会话；结束时时长落账（/today 可查）。',
      run: async (rest = '') => {
        const sub = String(rest || '').trim().toLowerCase()
        if (sub !== 'start' && sub !== 'stop') {
          return { ok: false, text: '用法：/learn start｜/learn stop', error: '用法：/learn start｜/learn stop', code: 'E_USAGE' }
        }
        const reg = hostRegistry()
        if (!reg) {
          return { ok: false, text: '宿主 registry 未接入（pack 未激活？）', error: '宿主 registry 未接入（pack 未激活？）', code: 'E_NO_REGISTRY' }
        }
        const consent = loadConsentForCheck()
        // 同意前提：S2 公开 API 判定（抓屏需要 session；不跨重启语义见 PROCESS_STARTED_AT）
        const consentOk = consentActive(consent, { now: Date.now(), processStartedAt: PROCESS_STARTED_AT }) &&
          consent.mode === 'session'

        if (sub === 'start') {
          const cur = readLearningSession()
          if (cur.active) {
            return { ok: true, text: `学习已在进行中（开始于 ${new Date(cur.startedAt).toISOString().slice(11, 19)}）。`, ui: { kind: 'learn', phase: 'already' } }
          }
          if (!consentOk) {
            return {
              ok: false,
              text: '需要重新授权：当前 consent 不是有效 session（已被撤销或过期）。重新授予 session 同意后再开始学习。',
              error: '需要重新授权：当前 consent 不是有效 session（已被撤销或过期）。重新授予 session 同意后再开始学习。',
              code: 'E_CONSENT_REQUIRED',
              ui: { kind: 'learn', phase: 'need-consent' },
            }
          }
          // 切 perception 到 learning：S2 的文档化注入点是 env/argv；重激活插件使其生效。
          process.env.PERCEPTION_STATE = 'learning'
          let perceptionState = 'learning'
          try {
            await reg.disable('perception')
            const en = await reg.enable('perception')
            if (!en || !en.enabled) perceptionState = 'unknown'
          } catch (e) {
            perceptionState = `flip-failed: ${String((e && e.message) || e).slice(0, 80)}`
          }
          // 计时落账：确保「学习」项目存在（按 **id** 判定：timer-store ID_RE 只收 ASCII；
          // 历史上可能存在同名中文 id 项目，按名称判定会误判"已存在"）
          const projList = await runHostCommand('project', 'list')
          if (!/（learn）|\(learn\)|id=learn/.test(cmdText(projList))) {
            await runHostCommand('project', `new ${LEARNING_PROJECT_ID} ${LEARNING_PROJECT_NAME}`)
          }
          const started = await runHostCommand('start', `--project ${LEARNING_PROJECT_ID}`)
          const segId = `seg-${Date.now()}`
          const session = { active: true, startedAt: Date.now(), segmentId: segId, perceptionState }
          writeLearningSession(session)
          appendSegment({
            id: segId, startedAt: session.startedAt, endedAt: null, state: 'learning',
            outcome: 'pending', dwellLabel: '学习会话（进行中）', samples: 0, eventsWritten: 0, evidence: [],
          })
          appendJsonl(AUDIT, { ts: Date.now(), kind: 'learn-start', segmentId: segId, perceptionState, timerOk: cmdOk(started) })
          return {
            ok: true,
            text: `已开始学习：perception 切到 learning 态（${perceptionState}），计时开始（/today 可查）。`,
            ui: { kind: 'learn', phase: 'started', segmentId: segId, perceptionState, timerOk: cmdOk(started) },
          }
        }

        // sub === 'stop'
        const cur = readLearningSession()
        if (!cur.active) {
          return { ok: true, text: '当前没有进行中的学习会话。', ui: { kind: 'learn', phase: 'idle' } }
        }
        const stopped = await runHostCommand('stop', '')
        const endedAt = Date.now()
        const durationMs = endedAt - cur.startedAt
        appendSegment({
          id: cur.segmentId, startedAt: cur.startedAt, endedAt, state: 'learning',
          outcome: 'stopped', dwellLabel: `学习会话（${Math.round(durationMs / 1000)}s）`,
          confidence: computeConfidence({ dwellMs: durationMs, dwellThresholdMs: durationMs, samples: 0, expectedSamples: 1, eventsWritten: 0 }),
          samples: 0, eventsWritten: 0, evidence: [],
        })
        writeLearningSession({ active: false, startedAt: cur.startedAt, endedAt, segmentId: cur.segmentId })
        // perception 回 normal 态（同样走重激活注入点）
        process.env.PERCEPTION_STATE = 'normal'
        try {
          await reg.disable('perception')
          await reg.enable('perception')
        } catch { /* 状态回切失败不影响落账 */ }
        const today = await runHostCommand('today', '')
        appendJsonl(AUDIT, { ts: endedAt, kind: 'learn-stop', segmentId: cur.segmentId, durationMs, timerOk: cmdOk(stopped) })
        return {
          ok: true,
          text: `已结束学习：本次 ${Math.round(durationMs / 1000)}s，时长已落账（/today 可查）。`,
          ui: { kind: 'learn', phase: 'stopped', segmentId: cur.segmentId, durationMs, todayText: cmdOk(today) ? cmdText(today) : null },
        }
      },
    })

    // ---- /panel：面板后端（状态矩阵调试入口 + 主动询问卡 + 首页数据聚合）----
    // S54·D1 改名 'ui' -> 'panel'：coach 插件早已注册 name:'ui'（CU 单步 list/allow/deny/run），
    // registry.runCommand 按注册顺序先命中 coach —— timeline 的整个面板后端（status/drafts/ask/...）
    // 因此全部失联（首页状态条/感知卡/学习按钮/待处理区从未收到过数据，撞名即静默断链）。
    // 面板后端与 CU 单步是两个功能族，'panel' 语义准确且无冲突；不新增 IPC 通道，仍是 plugin:command。
    ctx.ui.registerCommand({
      name: 'panel',
      title: '面板后端（状态/询问/草稿）',
      description: '面板内部命令：status｜drafts｜newdraft｜plans-done <id>｜ask｜help｜home｜state <...>｜sites｜trash｜reject｜promote|discard｜new',
      run: async (rest = '') => {
        const [sub, ...restParts] = String(rest || '').trim().split(/\s+/)
        if (sub === 'state') {
          const name = restParts[0] || ''
          const st = writeUiState(name, 'debug')
          if (!st) {
            return { ok: false, text: `未知状态「${name}」（12 态：${UI_STATES.join(', ')}）`, error: `未知状态「${name}」（12 态：${UI_STATES.join(', ')}）`, code: 'E_BAD_STATE' }
          }
          appendJsonl(AUDIT, { ts: Date.now(), kind: 'ui-state', state: name })
          return { ok: true, text: `UI 状态已切换到：${name}`, ui: { kind: 'state', state: name } }
        }
        if (sub === 'ask') {
          const store = lifecycleStore()
          const cooling = isCooling()
          if (cooling) {
            const st = getProactiveState()
            const remainH = Math.max(0, Math.ceil((st.nextAllowedAt - Date.now()) / 3600000))
            return {
              ok: true,
              text: `冷却中（剩余 ${remainH} 小时）：同一意图 24 小时内不再询问。`,
              ui: { kind: 'ask', phase: 'cooling', remainingMs: st.nextAllowedAt - Date.now(), remainingHours: remainH },
            }
          }
          const evId = `ev-${Date.now()}`
          const windowTitle = ''
          const evPath = writeDwellEvidence({
            id: evId, kind: 'dwell', segmentId: `seg-ask-${Date.now()}`, state: 'learning',
            startedAt: Date.now(), dwellMs: 0, dwellLabel: '调试触发（/ui ask）',
            samples: 0, eventsWritten: 0, windowTitle, note: '调试入口触发',
          })
          const reason = '调试触发（/ui ask）：学习态停留超过阈值'
          const askText = buildAskText({
            evidenceId: evId, reason, dwellLabel: '调试触发', windowTitle,
            disableHow: '点「不用了」→ 24h 同意图冷却；应用内亦可 /perception revoke',
          })
          appendJsonl(AUDIT, { ts: Date.now(), kind: 'ui-ask', evidenceId: evId })
          return { ok: true, text: askText, ui: { kind: 'ask', phase: 'asking', evidenceId: evId, reason, evidencePath: evPath, storeReady: !!store } }
        }
        if (sub === 'help') {
          // 「需要帮助」→ 真抓屏 + 草稿（S1 桥 + S3 store + data/drafts）
          if (!screen || typeof screen.captureScreen !== 'function') {
            return { ok: false, text: '抓屏桥不可用（非 Electron 主进程？）', error: '抓屏桥不可用（非 Electron 主进程？）', code: 'E_NO_SCREEN' }
          }
          const capr = await screen.captureScreen()
          if (!capr || !capr.ok) {
            return { ok: false, text: `抓屏失败：${(capr && capr.reason) || 'unknown'}`, error: `抓屏失败：${(capr && capr.reason) || 'unknown'}`, code: 'E_CAPTURE' }
          }
          const store = lifecycleStore()
          const consent = loadConsentForCheck()
          const consentId = `${(consent && consent.mode) || 'unknown'}@${(consent && consent.grantedAt) || 'demo'}`
          const d = writeDraftFromCapture({ capture: capr, store, consentId, windowTitle: '' })
          appendJsonl(AUDIT, { ts: Date.now(), kind: 'ui-help', evidenceId: d.evidenceId, draft: d.draftPath })
          return {
            ok: true,
            text: `已抓一帧并生成草稿：evidence_id=${d.evidenceId}（保留至 ${d.expiresAt || '（未登记）'}）；草稿在 data/drafts/${d.draftId}.md，等待你确认晋升或丢弃。`,
            ui: { kind: 'ask', phase: 'helped', evidenceId: d.evidenceId, draftPath: d.draftPath, expiresAt: d.expiresAt, capturePath: capr.pngPath, bytes: capr.bytes },
          }
        }
        if (sub === 'home') {
          return { ok: true, text: '已回首页。', ui: { kind: 'page', page: 'home' } }
        }
        if (sub === 'status') {
          // 首页状态条的数据源（一次拿全：感知/学习/草稿/冷却）
          const store = lifecycleStore()
          const reg = hostRegistry()
          let perception = { mode: 'unknown', running: null, state: null }
          let perToday = null
          let budgetDiagData = null // S58·P0-3：预算诊断（ps 在 if 块内，必须提到外层再给 return 用）
          if (reg) {
            const ps = await runHostCommand('perception', 'status')
            if (cmdOk(ps)) {
              const v = (ps && ps.value) || {}
              budgetDiagData = v.budget || null
              const t = String(v.text || '')
              const m = /当前状态：(\S+)/.exec(t)
              const rm = /采集运行：(\S+)/.exec(t)
              const cm = /同意模式：(\S+)/.exec(t)
              perception = {
                state: m ? m[1] : null,
                running: rm ? rm[1] === '是' : null,
                mode: cm ? cm[1] : null,
              }
              // S54·D1：perception status 现随行结构化 today（读 perception.jsonl 审计）
              perToday = v.today || null
            }
          }
          const cur = readLearningSession()
          const drafts = listDirFiles(DRAFTS_DIR)
          const st = getProactiveState()
          const cooling = isCooling()
          // S66·P0-1：待处理卡数据源（计划账只读折叠 + 今日日报文件摘要）
          const plans = pendingPlans()
          const report = readDailyReport()
          // 原图剩余：最近的可用帧的保留倒计时（S3 store 对账）
          let frameRemainingMs = null
          if (store && typeof store.listExpiredReady === 'function') {
            try {
              const nowIso = new Date().toISOString()
              const soonest = (store.listByStatus ? store.listByStatus('ready') : [])
                .filter((r) => r.expires_at && r.expires_at > nowIso)
                .sort((a, b) => (a.expires_at < b.expires_at ? -1 : 1))[0]
              if (soonest) frameRemainingMs = Date.parse(soonest.expires_at) - Date.now()
            } catch { /* 对账失败按未知 */ }
          }
          return {
            ok: true,
            text: '状态已刷新。',
            ui: {
              kind: 'status',
              perception,
              perceptionCard: buildPerceptionCard({ perception, perToday, processStartedAt: PROCESS_STARTED_AT }),
              // S58·P0-3：预算诊断透传（level/metrics/thresholds/fired），诊断页显示用
              budget: budgetDiagData,
              // S60·P0-4：视觉 provider 诊断（zhipu · glm-5.3-flash 就绪/未就绪 + 最近延迟）
              vision: visionDiagnostics(),
              learning: { active: cur.active, startedAt: cur.startedAt, todayMs: todayLearningMs() },
              drafts,
              // S66·P0-1：计划（due=现在要处理 / upcoming=未到期只给摘要）与今日日报摘要
              plans,
              report,
              frameRemainingMs,
              storeReady: !!store,
              cooldown: cooling
                ? { cooling: true, remainingMs: st.nextAllowedAt - Date.now(), remainingHours: Math.max(0, Math.ceil((st.nextAllowedAt - Date.now()) / 3600000)) }
                : { cooling: false },
            },
          }
        }
        if (sub === 'drafts') {
          const drafts = listDirFiles(DRAFTS_DIR)
          return { ok: true, text: `草稿 ${drafts.length} 个：${drafts.join(', ') || '（空）'}`, ui: { kind: 'drafts', drafts } }
        }
        if (sub === 'plans-done') {
          // S66·P0-1：待处理卡「完成」按钮 —— 勾销一条计划。
          // 真源在 coach（plans.done：记忆镜像 + 审计 + 只勾一次）；这里只做面板侧中继——
          // home-v1 只监听 timeline 的 ui 回包，跨插件调用走 registry 公开 API（与 perception status 同路径）。
          const id = String(restParts.join(' ') || '').trim()
          if (!id) return { ok: false, text: '用法：/panel plans-done <计划 id>', error: '用法：/panel plans-done <计划 id>', code: 'E_USAGE' }
          const r = await runHostCommand('coach', 'plans done ' + id)
          const txt = cmdText(r)
          if (!cmdOk(r)) {
            return { ok: false, text: `勾销失败：${txt || '未知原因'}`, ui: { kind: 'plans', action: 'error', id, message: txt || '未知原因' } }
          }
          return { ok: true, text: txt || `计划已勾销：${id}`, ui: { kind: 'plans', action: 'done', id } }
        }
        if (sub === 'newdraft') {
          const draftId = `draft-${Date.now()}`
          const draftPath = join(DRAFTS_DIR, `${draftId}.md`)
          const content = [
            '---',
            `draft_id: ${draftId}`,
            `created_at: ${new Date().toISOString()}`,
            'status: draft',
            '---',
            '',
            '# 新草稿',
            '',
            '（在这里写你的想法；确认后「晋升正式」，不要了「丢弃」。草稿与正式笔记物理隔离。）',
            '',
          ].join('\n')
          safeWrite(draftPath, content)
          appendJsonl(AUDIT, { ts: Date.now(), kind: 'ui-newdraft', draft: draftPath })
          return { ok: true, text: `已建草稿：data/drafts/${draftId}.md`, ui: { kind: 'drafts', action: 'created', draft: `${draftId}.md` } }
        }
        if (sub === 'trash') {
          // 回收区统计（D11-①）：体积/条数 + 例外台账条数 + TTL 配置
          const t = trashStats(dataPath('trash'))
          const cfg = loadLifecycleCfgForPlugin()
          const ttl = Number(cfg && cfg.retention && cfg.retention.trashDays) > 0 ? Number(cfg.retention.trashDays) : 7
          const exc = countExternalCaptures(dataPath())
          const mb = (t.bytes / 1048576).toFixed(2)
          return {
            ok: true,
            text: `回收区：${t.files} 个文件 / ${mb}MB（TTL ${ttl} 天，到期物理删除且不可恢复）；显式例外登记 ${exc} 条。`,
            ui: { kind: 'trash', files: t.files, bytes: t.bytes, ttlDays: ttl, exceptions: exc },
          }
        }
        if (sub === 'sites') {
          // 最近网站：S2/S1 浏览器域的数据目录（data/browser/<host>/*.json）
          const browserDir = dataPath('browser')
          const sites = []
          try {
            if (existsSync(browserDir)) {
              for (const host of readdirSync(browserDir)) {
                const hd = join(browserDir, host)
                if (!existsSync(hd)) continue
                const files = readdirSync(hd).filter((f) => f.endsWith('.json'))
                if (files.length > 0) sites.push({ host, count: files.length })
              }
            }
          } catch { /* 目录不可读按空列表 */ }
          sites.sort((a, b) => b.count - a.count)
          return { ok: true, text: sites.length ? `最近网站：${sites.map((s) => `${s.host}(${s.count})`).join('，')}` : '最近网站：暂无记录。', ui: { kind: 'sites', sites } }
        }
        if (sub === 'promote' || sub === 'discard') {
          const draftName = restParts[0] || ''
          if (!/^[\w.-]+\.md$/.test(draftName)) {
            return { ok: false, text: `用法：/ui ${sub} <draft文件名.md>`, error: 'E_USAGE', code: 'E_USAGE' }
          }
          const src = join(DRAFTS_DIR, draftName)
          if (!existsSync(src)) {
            return { ok: false, text: `草稿不存在：data/drafts/${draftName}`, error: 'E_NOT_FOUND', code: 'E_NOT_FOUND' }
          }
          const content = readFileSync(src)
          const sha = createHash('sha256').update(content).digest('hex')
          if (sub === 'promote') {
            const dest = join(FORMAL_DIR, `note-help-${Date.now()}.md`)
            mkdirSync(FORMAL_DIR, { recursive: true })
            writeFileSync(dest, content)
            const formalSha = createHash('sha256').update(readFileSync(dest)).digest('hex')
            trashFile(src)
            appendJsonl(AUDIT, { ts: Date.now(), kind: 'ui-promote', draft: draftName, note: dest, sha256: formalSha })
            return {
              ok: true,
              text: `已晋升正式笔记：${dest.split('\\').pop()}（sha256 ${formalSha === sha ? '一致' : '不一致'}）。`,
              ui: { kind: 'drafts', action: 'promoted', note: dest, sha256: formalSha, match: formalSha === sha, drafts: listDirFiles(DRAFTS_DIR) },
            }
          }
          trashFile(src)
          appendJsonl(AUDIT, { ts: Date.now(), kind: 'ui-discard', draft: draftName })
          return { ok: true, text: `已丢弃草稿：${draftName}（副本在 data/trash，可恢复）。`, ui: { kind: 'drafts', action: 'discarded', draft: draftName, drafts: listDirFiles(DRAFTS_DIR) } }
        }
        if (sub === 'reject') {
          // 「不用了」→ 24h 同意图冷却（logic.recordRejection 原样调用，语义未改）
          const st = recordRejection()
          appendJsonl(AUDIT, { ts: Date.now(), kind: 'ui-reject', intent: st.intent, nextAllowedAt: st.nextAllowedAt })
          return {
            ok: true,
            text: '已减少此类提醒（24 小时内不再询问）。',
            ui: { kind: 'ask', phase: 'rejected', nextAllowedAt: st.nextAllowedAt },
          }
        }
        return { ok: false, text: '用法：/ui state <name>｜/ui ask｜/ui help｜/ui reject｜/ui home', error: '用法：/ui state <name>｜/ui ask｜/ui help｜/ui reject｜/ui home', code: 'E_USAGE' }
      },
    })

    // ---- /claim：结论发布面板的数据出口（S7，D8/D9）----
    // 发布必须走 S6 的 publish.mjs（数据层闸）；本命令只做"呈现 + 编辑 + 转交"。
    ctx.ui.registerCommand({
      name: 'claim',
      title: '结论发布',
      description: '用法：/claim new seg <片段id>｜/claim new note <文件>｜/claim new text <内容>｜/claim claims｜/claim <id>｜/claim <id> text <新措辞>｜/claim publish <id>',
      run: async (rest = '') => {
        const parts = String(rest || '').trim().split(/\s+/)
        const sub = parts[0] || ''
        const store = lifecycleStore()
        if (!store) {
          return { ok: false, text: '生命周期库未接入（应用未运行 S3.1/S6 接线）：无法发布结论。', error: 'E_NO_STORE', code: 'E_NO_STORE', ui: { kind: 'claim', phase: 'no-store' } }
        }
        if (sub === 'new') {
          const src = parts[1] || ''
          const srcArg = parts.slice(2).join(' ')
          if (!['seg', 'note', 'text', 'frame', 'session'].includes(src) || !srcArg) {
            return { ok: false, text: '用法：/claim new seg <片段id>｜note <文件>｜text <内容>｜frame <raw_frame_id>｜session <会话消息>', error: 'E_USAGE', code: 'E_USAGE' }
          }
          const id = `clm-${Date.now()}`
          let text = ''
          let evidenceMode = 'direct'
          const evidence = []
          if (src === 'seg') {            const seg = readSegments().find((s) => s.id === srcArg)
            if (!seg) return { ok: false, text: `片段不存在：${srcArg}`, error: 'E_NO_SEG', code: 'E_NO_SEG' }
            text = `来自学习片段 ${seg.id}（${seg.dwellLabel || ''}，置信度 ${seg.confidence ?? '-'}）的结论`
            for (const e of seg.evidence || []) {
              if (e.kind === 'frame') evidence.push({ evidence_id: e.evidence_id, layer: 'raw_frame', relation: 'direct', path: e.path })
            }
            if (evidence.length === 0) evidenceMode = 'derived' // 片段在但没有原图证据 → 派生（停留证据），发布仍需至少一条
          } else if (src === 'frame') {
            // 直接引用一帧原图作为证据（发布面板的"从观察建结论"）
            const row = store.getRawFrame(srcArg)
            if (!row) return { ok: false, text: `原图不存在：${srcArg}`, error: 'E_NO_FRAME', code: 'E_NO_FRAME' }
            text = `来自观察证据 ${srcArg} 的结论`
            evidence.push({ evidence_id: srcArg, layer: 'raw_frame', relation: 'direct', sha256: row.sha256 })
          } else if (src === 'note') {
            text = `来自笔记 ${srcArg} 的结论`
            evidenceMode = 'none' // 笔记没有证据链：无直接证据（D9 降级渲染 + 不得发布）
          } else if (src === 'session') {
            // 镜 4：会话消息一键成结论——正文即消息原文（用户可在发布页改措辞）；
            // 会话消息本身没有证据链 → none（当场说明缺什么，不得伪装有证据）。
            text = srcArg.slice(0, 400)
            evidenceMode = 'none'
          } else {
            text = srcArg.slice(0, 400)
            evidenceMode = 'none' // 自由文本：无直接证据
          }
          const c = createClaim(store, { id, kind: src === 'seg' ? 'perception' : src === 'note' ? 'literature' : src === 'session' ? 'session' : 'manual', text, evidenceMode })
          if (!c.ok) return { ok: false, text: `建稿失败：${c.reason || c.code}`, error: c.code, code: c.code }
          for (const e of evidence) {
            let sha = null
            try {
              const row = store.getRawFrame(e.evidence_id)
              if (row) sha = row.sha256
            } catch { /* 哈希缺失不阻塞关联 */ }
            attachEvidence(store, { claimId: id, evidenceId: e.evidence_id, layer: e.layer, relation: e.relation, sha256: sha })
          }
          appendJsonl(AUDIT, { ts: Date.now(), kind: 'claim-created', claimId: id, source: src, evidenceMode, evidenceCount: evidence.length })
          return { ok: true, text: `已建草稿 ${id}（${evidenceMode === 'none' ? '无直接证据' : evidenceMode === 'derived' ? '派生证据' : '直接证据'} ${evidence.length} 条）。`, ui: { kind: 'claim', phase: 'created', claimId: id, evidenceMode, evidenceCount: evidence.length } }
        }
        if (sub === 'claims' || sub === '') {
          const rows = store._db.prepare('SELECT id, kind, text, evidence_mode, status, created_at, published_at FROM claim ORDER BY created_at DESC LIMIT 50').all()
          const list = rows.map((r) => {
            const n = store._db.prepare("SELECT COUNT(*) n FROM claim_evidence WHERE claim_id = ? AND relation <> 'none'").get(r.id).n
            return { id: r.id, kind: r.kind, text: String(r.text || '').slice(0, 60), evidenceMode: r.evidence_mode, status: r.status, publishableEvidence: Number(n), createdAt: r.created_at, publishedAt: r.published_at }
          })
          return { ok: true, text: `结论 ${list.length} 条（草稿 ${list.filter((x) => x.status === 'draft').length}）。`, ui: { kind: 'claims', claims: list } }
        }
        if (sub === 'attach') {
          // 补证据（镜 4："缺证据被拒 → 补证据 → 发布"）：把今日原图/今日片段的证据挂到草稿上
          const id = parts[1] || ''
          const what = parts[2] || ''
          const row = store._db.prepare('SELECT id, status, evidence_mode FROM claim WHERE id = ?').get(id)
          if (!row) return { ok: false, text: `结论不存在：${id}`, error: 'E_NO_CLAIM', code: 'E_NO_CLAIM' }
          if (row.status !== 'draft') return { ok: false, text: '只有草稿能补证据（已发布结论的快照不可变）。', error: 'E_NOT_DRAFT', code: 'E_NOT_DRAFT' }
          const frames = []
          if (what === 'frame') {
            const frameId = parts[3] || (store._db.prepare("SELECT id FROM raw_frame WHERE status = 'ready' ORDER BY created_at DESC LIMIT 1").get() || {}).id
            if (!frameId) {
              return { ok: false, text: '今天没有可关联的原图（先跑一次学习主线，让采集产生 raw_frame）。', error: 'E_NO_FRAME', code: 'E_NO_FRAME', ui: { kind: 'claim', phase: 'blocked', claimId: id, code: 'E_NO_FRAME', reason: '今天没有可关联的原图' } }
            }
            frames.push(frameId)
          } else if (what === 'latest-seg') {
            const seg = readSegments().slice(-1)[0]
            if (!seg) {
              return { ok: false, text: '今天还没有学习片段（先跑一次学习主线）。', error: 'E_NO_SEG', code: 'E_NO_SEG', ui: { kind: 'claim', phase: 'blocked', claimId: id, code: 'E_NO_SEG', reason: '今天还没有学习片段' } }
            }
            for (const e of seg.evidence || []) if (e.kind === 'frame') frames.push(e.evidence_id)
            if (frames.length === 0) {
              return { ok: false, text: `片段 ${seg.id} 没有原图证据（只有停留证据）——换「关联今日原图」。`, error: 'E_NO_FRAME', code: 'E_NO_FRAME', ui: { kind: 'claim', phase: 'blocked', claimId: id, code: 'E_NO_FRAME', reason: `片段 ${seg.id} 没有原图证据` } }
            }
          } else {
            return { ok: false, text: '用法：/claim attach <id> frame [raw_frame_id]｜latest-seg', error: 'E_USAGE', code: 'E_USAGE' }
          }
          let attached = 0
          for (const fid of frames) {
            const fr = store.getRawFrame(fid)
            if (!fr) continue
            const dup = store._db.prepare('SELECT COUNT(*) n FROM claim_evidence WHERE claim_id = ? AND evidence_id = ?').get(id, fid).n
            if (dup > 0) continue
            const r = attachEvidence(store, { claimId: id, evidenceId: fid, layer: 'raw_frame', relation: 'direct', sha256: fr.sha256 })
            if (r.ok) attached += 1
          }
          // 挂上非 none 证据后升级 evidence_mode：结论不再"无直接证据"（§6 语义：none 指无直接证据）。
          // 直接改发布闸的判定口径（与 publishClaim 的 evidence_mode≠none 一致），让"补证据→可发布"成立。
          if (attached > 0) {
            const modes = store._db.prepare("SELECT relation FROM claim_evidence WHERE claim_id = ? AND relation <> 'none'").all(id).map((r) => r.relation)
            const next = modes.includes('direct') ? 'direct' : modes.includes('derived') ? 'derived' : 'none'
            store._db.prepare('UPDATE claim SET evidence_mode = ? WHERE id = ?').run(next, id)
          }
          appendJsonl(AUDIT, { ts: Date.now(), kind: 'claim-evidence-attached', claimId: id, what, attached, frames: frames.length })
          return {
            ok: true,
            text: attached > 0 ? `已关联 ${attached} 条原图证据（现在可以发布了）。` : '这些证据都已关联过（无需重复）。',
            ui: { kind: 'claim', phase: 'attached', claimId: id, attached },
          }
        }
        if (sub === 'export') {
          // 镜 4：导出已发布结论（md + docx，复用文献插件既有 docx 能力，不新增依赖）
          const id = parts[1] || ''
          const built = buildClaimExport(store, id, { version: `s10/${TIMELINE_VERSION}` })
          if (!built.ok) {
            return { ok: false, text: `导出被拒：${built.reason || built.code}`, error: built.code, code: built.code }
          }
          const exportsDir = dataPath('exports')
          mkdirSync(exportsDir, { recursive: true })
          const stem = `claim-${id}-${Date.now()}`
          const mdPath = join(exportsDir, `${stem}.md`)
          safeWrite(mdPath, built.markdown)
          // docx：复用 research-literature/lib/docx-export 既有能力（懒加载 docx + markdownToParagraphs）
          let docxPath = null
          let docxError = null
          try {
            const { buildDocxFromMarkdown } = await import('../research-literature/lib/docx-export.mjs')
            const { buffer } = await buildDocxFromMarkdown(`结论导出 · ${id}`, built.markdown)
            docxPath = join(exportsDir, `${stem}.docx`)
            writeFileSync(docxPath, buffer)
          } catch (e) {
            docxError = String((e && e.message) || e)
          }
          appendJsonl(AUDIT, { ts: Date.now(), kind: 'claim-exported', claimId: id, md: mdPath, docx: docxPath, evidence: built.evidence.length, degraded: built.degraded })
          const mdSha = createHash('sha256').update(readFileSync(mdPath)).digest('hex')
          const docxSha = docxPath ? createHash('sha256').update(readFileSync(docxPath)).digest('hex') : null
          return {
            ok: true,
            text: `已导出：${mdPath.split('\\').pop()}${docxPath ? ' + ' + docxPath.split('\\').pop() : '（docx 失败：' + docxError + '）'}（证据 ${built.evidence.length} 条${built.degraded ? '，含已删降级 ' + built.degraded + ' 条' : ''}）`,
            ui: { kind: 'claim-export', claimId: id, md: mdPath, docx: docxPath, mdSha256: mdSha, docxSha256: docxSha, evidence: built.evidence.length, degraded: built.degraded, label: built.label, docxError },
          }
        }
        if (sub === 'publish') {
          const id = parts[1] || ''
          const before = store._db.prepare('SELECT status, evidence_mode FROM claim WHERE id = ?').get(id)
          if (!before) return { ok: false, text: `结论不存在：${id}`, error: 'E_NO_CLAIM', code: 'E_NO_CLAIM' }
          const r = publishClaim(store, id)
          const after = store._db.prepare('SELECT status, published_at FROM claim WHERE id = ?').get(id)
          appendJsonl(AUDIT, { ts: Date.now(), kind: 'claim-publish-attempt', claimId: id, ok: r.ok, code: r.code || null })
          if (r.ok) {
            return { ok: true, text: `已发布：${id}（证据 ${r.evidenceCount} 条）。`, ui: { kind: 'claim', phase: 'published', claimId: id, evidenceCount: r.evidenceCount, publishedAt: after.published_at } }
          }
          const missing = r.code === 'E_NONE_EVIDENCE'
            ? '该结论 evidence_mode=none（无直接证据）：契约 §6 禁止以事实语气发布，请补直接/派生证据或改写为假设语气。'
            : r.code === 'CLAIM_EVIDENCE_REQUIRED'
              ? `缺证据：还没有关联任何可直接回指的证据（非 none 证据 ${r.evidenceCount ?? 0} 条）。请先从轨迹片段/原图关联证据，再发布。`
              : `发布被拒：${r.reason || r.code}`
          return { ok: false, text: missing, error: missing, code: r.code, ui: { kind: 'claim', phase: 'blocked', claimId: id, code: r.code, reason: missing, evidenceCount: r.evidenceCount ?? 0 } }
        }
        // /claim <id> [text <新措辞>]：详情 / 编辑
        const id = sub
        const row = store._db.prepare('SELECT id, kind, text, evidence_mode, status, created_at, published_at FROM claim WHERE id = ?').get(id)
        if (!row) return { ok: false, text: `结论不存在：${id}`, error: 'E_NO_CLAIM', code: 'E_NO_CLAIM' }
        if (parts[1] === 'text') {
          if (row.status !== 'draft') return { ok: false, text: '已发布的结论不可改措辞（保持发布时的事实快照）。', error: 'E_PUBLISHED_IMMUTABLE', code: 'E_PUBLISHED_IMMUTABLE' }
          const newText = parts.slice(2).join(' ').trim()
          if (!newText) return { ok: false, text: '用法：/claim <id> text <新措辞>', error: 'E_USAGE', code: 'E_USAGE' }
          store._db.prepare('UPDATE claim SET text = ? WHERE id = ?').run(newText.slice(0, 2000), id)
          appendJsonl(AUDIT, { ts: Date.now(), kind: 'claim-edited', claimId: id })
          row.text = newText.slice(0, 2000)
        }
        const links = store._db.prepare('SELECT evidence_id, layer, relation, sha256 FROM claim_evidence WHERE claim_id = ? ORDER BY id').all(id)
        const evidence = links.map((l) => {
          const r0 = resolveEvidence(store, l.evidence_id, l.layer)
          return { evidence_id: l.evidence_id, layer: l.layer, relation: l.relation, sha256: l.sha256 || r0.sha256 || null, status: r0.status, label: r0.label }
        })
        const n = links.filter((l) => l.relation !== 'none').length
        return {
          ok: true,
          text: `${id} [${row.status}] ${row.evidence_mode}｜证据 ${links.length} 条（可发布 ${n}）`,
          ui: {
            kind: 'claim-detail', claimId: id, kindOf: row.kind, text: row.text, evidenceMode: row.evidence_mode,
            status: row.status, createdAt: row.created_at, publishedAt: row.published_at,
            publishableEvidence: n, canPublish: row.status === 'draft' && row.evidence_mode !== 'none' && n > 0,
            evidence,
          },
        }
      },
    })
  }

  log.info('[timeline] 轨迹插件已激活（/timeline /learn /ui）')

  return {
    deactivate() {
      log.info('[timeline] 已停用')
    },
  }
}

/** 读 data/lifecycle-config.json（回收区 TTL 等；只读）。 */
function loadLifecycleCfgForPlugin() {
  try {
    const p = dataPath('lifecycle-config.json')
    if (existsSync(p)) return JSON.parse(readFileSync(p, 'utf8'))
  } catch { /* 按默认 */ }
  return null
}

/** 读 perception 配置里的 consent 段（同意判定的输入；只读，不改）。 */
function loadConsentForCheck() {
  try {
    const p = dataPath('perception-config.json')
    if (existsSync(p)) {
      const c = JSON.parse(readFileSync(p, 'utf8'))
      return c.consent || { mode: 'denied' }
    }
  } catch { /* 按未同意处理 */ }
  return { mode: 'denied' }
}

export default { activate, TIMELINE_VERSION }
