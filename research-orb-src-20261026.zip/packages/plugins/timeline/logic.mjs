// packages/plugins/timeline/logic.mjs
//
// S4 学习主线 · 共享逻辑（纯函数 + 落盘助手，不依赖 electron）。
//
// 被两方复用：
//   · packages/plugins/timeline/index.mjs（应用内 /timeline 命令 → 轨迹页数据）
//   · tools/demo-script.mjs（headless 演示主线）
//
// 数据落点（全部项目根内）：
//   data/timeline/segments-<YYYYMMDD>.jsonl   轨迹片段（append，同 id 后行覆盖前行）
//   data/timeline/evidence/ev-*.json          停留证据（ask 时生成）
//   data/timeline/proactive-state.json        主动询问冷却（同意图 24h 退让）
//   data/timeline/learning-session.json       学习会话（开始/结束学习，S5）
//   data/timeline/ui-state.json               UI 状态矩阵的调试态（S5）
//   data/drafts/draft-*.md                    草稿（绝不直接进正式笔记）
//   data/notes/                               正式笔记（S1 note/fs 工具的正式区）
//
// 诚实性纪律：本模块只做记录与计算，绝不生成"成功"字样；置信度是真实测量值的加权。
// S5 纪律：本文件**只新增**函数与别名导出，不改既有冷却语义（isCooling/recordRejection 原样）。

import { existsSync, mkdirSync, readFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'

import { appendJsonl, safeWrite, PROJECT_ROOT, dataPath } from '../../core/src/safefs.mjs'
import { computeExpiry, DEFAULT_LIFECYCLE_CONFIG } from '../../core/src/db.mjs'
// S66·P0-1：首页「待处理」卡的两个只读数据源。写方都只有 coach
// （plans.jsonl 事件流 / daily-YYYYMMDD.md）——本模块只读，不重跑日报轮。
// 复用 coach 的 foldPlans 纯函数与 DAILY_DIR 常量（单一事实源，不复制折叠逻辑）。
import { foldPlans } from '../coach/plans.mjs'
import { DAILY_DIR } from '../coach/daily.mjs'

export const TIMELINE_DIR = dataPath('timeline')
export const EVIDENCE_DIR = join(TIMELINE_DIR, 'evidence')
export const DRAFTS_DIR = dataPath('drafts')
export const FORMAL_DIR = dataPath('notes')
export const PROACTIVE_STATE_PATH = join(TIMELINE_DIR, 'proactive-state.json')
export const LEARNING_SESSION_PATH = join(TIMELINE_DIR, 'learning-session.json')
export const UI_STATE_PATH = join(TIMELINE_DIR, 'ui-state.json')
export const PERCEPTION_DIR = dataPath('perception')

/** S5 UI 状态矩阵（12 态；调试入口 /ui state <name> 可确定性切到任一态）。 */
export const UI_STATES = Object.freeze([
  'default', 'monitoring', 'paused', 'no-consent', 'learning-candidate', 'learning',
  'silent', 'needs-confirm', 'success', 'failure', 'offline', 'deleted',
])

/** 主动询问的意图 id（同意图冷却 24h）。 */
export const PROACTIVE_INTENT = 'learning-help'
export const PROACTIVE_COOLDOWN_MS = 24 * 60 * 60 * 1000

/** 真实时长口径：learning 停留阈值（演示用 --dwell 压缩，文档必须声明）。 */
export const REAL_DWELL_MINUTES = 10

function dayStamp(ts) {
  const d = new Date(ts)
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}`
}

export function segmentPath(ts) {
  return join(TIMELINE_DIR, `segments-${dayStamp(ts)}.jsonl`)
}

/** 追加一条片段记录（同 id 多行时读方取最后一行）。 */
export function appendSegment(seg) {
  return appendJsonl(segmentPath(seg.startedAt ?? Date.now()), seg)
}

/** 读某天的片段（latest-wins：同 id 取最后一条）。 */
export function readSegments(ts = Date.now()) {
  const p = segmentPath(ts)
  if (!existsSync(p)) return []
  const byId = new Map()
  for (const line of readFileSync(p, 'utf8').split('\n')) {
    const s = line.trim()
    if (!s) continue
    try {
      const row = JSON.parse(s)
      if (row && row.id) byId.set(row.id, row)
    } catch { /* 半行跳过 */ }
  }
  return [...byId.values()].sort((a, b) => (a.startedAt ?? 0) - (b.startedAt ?? 0))
}

// ---------------------------------------------------------------------------
// 冷却（判据 C：被拒后同一意图 24h 内不再弹）
// ---------------------------------------------------------------------------

export function getProactiveState() {
  try {
    if (existsSync(PROACTIVE_STATE_PATH)) return JSON.parse(readFileSync(PROACTIVE_STATE_PATH, 'utf8'))
  } catch { /* 损坏按无冷却 */ }
  return { intent: null, lastRejectedAt: null, nextAllowedAt: 0 }
}

export function isCooling(now = Date.now()) {
  const st = getProactiveState()
  return st.intent === PROACTIVE_INTENT && typeof st.nextAllowedAt === 'number' && now < st.nextAllowedAt
}

/** 记录一次拒绝 → 同意图 24h 冷却。 */
export function recordRejection(now = Date.now()) {
  const st = {
    intent: PROACTIVE_INTENT,
    lastRejectedAt: now,
    nextAllowedAt: now + PROACTIVE_COOLDOWN_MS,
    policy: '同意图 24h 内不再主动询问（后悔退让）',
  }
  safeWrite(PROACTIVE_STATE_PATH, JSON.stringify(st, null, 2))
  return st
}

// ---------------------------------------------------------------------------
// 停留证据 / 主动询问文案（判据 C：提示必须带 evidence_id + reason + 如何关闭）
// ---------------------------------------------------------------------------

export function writeDwellEvidence(ev) {
  mkdirSync(EVIDENCE_DIR, { recursive: true })
  const path = join(EVIDENCE_DIR, `${ev.id}.json`)
  safeWrite(path, JSON.stringify(ev, null, 2))
  return path
}

/** 主动询问文案。disableHow 由调用方按运行环境给（面板 = /perception revoke；演示 = --answer reject）。 */
export function buildAskText({ evidenceId, reason, dwellLabel, windowTitle, disableHow }) {
  return [
    '需要帮助吗？',
    `· 为什么现在提示：${reason}（当前停留 ${dwellLabel}）`,
    `· 用了哪些证据：evidence_id=${evidenceId}${windowTitle ? `（前台窗口「${windowTitle}」的 1Hz 廉价信号）` : ''}`,
    `· 如何关闭：${disableHow}`,
  ].join('\n')
}

// ---------------------------------------------------------------------------
// 置信度（全部来自真实测量；口径见 docs/DEMO.md）
// ---------------------------------------------------------------------------

/**
 * confidence = 0.5×min(1, dwell/阈值) + 0.3×min(1, samples/期望样本数) + 0.2×(有事件落盘 ? 1 : 0)
 * @returns {number} 0~1，两位小数
 */
export function computeConfidence({ dwellMs, dwellThresholdMs, samples, expectedSamples, eventsWritten }) {
  const c =
    0.5 * Math.min(1, dwellMs / Math.max(1, dwellThresholdMs)) +
    0.3 * Math.min(1, samples / Math.max(1, expectedSamples)) +
    0.2 * (eventsWritten > 0 ? 1 : 0)
  return Math.round(Math.min(1, Math.max(0, c)) * 100) / 100
}

// ---------------------------------------------------------------------------
// 草稿
// ---------------------------------------------------------------------------

export function draftMarkdown({ draftId, segmentId, evidenceId, windowTitle, dwellLabel, confidence, samples, eventsWritten, capturePath, captureSha256, capturedAt }) {
  return [
    '---',
    `draft_id: ${draftId}`,
    `segment_id: ${segmentId}`,
    `evidence_id: ${evidenceId}`,
    `captured_at: ${capturedAt}`,
    `confidence: ${confidence}`,
    'status: draft',
    '---',
    '',
    `# 学习片段草稿（${segmentId}）`,
    '',
    `- 前台窗口：${windowTitle || '（未知）'}`,
    `- 停留时长：${dwellLabel}`,
    `- 1Hz 样本：${samples} 条；事件落盘：${eventsWritten} 条`,
    `- 原图证据：evidence_id=${evidenceId}（${capturePath}）`,
    `- 原图 sha256：${captureSha256}`,
    '',
    '（草稿由学习主线自动生成：只记录可复核的事实，不做任何结论性推断。）',
    '',
  ].join('\n')
}

// ---------------------------------------------------------------------------
// 轨迹页数据（应用内 /timeline 命令与演示脚本共用同一实现）
// ---------------------------------------------------------------------------

/** 证据状态：与 S3 raw_frame 对账。deleted → 必须显示"原图已按保留策略删除"。 */
export function evidenceStatus(store, evidenceId, now = Date.now()) {
  let row = null
  try {
    row = store && typeof store.getRawFrame === 'function' ? store.getRawFrame(evidenceId) : null
  } catch { row = null }
  if (!row) return { status: 'unregistered', label: '未登记到生命周期库', remainingMs: null }
  if (row.status === 'deleted') return { status: 'deleted', label: '原图已按保留策略删除', remainingMs: 0 }
  const alive = row.file_path && existsSync(row.file_path)
  if (row.status === 'error') return { status: 'error', label: `清理失败（保留待排查）`, remainingMs: 0, file_path: row.file_path }
  if (!alive) return { status: 'missing', label: '原图文件缺失（已移入回收站或被移动）', remainingMs: 0, file_path: row.file_path }
  const remainingMs = row.expires_at ? Date.parse(row.expires_at) - now : null
  return {
    status: 'available',
    label: `原图在盘（保留倒计时 ${remainingMs != null ? Math.max(0, Math.round(remainingMs / 60000)) + ' 分钟' : '未知'}）`,
    remainingMs,
    file_path: row.file_path,
  }
}

/**
 * 组装轨迹页 payload（/timeline 命令的 ui 与演示脚本的 --timeline 输出同源）。
 * @param {{store?: object, day?: number}} opts store 为 S3 createStore 返回值（可 null → degraded）
 */
export function buildTimelinePayload({ store = null, day = Date.now() } = {}) {
  const now = Date.now()
  const segments = readSegments(day).map((seg) => {
    const evidence = (seg.evidence || []).map((e) => {
      if ((e.kind || 'frame') !== 'frame') {
        return { evidence_id: e.evidence_id, kind: e.kind, status: 'dwell', label: '停留证据（1Hz 廉价信号，非原图）', remainingMs: null }
      }
      return { evidence_id: e.evidence_id, kind: e.kind, ...evidenceStatus(store, e.evidence_id, now) }
    })
    // 第三级：片段时间窗内的感知事件（S2 events-*.jsonl 真实行）
    let events = []
    if (seg.startedAt && seg.endedAt) {
      try {
        events = eventsInWindow(day, seg.startedAt, seg.endedAt).slice(-20).map((e) => ({
          ts: e.ts, type: e.type || null, title: e.title ? String(e.title).slice(0, 60) : null,
        }))
      } catch { events = [] }
    }
    return {
      id: seg.id,
      startedAt: seg.startedAt,
      endedAt: seg.endedAt ?? null,
      durationMs: seg.endedAt && seg.startedAt ? seg.endedAt - seg.startedAt : null,
      state: seg.state || 'learning',
      confidence: seg.confidence ?? null,
      dwellLabel: seg.dwellLabel || null,
      evidenceCount: evidence.length,
      evidence,
      eventCount: events.length,
      events,
      outcome: seg.outcome || 'pending',
      draftPath: seg.draftPath || null,
      notePath: seg.notePath || null,
    }
  })
  return {
    kind: 'timeline',
    day: dayStamp(day),
    generatedAt: new Date(now).toISOString(),
    degraded: !store,
    segments,
  }
}

/** 轨迹的人类可读摘要（/timeline 命令的 text）。 */
export function timelineText(payload) {
  if (!payload.segments.length) return `轨迹（${payload.day}）：今天还没有片段。`
  const lines = [`轨迹（${payload.day}）：${payload.segments.length} 个片段`]
  for (const s of payload.segments) {
    const t = s.startedAt ? new Date(s.startedAt).toISOString().slice(11, 19) : '--:--:--'
    const dur = s.durationMs != null ? Math.round(s.durationMs / 1000) + 's' : '进行中'
    lines.push(
      `· ${t} [${s.outcome}] ${dur} 置信度=${s.confidence ?? '-'} 证据=${s.evidenceCount}` +
        (s.evidence.length ? `（${s.evidence.map((e) => `${e.evidence_id}:${e.label}`).join('；')}）` : ''),
    )
  }
  if (payload.degraded) lines.push('（lifecycle store 未接入：证据保留状态无法对账）')
  return lines.join('\n')
}

/** 列目录文件（判据 D 的两目录清单用）。 */
export function listDirFiles(dir) {
  if (!existsSync(dir)) return []
  return readdirSync(dir).filter((n) => !n.startsWith('.')).sort()
}

// ---------------------------------------------------------------------------
// S5 新增：别名导出（不改冷却语义，只是给 S5 任务书的名字）
// ---------------------------------------------------------------------------

/** 同 isCooling（冷却中 = 抑制询问）。 */
export const isSuppressed = isCooling
/** 同 recordRejection（记一次婉拒 → 24h 同意图冷却）。 */
export const rejectProactive = recordRejection

// ---------------------------------------------------------------------------
// S5 新增：学习会话（开始/结束学习）
// ---------------------------------------------------------------------------

/** 读当前学习会话（无 → {active:false}）。 */
export function readLearningSession() {
  try {
    if (existsSync(LEARNING_SESSION_PATH)) return JSON.parse(readFileSync(LEARNING_SESSION_PATH, 'utf8'))
  } catch { /* 损坏按未开始 */ }
  return { active: false, startedAt: null, segmentId: null }
}

export function writeLearningSession(s) {
  safeWrite(LEARNING_SESSION_PATH, JSON.stringify(s, null, 2))
  return s
}

/** 今日学习时长（毫秒）：进行中的会话算到现在；已结束的按 endedAt-startedAt。 */
export function todayLearningMs(now = Date.now()) {
  const startOfDay = new Date(now)
  startOfDay.setHours(0, 0, 0, 0)
  let total = 0
  for (const seg of readSegments(now)) {
    if (seg.state !== 'learning' || !seg.startedAt) continue
    if (seg.startedAt < startOfDay.getTime()) continue
    const end = seg.endedAt ?? (seg.outcome === 'pending' ? now : seg.endedAt)
    if (end) total += Math.max(0, end - seg.startedAt)
  }
  const cur = readLearningSession()
  if (cur.active && cur.startedAt && cur.startedAt >= startOfDay.getTime()) {
    total += Math.max(0, now - cur.startedAt)
  }
  return total
}

// ---------------------------------------------------------------------------
// S5 新增：UI 状态矩阵（调试态，确定性触发用）
// ---------------------------------------------------------------------------

export function readUiState() {
  try {
    if (existsSync(UI_STATE_PATH)) return JSON.parse(readFileSync(UI_STATE_PATH, 'utf8'))
  } catch { /* 损坏按默认 */ }
  return { state: 'default', forced: false, reason: null, at: null }
}

/** 设置调试态（校验 12 态白名单；unknown → 拒绝，返回 null）。 */
export function writeUiState(name, reason = 'debug') {
  if (!UI_STATES.includes(name)) return null
  const st = { state: name, forced: true, reason, at: Date.now() }
  safeWrite(UI_STATE_PATH, JSON.stringify(st, null, 2))
  return st
}

// ---------------------------------------------------------------------------
// S5 新增：片段事件（轨迹页第三级：读 S2 的 events-*.jsonl，按片段窗口过滤）
// ---------------------------------------------------------------------------

/** 读某天的感知事件（S2 events-<ymd>.jsonl 原文行）。 */
export function readPerceptionEvents(day = Date.now()) {
  const p = join(PERCEPTION_DIR, `events-${dayStamp(day)}.jsonl`)
  if (!existsSync(p)) return []
  const out = []
  for (const line of readFileSync(p, 'utf8').split('\n')) {
    const s = line.trim()
    if (!s) continue
    try {
      const j = JSON.parse(s)
      out.push(j)
    } catch { /* 半行跳过 */ }
  }
  return out
}

/** 片段时间窗内的感知事件（第三级轨迹）。 */
export function eventsInWindow(day, startedAt, endedAt) {
  const from = Math.min(startedAt, endedAt)
  const to = Math.max(startedAt, endedAt)
  return readPerceptionEvents(day).filter((e) => {
    const ts = typeof e.ts === 'number' ? e.ts : Date.parse(e.ts || '')
    return Number.isFinite(ts) && ts >= from && ts <= to
  })
}

// ---------------------------------------------------------------------------
// S5 新增：从一次抓屏直接产草稿（应用内「需要帮助」流程；与 S4 口径一致）
// ---------------------------------------------------------------------------

/**
 * @param {{capture:{ok:true,path?:string,pngPath?:string,bytes?:number,hash?:string,width?:number,height?:number}, store?:object, consentId?:string, windowTitle?:string, mode?:string}} input
 * @returns {{draftId, draftPath, evidenceId, expiresAt, bytes}}
 */
export function writeDraftFromCapture({ capture, store = null, consentId = 'unknown@demo', windowTitle = '', mode = 'learning' }) {
  const pngPath = capture.path || capture.pngPath
  const sha = capture.hash
  const capturedAt = new Date().toISOString()
  const evidenceId = `rf-help-${Date.now()}`
  let expiresAt = null
  if (store && typeof store.insertRawFrame === 'function') {
    const row = store.insertRawFrame({
      id: evidenceId, file_path: pngPath, sha256: sha, sensitivity: 'normal',
      created_at: capturedAt,
      expires_at: computeExpiry('normal', mode, DEFAULT_LIFECYCLE_CONFIG, Date.parse(capturedAt)),
    })
    expiresAt = row.expires_at
    if (typeof store.insertAuditEvent === 'function') {
      store.insertAuditEvent({
        ts: capturedAt, kind: 'frame-registered',
        metadata: { id: evidenceId, file_path: pngPath, sha256: sha, mode, consent_id: consentId, origin: 'help-flow', trace_id: `trc-${Date.now()}` },
      })
    }
  }
  const draftId = `draft-${Date.now()}`
  const draftPath = join(DRAFTS_DIR, `${draftId}.md`)
  const content = draftMarkdown({
    draftId, segmentId: `seg-help-${Date.now()}`, evidenceId, windowTitle,
    dwellLabel: '用户主动求助（/ui ask → 需要帮助）', confidence: null,
    samples: 0, eventsWritten: 0, capturePath: pngPath, captureSha256: sha, capturedAt,
  })
  safeWrite(draftPath, content)
  return { draftId, draftPath, evidenceId, expiresAt, bytes: Buffer.byteLength(content) }
}

// ---------------------------------------------------------------------------
// S66·P0-1 新增：计划账 + 今日日报只读出口（首页「待处理」卡数据源）
// ---------------------------------------------------------------------------

const PLANS_PATH = join(dataPath('coach'), 'plans.jsonl')

/** 读计划账（事件流折叠为每计划最新态；坏行跳过，文件缺失/损坏 → []）。 */
export function readPlans() {
  try {
    if (!existsSync(PLANS_PATH)) return []
    const rows = readFileSync(PLANS_PATH, 'utf8').split('\n').filter((l) => l.trim())
      .map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
    return [...foldPlans(rows).values()]
  } catch { return [] }
}

/**
 * 待处理计划分组（「待处理」卡口径：只催"现在要处理的"，未到期的只给摘要）：
 *   due      = 未完成且（已到期 或 未设到期）→ 卡片出行动行（带「完成」按钮）
 *   upcoming = 未完成且未到期 → 摘要一行（N 条 + 最近到期时间），不占行动区
 * @returns {{due:Array<{id,text,dueAt}>, upcoming:Array, pendingCount:number, nextDueAt:string|null}}
 */
export function pendingPlans(now = Date.now()) {
  const due = [], upcoming = []
  for (const p of readPlans()) {
    if (!p || p.status !== 'pending') continue
    const t = p.dueAt ? Date.parse(p.dueAt) : NaN
    if (!Number.isFinite(t) || t <= now) due.push({ id: p.id, text: p.text, dueAt: p.dueAt || null })
    else upcoming.push({ id: p.id, text: p.text, dueAt: p.dueAt || null })
  }
  const byDue = (a, b) => (Date.parse(a.dueAt || 0) - Date.parse(b.dueAt || 0))
  due.sort(byDue)
  upcoming.sort(byDue)
  return {
    due, upcoming,
    pendingCount: due.length + upcoming.length,
    nextDueAt: upcoming.length ? upcoming[0].dueAt : null,
  }
}

/**
 * 今日日报摘要（「看日报」按钮数据源；只读文件，不重跑日报轮；没有 → exists:false）。
 * 解析口径与 daily.mjs 的日报正文一致：评分行 / 当日累计行 / 「## 明日建议」段。
 */
export function readDailyReport(now = Date.now()) {
  const day = dayStamp(now)
  const file = join(DAILY_DIR, `daily-${day}.md`)
  const out = { exists: false, date: day, score: null, trajectoryTotal: null, advice: [] }
  try {
    if (!existsSync(file)) return out
    const text = readFileSync(file, 'utf8')
    out.exists = true
    const sm = /- 评分：\s*([^\n（(]+)/.exec(text)
    if (sm) out.score = sm[1].trim()
    const tm = /当日累计\s*(\d+)/.exec(text)
    if (tm) out.trajectoryTotal = Number(tm[1])
    const am = /## 明日建议\s*\n([\s\S]*?)(?:\n\s*\n|$)/.exec(text)
    if (am) {
      out.advice = am[1].split('\n').map((l) => l.replace(/^\s*\d+[.、]\s*/, '').trim()).filter(Boolean).slice(0, 3)
    }
  } catch { /* 读不出按不存在（不装数据） */ }
  return out
}
