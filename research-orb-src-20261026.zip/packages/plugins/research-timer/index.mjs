// packages/plugins/research-timer/index.mjs
//
// 计时与进度收纳插件：番茄钟 + 项目/阶段 + 日报周报（阶段 3）。
//
// 契约要点（与文献插件同一套纪律）：
//   · activate() 零副作用：不发请求、不写数据文件、不 setInterval；
//   · 所有落盘都经 core 引擎（timer / progress，内部走 safefs → writes.jsonl），
//     本插件【不 import node:fs、不读 process.env】—— 可直接 grep 验证；
//   · 计时引擎由宿主装配（core-host.mjs 创建后经 ctx.timer / ctx.progress 注入），
//     主进程的秒级节拍、空闲探测、通知也由主进程驱动（见 apps/desktop/main.mjs）；
//     插件禁用不影响已开始的计时收尾 —— 账本在 core，不在插件里。
//   · 面板只是渲染器：所有动作原路返回命令层（/start /pause /today …），
//     面板不直接改任何文件。

import { PROJECT_ROOT } from '../../core/src/safefs.mjs'
import { createProgress } from '../../core/src/progress.mjs'
import { buildDailyReport, buildWeeklyReport, fmtDuration } from '../../core/src/report.mjs'
import { createTimer, POMODORO_PRESETS } from '../../core/src/timer.mjs'
import { createDefaultStore, dayKeyOf, weekMondayOf } from '../../core/src/timer-store.mjs'

import { collectChat } from './lib/llm.mjs'
import { APP_VERSION } from '../../core/src/version.mjs'

export const PLUGIN_ID = 'research-timer'
export const TIMER_VERSION = APP_VERSION
export const CARD_ID = 'research.timer'

export const DEFAULTS = Object.freeze({
  minutes: 25,
  model: 'deepseek-chat',
})

/** 显式 id 形态（与 timer-store 的 ID_RE 同规格）：/project new <id> <名称> 的判别用。 */
const ID_LIKE = /^[a-z0-9][a-z0-9._-]{1,63}$/i

/** 剥掉 `--key value` / `--flag`，剩下的当正文（与文献插件同一口径）。 */
export function splitFlags(rest) {
  const tokens = String(rest || '').trim().split(/\s+/).filter(Boolean)
  const flags = {}
  const keep = []
  for (let i = 0; i < tokens.length; i += 1) {
    const t = tokens[i]
    if (t.startsWith('--') && t.length > 2) {
      const key = t.slice(2).toLowerCase()
      const next = tokens[i + 1]
      if (next !== undefined && !next.startsWith('--')) {
        flags[key] = next
        i += 1
      } else {
        flags[key] = true
      }
      continue
    }
    keep.push(t)
  }
  return { text: keep.join(' ').trim(), flags }
}

/** 绝对路径 -> 项目内相对路径（报表/面板只出现相对路径）。 */
function relOf(abs) {
  return String(abs || '')
    .replace(/\\/g, '/')
    .replace(new RegExp(`^${PROJECT_ROOT.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}/`), '')
}

/** mm:ss（>1 小时显示 h:mm:ss）。 */
export function fmtClock(sec) {
  const s = Math.max(0, Math.round(Number(sec) || 0))
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const r = s % 60
  const p = (n) => String(n).padStart(2, '0')
  return h > 0 ? `${h}:${p(m)}:${p(r)}` : `${p(m)}:${p(r)}`
}

// ---------------------------------------------------------------------------
// 引擎（scope 可注入，便于单测用内存 store / 假引擎）
// ---------------------------------------------------------------------------

/**
 * @param {object} ctx 插件上下文
 * @param {{store?: object, timer?: object, progress?: object, now?: () => number}} [options]
 */
export function createEngine(ctx, options = {}) {
  const store = options.store || createDefaultStore()
  const now = options.now || (() => Date.now())
  // 引擎优先用宿主装配好的实例（ctx.timer / ctx.progress，由 core-host 创建并注入）——
  // 这样主进程的秒级节拍与插件的命令操作的是【同一个】引擎，不会出现两本账。
  // 宿主没给（例如裸注册表的测试）时，用默认 store 自建一个。
  const timer = options.timer || (ctx && ctx.timer) || createTimer({ store, now })
  const progress = options.progress || (ctx && ctx.progress) || createProgress({ store, now })
  const projects = progress.projects
  const log = (ctx && ctx.log) || { info() {}, warn() {}, error() {}, debug() {} }
  const state = ctx && ctx.state ? ctx.state : null

  function fail(code, text, extra = {}) {
    return { ok: false, code, text, ...extra }
  }

  /** TimerError -> 面向用户的中文文案（错误码保留，便于审计与排查）。 */
  function timerFail(err) {
    const code = (err && err.code) || 'E_TIMER'
    const table = {
      E_TIMER_RUNNING: '已有正在进行的计时（/stop 结束，或 /pause 暂停后重新开始）',
      E_TIMER_PAUSED: '有暂停中的计时（/resume 继续，或 /stop 结束）',
      E_TIMER_NOT_RUNNING: '当前没有正在进行的计时',
      E_TIMER_NOT_PAUSED: '当前没有暂停中的计时',
      E_BAD_MINUTES: `时长必须是 1~180 的整数分钟（预设 ${POMODORO_PRESETS.join(' / ')}）`,
    }
    return fail(code, table[code] || String((err && err.message) || err))
  }

  /**
   * 解析项目/阶段引用（支持 id 或名称），失败返回 {error}。
   * 两种形式，旗标优先：
   *   · 旗标：--project <id|名称> [--stage <id|名称>]（既有形式）
   *   · 位置：/start [分钟] <项目> [<阶段>]（任务书字面形式，中文名直接打）
   * 都没给时沿用上次选择（插件私有 state，不混进计时账本）。
   */
  function resolveProjectStage(flags, positional = []) {
    if (flags.project || flags.stage) {
      let projectId = null
      let stageId = null
      if (flags.project) {
        const p = projects.find(String(flags.project))
        if (!p) return { error: fail('E_NO_PROJECT', `项目不存在：${flags.project}（/project new <名称> 新建，/project 看列表）`) }
        projectId = p.id
        if (flags.stage) {
          const s = (p.stages || []).find((x) => x.id === flags.stage || x.name === flags.stage)
          if (!s) return { error: fail('E_NO_STAGE', `阶段不存在：${p.name} / ${flags.stage}（/project add-stage ${p.id} <阶段名>）`) }
          stageId = s.id
        }
        return { projectId, stageId }
      }
      // 没传 --project：沿用上次（插件私有 state，不混进计时账本）
      if (state) {
        projectId = state.get('lastProjectId', null)
        stageId = state.get('lastStageId', null)
      }
      // 只给了阶段：必须在 remembered project 里找得到
      if (!projectId) return { error: fail('E_NO_PROJECT', '只给了 --stage 但没有项目：请同时给 --project，或先用 /project new 建项目') }
      const p = projects.get(projectId)
      const s = (p.stages || []).find((x) => x.id === flags.stage || x.name === flags.stage)
      if (!s) return { error: fail('E_NO_STAGE', `阶段不存在：${p.name} / ${flags.stage}`) }
      return { projectId, stageId: s.id }
    }
    // 位置参数形式：/start [分钟] <项目> [<阶段>]
    if (positional.length > 0) {
      const p = projects.find(positional[0])
      if (!p) return { error: fail('E_NO_PROJECT', `项目不存在：${positional[0]}（/project new <名称> 新建，/project 看列表）`) }
      let stageId = null
      if (positional.length > 1) {
        const s = (p.stages || []).find((x) => x.id === positional[1] || x.name === positional[1])
        if (!s) return { error: fail('E_NO_STAGE', `阶段不存在：${p.name} / ${positional[1]}（/project add-stage ${p.id} <阶段名>）`) }
        stageId = s.id
      }
      return { projectId: p.id, stageId }
    }
    // 都没给：沿用上次
    let projectId = null
    let stageId = null
    if (state) {
      projectId = state.get('lastProjectId', null)
      stageId = state.get('lastStageId', null)
    }
    return { projectId, stageId }
  }

  function projectName(id) {
    if (!id) return null
    try {
      return projects.get(id).name
    } catch {
      return `${id}（已删除）`
    }
  }

  function stageName(projectId, stageId) {
    if (!projectId || !stageId) return null
    try {
      const p = projects.get(projectId)
      const s = (p.stages || []).find((x) => x.id === stageId)
      return s ? s.name : `${stageId}（已删除）`
    } catch {
      return null
    }
  }

  /**
   * 加速测试模式提示（timeScale≠1）：宿主从 RESEARCH_ORB_TIME_SCALE 读一次注入
   * timer 引擎，插件只读引擎属性、不碰 process.env。加速会话的数据不计入
   * 进度汇总与日报统计，这件事必须显式告知用户，不能只写进注释。
   */
  function scaleWarning() {
    const ts = timer.timeScale
    if (ts === 1) return null
    return `⚠ 当前为加速测试模式（RESEARCH_ORB_TIME_SCALE=${ts}，计时加速 ${ts} 倍）：本会话产生的数据不计入进度汇总与日报统计`
  }

  /** 快照 + 今日摘要 -> 面板 status payload。 */
  function statusPayload(snap) {
    let today = null
    try {
      today = progress.summarizeDay(dayKeyOf(now()))
    } catch {
      today = null
    }
    return {
      kind: 'status',
      snapshot: snap,
      timeScale: snap.timeScale,
      projectName: projectName(snap.projectId),
      stageName: stageName(snap.projectId, snap.stageId),
      today: today && {
        dayKey: today.dayKey,
        focusSec: today.focusSec,
        sessionCount: today.sessionCount,
        completedCount: today.completedCount,
        cards: today.outputs.cards.count,
        bib: today.outputs.bib.count,
      },
    }
  }

  function statusText(snap, ui) {
    const lines = []
    const label = { running: '运行中', paused: '已暂停', idle: '空闲' }[snap.status] || snap.status
    if (snap.status === 'idle') {
      lines.push('计时状态：空闲（/start 25 开始一个 25 分钟番茄）')
    } else {
      lines.push(`计时状态：${label} · 剩余 ${fmtClock(snap.remainingSec)} / 共 ${Math.round(snap.plannedSec / 60)} 分钟 · 已专注 ${fmtClock(snap.accumulatedSec + snap.elapsedSec)}`)
      const pn = ui && ui.projectName
      const sn = ui && ui.stageName
      lines.push(pn ? `项目：${pn}${sn ? ' / ' + sn : ''}` : '项目：未归类（/start --project <名> 或 /start 25 <项目名> 可归类）')
    }
    if (snap.idlePrompt) {
      lines.push(`⚠ 检测到已空闲 ${fmtDuration(snap.idlePrompt.idleSec)}：保留还是扣除？回复「保留」或「扣除」（不操作则不做任何改动）`)
    }
    if (snap.corrupt) {
      lines.push(`⚠ 上次的计时状态文件损坏（${snap.corrupt.problems.join('、')}）：磁盘原样未改，/start 将开新账`)
    }
    if (snap.lastInterrupted) {
      lines.push(
        `上次中断恢复：记录 ${fmtDuration(snap.lastInterrupted.totalSec)}，未记录间隔 ${fmtDuration(snap.lastInterrupted.gapSec)}（进程中断，不猜不补）`,
      )
    }
    if (ui && ui.today) {
      lines.push(
        `今日（${ui.today.dayKey}）：专注 ${fmtDuration(ui.today.focusSec)} · 会话 ${ui.today.sessionCount}（完成 ${ui.today.completedCount}）· 新增卡片 ${ui.today.cards} · 新增 bib ${ui.today.bib}`,
      )
    }
    lines.push(`通知提醒：${snap.settings.notifications ? '开' : '关'}（设置页或计时面板可一键切换）`)
    return lines.join('\n')
  }

  // --- 命令实现 ------------------------------------------------------------

  async function start(rest) {
    const { text, flags } = splitFlags(rest)
    const tokens = text.split(/\s+/).filter(Boolean)
    // 第一个 token 以数字（或负号数字）开头 -> 当分钟解析（0/181/25.5/-5 照旧 E_BAD_MINUTES）；
    // 不以数字开头（如中文项目名）-> 整个 text 都是项目/阶段位置参数。
    let minutes = DEFAULTS.minutes
    let positional = tokens
    if (tokens.length > 0 && /^-?\d/.test(tokens[0])) {
      const n = Number(tokens[0])
      if (!Number.isInteger(n)) {
        return fail('E_BAD_MINUTES', `时长必须是整数分钟（预设 ${POMODORO_PRESETS.join(' / ')} 或 1~180 自定义）-> ${tokens[0]}`)
      }
      minutes = n
      positional = tokens.slice(1)
    }
    if (positional.length > 2) {
      return fail('E_BAD_ARGS', '用法：/start [15|25|45|<分钟>] [--project <id|名称>] [--stage <id|名称>]，或 /start [分钟] <项目> [<阶段>]')
    }
    const resolved = resolveProjectStage(flags, positional)
    if (resolved.error) return resolved.error
    try {
      const snap = timer.start({ minutes, projectId: resolved.projectId, stageId: resolved.stageId })
      if (state && resolved.projectId) {
        state.set('lastProjectId', resolved.projectId)
        state.set('lastStageId', resolved.stageId)
      }
      log.info(`start ${minutes} 分钟（project=${resolved.projectId || '-'} stage=${resolved.stageId || '-'}）`)
      const ui = statusPayload(snap)
      const warn = scaleWarning()
      return { ok: true, text: [warn, statusText(snap, ui)].filter(Boolean).join('\n'), ui }
    } catch (err) {
      return timerFail(err)
    }
  }

  async function pause() {
    try {
      const snap = timer.pause()
      log.info('pause')
      const ui = statusPayload(snap)
      return { ok: true, text: statusText(snap, ui), ui }
    } catch (err) {
      return timerFail(err)
    }
  }

  async function resume() {
    try {
      const snap = timer.resume()
      log.info('resume')
      const ui = statusPayload(snap)
      return { ok: true, text: statusText(snap, ui), ui }
    } catch (err) {
      return timerFail(err)
    }
  }

  async function stop() {
    try {
      const out = timer.stop()
      log.info(`stop total=${out.summary.totalSec}s completed=${out.summary.completed}`)
      const ui = statusPayload(out)
      return {
        ok: true,
        text: [
          `已收尾：本次专注 ${fmtDuration(out.summary.totalSec)}${out.summary.completed ? '（满额完成）' : out.summary.overrunSec > 0 ? `（超时 ${fmtDuration(out.summary.overrunSec)}）` : '（提前停止）'}`,
          statusText(out, ui).split('\n').slice(1).join('\n'),
        ].join('\n'),
        ui,
      }
    } catch (err) {
      return timerFail(err)
    }
  }

  async function status() {
    const snap = timer.status()
    const ui = statusPayload(snap)
    const warn = scaleWarning()
    return { ok: true, text: [warn, statusText(snap, ui)].filter(Boolean).join('\n'), ui }
  }

  /** LLM 润色口：不可用 / 失败都由 report 层回落纯模板。 */
  function makeAsk() {
    const llm = ctx && ctx.llm
    if (!llm || !llm.available || typeof llm.chat !== 'function') return null
    return async ({ messages }) => {
      const collected = await collectChat(llm.chat({ model: DEFAULTS.model, messages }))
      if (!collected.ok) throw new Error((collected.error && collected.error.message) || 'llm failed')
      if (!collected.text) throw new Error('llm empty reply')
      return collected.text
    }
  }

  async function today() {
    const dayKey = dayKeyOf(now())
    const written = progress.writeDay(dayKey)
    const report = await buildDailyReport({ progress: written.progress, store, ask: makeAsk() })
    log.info(`today ${dayKey}: focus=${written.progress.focusSec}s cards=${written.progress.outputs.cards.count} bib=${written.progress.outputs.bib.count} polished=${report.polished}`)
    const scaled = written.progress.scaled
    const scaledNote =
      scaled && scaled.sessionCount > 0
        ? `另有加速测试会话 ${scaled.sessionCount} 个（${fmtDuration(scaled.focusSec)}，timeScale≠1），不计入上方专注`
        : null
    return {
      ok: true,
      text: [
        `日报已生成：${relOf(report.path)}${report.polished ? '（含 AI 复盘）' : '（纯模板，AI 复盘未启用或失败）'}`,
        `进度数据：${relOf(written.path)}`,
        `专注 ${fmtDuration(written.progress.focusSec)} · 会话 ${written.progress.sessionCount}（完成 ${written.progress.completedCount}）· 新增卡片 ${written.progress.outputs.cards.count} · 新增 bib ${written.progress.outputs.bib.count}`,
        scaledNote,
      ]
        .filter(Boolean)
        .join('\n'),
      ui: {
        kind: 'report',
        scope: 'daily',
        dayKey,
        reportPath: relOf(report.path),
        progressPath: relOf(written.path),
        markdown: report.markdown,
        polished: report.polished,
        progress: written.progress,
      },
    }
  }

  async function weekly() {
    const weekKey = weekMondayOf(now())
    const week = progress.summarizeWeek(weekKey)
    const report = await buildWeeklyReport({ week, store, ask: makeAsk() })
    log.info(`weekly ${weekKey}: focus=${week.focusSec}s days=${week.activeDays} polished=${report.polished}`)
    return {
      ok: true,
      text: [
        `周报已生成：${relOf(report.path)}${report.polished ? '（含 AI 复盘）' : '（纯模板，AI 复盘未启用或失败）'}`,
        `本周（${week.from} ~ ${week.to}）：专注 ${fmtDuration(week.focusSec)} · ${week.activeDays}/7 天有记录 · 新增卡片 ${week.outputs.cards.count} · 新增 bib ${week.outputs.bib.count}`,
      ].join('\n'),
      ui: {
        kind: 'report',
        scope: 'weekly',
        weekKey,
        reportPath: relOf(report.path),
        markdown: report.markdown,
        polished: report.polished,
        week,
      },
    }
  }

  function project(rest) {
    const { text } = splitFlags(rest)
    const parts = text.split(/\s+/).filter(Boolean)
    const sub = (parts[0] || 'list').toLowerCase()
    const args = parts.slice(1)
    try {
      if (sub === 'new') {
        // 两种形式：
        //   /project new <名称>            自动推导 id（既有）
        //   /project new <id> <名称>       显式 id（任务书字面；id 须为合法 id 形态）
        let id = null
        let name = ''
        if (args.length >= 2 && ID_LIKE.test(args[0])) {
          id = args[0]
          name = args.slice(1).join(' ')
        } else {
          name = args.join(' ')
        }
        if (!name) return fail('E_BAD_NAME', '用法：/project new [<id>] <项目名称>')
        const p = projects.create({ name, id })
        log.info(`project new ${p.id}（${p.name}）`)
        return { ok: true, text: `已新建项目：${p.name}（id=${p.id}）\n计时归类：/start 25 --project ${p.id}，或 /start 25 ${p.id}`, ui: projectsPayload() }
      }
      if (sub === 'add-stage') {
        const ref = args[0]
        const name = args.slice(1).join(' ')
        if (!ref || !name) return fail('E_BAD_ARGS', '用法：/project add-stage <项目id|名称> <阶段名>')
        // 命令描述承诺 <项目id|名称>：先按 id/名称解析（与 /start 的位置参数、/project done 同一口径）。
        // 直接把 ref 传给 store 的 addStage 会撞上"严格 id"断言——用名称引用必得 E_BAD_ID（GUI 取证实测）。
        const found = projects.find(ref)
        if (!found) return fail('E_NO_PROJECT', `项目不存在：${ref}（/project new <名称> 新建，/project 看列表）`)
        const p = projects.addStage(found.id, { name })
        log.info(`project add-stage ${p.id}/${name}`)
        return {
          ok: true,
          text: `已为「${p.name}」添加阶段：${name}（当前 ${p.stages.length} 个阶段）\n计时归类：/start 25 --project ${p.id} --stage ${p.stages[p.stages.length - 1].id}`,
          ui: projectsPayload(),
        }
      }
      if (sub === 'done') {
        // /project done <项目> [阶段] [<里程碑备注>]
        const ref = args[0]
        const stageRef = args[1] || null
        const milestone = args.slice(2).join(' ').trim() || null
        if (!ref) return fail('E_BAD_ARGS', '用法：/project done <项目id|名称> [阶段id|名称] [<里程碑备注>]')
        const p = projects.markDone(ref, stageRef, milestone)
        log.info(`project done ${p.id}${stageRef ? '/' + stageRef : ''}${milestone ? ' [' + milestone + ']' : ''}`)
        return {
          ok: true,
          text: stageRef
            ? `已标记阶段完成：${p.name} / ${stageRef}${milestone ? `（里程碑：${milestone}）` : ''}`
            : `已标记项目完成：${p.name}${milestone ? `（里程碑：${milestone}）` : ''}`,
          ui: projectsPayload(),
        }
      }
      // list（默认）
      return { ok: true, text: projectsText(), ui: projectsPayload() }
    } catch (err) {
      return fail((err && err.code) || 'E_PROJECT', String((err && err.message) || err))
    }
  }

  function projectsPayload() {
    return {
      kind: 'projects',
      projects: projects.list().map((p) => ({
        id: p.id,
        name: p.name,
        done: !!p.done,
        milestone: p.milestone || null,
        stages: (p.stages || []).map((s) => ({ id: s.id, name: s.name, done: !!s.done, milestone: s.milestone || null })),
      })),
    }
  }

  function projectsText() {
    const all = projects.list()
    if (all.length === 0) return '还没有项目。/project new <名称> 新建一个（例如：/project new 构网型逆变器惯量支撑）'
    return [
      `项目 ${all.length} 个：`,
      ...all.map((p) => {
        const stages = (p.stages || []).map((s) => `${s.done ? '✓' : '·'} ${s.name}`)
        return `· ${p.name}（${p.id}）${p.done ? '［已完成］' : ''}${stages.length ? '\n    ' + stages.join('\n    ') : '\n    （无阶段，/project add-stage ' + p.id + ' <阶段名>）'}`
      }),
    ].join('\n')
  }

  function cardBody() {
    let today = null
    try {
      today = progress.summarizeDay(dayKeyOf(now()))
    } catch {
      today = null
    }
    const snap = timer.status()
    const cur =
      snap.status === 'idle'
        ? '空闲'
        : `${snap.status === 'running' ? '运行中' : '已暂停'} · 剩余 ${fmtClock(snap.remainingSec)}`
    return [
      `番茄钟 ${POMODORO_PRESETS.join('/')} 分钟 + 自定义 · 崩溃恢复 · 空闲>5 分钟询问`,
      `当前：${cur}｜今日专注 ${today ? fmtDuration(today.focusSec) : '—'}｜今日卡片 +${today ? today.outputs.cards.count : 0} · bib +${today ? today.outputs.bib.count : 0}`,
      '命令：/start /pause /resume /stop /status /today /weekly /project',
      scaleWarning(),
    ]
      .filter(Boolean)
      .join('\n')
  }

  return { start, pause, resume, stop, status, today, weekly, project, cardBody, statusPayload, projectsPayload, _internals: { store, timer, progress } }
}

// ---------------------------------------------------------------------------
// 插件契约
// ---------------------------------------------------------------------------

export async function activate(ctx) {
  const engine = createEngine(ctx)
  const log = ctx.log

  let body = '计时与进度收纳插件已加载'
  try {
    body = engine.cardBody()
  } catch (err) {
    body = `计时与进度收纳插件已加载（状态读取失败：${String(err && err.message)}）`
  }
  ctx.ui.registerCard({
    id: CARD_ID,
    title: '计时',
    body,
    actions: ['status', 'today', 'weekly', 'project'],
  })

  ctx.ui.registerCommand({
    name: 'start',
    title: '开始计时',
    description:
      '开始一个番茄钟。用法：/start [15|25|45|<分钟>] [--project <id|名称>] [--stage <id|名称>]，或 /start [分钟] <项目> [<阶段>]；默认 25 分钟，归类可省略（沿用上次）',
    run: async (rest = '') => {
      const r = await engine.start(rest)
      return { text: r.text, ui: r.ui, ok: r.ok, code: r.code || null }
    },
  })

  ctx.ui.registerCommand({
    name: 'pause',
    title: '暂停计时',
    description: '暂停当前计时（已专注时间先落账，不丢）。',
    run: async () => {
      const r = await engine.pause()
      return { text: r.text, ui: r.ui, ok: r.ok, code: r.code || null }
    },
  })

  ctx.ui.registerCommand({
    name: 'resume',
    title: '恢复计时',
    description: '恢复暂停中的计时。',
    run: async () => {
      const r = await engine.resume()
      return { text: r.text, ui: r.ui, ok: r.ok, code: r.code || null }
    },
  })

  ctx.ui.registerCommand({
    name: 'stop',
    title: '停止并收尾',
    description: '停止当前计时并收尾（落账 + 刷新当日进度 + 生成日报数据）。',
    run: async () => {
      const r = await engine.stop()
      return { text: r.text, ui: r.ui, ok: r.ok, code: r.code || null }
    },
  })

  ctx.ui.registerCommand({
    name: 'status',
    title: '计时状态',
    description: '查看当前计时、今日专注与产出、通知开关。',
    run: async () => {
      const r = await engine.status()
      return { text: r.text, ui: r.ui, ok: r.ok, code: r.code || null }
    },
  })

  ctx.ui.registerCommand({
    name: 'today',
    title: '今日日报',
    description: '汇总今天：专注时长、分项目、当日新增卡片与 .bib 计数，并生成 data/reports/daily-<日期>.md（LLM 润色失败自动回落纯模板）。',
    run: async () => {
      const r = await engine.today()
      return { text: r.text, ui: r.ui, ok: r.ok, code: r.code || null }
    },
  })

  ctx.ui.registerCommand({
    name: 'weekly',
    title: '本周周报',
    description: '汇总本周一到周日：每日明细、分项目累计、产出汇总，生成 data/reports/weekly-<周一日期>.md。',
    run: async () => {
      const r = await engine.weekly()
      return { text: r.text, ui: r.ui, ok: r.ok, code: r.code || null }
    },
  })

  ctx.ui.registerCommand({
    name: 'project',
    title: '项目管理',
    description: '用法：/project [list]｜/project new [<id>] <名称>｜/project add-stage <项目> <阶段名>｜/project done <项目> [阶段] [<里程碑>]',
    run: async (rest = '') => {
      const r = engine.project(rest)
      return { text: r.text, ui: r.ui, ok: r.ok, code: r.code || null }
    },
  })

  log.info(`research-timer 已激活：1 张卡片 + 8 条命令；持久化经 core timer/progress 引擎`)

  return {
    deactivate() {
      log.info('research-timer 已停用（进行中的计时由 core 引擎继续收尾，不随插件停用丢失）')
    },
    engine,
    ctx,
  }
}

export default { activate, createEngine, TIMER_VERSION }
