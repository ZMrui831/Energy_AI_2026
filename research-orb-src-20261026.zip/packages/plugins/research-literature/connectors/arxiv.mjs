// packages/plugins/research-literature/connectors/arxiv.mjs
//
// arXiv 连接器（DOMAIN-smart-energy.md 第 2 节第 1 优先源）。
//
// 端点：https://export.arxiv.org/api/query  —— 已在 core net 白名单内（仅 https）。
// 限速：任务书规定 3 req/s。这里如实记一笔差异：arXiv 官方 API 手册建议"每 3 秒不超过 1 次"，
//       比 3 req/s 保守得多。本连接器**按任务书执行 3 req/s**（net 默认令牌桶），
//       但把官方建议值作为常量 ARXIV_MIN_INTERVAL_SEC 留在文件里 —— 一旦被主管判定为过激，
//       只需在 core-host 里把 'research-literature:arxiv' 这个桶的速率调低，连接器一行不用改。
//       实测单次 /find 只对 arXiv 发 1~2 个请求，不会打出 3 req/s 的持续流量。
// 分类：eess.SY（系统与控制）/ eess.SP（信号）/ physics.app-ph / cs.LG —— DOMAIN 第 2 节。
//
// 返回统一的 {title, authors[], venue, year, doi, url, abstract, citations, source}。
// citations 在 arXiv 上不存在 → 恒为 null（不编造 0，0 与"未知"在打分里含义不同）。

import { firstTagNumber, firstTagText, splitBlocks, tagAttr } from '../lib/xml.mjs'
import { normalizeRecord } from '../lib/record.mjs'
import { ConnectorError, requestText, tokenizeQuery, withQuery } from '../lib/http.mjs'

export const ARXIV_ENDPOINT = 'https://export.arxiv.org/api/query'
export const ARXIV_CATEGORIES = Object.freeze(['eess.SY', 'eess.SP', 'physics.app-ph', 'cs.LG'])
export const ARXIV_LIMIT_KEY = 'research-literature:arxiv'
/** arXiv 官方 API 手册建议的请求间隔（秒）。 */
export const ARXIV_MIN_INTERVAL_SEC = 3
export const ARXIV_SOURCE = 'arxiv'

/**
 * 构造 arXiv 的 search_query。
 *
 * 为什么要"整句 + 二元短语 + 全词 AND"三路并联：
 *   · 整句短语 all:"grid-forming inverter inertia support" 命中太少 —— 但万一标题里就是这句呢；
 *   · 二元短语 all:"grid-forming inverter" OR all:"inertia support" 是主力；
 *   · 全词 AND all:grid-forming AND all:inverter AND all:inertia AND all:support 保证召回。
 * 三路用 OR 并联，再可选 AND 上分类过滤。分类过滤用单独的 `categories` 参数，
 * 因为"分类太窄导致 0 结果"要靠上层再做一次无分类回退（见 searchArxivWithFallback）。
 */
export function buildArxivQuery({ text, categories = [] } = {}) {
  const tokens = tokenizeQuery(text)
  if (tokens.length === 0) throw new ConnectorError('E_EMPTY_QUERY', 'arXiv: 检索词为空')
  const clean = tokens.join(' ')

  const phrases = new Set([clean])
  for (let i = 0; i + 1 < tokens.length; i += 1) phrases.add(`${tokens[i]} ${tokens[i + 1]}`)

  const phraseExpr = [...phrases].map((p) => `all:"${p}"`)
  const termExpr = tokens.map((t) => `all:${t}`)
  const textExpr = `((${phraseExpr.join(' OR ')}) OR (${termExpr.join(' AND ')}))`

  const cats = (categories || []).map((c) => String(c).trim()).filter(Boolean)
  if (cats.length === 0) return textExpr
  return `${textExpr} AND (${cats.map((c) => `cat:${c}`).join(' OR ')})`
}

/** 组装完整请求 URL。 */
export function buildArxivUrl({ text, categories = [], max = 20, start = 0, sortBy = 'relevance' } = {}) {
  return withQuery(ARXIV_ENDPOINT, {
    search_query: buildArxivQuery({ text, categories }),
    start,
    max_results: Math.max(1, Math.min(100, Number(max) || 20)),
    sortBy,
    sortOrder: 'descending',
  })
}

/** 解析 Atom feed 的 <entry> 块（纯函数，测试直接喂字符串）。 */
export function parseArxivFeed(xml) {
  const src = String(xml || '')
  const blocks = splitBlocks(src, 'entry')
  const entries = blocks.map((block) => {
    const authors = []
    for (const m of block.matchAll(/<author>[\s\S]*?<\/author>/gi)) {
      const name = firstTagText(m[0], 'name')
      if (name) authors.push(name)
    }
    const published = firstTagText(block, 'published')
    const primary = tagAttr(block, 'primary_category', 'term')
    const pdf = tagAttr(block, 'link', 'href', { where: /title\s*=\s*"pdf"/i })
    const alternate = tagAttr(block, 'link', 'href', { where: /rel\s*=\s*"(alternate|abs)"/i })
    const doi = firstTagText(block, 'doi')
    return {
      rawId: firstTagText(block, 'id'),
      title: firstTagText(block, 'title'),
      summary: firstTagText(block, 'summary'),
      published,
      updated: firstTagText(block, 'updated'),
      authors,
      primaryCategory: primary,
      journalRef: firstTagText(block, 'journal_ref'),
      comment: firstTagText(block, 'comment'),
      doi,
      pdfHref: pdf,
      absHref: alternate,
    }
  })
  return {
    total: firstTagNumber(src, 'totalResults'),
    entries,
  }
}

/** 把一条 Atom entry 映射成统一记录。 */
export function mapArxivEntry(entry) {
  const year = entry && entry.published ? Number.parseInt(String(entry.published).slice(0, 4), 10) : null
  const journalRef = entry && entry.journalRef ? entry.journalRef : ''
  const venue = journalRef || (entry && entry.primaryCategory ? `arXiv:${entry.primaryCategory}` : 'arXiv preprint')
  const absId = entry && entry.rawId ? String(entry.rawId) : ''
  return normalizeRecord(
    {
      id: absId.replace(/^https?:\/\/arxiv\.org\/abs\//i, '').replace(/v\d+$/i, '') || absId,
      title: entry && entry.title,
      authors: entry && entry.authors,
      venue,
      year: Number.isFinite(year) ? year : null,
      doi: entry && entry.doi,
      url: (entry && entry.absHref) || absId,
      abstract: entry && entry.summary,
      citations: null, // arXiv 不提供引用数，绝不编造
      pdfUrl: entry && entry.pdfHref,
      openAccess: true, // arXiv 的一切都是开放获取
      type: 'preprint',
    },
    ARXIV_SOURCE,
  )
}

/**
 * 检索 arXiv。
 * @param {{net: object, query: string, categories?: string[], max?: number, sortBy?: string}} args
 */
export async function searchArxiv({ net, query, categories = ARXIV_CATEGORIES, max = 20, sortBy = 'relevance' } = {}) {
  const url = buildArxivUrl({ text: query, categories, max, sortBy })
  const { text } = await requestText(net, url, { limitKey: ARXIV_LIMIT_KEY, accept: 'application/atom+xml' })
  const feed = parseArxivFeed(text)
  return {
    source: ARXIV_SOURCE,
    url,
    total: feed.total,
    records: feed.entries.map(mapArxivEntry),
    entries: feed.entries.length,
  }
}

/**
 * 检索 arXiv，分类过滤命中不足时自动去掉分类再检索一次。
 *
 * 这条回退不是"容错代码"，是必要的：
 * 「grid-forming inverter inertia support」在 eess.SY 里可能只有 1 篇，
 * 但整站有几十篇。宁可多一次请求，也不要拿"分类干净"换"召回为零"。
 * 回退发生时返回 usedFallback=true，面板会显示，用户能看出结果不是全带分类过滤的。
 */
export async function searchArxivWithFallback({
  net,
  query,
  categories = ARXIV_CATEGORIES,
  max = 20,
  minResults = 5,
} = {}) {
  const first = await searchArxiv({ net, query, categories, max })
  if (first.records.length >= minResults || !categories || categories.length === 0) {
    return { ...first, usedFallback: false }
  }
  const wide = await searchArxiv({ net, query, categories: [], max })
  const merged = [...first.records, ...wide.records]
  return {
    ...wide,
    records: merged,
    total: wide.total,
    usedFallback: true,
    note: `分类过滤仅命中 ${first.records.length} 篇，已回退到全站检索`,
  }
}

export default {
  ARXIV_ENDPOINT,
  ARXIV_CATEGORIES,
  ARXIV_LIMIT_KEY,
  ARXIV_MIN_INTERVAL_SEC,
  buildArxivQuery,
  buildArxivUrl,
  parseArxivFeed,
  mapArxivEntry,
  searchArxiv,
  searchArxivWithFallback,
}
