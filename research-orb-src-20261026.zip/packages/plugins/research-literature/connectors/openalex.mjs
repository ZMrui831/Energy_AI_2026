// packages/plugins/research-literature/connectors/openalex.mjs
//
// OpenAlex 连接器（DOMAIN-smart-energy.md 第 2 节第 2 优先源，覆盖面最广，含 IEEE/Elsevier 元数据）。
//
// 端点：https://api.openalex.org/works —— 已在 core net 白名单内（仅 https）。
// 礼貌池：OpenAlex 建议带 mailto 进礼貌池。任务书要求「若 data\secrets.json 的
//         openalex.mailto 为空则不加该参数，不要臆造邮箱」—— 本连接器严格遵守：
//         mailto 只能由调用方从 secrets 读出后显式传入，为空就整个参数不出现。
//         绝不写死任何邮箱，也绝不从系统里"猜"一个。
//
// 摘要：OpenAlex 不给 <abstract> 原文，只给 abstract_inverted_index（词 → 位置列表）。
//       要还原成可读句子必须按位置排序再拼 —— invertAbstract() 做这件事。
//       这件事做错的典型症状是"摘要词序全乱但看起来像摘要"，所以单测专门钉了它。

import { ConnectorError, requestJson, withQuery } from '../lib/http.mjs'
import { normalizeRecord } from '../lib/record.mjs'

export const OPENALEX_ENDPOINT = 'https://api.openalex.org/works'
export const OPENALEX_LIMIT_KEY = 'research-literature:openalex'
export const OPENALEX_SOURCE = 'openalex'

/**
 * 组装 URL。mailto 为空/非法时**不加**该参数。
 * @param {{text?: string, mailto?: string, perPage?: number, filter?: string, page?: number}} args
 */
export function buildOpenAlexUrl({ text = '', mailto = null, perPage = 20, filter = null, page = null } = {}) {
  const params = {
    search: text || null,
    'per-page': Math.max(1, Math.min(200, Number(perPage) || 20)),
    page: page || null,
    filter: filter || null,
  }
  const cleanMailto = typeof mailto === 'string' && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(mailto.trim()) ? mailto.trim() : null
  if (cleanMailto) params.mailto = cleanMailto
  return withQuery(OPENALEX_ENDPOINT, params)
}

/**
 * 把 abstract_inverted_index 还原成摘要文本。
 * 输入形如 { "Grid": [0, 7], "forming": [1], ... }，值是该词在原文里的词位。
 * 输出按词位升序拼回的字符串；输入非法时返回 ''（而不是抛错——摘要缺失是常态，
 * OpenAlex 对相当比例的文献就没有摘要，为这个中断整次检索不值得）。
 */
export function invertAbstract(inverted) {
  if (!inverted || typeof inverted !== 'object') return ''
  const slots = []
  for (const [word, positions] of Object.entries(inverted)) {
    if (!Array.isArray(positions)) continue
    for (const p of positions) {
      const idx = Number(p)
      if (!Number.isFinite(idx) || idx < 0) continue
      slots.push({ idx, word: String(word) })
    }
  }
  if (slots.length === 0) return ''
  slots.sort((a, b) => a.idx - b.idx)
  return slots
    .map((s) => s.word)
    .join(' ')
    .replace(/\s+/g, ' ')
    .trim()
}

/** 把一条 OpenAlex work 映射成统一记录。 */
export function mapOpenAlexWork(work) {
  const w = work && typeof work === 'object' ? work : {}
  const authors = Array.isArray(w.authorships)
    ? w.authorships.map((a) => (a && a.author ? a.author.display_name : null)).filter(Boolean)
    : []
  const primary = w.primary_location && typeof w.primary_location === 'object' ? w.primary_location : {}
  const source = primary.source && typeof primary.source === 'object' ? primary.source : {}
  const hostVenue = w.host_venue && typeof w.host_venue === 'object' ? w.host_venue : {}
  const venue = source.display_name || hostVenue.display_name || ''
  const oa = w.open_access && typeof w.open_access === 'object' ? w.open_access : {}
  const bestOa = w.best_oa_location && typeof w.best_oa_location === 'object' ? w.best_oa_location : {}
  const url = primary.landing_page_url || w.doi || w.id || ''
  return normalizeRecord(
    {
      id: (w.id || '').replace(/^https?:\/\/openalex\.org\//i, ''),
      title: w.title || w.display_name || '',
      authors,
      venue,
      year: w.publication_year ?? null,
      doi: w.doi || null,
      url,
      abstract: invertAbstract(w.abstract_inverted_index),
      citations: Number.isFinite(w.cited_by_count) ? w.cited_by_count : null,
      pdfUrl: bestOa.pdf_url || oa.oa_url || null,
      openAccess: oa.is_oa === true,
      type: w.type || null,
    },
    OPENALEX_SOURCE,
  )
}

/**
 * 检索 OpenAlex。
 * @param {{net: object, query: string, mailto?: string|null, max?: number, filter?: string|null}} args
 */
export async function searchOpenAlex({ net, query, mailto = null, max = 20, filter = null } = {}) {
  const text = String(query || '').trim()
  if (!text && !filter) throw new ConnectorError('E_EMPTY_QUERY', 'OpenAlex: 检索词为空且未给 filter')
  const url = buildOpenAlexUrl({ text, mailto, perPage: max, filter })
  const { json } = await requestJson(net, url, { limitKey: OPENALEX_LIMIT_KEY })
  const results = Array.isArray(json && json.results) ? json.results : []
  return {
    source: OPENALEX_SOURCE,
    url,
    total: Number.isFinite(json && json.meta && json.meta.count) ? json.meta.count : null,
    mailtoUsed: url.includes('mailto='),
    records: results.map(mapOpenAlexWork),
    entries: results.length,
  }
}

/**
 * 按 DOI 取单篇元数据。URL 形如 https://api.openalex.org/works/https://doi.org/<doi>。
 * 注意 DOI 里的斜杠**不能**编码：OpenAlex 就是靠这段路径做 DOI 解析的。
 */
export async function fetchOpenAlexByDoi({ net, doi, mailto = null } = {}) {
  const clean = String(doi || '').trim().replace(/^https?:\/\/(dx\.)?doi\.org\//i, '').replace(/^doi:/i, '')
  if (!clean) throw new ConnectorError('E_BAD_DOI', 'OpenAlex: DOI 为空')
  const base = `${OPENALEX_ENDPOINT}/https://doi.org/${clean}`
  const url = withQuery(base, {
    mailto: typeof mailto === 'string' && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(mailto.trim()) ? mailto.trim() : null,
  })
  const { json } = await requestJson(net, url, { limitKey: OPENALEX_LIMIT_KEY })
  if (!json || (!json.title && !json.display_name)) {
    throw new ConnectorError('E_NOT_FOUND', `OpenAlex: 未找到 DOI -> ${clean}`, { status: 404 })
  }
  return { source: OPENALEX_SOURCE, url, record: mapOpenAlexWork(json) }
}

export default {
  OPENALEX_ENDPOINT,
  OPENALEX_LIMIT_KEY,
  buildOpenAlexUrl,
  invertAbstract,
  mapOpenAlexWork,
  searchOpenAlex,
  fetchOpenAlexByDoi,
}