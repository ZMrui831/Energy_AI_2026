// packages/plugins/research-literature/connectors/index.mjs
//
// 四源并联检索 → 去重 → 打分 → 排序。这是 /find 的执行体。
//
// 为什么是"并联 + 部分失败可接受"：
//   四个源都可能单独挂（限流/超时/维护）。如果串行且一挂全挂，那 /find 的可用性
//   就等于四个源可用性的乘积 —— 数学上必然差。这里用 allSettled，任何单源失败都只
//   表现为该源 status.ok=false + 一行原因，其余源的结果照常返回并参与打分。
//   只有在**候选总数为 0** 时才算 /find 失败。
//
// 顺带把"白名单域名"这件事做成了可断言的：每个连接器都硬编码自己的 https 端点，
// 聚合层不接受调用方传入自定义 baseUrl —— 于是 /find 的 net.jsonl 里只可能出现
// export.arxiv.org / api.openalex.org / api.crossref.org / api.semanticscholar.org 四个域。

import { ARXIV_SOURCE, searchArxivWithFallback } from './arxiv.mjs'
import { OPENALEX_SOURCE, fetchOpenAlexByDoi, searchOpenAlex } from './openalex.mjs'
import { CROSSREF_SOURCE, fetchCrossrefByDoi, searchCrossref } from './crossref.mjs'
import { S2_SOURCE, searchSemanticScholar } from './semanticscholar.mjs'
import { dedupeRecords, rankRecords } from '../lib/record.mjs'

export { ARXIV_SOURCE, OPENALEX_SOURCE, CROSSREF_SOURCE, S2_SOURCE }
export * from './arxiv.mjs'
export * from './openalex.mjs'
export * from './crossref.mjs'
export * from './semanticscholar.mjs'

/** 检索源顺序即面板展示顺序（也是"哪几个源被问过"的权威列表）。 */
export const SEARCH_SOURCES = Object.freeze([ARXIV_SOURCE, OPENALEX_SOURCE, CROSSREF_SOURCE, S2_SOURCE])

function shortErr(err) {
  const code = (err && err.code) || 'E_UNKNOWN'
  const msg = String((err && err.message) || err || '').slice(0, 180)
  return { code, message: msg }
}

/**
 * 并联检索。
 * @param {{
 *   net: object,
 *   query: string,
 *   max?: number,
 *   sources?: string[],
 *   openalexMailto?: string|null,
 *   s2ApiKey?: string|null,
 *   minCandidates?: number,
 *   minArxiv?: number,
 *   now?: Date,
 *   refYear?: number|null,
 * }} args
 */
export async function searchAll({
  net,
  query,
  max = 12,
  sources = SEARCH_SOURCES,
  openalexMailto = null,
  s2ApiKey = null,
  minCandidates = 5,
  minArxiv = 5,
  now = new Date(),
  refYear = null,
} = {}) {
  const text = String(query || '').trim()
  if (!text) {
    const err = new Error('检索词为空')
    err.code = 'E_EMPTY_QUERY'
    throw err
  }
  const wanted = Array.isArray(sources) && sources.length > 0 ? sources.filter((s) => SEARCH_SOURCES.includes(s)) : [...SEARCH_SOURCES]

  const tasks = wanted.map(async (source) => {
    if (source === ARXIV_SOURCE) {
      return searchArxivWithFallback({ net, query: text, max, minResults: minArxiv })
    }
    if (source === OPENALEX_SOURCE) return searchOpenAlex({ net, query: text, mailto: openalexMailto, max })
    if (source === CROSSREF_SOURCE) return searchCrossref({ net, query: text, max })
    if (source === S2_SOURCE) return searchSemanticScholar({ net, query: text, apiKey: s2ApiKey, max })
    throw Object.assign(new Error(`未知检索源 -> ${source}`), { code: 'E_UNKNOWN_SOURCE' })
  })

  const settled = await Promise.allSettled(tasks)
  const statuses = []
  const raw = []

  settled.forEach((result, i) => {
    const source = wanted[i]
    if (result.status === 'fulfilled') {
      const value = result.value || {}
      const records = Array.isArray(value.records) ? value.records : []
      raw.push(...records)
      statuses.push({
        source,
        ok: true,
        skipped: !!value.skipped,
        reason: value.reason || null,
        note: value.note || null,
        entries: records.length,
        total: value.total ?? null,
        usedFallback: !!value.usedFallback,
        url: value.url || null,
      })
    } else {
      statuses.push({ source, ok: false, entries: 0, total: null, error: shortErr(result.reason) })
    }
  })

  const { records: deduped, duplicates } = dedupeRecords(raw)
  const candidates = rankRecords(deduped, { now, refYear })

  const bySource = {}
  for (const rec of candidates) {
    for (const s of rec.sources || [rec.source]) bySource[s] = (bySource[s] || 0) + 1
  }

  const okCount = statuses.filter((s) => s.ok && !s.skipped).length
  return {
    query: text,
    searchedAt: now.toISOString(),
    sources: statuses,
    candidates,
    stats: {
      raw: raw.length,
      deduped: candidates.length,
      duplicates,
      sourcesAsked: wanted.length,
      sourcesOk: okCount,
      bySource,
      enough: candidates.length >= minCandidates,
    },
    ok: candidates.length > 0,
  }
}

/**
 * 按 DOI 查单篇元数据：先 OpenAlex（覆盖广、有 OA 链接），失败再 Crossref。
 * 两个都失败才放弃 —— 只挂一个源就放弃，会让 /card 的可靠性无谓地减半。
 * @returns {{ok: boolean, record: object|null, via: string|null, attempts: object[]}}
 */
export async function lookupRecordByDoi({ net, doi, mailto = null } = {}) {
  const attempts = []
  for (const [name, fn] of [
    [OPENALEX_SOURCE, fetchOpenAlexByDoi],
    [CROSSREF_SOURCE, fetchCrossrefByDoi],
  ]) {
    try {
      const r = await fn({ net, doi, mailto })
      attempts.push({ source: name, ok: true, url: r.url })
      return { ok: true, record: r.record, via: name, attempts }
    } catch (err) {
      attempts.push({ source: name, ok: false, error: shortErr(err) })
    }
  }
  return { ok: false, record: null, via: null, attempts }
}

export default { searchAll, SEARCH_SOURCES, lookupRecordByDoi }
