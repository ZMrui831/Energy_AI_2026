// packages/plugins/research-literature/connectors/crossref.mjs
//
// Crossref 连接器（DOMAIN-smart-energy.md 第 2 节第 3 优先源：DOI/期刊/会议元数据、引用关系）。
//
// 端点：https://api.crossref.org/works —— 已在 core net 白名单内（仅 https）。
// 礼貌池：Crossref 同样建议带 mailto。任务书只授权我们从 data\secrets.json 读
//         openalex.mailto，没授权臆造邮箱 —— 所以本连接器**不主动加 mailto**，
//         但保留 mailto 入参：将来若 secrets 里补了 crossref.mailto，调用方传进来即可。
// 摘要：Crossref 的 abstract 是 JATS XML 片段（<jats:p>…</jats:p>），要剥标签。
// select 参数：只取用得上的字段，响应体积从 ~400KB 降到 ~40KB（对限速友好，也更省流量）。

import { ConnectorError, requestJson, tokenizeQuery, withQuery } from '../lib/http.mjs'
import { normalizeRecord } from '../lib/record.mjs'

export const CROSSREF_ENDPOINT = 'https://api.crossref.org/works'
export const CROSSREF_LIMIT_KEY = 'research-literature:crossref'
export const CROSSREF_SOURCE = 'crossref'
export const CROSSREF_SELECT = Object.freeze([
  'DOI',
  'title',
  'author',
  'container-title',
  'issued',
  'is-referenced-by-count',
  'URL',
  'abstract',
  'type',
])

/** 组装 URL。 */
export function buildCrossrefUrl({ text = '', rows = 20, mailto = null, filter = null, offset = null } = {}) {
  const params = {
    query: text || null,
    rows: Math.max(1, Math.min(100, Number(rows) || 20)),
    select: CROSSREF_SELECT.join(','),
    filter: filter || null,
    offset: offset || null,
  }
  const cleanMailto = typeof mailto === 'string' && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(mailto.trim()) ? mailto.trim() : null
  if (cleanMailto) params.mailto = cleanMailto
  return withQuery(CROSSREF_ENDPOINT, params)
}

/** 剥掉 JATS/HTML 标签并把段落拼起来。 */
export function stripJats(input) {
  return String(input || '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim()
}

/** 把 Crossref 的 author 数组映射成 "Given Family" 形式的字符串数组。 */
export function mapCrossrefAuthors(authors) {
  if (!Array.isArray(authors)) return []
  return authors
    .map((a) => {
      if (!a || typeof a !== 'object') return ''
      if (a.name) return String(a.name)
      return [a.given, a.family].filter(Boolean).join(' ')
    })
    .filter(Boolean)
}

/** 把一条 Crossref item 映射成统一记录。 */
export function mapCrossrefItem(item) {
  const it = item && typeof item === 'object' ? item : {}
  const titles = Array.isArray(it.title) ? it.title : []
  const containers = Array.isArray(it['container-title']) ? it['container-title'] : []
  const issuedParts = it.issued && Array.isArray(it.issued['date-parts']) ? it.issued['date-parts'][0] : null
  const year = Array.isArray(issuedParts) && Number.isFinite(issuedParts[0]) ? issuedParts[0] : null
  return normalizeRecord(
    {
      id: it.DOI || null,
      title: titles[0] || '',
      authors: mapCrossrefAuthors(it.author),
      venue: containers[0] || '',
      year,
      doi: it.DOI || null,
      url: it.URL || (it.DOI ? `https://doi.org/${it.DOI}` : ''),
      abstract: stripJats(it.abstract),
      citations: Number.isFinite(it['is-referenced-by-count']) ? it['is-referenced-by-count'] : null,
      type: it.type || null,
    },
    CROSSREF_SOURCE,
  )
}

/**
 * 检索 Crossref。
 * @param {{net: object, query: string, max?: number, mailto?: string|null, filter?: string|null}} args
 */
export async function searchCrossref({ net, query, max = 20, mailto = null, filter = null } = {}) {
  const text = tokenizeQuery(query).join(' ')
  if (!text && !filter) throw new ConnectorError('E_EMPTY_QUERY', 'Crossref: 检索词为空且未给 filter')
  const url = buildCrossrefUrl({ text, rows: max, mailto, filter })
  const { json } = await requestJson(net, url, { limitKey: CROSSREF_LIMIT_KEY })
  const items = json && json.message && Array.isArray(json.message.items) ? json.message.items : []
  return {
    source: CROSSREF_SOURCE,
    url,
    total: Number.isFinite(json && json.message && json.message['total-results']) ? json.message['total-results'] : null,
    records: items.map(mapCrossrefItem),
    entries: items.length,
  }
}

/**
 * 按 DOI 取单篇元数据：https://api.crossref.org/works/<doi>。
 * DOI 原样拼在路径里（保留斜杠）—— 这是 Crossref 文档里的形态。
 */
export async function fetchCrossrefByDoi({ net, doi, mailto = null } = {}) {
  const clean = String(doi || '').trim().replace(/^https?:\/\/(dx\.)?doi\.org\//i, '').replace(/^doi:/i, '')
  if (!clean) throw new ConnectorError('E_BAD_DOI', 'Crossref: DOI 为空')
  const base = `${CROSSREF_ENDPOINT}/${clean}`
  const url = withQuery(base, {
    mailto: typeof mailto === 'string' && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(mailto.trim()) ? mailto.trim() : null,
  })
  const { json } = await requestJson(net, url, { limitKey: CROSSREF_LIMIT_KEY })
  const item = json && json.message ? json.message : null
  if (!item || (!item.DOI && !item.title)) {
    throw new ConnectorError('E_NOT_FOUND', `Crossref: 未找到 DOI -> ${clean}`, { status: 404 })
  }
  return { source: CROSSREF_SOURCE, url, record: mapCrossrefItem(item) }
}

export default {
  CROSSREF_ENDPOINT,
  CROSSREF_LIMIT_KEY,
  CROSSREF_SELECT,
  buildCrossrefUrl,
  stripJats,
  mapCrossrefItem,
  searchCrossref,
  fetchCrossrefByDoi,
}
