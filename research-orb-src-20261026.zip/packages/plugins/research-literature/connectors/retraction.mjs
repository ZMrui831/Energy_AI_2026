// packages/plugins/research-literature/connectors/retraction.mjs
//
// S20·B：撤稿检查（保守口径）。
// 对外宣称口径 ONLY："基于 Crossref / OpenAlex 元数据的撤稿标记检查"——
// 绝不声称"自动判断论文是否撤稿"或"替代人工核查"。
//
// 设计：
//   · parseRetraction：纯函数，从 Crossref message + OpenAlex work 抽撤稿信号。
//     Crossref 信号三种：① is-retracted=true ② update[] 中 update-type 含 "retract"
//                       ③ 标题前缀 "RETRACTED:"（Crossref 真实约定，已实测命中 Wakefield）。
//   · lookupRetraction：走 ctx.net（白名单/令牌桶/审计），可注入 getJson 做离线测试。
//   · assertRetractionGate：命中撤稿后，拒绝"已证实"话术导出（照 E_NOT_PUBLISHED 模式）。
import { requestJson } from '../lib/http.mjs'

export const RETRACTED_TAG = '已撤稿'

// "已证实"类话术——命中撤稿后禁止以这些词导出结论
const VERIFIED_WORDING = [/(已证实)/, /(已确认)/, /(证实)/, /(确认无误)/, /(确证)/, /(已验证)/]
// 假设/待核实类——命中撤稿但用这些词则放行（把球交回人工核查）
const HYPOTHETICAL_WORDING = [
  /(假设)/, /(待核实)/, /(存疑)/, /(可能)/, /(推测)/, /(未定)/, /(尚待)/, /(疑似)/, /(有待)/, /(疑为)/, /(需复核)/,
]

/** 从 Crossref message + OpenAlex work 抽撤稿信号（纯函数，便于离线测试）。 */
export function parseRetraction({ crossrefMessage = null, openalexWork = null } = {}) {
  const signals = {}
  let cr = false
  if (crossrefMessage && typeof crossrefMessage === 'object') {
    if (crossrefMessage['is-retracted'] === true) { cr = true; signals.crossref_isRetracted = true }
    const upd = crossrefMessage['update']
    if (Array.isArray(upd)) {
      for (const u of upd) {
        const ut = String((u && u['update-type']) || '').toLowerCase()
        if (ut.includes('retract')) { cr = true; signals.crossref_updateType = u['update-type']; break }
      }
    }
    const title = Array.isArray(crossrefMessage.title)
      ? crossrefMessage.title[0]
      : (typeof crossrefMessage.title === 'string' ? crossrefMessage.title : '')
    if (typeof title === 'string' && title.toUpperCase().startsWith('RETRACTED:')) {
      cr = true; signals.crossref_titlePrefix = true
    }
  }
  let oa = false
  if (openalexWork && typeof openalexWork === 'object') {
    if (openalexWork.is_retracted === true) { oa = true; signals.openalex_isRetracted = true }
  }
  const retracted = cr || oa
  const source = oa ? 'openalex' : (cr ? 'crossref' : null)
  return { retracted, source, signals }
}

/**
 * 联网查询撤稿状态。
 * @param {string} doi
 * @param {{ net?: object, getJson?: Function, limitKey?: string }} [opts]
 */
export async function lookupRetraction(doi, { net, getJson = null, limitKey = 'research-literature:retraction' } = {}) {
  const enc = encodeURIComponent(doi)
  const doGet = getJson || (async (url) => {
    const { json } = await requestJson(net, url, { limitKey })
    return json
  })
  let crossrefMessage = null
  let openalexWork = null
  try {
    const cj = await doGet('https://api.crossref.org/works/' + enc)
    crossrefMessage = (cj && cj.message) || null
  } catch { /* 网络失败不阻断：视为未命中，由人工核查兜底 */ }
  try {
    openalexWork = await doGet('https://api.openalex.org/works/https://doi.org/' + doi)
  } catch { /* 同上 */ }
  const parsed = parseRetraction({ crossrefMessage, openalexWork })
  return { doi, ...parsed }
}

/** 命中撤稿时返回行内标记 [已撤稿]，否则空串（与 [双源]/[单源] 同级行内使用）。 */
export function tagRetracted(verdict) {
  return verdict && verdict.retracted ? '[' + RETRACTED_TAG + ']' : ''
}

export class RetractionError extends Error {
  constructor(code, message, guidance) {
    super(message)
    this.name = 'RetractionError'
    this.code = code
    this.guidance = guidance
  }
}

/**
 * 命中撤稿时的发布闸门：拒绝"已证实"话术导出。
 * 照 E_NOT_PUBLISHED 模式：明确 code + 说明 + 引导改假设/待核实。
 * @returns {{ ok: boolean, hypothetical?: boolean }}
 */
export function assertRetractionGate({ doi, retracted, text }) {
  if (!retracted) return { ok: true }
  const t = String(text || '')
  const hasVerified = VERIFIED_WORDING.some((re) => re.test(t))
  const hasHypo = HYPOTHETICAL_WORDING.some((re) => re.test(t))
  if (hasVerified && !hasHypo) {
    throw new RetractionError(
      'E_RETRACTED_VERIFIED',
      `该 DOI（${doi}）已被撤稿标记命中，禁止以"已证实/已确认"话术导出结论。`,
      '请改为假设/待核实语气（如"假设该结论存疑，待核实""此项需复核原始撤稿声明"），或改引未被撤稿的文献。',
    )
  }
  return { ok: true, hypothetical: hasHypo }
}

export default { parseRetraction, lookupRetraction, tagRetracted, assertRetractionGate, RETRACTED_TAG }
