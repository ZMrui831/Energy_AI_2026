// packages/plugins/research-literature/connectors/semanticscholar.mjs
//
// Semantic Scholar 连接器（DOMAIN-smart-energy.md 第 2 节第 4 优先源：TLDR 摘要、引用上下文）。
//
// 端点：https://api.semanticscholar.org/graph/v1/paper/search —— 已在 core net 白名单内。
//
// 「有 key 才用」——本连接器把这句话当成硬规则，不是建议：
//   无 key 时 S2 走的是公共共享池，配额极小且随时会被限流，拿它当默认检索源会让
//   /find 的成败取决于运气。所以：
//     · key 为空 → searchSemanticScholar() 直接返回 {skipped:true, reason:'E_NO_KEY'}，
//       **一个网络请求都不发**（不是发了被拒，是压根不发）；
//     · key 存在 → 挂 x-api-key 头，并取 tldr（这是 S2 相对其他三个源的独特价值）。
//   这也让"密钥零泄露"这条验收更好做：有没有 key，行为是可断言的。
//
// 密钥来源：只从 data\secrets.json 的 semanticscholar.apiKey 读（由调用方读出后传入）。
// 本文件不读文件、不读环境变量 —— 它只接收一个字符串。

import { ConnectorError, requestJson, withQuery } from '../lib/http.mjs'
import { normalizeRecord } from '../lib/record.mjs'

export const S2_ENDPOINT = 'https://api.semanticscholar.org/graph/v1/paper/search'
export const S2_LIMIT_KEY = 'research-literature:semanticscholar'
export const S2_SOURCE = 'semanticscholar'
export const S2_FIELDS = Object.freeze([
  'title',
  'abstract',
  'year',
  'venue',
  'authors',
  'externalIds',
  'citationCount',
  'openAccessPdf',
  'tldr',
  'url',
  'publicationTypes',
])

/** key 是否可用（非空字符串才算有）。 */
export function hasApiKey(apiKey) {
  return typeof apiKey === 'string' && apiKey.trim().length > 0
}

/** 组装 URL。 */
export function buildS2Url({ text = '', limit = 20, fields = S2_FIELDS } = {}) {
  return withQuery(S2_ENDPOINT, {
    query: text || null,
    limit: Math.max(1, Math.min(100, Number(limit) || 20)),
    fields: (fields || S2_FIELDS).join(','),
  })
}

/** 把一条 S2 paper 映射成统一记录。 */
export function mapS2Paper(paper) {
  const p = paper && typeof paper === 'object' ? paper : {}
  const ext = p.externalIds && typeof p.externalIds === 'object' ? p.externalIds : {}
  const tldr = p.tldr && typeof p.tldr === 'object' ? p.tldr.text : null
  const oaPdf = p.openAccessPdf && typeof p.openAccessPdf === 'object' ? p.openAccessPdf.url : null
  const abstract = p.abstract || tldr || ''
  return normalizeRecord(
    {
      id: p.paperId || ext.CorpusId || null,
      title: p.title || '',
      authors: Array.isArray(p.authors) ? p.authors.map((a) => (a ? a.name : null)).filter(Boolean) : [],
      venue: p.venue || (Array.isArray(p.publicationTypes) ? p.publicationTypes[0] : '') || '',
      year: Number.isFinite(p.year) ? p.year : null,
      doi: ext.DOI || null,
      url: p.url || (ext.DOI ? `https://doi.org/${ext.DOI}` : ''),
      abstract,
      citations: Number.isFinite(p.citationCount) ? p.citationCount : null,
      tldr: tldr || null,
      pdfUrl: oaPdf || null,
      openAccess: !!oaPdf,
      type: Array.isArray(p.publicationTypes) && p.publicationTypes.length > 0 ? p.publicationTypes[0] : null,
    },
    S2_SOURCE,
  )
}

/**
 * 检索 Semantic Scholar。
 * @param {{net: object, query: string, apiKey?: string|null, max?: number}} args
 */
export async function searchSemanticScholar({ net, query, apiKey = null, max = 20 } = {}) {
  if (!hasApiKey(apiKey)) {
    return {
      source: S2_SOURCE,
      skipped: true,
      reason: 'E_NO_KEY',
      note: 'secrets.json 的 semanticscholar.apiKey 为空，按任务书「有 key 才用」跳过（未发起任何请求）',
      records: [],
      entries: 0,
      total: null,
      url: null,
    }
  }
  const text = String(query || '').trim()
  if (!text) throw new ConnectorError('E_EMPTY_QUERY', 'Semantic Scholar: 检索词为空')
  const url = buildS2Url({ text, limit: max })
  const { json } = await requestJson(net, url, {
    limitKey: S2_LIMIT_KEY,
    // 密钥只出现在请求头，且 net 的审计行只记 host+path（不带 query、不带 header），
    // 因此 net.jsonl / plugins.jsonl 里都不会出现它。
    headers: { 'x-api-key': String(apiKey).trim() },
  })
  const data = Array.isArray(json && json.data) ? json.data : []
  return {
    source: S2_SOURCE,
    skipped: false,
    url,
    total: Number.isFinite(json && json.total) ? json.total : null,
    records: data.map(mapS2Paper),
    entries: data.length,
  }
}

export default {
  S2_ENDPOINT,
  S2_LIMIT_KEY,
  S2_FIELDS,
  hasApiKey,
  buildS2Url,
  mapS2Paper,
  searchSemanticScholar,
}
