// packages/plugins/research-literature/connectors/preprint.mjs
//
// S23·C1 预印本标记（保守口径）。
// 对外宣称口径 ONLY："基于元数据的预印本标记"——绝不声称"判断论文是否通过同行评审"。
//
// 设计（与 retraction.mjs 同一模式）：
//   · parsePreprint：纯函数，从 Crossref message / OpenAlex work / arXiv entry /
//     URL / DOI 前缀抽预印本信号，可离线测试。
//   · tagPreprint：命中 → 行内标记 [预印本]（与 [已撤稿] / ✓双源 / ⚠仅单源 同级）。
//   · renderPreprintNotice：/verify meta 输出用的一段提示（含"未经同行评审终稿"口径）。
//
// 信号来源（只认显式元数据，不猜）：
//   · Crossref type === 'posted-content'（Crossref 对预印本的官方类型）
//   · OpenAlex type === 'preprint'
//   · arXiv 条目（arXiv 本身即预印本平台）
//   · DOI 已知预印本前缀：10.48550(arXiv)/10.1101(bioRxiv)/10.26434(ChemRxiv)/
//     10.21203(Research Square)/10.2139(SSRN)
//   · URL 主机：arxiv/biorxiv/medrxiv/chemrxiv/preprints.org/ssrn/researchsquare

export const PREPRINT_TAG = '预印本'

export const PREPRINT_DOI_PREFIXES = Object.freeze([
  '10.48550', // arXiv
  '10.1101', // bioRxiv
  '10.26434', // ChemRxiv
  '10.21203', // Research Square
  '10.2139', // SSRN
])

const PREPRINT_HOST_RE = /(arxiv\.org|biorxiv\.org|medrxiv\.org|chemrxiv\.org|preprints\.org|ssrn\.com|researchsquare\.com)/i

/** 从元数据抽预印本信号（纯函数，离线可测）。 */
export function parsePreprint({ crossrefMessage = null, openalexWork = null, arxivEntry = null, url = null, doi = null } = {}) {
  const signals = {}
  let preprint = false
  let source = null

  if (crossrefMessage && typeof crossrefMessage === 'object') {
    if (String(crossrefMessage.type || '') === 'posted-content') {
      preprint = true; source = source || 'crossref'; signals.crossref_type = 'posted-content'
    }
  }
  if (openalexWork && typeof openalexWork === 'object') {
    if (String(openalexWork.type || '') === 'preprint') {
      preprint = true; source = source || 'openalex'; signals.openalex_type = 'preprint'
    }
  }
  if (arxivEntry) {
    preprint = true; source = source || 'arxiv'; signals.arxiv = true
  }
  const doiStr = String(doi || '').toLowerCase()
  for (const prefix of PREPRINT_DOI_PREFIXES) {
    if (doiStr.startsWith(prefix.toLowerCase() + '/') || doiStr.startsWith(prefix.toLowerCase())) {
      preprint = true; source = source || 'doi-prefix'; signals.doiPrefix = prefix
      break
    }
  }
  const urlStr = String(url || '')
  if (urlStr && PREPRINT_HOST_RE.test(urlStr)) {
    preprint = true; source = source || 'url-host'; signals.urlHost = (urlStr.match(PREPRINT_HOST_RE) || [])[0] || null
  }
  return { preprint, source, signals }
}

/** 命中预印本 → 行内标记 [预印本]，否则空串。 */
export function tagPreprint(verdict) {
  return verdict && verdict.preprint ? '[' + PREPRINT_TAG + ']' : ''
}

/** /verify meta 用的一段提示（含保守口径与建议动作）。 */
export function renderPreprintNotice(verdict) {
  if (!verdict || !verdict.preprint) return ''
  const via = verdict.source ? `（信号源：${verdict.source}）` : ''
  return [
    `${tagPreprint(verdict)} 该条目为预印本${via}：尚未经过期刊同行评审终稿，引用时建议注明版本与检索时间，`,
    '重要结论优先替换为已发表的同行评审版本（或并引并说明差异）。',
  ].join('\n')
}

export default { parsePreprint, tagPreprint, renderPreprintNotice, PREPRINT_TAG, PREPRINT_DOI_PREFIXES, PREPRINT_HOST_RE }
