// packages/plugins/research-literature/index.mjs
//
// 科研核心插件：文献检索 / PDF 抽取 / 卡片笔记 / 混合检索索引 / 引用导出。
// 对应 docs/DOMAIN-smart-energy.md 的阅读流程：检索 → 抽取 → 结构化 → 追问 → 归档。
//
// 契约要点（其余细节见 lib/ 与 connectors/ 各自的文件头）：
//   · activate() 零副作用：不发网络请求、不写数据文件、不加载 Orama/unpdf/citation-js
//     （重依赖都在用到时才 await import，见各 lib 的懒加载函数）。
//   · 所有出网都经 ctx.net（宿主注入的 core net：白名单 + 令牌桶 + 429 退避 + 审计）。
//     本插件里没有第二个 fetch 出口 —— 这是可以直接 grep 验证的。
//   · 所有落盘都经 ctx.fs.scope(...)（宿主按 manifest 授权 + 路径夹逼 + safeWrite 审计）。
//     本插件里没有直接 import node:fs 的写函数 —— 唯一的 node:fs 导入是 existsSync
//     （/note image 对用户给的图片路径做只读存在性检查），可以直接 grep 验证。
//   · 密钥只在需要它的那次请求前从 data/secrets.json 读一次，值不落日志、不进面板。

import { existsSync } from 'node:fs'

import { loadSecrets } from '../../core/src/config.mjs'
import { APP_VERSION } from '../../core/src/version.mjs'

import { SEARCH_SOURCES, lookupRecordByDoi, searchAll } from './connectors/index.mjs'
import { lookupRetraction, tagRetracted, assertRetractionGate, RetractionError } from './connectors/retraction.mjs'
// S23·C1：预印本行内标记 [预印本]（保守口径：只认显式元数据，不猜同行评审状态）
import { parsePreprint, tagPreprint, renderPreprintNotice } from './connectors/preprint.mjs'
import { buildBibtex, exportBib, selfCheckBibtex } from './lib/bib.mjs'
import {
  CARD_FIELDS,
  buildCardPrompt,
  cardFromRecord,
  emptyCard,
  listAllCards,
  listCards,
  mergeDraft,
  readCard,
  renderCard,
  renderCardPreserving,
  validateCard,
  validateLlmDraft,
  writeCard,
} from './lib/cards.mjs'
import { listCandidateFiles, readCandidates, saveCandidates } from './lib/candidates.mjs'
import { renderVerifyReport, verifyAssertion, verifyAssertions } from './lib/cite-verify.mjs'
import { requestText } from './lib/http.mjs'
import { buildIndex, embedText, loadOrRebuild, rebuildIndex, searchIndex } from './lib/index-store.mjs'
import { expandQueryToEnglish, resolveQuery, slugify } from './lib/keywords.mjs'
import { LINKS_FILENAME, queryLinks, readLinksIndex, rebuildLinksIndex } from './lib/links.mjs'
import { askJson, collectChat } from './lib/llm.mjs'
import { buildDocx } from './lib/docx-export.mjs'
import { doiTrustForCandidates, DOI_TRUST_LABELS } from './lib/doi-trust.mjs'
import { buildLatexPair } from './lib/latex-export.mjs'
import { cardExcerpt, extractPdfFile } from './lib/pdf.mjs'
import { buildOutline, exportDocxOutline, exportSingleMarkdown, exportTopicMarkdown, renderOutlineMarkdown } from './lib/notemd.mjs'
import { runRecall } from './lib/recall.mjs'
import { buildTemplateCard, loadTemplates, TEMPLATE_NAMES, withSkeleton } from './lib/templates.mjs'
import { readZoteroExport } from './lib/zotero.mjs'
import {
  assessMetaCompleteness,
  checkQuantityConsistency,
  checkQuantities,
  extractQuantities,
  renderMetaCompleteness,
  renderQuantityReport,
  renderRigorAnswer,
} from './lib/rigor.mjs'
import { rankRecords, summarizeRecord } from './lib/record.mjs'
import { decodeXmlEntities } from './lib/xml.mjs'
import { readFileSync } from 'node:fs'

export const RESEARCH_LITERATURE_VERSION = APP_VERSION
export const PLUGIN_ID = 'research-literature'
export const CARD_ID = 'research.literature'

/** 默认参数集中在这里，方便审查"到底改了什么口径"。 */
export const DEFAULTS = Object.freeze({
  max: 12,
  minCandidates: 5,
  topic: 'inbox',
  cardModel: 'deepseek-chat',
  recallModel: 'deepseek-chat',
  topK: 5,
  trustLimit: 12, // /find 的 DOI 行内校验条数上限（防一次检索打满出网预算；--trust-limit 可调）
})

/** /verify 抓 URL 标题的独立限速键（与四个检索源分开计数，避免互相挤占）。 */
export const VERIFY_URL_LIMIT_KEY = 'research-literature:verify-url'

/** 本插件自己的私有目录名（卡片库遍历时要排除，别把自己的 state 当卡片）。 */
export const PRIVATE_TOPIC = PLUGIN_ID

// ---------------------------------------------------------------------------
// 纯函数小工具（单测直接打这些）
// ---------------------------------------------------------------------------

/**
 * 按空白切词，但双引号内的内容不分切、引号本身不进入 token。
 * 为什么需要：/verify doi X --title "Grid-Forming Inverter Control for ..." 这类
 * 多词参数值是该命令的主要用法，按纯空白切会把标题切碎（flags.title 只剩第一个词）。
 * 空引号 "" 仍产生一个空 token，与 shell 的直觉一致。
 */
function tokenizeQuoted(input) {
  const out = []
  let cur = ''
  let quoted = false
  let has = false
  for (const ch of String(input ?? '')) {
    if (ch === '"') {
      quoted = !quoted
      has = true
      continue
    }
    if (!quoted && /\s/.test(ch)) {
      if (has) {
        out.push(cur)
        cur = ''
        has = false
      }
      continue
    }
    cur += ch
    has = true
  }
  if (has) out.push(cur)
  return out
}

/** 剥掉 `--key value` / `--flag`，剩下的当正文。 */
export function splitFlags(rest) {
  const tokens = tokenizeQuoted(rest)
  const flags = {}
  const keep = []
  for (let i = 0; i < tokens.length; i += 1) {
    const t = tokens[i]
    if (t.startsWith('--') && t.length > 2) {
      const key = t.slice(2).toLowerCase()
      const next = tokens[i + 1]
      if (next !== undefined && !next.startsWith('--')) {
        flags[key] = next
        i += 1
      } else {
        flags[key] = true
      }
      continue
    }
    keep.push(t)
  }
  return { text: keep.join(' ').trim(), flags }
}

/** 判断 /card 的参数是 DOI 还是本地 PDF 路径。 */
export function classifyCardTarget(input) {
  const s = String(input || '').trim().replace(/^["']|["']$/g, '')
  if (!s) return { kind: 'empty', value: '' }
  if (/\.pdf$/i.test(s)) return { kind: 'pdf', value: s }
  if (/^10\.\d{4,9}\//.test(s)) return { kind: 'doi', value: s }
  if (/^https?:\/\/(dx\.)?doi\.org\//i.test(s)) return { kind: 'doi', value: s.replace(/^https?:\/\/(dx\.)?doi\.org\//i, '') }
  if (/^doi:/i.test(s)) return { kind: 'doi', value: s.replace(/^doi:/i, '') }
  // 没有明显特征：有路径分隔符或盘符就当文件，否则当 DOI 试试
  if (/[\\/]/.test(s) || /^[A-Za-z]:/.test(s)) return { kind: 'pdf', value: s }
  return { kind: 'doi', value: s }
}

/** 解析 `--find 1,3,5` 或 `--find 2-4`。 */
export function parseSelection(spec) {
  const out = new Set()
  for (const part of String(spec || '').split(/[,;\s]+/).filter(Boolean)) {
    const range = /^(\d+)\s*-\s*(\d+)$/.exec(part)
    if (range) {
      const a = Number.parseInt(range[1], 10)
      const b = Number.parseInt(range[2], 10)
      for (let i = Math.min(a, b); i <= Math.max(a, b); i += 1) out.add(i)
      continue
    }
    const n = Number.parseInt(part, 10)
    if (Number.isFinite(n) && n > 0) out.add(n)
  }
  return [...out].sort((a, b) => a - b)
}

function clip(s, n) {
  const t = String(s || '').replace(/\s+/g, ' ').trim()
  return t.length > n ? t.slice(0, n) + '…' : t
}

function pad(s, n) {
  const t = String(s ?? '')
  return t.length >= n ? clip(t, n) : t + ' '.repeat(n - t.length)
}

/** 源状态一行。 */
export function formatSourceLine(sources) {
  return (sources || [])
    .map((s) => {
      if (s.skipped) return `${s.source}:跳过(${s.reason})`
      if (!s.ok) return `${s.source}:失败(${s.error ? s.error.code : 'E_UNKNOWN'})`
      return `${s.source}:${s.entries}条${s.usedFallback ? '(无分类回退)' : ''}`
    })
    .join('  ')
}

/** 候选列表的文字表格。 */
export function formatCandidates(candidates, { limit = 12 } = {}) {
  const rows = candidates.slice(0, limit)
  const lines = []
  lines.push(`${pad('#', 4)}${pad('score', 7)}${pad('年', 6)}${pad('引用', 7)}${pad('venue', 26)}${pad('源', 16)}${pad('DOI 校验', 12)}标题`)
  rows.forEach((c, i) => {
    const s = summarizeRecord(c)
    const trust = c.doiTrust ? c.doiTrust.label : '-'
    lines.push(
      `${pad(i + 1, 4)}${pad(s.score === null ? '-' : s.score.toFixed(3), 7)}${pad(s.year ?? '-', 6)}${pad(s.citations ?? '-', 7)}${pad(s.venue, 26)}${pad((s.sources || []).join('/'), 16)}${pad(trust, 12)}${clip(c.title, 78)}`,
    )
  })
  if (candidates.length > limit) lines.push(`… 另有 ${candidates.length - limit} 条未列出（面板可看全部）`)
  return lines.join('\n')
}

export function formatDoi(candidate) {
  return candidate && candidate.doi ? candidate.doi : '(该条无 DOI，请用 URL 或 PDF 生成卡片)'
}

// ---------------------------------------------------------------------------
// 引擎
// ---------------------------------------------------------------------------

/**
 * 组装引擎。scope 可注入，便于单测使用内存版 scope（不落真实磁盘）。
 * @param {object} ctx 插件上下文
 * @param {{scopes?: object, secretsLoader?: Function}} [options]
 */
export function createEngine(ctx, options = {}) {
  const scopes = options.scopes || {
    notes: ctx.fs.scope('notes'),
    pdf: ctx.fs.scope('pdf'),
    index: ctx.fs.scope('index'),
    exports: ctx.fs.scope('exports'),
  }
  const secretsLoader = options.secretsLoader || (() => loadSecrets())
  const log = ctx.log || { info() {}, warn() {}, error() {} }
  const net = ctx.net

  let secretsCache = null
  /** 密钥只在本地读一次，且只以布尔形式对外流通（面板/日志永远看不到值）。 */
  function secretsInfo() {
    if (secretsCache) return secretsCache
    let doc = null
    try {
      doc = secretsLoader() || {}
    } catch {
      doc = {}
    }
    const mailto = typeof doc.openalex?.mailto === 'string' ? doc.openalex.mailto.trim() : ''
    const s2Key = typeof doc.semanticscholar?.apiKey === 'string' ? doc.semanticscholar.apiKey.trim() : ''
    secretsCache = {
      openalexMailto: mailto || null,
      s2ApiKey: s2Key || null,
      s2Configured: s2Key.length > 0,
      openalexPolite: mailto.length > 0,
    }
    return secretsCache
  }

  /** 当前全部卡片（排除本插件私有目录）。 */
  function allCards() {
    return listAllCards(scopes.notes, { excludeTopics: [PRIVATE_TOPIC] })
  }

  /** 卡片 → 索引条目。 */
  function indexEntries() {
    return allCards()
      .filter((c) => c.ok && c.card)
      .map((c) => {
        const parts = String(c.rel).split('/')
        return { ok: true, rel: c.rel, topic: parts[0] || '', slug: (parts[1] || '').replace(/\.md$/i, ''), card: c.card, content: c.content || '' }
      })
  }

  /**
   * 重建索引，并把"同一篇论文被归档到多个主题"的合并情况**记进日志**。
   * 静默丢弃一份卡片是不可接受的：用户会以为两张卡都在索引里。
   * 这里给出保留/丢弃的具体路径，用户据此决定要不要清理重复归档。
   */
  async function rebuildIndexSafe() {
    const built = await rebuildIndex(scopes.index, indexEntries())
    const m = built.manifest || {}
    const duplicateCount = Number(m.duplicateCount || 0)
    if (duplicateCount > 0) {
      log.warn(
        `索引合并了 ${duplicateCount} 组同论文卡片（同一 DOI 归在多个主题）：` +
          (m.duplicates || []).map((d) => `${d.id} → 保留 ${d.kept}，丢弃 ${d.dropped.join(' / ')}`).join('；'),
      )
    }
    return { count: Number(m.count || 0), duplicateCount, duplicates: m.duplicates || [] }
  }

  /**
   * 重建反向链接索引（块 3 交付 1）。派生品：失败只告警不阻断写卡
   * （链接查询在索引缺失时会明说"尚未建立"，不会拿旧索引装新数据）。
   */
  function rebuildLinksSafe() {
    try {
      const index = rebuildLinksIndex(scopes.notes)
      scopes.notes.writeJson(LINKS_FILENAME, index)
      return index
    } catch (err) {
      log.warn(`链接索引重建失败（派生品，不阻断）：${String(err && err.message)}`)
      return null
    }
  }

  /** 卡片总数（不解析 front-matter，activate 时用它，保持零重活）。 */
  function quickCardCount() {
    let n = 0
    let topics = []
    try {
      topics = scopes.notes.list('')
    } catch {
      return 0
    }
    for (const t of topics) {
      const name = String(t).split('/').pop()
      if (name.includes('.') || name === PRIVATE_TOPIC) continue
      try {
        n += scopes.notes.list(name).filter((r) => String(r).endsWith('.md')).length
      } catch {
        /* 目录不可读就跳过 */
      }
    }
    return n
  }

  function indexManifest() {
    try {
      return scopes.index.exists('literature.manifest.json') ? scopes.index.readJson('literature.manifest.json') : null
    } catch {
      return null
    }
  }

  /** 面板卡片与 /find 头部共享的状态摘要。 */
  function status() {
    const s = secretsInfo()
    const manifest = indexManifest()
    return {
      version: RESEARCH_LITERATURE_VERSION,
      cards: quickCardCount(),
      indexCount: manifest && Number.isFinite(manifest.count) ? manifest.count : null,
      indexBuiltAt: manifest ? manifest.builtAt || manifest.persistedAt || null : null,
      sources: [...SEARCH_SOURCES],
      s2Configured: s.s2Configured,
      openalexPolite: s.openalexPolite,
      candidates: listCandidateFiles(scopes.index).length,
      scopes: Object.keys(scopes),
      max: DEFAULTS.max,
      minCandidates: DEFAULTS.minCandidates,
    }
  }

  // --- /find ---------------------------------------------------------------

  async function find(rawQuery, flags = {}) {
    const resolved = resolveQuery(rawQuery)
    if (!resolved.query) {
      return { ok: false, code: 'E_EMPTY_QUERY', text: '用法：/find <关键词>，例如 /find gfm 或 /find grid-forming inverter inertia support' }
    }
    const max = Number.parseInt(flags.max, 10) > 0 ? Number.parseInt(flags.max, 10) : DEFAULTS.max
    const minCandidates = Number.parseInt(flags.min, 10) > 0 ? Number.parseInt(flags.min, 10) : DEFAULTS.minCandidates
    const s = secretsInfo()
    const result = await searchAll({
      net,
      query: resolved.query,
      max,
      openalexMailto: s.openalexMailto,
      s2ApiKey: s.s2ApiKey,
      minCandidates,
    })
    const saved = saveCandidates(scopes.index, {
      query: resolved.query,
      clusterId: resolved.clusterId,
      searchedAt: result.searchedAt,
      sources: result.sources,
      candidates: result.candidates,
      stats: result.stats,
    })
    log.info(
      `find "${resolved.query}" → 候选 ${result.candidates.length}（原始 ${result.stats.raw}，合并重复 ${result.stats.duplicates}），落盘 ${saved.rel}`,
    )

    const trustLimit = Number.parseInt(flags['trust-limit'], 10) > 0 ? Number.parseInt(flags['trust-limit'], 10) : DEFAULTS.trustLimit
    // 镜 2：行内可信标记——DOI 收录档位（复用 connectors 同一抓取器，不另写判定）
    let trustMap = new Map()
    let trustNote = ''
    if (flags['no-trust'] === true) {
      trustNote = '（已按 --no-trust 跳过 DOI 校验）'
    } else {
      trustMap = await doiTrustForCandidates(result.candidates, { net, mailto: s.openalexMailto, limit: trustLimit })
      const dual = [...trustMap.values()].filter((t) => t.status === 'dual').length
      const single = [...trustMap.values()].filter((t) => t.status === 'single').length
      const none = [...trustMap.values()].filter((t) => t.status === 'none').length
      trustNote = `DOI 校验（Crossref/OpenAlex 双源，同一判定源）：✓双源 ${dual} · ⚠仅单源 ${single} · ✗未收录 ${none}`
      log.info(`find "${resolved.query}" DOI 校验：dual=${dual} single=${single} none=${none}`)
    }
    const withTrust = result.candidates.map((c) => ({ ...c, doiTrust: trustMap.get(c) || null }))

    const head = [
      `检索：${resolved.query}${resolved.expanded ? `（由 "${resolved.input}" 展开自主题簇「${resolved.clusterName}」）` : ''}`,
      `源状态：${formatSourceLine(result.sources)}`,
      `去重：原始 ${result.stats.raw} → 候选 ${result.candidates.length}（合并 ${result.stats.duplicates} 条跨源重复）`,
      `阈值：需要 ≥${minCandidates} 条 → ${result.stats.enough ? '已满足' : `未满足（只有 ${result.candidates.length} 条）`}`,
      trustNote,
      '',
    ].join('\n')

    const table = result.candidates.length > 0 ? formatCandidates(withTrust) : '（没有任何候选。检查网络或换个关键词。）'

    const foot = [
      '',
      `已落盘：data/index/${saved.rel.replace(/\\/g, '/')}`,
      '下一步：/card <doi> 生成单张卡片；或 /card --find 1,2,3 批量生成（编号即上表 # 列）',
    ].join('\n')

    const text = head + table + '\n' + foot
    return {
      ok: result.ok,
      code: result.ok ? null : 'E_NO_CANDIDATE',
      text,
      ui: { kind: 'candidates', query: resolved.query, input: resolved.input, clusterName: resolved.clusterName, searchedAt: result.searchedAt, sources: result.sources, stats: result.stats, trustNote, candidates: withTrust.map((c) => ({ ...summarizeRecord(c), key: c.key, abstract: clip(c.abstract, 400), doiTrust: c.doiTrust })) },
    }
  }

  /** /find --last：不重新检索，重放最近一次候选集（DOI 档位当场重算——判定源不变）。 */
  async function findLast(flags = {}) {
    const latest = latestCandidates()
    if (!latest) {
      return { ok: false, code: 'E_NO_CANDIDATES', text: '还没有候选集，请先执行 /find <关键词>' }
    }
    const s = secretsInfo()
    const trustLimit = Number.parseInt(flags['trust-limit'], 10) > 0 ? Number.parseInt(flags['trust-limit'], 10) : DEFAULTS.trustLimit
    const trustMap = flags['no-trust'] === true
      ? new Map()
      : await doiTrustForCandidates(latest.candidates, { net, mailto: s.openalexMailto, limit: trustLimit })
    const withTrust = latest.candidates.map((c) => ({ ...c, doiTrust: trustMap.get(c) || null }))
    const dual = [...trustMap.values()].filter((t) => t.status === 'dual').length
    const single = [...trustMap.values()].filter((t) => t.status === 'single').length
    const none = [...trustMap.values()].filter((t) => t.status === 'none').length
    const head = [
      `重放候选集：${latest.query}（检索于 ${latest.searchedAt}，未重新检索）`,
      `DOI 校验（当场重算，Crossref/OpenAlex 同一判定源）：✓双源 ${dual} · ⚠仅单源 ${single} · ✗未收录 ${none}`,
      '',
    ].join('\n')
    const table = formatCandidates(withTrust)
    const text = head + table + '\n\n已落盘：data/index/' + String(latest.rel || '').replace(/\\/g, '/')
    return {
      ok: true,
      code: null,
      text,
      ui: { kind: 'candidates', query: latest.query, input: latest.query, clusterName: null, searchedAt: latest.searchedAt, sources: latest.sources || [], stats: latest.stats || {}, replay: true, trustNote: head.split('\n')[1], candidates: withTrust.map((c) => ({ ...summarizeRecord(c), key: c.key, abstract: clip(c.abstract, 400), doiTrust: c.doiTrust })) },
    }
  }

  // --- PDF 抽取 -----------------------------------------------------------

  async function extractAndStore(pdfPath) {
    const doc = await extractPdfFile(pdfPath)
    const rel = `${doc.shortHash}.json`
    const written = scopes.pdf.writeJson(rel, doc)
    log.info(`PDF 抽取 ${pdfPath} → data/pdf/${rel}（${doc.pages ?? '?'} 页 / ${doc.chars} 字符 / 分节 ${doc.sectionOrder.join('+') || '未识别'}）`)
    return { doc, rel: `data/pdf/${rel}`, bytes: written.bytes }
  }

  // --- /card ---------------------------------------------------------------

  async function buildOneCard({ record, topic, pdfRel = null, extraction = null, useLlm = true, model = DEFAULTS.cardModel, signal = null }) {
    const notes = { topic, pdfRel, extraction }
    if (!useLlm || !ctx.llm || !ctx.llm.available) {
      const base = cardFromRecord(record, notes)
      return { ...base, generatedBy: 'heuristic', fieldsFromLlm: [], llmNote: useLlm ? '宿主未注入 llm' : '按 --heuristic 跳过模型' }
    }
    const excerpt = extraction ? cardExcerpt(extraction) : clip(record.abstract, 2500)
    const r = await askJson(ctx.llm, {
      system: '你是一个严格的科研信息抽取器。任何无法从材料中确认的内容都不要编造。',
      prompt: buildCardPrompt({ record, extraction, topic, excerpt }),
      model,
      signal,
    })
    if (!r.ok) {
      // 区分两类失败，因为处置方式完全不同：
      //   · 模型**答了但不是合法 JSON** → 这是"输出不符合约定的结构"，按命题要求报错、不写盘；
      //   · 模型**压根没答成**（网络/限流/超时）→ 这不是卡片格式问题，退回确定性草案更符合用户预期。
      if (r.error && r.error.code === 'E_LLM_NOT_JSON') {
        return {
          ok: false,
          code: 'E_CARD_SCHEMA',
          errors: [r.error.message],
          generatedBy: 'llm-invalid',
          card: null,
          llmNote: '模型输出不是合法 JSON，已拒绝写盘；可加 --heuristic 改用确定性草案',
        }
      }
      const base = cardFromRecord(record, notes)
      return {
        ...base,
        generatedBy: 'heuristic',
        fieldsFromLlm: [],
        llmNote: `模型调用失败(${(r.error && r.error.code) || 'E_LLM'})，已退回确定性草案`,
      }
    }
    const draftCheck = validateLlmDraft(r.json)
    if (!draftCheck.ok) {
      return {
        ok: false,
        code: 'E_CARD_SCHEMA',
        errors: draftCheck.errors,
        generatedBy: 'llm-invalid',
        card: null,
        llmNote: `模型输出不符合卡片 schema：${draftCheck.errors.join('; ')}（已拒绝写盘；可加 --heuristic 改用确定性草案）`,
      }
    }
    const merged = mergeDraft(record, r.json, notes)
    if (!merged.ok) {
      return {
        ok: false,
        code: 'E_CARD_SCHEMA',
        errors: merged.errors,
        generatedBy: 'llm-invalid',
        card: null,
        llmNote: `合并后仍不符合 schema：${merged.errors.join('; ')}（未写盘；可加 --heuristic 用确定性草案）`,
      }
    }
    return { ...merged, generatedBy: 'llm', llmNote: `模型 ${r.model || model} 生成 ${merged.fieldsFromLlm.length}/7 个解释性字段` }
  }

  async function cardFromTarget(target, flags = {}) {
    const topic = typeof flags.topic === 'string' && flags.topic ? flags.topic : DEFAULTS.topic
    const useLlm = flags.heuristic ? false : true
    const model = typeof flags.model === 'string' && flags.model ? flags.model : DEFAULTS.cardModel

    // 路径 1：--find N[,M] —— 从最近一次候选集里取
    if (flags.find !== undefined && flags.find !== true) {
      return cardFromFindSelection(String(flags.find), { topic, useLlm, model })
    }

    const cls = classifyCardTarget(target)
    if (cls.kind === 'empty') {
      return { ok: false, code: 'E_EMPTY_TARGET', text: '用法：/card <DOI | PDF 路径> [--topic <名>] [--heuristic] [--find 1,3]' }
    }

    let record = null
    let via = null
    let extraction = null
    let pdfRel = null
    let derivedFrom = null

    if (cls.kind === 'pdf') {
      const ex = await extractAndStore(cls.value)
      extraction = ex.doc
      pdfRel = ex.rel
      derivedFrom = 'local-pdf'
      // 先看看 PDF 里有没有 DOI（首页常有），有就直接用它去换权威元数据
      const doiMatch = /10\.\d{4,9}\/[^\s"'<>)]+/.exec(String(extraction.text || '').slice(0, 6000))
      const pdfDoi = doiMatch ? doiMatch[0].replace(/[.,;]$/, '') : null
      if (pdfDoi) {
        const looked = await lookupRecordByDoi({ net, doi: pdfDoi, mailto: secretsInfo().openalexMailto })
        if (looked.ok) {
          record = looked.record
          via = `${looked.via}(由 PDF 内 DOI 反查)`
        }
      }
      if (!record) {
        // 退化：只用本地 PDF 自身的信息。绝不臆造 DOI/年份/venue。
        const head = String(extraction.sections?.abstract?.text || extraction.text || '').split(/\r?\n/).filter(Boolean)[0] || ''
        record = {
          title: clip(head, 180) || `本地 PDF ${cls.value.split(/[\\/]/).pop()}`,
          authors: [],
          venue: '(本地 PDF，未取得元数据)',
          year: null,
          doi: null,
          url: null,
          abstract: extraction.sections?.abstract?.text || extraction.text.slice(0, 1200),
          citations: null,
          source: 'local-pdf',
          sources: ['local-pdf'],
          venueTier: 'none',
        }
        via = 'local-pdf'
      }
    } else {
      // 先零网络地在已存候选里找
      const cached = findByDoiInCandidates(cls.value)
      if (cached) {
        record = cached.record
        via = `candidates:${cached.from}`
      } else {
        const looked = await lookupRecordByDoi({ net, doi: cls.value, mailto: secretsInfo().openalexMailto })
        if (!looked.ok) {
          return {
            ok: false,
            code: 'E_DOI_NOT_FOUND',
            text: `未能解析 DOI：${cls.value}\n尝试过的源：${looked.attempts.map((a) => `${a.source}(${a.ok ? 'ok' : a.error.code})`).join(' / ')}\n提示：先 /find 检索，再从候选列表里生成；或直接拖入本地 PDF 走 /card <pdf 路径>`,
          }
        }
        record = looked.record
        via = looked.via
      }
    }

    const built = await buildOneCard({ record, topic, pdfRel, extraction, useLlm, model })
    if (!built.ok) {
      return {
        ok: false,
        code: built.code || 'E_CARD_BUILD',
        text: `卡片生成失败：${built.llmNote || built.errors?.join('; ')}`,
        ui: { kind: 'card-error', errors: built.errors || [], generatedBy: built.generatedBy },
      }
    }

    const written = writeCard({
      notes: scopes.notes,
      topic,
      card: built.card,
      meta: {
        generatedBy: built.generatedBy,
        fieldsFromLlm: built.fieldsFromLlm || [],
        model: built.generatedBy === 'llm' ? model : null,
        biblioVia: via,
        sources: record.sources || [record.source],
        pdfRel,
        pdfHash: extraction ? extraction.hash : null,
      },
    })
    const rebuilt = await rebuildIndexSafe()
    rebuildLinksSafe()
    const elsewhere = sameDoiElsewhere(written.overwritten ? null : written.rel, built.card.doi)

    log.info(`card 写入 data/notes/${written.rel}（${built.generatedBy}），索引重建 ${rebuilt.count} 条`)

    const text = [
      `卡片已写入：data/notes/${written.rel}${written.overwritten ? '（覆盖同名卡片）' : ''}`,
      `字段：16/16 齐全（字段名逐字取自 DOMAIN-smart-energy.md 第 4 节）`,
      `书目来源：${via}`,
      `解释性字段：${built.generatedBy === 'llm' ? `LLM（${model}）生成 ${(built.fieldsFromLlm || []).length}/7` : `确定性草案（${built.llmNote}）`}`,
      extraction ? `抽取文本：${pdfRel}（${extraction.pages ?? '?'} 页 / ${extraction.chars} 字符 / 分节：${extraction.sectionOrder.join(' → ') || '未识别'}）` : '抽取文本：（仅元数据，无本地 PDF）',
      `索引：已重建，当前 ${rebuilt.count} 条${rebuilt.duplicateCount ? `（同论文合并 ${rebuilt.duplicateCount} 组）` : ''}`,
      elsewhere ? `提醒：同一 DOI 还存在于 ${elsewhere.join('、')}；索引里按论文身份只保留一张（读数高的优先），重复卡片仍留在磁盘上。` : '',
    ]
      .filter(Boolean)
      .join('\n')

    return {
      ok: true,
      text,
      ui: {
        kind: 'card',
        topic: written.topic,
        slug: written.slug,
        rel: `data/notes/${written.rel}`,
        card: built.card,
        generatedBy: built.generatedBy,
        fieldsFromLlm: built.fieldsFromLlm || [],
        biblioVia: via,
        pdfRel,
        indexCount: rebuilt.count,
        duplicateDoiElsewhere: elsewhere,
      },
    }
  }

  /** 同一 DOI 是否已归档在别的卡片里（换主题重复归档时提醒用户，而不是默默留两份）。 */
  function sameDoiElsewhere(justWrittenRel, doi) {
    if (!doi) return null
    const want = String(doi).toLowerCase()
    const rels = allCards()
      .filter((c) => c.ok && c.card && String(c.card.doi || '').toLowerCase() === want)
      .map((c) => c.rel)
      .filter((rel) => rel !== justWrittenRel)
    return rels.length > 0 ? rels : null
  }

  function findByDoiInCandidates(doi) {
    const clean = String(doi || '').toLowerCase().replace(/^https?:\/\/(dx\.)?doi\.org\//, '')
    for (const f of listCandidateFiles(scopes.index)) {
      const doc = readCandidates(scopes.index, f.rel)
      if (!doc) continue
      const hit = doc.candidates.find((c) => c.doi && String(c.doi).toLowerCase() === clean)
      if (hit) return { record: hit, from: f.rel }
    }
    return null
  }

  /** 最近一次有候选的检索。 */
  function latestCandidates() {
    for (const f of listCandidateFiles(scopes.index)) {
      const doc = readCandidates(scopes.index, f.rel)
      if (doc && doc.candidates.length > 0) return { ...doc, rel: f.rel }
    }
    return null
  }

  async function cardFromFindSelection(spec, { topic, useLlm, model }) {
    const nums = parseSelection(spec)
    if (nums.length === 0) {
      return { ok: false, code: 'E_BAD_SELECTION', text: '用法：/card --find 1,3,5（编号来自 /find 输出表的第一列）' }
    }
    const latest = latestCandidates()
    if (!latest) {
      return { ok: false, code: 'E_NO_CANDIDATES', text: '还没有候选集，请先执行 /find <关键词>' }
    }
    const picked = []
    const missing = []
    for (const n of nums) {
      const c = latest.candidates[n - 1]
      if (c) picked.push(c)
      else missing.push(n)
    }
    if (picked.length === 0) {
      return { ok: false, code: 'E_BAD_SELECTION', text: `编号超出范围（最近一次检索「${latest.query}」只有 ${latest.candidates.length} 条）：${nums.join(',')}` }
    }
    const results = []
    const lines = [`批量生成卡片（来自最近一次检索「${latest.query}」${latest.searchedAt}）`]
    if (missing.length > 0) lines.push(`忽略越界编号：${missing.join(',')}`)
    for (const [i, c] of picked.entries()) {
      const built = await buildOneCard({ record: c, topic, pdfRel: null, extraction: null, useLlm, model })
      if (!built.ok) {
        lines.push(`  ${nums[i]} ✗ ${clip(c.title, 50)}：${built.llmNote || built.errors.join('; ')}`)
        results.push({ index: nums[i], ok: false, code: built.code, title: c.title })
        continue
      }
      const written = writeCard({
        notes: scopes.notes,
        topic,
        card: built.card,
        meta: { generatedBy: built.generatedBy, fieldsFromLlm: built.fieldsFromLlm || [], model: built.generatedBy === 'llm' ? model : null, biblioVia: `candidates:${latest.rel}`, sources: c.sources || [c.source] },
      })
      lines.push(`  ${nums[i]} ✓ ${clip(c.title, 50)} → data/notes/${written.rel}`)
      results.push({ index: nums[i], ok: true, rel: `data/notes/${written.rel}`, topic: written.topic, slug: written.slug, card: built.card, generatedBy: built.generatedBy, title: c.title })
    }
    const rebuilt = await rebuildIndexSafe()
    // 链接索引落 notes 作用域：只有真的写了卡才重建——"报错零写盘"契约不容破例
    if (results.some((r) => r.ok)) rebuildLinksSafe()
    lines.push(
      `完成：成功 ${results.filter((r) => r.ok).length}/${nums.length}；索引已重建，当前 ${rebuilt.count} 条` +
        (rebuilt.duplicateCount ? `（同论文合并 ${rebuilt.duplicateCount} 组，详见 data/logs/plugins.jsonl 的 warn 行）` : ''),
    )
    return {
      ok: results.some((r) => r.ok),
      text: lines.join('\n'),
      ui: { kind: 'cards-batch', results, indexCount: rebuilt.count, duplicateCount: rebuilt.duplicateCount, query: latest.query },
    }
  }

  // --- /bib ----------------------------------------------------------------

  async function bib(topicArg = '', flags = {}) {
    const topic = String(topicArg || '').trim()
    const all = allCards().filter((c) => c.ok && c.card)
    let cards = []
    let scopeLabel = ''
    if (topic && topic !== '*' && topic.toLowerCase() !== 'all') {
      const t = slugify(topic, { max: 40 })
      cards = all.filter((c) => String(c.rel).split('/')[0] === t).map((c) => c.card)
      scopeLabel = `主题 ${t}`
    } else {
      cards = all.map((c) => c.card)
      scopeLabel = '全部卡片'
    }
    if (cards.length === 0) {
      return { ok: false, code: 'E_NO_CARD', text: `没有可导出的卡片（${scopeLabel}）。先用 /find + /card 归档几篇。可用主题：${[...new Set(all.map((c) => String(c.rel).split('/')[0]))].join(', ') || '（暂无）'}` }
    }
    const date = typeof flags.date === 'string' ? flags.date : null
    const out = await exportBib({ exportsScope: scopes.exports, topic: topic && topic !== '*' ? topic : 'library', cards, date })
    log.info(`bib 导出 data/exports/${out.file}（${out.entries.length} 条），自检 ${out.check.ok ? '通过' : '未通过'}`)

    const text = [
      `导出：data/exports/${out.file}（${out.entries.length} 条 / ${out.bytes} 字节；范围：${scopeLabel}）`,
      `自检（citation-js 回读）：${out.check.ok ? '通过' : '未通过'}`,
      `  解析条数：${out.check.parsed}/${out.check.expected}`,
      `  DOI 保留：${out.check.dois.parsed.length}/${out.check.dois.expected.length}${out.check.missingDoi.length ? `（丢失：${out.check.missingDoi.join(', ')}）` : ''}`,
      out.check.error ? `  说明：${out.check.error}` : '',
      `引用键：${out.keys.slice(0, 8).join(', ')}${out.keys.length > 8 ? ` …（共 ${out.keys.length} 个）` : ''}`,
    ]
      .filter(Boolean)
      .join('\n')
    return { ok: out.check.ok, code: out.check.ok ? null : 'E_BIB_SELFCHECK', text, ui: { kind: 'bib', file: out.file, rel: out.rel, count: out.entries.length, keys: out.keys, bytes: out.bytes, check: out.check, sample: out.bib.slice(0, 1600) } }
  }

  // --- /recall -------------------------------------------------------------

  /**
   * 混合检索 + 中英文双路。
   *
   * 为什么要双路：卡片正文是英文的，而用户经常用中文提问（"构网型逆变器的惯量支撑…"）。
   * 纯中文查询在 Orama 上必然零命中 —— 不是索引坏了，是词根完全不相交。
   * 所以命中中文别名时，用该主题簇的英文关键词再检索一次，两路结果取并集（同一条取高分）。
   * 不这么做，"问答"功能对中文用户就是坏的，而中文用户是这个工具的主要用户。
   */
  async function hybridRetrieve(db, question, topK) {
    const primary = await searchIndex(db, { term: question, mode: 'hybrid', limit: topK })
    const expansion = expandQueryToEnglish(question)
    if (!expansion || !expansion.query || expansion.query.trim().toLowerCase() === String(question).trim().toLowerCase()) {
      return { ...primary, expansion: null }
    }
    const secondary = await searchIndex(db, { term: expansion.query, mode: 'hybrid', limit: topK })
    const merged = mergeHits(primary.hits, secondary.hits, topK)
    return {
      mode: `${primary.mode}+expanded`,
      term: question,
      expansion,
      hits: merged,
      branches: [
        { term: question, hits: primary.hits.length, mode: primary.mode },
        { term: expansion.query, hits: secondary.hits.length, mode: secondary.mode },
      ],
    }
  }

  async function recall(question, flags = {}) {
    const q = String(question || '').trim()
    if (!q) return { ok: false, code: 'E_EMPTY_QUESTION', text: '用法：/recall <问题>，例如 /recall 构网型逆变器的惯量支撑有哪些实现路径' }
    const topK = Number.parseInt(flags.top, 10) > 0 ? Number.parseInt(flags.top, 10) : DEFAULTS.topK
    const entries = indexEntries()
    if (entries.length === 0) {
      return { ok: false, code: 'E_INDEX_EMPTY', text: '卡片库为空，先 /find + /card 归档几篇再来提问。' }
    }
    const loaded = await loadOrRebuild(scopes.index, entries)
    const searched = await hybridRetrieve(loaded.db, q, topK)
    const model = typeof flags.model === 'string' ? flags.model : DEFAULTS.recallModel
    const llm = ctx.llm && ctx.llm.available ? ctx.llm : null
    const result = await runRecall({
      hits: searched.hits,
      question: q,
      topic: typeof flags.topic === 'string' ? flags.topic : null,
      llm,
      model,
      ask: llm ? async ({ prompt, model: m }) => askRaw(llm, prompt, m) : null,
    })
    log.info(
      `recall "${clip(q, 40)}" → 命中 ${searched.hits.length}（${searched.mode}${searched.degradedFrom ? '，向量降级' : ''}），模式 ${result.mode}`,
    )
    const expandLine = searched.expansion
      ? `检索式扩展：命中中文/别名「${searched.expansion.matched.join('、')}」→ 追加英文检索式 "${searched.expansion.query}"（两路取并集）`
      : null
    const text = [
      `问答（检索 ${searched.hits.length} 张卡片，模式 ${searched.mode}${searched.degradedFrom ? ` → 已从 ${searched.degradedFrom} 降级` : ''}）`,
      expandLine,
      '',
      result.answer,
    ]
      .filter((l) => l !== null)
      .join('\n')
    return {
      ok: result.mode !== 'empty',
      text,
      ui: {
        kind: 'recall',
        question: q,
        mode: result.mode,
        answer: result.answer,
        citations: result.citations,
        citedByModel: result.citedByModel,
        searchMode: searched.mode,
        expansion: searched.expansion,
        branches: searched.branches || null,
        hitCount: searched.hits.length,
        indexCount: loaded.manifest ? loaded.manifest.count : null,
        rebuilt: !!loaded.rebuilt,
      },
    }
  }

  /** 两路命中并集：同一条（DOI/URL/rel）取更高分。 */
  function mergeHits(a, b, limit) {
    const keyOf = (h) => {
      const d = h.document || {}
      return d.doi || d.url || d.rel || h.id
    }
    const map = new Map()
    for (const h of [...(a || []), ...(b || [])]) {
      const k = keyOf(h)
      const prev = map.get(k)
      if (!prev || (h.score ?? 0) > (prev.score ?? 0)) map.set(k, h)
    }
    return [...map.values()]
      .sort((x, y) => (y.score ?? 0) - (x.score ?? 0))
      .slice(0, Math.max(1, limit))
  }

  /** 取一次完整文本回复（不落会话）。 */
  async function askRaw(llm, prompt, model) {
    const iterable = llm.chat({ ...(model ? { model } : {}), messages: [{ role: 'user', content: prompt }] })
    return collectChat(iterable)
  }

  // --- 引用校验（P-R4 块 1，产品红线）---------------------------------------

  /**
   * 引用校验的三个依赖，全部经宿主 net / 本机文件，测试可整体换桩。
   * 出网仍然只有 ctx.net 一个出口（DOI 双源解析复用 lookupRecordByDoi，
   * URL 标题抓取走 requestText —— 都记 net.jsonl 审计）。
   */
  function verifyDeps() {
    const s = secretsInfo()
    return {
      resolveDoi: async (doi) => {
        const r = await lookupRecordByDoi({ net, doi, mailto: s.openalexMailto })
        if (r.ok && r.record) return { source: r.via, record: r.record }
        // 两源都失败时按失败性质分流，**不能**一律当成"查不到"：
        // 全部 404/未收录/格式错 → 引用不成立（拒引）；
        // 任一源是网络/服务错误 → 校验未完成（无法校验，环境恢复后可重试）。
        const codes = (r.attempts || []).map((a) => (a.error && a.error.code) || 'E_UNKNOWN')
        const notFound = new Set(['E_NOT_FOUND', 'E_HTTP_404'])
        const badDoi = new Set(['E_BAD_DOI', 'E_HTTP_400'])
        const err = new Error(
          codes.every((c) => notFound.has(c))
            ? `Crossref 与 OpenAlex 均未收录 DOI -> ${doi}`
            : `DOI 解析未完成 -> ${doi}（${codes.join('/')}）`,
        )
        err.code = codes.every((c) => notFound.has(c)) ? 'E_NOT_FOUND' : codes.every((c) => badDoi.has(c)) ? 'E_BAD_DOI' : 'E_NET'
        throw err
      },
      readPdfText: async (filePath) => {
        const doc = await extractPdfFile(filePath)
        return { text: doc.text, pages: doc.pages }
      },
      resolveUrl: async (url) => {
        const { text: html } = await requestText(net, url, { limitKey: VERIFY_URL_LIMIT_KEY })
        const m = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(html)
        const title = m ? decodeXmlEntities(m[1]).replace(/\s+/g, ' ').trim() : ''
        return { title: title || null, url }
      },
    }
  }

  /** 把 --title/--year/--author flags 收成题录断言（全空返回 null，让校验器走"弱通过"）。 */
  function claimFromFlags(flags) {
    const authorFlag = flags.author ?? flags.authors ?? null
    const claim = {
      title: typeof flags.title === 'string' && flags.title.trim() ? flags.title.trim() : null,
      year: typeof flags.year === 'string' && flags.year.trim() ? flags.year : null,
      authors: typeof authorFlag === 'string' ? authorFlag.split(/[,;，；]/).map((a) => a.trim()).filter(Boolean) : null,
    }
    return claim.title || claim.year || claim.authors ? claim : null
  }

  /**
   * /verify —— 引用校验（块 1）+ 严谨性检查（块 2）的对外命令。
   * 用法：/verify doi <DOI> [--title <题名>] [--year <年>] [--author <作者>]
   *       /verify quote <引文> --pdf <本地PDF路径> [--page N]
   *       /verify numbers <文本> [--pdf <本地PDF路径>]           （数值与单位校验 + 回溯原文）
   *       /verify meta <DOI|URL|PDF路径> […]                     （元数据完整性：预印本/版本/检索时间/DOI 可解析性）
   *       /verify answer --file <断言JSON路径>                    （多断言总装：三档强度 + 未验证断言区 + 严谨性两区）
   * 校验失败时 ok=false，文案必含「引用校验失败（原因）」；无法校验时同样不得作为结论依据。
   */
  async function verify(rest) {
    const { text, flags } = splitFlags(rest)
    const parts = text.split(/\s+/).filter(Boolean)
    const sub = (parts[0] || '').toLowerCase()
    const body = parts.slice(1).join(' ')
    const usage =
      '用法：/verify doi <DOI> [--title <题名>] [--year <年>] [--author <作者>]；/verify quote <引文> --pdf <本地PDF路径> [--page N]；/verify numbers <文本> [--pdf <本地PDF路径>]；/verify meta <DOI|URL|PDF路径> [--title <题名>] [--quote <引文>]；/verify answer --file <断言JSON路径>'
    if (sub === 'numbers') return verifyNumbers(body, flags, usage)
    if (sub === 'meta') return verifyMeta(body, flags, usage)
    if (sub === 'answer') return verifyAnswer(flags, usage)
    if (sub !== 'doi' && sub !== 'quote') return { ok: false, code: 'E_BAD_ARGS', text: usage }
    if (!body) return { ok: false, code: 'E_BAD_ARGS', text: usage }

    let source
    if (sub === 'doi') {
      // S20·B：撤稿闸门——命中撤稿且以"已证实"话术导出则拒（照 E_NOT_PUBLISHED 模式）
      try {
        const retr = await lookupRetraction(body, { net })
        const claimText = [body, (claimFromFlags(flags) || {}).title].filter(Boolean).join(' ')
        assertRetractionGate({ doi: body, retracted: retr.retracted, text: claimText })
      } catch (e) {
        if (e instanceof RetractionError) {
          return { ok: false, code: e.code, text: '撤稿闸门：' + e.message + '\n引导：' + e.guidance, ui: { kind: 'verify', retractionGate: true, code: e.code, guidance: e.guidance } }
        }
        throw e
      }
      source = { kind: 'doi', ref: body, claim: claimFromFlags(flags) }
    } else {
      if (!flags.pdf || typeof flags.pdf !== 'string') {
        return { ok: false, code: 'E_BAD_ARGS', text: `PDF 引文校验需要 --pdf <本地PDF路径>。${usage}` }
      }
      source = { kind: 'pdf', ref: flags.pdf, locator: { quote: body, page: flags.page } }
    }

    const result = await verifyAssertion(
      { text: sub === 'doi' ? `引用「${body}」` : `引用「${clip(body, 60)}」`, strength: 'proven', sources: [source] },
      verifyDeps(),
    )
    const r = result.sources[0]
    return {
      ok: r.status === 'verified',
      text: renderVerifyReport(r),
      ui: {
        kind: 'verify',
        sub,
        status: r.status,
        ref: r.ref,
        confidence: r.confidence,
        metaChecked: r.metaChecked,
        reason: r.reason,
        resolvedBy: r.resolvedBy,
      },
    }
  }

  /**
   * /verify numbers —— 数值与单位校验（块 2）。
   * ok 语义：有原文时只要存在回溯失败就 ok=false（含这些数值的结论不得作为已证实）；
   * 量纲警告只提示、不影响 ok（改不改由人，工具不静默修）。
   */
  async function verifyNumbers(body, flags, usage) {
    if (!body) return { ok: false, code: 'E_BAD_ARGS', text: `数值与单位校验需要待检文本。${usage}` }
    let sourceText = null
    let sourceLabel = null
    if (flags.pdf && typeof flags.pdf === 'string') {
      try {
        const doc = await verifyDeps().readPdfText(flags.pdf)
        sourceText = doc.text
        sourceLabel = flags.pdf
      } catch (err) {
        return { ok: false, code: 'E_PDF_READ', text: `PDF 无法读取：${(err && err.message) || err}` }
      }
    }
    const report = renderQuantityReport({ text: body, sourceText, sourceLabel })
    return {
      ok: report.untraced.length === 0,
      text: report.text,
      ui: {
        kind: 'verify-numbers',
        quantities: report.quantities.map((q) => ({ raw: q.raw, value: q.value, unit: q.unit })),
        untraced: report.untraced.map((q) => q.raw),
        warnings: report.consistency.warnings,
        notes: report.consistency.notes,
      },
    }
  }

  /**
   * /verify meta —— 元数据完整性（块 2）：预印本标记 / arXiv 版本 / 检索时间 / DOI 可解析性缺项。
   * ok 语义与块 1 一致（verified 才 ok）；缺项是显式提示，不影响 ok 但必须逐条呈现。
   */
  async function verifyMeta(body, flags, usage) {
    if (!body) return { ok: false, code: 'E_BAD_ARGS', text: `元数据校验需要目标（DOI / URL / 本地 PDF 路径）。${usage}` }
    let source
    if (/^https?:\/\//i.test(body) && !/^https?:\/\/(dx\.)?doi\.org\//i.test(body)) {
      source = { kind: 'url', ref: body, claim: claimFromFlags(flags) }
    } else {
      const cls = classifyCardTarget(body)
      if (cls.kind === 'pdf') {
        if (!flags.quote || typeof flags.quote !== 'string') {
          return { ok: false, code: 'E_BAD_ARGS', text: `PDF 来源的元数据校验需要 --quote <引文>（引文是 PDF 来源唯一的校验依据）。${usage}` }
        }
        source = { kind: 'pdf', ref: cls.value, locator: { quote: flags.quote, page: flags.page } }
      } else {
        source = { kind: 'doi', ref: cls.value, claim: claimFromFlags(flags) }
      }
    }
    const result = await verifyAssertion({ text: `引用「${clip(body, 60)}」`, strength: 'proven', sources: [source] }, verifyDeps())
    const r = result.sources[0]
    const assessment = assessMetaCompleteness({
      kind: r.kind,
      ref: r.ref,
      meta: r.meta,
      status: r.status,
      reason: r.reason,
      checkedAt: r.checkedAt,
    })
    // S23·C1：预印本判定 = 显式元数据信号（connector）∪ assessment 的 venue/ref/url 证据；
    // 命中则在报告行内加 [预印本] 标记 + 一段保守口径提示。
    const preVerdict = parsePreprint({
      url: r.kind === 'url' ? r.ref : null,
      doi: r.kind === 'doi' ? r.ref : null,
      arxivEntry: r.meta && r.meta.arxiv ? r.meta.arxiv : null,
    })
    const preprintFinal = preVerdict.preprint || assessment.isPreprint === true
    const preVerdictFinal = { preprint: preprintFinal, source: preVerdict.source || (assessment.isPreprint ? 'meta-evidence' : null) }
    const preTag = tagPreprint(preVerdictFinal)
    const preNotice = renderPreprintNotice(preVerdictFinal)
    return {
      ok: r.status === 'verified',
      text: [
        preTag ? `${preTag} （预印本标记：该来源为预印本，见文末提示）` : '',
        renderVerifyReport(r),
        '',
        renderMetaCompleteness(assessment),
        ...(preNotice ? ['', preNotice] : []),
      ].filter((s) => s !== '').join('\n'),
      ui: { kind: 'verify-meta', status: r.status, ref: r.ref, completeness: assessment, preprint: preprintFinal },
    }
  }

  /**
   * /verify answer —— 多断言总装（块 2 验收口径的直接出口）：
   * 一段输出同屏三档强度 + 未验证断言区 + 数值/元数据严谨性两区。
   * 输入 JSON：{ lead?: string, assertions: [{ text, strength?, sources? }] }。
   * 读用户给的本地 JSON 与 pdf.mjs 读用户给的本地 PDF 是同一立场：显式提供的路径即意图。
   */
  async function verifyAnswer(flags, usage) {
    if (!flags.file || typeof flags.file !== 'string') {
      return { ok: false, code: 'E_BAD_ARGS', text: `多断言总装需要 --file <断言JSON路径>。${usage}` }
    }
    let doc
    try {
      doc = JSON.parse(readFileSync(flags.file, 'utf8'))
    } catch (err) {
      return { ok: false, code: 'E_BAD_JSON', text: `断言 JSON 读取/解析失败：${(err && err.message) || err}` }
    }
    if (!doc || typeof doc !== 'object' || !Array.isArray(doc.assertions)) {
      return { ok: false, code: 'E_BAD_JSON', text: '断言 JSON 形态应为 { lead?: string, assertions: [{ text, strength?, sources? }] }' }
    }
    const deps = verifyDeps()
    const results = await verifyAssertions(doc.assertions, deps)

    // 严谨性-数值：逐断言抽数值；有 verified PDF 来源时回溯到该 PDF 全文（同一路径只读一次）
    const pdfTextCache = new Map()
    const quantities = []
    for (const a of results) {
      const part = {
        label: clip(a.text, 40),
        quantities: extractQuantities(a.text),
        trace: null,
        untraced: [],
        consistency: { warnings: [], notes: [] },
      }
      let sourceText = null
      for (const s of a.verified || []) {
        if (s.kind !== 'pdf') continue
        if (!pdfTextCache.has(s.ref)) {
          try {
            const d = await deps.readPdfText(s.ref)
            pdfTextCache.set(s.ref, d.text)
          } catch {
            pdfTextCache.set(s.ref, null)
          }
        }
        const t = pdfTextCache.get(s.ref)
        if (t) {
          sourceText = t
          break
        }
      }
      if (sourceText !== null) {
        const checked = checkQuantities({ text: a.text, sourceText })
        part.trace = checked.trace
        part.untraced = checked.untraced
        part.consistency = checked.consistency
      } else if (part.quantities.length > 0) {
        part.consistency = checkQuantityConsistency(part.quantities, a.text)
      }
      quantities.push(part)
    }

    // 严谨性-元数据：所有来源（含被拒的）逐条评估
    const meta = []
    for (const a of results) {
      for (const s of a.sources || []) {
        meta.push({
          label: `${s.kind === 'doi' ? 'DOI' : s.kind === 'pdf' ? 'PDF' : 'URL'} ${clip(s.ref, 50)}`,
          assessment: assessMetaCompleteness({ kind: s.kind, ref: s.ref, meta: s.meta, status: s.status, reason: s.reason, checkedAt: s.checkedAt }),
        })
      }
    }

    const text = renderRigorAnswer({ lead: doc.lead ?? null, assertions: results, rigor: { quantities, meta } })
    const unverifiedCount = results.filter((a) => a.effective === 'unverified').length
    const blocked = results.some((a) => (a.rejected || []).length > 0 || (a.unverifiable || []).length > 0)
    return {
      ok: unverifiedCount === 0 && !blocked,
      text,
      ui: {
        kind: 'verify-answer',
        assertions: results.map((a) => ({ text: a.text, claimed: a.claimed, effective: a.effective, downgraded: a.downgraded, downgradeReason: a.downgradeReason, confidence: a.confidence })),
        quantities,
        meta,
      },
    }
  }

  // --- /note 命令族（P-R4 块 3：笔记操作深化） ------------------------------

  const NOTE_STATUSES = Object.freeze(['draft', 'reading', 'done'])

  /** /note new <topic> <slug> [--template <类>] [--title <题>] —— 按模板建空卡。 */
  async function noteNew(topicArg, slugArg, flags) {
    const topic = slugify(topicArg, { max: 40 })
    if (!topicArg || !topic) return { ok: false, code: 'E_BAD_TOPIC', text: '主题名非法（字母/数字/连字符/中文）' }
    const slug = String(slugArg || '').trim().toLowerCase()
    if (!slug || /[\\/\s]/.test(slug)) return { ok: false, code: 'E_BAD_SLUG', text: '用法：/note new <topic> <slug> [--template 综述|方法|实验|失败] [--title <题>]（slug 不能含空白与路径分隔符）' }
    const rel = `${topic}/${slug}.md`
    if (scopes.notes.exists(rel)) {
      return { ok: false, code: 'E_NOTE_EXISTS', text: `卡片已存在，不覆盖：data/notes/${rel}（改名或换主题；手动指定的 slug 不做自动去重）` }
    }
    let built
    try {
      built = buildTemplateCard(flags.template, { topic, slug, title: typeof flags.title === 'string' ? flags.title : null })
    } catch (err) {
      return { ok: false, code: err.code || 'E_BAD_TEMPLATE', text: String(err && err.message) }
    }
    const check = validateCard(built.card)
    if (!check.ok) return { ok: false, code: 'E_CARD_SCHEMA', text: `模板卡未过 schema（模板配置坏了？）：${check.errors.join('; ')}` }
    const written = scopes.notes.write(rel, withSkeleton(renderCard(check.card), built.skeleton))
    scopes.notes.writeJson(`${topic}/${slug}.meta.json`, { slug, topic, writtenAt: new Date().toISOString(), source: 'template', template: String(flags.template) })
    const rebuilt = await rebuildIndexSafe()
    rebuildLinksSafe()
    log.info(`note new ${rel}（模板 ${flags.template}，${written.bytes}B），索引重建 ${rebuilt.count} 条`)
    return {
      ok: true,
      text: [
        `已建模板卡：data/notes/${rel}（${written.bytes} 字节）`,
        `模板：${flags.template}｜预置标签：${built.template.tags.join(', ')}`,
        `骨架 sections：${built.template.sections.join(' / ')}`,
        `索引：已重建（${rebuilt.count} 条）；反向链接索引：已更新`,
      ].join('\n'),
      ui: { kind: 'note', sub: 'new', rel, topic, slug, template: String(flags.template), tags: check.card.tags },
    }
  }

  /** /note links <slug> —— 本卡引用了谁 / 被谁引用 / 悬空链接。 */
  function noteLinks(slugArg) {
    const slug = String(slugArg || '').trim().toLowerCase()
    if (!slug) return { ok: false, code: 'E_BAD_ARGS', text: '用法：/note links <slug>' }
    // 查询前**强制重建**而不是读旧索引：卡片可以绕过命令路径被手改（直接编辑 md），
    // 旧索引会把"刚加的链接"报成不存在——确定性比省一次全扫重要（几十张卡毫秒级）。
    const index = rebuildLinksSafe()
    if (!index) return { ok: false, code: 'E_LINKS_INDEX', text: '链接索引不可用（重建失败，见日志）' }
    const r = queryLinks(index, slug)
    const lines = [`链接查询：${r.slug}${r.cardKey ? `（${r.cardKey}）` : '（库中无此 slug 的卡）'}`]
    lines.push(`本卡引用（${r.links.length}）：${r.links.join(', ') || '（无 [[slug]] 出链）'}`)
    if (r.dangling.length > 0) lines.push(`其中悬空（目标不存在）：${r.dangling.join(', ')}`)
    lines.push(`被谁引用（${r.backlinks.length}）：`)
    if (r.backlinks.length === 0) lines.push('  （无反向链接）')
    for (const b of r.backlinks) lines.push(`  ← ${b.from}${b.title ? `「${b.title}」` : ''}`)
    if ((index.dangling || []).length > 0) {
      lines.push('', `全库悬空链接（${index.dangling.length} 处）：`)
      for (const d of index.dangling) lines.push(`  ${d.from} → [[${d.slug}]]（目标不存在）`)
    }
    return { ok: true, text: lines.join('\n'), ui: { kind: 'note', sub: 'links', ...r, allDangling: index.dangling || [] } }
  }

  /**
   * /note batch --topic <t> [--pick 1,2,3 | --slug a,b] [--tag A,B] [--status draft|reading|done]
   * 批量打标签（front-matter，原路过 schema）+ 批量改状态（meta 侧车——16 字段红线之外的数据放侧车）。
   * 每张卡的变更都落审计日志（plugins.jsonl）。
   */
  async function noteBatch(flags) {
    const topic = typeof flags.topic === 'string' ? slugify(flags.topic, { max: 40 }) : ''
    if (!topic) return { ok: false, code: 'E_BAD_ARGS', text: '用法：/note batch --topic <主题> [--pick 1,2,3 | --slug a,b] [--tag A,B] [--status draft|reading|done]（--pick/--slug 至少给一个；编号按主题内 slug 字母序）' }
    const entries = scopes.notes
      .list(topic)
      .filter((r) => String(r).endsWith('.md'))
      .map((r) => `${topic}/${String(r).split('/').pop()}`)
      .sort()
    if (entries.length === 0) return { ok: false, code: 'E_NO_CARDS', text: `主题 ${topic} 下没有卡片` }

    // 选卡：--slug 精确优先，其次 --pick 编号（1 起）
    let picked = []
    if (typeof flags.slug === 'string' && flags.slug.trim()) {
      const wanted = new Set(flags.slug.split(/[,;\s]+/).filter(Boolean).map((s) => s.toLowerCase()))
      picked = entries.filter((rel) => wanted.has(rel.split('/').pop().replace(/\.md$/i, '').toLowerCase()))
      const missing = [...wanted].filter((s) => !entries.some((rel) => rel.split('/').pop().replace(/\.md$/i, '').toLowerCase() === s))
      if (missing.length > 0) return { ok: false, code: 'E_NO_CARD', text: `这些 slug 不在主题 ${topic} 下：${missing.join(', ')}` }
    } else if (flags.pick !== undefined && flags.pick !== true) {
      const nums = parseSelection(String(flags.pick))
      if (nums.size === 0) return { ok: false, code: 'E_BAD_ARGS', text: '--pick 形如 1,3,5 或 2-4' }
      for (const n of nums) {
        if (n < 1 || n > entries.length) return { ok: false, code: 'E_BAD_PICK', text: `编号越界：${n}（主题 ${topic} 共 ${entries.length} 张卡，按 slug 字母序）` }
      }
      picked = [...nums].sort((a, b) => a - b).map((n) => entries[n - 1])
    } else {
      return { ok: false, code: 'E_BAD_ARGS', text: '需要 --pick <编号> 或 --slug <名> 指定要批量操作的卡片' }
    }

    const tagList = typeof flags.tag === 'string' ? flags.tag.split(/[,;\s]+/).map((s) => s.trim()).filter(Boolean) : []
    const status = typeof flags.status === 'string' && flags.status.trim() ? flags.status.trim().toLowerCase() : null
    if (status && !NOTE_STATUSES.includes(status)) {
      return { ok: false, code: 'E_BAD_STATUS', text: `status 只接受 ${NOTE_STATUSES.join(' / ')}（状态存 meta 侧车——front-matter 严格 16 字段是 DOMAIN 红线）` }
    }
    if (tagList.length === 0 && !status) {
      return { ok: false, code: 'E_BAD_ARGS', text: '至少给一个操作：--tag A,B（批量打标签）和/或 --status <draft|reading|done>（批量改状态）' }
    }

    const results = []
    for (const rel of picked) {
      const r = readCard(scopes.notes, rel)
      if (!r.ok) {
        results.push({ rel, ok: false, error: `现有卡片不过 schema，跳过：${(r.errors || []).join('; ')}` })
        continue
      }
      let changed = []
      if (tagList.length > 0) {
        const before = r.card.tags.join(', ')
        const merged = { ...r.card, tags: [...new Set([...r.card.tags, ...tagList])] }
        const check = validateCard(merged)
        if (!check.ok) {
          results.push({ rel, ok: false, error: `标签变更未过 schema：${check.errors.join('; ')}` })
          continue
        }
        scopes.notes.write(rel, renderCardPreserving(check.card, r.content))
        changed.push(`tags: [${before || '无'}] → [${check.card.tags.join(', ')}]`)
      }
      if (status) {
        const metaRel = rel.replace(/\.md$/i, '.meta.json')
        const meta = r.meta && typeof r.meta === 'object' ? r.meta : { slug: rel.split('/').pop().replace(/\.md$/i, ''), topic }
        const before = meta.status || '(未设)'
        meta.status = status
        meta.statusAt = new Date().toISOString()
        scopes.notes.writeJson(metaRel, meta)
        changed.push(`status: ${before} → ${status}`)
      }
      log.info(`note.batch ${rel}｜${changed.join('｜')}`)
      results.push({ rel, ok: true, changed })
    }
    const okCount = results.filter((r) => r.ok).length
    if (okCount > 0) {
      await rebuildIndexSafe()
      rebuildLinksSafe()
    }
    const lines = [`批量操作完成：${okCount}/${results.length} 张卡（审计已落 data/logs/plugins.jsonl）`]
    for (const r of results) {
      lines.push(r.ok ? `  ${r.rel}｜${r.changed.join('｜')}` : `  跳过 ${r.rel}｜${r.error}`)
    }
    return {
      ok: okCount === results.length,
      text: lines.join('\n'),
      ui: { kind: 'note', sub: 'batch', topic, results, audit: results.filter((r) => r.ok).map((r) => ({ rel: r.rel, changed: r.changed })) },
    }
  }

  /**
   * /note find <query> [--tag X] [--project gfm] [--status done] [--limit N]
   * 有 query 走 Orama 混合检索 + 过滤；无 query 直接全库过滤（纯维度检索）。
   * --project 双路命中：主题目录 === X，或卡片标签含前缀命名空间 `project/X`。
   */
  async function noteFind(text, flags) {
    const query = String(text || '').trim()
    const tagFilter = typeof flags.tag === 'string' && flags.tag.trim() ? flags.tag.trim() : null
    const projectFilter = typeof flags.project === 'string' && flags.project.trim() ? flags.project.trim() : null
    const statusFilter = typeof flags.status === 'string' && flags.status.trim() ? flags.status.trim().toLowerCase() : null
    const limit = Math.max(1, Math.min(50, Number.parseInt(flags.limit, 10) || 20))
    if (!query && !tagFilter && !projectFilter && !statusFilter) {
      return { ok: false, code: 'E_BAD_ARGS', text: '用法：/note find <query> [--tag X] [--project gfm] [--status draft|reading|done] [--limit N]（纯维度检索可不带 query，但至少给一个过滤维度）' }
    }

    const tagHit = (tags, tag) => (Array.isArray(tags) ? tags : String(tags || '').split(/\s+/)).includes(tag)

    let hits = []
    let mode = 'scan'
    if (query) {
      const { db } = await loadOrRebuild(scopes.index, indexEntries())
      // 与 /recall 同一策略：中文提问自动补英文检索式（Orama 默认分词对中文子串无力，
      // 这不是 /note find 的新问题——命中主题簇时两路并集，同一条取高分）。
      const primary = await searchIndex(db, { term: query, limit: Math.min(50, limit * 3) })
      let merged = primary
      const expansion = expandQueryToEnglish(query)
      if (expansion && expansion.query && expansion.query.trim().toLowerCase() !== query.toLowerCase()) {
        const secondary = await searchIndex(db, { term: expansion.query, limit: Math.min(50, limit * 3) })
        merged = { mode: `${primary.mode}+expanded`, hits: mergeHits(primary.hits, secondary.hits, limit * 3), expansion }
      }
      mode = merged.mode
      hits = merged.hits
        .map((h) => h.document)
        .filter((doc) => {
          if (tagFilter && !tagHit(String(doc.tags || '').split(/\s+/), tagFilter)) return false
          if (projectFilter && doc.topic !== projectFilter && !tagHit(String(doc.tags || '').split(/\s+/), `project/${projectFilter}`)) return false
          return true
        })
        .slice(0, limit)
        .map((doc) => ({ rel: doc.rel, title: doc.title, tags: String(doc.tags || '').split(/\s+/).filter(Boolean), topic: doc.topic, status: null }))
    } else {
      for (const r of listAllCards(scopes.notes)) {
        if (!r.ok) continue
        const tags = r.card.tags || []
        if (tagFilter && !tagHit(tags, tagFilter)) continue
        if (projectFilter && r.rel.split('/')[0] !== projectFilter && !tagHit(tags, `project/${projectFilter}`)) continue
        const st = r.meta && r.meta.status ? r.meta.status : null
        if (statusFilter && st !== statusFilter) continue
        hits.push({ rel: r.rel, title: r.card.title, tags, topic: r.rel.split('/')[0], status: st || null })
        if (hits.length >= limit) break
      }
    }

    const lines = [
      `笔记检索（${mode}）：${query ? `query「${query}」` : '（无 query，纯维度过滤）'}${tagFilter ? `｜tag=${tagFilter}` : ''}${projectFilter ? `｜project=${projectFilter}` : ''}${statusFilter ? `｜status=${statusFilter}` : ''}`,
      `命中 ${hits.length} 条：`,
    ]
    if (hits.length === 0) lines.push('  （无命中——若刚建卡，先确认标签/主题与过滤条件一致）')
    for (const h of hits) {
      lines.push(`  ${h.rel}｜${h.title || '(无标题)'}｜tags: ${h.tags.join(', ') || '无'}${h.status ? `｜status: ${h.status}` : ''}`)
    }
    return { ok: true, text: lines.join('\n'), ui: { kind: 'note', sub: 'find', mode, query, hits } }
  }

  /**
   * /note export <topic> [--slug <s>] —— Markdown 导出（单篇 / 整主题合并，含大纲结构）。
   * Word（.docx）大纲导出是块 4 的依赖决策，本块只备好大纲中间形态（不引新依赖）。
   */
  async function noteExport(topicArg, flags) {
    const topic = slugify(topicArg, { max: 40 })
    if (!topicArg || !topic) {
      return { ok: false, code: 'E_BAD_TOPIC', text: '用法：/note export <主题> [--slug <s>] [--docx] [--latex]（默认 markdown；--docx 走 docx 包，--latex 出 .tex+.bib 成对）' }
    }
    const date = new Date().toISOString().slice(0, 10)
    const wantDocx = flags.docx !== undefined
    const wantLatex = flags.latex !== undefined
    const wantMd = !wantDocx && !wantLatex

    // 统一取卡：slug 指定单篇，否则整主题
    const rels = []
    if (typeof flags.slug === 'string' && flags.slug.trim()) {
      const slug = flags.slug.trim().toLowerCase()
      const rel = `${topic}/${slug}.md`
      if (!scopes.notes.exists(rel)) return { ok: false, code: 'E_NO_CARD', text: `卡片不存在：data/notes/${rel}` }
      rels.push(rel)
    } else {
      for (const r of scopes.notes.list(topic)) {
        if (String(r).endsWith('.md')) rels.push(`${topic}/${String(r).split('/').pop()}`)
      }
    }
    if (rels.length === 0) return { ok: false, code: 'E_NO_CARDS', text: `主题 ${topic} 下没有卡片可导出` }
    const entries = rels
      .map((rel) => {
        const rd = readCard(scopes.notes, rel)
        return {
          rel,
          slug: rel.split('/').pop().replace(/\.md$/i, ''),
          title: rd.ok ? rd.card.title : '',
          card: rd.ok ? rd.card : null,
          content: rd.content || '',
          markdown: scopes.notes.read(rel),
        }
      })
      .sort((a, b) => String(a.title).localeCompare(String(b.title), 'zh'))
    const form = wantDocx ? 'docx' : wantLatex ? 'latex' : 'md'

    if (form === 'docx') {
      const usable = entries.filter((e) => e.card)
      if (usable.length === 0) return { ok: false, code: 'E_NO_CARD', text: '没有过 schema 的卡片可导出（坏卡先修）' }
      const { buffer, paragraphCount } = await buildDocx(topic, usable)
      const filename = `${topic}-${date}.docx`
      const written = scopes.exports.write(filename, buffer)
      return {
        ok: true,
        text: [
          `已导出：data/exports/${filename}（${written.bytes} 字节，docx 包 9.11.0，评审见 docs/DEPS.md §6）`,
          `范围：${usable.length} 张卡（标题层级 + front-matter 元信息表 + 正文与批注）｜文档元素 ${paragraphCount} 个`,
          '独立验证：docx 是 zip 包，可解压核对 word/document.xml（tests/docx-export.test.mjs 有自动核验）。',
        ].join('\n'),
        ui: { kind: 'note', sub: 'export', format: 'docx', file: `data/exports/${filename}`, bytes: written.bytes, cards: usable.length },
      }
    }
    if (form === 'latex') {
      const pair = buildLatexPair(topic, entries)
      const texName = `${topic}-${date}.tex`
      const bibName = `${topic}-${date}.bib`
      const wTex = scopes.exports.write(texName, pair.tex)
      const wBib = scopes.exports.write(bibName, pair.bib)
      const selfcheck = await selfCheckBibtex(pair.bib, { expectDois: pair.bibDois })
      return {
        ok: selfcheck.ok,
        text: [
          `已导出 LaTeX 草稿：data/exports/${texName}（${wTex.bytes} 字节）+ data/exports/${bibName}（${wBib.bytes} 字节）`,
          `.bib 条目 ${pair.bibEntries}（DOI ${pair.bibDois.length}）｜citation-js 回读自检：${selfcheck.ok ? '通过' : '失败：' + selfcheck.error}`,
          'Overleaf 用法：.tex 与 .bib 放同一目录即可编译（\\href 需要 hyperref，模板注释已注明）。',
        ].join('\n'),
        ui: { kind: 'note', sub: 'export', format: 'latex', tex: `data/exports/${texName}`, bib: `data/exports/${bibName}`, selfcheck },
      }
    }

    // markdown（块 3 既有路径）
    let filename = null
    let text = null
    let outlineCount = 0
    if (typeof flags.slug === 'string' && flags.slug.trim()) {
      const e = entries[0]
      text = exportSingleMarkdown({ rel: e.rel, markdown: e.markdown })
      outlineCount = buildOutline(e.markdown).reduce((n, h) => n + 1 + (h.children || []).length, 0)
      filename = `${topic}-${e.slug}-${date}.md`
    } else {
      text = exportTopicMarkdown(topic, entries)
      outlineCount = (text.match(/^#{1,4}\s/gm) || []).length
      filename = `${topic}-${date}.md`
    }
    const written = scopes.exports.write(filename, text)
    return {
      ok: true,
      text: [
        `已导出：data/exports/${filename}（${written.bytes} 字节）`,
        `形态：${typeof flags.slug === 'string' && flags.slug.trim() ? '单篇' : '整主题合并（目录 + 大纲 + 逐卡正文）'}｜大纲标题 ${outlineCount} 处`,
        '其它形态：--docx（Word，docx 包）/ --latex（.tex+.bib 成对）。',
      ].join('\n'),
      ui: { kind: 'note', sub: 'export', file: `data/exports/${filename}`, bytes: written.bytes, outlineCount },
    }
  }

  /**
   * /note image <图片路径> [--topic <t>] [--note <一句话>] —— 截图/表格转 Markdown 的**接口先行**实现：
   * 图片不丢（留在原路径）、生成占位卡（tags: source/image + ocr-pending），正文记录路径与说明；
   * OCR 依赖（本机 OCR 或云 OCR）不在本块引入——占位卡保证"截图进了笔记系统"，
   * 后续接上 OCR 后按 ocr-pending 标签批量补正文。
   */
  async function noteImage(pathArg, flags) {
    const p = String(pathArg || '').trim()
    if (!p) return { ok: false, code: 'E_BAD_ARGS', text: '用法：/note image <图片路径> [--topic <t>] [--note <一句话说明>]' }
    if (!existsSync(p)) return { ok: false, code: 'E_NOT_FOUND', text: `图片不存在 -> ${p}` }
    const topic = typeof flags.topic === 'string' && flags.topic.trim() ? slugify(flags.topic, { max: 40 }) : 'inbox'
    const name = p.split(/[\\/]/).pop().replace(/\.[a-z0-9]+$/i, '')
    const slug = `img-${slugify(name, { max: 50 })}-${Date.now().toString(36).slice(-4)}`
    const rel = `${topic}/${slug}.md`
    if (scopes.notes.exists(rel)) return { ok: false, code: 'E_NOTE_EXISTS', text: `占位卡已存在（罕见冲突，重试即可）：data/notes/${rel}` }
    const card = emptyCard()
    card.title = `截图：${name}`
    card.tags = ['source/image', 'ocr-pending', `project/${topic}`]
    card['问题'] = '（图片待 OCR）这张截图/表格要回答什么问题？'
    card['方法'] = `图片路径：${p}`
    card['数据与算例'] = `（待 OCR）图片内容占位——${typeof flags.note === 'string' && flags.note.trim() ? flags.note.trim() : '见原图片'}`
    card['读数（0-5）'] = 0
    const check = validateCard(card)
    if (!check.ok) return { ok: false, code: 'E_CARD_SCHEMA', text: `占位卡未过 schema：${check.errors.join('; ')}` }
    const body = renderCard(check.card).replace(
      '## 我的批注',
      `## 图片\n\n- 路径：\`${p}\`\n- 状态：待 OCR（接上 OCR 后按 \`ocr-pending\` 标签批量补正文）\n- 说明：${typeof flags.note === 'string' && flags.note.trim() ? flags.note.trim() : '（无）'}\n\n## 我的批注`,
    )
    scopes.notes.write(rel, body)
    scopes.notes.writeJson(`${topic}/${slug}.meta.json`, { slug, topic, writtenAt: new Date().toISOString(), source: 'image-placeholder', imagePath: p })
    const rebuilt = await rebuildIndexSafe()
    rebuildLinksSafe()
    log.info(`note image ${rel}（${p}，占位待 OCR）`)
    return {
      ok: true,
      text: [
        `已建占位卡：data/notes/${rel}`,
        `图片：${p}（留在原路径，不复制不修改）｜标签：source/image, ocr-pending`,
        `OCR：本块未引入（任务书允许后补）；接上后按 ocr-pending 标签批量补正文，索引已重建（${rebuilt.count} 条）`,
      ].join('\n'),
      ui: { kind: 'note', sub: 'image', rel, imagePath: p, ocr: 'pending' },
    }
  }

  /**
   * /note zotero <文件或收件目录> [--topic <t>] —— Zotero 只读互通。
   * 只读 .bib / CSL-JSON 导出文件生成候选卡；**绝不写 Zotero 目录**（lib/zotero.mjs 只 import 读函数，
   * tests/notes.test.mjs 有静态断言）。候选落本项目 data/index/candidates/，用 /card --find 生成卡片。
   */
  async function noteZotero(pathArg, flags) {
    const p = String(pathArg || '').trim()
    if (!p) return { ok: false, code: 'E_BAD_ARGS', text: '用法：/note zotero <Zotero导出.bib|.json|收件目录> [--topic <t>]' }
    let r
    try {
      r = await readZoteroExport(p)
    } catch (err) {
      return { ok: false, code: err.code || 'E_ZOTERO', text: `Zotero 导入失败：${String(err && err.message)}` }
    }
    if (r.candidates.length === 0) {
      return { ok: false, code: 'E_EMPTY_IMPORT', text: `没有解析到任何条目（${r.files.length} 个文件）${r.errors.length ? '；' + r.errors.join('；') : ''}` }
    }
    const topic = typeof flags.topic === 'string' && flags.topic.trim() ? slugify(flags.topic, { max: 40 }) : 'zotero'
    const saved = saveCandidates(scopes.index, {
      query: `zotero:${p}`,
      searchedAt: new Date().toISOString(),
      sources: [{ name: 'zotero', count: r.candidates.length }],
      stats: { files: r.files.length, errors: r.errors.length },
      candidates: r.candidates,
    })
    log.info(`note.zotero ${p}：${r.candidates.length} 条候选（去重 ${r.deduped}），候选集 ${saved.rel || '(内存认账)'}`)
    const lines = [
      `Zotero 导入（只读）：${r.files.length} 个文件 → ${r.candidates.length} 条候选（去重丢弃 ${r.deduped}）`,
      `候选集：data/index/${saved.rel || 'candidates/'}（query: zotero:${p}）`,
      ...r.errors.map((e) => `  解析失败｜${e}`),
      '下一步：/card --find 1,2,3 生成研究卡片；Zotero 侧零写入（只读适配器）。',
    ]
    return {
      ok: true,
      text: lines.join('\n'),
      ui: { kind: 'note', sub: 'zotero', count: r.candidates.length, deduped: r.deduped, files: r.files, errors: r.errors, candidates: r.candidates },
    }
  }

  /** /note —— 笔记操作深化的对外命令（块 3）。 */
  async function note(rest) {
    const { text, flags } = splitFlags(rest)
    const parts = text.split(/\s+/).filter(Boolean)
    const sub = (parts[0] || '').toLowerCase()
    const body = parts.slice(1).join(' ')
    const usage =
      '用法：/note new <topic> <slug> [--template 综述|方法|实验|失败]；/note links <slug>；/note batch --topic <t> [--pick 1,2,3] [--tag A,B] [--status done]；/note find <query> [--tag X] [--project gfm]；/note export <主题> [--slug <s>] [--docx|--latex]；/note zotero <路径>；/note image <图片路径> [--topic <t>]'
    if (sub === 'new') return noteNew(body.split(/\s+/)[0] || '', body.split(/\s+/).slice(1).join(' ').trim(), flags)
    if (sub === 'links') return noteLinks(body)
    if (sub === 'batch') return noteBatch(flags)
    if (sub === 'find') return noteFind(body, flags)
    if (sub === 'export') return noteExport(body.split(/\s+/)[0] || '', flags)
    if (sub === 'zotero') return noteZotero(body, flags)
    if (sub === 'image') return noteImage(body, flags)
    return { ok: false, code: 'E_BAD_ARGS', text: usage }
  }

  // --- 维护 ----------------------------------------------------------------

  /**
   * 面板卡片编辑弹层的写回路径。
   *
   * 为什么不做成"面板直接改文件"：改 front-matter 会绕过 schema 校验，
   * 而卡片是要被引用与检索的，字段坏掉比改不动更糟。所以编辑也必须**原路返回**：
   * 面板 → 主进程 → 插件命令 → validateCard → 写盘 → 重建索引。
   * 只允许改 CARD_FIELDS 里的字段；读数会被再校验一次 0-5。
   *
   * @param {string} rel 形如 `gfm/xxx.md`（相对 data/notes）
   * @param {object} patch 只含需要改的字段
   */
  async function updateCard(rel, patch) {
    const target = String(rel || '').replace(/^data[\\/]notes[\\/]/i, '').replace(/\\/g, '/')
    if (!target || !target.endsWith('.md') || target.includes('..')) {
      return { ok: false, code: 'E_BAD_REL', text: `卡片路径非法：${rel}` }
    }
    if (!scopes.notes.exists(target)) {
      return { ok: false, code: 'E_NO_CARD_FILE', text: `卡片不存在：data/notes/${target}` }
    }
    const current = readCard(scopes.notes, target)
    if (!current.ok) {
      return { ok: false, code: 'E_CARD_SCHEMA', text: `现有卡片本身就不符合 schema，拒绝改写：${current.errors.join('; ')}` }
    }
    const src = patch && typeof patch === 'object' ? patch : {}
    const merged = { ...current.card }
    const ignored = []
    for (const [k, v] of Object.entries(src)) {
      if (!CARD_FIELDS.includes(k)) {
        ignored.push(k)
        continue
      }
      merged[k] = v
    }
    const check = validateCard(merged)
    if (!check.ok) {
      return { ok: false, code: 'E_CARD_SCHEMA', text: `改动未通过 schema 校验，已放弃写盘：${check.errors.join('; ')}`, errors: check.errors }
    }
    const written = scopes.notes.write(target, renderCardPreserving(check.card, current ? current.content : null))
    const rebuilt = await rebuildIndexSafe()
    rebuildLinksSafe()
    log.info(`card.update ${target}（字段 ${Object.keys(src).length} 个），索引重建 ${rebuilt.count} 条`)
    return {
      ok: true,
      text: [
        `卡片已更新：data/notes/${target}（${written.bytes} 字节）`,
        ignored.length > 0 ? `忽略的非卡片字段：${ignored.join(', ')}` : '',
        `索引：已重建，当前 ${rebuilt.count} 条`,
      ]
        .filter(Boolean)
        .join('\n'),
      ui: { kind: 'card', rel: `data/notes/${target}`, topic: target.split('/')[0], slug: target.split('/').pop().replace(/\.md$/, ''), card: check.card, generatedBy: 'edited', updated: true, indexCount: rebuilt.count },
    }
  }

  function cardBody() {
    const s = status()
    return [
      `v${s.version}｜卡片 ${s.cards} 张｜索引 ${s.indexCount === null ? '未建' : `${s.indexCount} 条`}`,
      `源：arXiv / OpenAlex / Crossref${s.s2Configured ? ' / Semantic Scholar(已配 key)' : '（S2 无 key，已按规则跳过）'}`,
      `OpenAlex 礼貌池：${s.openalexPolite ? '已配 mailto' : '未配（按规则不加 mailto 参数）'}`,
      `命令：/find /card /bib /recall /verify（引用校验·严谨性检查）/note（笔记操作：模板/双向链接/批量/检索/导出/Zotero）`,
    ].join('\n')
  }

  return {
    status,
    find,
    cardFromTarget,
    cardFromFindSelection,
    bib,
    recall,
    verify,
    note,
    updateCard,
    extractAndStore,
    allCards,
    indexEntries,
    rebuild: async () => rebuildIndexSafe(),
    prebuild: async () => buildIndex(indexEntries()),
    scopes,
    secretsInfo,
    cardBody,
    embed: embedText,
    readCard: (rel) => readCard(scopes.notes, rel),
    listCards: (topic) => listCards(scopes.notes, topic),
    validateCard,
    selfCheckBibtex,
    buildBibtex,
    latestCandidates,
    // 供测试/验收工具断言"没有第二条出网/落盘出口"，以及按同一份 deps 组装多源答案
    _internals: { scopes, secretsLoader, verifyDeps },
  }
}

// ---------------------------------------------------------------------------
// 插件契约
// ---------------------------------------------------------------------------

export async function activate(ctx) {
  const engine = createEngine(ctx)
  const log = ctx.log

  // 面板卡片（「文献」卡片）：内容由引擎在启用时快照，动态状态走 /find 等命令回推
  let body = '科研核心插件已加载'
  try {
    body = engine.cardBody()
  } catch (err) {
    body = `科研核心插件已加载（状态读取失败：${String(err && err.message)}）`
  }
  ctx.ui.registerCard({
    id: CARD_ID,
    title: '文献',
    body,
    actions: ['find', 'card', 'bib', 'recall', 'verify', 'note'],
  })

  ctx.ui.registerCommand({
    name: 'find',
    title: '文献检索',
    description: '四源并联检索 arXiv/OpenAlex/Crossref/S2（去重+打分）+ 行内 DOI 可信标记（✓双源/⚠仅单源/✗未收录，与引用校验同一判定源）。用法：/find <关键词|主题别名>，别名如 gfm、hvdc、microgrid；也支持 --max N --min N --trust-limit N --no-trust --last（重放最近候选集不重新检索）',
    run: async (rest = '') => {
      const { text, flags } = splitFlags(rest)
      const r = await engine.find(text, flags)
      return { text: r.text, ui: r.ui, ok: r.ok, code: r.code || null }
    },
  })

  ctx.ui.registerCommand({
    name: 'card',
    title: '生成研究卡片',
    description: '从 DOI / 本地 PDF / 候选编号生成结构化卡片。用法：/card <DOI|PDF路径>、/card --find 1,3,5，可选 --topic <名> --heuristic',
    run: async (rest = '') => {
      const { text, flags } = splitFlags(rest)
      if (flags.find !== undefined && flags.find !== true) {
        const r = await engine.cardFromFindSelection(String(flags.find), {
          topic: typeof flags.topic === 'string' && flags.topic ? flags.topic : DEFAULTS.topic,
          useLlm: !flags.heuristic,
          model: typeof flags.model === 'string' ? flags.model : DEFAULTS.cardModel,
        })
        return { text: r.text, ui: r.ui, ok: r.ok, code: r.code || null }
      }
      const r0 = await engine.cardFromTarget(text, flags)
      let r = r0
      // S20·B：命中撤稿则在卡片顶部行内标记 [已撤稿]
      const cls = classifyCardTarget(text)
      if (r0.ok && cls && cls.kind === 'doi') {
        try {
          const retr = await lookupRetraction(cls.value, { net })
          const tag = tagRetracted(retr)
          if (tag) {
            r = { ...r0, text: tag + ' ' + r0.text, ui: { ...(r0.ui || {}), retracted: true, retractionTag: tag } }
          }
        } catch { /* 网络失败不阻断卡片生成 */ }
      }
      return { text: r.text, ui: r.ui, ok: r.ok, code: r.code || null }
    },
  })

  ctx.ui.registerCommand({
    name: 'bib',
    title: '导出 BibTeX',
    description: '把某主题（或全部）卡片导出为 .bib 并用 citation-js 自检。用法：/bib <主题>，主题省略或 all 表示全部',
    run: async (rest = '') => {
      const { text, flags } = splitFlags(rest)
      const r = await engine.bib(text, flags)
      return { text: r.text, ui: r.ui, ok: r.ok, code: r.code || null }
    },
  })

  ctx.ui.registerCommand({
    name: 'recall',
    title: '卡片问答',
    description: '对已归档卡片做混合检索问答，答案必带卡片出处。用法：/recall <问题>，可选 --top N --topic <名>',
    run: async (rest = '') => {
      const { text, flags } = splitFlags(rest)
      const r = await engine.recall(text, flags)
      return { text: r.text, ui: r.ui, ok: r.ok, code: r.code || null }
    },
  })

  ctx.ui.registerCommand({
    name: 'verify',
    title: '引用校验·严谨性检查',
    description:
      '引用校验（产品红线）+ 严谨性检查：DOI 经 Crossref/OpenAlex 双源解析 + 题录模糊比对贴置信度；PDF 引文归一化后逐字命中；数值与单位回溯原文并给量纲警告；元数据完整性（预印本/arXiv 版本/检索时间/DOI 可解析性缺项）；多断言总装同屏三档强度 + 未验证断言区。校验失败的来源拒引并说明原因。用法：/verify doi <DOI> [--title <题名>] [--year <年>] [--author <作者>]；/verify quote <引文> --pdf <本地PDF路径>；/verify numbers <文本> [--pdf <本地PDF路径>]；/verify meta <DOI|URL|PDF路径>；/verify answer --file <断言JSON>',
    run: async (rest = '') => {
      const r = await engine.verify(rest)
      return { text: r.text, ui: r.ui, ok: r.ok, code: r.code || null }
    },
  })

  ctx.ui.registerCommand({
    name: 'note',
    title: '笔记操作',
    description:
      '笔记操作深化（P-R4 块 3）：模板建卡（综述/方法/实验/失败，模板定义在插件 templates.json 可改不改码）；[[slug]] 双向链接与反向索引（悬空链接可列出）；批量打标签/改状态（审计落 plugins.jsonl）；标签 + 项目维度检索；Markdown 导出（单篇/整主题合并 + 大纲；Word .docx / LaTeX .tex+.bib 见 --docx/--latex，块 4 已落地）；Zotero 只读互通（.bib/CSL-JSON → 候选卡，绝不写 Zotero 目录）。用法：/note new <topic> <slug> [--template 综述]；/note links <slug>；/note batch --topic <t> [--pick 1,2,3] [--tag A,B] [--status done]；/note find <query> [--tag X] [--project gfm]；/note export <主题> [--slug <s>] [--docx|--latex]；/note zotero <路径>',
    run: async (rest = '') => {
      const r = await engine.note(rest)
      return { text: r.text, ui: r.ui, ok: r.ok, code: r.code || null }
    },
  })

  ctx.ui.registerCommand({
    name: 'card.update',
    title: '卡片写回（面板编辑弹层用）',
    description:
      '按 schema 校验后写回一张卡片。用法：/card.update {"rel":"gfm/xxx.md","patch":{"读数（0-5）":3}}（面板的卡片编辑弹层走这条命令，不直接改文件）',
    run: async (rest = '') => {
      let payload = null
      try {
        payload = JSON.parse(String(rest || '').trim() || '{}')
      } catch (err) {
        return { text: `参数不是合法 JSON：${String(err && err.message)}\n用法：/card.update {"rel":"gfm/xxx.md","patch":{...}}`, ok: false, code: 'E_BAD_JSON' }
      }
      if (!payload || typeof payload.rel !== 'string') {
        return { text: '用法：/card.update {"rel":"gfm/xxx.md","patch":{...}}', ok: false, code: 'E_BAD_REL' }
      }
      const r = await engine.updateCard(payload.rel, payload.patch || {})
      return { text: r.text, ui: r.ui, ok: r.ok, code: r.code || null, errors: r.errors || null }
    },
  })

  log.info(`research-literature 已激活：1 张卡片 + 7 条命令（6 条对外 + card.update 供面板写回）；状态 ${JSON.stringify(engine.status())}`)

  return {
    deactivate() {
      log.info('research-literature 已停用')
    },
    engine,
    // 把宿主发下来的 ctx 原样带出去：宿主与测试可以据此核对
    // "这个插件实际拿到了哪些能力"（例如 scope('fixtures') 必须抛 E_SCOPE_NOT_GRANTED）。
    // 不需要额外权限 —— 这本来就是宿主自己构造并交给插件的那个对象。
    ctx,
  }
}

export default { activate, createEngine, activateVersion: RESEARCH_LITERATURE_VERSION }
