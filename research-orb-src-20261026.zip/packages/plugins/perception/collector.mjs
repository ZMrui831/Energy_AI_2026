// packages/plugins/perception/collector.mjs
//
// Perception layer S2 - collection sub-agent (Node side, pure ESM, zero electron).
//
// Responsibilities:
//   1. Spawn the long-lived PowerShell helper (collector.ps1) EXACTLY ONCE.
//   2. Read its stdout line-by-line (robust against BOM / partial / multi-line chunks).
//   3. Parse each JSONL line into a sample and forward to options.onSample.
//   4. If the child dies unexpectedly, auto-restart with exponential backoff
//      (<= 30s, base default 500ms, cap 30000ms) and emit a 'restart' event.
//   5. stop() kills ONLY our own spawned PID tree (taskkill /PID <pid> /T /F) --
//      never by process name. Then self-checks the residue via an injectable isAlive.
//
// This module is intentionally injectable: tests pass options.spawnImpl /
// options.killTreeImpl / options.isAlive so they never touch real PowerShell,
// real processes, or Electron.

import { spawn, execFileSync } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

// Safe write path for optional restart audit (only used when options.auditFile set).
import { appendJsonl, logPath } from '../../core/src/safefs.mjs'

const __dirname = dirname(fileURLToPath(import.meta.url))

/** Absolute path to the bundled collector.ps1 (real helper). */
export const collectorPath = join(__dirname, 'collector.ps1')

/** Required JSON fields (fixed schema) and their expected JSON types. */
const REQUIRED_FIELDS = ['ts', 'hwnd', 'pid', 'process', 'title', 'idleMs', 'isFullscreen', 'monitorId']
const FIELD_TYPES = {
  ts: 'number',
  hwnd: 'number',
  pid: 'number',
  process: 'string',
  title: 'string',
  idleMs: 'number',
  isFullscreen: 'boolean',
  monitorId: 'string',
}

const BOM = '﻿' // U+FEFF

/**
 * Pure: parse a single line of collector output.
 * Never throws. Returns {ok:true, sample} or {ok:false, reason}.
 * Tolerant of leading/trailing whitespace and a stray UTF-8 BOM.
 * @param {string} line
 * @returns {{ok:true, sample:object} | {ok:false, reason:string}}
 */
export function parseLine(line) {
  if (typeof line !== 'string') return { ok: false, reason: 'not-string' }
  let s = line.trim()
  if (s.length === 0) return { ok: false, reason: 'empty' }
  if (s.charCodeAt(0) === 0xfeff) s = s.slice(1) // strip BOM
  if (s.length === 0) return { ok: false, reason: 'empty-after-bom' }

  let obj
  try {
    obj = JSON.parse(s)
  } catch {
    return { ok: false, reason: 'invalid-json' }
  }
  if (obj === null || typeof obj !== 'object' || Array.isArray(obj)) {
    return { ok: false, reason: 'not-object' }
  }

  const missing = REQUIRED_FIELDS.filter((k) => !(k in obj))
  if (missing.length > 0) {
    return { ok: false, reason: `missing-fields:${missing.join(',')}` }
  }
  for (const k of REQUIRED_FIELDS) {
    if (typeof obj[k] !== FIELD_TYPES[k]) {
      return { ok: false, reason: `bad-type:${k}` }
    }
  }
  return { ok: true, sample: obj }
}

/**
 * Pure residue self-check. Given a list of pids (our spawned subtree) and an
 * injectable isAlive predicate, report whether every one of them has exited.
 * Real default probes the OS via process.kill(pid, 0).
 * @param {number|number[]} pids
 * @param {(pid:number)=>boolean} [isAlive]
 * @returns {{allExited:boolean, alive:number[], pids:number[]}}
 */
export function listOwnPowershell(pids, isAlive = defaultIsAlive) {
  const arr = Array.isArray(pids) ? pids : pids == null ? [] : [pids]
  const alive = arr.filter((p) => {
    try {
      return isAlive(p)
    } catch {
      return false
    }
  })
  return { allExited: alive.length === 0, alive, pids: arr }
}

/** Default liveness probe: process.kill(pid, 0) throws ESRCH when absent. */
function defaultIsAlive(pid) {
  try {
    process.kill(pid, 0)
    return true
  } catch {
    return false
  }
}

/**
 * Default tree kill: ONLY our own PID, never by process name.
 * MUST be synchronous (execFileSync): callers historically did
 * `collector.stop(); process.exit()` immediately after — an async execFile
 * spawn request could be aborted by process.exit() before taskkill.exe ever
 * launched, leaving an orphaned powershell (实测复现的孤儿根因之一)。
 */
function defaultKillTree(pid) {
  try {
    execFileSync('taskkill', ['/PID', String(pid), '/T', '/F'], {
      windowsHide: true,
      timeout: 10_000,
      stdio: 'ignore',
    })
  } catch {
    /* taskkill non-zero (already dead) is fine; never throw from stop() */
  }
}

/**
 * Start the collector.
 * @param {object} [options]
 * @param {(sample:object)=>void} [options.onSample] called for each valid sample
 * @param {(info:{restarts:number, delay:number})=>void} [options.onRestart] audit callback
 * @param {typeof spawn} [options.spawnImpl] injectable spawn (test)
 * @param {(pid:number)=>void} [options.killTreeImpl] injectable tree kill (test)
 * @param {(pid:number)=>boolean} [options.isAlive] injectable liveness probe
 * @param {string} [options.scriptPath] powershell script (default collectorPath)
 * @param {number} [options.baseDelay] backoff base ms (default 500)
 * @param {number} [options.maxDelay] backoff cap ms (default 30000)
 * @param {number} [options.healthMs] reset failures after this healthy uptime (default 5000)
 * @param {string|null} [options.auditFile] optional safefs log filename for restart audit
 * @returns {object} controller: { stop, isRunning, pid, on, restartCount }
 */
export function startCollector(options = {}) {
  const spawnImpl = options.spawnImpl || spawn
  const killTreeImpl = options.killTreeImpl || defaultKillTree
  const isAlive = options.isAlive || defaultIsAlive
  const onSample = options.onSample || (() => {})
  const onRestart = options.onRestart || null
  const scriptPath = options.scriptPath || collectorPath
  const baseDelay = options.baseDelay ?? 500
  const maxDelay = options.maxDelay ?? 30000
  const healthMs = options.healthMs ?? 5000
  const auditFile = options.auditFile || null

  let child = null
  let running = false
  let stopped = false
  let failures = 0 // consecutive unexpected exits
  let restarts = 0
  let restartTimer = null
  let lineLeftover = ''
  const listeners = { restart: [] }

  function emit(event, payload) {
    for (const cb of listeners[event] || []) {
      try {
        cb(payload)
      } catch {
        /* listener errors must not break the loop */
      }
    }
  }

  function handleChunk(chunk) {
    lineLeftover += chunk
    let idx
    while ((idx = lineLeftover.indexOf('\n')) !== -1) {
      const raw = lineLeftover.slice(0, idx)
      lineLeftover = lineLeftover.slice(idx + 1)
      const parsed = parseLine(raw)
      if (parsed.ok) onSample(parsed.sample)
    }
  }

  function spawnChild() {
    if (stopped) return null
    const args = ['-NoProfile', '-NonInteractive', '-File', scriptPath, String(process.pid)]
    let c
    // Re-check `stopped` immediately before spawn: the restart-timer callback
    // path can be enqueued before stop() runs; this closes the stop/restart race
    // (spawn-after-stop = orphaned powershell, 实测复现).
    if (stopped) return null
    try {
      c = spawnImpl('powershell.exe', args, { windowsHide: true })
    } catch (err) {
      // Spawn failed outright: count as a failure and back off.
      failures += 1
      scheduleRestart()
      return null
    }
    child = c
    running = true

    const stableTimer = setTimeout(() => {
      // If this child survived healthMs, treat the streak as healthy and reset backoff.
      if (child === c && running && !stopped) failures = 0
    }, healthMs)

    if (c.stdout) {
      c.stdout.setEncoding('utf8')
      c.stdout.on('data', (chunk) => handleChunk(chunk))
    }
    if (c.stderr) {
      c.stderr.on('data', () => { /* ignore helper stderr noise */ })
    }
    c.on('exit', (code, signal) => {
      clearTimeout(stableTimer)
      running = false
      if (stopped) return // intentional shutdown: no restart
      // Unexpected death -> exponential backoff restart.
      failures += 1
      scheduleRestart()
    })
    c.on('error', () => {
      clearTimeout(stableTimer)
      if (stopped) return
      failures += 1
      scheduleRestart()
    })
    return c
  }

  function scheduleRestart() {
    if (stopped) return
    const n = failures // consecutive failures so far
    const delay = Math.min(maxDelay, baseDelay * Math.pow(2, n))
    if (restartTimer) clearTimeout(restartTimer)
    restartTimer = setTimeout(() => {
      restartTimer = null
      if (stopped) return
      restarts += 1
      const info = { restarts, delay }
      emit('restart', info)
      if (onRestart) {
        try {
          onRestart(info)
        } catch {
          /* ignore */
        }
      }
      if (auditFile) {
        try {
          appendJsonl(logPath(auditFile), { ts: Date.now(), source: 'perception-collector', event: 'restart', ...info })
        } catch {
          /* ignore */
        }
      } else {
        // Structured stderr audit line (no disk write by default).
        console.error(JSON.stringify({ ts: Date.now(), source: 'perception-collector', event: 'restart', ...info }))
      }
      spawnChild()
    }, delay)
  }

  function stop() {
    // Order matters: flip `stopped` FIRST so any already-dequeued restart-timer
    // callback (or in-flight exit handler) sees it, then clear the pending
    // restart timer, then kill the child tree synchronously.
    stopped = true
    if (restartTimer) {
      clearTimeout(restartTimer)
      restartTimer = null
    }
    const c = child
    const pid = c ? c.pid : null
    if (c) {
      try {
        c.kill()
      } catch {
        /* ignore */
      }
      if (pid != null) {
        try {
          killTreeImpl(pid)
        } catch {
          /* ignore */
        }
      }
    }
    running = false
    return { pid }
  }

  function isRunning() {
    return running && !stopped
  }

  function pid() {
    return child ? child.pid : null
  }

  function restartCount() {
    return restarts
  }

  function on(event, cb) {
    if (!listeners[event]) listeners[event] = []
    listeners[event].push(cb)
    return () => {
      listeners[event] = (listeners[event] || []).filter((f) => f !== cb)
    }
  }

  // Kick off the single long-lived child.
  spawnChild()

  return { stop, isRunning, pid, on, restartCount }
}

export default { startCollector, parseLine, listOwnPowershell, collectorPath }
