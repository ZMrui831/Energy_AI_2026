// packages/plugins/perception/index.mjs
//
// 感知层 S2 · 插件入口（整合 B/C/D 三子代理模块 + 预算 + 同意流）。
//
// 纪律（硬红线）：
//   · 1Hz 只采元数据（前台窗口/进程/标题/空闲/全屏），绝不截图。
//   · 原图只在「状态允许 + 同意允许截图 + 非敏感窗口 + changeScore 超阈 + 截图节奏闸门」
//     全部满足时才落 data/perception/shots/（经 safefs）。
//   · 敏感窗口（isSensitive）命中 → 永不截图 + 写审计 data/logs/perception.jsonl。
//   · 绝不抢前台 / 弹窗 / 发声 / 覆盖桌面点击。
//   · 落盘一律走 safefs（scopes 为空，因为 DATA_SCOPES 不含 perception）。
//   · 主进程接线（把 perception 加入 pack.json 的 plugins、ctx.core.screen 桥复用）
//     见 docs/PERCEPTION.md「主进程接线补丁」—— 本文件不在本任务内改宿主。

import { readFileSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import { createHash } from 'node:crypto'

import { appendJsonl, safeWrite, logPath, PROJECT_ROOT, dataPath } from '../../core/src/safefs.mjs'
import { computeExpiry } from '../../core/src/db.mjs'
import { startCollector } from './collector.mjs'
import { detectEvents, createEventRecorder } from './events.mjs'
import { computeDiff, adaptCapture } from './diff.mjs'
import { decide, isSensitive, sensitiveMatched, LEARNING_MIN_INTERVAL_MS } from './sampler.mjs'
import { isActive, allowsScreenCapture, revoke, remainingMs, grant } from './consent.mjs'
// S74c·P0-4：拒授权期间「因未同意而跳过抓屏」的聚合审计（60s 窗口合并）
import { recordSkippedNoConsent, computeSkippedStats } from './skip-audit.mjs'
import { evaluateBudget, DEFAULT_THRESHOLDS, thresholdsFromBaseline, FALLBACK_THRESHOLDS, diagnoseBudget } from '../../core/src/budget.mjs'
import { readBaseline, writeBaseline, collectBaseline } from '../../core/src/budget-baseline.mjs'
import { sampleHostMetrics } from './metrics.mjs'
// S23·B：变化分类（规则式）+ 活动摘要（每 summary.intervalMs 一条，落 data/perception/summary-*.jsonl）
import { classifyChange } from './classify.mjs'
import { createSummarizer, createSummaryWriter, DEFAULT_SUMMARY_INTERVAL_MS, DEFAULT_SCROLL_MINOR_FRAMES } from './summary.mjs'

const CONFIG_PATH = dataPath('perception-config.json')
const PERCEPTION_DIR = dataPath('perception')
const SHOTS_DIR = join(PERCEPTION_DIR, 'shots')
const AUDIT_LOG = logPath('perception.jsonl')

const VALID_STATES = ['idle', 'normal', 'candidate', 'learning', 'dnd']

// ---------------------------------------------------------------------------
// 配置读写（scopes 为空 → 直写 data/perception-config.json，根内断言 + 审计照旧）
// ---------------------------------------------------------------------------

function defaultConfig() {
  // S74c·P2-7：本默认值与生产 data\perception-config.json 是**两套并存口径**，此前注释含糊，
  // 且 coldStartMinutes 是**死字段**（全仓库从未被读取，冷启动窗口恒为 decide() 默认 5 分钟）。现明确：
  //   · 本默认值 = 首次启动/演示的**保守慢启动**：普通态前 coldStartMinutes 分钟不抓屏。
  //   · 生产（数据树里的 perception-config.json）= **立即抓屏**：coldStartMinutes:0 + coldStartCaptureDisabled:false。
  //   · 语义：coldStartCaptureDisabled=true 表示"冷启动期间禁止抓屏"（与 decide() 的 coldStart 对应）；
  //     调用方以 `!== false` 判定——**仅显式 false 才关闭保护**，缺省/undefined 视为开启（易误读，此处写明）。
  //   · 黑名单：默认已与生产对齐（含 LastPass / cmd / powershell / 终端 / ssh / id_rsa），避免默认比生产更弱。
  return {
    version: 1,
    policyVersion: 'perception-s2-2026-10-17',
    thresholds: { changeScoreNormal: 0.12, changeScoreCandidate: 0.08 },
    intervals: {},
    blacklist: '1Password|Bitwarden|KeePass|LastPass|密码|Login Data|银行|网银|支付|医疗|病历|处方|health|bank|cmd\\.exe|powershell|终端|ssh|id_rsa',
    consent: { mode: 'denied', grantedAt: null, expiresAt: null, policyVersion: 'perception-s2-2026-10-17', displays: [], windowWhitelist: [] },
    coldStartMinutes: 5,            // 冷启动保护窗口（分钟）；0 = 不保护（立即抓屏）。生产为 0。
    coldStartCaptureDisabled: true, // true=冷启动期间禁止抓屏；仅显式 false 关闭保护。生产为 false。
    budget: { thresholds: { ...DEFAULT_THRESHOLDS }, sampleMs: 30000 },
    // S23·B：活动摘要参数（可配；不改既有采样阈值默认值）
    summary: { intervalMs: DEFAULT_SUMMARY_INTERVAL_MS, scrollMinorFrames: DEFAULT_SCROLL_MINOR_FRAMES },
  }
}

export function loadConfig() {
  try {
    if (existsSync(CONFIG_PATH)) {
      const c = JSON.parse(readFileSync(CONFIG_PATH, 'utf8'))
      const d = defaultConfig()
      return {
        ...d,
        ...c,
        thresholds: { ...d.thresholds, ...(c.thresholds || {}) },
        intervals: { ...(c.intervals || {}) },
        consent: { ...d.consent, ...(c.consent || {}) },
        budget: {
          thresholds: { ...DEFAULT_THRESHOLDS, ...((c.budget && c.budget.thresholds) || {}) },
          sampleMs: (c.budget && c.budget.sampleMs) || 30000,
        },
        summary: { ...d.summary, ...(c.summary || {}) },
      }
    }
  } catch {
    /* 损坏则回退默认 */
  }
  return defaultConfig()
}

export function saveConfig(config) {
  return safeWrite(CONFIG_PATH, JSON.stringify(config, null, 2))
}

function resolveState(ctx, config) {
  const fromCtx = ctx && typeof ctx.state === 'string' ? ctx.state : null
  const fromEnv = process.env.PERCEPTION_STATE || null
  // 命令行注入：--state <state>（Electron 宿主会透传 argv）
  let fromArgv = null
  const ai = process.argv.indexOf('--state')
  if (ai !== -1 && typeof process.argv[ai + 1] === 'string') fromArgv = process.argv[ai + 1]
  const s = fromCtx || fromArgv || fromEnv || 'normal'
  return VALID_STATES.includes(s) ? s : 'normal'
}

// ---------------------------------------------------------------------------
// 感知控制器
// ---------------------------------------------------------------------------

// S55·D：本应用进程内 perception 模块的首次求值时刻（≈进程启动）。
// session 同意的"重启不恢复"只能按**应用重启**判定；插件重激活（/learn 会 disable/enable
// 本插件以切换 PERCEPTION_STATE）不得刷新它 —— 否则用户点"开始学习"的瞬间授权就被
// 自动吊销（实测：running=false、感知卡显示关闭、教练线整条静默断掉）。
const PROCESS_BOOT_AT = Date.now()

class PerceptionController {
  constructor(ctx, config) {
    this.ctx = ctx || {}
    this.log = this.ctx.log || console
    this.screen = (this.ctx.core && this.ctx.core.screen) || null
    this.config = config
    this.consent = config.consent
    this.state = resolveState(ctx, config)
    this.processStartedAt = PROCESS_BOOT_AT
    this.recorder = createEventRecorder()
    this.collector = null
    this.running = false
    this.paused = false
    this.lastGray = null
    this.lastDiffTs = 0
    this.captureTimes = [] // 滚动 60s 内的落图时间戳
    this.lastShotSavedTs = 0
    this.lastSample = null // 最近一条 1Hz 样本（登记 raw_frame 的窗口元数据来源）
    this.registerSeq = 0 // raw_frame id/trace_id 的进程内序号
    this.budgetLevel = 0
    this.budgetTimer = null
    // S74c·P0-4：拒授权期间的跳过心跳（denied 时采集循环不启动，靠它定期落聚合审计）
    this._skipHeartbeatTimer = null
    // S23·B：活动摘要器（间隔/滚动帧数读 config.summary；窗口停留来自 1Hz 元数据，
    // 变化分类来自 diff 节点的规则式 classifyChange；敏感窗口摘要脱敏）。
    this.summarizer = createSummarizer({
      intervalMs: (config.summary && config.summary.intervalMs) || DEFAULT_SUMMARY_INTERVAL_MS,
      scrollMinorFrames: (config.summary && config.summary.scrollMinorFrames) || DEFAULT_SCROLL_MINOR_FRAMES,
    })
    this.summaryWriter = createSummaryWriter({ dir: PERCEPTION_DIR })
    this.lastWindowMeta = null // 最近一次 diff 节点的前台窗口元数据（切窗判定基准）
    // 统计（供 status 命令 / 验收）
    this.stats = { events: 0, summaries: 0, shotsSaved: 0, shotsRejectedSensitive: 0, captureDecisions: 0, restarts: 0 }
  }

  _consentCtx() {
    return { now: Date.now(), processStartedAt: this.processStartedAt }
  }

  /**
   * S74c·P0-4：拒授权期间的跳过心跳。
   * 采集循环在 denied 时不启动（隐私红线），但"因未授权而没抓屏"这件事必须留痕——
   * 否则用户看到系统像哑了。这里只按 15s 节拍记一次聚合跳过（不采集任何屏幕/窗口数据），
   * 由 skip-audit 合并为每 60s 至多 1 条；授权后立即停掉。
   */
  _startConsentSkipHeartbeat() {
    if (this._skipHeartbeatTimer) return
    const tick = () => { try { recordSkippedNoConsent({ reason: 'consent-inactive' }) } catch { /* 尽力 */ } }
    this._skipHeartbeatTimer = setInterval(tick, 15000)
    if (this._skipHeartbeatTimer && typeof this._skipHeartbeatTimer.unref === 'function') this._skipHeartbeatTimer.unref()
  }

  _stopConsentSkipHeartbeat() {
    if (this._skipHeartbeatTimer) {
      try { clearInterval(this._skipHeartbeatTimer) } catch { /* noop */ }
      this._skipHeartbeatTimer = null
    }
  }

  /** 启动采集循环（仅当同意有效）。 */
  start() {
    if (!isActive(this.consent, this._consentCtx())) {
      this.log.info('[perception] 同意未激活（denied/过期/重启失效）→ 不启动采集')
      // S74c·P0-4：denied 不启动采集，但开启跳过心跳让"因未授权没抓"可审计
      this._startConsentSkipHeartbeat()
      return false
    }
    // 同意有效 → 停止跳过心跳（授权后不再出现 skipped-no-consent）
    this._stopConsentSkipHeartbeat()
    if (this.running) return true
    this.running = true
    this.paused = false
    this.collector = startCollector({
      onSample: (s) => this._onSample(s),
      onRestart: () => {
        this.stats.restarts += 1
        appendJsonl(AUDIT_LOG, { ts: Date.now(), kind: 'collector-restart', restarts: this.stats.restarts })
      },
    })
    const sampleMs = this.config.budget.sampleMs || 30000
    this.budgetTimer = setInterval(() => this._sampleBudget().catch(() => {}), sampleMs)
    this._sampleBudget().catch(() => {})
    return true
  }

  /** 停止采集（只杀自己子树 + 清定时器 + flush 批次）。 */
  stopCollection() {
    if (this.collector) {
      this.collector.stop()
      this.collector = null
    }
    if (this.budgetTimer) {
      clearInterval(this.budgetTimer)
      this.budgetTimer = null
    }
    this._stopConsentSkipHeartbeat() // S74c·P0-4：采集停止时跳过心跳一并停
    try {
      this.recorder.flush()
    } catch {
      /* ignore */
    }
    this.running = false
  }

  pause() {
    if (!this.running) return
    this.stopCollection()
    this.paused = true
    this.log.info('[perception] 已暂停采集（同意保持）')
  }

  resume() {
    this.paused = false
    this.start()
  }

  /** S55·D：授予同意（session 默认 4h 且仅本进程有效）→ 回写 config → 立即开始采集。
   *  此前 consent.grant() 全仓库无调用方 —— 应用内根本没有授权入口，
   *  学习轨迹/问屏幕/感知卡整条教练线都卡在"无授权"。 */
  grantConsent(mode = 'session') {
    const m = mode === 'metadata-only' ? 'metadata-only' : 'session'
    this.consent = grant(m, { now: Date.now() })
    this.config.consent = this.consent
    saveConfig(this.config)
    appendJsonl(AUDIT_LOG, { ts: Date.now(), kind: 'consent-granted', mode: m, expiresAt: this.consent.expiresAt || null })
    this.paused = false
    this.start()
    this.log.info(`[perception] 已授予同意（${m}）`)
    return this.consent
  }

  /** 撤销同意 → denied，回写 config，5 秒内停采。 */
  revokeConsent() {    this.consent = revoke(this.consent)
    this.config.consent = this.consent
    saveConfig(this.config)
    appendJsonl(AUDIT_LOG, { ts: Date.now(), kind: 'consent-revoked' })
    this.stopCollection() // 立即停采（远小于 5s 上限）
    // S74c·P0-4：撤销后回到 denied，重新开启跳过心跳（此后未授权抓屏尝试都会留聚合计）
    this._startConsentSkipHeartbeat()
    this.log.info('[perception] 已撤销同意，采集停止')
  }

  _onSample(sample) {
    this.lastSample = sample // S3.1：留档给原图登记（不改采样本身）
    const state = this.state
    const sensitive = isSensitive(sample.title, sample.process, this.config.blacklist)
    const matched = sensitive ? sensitiveMatched(sample.title, sample.process, this.config.blacklist) : null
    // S74c·P2-7：coldStartCaptureDisabled 用 `!== false` 判定（仅显式 false 关闭保护），
    // 且把 coldStartMinutes 真正接上（此前是死字段，窗口恒为默认 5 分钟）。
    const coldStartEnabled = this.config.coldStartCaptureDisabled !== false
    const coldStartMin = Number(this.config.coldStartMinutes)
    const coldStartMs = Number.isFinite(coldStartMin) && coldStartMin >= 0 ? coldStartMin * 60000 : 300000
    const decision = decide(state, { sensitive }, {
      coldStart: coldStartEnabled,
      coldStartMs,
      processStartedAt: this.processStartedAt,
      now: Date.now(),
    })
    const frame = {
      ts: sample.ts,
      pid: sample.pid,
      hwnd: sample.hwnd,
      process: sample.process,
      title: sample.title,
      idleMs: sample.idleMs,
      isFullscreen: sample.isFullscreen,
      state,
      consent: this.consent.mode,
    }
    const { events } = this.recorder.tick(frame)
    this.stats.events += events.length
    // S23·B：喂活动摘要（1Hz 停留推进；level=none 不计变化），到点落 summary-*.jsonl
    this.summarizer.observe({ ts: sample.ts, process: sample.process, title: sample.title, sensitive })
    const flushed = this.summarizer.maybeFlush(Date.now())
    if (flushed && this.summaryWriter.write(flushed)) this.stats.summaries += 1
    this._maybeCapture(sample, decision, sensitive, matched, Date.now())
  }

  _captureAllowed(cap, now) {
    this.captureTimes = this.captureTimes.filter((t) => now - t < 60000)
    if (now - this.lastShotSavedTs < cap.minIntervalMs) return false
    if (this.captureTimes.length >= cap.maxPerMinute) return false
    return true
  }

  _maybeCapture(sample, decision, sensitive, matched, now) {
    const cap = decision.capture
    // 敏感窗口：无论是否开启截图，命中即拒采 + 写审计（绝不能漏）。
    // S67·1-C：fail-closed 启发式——基于窗口元数据的正则命中即拒采（非内容识别），
    // 审计 kind 改为 skipped-sensitive 并携带命中关键词（why/matched），便于溯源。
    if (sensitive) {
      this.stats.shotsRejectedSensitive += 1
      appendJsonl(AUDIT_LOG, {
        ts: now,
        kind: 'skipped-sensitive',
        why: 'sensitive-window-heuristic',
        matched: matched ? String(matched).slice(0, 40) : 'unknown',
        process: sample.process,
        title: String(sample.title || '').slice(0, 80),
      })
      return
    }
    // S74c·P0-4：未同意 → 落聚合审计 skipped-no-consent 后跳过（此前静默 return，用户以为系统哑了）。
    // 放在 cap.enabled 之前：冷启动禁采期间也会如实记录"因未授权而没抓"。
    if (!allowsScreenCapture(this.consent, this._consentCtx())) { recordSkippedNoConsent({ reason: 'consent-inactive' }); return }
    if (!cap.enabled) return
    if (now - this.lastDiffTs < decision.diffMs) return // 差分节奏闸门
    this.lastDiffTs = now
    if (!this._captureAllowed(cap, now)) return
    this.stats.captureDecisions += 1 // 本应落原图（独立脚本同口径）
    this._doCapture(cap, now).catch((e) => this.log.warn('[perception] 抓取失败: ' + (e && e.message)))
  }

  async _doCapture(cap, now) {
    if (!this.screen || typeof this.screen.captureScreen !== 'function') {
      // 无屏幕桥（如纯 node / 未注入 screen）：仅记录"应落原图"决策，不真正截屏。
      return { captured: false, reason: 'no-screen-bridge' }
    }
    const capr = await this.screen.captureScreen()
    if (!capr || !capr.ok) return { captured: false, reason: 'capture-failed' }
    this._registerRawFrame(capr, now) // S3.1：PNG 已落盘 → 登记进生命周期 DB（fail-soft）
    let gray
    try {
      gray = await adaptCapture(capr) // 动态 import('electron') —— 仅在 Electron 主进程可用
    } catch {
      return { captured: false, reason: 'adapt-failed' }
    }
    if (this.lastGray) {
      const diff = computeDiff(this.lastGray, gray)
      this.lastGray = gray
      // S23·B：规则式变化分类（切窗=进程/标题变化；滚动=连续 minor 累计；阈值沿用既有字段）
      const curMeta = this.lastSample
        ? { process: this.lastSample.process, title: this.lastSample.title }
        : null
      const cls = classifyChange({
        changeScore: diff.changeScore,
        prevWindow: this.lastWindowMeta,
        curWindow: curMeta,
        consecutiveMinor: this.summarizer.consecutiveMinor,
        thresholds: this.config.thresholds,
        scrollMinorFrames: this.config.summary ? this.config.summary.scrollMinorFrames : undefined,
      })
      this.lastWindowMeta = curMeta
      this.summarizer.noteChange(cls)
      if (diff.changeScore >= cap.threshold) {
        const saved = this._saveShot(capr, now)
        if (saved) {
          this.lastShotSavedTs = now
          this.captureTimes.push(now)
          this.stats.shotsSaved += 1
          appendJsonl(AUDIT_LOG, {
            ts: now,
            kind: 'shot-saved',
            changeScore: Number(diff.changeScore.toFixed(4)),
            threshold: cap.threshold,
          })
          return { captured: true, changeScore: diff.changeScore }
        }
        return { captured: false, reason: 'save-failed' }
      }
      return { captured: false, reason: 'below-threshold', changeScore: diff.changeScore }
    }
    this.lastGray = gray
    this.lastWindowMeta = this.lastSample
      ? { process: this.lastSample.process, title: this.lastSample.title }
      : null
    return { captured: false, reason: 'baseline' }
  }

  /**
   * S3.1：把已落盘的抓屏 PNG 登记进生命周期 DB（raw_frame），让保留矩阵真实生效。
   *
   * 规则（任务书）：
   *   · sha256 去重：raw_frame 已有同 sha 且未删（status='ready'）→ 复用，不重复插入；
   *   · expires_at = computeExpiry(sensitivity, mode)：普通 6h / 学习中 20min；
   *   · sensitivity='sensitive' → store/computeExpiry 抛 E_SENSITIVE_NO_PERSIST，
   *     捕获后记审计并继续（不崩、不重试）；
   *   · 登记失败一律 fail-soft：记 perception-register-failed，绝不影响抓屏与采样主流程。
   *
   * store 来源：主进程在就绪后创建的**单例**，经 globalThis.researchOrbLifecycle 交接
   * （ctx.core 是冻结白名单，registry 本任务禁改）；桥不存在（纯 node/测试）→ 直接跳过。
   *
   * @param {{ok:true, pngPath:string, width:number, height:number, hash:string, ts:string, bytes:number, display?:object}} capr 抓屏结果
   * @param {number} now 当前毫秒时间戳
   * @returns {{registered:boolean, reason?:string, id?:string, expires_at?:string}}
   */
  _registerRawFrame(capr, now) {
    const bridge = globalThis.researchOrbLifecycle
    const store = bridge && bridge.store
    if (!store || typeof store.insertRawFrame !== 'function') {
      return { registered: false, reason: 'no-store' }
    }
    this.registerSeq += 1
    const sample = this.lastSample || {}
    const mode = this.state === 'learning' ? 'learning' : 'normal'
    const consent = this.consent || {}
    // 会话同意 id：consent 结构无独立 id 字段，用 mode@grantedAt 派生（非空、可追溯）。
    const consentId =
      consent.grantedAt != null
        ? `${consent.mode || 'unknown'}@${consent.grantedAt}`
        : `${consent.mode || 'unknown'}@boot`
    const base = {
      id: `rf-${now}-${this.registerSeq}`,
      captured_at: capr.ts || new Date(now).toISOString(),
      monitor_id: capr.display && capr.display.id != null ? String(capr.display.id) : null,
      window_id: sample.hwnd != null ? String(sample.hwnd) : null,
      process_name: sample.process || null,
      window_title: String(sample.title || '').slice(0, 200),
      width: capr.width,
      height: capr.height,
      format: 'png',
      file_path: capr.pngPath, // 屏幕桥落盘的绝对路径（data\shots\capture-*.png）
      sha256: String(capr.hash || ''),
      size_bytes: capr.bytes,
      mode,
      sensitivity: 'normal', // 敏感窗口在采样层已拒采，能走到这里的都是普通帧
      consent_id: consentId,
      trace_id: `trc-${now}-${this.registerSeq}`,
    }
    try {
      // 去重：同 sha 且未删 → 复用不重复插入（静态画面反复抓屏不再灌库）。
      const dup = store.listByStatus('ready').find((r) => r.sha256 === base.sha256)
      if (dup) {
        appendJsonl(AUDIT_LOG, { ts: now, kind: 'register-dedupe', sha256: base.sha256.slice(0, 16), existing_id: dup.id })
        return { registered: false, reason: 'duplicate', id: dup.id }
      }
      // 保留矩阵：普通 6h / 学习中 20min；sensitive 在这里会直接抛 E_SENSITIVE_NO_PERSIST。
      const expiresAt = computeExpiry(base.sensitivity, mode, bridge.config)
      const row = store.insertRawFrame({ ...base, expires_at: expiresAt })
      // raw_frame 表 schema（0001 迁移 checksum 锁定）只存核心 8 列；扩展字段
      // （consent_id/monitor_id/window_*/trace_id 等）全量记入 audit_event 供验收追溯。
      store.insertAuditEvent({
        ts: new Date(now).toISOString(),
        kind: 'frame-registered',
        metadata: { ...base, expires_at: expiresAt, row_id: row && row.id },
      })
      appendJsonl(AUDIT_LOG, {
        ts: now,
        kind: 'frame-registered',
        id: base.id,
        sha256: base.sha256.slice(0, 16),
        mode,
        expires_at: expiresAt,
      })
      return { registered: true, id: base.id, expires_at: expiresAt }
    } catch (err) {
      const code = (err && err.code) || null
      const kind = code === 'E_SENSITIVE_NO_PERSIST' ? 'register-sensitive-blocked' : 'perception-register-failed'
      try {
        appendJsonl(AUDIT_LOG, {
          ts: now,
          kind,
          code,
          id: base.id,
          reason: String((err && err.message) || err).slice(0, 200),
        })
      } catch {
        /* 审计失败也不影响主流程 */
      }
      return { registered: false, reason: kind }
    }
  }

  _saveShot(capr, now) {
    try {
      // 屏幕桥落下的 png 在 data/shots 内（根内）；复制进 data/perception/shots（safefs 根内断言）。
      if (!existsSync(capr.pngPath)) return false
      const buf = readFileSync(capr.pngPath)
      const shotPath = join(SHOTS_DIR, `shot-${now}.png`)
      safeWrite(shotPath, buf)
      return true
    } catch {
      return false
    }
  }

  async _sampleBudget() {
    const metrics = await sampleHostMetrics({
      cmdlineMatch: 'research-orb',
      iterations: 6,
      intervalMs: 500,
    }).catch(() => null)
    if (!metrics) return
    const prev = this.budgetLevel
    // S58·P0-1：用基线派生阈值（this.budgetThresholds）；同时留一份诊断给诊断页
    const thresholds = this.budgetThresholds || { ...DEFAULT_THRESHOLDS }
    const diag = diagnoseBudget(metrics, { thresholds })
    this.lastBudget = { metrics, thresholds, fired: diag.fired, level: diag.level, at: Date.now() }
    const res = evaluateBudget(metrics, {
      thresholds,
      current: prev,
    })
    this.budgetLevel = res.level
    if (res.downgraded || res.recovered) {
      appendJsonl(AUDIT_LOG, {
        ts: Date.now(),
        kind: 'budget',
        level: res.level,
        actions: res.actions,
        downgraded: res.downgraded,
        recovered: res.recovered,
        metrics,
        thresholds,
        fired: diag.fired,
      })
      this.log.info(`[perception] 预算${res.downgraded ? '降级' : '恢复'} → L${res.level} (${res.actions.join(',') || '无动作'})`)
    }
  }

  status() {
    // S74c·P0-4：未同意感知下跳过审计的聚合统计（读 perception.jsonl 自身审计）
    const skip = readPerceptionSkippedStats()
    return {
      running: this.running,
      paused: this.paused,
      state: this.state,
      consent: this.consent.mode,
      remainingMs: remainingMs(this.consent, { now: Date.now() }),
      budgetLevel: this.budgetLevel,
      // S58·P0-3：诊断页要看 metrics + 各级 trigger 是否 fired（此前只能靠手写脚本）
      budget: this.lastBudget
        ? {
            level: this.budgetLevel,
            at: this.lastBudget.at,
            metrics: this.lastBudget.metrics,
            thresholds: this.lastBudget.thresholds,
            fired: this.lastBudget.fired,
          }
        : { level: this.budgetLevel, at: null, metrics: null, thresholds: this.budgetThresholds || null, fired: null },
      lastShotSavedTs: this.lastShotSavedTs,
      // S74c·P0-4：让感知状态卡能直接反映"因未同意而跳过"的次数与最近一次，避免用户以为系统哑了
      lastSkippedAt: skip.lastSkippedAt,
      skippedTotal: skip.skippedTotal,
      stats: { ...this.stats },
      collectorPid: this.collector ? this.collector.pid() : null,
      collectorRunning: this.collector ? this.collector.isRunning() : false,
    }
  }
}

// 延迟取 fs（避免顶部静态依赖在极少数环境报错；node 必然可用）。


// ---------------------------------------------------------------------------
// 命令解析
// ---------------------------------------------------------------------------

function parseRest(rest) {
  const tokens = String(rest || '').trim().split(/\s+/).filter(Boolean)
  return { sub: tokens[0] || '', rest: tokens.slice(1).join(' ') }
}

// ---------------------------------------------------------------------------
// 插件激活
// ---------------------------------------------------------------------------

export async function activate(ctx) {
  const log = (ctx && ctx.log) || console
  const config = loadConfig()

  // 启动时：session 模式若进程重启过（PROCESS_BOOT_AT > grantedAt）→ 自动 revoke 到 denied
  // 注：用模块级 PROCESS_BOOT_AT（进程启动时刻），不用 Date.now() —— 插件重激活不是重启。
  let consent = config.consent
  const processStartedAt = PROCESS_BOOT_AT
  if (consent.mode === 'session' && !isActive(consent, { now: processStartedAt, processStartedAt })) {
    consent = revoke(consent)
    config.consent = consent
    saveConfig(config)
    appendJsonl(AUDIT_LOG, { ts: processStartedAt, kind: 'consent-auto-revoke', reason: 'session-invalid-at-boot' })
    log.info('[perception] session 同意在启动时无效（过期/重启）→ 已自动撤销为 denied')
  }

  const controller = new PerceptionController(ctx, config)
  controller.processStartedAt = processStartedAt

  // S58·P0-1：预算阈值改"相对自身基线"（绝对常数必然误触发，本机曾常年 L5）。
  //   · 有 baseline（7 天内）→ 阈值 = base×2.5/2/1.8（内存另受 3000MB 极值兜底）
  //   · 无 baseline → 先用宽松兜底（不做误降级），后台采样 60s 后写 baseline 并收紧
  try {
    const base = readBaseline()
    if (base) {
      controller.budgetThresholds = thresholdsFromBaseline(base)
      controller.log.info(`[perception] 预算阈值来自基线（cpuP95=${base.cpuP95}% cpuAvg=${base.cpuAvg}% mem=${base.memMB}MB）`)
    } else {
      controller.budgetThresholds = { ...FALLBACK_THRESHOLDS }
      controller.log.info('[perception] 无预算基线 → 先用宽松兜底，后台采样 60s 建基线')
      // 后台采样（不阻塞启动）：12 × 5s = 60s
      setTimeout(() => {
        collectBaseline({
          sample: () => sampleHostMetrics({ cmdlineMatch: 'research-orb', iterations: 4, intervalMs: 400 }),
          times: 12,
          intervalMs: 5000,
        }).then((b) => {
          if (!b) return
          const doc = writeBaseline(b)
          if (doc) {
            controller.budgetThresholds = thresholdsFromBaseline(doc)
            controller.log.info(`[perception] 预算基线已建立（samples=${doc.samples}，cpuP95=${doc.cpuP95.toFixed(2)} mem=${doc.memMB.toFixed(0)}MB）`)
          }
        }).catch(() => { /* 采样失败下次启动再试 */ })
      }, 8000).unref?.()
    }
  } catch { /* 基线不可用就走默认兜底 */ }

  // 注册卡片（只描述本地低频感知状态，不显示截图内容）
  if (ctx && ctx.ui && typeof ctx.ui.registerCard === 'function') {
    ctx.ui.registerCard({
      id: 'perception.status',
      title: '本地低频感知',
      body: '1Hz 廉价信号（前台窗口/进程/标题/空闲）+ 差值抑制截图。可见、可暂停、可撤销。原图仅在同意且非敏感窗口下、画面显著变化时落本地 data/perception/shots/，绝不外发、1Hz 不截图。',
    })
  }

  // 注册命令
  if (ctx && ctx.ui && typeof ctx.ui.registerCommand === 'function') {
    ctx.ui.registerCommand({
      name: 'perception',
      title: '本地低频感知控制',
      description: '用法：/perception status｜pause｜resume｜revoke｜self-test',
      run: async (rest = '') => controllerCommand(controller, rest),
    })
  }

  // 启动采集循环（denied 时不启动）
  controller.start()

  return {
    deactivate() {
      controller.stopCollection()
      log.info('[perception] 已停用，采集循环与定时器已清理')
    },
    // 暴露控制器，便于宿主/测试反射（非必需）
    __controller: controller,
  }
}

async function controllerCommand(controller, rest) {
  const { sub } = parseRest(rest)
  if (sub === 'status') {
    const s = controller.status()
    const lines = [
      '本地低频感知状态：',
      `· 采集运行：${s.running ? '是' : '否'}${s.paused ? '（已暂停）' : ''}`,
      `· 当前状态：${s.state}`,
      `· 同意模式：${s.consent}${s.consent === 'session' ? `（剩余 ${Math.round(s.remainingMs / 1000)}s）` : ''}`,
      `· 预算级别：L${s.budgetLevel}`,
      `· 事件数：${s.stats.events}｜落原图：${s.stats.shotsSaved}｜敏感拒采：${s.stats.shotsRejectedSensitive}｜应落原图决策：${s.stats.captureDecisions}`,
      // S74c·P0-4：未同意感知时明确告知"系统因未授权跳过 N 次"，不是哑了
      `· 未授权跳过：累计 ${s.skippedTotal} 次${s.lastSkippedAt ? `（最近 ${new Date(s.lastSkippedAt).toLocaleString('zh-CN')}）` : ''}`,
      `· collector：${s.collectorRunning ? '存活 pid=' + s.collectorPid : '未运行'}`,
    ]
    // S54·D1 感知状态卡：结构化数据随行（对象加字段，不破坏 text 的既有解析者）。
    // today 走审计实读（perception.jsonl 按今日 0 点过滤）——内存 stats 是进程累计，重启会丢"今日"口径。
    // S58·P0-3：budget 诊断（level/metrics/thresholds/fired）一并返回，供 timeline → 诊断页展示。
    // S65·P0-2：回包带 ui → 主进程才会把结果转发给渲染层（无 ui 一律不转发），
    // 命令行触发器（tools\coach-trigger.mjs --perception status）据此判定"命令真的被处理了"。
    return {
      ok: true,
      text: lines.join('\n'),
      stats: { ...s.stats },
      budget: s.budget,
      lastShotSavedTs: s.lastShotSavedTs || 0,
      // S74c·P0-4：跳过聚合统计随行（供状态卡/命令行断言）
      lastSkippedAt: s.lastSkippedAt || 0,
      skippedTotal: s.skippedTotal || 0,
      today: perceptionToday(),
      ui: { kind: 'perception-status', consent: s.consent, state: s.state, budgetLevel: s.budgetLevel, running: !!s.running && !s.paused, lastSkippedAt: s.lastSkippedAt || 0, skippedTotal: s.skippedTotal || 0 },
    }
  }
  if (sub === 'grant') {
    const mode = /metadata/.test(rest) ? 'metadata-only' : 'session'
    const c = controller.grantConsent(mode)
    const hrs = c.expiresAt ? Math.max(1, Math.round((c.expiresAt - Date.now()) / 3600000)) : null
    return {
      ok: true,
      text: `已授予同意（${mode}${hrs != null ? `，${hrs} 小时内有效；应用重启后需重新授权` : ''}）。现在可以开始学习了。`,
      ui: { kind: 'consent', phase: 'granted', mode: c.mode, expiresAt: c.expiresAt || null },
    }
  }
  if (sub === 'pause') {
    controller.pause()
    return { ok: true, text: '已暂停采集（同意保持，可用 /perception resume 恢复）。' }
  }
  if (sub === 'resume') {
    const ok = controller.resume()
    return { ok, text: ok ? '已恢复采集。' : '恢复失败：同意未激活（需先授予同意）。' }
  }
  if (sub === 'revoke') {
    controller.revokeConsent()
    return { ok: true, text: '已撤销同意，采集已停止；重启前不再采集。' }
  }
  if (sub === 'self-test') {
    return { ok: true, text: selfTest() }
  }
  return {
    ok: true,
    text: '本地低频感知用法：\n  /perception status    查看采集/同意/预算状态\n  /perception pause     暂停采集（保持同意）\n  /perception resume    恢复采集\n  /perception revoke    撤销同意并停止采集\n  /perception self-test 跑一致性自检',
  }
}

/** S54·D1：今日感知审计统计（读 perception.jsonl，按今日 0 点过滤；文件缺失/损坏按 0，不抛）。 */
function perceptionToday(now = Date.now()) {
  const out = { samples: 0, shotsSaved: 0, rejectedSensitive: 0, lastSampleTs: 0, sentToModel: 0, sentBytesBefore: 0, sentBytesAfter: 0 }
  try {
    const d0 = new Date(now)
    d0.setHours(0, 0, 0, 0)
    const t0 = d0.getTime()
    if (existsSync(AUDIT_LOG)) {
      for (const line of readFileSync(AUDIT_LOG, 'utf8').split('\n')) {
        const s = line.trim()
        if (!s) continue
        try {
          const row = JSON.parse(s)
          if (!row || typeof row.ts !== 'number' || row.ts < t0) continue
          if (row.kind === 'frame-registered') {
            out.samples += 1
            if (row.ts > out.lastSampleTs) out.lastSampleTs = row.ts
          } else if (row.kind === 'shot-saved') out.shotsSaved += 1
          else if (row.kind === 'skipped-sensitive') out.rejectedSensitive += 1
          else if (row.kind === 'sent-to-model') {
            // S56：真实"压缩送模"事件（coach/extract.mjs 在送模那一刻写）
            out.sentToModel += 1
            const b = Number(row.bytesBefore), a = Number(row.bytesAfter)
            if (Number.isFinite(b)) out.sentBytesBefore += b
            if (Number.isFinite(a)) out.sentBytesAfter += a
          }
        } catch { /* 半行跳过 */ }
      }
    }
  } catch { /* 读不了按 0 */ }
  return out
}

/**
 * S74c·P0-4：聚合「未同意感知而跳过」的审计统计（读 perception.jsonl）。
 * 兼容两种行：聚合行（window==='60s', attempts=N，按 N 计）与单条老行（各计 1）。
 * 返回 lastSkippedAt（最近一次跳过的毫秒时间戳，无则 0）与 skippedTotal（累计跳过次数）。
 */
function readPerceptionSkippedStats() {
  try {
    const f = AUDIT_LOG
    if (!existsSync(f)) return { lastSkippedAt: 0, skippedTotal: 0 }
    const lines = readFileSync(f, 'utf8').split('\n')
    // 只看末尾一段，避免大文件全量扫描；聚合行本就低频
    const start = Math.max(0, lines.length - 4000)
    const rows = []
    for (let i = start; i < lines.length; i++) {
      const s = lines[i].trim()
      if (!s) continue
      try { rows.push(JSON.parse(s)) } catch { /* 半行跳过 */ }
    }
    return computeSkippedStats(rows)
  } catch { return { lastSkippedAt: 0, skippedTotal: 0 } }
}

/** 纯函数一致性自检（不触屏、不落盘）。 */
function selfTest() {
  const checks = []
  const d = decide('learning', {}, {})
  checks.push(`learning 截图最小间隔=${d.capture.minIntervalMs}ms（应≥20000）：${d.capture.minIntervalMs >= LEARNING_MIN_INTERVAL_MS ? 'PASS' : 'FAIL'}`)
  checks.push(`learning 每分上限=${d.capture.maxPerMinute}（应≤3）：${d.capture.maxPerMinute <= 3 ? 'PASS' : 'FAIL'}`)
  checks.push(`普通态截图阈值=${decide('normal').capture.threshold}：${decide('normal').capture.threshold === 0.12 ? 'PASS' : 'FAIL'}`)
  checks.push(`敏感窗口命中（"网上银行"）：${isSensitive('网上银行登录', 'chrome') ? 'PASS' : 'FAIL'}`)
  checks.push(`普通窗口不敏感（"VS Code"）：${!isSensitive('VS Code', 'code') ? 'PASS' : 'FAIL'}`)
  return '感知自检：\n' + checks.join('\n')
}

export default { activate, loadConfig, saveConfig, resolveState }
export { PerceptionController }
