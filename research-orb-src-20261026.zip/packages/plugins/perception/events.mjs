// packages/plugins/perception/events.mjs
//
// 感知层 S2 · 事件化与聚合（§5.2）
//
// 职责边界（只做数据层，绝不触发抓屏 / 不抢前台 / 不发声）：
//   ① 把 1 Hz 的"采样信号"转换成【立即落盘】事件（events.jsonl）；
//   ② 只把 1 Hz 的 tick 累积进【内存聚合】，聚合结果按"≥5 秒或 ≥50 条"
//      一批写一次 summary.jsonl（§1-5 硬判据：1Hz tick 不落任何持久层）。
//
// 可注入性：createEventRecorder 接受 writer 与时钟注入，纯 node 下用假 writer
// 既能验证批次规则又不污染真实盘。默认 writer 走 safefs.appendJsonl。

import { join } from 'node:path'
import { PROJECT_ROOT, appendJsonl, dataPath } from '../../core/src/safefs.mjs'

/** §5.2 允许的立即落盘事件类型（只这些）。 */
export const EVENT_TYPES = Object.freeze([
  'window-switch',
  'title-change',
  'idle-start',
  'idle-end',
  'fullscreen-enter',
  'fullscreen-leave',
  'state-change',
  'consent-change',
])

const DEFAULT_IDLE_THRESHOLD_MS = 5000
const DEFAULT_SUMMARY_MAX_AGE_MS = 5000
const DEFAULT_SUMMARY_MAX_COUNT = 50
const EWMA_ALPHA = 0.2

function dayStamp(ts) {
  const d = new Date(ts)
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}${m}${day}`
}

function defaultEventPath(ts) {
  return dataPath('perception', `events-${dayStamp(ts)}.jsonl`)
}
function defaultSummaryPath(ts) {
  return dataPath('perception', `summary-${dayStamp(ts)}.jsonl`)
}

/**
 * 纯函数：输入上一帧与当前帧，返回本次应【立即落盘】的事件数组（空数组=无事件）。
 * 帧形状（由 sampler 提供，events 不关心来源）：
 *   { ts?, pid, hwnd, process, title, idleMs?, isFullscreen?, state?, consent? }
 *
 * 判定逻辑：
 *   · window-switch：pid 或 hwnd 变化（此时不再派生 title-change，避免重复噪声）。
 *   · title-change：同 pid/hwnd 下 title 变化。
 *   · idle-start / idle-end：idleMs 跨过阈值（默认 5000ms）。
 *   · fullscreen-enter / leave：isFullscreen 翻转。
 *   · state-change：外部注入的 state 字段变化（两端都定义且不同）。
 *   · consent-change：consent 字段变化（两端都定义且不同）。
 *
 * @param {object|null} prev
 * @param {object} cur
 * @param {{idleThresholdMs?:number}} [opts]
 * @returns {Array<object>}
 */
export function detectEvents(prev, cur, opts = {}) {
  const idleThreshold = opts.idleThresholdMs ?? DEFAULT_IDLE_THRESHOLD_MS
  if (!prev) return []

  const t = cur.ts
  const events = []

  const winSwitch = prev.pid !== cur.pid || prev.hwnd !== cur.hwnd
  if (winSwitch) {
    events.push({
      ts: t,
      type: 'window-switch',
      pid: cur.pid,
      hwnd: cur.hwnd,
      process: cur.process,
      title: cur.title,
    })
  } else if (prev.title !== cur.title) {
    events.push({
      ts: t,
      type: 'title-change',
      pid: cur.pid,
      process: cur.process,
      from: prev.title,
      to: cur.title,
    })
  }

  const prevIdle = prev.idleMs ?? 0
  const curIdle = cur.idleMs ?? 0
  if (prevIdle < idleThreshold && curIdle >= idleThreshold) {
    events.push({ ts: t, type: 'idle-start', idleMs: curIdle })
  } else if (prevIdle >= idleThreshold && curIdle < idleThreshold) {
    events.push({ ts: t, type: 'idle-end', idleMs: curIdle })
  }

  if (prev.isFullscreen !== cur.isFullscreen) {
    events.push({
      ts: t,
      type: cur.isFullscreen ? 'fullscreen-enter' : 'fullscreen-leave',
      isFullscreen: cur.isFullscreen,
    })
  }

  const s0 = prev.state
  const s1 = cur.state
  if (s0 !== undefined && s1 !== undefined && s0 !== s1) {
    events.push({ ts: t, type: 'state-change', from: s0, to: s1 })
  }

  const c0 = prev.consent
  const c1 = cur.consent
  if (c0 !== undefined && c1 !== undefined && c0 !== c1) {
    events.push({ ts: t, type: 'consent-change', from: c0, to: c1 })
  }

  return events
}

function newAccumulator() {
  return {
    count: 0,
    durationMs: 0,
    windowSwitches: 0,
    titleChanges: 0,
    idleStarts: 0,
    idleEnds: 0,
    fullscreenChanges: 0,
    stateChanges: 0,
    consentChanges: 0,
  }
}

/**
 * 创建事件记录器（事件化 + 内存聚合）。
 *
 * @param {{
 *   now?: ()=>number,
 *   writeEvent?: (line:object)=>void,
 *   writeSummary?: (line:object)=>void,
 *   idleThresholdMs?: number,
 *   summaryMaxAgeMs?: number,
 *   summaryMaxCount?: number,
 * }} [options]
 *   - now：注入的时钟，返回毫秒；默认 Date.now。
 *   - writeEvent：注入的事件落盘器（默认走 safefs 写 data/perception/events-*.jsonl）。
 *   - writeSummary：注入的汇总落盘器（默认走 safefs 写 data/perception/summary-*.jsonl）。
 *   - idleThresholdMs / summaryMaxAgeMs / summaryMaxCount 可调阈值。
 *
 * @returns {{
 *   tick:(sample:object)=>{events:object[]},
 *   flush:(endTs?:number)=>number,
 *   detectEvents:(prev:object,cur:object,opts?:object)=>object[],
 *   snapshot:()=>({hasPrev:boolean, count:number, ewmaActive:number|null}),
 * }}
 */
export function createEventRecorder(options = {}) {
  const now = typeof options.now === 'function' ? options.now : Date.now
  const idleThresholdMs = options.idleThresholdMs ?? DEFAULT_IDLE_THRESHOLD_MS
  const summaryMaxAgeMs = options.summaryMaxAgeMs ?? DEFAULT_SUMMARY_MAX_AGE_MS
  const summaryMaxCount = options.summaryMaxCount ?? DEFAULT_SUMMARY_MAX_COUNT

  const writeEvent =
    typeof options.writeEvent === 'function'
      ? options.writeEvent
      : (line) => appendJsonl(defaultEventPath(line.ts), line)
  const writeSummary =
    typeof options.writeSummary === 'function'
      ? options.writeSummary
      : (line) => appendJsonl(defaultSummaryPath(line.ts), line)

  let prev = null
  let batchStart = null
  let acc = null
  let ewmaActive = null

  const timeOf = (sample) =>
    sample && typeof sample.ts === 'number' ? sample.ts : now()

  /**
   * 强制把当前内存聚合写出一次（清空批次）。返回写出的行数（0/1）。
   * @param {number} [endTs] 批次结束时间；缺省用 now()。
   */
  function flush(endTs) {
    if (!acc || acc.count === 0) return 0
    const ts = typeof endTs === 'number' ? endTs : now()
    const line = {
      ts,
      type: 'tick-batch',
      count: acc.count,
      durationMs: acc.durationMs,
      windowSwitches: acc.windowSwitches,
      titleChanges: acc.titleChanges,
      idleStarts: acc.idleStarts,
      idleEnds: acc.idleEnds,
      fullscreenChanges: acc.fullscreenChanges,
      stateChanges: acc.stateChanges,
      consentChanges: acc.consentChanges,
      ewmaActive: ewmaActive === null ? null : Number(ewmaActive.toFixed(4)),
    }
    writeSummary(line)
    acc = newAccumulator()
    batchStart = ts
    return 1
  }

  /**
   * 喂入一个采样样本。
   * @param {object} sample
   * @returns {{events: object[]}}
   */
  function tick(sample) {
    const t = timeOf(sample)
    const cur = { ...(sample || {}), ts: t }

    // 首帧：仅建立基线，不派生任何事件；开批次。
    if (prev === null) {
      prev = cur
      if (batchStart === null) batchStart = t
      if (acc === null) acc = newAccumulator()
      return { events: [] }
    }
    if (acc === null) {
      acc = newAccumulator()
      batchStart = t
    }

    // —— 事件：立即落盘，不进批次 ——
    const events = detectEvents(prev, cur, { idleThresholdMs })
    for (const e of events) {
      writeEvent(e)
      if (e.type === 'window-switch') acc.windowSwitches++
      else if (e.type === 'title-change') acc.titleChanges++
      else if (e.type === 'idle-start') acc.idleStarts++
      else if (e.type === 'idle-end') acc.idleEnds++
      else if (e.type === 'fullscreen-enter' || e.type === 'fullscreen-leave')
        acc.fullscreenChanges++
      else if (e.type === 'state-change') acc.stateChanges++
      else if (e.type === 'consent-change') acc.consentChanges++
    }

    // —— 内存聚合（计数 / 时长 / EWMA）——
    const dt = Math.max(0, t - prev.ts)
    acc.count++
    acc.durationMs += dt
    // 活跃度：未跨过 idle 阈值记 1，否则 0；EWMA 平滑。
    const active = (cur.idleMs ?? 0) < idleThresholdMs ? 1 : 0
    ewmaActive =
      ewmaActive === null ? active : EWMA_ALPHA * active + (1 - EWMA_ALPHA) * ewmaActive

    // —— 批次写出：≥5 秒 或 ≥50 条 才写（§1-5）——
    if (
      acc.count >= summaryMaxCount ||
      (batchStart !== null && t - batchStart >= summaryMaxAgeMs)
    ) {
      flush(t)
    }

    prev = cur
    return { events }
  }

  return {
    tick,
    flush,
    detectEvents,
    snapshot: () => ({
      hasPrev: prev !== null,
      count: acc ? acc.count : 0,
      ewmaActive,
    }),
  }
}

export default { EVENT_TYPES, detectEvents, createEventRecorder }
