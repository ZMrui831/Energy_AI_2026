// packages/plugins/perception/consent.mjs
//
// §5.6 同意与可见性（纯逻辑，不触屏、不抓图、不弹窗）。
//
// 同意状态结构（将持久化在 data/perception-config.json 的 consent 字段；
// 配置文件由 E 交付子代理创建，本模块只提供读写与判定函数）。
//   { mode: 'metadata-only'|'session'|'denied', grantedAt, expiresAt?,
//     policyVersion, displays[], windowWhitelist[] }
//
// 关键语义：
//   - denied        → 永不采集（含屏幕）。
//   - metadata-only → 长期元数据允许（无强过期），但【只允许元数据，不允许截图】。
//   - session       → ① 未过期（now ≤ expiresAt）且 ② 进程未重启
//                     （processStartedAt ≤ grantedAt，即授权在本进程启动之后授予；
//                      若 processStartedAt > grantedAt 说明应用重启过 → 失效，体现「重启不恢复」）。
//
// 写盘：本模块不创建 config 文件，但提供 saveConsent，走 safefs 写 consent 段（可注入 writer 测试）。

import { safeWrite, PROJECT_ROOT } from '../../core/src/safefs.mjs'
import { join, resolve } from 'node:path'

export const FOUR_HOURS = 4 * 60 * 60 * 1000
export const DEFAULT_POLICY_VERSION = '1.0'

const MODES = ['metadata-only', 'session', 'denied']

/**
 * 授予同意，返回新的 consent 对象（不修改入参）。
 * @param {'metadata-only'|'session'|'denied'} mode
 * @param {object} [opts] { now, ttl, policyVersion, displays, windowWhitelist }
 *   - now: 授予时间戳（默认 Date.now()）
 *   - ttl: session 模式有效期毫秒（默认 4h，且不超过 4h）
 */
export function grant(mode, opts = {}) {
  if (!MODES.includes(mode)) {
    throw new Error(`consent.grant: 非法 mode=${JSON.stringify(mode)}（应为 ${MODES.join('|')}）`)
  }
  const now = typeof opts.now === 'number' ? opts.now : Date.now()
  const policyVersion = opts.policyVersion ?? DEFAULT_POLICY_VERSION
  const base = {
    mode,
    grantedAt: mode === 'denied' ? undefined : now,
    policyVersion,
    displays: opts.displays ?? [],
    windowWhitelist: opts.windowWhitelist ?? [],
  }
  if (mode === 'denied') {
    // denied：不记录 grantedAt/expiresAt（清敏感字段）
    delete base.grantedAt
    return base
  }
  if (mode === 'metadata-only') {
    // metadata-only：长期元数据，无强过期约束，但仍记录 grantedAt。
    return base
  }
  // session：expiresAt = grantedAt + min(4h, ttl)
  const ttl = typeof opts.ttl === 'number' ? opts.ttl : FOUR_HOURS
  base.expiresAt = now + Math.min(FOUR_HOURS, ttl)
  return base
}

/**
 * 当前是否允许采集（含屏幕感知）。
 * @param {object} consent
 * @param {object} ctx { now, processStartedAt }
 */
export function isActive(consent, ctx = {}) {
  if (!consent || consent.mode === 'denied') return false
  if (consent.mode === 'metadata-only') return true // 长期元数据允许
  // session：
  const now = typeof ctx.now === 'number' ? ctx.now : Date.now()
  // ① 过期判定
  if (consent.expiresAt != null && now > consent.expiresAt) return false
  // ② 重启不恢复：本次进程启动晚于授权授予时间 → 失效
  if (
    typeof ctx.processStartedAt === 'number' &&
    typeof consent.grantedAt === 'number' &&
    ctx.processStartedAt > consent.grantedAt
  ) {
    return false
  }
  return true
}

/**
 * 是否允许【截图/屏幕采集】。metadata-only 仅元数据，不允许截图；session 视 isActive。
 * @param {object} consent
 * @param {object} ctx
 */
export function allowsScreenCapture(consent, ctx = {}) {
  if (!consent) return false
  if (consent.mode === 'session') return isActive(consent, ctx)
  return false
}

/**
 * 撤销同意 → 返回 denied 状态（清 grantedAt/expiresAt 敏感字段）。
 * @param {object} consent
 */
export function revoke(consent = {}) {
  const out = { mode: 'denied', policyVersion: consent.policyVersion ?? DEFAULT_POLICY_VERSION }
  return out
}

/**
 * 会话剩余毫秒（用于 UI「原图剩余 18 分钟」）。
 * 非 session 或无 expiresAt 返回 0。
 * @param {object} consent
 * @param {object} ctx { now }
 */
export function remainingMs(consent, ctx = {}) {
  if (!consent || consent.mode !== 'session' || consent.expiresAt == null) return 0
  const now = typeof ctx.now === 'number' ? ctx.now : Date.now()
  return Math.max(0, consent.expiresAt - now)
}

/**
 * 写盘：把 consent 段写入 data/perception-config.json（走 safefs，根内断言 + 审计）。
 * 默认 writer 用 safeWrite；测试可注入 writer 验证而不落真实盘。
 * @param {object} consent
 * @param {object} [opts] { path?, writer? }
 */
export function saveConsent(consent, opts = {}) {
  const writer = opts.writer || defaultWriter
  const path =
    opts.path || join(PROJECT_ROOT, 'data', 'perception-config.json')
  return writer(path, { consent })
}

function defaultWriter(path, data) {
  return safeWrite(path, JSON.stringify(data, null, 2))
}

export default {
  FOUR_HOURS,
  DEFAULT_POLICY_VERSION,
  grant,
  isActive,
  allowsScreenCapture,
  revoke,
  remainingMs,
  saveConsent,
}
