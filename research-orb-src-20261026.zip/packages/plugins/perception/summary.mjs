// packages/plugins/perception/summary.mjs
//
// S23·B 活动摘要（规则式）：把一段时间窗口的前台停留 + 画面变化压成一句中文，
// 落 data\perception\summary-YYYYMMDD.jsonl。
//
// 纪律：
//   · 不 OCR、不用模型——只吃 1Hz 元数据（process/title）与 diff 分类结果。
//   · 敏感窗口：命中 isSensitive 的样本参与"有窗口"事实，但摘要文本脱敏为
//     「敏感窗口（已略）」，process/title 置 null，绝不外泄标题与进程名。
//   · 间隔/滚动阈值走 perception-config.json 的 summary 段（可配，默认 5 分钟 / 3 帧）。
//   · 落盘走 appendJsonl（根内断言 + 审计语义与其它感知日志一致）。

import { join } from 'node:path'
import { appendJsonl } from '../../core/src/safefs.mjs'

export const DEFAULT_SUMMARY_INTERVAL_MS = 5 * 60 * 1000
export const DEFAULT_SCROLL_MINOR_FRAMES = 3

function clip(s, n = 60) {
  const t = String(s || '').replace(/\s+/g, ' ').trim()
  return t.length > n ? t.slice(0, n) + '…' : t
}

function iso(ts) {
  try { return new Date(ts).toISOString() } catch { return new Date().toISOString() }
}

function dayStamp(ts) {
  const d = new Date(ts)
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}`
}

/** 组装一条摘要记录（纯函数，可测）。sensitive → 脱敏文本 + 字段置空。 */
export function buildSummaryRecord(win, endTs) {
  const w = win || {}
  const dwellMs = Math.max(0, (endTs || w.lastTs || w.startTs || 0) - (w.startTs || 0))
  const minutes = Math.max(1, Math.round(dwellMs / 60000))
  const level = w.major > 0 ? 'major' : (w.minor > 0 ? 'minor' : 'none')
  const base = {
    windowStart: iso(w.startTs || endTs),
    windowEnd: iso(endTs),
    dwellMs,
    process: null,
    title: null,
    sensitive: !!w.sensitive,
    changes: w.changes || 0,
    minor: w.minor || 0,
    major: w.major || 0,
    switches: w.switches || 0,
    level,
  }
  if (base.sensitive) {
    return { ...base, text: '敏感窗口（已略）' }
  }
  return {
    ...base,
    process: clip(w.process, 40),
    title: clip(w.title, 60),
    text: `前台 ${clip(w.process, 40)}（${clip(w.title, 40) || '未知窗口'}）${minutes} 分钟，画面变化 ${base.changes} 次（${base.switches} 次切窗）`,
  }
}

/**
 * 摘要器：observe(样本) 维护当前窗口的停留/变化计数；maybeFlush(now) 到点产出记录。
 * 样本形态：{ ts, process, title, sensitive, level?, reason? }。
 *   · 进程变化 → 关闭旧窗口、开新窗口（返回旧窗口的摘要记录）。
 *   · level 'none' 只推进停留时间；'minor'/'major' 计入 changes（noteChange 亦可喂 diff 结果）。
 */
export function createSummarizer({ intervalMs = DEFAULT_SUMMARY_INTERVAL_MS, scrollMinorFrames = DEFAULT_SCROLL_MINOR_FRAMES } = {}) {
  let cur = null

  function newWindow(s, ts) {
    return {
      startTs: ts,
      lastTs: ts,
      process: s.process || '',
      title: s.title || '',
      sensitive: !!s.sensitive,
      changes: 0,
      minor: 0,
      major: 0,
      switches: 0,
      consecutiveMinor: 0,
    }
  }

  return {
    /** 喂一条 1Hz 样本。窗口切换时返回被关闭窗口的摘要记录，否则 null。 */
    observe(s) {
      const sample = s || {}
      const ts = Number.isFinite(sample.ts) ? sample.ts : Date.now()
      if (!cur) { cur = newWindow(sample, ts); return null }
      const switched = String(cur.process || '') !== String(sample.process || '')
      if (switched) {
        cur.switches += 1
        const done = buildSummaryRecord(cur, ts)
        cur = newWindow(sample, ts)
        return done
      }
      cur.lastTs = ts
      if (sample.sensitive) cur.sensitive = true
      if (sample.level === 'minor') { cur.changes += 1; cur.minor += 1; cur.consecutiveMinor += 1 }
      else if (sample.level === 'major') { cur.changes += 1; cur.major += 1; cur.consecutiveMinor = 0 }
      return null
    },
    /** 喂一条 diff 分类结果（与当前 1Hz 窗口同属一窗）。 */
    noteChange({ level = 'none', reason = '' } = {}) {
      if (!cur) return
      if (String(reason || '').startsWith('切窗')) cur.switches += 1
      if (level === 'minor') { cur.changes += 1; cur.minor += 1; cur.consecutiveMinor += 1 }
      else if (level === 'major') { cur.changes += 1; cur.major += 1; cur.consecutiveMinor = 0 }
    },
    get consecutiveMinor() { return cur ? cur.consecutiveMinor : 0 },
    get currentWindow() { return cur ? { ...cur } : null },
    /** 到点产出（返回记录并关闭当前窗口；由调用方落盘）。 */
    maybeFlush(now = Date.now()) {
      if (!cur) return null
      if (now - cur.startTs < intervalMs) return null
      const done = buildSummaryRecord(cur, now)
      cur = null
      return done
    },
    /** 手动收口（停止采集时调用）。 */
    flush(now = Date.now()) {
      if (!cur) return null
      const done = buildSummaryRecord(cur, now)
      cur = null
      return done
    },
    config: { intervalMs, scrollMinorFrames },
  }
}

/** 落盘助手：绑定目录的 summary writer（写 summary-YYYYMMDD.jsonl）。 */
export function createSummaryWriter({ dir }) {
  return {
    path(ts = Date.now()) { return join(dir, `summary-${dayStamp(ts)}.jsonl`) },
    write(record, ts = Date.now()) {
      if (!record) return null
      try { appendJsonl(this.path(ts), record); return this.path(ts) } catch { return null }
    },
  }
}

export default { createSummarizer, createSummaryWriter, buildSummaryRecord, DEFAULT_SUMMARY_INTERVAL_MS, DEFAULT_SCROLL_MINOR_FRAMES }
