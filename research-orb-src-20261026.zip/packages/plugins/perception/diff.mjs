// packages/plugins/perception/diff.mjs
//
// 感知层 S2 · 差分（§5.3）——省钱核心
//
// 纯函数核心只吃"已解码的灰度像素数组" Uint8Array(256*144)，不依赖任何图像解码库、
// 不 import electron、不 import screen-capture.mjs，纯 node 可测。
//
// 抓屏适配（adaptCapture）为可选导出，仅在 Electron 主进程/集成时使用，内部通过
// 动态 import('electron') 引入，纯 node 测试不调用它，避免崩溃。

const DIFF_W = 256
const DIFF_H = 144
const PHASH_DIM = 8 // 8×8 = 64 bits

/**
 * 最近邻缩放：把任意尺寸灰度 Uint8Array(sw*sh) 缩放到 dw×dh。
 * 纯函数，可测，供适配层或测试用。
 * @param {Uint8Array} src
 * @param {number} sw
 * @param {number} sh
 * @param {number} [dw]
 * @param {number} [dh]
 * @returns {Uint8Array}
 */
export function downscaleGray(src, sw, sh, dw = DIFF_W, dh = DIFF_H) {
  const out = new Uint8Array(dw * dh)
  for (let dy = 0; dy < dh; dy++) {
    const sy = Math.min(sh - 1, Math.floor((dy * sh) / dh))
    for (let dx = 0; dx < dw; dx++) {
      const sx = Math.min(sw - 1, Math.floor((dx * sw) / dw))
      out[dy * dw + dx] = src[sy * sw + sx]
    }
  }
  return out
}

/**
 * 简化感知哈希：把灰度图（默认 256×144）按 8×8 分块【平均】，>=中值记 1，
 * 返回长度 64 的 0/1 数组。
 * @param {Uint8Array} gray
 * @param {number} [w]
 * @param {number} [h]
 * @returns {number[]} 长度 64
 */
export function phashBits(gray, w = DIFF_W, h = DIFF_H) {
  const grid = new Float64Array(PHASH_DIM * PHASH_DIM)
  for (let cy = 0; cy < PHASH_DIM; cy++) {
    const sy0 = Math.floor((cy * h) / PHASH_DIM)
    const sy1 = Math.floor(((cy + 1) * h) / PHASH_DIM)
    for (let cx = 0; cx < PHASH_DIM; cx++) {
      const sx0 = Math.floor((cx * w) / PHASH_DIM)
      const sx1 = Math.floor(((cx + 1) * w) / PHASH_DIM)
      let sum = 0
      let n = 0
      for (let sy = sy0; sy < sy1; sy++) {
        for (let sx = sx0; sx < sx1; sx++) {
          sum += gray[sy * w + sx]
          n++
        }
      }
      grid[cy * PHASH_DIM + cx] = n > 0 ? sum / n : 0
    }
  }
  // 中值
  const sorted = Array.from(grid).sort((a, b) => a - b)
  const mid = sorted.length >> 1
  const median =
    sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid]
  const bits = new Array(PHASH_DIM * PHASH_DIM)
  for (let i = 0; i < grid.length; i++) bits[i] = grid[i] >= median ? 1 : 0
  return bits
}

/**
 * 把 64 位 0/1 数组转成 BigInt（便于紧凑存储/传输）。
 * @param {number[]} bits
 * @returns {bigint}
 */
export function phashInt(bits) {
  let v = 0n
  for (let i = 0; i < bits.length; i++) {
    if (bits[i]) v |= 1n << BigInt(bits.length - 1 - i)
  }
  return v
}

/**
 * Hamming 距离：两个等长 0/1（或 0/255）比特序列的不同位数。
 * @param {number[]|bigint} a
 * @param {number[]|bigint} b
 * @returns {number}
 */
export function hamming(a, b) {
  if (typeof a === 'bigint' && typeof b === 'bigint') {
    let x = a ^ b
    let c = 0
    while (x > 0n) {
      c += Number(x & 1n)
      x >>= 1n
    }
    return c
  }
  const n = Math.min(a.length, b.length)
  let c = 0
  for (let i = 0; i < n; i++) {
    if ((a[i] ? 1 : 0) !== (b[i] ? 1 : 0)) c++
  }
  return c
}

/**
 * 计算两帧灰度（Uint8Array(256*144)，值 0-255）的差异。
 * @param {Uint8Array} frameA
 * @param {Uint8Array} frameB
 * @returns {{meanDiff:number, histogramDistance:number, phash:number[], changeScore:number}}
 *   · meanDiff：逐像素绝对差均值 / 255         ∈ [0,1]
 *   · histogramDistance：256 桶归一化直方图 L1 距离 / 2 ∈ [0,1]
 *   · phash：frame 各自 64 位感知哈希（0/1 数组）
 *   · changeScore：综合 = max(meanDiff, histogramDistance, hamming/64)
 *        —— hamming/64 即"感知哈希翻转的比例"（变化度，∈[0,1]，相同帧=0、全翻转=1）；
 *           取 max 而非加权：任何一个强线索（像素大变 / 直方图大变 / 结构大变）
 *           都足以判定"画面变了"，避免加权把真实变化稀释到阈值以下；裁剪 [0,1]。
 */
export function computeDiff(frameA, frameB) {
  const N = frameA.length
  const Na = frameB.length
  const len = Math.min(N, Na)

  // meanDiff
  let absSum = 0
  for (let i = 0; i < len; i++) {
    absSum += Math.abs(frameA[i] - frameB[i])
  }
  const meanDiff = len > 0 ? absSum / len / 255 : 0

  // histogramDistance（各自归一化 → L1 距离 / 2）
  const ha = new Float64Array(256)
  const hb = new Float64Array(256)
  for (let i = 0; i < len; i++) {
    ha[frameA[i]]++
    hb[frameB[i]]++
  }
  if (len > 0) {
    for (let k = 0; k < 256; k++) {
      ha[k] /= len
      hb[k] /= len
    }
  }
  let l1 = 0
  for (let k = 0; k < 256; k++) l1 += Math.abs(ha[k] - hb[k])
  const histogramDistance = l1 / 2

  // phash + hamming
  const bitsA = phashBits(frameA, DIFF_W, DIFF_H)
  const bitsB = phashBits(frameB, DIFF_W, DIFF_H)
  const h = hamming(bitsA, bitsB)
  const phashChange = h / 64 // 感知哈希翻转比例（变化度：相同=0，全翻转=1）

  const raw = Math.max(meanDiff, histogramDistance, phashChange)
  const changeScore = Math.max(0, Math.min(1, raw))

  return { meanDiff, histogramDistance, phash: bitsA, changeScore }
}

/**
 * 抓屏适配（可选，需 Electron；纯 node 测试不调用）。
 * 接收 screen-capture.captureScreen() 的结果 {ok, pngPath, width, height, ...}，
 * 用 electron.nativeImage 解码 + 灰度化 + 缩放到 256×144 返回 Uint8Array。
 *
 * electron 通过动态 import 引入，避免纯 node 下因静态 import('electron') 崩溃。
 *
 * @param {{ok:boolean, pngPath?:string}} captureResult
 * @param {object} [electronLike] 可注入的 electron 替身（用于集成测试），缺省动态 import。
 * @returns {Promise<Uint8Array>} 长度 256*144 的灰度数组
 */
export async function adaptCapture(captureResult, electronLike) {
  if (!captureResult || !captureResult.ok || !captureResult.pngPath) {
    throw new Error('adaptCapture: 无效抓屏结果（ok=false 或无 pngPath）')
  }
  const electron = electronLike || (await import('electron'))
  const img = electron.nativeImage.createFromPath(captureResult.pngPath)
  const { width, height } = img.getSize()
  // toBitmap 返回 width*height*4 的 BGRA 字节缓冲
  const buf = img.toBitmap()
  const gray = new Uint8Array(width * height)
  for (let i = 0; i < width * height; i++) {
    const o = i * 4
    const b = buf[o]
    const g = buf[o + 1]
    const r = buf[o + 2]
    // 亮度灰度（Rec. 601）
    gray[i] = Math.round(0.299 * r + 0.587 * g + 0.114 * b)
  }
  return downscaleGray(gray, width, height, DIFF_W, DIFF_H)
}

export default {
  DIFF_W,
  DIFF_H,
  downscaleGray,
  phashBits,
  phashInt,
  hamming,
  computeDiff,
  adaptCapture,
}
