// packages/plugins/perception/metrics.mjs
//
// 主机指标采样（§5.5 预算与验收项 2 共用）。
//
// 默认只统计【命令行含 'research-orb' 的进程】（本项目所有进程路径都含该串，
// 见 stop-app.mjs 的 MARK 约定）——这样测得的是"本应用"的足迹，而非全机 node/powershell 总和。
//
//   · 内存：Get-CimInstance Win32_Process 的 WorkingSetSize 求和（MB）。
//   · CPU：取 KernelModeTime+UserModeTime（100ns 单位）在两采样点间的增量，
//     除以墙钟间隔得到「核心占用百分比」；取均值与 P95。
//
// 纯 node 单测与验收脚本可注入 execFileImpl 避免真实子进程；无法采样时返回 null（绝不抛）。

import { execFile } from 'node:child_process'

const DEFAULT_CMDLINE_MATCH = 'research-orb'

function buildScript(cmdlineMatch, iterations, intervalMs, nameFilter, rootPid) {
  const m = String(cmdlineMatch).replace(/'/g, "''")
  const lines = []
  if (rootPid != null) {
    // Own-tree mode (R2): sample EXACTLY our own process tree — the runner
    // (root pid) plus its direct children (the collector powershell, which may
    // restart with a new pid, so children are re-enumerated every iteration).
    // No fuzzy name matching: the target set is pinned by explicit PIDs.
    lines.push(
      `$root=${Number(rootPid)}`,
      `$me=$PID`,
      `$c=${iterations}`,
      `$ivMs=${intervalMs}`,
      `$snaps=@()`,
      `$wsLast=0`,
      `$lastPids=@()`,
      // 子进程枚举（WMI 查询很慢，~几百 ms/次）：循环前查一次，此后每 8 轮刷新一次。
      // 放进每轮会把 31 轮 × WMI 拖到超时被杀（killed=true，实测复现）。
      `  $kids=@(Get-CimInstance Win32_Process -Filter "ParentProcessId=$root" | ForEach-Object { $_.ProcessId })`,
      `for($i=0;$i -lt $c;$i++){`,
      `  if($i -gt 0 -and $i % 8 -eq 0){ $kids=@(Get-CimInstance Win32_Process -Filter "ParentProcessId=$root" | ForEach-Object { $_.ProcessId }) }`,
      `  $pids=@($root)+$kids`,
      `  $t=0.0; $ws=0`,
      `  foreach($p in $pids){`,
      `    $gp=Get-Process -Id $p -ErrorAction SilentlyContinue`,
      `    if($gp){ $t += $gp.CPU; $ws += $gp.WorkingSet64 }`,
      `  }`,
      `  $snaps+=$t`,
      `  if($ws -gt 0){ $wsLast=$ws }`,
      `  $lastPids=$pids`,
      `  if($i -lt ($c-1)){ Start-Sleep -Milliseconds $ivMs }`,
      `}`,
    )
  } else {
    // Cmdline-match mode: target = command line contains cmdlineMatch, optional
    // exact process-name filter (nameFilter, e.g. 'electron.exe' for app-tree),
    // always excluding the measuring PS itself ($PID — its own script text
    // contains the match string and would pollute samples).
    const nf = nameFilter ? ` -and $_.Name -eq '${String(nameFilter).replace(/'/g, "''")}'` : ''
    lines.push(
      `$match='${m}'`,
      `$me=$PID`,
      `$pids=@(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match $match${nf} -and $_.ProcessId -ne $me } | ForEach-Object { $_.ProcessId })`,
      `$c=${iterations}`,
      `$ivMs=${intervalMs}`,
      `$snaps=@()`,
      `$wsLast=0`,
      `$lastPids=$pids`,
      `for($i=0;$i -lt $c;$i++){`,
      `  $t=0.0; $ws=0`,
      `  foreach($p in $pids){`,
      `    $gp=Get-Process -Id $p -ErrorAction SilentlyContinue`,
      `    if($gp){ $t += $gp.CPU; $ws += $gp.WorkingSet64 }`,
      `  }`,
      `  $snaps+=$t`,
      `  if($ws -gt 0){ $wsLast=$ws }`,
      `  if($i -lt ($c-1)){ Start-Sleep -Milliseconds $ivMs }`,
      `}`,
    )
  }
  lines.push(
    `$vals=@()`,
    `for($i=1;$i -lt $c;$i++){`,
    `  $d=$snaps[$i]-$snaps[$i-1]`,
    `  if($d -lt 0){ $d=0 }`,
    `  $vals+=[math]::Round($d/($ivMs/1000)*100,3)`,
    `}`,
    `[pscustomobject]@{ cpu=$vals; memMB=[math]::Round($wsLast/1MB,1); pids=$lastPids } | ConvertTo-Json -Compress`,
  )
  return lines.join('\n')
}

function runPs(execFileImpl, script, timeoutMs) {
  return new Promise((resolve, reject) => {
    execFileImpl(
      'powershell.exe',
      ['-NoProfile', '-NonInteractive', '-Command', script],
      { encoding: 'utf8', timeout: timeoutMs, windowsHide: true, maxBuffer: 1 << 20 },
      (err, stdout) => {
        if (err) {
          // 调试开关（默认关）：PERCEPTION_METRICS_DEBUG=1 时打印失败原因，便于验收诊断。
          if (process.env.PERCEPTION_METRICS_DEBUG === '1') {
            process.stderr.write(`[metrics:debug] execFile err: ${err && err.message}; killed=${err && err.killed}; stderr=${String(err && err.stderr || '').slice(0, 400)}\n`)
          }
          reject(err)
        } else resolve(String(stdout || ''))
      },
    )
  })
}

function round(n, d) {
  const f = Math.pow(10, d)
  return Math.round((Number(n) || 0) * f) / f
}

/**
 * 采样主机 CPU（均值 / P95）与内存（WS，MB）。
 * 两种互斥的选目标方式（R2 修复：禁止模糊名匹配测错对象）：
 *   - opts.pidRoot: 按显式进程树采样（root + 其直接子进程，每轮重新枚举以覆盖
 *     collector 重启换 pid 的情形）→ 用于"本任务自己的进程树"（runner+collector）。
 *   - opts.cmdlineMatch（可配 opts.nameFilter 精确到进程名）: 命令行匹配模式，
 *     仅用于"应用在跑时"的 app-tree 复测；测量 PS 自身始终排除。
 * @param {object} [opts]
 *   - pidRoot: number（显式进程树根 pid，优先于 cmdlineMatch）
 *   - cmdlineMatch: 进程命令行匹配串（默认 'research-orb'）
 *   - nameFilter: 精确进程名过滤（如 'electron.exe'）
 *   - iterations / intervalMs / timeoutMs
 *   - execFileImpl: 可注入（测试 / 非 Windows）
 * @returns {Promise<{cpuAvg:number, cpuP95:number, memMB:number, sampleCount:number, sampledPids:number[]}|null>}
 */
export async function sampleHostMetrics(opts = {}) {
  const execFileImpl = opts.execFileImpl || execFile
  const rootPid = opts.pidRoot != null ? Number(opts.pidRoot) : null
  const cmdlineMatch = opts.cmdlineMatch || DEFAULT_CMDLINE_MATCH
  const nameFilter = opts.nameFilter || null
  const iterations = opts.iterations || 30
  const intervalMs = opts.intervalMs || 1000
  const timeoutMs = opts.timeoutMs || 120000

  let out
  try {
    out = await runPs(execFileImpl, buildScript(cmdlineMatch, iterations, intervalMs, nameFilter, rootPid), timeoutMs)
  } catch {
    return null
  }
  let parsed
  try {
    parsed = JSON.parse(out)
  } catch {
    if (process.env.PERCEPTION_METRICS_DEBUG === '1') {
      process.stderr.write(`[metrics:debug] JSON.parse 失败; 输出前 400 字符: ${String(out).slice(0, 400)}\n`)
    }
    return null
  }
  const cpu = Array.isArray(parsed.cpu) ? parsed.cpu.filter((n) => Number.isFinite(Number(n))) : []
  if (cpu.length === 0) return null
  const avg = cpu.reduce((a, b) => a + Number(b), 0) / cpu.length
  const sorted = [...cpu].sort((a, b) => Number(a) - Number(b))
  const p95 = sorted[Math.floor((sorted.length - 1) * 0.95)] ?? sorted[sorted.length - 1]
  return {
    cpuAvg: round(avg, 3),
    cpuP95: round(Number(p95), 3),
    memMB: round(parsed.memMB || 0, 1),
    sampleCount: cpu.length,
    sampledPids: Array.isArray(parsed.pids) ? parsed.pids.map(Number).filter(Number.isFinite) : [],
  }
}

export default { sampleHostMetrics }
