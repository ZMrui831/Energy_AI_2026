// packages/plugins/perception/classify.mjs
//
// S23·B 变化分类（规则式，不 OCR、不用模型）：把"变没变"升级为 none/minor/major + reason。
//
// 纪律：
//   · 阈值一律**参数化读取**既有 thresholds 字段（changeScoreCandidate=minor 下限、
//     changeScoreNormal=major 下限），不新增魔法数、不改默认值。
//   · 切窗：前台进程或标题变化 → major（理由注明进程/标题）。
//   · 滚动：连续 minor 累计 ≥ scrollMinorFrames（可配）→ reason 标注"滚动累计"。
//
// 纯函数，输入是 computeDiff 的 changeScore + 两帧窗口元数据，纯 node 可测。

/**
 * @param {{
 *   changeScore?: number,
 *   prevWindow?: {process?:string, title?:string} | null,
 *   curWindow?: {process?:string, title?:string} | null,
 *   consecutiveMinor?: number,
 *   thresholds?: {changeScoreCandidate?:number, changeScoreNormal?:number},
 *   scrollMinorFrames?: number,
 * }} input
 * @returns {{level:'none'|'minor'|'major', reason:string}}
 */
export function classifyChange(input = {}) {
  const {
    changeScore = 0,
    prevWindow = null,
    curWindow = null,
    consecutiveMinor = 0,
    thresholds = {},
    scrollMinorFrames = 3,
  } = input
  const minorT = Number.isFinite(thresholds.changeScoreCandidate)
    ? thresholds.changeScoreCandidate
    : 0.08
  const majorT = Number.isFinite(thresholds.changeScoreNormal)
    ? thresholds.changeScoreNormal
    : 0.12

  // 1) 切窗：前台进程 / 标题变化（规则式，零像素依赖）
  if (prevWindow && curWindow) {
    const procChanged = String(prevWindow.process || '') !== String(curWindow.process || '')
    const titleChanged = String(prevWindow.title || '') !== String(curWindow.title || '')
    if (procChanged) return { level: 'major', reason: `切窗：前台 ${String(curWindow.process || '').slice(0, 40)}` }
    if (titleChanged) return { level: 'major', reason: '切窗：标题变化' }
  }

  // 2) 像素差分分档（阈值沿用 perception-config.json 的既有字段）
  const score = Number.isFinite(changeScore) ? changeScore : 0
  if (score < minorT) return { level: 'none', reason: '画面未变' }
  if (score < majorT) {
    const consec = Number.isFinite(consecutiveMinor) ? consecutiveMinor : 0
    if (consec >= scrollMinorFrames) return { level: 'minor', reason: `滚动累计（连续 ${consec} 帧微变）` }
    return { level: 'minor', reason: '画面微变' }
  }
  return { level: 'major', reason: '画面大变' }
}

export default { classifyChange }
