// packages/plugins/perception/sampler.mjs
//
// §5.4 五状态采样决策表（纯函数 + 支持外部注入状态）与 §5.7 敏感窗口黑名单。
//
// 五状态（state 由外部注入；学习态判定本身属 S5，不在本任务范围）：
//   idle / normal / candidate / learning / dnd
//
// decide(state, signals, config) → 采样决策：
//   { pollMs, aggregateMs, diffMs,
//     capture: { enabled, minIntervalMs, maxPerMinute, threshold },
//     uploadModel: bool, interruptible: bool }
//
// 硬约束（§1-4）：学习中状态截图间隔最小值 ≥20 秒（maxPerMinute ≤3 且 minIntervalMs≥20000）。
//   decide 在 learning 状态【强制】capture.minIntervalMs >= 20000（即便 config 给更小值也要
//   钳制到 20000）。这是不可突破的硬上限——任何 config 都无法降低它（见 clampLearningCap）。

/**
 * §5.7 默认敏感窗口正则（大小写不敏感，命中 title 或 processName 任一即 true）。
 * S67·1-C 扩展：密码管理器（1Password/Bitwarden/KeePass/LastPass）、终端/解释器
 * （cmd.exe/powershell/终端/ssh）、私钥（id_rsa）、医疗处方（病历/处方）、银行网银支付。
 * 诚实声明：这是**基于窗口元数据的启发式拒截**，**不做图像/内容识别**——
 * 名单外或内容级敏感无法识别（见 docs/局限清单.md 第 8 条）。
 */
export const DEFAULT_SENSITIVE_RE =
  /1Password|Bitwarden|KeePass|LastPass|密码|Login Data|银行|网银|支付|医疗|病历|处方|health|bank|cmd\.exe|powershell|终端|ssh|id_rsa/i

/** learning 状态截图硬上限（不可被 config 突破）。 */
export const LEARNING_MIN_INTERVAL_MS = 20000
export const LEARNING_MAX_PER_MINUTE = 3

/**
 * §5.7 敏感窗口判定（纯函数）。
 * @param {string} title 窗口标题
 * @param {string} processName 进程名
 * @param {RegExp|string} [blacklist] 可覆盖默认（RegExp 或字符串）
 * @returns {boolean}
 */
export function isSensitive(title = '', processName = '', blacklist) {
  const re =
    blacklist != null
      ? typeof blacklist === 'string'
        ? new RegExp(blacklist, 'i')
        : blacklist
      : DEFAULT_SENSITIVE_RE
  const t = String(title || '')
  const p = String(processName || '')
  return re.test(t) || re.test(p)
}

/**
 * 返回命中的敏感关键词（用于审计 skipped-sensitive 的 matched 字段）。
 * 未命中返回 null。与 isSensitive 同源正则，便于追溯是哪条规则拒采。
 */
export function sensitiveMatched(title = '', processName = '', blacklist) {
  const re =
    blacklist != null
      ? typeof blacklist === 'string'
        ? new RegExp(blacklist, 'i')
        : blacklist
      : DEFAULT_SENSITIVE_RE
  const t = String(title || '')
  const p = String(processName || '')
  const m = re.exec(t) || re.exec(p)
  return m ? m[0] : null
}

/**
 * 决策表默认值（可被 config 覆盖）。所有间隔以毫秒计。
 * 表中「每60s≤1张」「每20s≤1张」换算为 maxPerMinute 与 minIntervalMs。
 */
const DEFAULTS = {
  idle: { pollMs: 30000, aggregateMs: 60000, diffMs: 60000, capture: { enabled: false, minIntervalMs: 0, maxPerMinute: 0, threshold: 1 } },
  normal: { pollMs: 5000, aggregateMs: 10000, diffMs: 5000, capture: { enabled: true, minIntervalMs: 60000, maxPerMinute: 1, threshold: 0.12 } },
  candidate: { pollMs: 1000, aggregateMs: 1000, diffMs: 5000, capture: { enabled: true, minIntervalMs: 20000, maxPerMinute: 3, threshold: 0.08 } },
  learning: { pollMs: 1000, aggregateMs: 1000, diffMs: 1000, capture: { enabled: true, minIntervalMs: 20000, maxPerMinute: 3, threshold: 0 } },
  dnd: { pollMs: 30000, aggregateMs: 0, diffMs: 0, capture: { enabled: false, minIntervalMs: 0, maxPerMinute: 0, threshold: 1 } },
}

const VALID_STATES = ['idle', 'normal', 'candidate', 'learning', 'dnd']

/**
 * 将 config 覆盖合并进某状态的默认决策。
 */
function resolveState(state, config = {}) {
  const base = DEFAULTS[state]
  const override = (config.overrides && config.overrides[state]) || {}
  const capture = { ...base.capture, ...(override.capture || {}) }
  return {
    pollMs: override.pollMs ?? base.pollMs,
    aggregateMs: override.aggregateMs ?? base.aggregateMs,
    diffMs: override.diffMs ?? base.diffMs,
    capture,
    uploadModel: false, // 五状态均不上远端模型（§5.4 表）
    interruptible: false, // 五状态均不可打扰（§5.4 表）
  }
}

/**
 * 钳制 learning 状态的截图硬上限：minIntervalMs ≥20000 且 maxPerMinute ≤3。
 * 不可被 config 突破——即使 config 给更小值也要拉回 20000。
 */
function clampLearningCap(decision) {
  const cap = { ...decision.capture }
  if (cap.minIntervalMs < LEARNING_MIN_INTERVAL_MS) cap.minIntervalMs = LEARNING_MIN_INTERVAL_MS
  if (cap.maxPerMinute > LEARNING_MAX_PER_MINUTE) cap.maxPerMinute = LEARNING_MAX_PER_MINUTE
  return { ...decision, capture: cap }
}

/**
 * 五状态采样决策。
 * @param {string} state 五状态之一
 * @param {object} [signals] { changeScore?, sensitive? } 本帧信号（可选）
 * @param {object} [config] { overrides?, coldStart?, coldStartMs?, now?, processStartedAt? }
 *   - coldStart: 开启冷启动保护（普通态前 N ms 关闭截图）
 *   - coldStartMs: 冷启动窗口（默认 300000 = 5 分钟）
 *   - now / processStartedAt: 用于计算冷启动已用时长
 * @returns 采样决策对象
 */
export function decide(state, signals = {}, config = {}) {
  if (!VALID_STATES.includes(state)) {
    throw new Error(`sampler.decide: 非法 state=${JSON.stringify(state)}（应为 ${VALID_STATES.join('|')}）`)
  }
  let decision = resolveState(state, config)

  // 学习中：强制截图硬上限（不可突破）。
  if (state === 'learning') {
    decision = clampLearningCap(decision)
  }

  // 冷启动保护：普通态 + 冷启动窗口内 → 关闭截图。
  if (config.coldStart && state === 'normal') {
    const now = typeof config.now === 'number' ? config.now : Date.now()
    const start = typeof config.processStartedAt === 'number' ? config.processStartedAt : now
    const elapsed = now - start
    const coldMs = typeof config.coldStartMs === 'number' ? config.coldStartMs : 300000
    if (elapsed < coldMs) {
      decision = { ...decision, capture: { ...decision.capture, enabled: false } }
    }
  }

  // 敏感窗口：命中则拒采截图（由 E 在采集循环调用 isSensitive；此处若传入 sensitive 信号也拒采）。
  if (signals && signals.sensitive) {
    decision = { ...decision, capture: { ...decision.capture, enabled: false } }
  }

  return decision
}

export default {
  DEFAULT_SENSITIVE_RE,
  LEARNING_MIN_INTERVAL_MS,
  LEARNING_MAX_PER_MINUTE,
  isSensitive,
  sensitiveMatched,
  decide,
}
