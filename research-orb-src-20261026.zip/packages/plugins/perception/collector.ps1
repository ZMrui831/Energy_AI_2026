# perception-collector.ps1
#
# Long-lived helper. Node spawns this exactly once; it loops forever and prints
# ONE JSON object per second to stdout (JSONL). Each object is cheap foreground
# window metadata only -- never a screenshot.
#
# Contract:
#   - Windows PowerShell 5.1 compatible (no 7+ only cmdlets / syntax).
#   - UTF-8 output, NO BOM.
#   - ASCII comments only (no Chinese) to avoid encoding pitfalls.
#   - NO global hooks (no SetWindowsHookEx). We only poll cheap Win32 facts.
#   - Never steals focus, never shows a window, never makes sound.
#   - Exits cleanly when stdout is closed or the process is killed.
#
# Each JSON line has these fixed fields:
#   ts, hwnd, pid, process, title, idleMs, isFullscreen, monitorId

$ErrorActionPreference = 'SilentlyContinue'

# Force UTF-8 WITHOUT BOM on stdout.
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = $utf8NoBom

# Win32 P/Invoke (all cheap, no hooks).
Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;

public class PCollect {
  public struct LASTINPUTINFO { public uint cbSize; public uint dwTime; }
  public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern int GetWindowTextLength(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
  [DllImport("user32.dll")] public static extern uint GetLastInputInfo(ref LASTINPUTINFO plii);
  [DllImport("kernel32.dll")] public static extern IntPtr OpenProcess(uint dwDesiredAccess, bool bInheritHandle, uint dwProcessId);
  [DllImport("kernel32.dll")] public static extern uint WaitForSingleObject(IntPtr hHandle, uint dwMilliseconds);
  [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr hObject);
}
"@

# WinForms is only used for primary-screen geometry (best effort); the bounds
# are cached once -- screen geometry does not change per second.
$winformsOk = $false
try {
  Add-Type -AssemblyName System.Windows.Forms
  $winformsOk = $true
} catch {
  $winformsOk = $false
}
$screenBounds = $null
if ($winformsOk) {
  try { $screenBounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds } catch { $screenBounds = $null }
}

# Process-name cache: the foreground process name only changes when the
# foreground PID changes. Avoids a Get-Process cmdlet round-trip every second
# (实测：PS 每秒 cmdlet 开销是 own-tree CPU 的主要来源，缓存后显著下降).
$lastPid = -1
$lastProcName = ''

# Reusable buffers: New-Object in PS 5.1 costs ~1-3ms per call; creating
# StringBuilder/RECT/LASTINPUTINFO every poll round was the dominant CPU cost
# of the 1 Hz loop (~41ms/round 实测). Allocate once, reuse forever.
$script:titleBuf = New-Object System.Text.StringBuilder(1024)
$script:rect = New-Object PCollect+RECT
$script:lii = New-Object PCollect+LASTINPUTINFO
$script:lii.cbSize = [uint32][System.Runtime.InteropServices.Marshal]::SizeOf($script:lii)

function Get-IdleMs {
  if ([PCollect]::GetLastInputInfo([ref]$script:lii) -ne 0) {
    $diff = [Environment]::TickCount - [int]$script:lii.dwTime
    if ($diff -lt 0) { $diff = 0 }
    return $diff
  }
  return 0
}

# Returns the JSON line directly (no intermediate pscustomobject).
function Get-ForegroundJson {
  $hwnd = [PCollect]::GetForegroundWindow()
  $procId = 0
  $proc = ''
  $title = ''
  $full = $false

  if ($hwnd -ne [IntPtr]::Zero) {
    $len = [PCollect]::GetWindowTextLength($hwnd)
    if ($len -gt 0) {
      if ($script:titleBuf.Capacity -lt ($len + 1)) { [void]$script:titleBuf.EnsureCapacity($len + 1) }
      $script:titleBuf.Length = 0
      [void][PCollect]::GetWindowText($hwnd, $script:titleBuf, $len + 1)
      $title = $script:titleBuf.ToString()
    }

    $outPid = 0
    [void][PCollect]::GetWindowThreadProcessId($hwnd, [ref]$outPid)
    $procId = [int]$outPid

    if ($procId -ne $script:lastPid) {
      $p = Get-Process -Id $procId -ErrorAction SilentlyContinue
      if ($p) { $script:lastProcName = $p.ProcessName } else { $script:lastProcName = '' }
      $script:lastPid = $procId
    }
    $proc = $script:lastProcName

    if ($null -ne $screenBounds) {
      if ([PCollect]::GetWindowRect($hwnd, [ref]$script:rect)) {
        $b = $screenBounds
        $r = $script:rect
        if (($r.Left -le $b.Left) -and ($r.Top -le $b.Top) -and
            ($r.Right -ge $b.Right) -and ($r.Bottom -ge $b.Bottom)) {
          $full = $true
        }
      }
    }
  }

  $escProc = $proc.Replace('\', '\\').Replace('"', '\"')
  $escTitle = $title.Replace('\', '\\').Replace('"', '\"')
  return '{"ts":' + [DateTimeOffset]::Now.ToUnixTimeMilliseconds() +
         ',"hwnd":' + [int64]$hwnd.ToInt64() +
         ',"pid":' + $procId +
         ',"process":"' + $escProc +
         '","title":"' + $escTitle +
         '","idleMs":' + (Get-IdleMs) +
         ',"isFullscreen":' + $(if ($full) { 'true' } else { 'false' }) +
         ',"monitorId":"' + $monitorId.Replace('\', '\\') + '"}'
}

# Monitor id is fixed to the primary display (literal backslash-backslash-dot form).
$monitorId = '\\.\DISPLAY1'

# ---------------------------------------------------------------------------
# Parent-PID guardian (orphan protection).
# Node passes its own PID as argv[0]. If the parent (the Node controller)
# disappears without a chance to taskkill us -- SIGKILL, power loss, crashed
# host -- we must self-terminate within ~1 second (one poll interval).
# No parent pid given -> behave exactly as before (long-lived until killed).
# ---------------------------------------------------------------------------
$parentPid = 0
if ($args.Count -ge 1 -and $args[0] -match '^\d+$') { $parentPid = [int]$args[0] }

function Test-ParentAlive {
  if ($parentPid -le 0) { return $true }
  $p = Get-Process -Id $parentPid -ErrorAction SilentlyContinue
  if ($null -eq $p) { return $false }
  return (-not $p.HasExited)
}

# Parent handle for zero-cmdlet guarding: WaitForSingleObject doubles as the
# 1 s sleep AND the orphan check (returns immediately when the parent dies).
# Falls back to Start-Sleep + Test-ParentAlive when a handle cannot be opened.
$SYNCHRONIZE = [uint32]'0x00100000'
$hParent = [IntPtr]::Zero
if ($parentPid -gt 0) {
  try { $hParent = [PCollect]::OpenProcess($SYNCHRONIZE, $false, [uint32]$parentPid) } catch { $hParent = [IntPtr]::Zero }
  if ($hParent -eq [IntPtr]::Zero -and -not (Test-ParentAlive)) { exit 0 }
}

# Clean exit on Ctrl-C / terminate.
trap { exit 0 }

try {
  while ($true) {
    # Sleep 1s while simultaneously guarding the parent: WaitForSingleObject
    # returns WAIT_OBJECT_0 the instant the parent process dies (covers
    # SIGKILL / power loss within ms, far better than a 1 s poll).
    if ($hParent -ne [IntPtr]::Zero) {
      $w = [PCollect]::WaitForSingleObject($hParent, 1000)
      if ($w -eq 0) { [void][PCollect]::CloseHandle($hParent); exit 0 }
    } else {
      Start-Sleep -Milliseconds 1000
      # Orphan guard fallback (no parent handle available).
      if (-not (Test-ParentAlive)) { exit 0 }
    }
    $json = Get-ForegroundJson
    # Write raw bytes via Console.Out (respects OutputEncoding, no extra newline).
    [Console]::Out.Write($json + [char]10)
  }
} catch {
  # stdout closed or interrupted: exit cleanly, do not linger.
  exit 0
}
