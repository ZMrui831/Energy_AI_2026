// packages/plugins/perception/skip-audit.mjs
//
// S74c·P0-4：拒授权期间「因未同意而跳过抓屏」的聚合审计（60s 窗口合并）。
//
// 背景（缺陷原文）：consent 未激活时感知抓屏闸门 _maybeCapture 直接静默 return，不留任何审计。
// 未授权时用户看到"系统像哑了"，事后也无从判断"到底是因为没授权还是坏了"。
//
// 修复：所有"因未同意而跳过"的事件落入本聚合器，按 60s 固定窗口（对齐墙钟）合并为单条：
//   { kind:'skipped-no-consent', window:'60s', attempts, reason, firstTs, lastTs }
// 落 perception.jsonl（感知自身审计日志，与 skipped-sensitive 等同库），并要求：
//   · 每 60 秒最多 1 条（窗口合并天然保证）；
//   · 授权后不再出现（调用方在 consent 激活后不再调用本聚合器）。
// 单条 why/reason 保留窗口内首个值以兼容既有断言；reasons 数组保留全部来源。

import { appendJsonl, logPath } from '../../core/src/safefs.mjs'

const WINDOW_MS = 60 * 1000

let buf = null // { bucket, firstTs, lastTs, attempts, reasons:Set }
let flushTimer = null

function flush() {
  if (flushTimer) { try { clearTimeout(flushTimer) } catch { /* noop */ } flushTimer = null }
  if (!buf || buf.attempts === 0) { buf = null; return }
  const b = buf
  buf = null
  const reasons = [...b.reasons]
  try {
    appendJsonl(logPath('perception.jsonl'), {
      ts: new Date().toISOString(),
      kind: 'skipped-no-consent',
      window: '60s',
      attempts: b.attempts,
      reason: reasons[0] || 'consent-inactive',
      reasons,
      firstTs: new Date(b.firstTs).toISOString(),
      lastTs: new Date(b.lastTs).toISOString(),
    })
  } catch { /* 尽力落盘，失败不影响主流程 */ }
}

function scheduleFlush() {
  if (flushTimer) return
  flushTimer = setTimeout(() => {
    flushTimer = null
    // 仅当本窗口已结束（距末次事件 ≥ 窗口）才落盘，避免提前刷掉尚在累积的窗口
    if (buf && Date.now() - buf.lastTs >= WINDOW_MS - 5000) flush()
  }, WINDOW_MS + 1500)
  if (flushTimer && typeof flushTimer.unref === 'function') flushTimer.unref()
}

/** 主入口：记录一次"因未同意而跳过抓屏"。 */
export function recordSkippedNoConsent(rec = {}) {
  const now = Date.now()
  const bucket = Math.floor(now / WINDOW_MS)
  if (buf && buf.bucket !== bucket) flush() // 跨窗口 → 先落旧窗口
  if (!buf) buf = { bucket, firstTs: now, lastTs: now, attempts: 0, reasons: new Set() }
  buf.attempts += 1
  buf.lastTs = now
  const reason = rec && rec.reason != null ? (typeof rec.reason === 'string' ? rec.reason : JSON.stringify(rec.reason)) : 'consent-inactive'
  buf.reasons.add(reason)
  scheduleFlush()
}

// 进程即将空闲退出时落盘最后一个窗口（unref 定时器不会阻止退出，靠 beforeExit 兜底）
try { process.on('beforeExit', () => flush()) } catch { /* 非 Node 环境忽略 */ }

/**
 * S74c·P0-4：从审计行计算 skipped 统计（纯函数，供 /perception status 的
 * lastSkippedAt / skippedTotal 使用；可单测）。
 * 兼容两种行：聚合行（window==='60s', attempts=N，按 N 计）与单条老行（各计 1）。
 * @param {Array<object>} rows
 * @returns {{lastSkippedAt:number, skippedTotal:number}}
 */
export function computeSkippedStats(rows) {
  const out = { lastSkippedAt: 0, skippedTotal: 0 }
  for (const row of rows || []) {
    if (!row || row.kind !== 'skipped-no-consent') continue
    const n = Number(row.attempts)
    const attempts = Number.isFinite(n) && n > 0 ? n : 1
    out.skippedTotal += attempts
    const ts = Date.parse(row.lastTs || row.ts)
    if (Number.isFinite(ts) && ts > out.lastSkippedAt) out.lastSkippedAt = ts
  }
  return out
}

// ---- 测试辅助（仅供单测重置内存态，不影响生产逻辑） ----
export function __resetSkipAuditForTest() {
  buf = null
  if (flushTimer) { try { clearTimeout(flushTimer) } catch { /* noop */ } flushTimer = null }
}
export function flushSkipAudit() { flush() }
