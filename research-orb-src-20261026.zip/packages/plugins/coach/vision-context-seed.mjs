// packages/plugins/coach/vision-context-seed.mjs —— S74·1-A：视觉资料库初始版本（唯一真源）
//
// 纪律：
//   · 这是 data\vision-context.json 的**出厂种子**，data\prompts\context-v1.json 由此导出；
//   · 只是**初始内容**：用户改了 data\vision-context.json 后**不许**被种子覆盖（seed 幂等、不覆盖）；
//   · 用 ESM 对象而不用 .json 导入 —— 免断言/免 import-attribute 兼容问题。
//
// 结构（与 loadVisionContext 的读取契约一致）：
//   machine  本机画像（自由文本）
//   apps     应用特征表：{name, signals[]} —— 视觉解析只与 signals 做通用比对，**不做硬编码分支**
//   selfApps 自身面板白名单（命中 → intent.line = self）
//   routines 常见习惯
//   fewShots 少样本示例（scene → tool/task/intent）

export const VISION_CONTEXT_SEED = {
  machine: 'Windows 11 游戏本（4060）',
  apps: [
    { name: 'DeepSeek Harness', signals: ['DeepSeek Harness', '上下文洞察', '自动化任务', '插件', '会话'] },
    { name: 'Visual Studio Code', signals: ['Visual Studio Code', '资源管理器', '扩展', '终端'] },
    { name: 'Zotero', signals: ['Zotero', '我的文库', '文献'] },
    { name: 'Microsoft Word', signals: ['Microsoft Word', '审阅', '引用'] },
    // S74·1-A：浏览器是日常文献检索入口。signals 只收**界面里真实可见的字串**
    // （InPrivate 徽标 / 地址栏占位文案 / 必应域名），不收任何猜测性词。
    { name: 'Microsoft Edge', signals: ['InPrivate', '搜索或输入 Web 地址', 'bing.com', '必应'] },
    { name: 'research-orb', signals: ['research-orb', '教练日报', '感知卡', '番茄钟', '轨迹'] },
  ],
  selfApps: ['research-orb'],
  routines: [
    { name: '科研写作', apps: ['Microsoft Word', 'Zotero', 'DeepSeek Harness'] },
  ],
  fewShots: [
    { scene: '左侧为带左侧导航的聊天应用主窗口，标题栏含应用名', tool: 'DeepSeek Harness', task: '整理论文连接词', intent: '工作' },
  ],
}

export default { VISION_CONTEXT_SEED }
