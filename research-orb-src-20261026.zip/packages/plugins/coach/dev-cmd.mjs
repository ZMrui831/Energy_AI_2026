// packages/plugins/coach/dev-cmd.mjs —— S73 开发者 Agent 接口（/dev 命令 + dev-agent CLI 共享实现）
//
// 纪律（硬要求）：
//   · 默认只读：shot/ask/log/bench 不写产品数据（除 data\dev-shots、data\dev\last-result.json、审计）。
//   · 不绕护栏：截图走 ctx.core.screen；LLM 走 router；落盘一律 safefs.safeWrite；**无直接 fetch/writeFileSync**。
//   · 零外发；每个子命令写审计 dev-agent{caller:'dev-agent', sub}。
//   · settings.devApi === false → 一律 E_DEV_DISABLED（交付版可关）。
//   · 结果写 data\dev\last-result.json —— CLI（tools\dev-agent.mjs）轮询该文件取回 JSON（等答案落盘后返回）。
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, statSync, rmSync } from 'node:fs'
import { isAbsolute, join } from 'node:path'
import { PROJECT_ROOT, dataPath, safeWrite, logPath } from '../../core/src/safefs.mjs'
import { isRecallQuery, RECALL_PROMPT } from './confusion.mjs'
import { VISION_PROMPT_TEMPLATE } from './extract.mjs'
import { VISION_CONTEXT_SEED } from './vision-context-seed.mjs'

const _PH = /（增量抽取）|（命令触发）|（手动捕获）|（自动捕获）/
const pad = (n) => String(n).padStart(2, '0')
const tsName = () => { const d = new Date(); return `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}` }
const flagOf = (rest, name, def = null) => {
  const m = new RegExp(`--${name}(?:=|\\s+)(?:"([^"]*)"|([^\\s]+))`).exec(String(rest || ''))
  if (!m) return def
  return m[1] !== undefined ? m[1] : m[2]
}
const hasFlag = (rest, name) => new RegExp(`--${name}(\\s|$|=)`).test(String(rest || ''))

/** PNG 尺寸（IHDR：宽 16-19、高 20-23，大端）。 */
function pngSize(buf) {
  try { if (buf.length > 24 && buf.slice(1, 4).toString('ascii') === 'PNG') return { width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) } } catch { /* noop */ }
  return { width: 0, height: 0 }
}

export const DEV_PROMPT_KINDS = ['vision', 'recall', 'chat', 'context']
export const DEV_LOG_FILES = ['coach', 'usage', 'perception', 'net', 'ui']
/** S74·1-A：种子版本文件名（context 是 JSON，其余是 txt）。 */
export const SEED_VERSION_ID = { vision: 'vision-v1', recall: 'recall-v1', chat: 'chat-v1', context: 'context-v1' }

export function promptsDir() { return dataPath('prompts') }
export function activePromptPath(kind) { return join(promptsDir(), `${kind}-active.txt`) }
export function devResultFile() { return dataPath('dev', 'last-result.json') }
/** context 的"生效文件"在 data 根（视觉资料库），其余在 data\prompts\。 */
export function activePathOf(kind) { return kind === 'context' ? dataPath('vision-context.json') : activePromptPath(kind) }

const sha256 = (s) => createHash('sha256').update(Buffer.from(String(s), 'utf8')).digest('hex')

/**
 * S74·1-A：种子内容 —— **唯一真源是代码常量**，仓库 data\prompts\*-v1.* 由此导出。
 * 与运行时逐字一致：vision 用 VISION_PROMPT_TEMPLATE（`{context}` 为资料库注入位），
 * recall 用 RECALL_PROMPT，chat 用 DEV_CHAT_PROMPT，context 用 VISION_CONTEXT_SEED。
 */
export function seedContent(kind) {
  if (kind === 'vision') return VISION_PROMPT_TEMPLATE
  if (kind === 'recall') return RECALL_PROMPT
  if (kind === 'chat') return DEV_CHAT_PROMPT
  if (kind === 'context') return JSON.stringify(VISION_CONTEXT_SEED, null, 2)
  return ''
}
export function seedFileName(kind) { return kind === 'context' ? `${SEED_VERSION_ID[kind]}.json` : `${SEED_VERSION_ID[kind]}.txt` }

/**
 * 首次自动 seed（幂等）：只补缺失的 v1 版本文件 + index.json，**绝不覆盖已有文件**。
 * 不写 *-active.txt / data\vision-context.json —— 用户改过的生效文件不许被种子冲掉。
 * @returns {{created:string[], existed:string[]}}
 */
export function ensureSeeded() {
  const dir = promptsDir()
  mkdirSync(dir, { recursive: true })
  const idx = loadIndex()
  const created = []
  const existed = []
  for (const kind of DEV_PROMPT_KINDS) {
    const id = SEED_VERSION_ID[kind]
    const file = seedFileName(kind)
    const p = join(dir, file)
    const content = seedContent(kind)
    const hasFile = existsSync(p)
    const hasVer = idx.versions.some((v) => v.id === id)
    if (hasFile && hasVer) { existed.push(id); continue }
    // 索引缺/文件缺 → 补文件（文件在则**不重写**，只补索引条目）
    if (!hasFile) safeWrite(p, content)
    if (!hasVer) {
      let chars = content.length
      try { chars = statSync(p).size } catch { /* 按内容长度 */ }
      idx.versions.push({
        id, kind, file, chars,
        createdAt: new Date().toISOString(),
        sha256: hasFile ? sha256(readFileSync(p, 'utf8')) : sha256(content),
        note: 'v1 种子（由代码常量导出，与运行时逐字一致）',
      })
    }
    if (!idx.active[kind]) idx.active[kind] = id
    ;(hasFile ? existed : created).push(id)
  }
  saveIndex(idx)
  return { created, existed }
}

/** 读某 kind 的生效提示词（文件不存在/为空 → fallback 内置）。 */
export function readActivePrompt(kind, fallback = '') {
  try {
    const p = activePromptPath(kind)
    if (existsSync(p)) { const t = readFileSync(p, 'utf8'); if (t.trim()) return t }
  } catch { /* fallthrough */ }
  return fallback
}

/**
 * index.json 落盘 schema（S74·1-A）：**按 kind 分桶**，每桶 {kind, activeVersion, versions[]}。
 * 内部仍用扁平 {versions:[], active:{}} 视图，读写各转一次 —— 兼容 S73 遗留的扁平文件。
 */
function loadIndex() {
  let raw = null
  try { raw = JSON.parse(readFileSync(join(promptsDir(), 'index.json'), 'utf8')) } catch { return { versions: [], active: {} } }
  if (raw && Array.isArray(raw.kinds)) {
    const versions = []
    const active = {}
    for (const k of raw.kinds) {
      for (const v of (k.versions || [])) versions.push({ ...v, kind: v.kind || k.kind })
      if (k.activeVersion) active[k.kind] = k.activeVersion
    }
    return { versions, active }
  }
  return { versions: Array.isArray(raw && raw.versions) ? raw.versions : [], active: (raw && raw.active) || {} }
}

function saveIndex(idx) {
  const versions = Array.isArray(idx.versions) ? idx.versions : []
  const kinds = DEV_PROMPT_KINDS.map((kind) => ({
    kind,
    activeVersion: (idx.active && idx.active[kind]) || null,
    versions: versions.filter((v) => v.kind === kind),
  }))
  safeWrite(join(promptsDir(), 'index.json'), JSON.stringify({ schema: 1, updatedAt: new Date().toISOString(), kinds }, null, 2))
}

/**
 * 当前生效提示词。三级回落（**都不存在才用内置种子，绝不覆盖用户文件**）：
 *   ① *-active.txt / data\vision-context.json 有内容 → 用它（src='active-file'）
 *   ② index 指向的版本文件 → 用它（src='active-version:<id>'）
 *   ③ 内置种子 → 用它（src='builtin-seed'）
 */
function currentPrompt(kind) {
  const idx = loadIndex()
  const id = idx.active[kind] || null
  const v = id ? idx.versions.find((x) => x.id === id) : null
  const p = activePathOf(kind)
  let content = ''
  try { if (existsSync(p)) content = readFileSync(p, 'utf8') } catch { /* noop */ }
  let src = 'active-file'
  if (!String(content).trim() && v) {
    try { content = readFileSync(join(promptsDir(), v.file), 'utf8'); src = 'active-version:' + v.id } catch { /* noop */ }
  }
  if (!String(content).trim()) { content = seedContent(kind); src = 'builtin-seed' }
  return { id: id || SEED_VERSION_ID[kind] || `${kind}-builtin`, path: p, chars: String(content).length, content: String(content), src }
}

function writeActive(kind, content) {
  safeWrite(activePathOf(kind), content)
}

export const DEV_CHAT_PROMPT = '你是 research-orb 的对话助手。根据用户问题与已有上下文，用中文简洁回答；不要编造没有依据的细节。'

/** 行级统一 diff（unified，3 行上下文）。零依赖。 */
export function unifiedDiff(aText, bText, fromLabel = 'from', toLabel = 'to', ctx = 3) {
  const a = String(aText || '').split('\n')
  const b = String(bText || '').split('\n')
  // LCS（O(n·m)；提示词 ≤ 数百行，够用且无依赖）
  const n = a.length
  const m = b.length
  const dp = Array.from({ length: n + 1 }, () => new Uint32Array(m + 1))
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      dp[i][j] = a[i] === b[j] ? dp[i + 1][j + 1] + 1 : Math.max(dp[i + 1][j], dp[i][j + 1])
    }
  }
  const ops = [] // {t:' '|'-'|'+', line}
  let i = 0
  let j = 0
  while (i < n && j < m) {
    if (a[i] === b[j]) { ops.push({ t: ' ', line: a[i] }); i++; j++ }
    else if (dp[i + 1][j] >= dp[i][j + 1]) { ops.push({ t: '-', line: a[i] }); i++ }
    else { ops.push({ t: '+', line: b[j] }); j++ }
  }
  while (i < n) { ops.push({ t: '-', line: a[i] }); i++ }
  while (j < m) { ops.push({ t: '+', line: b[j] }); j++ }
  // 压缩成 hunk
  const keep = ops.map((o) => o.t === ' ')
  const marks = ops.map((o) => o.t !== ' ')
  const show = new Array(ops.length).fill(false)
  for (let k = 0; k < ops.length; k++) {
    if (!marks[k]) continue
    for (let x = Math.max(0, k - ctx); x <= Math.min(ops.length - 1, k + ctx); x++) show[x] = true
  }
  const hunks = []
  let k = 0
  let ai = 0
  let bi = 0
  while (k < ops.length) {
    if (!show[k]) { if (ops[k].t === ' ') ai++; else if (ops[k].t === '-') ai++; else bi++; k++; continue }
    const start = k
    const aStart = ai
    const bStart = bi
    const buf = []
    while (k < ops.length && show[k]) {
      buf.push(`${ops[k].t}${ops[k].line}`)
      if (ops[k].t === ' ') { ai++; bi++ } else if (ops[k].t === '-') ai++
      else bi++
      k++
      if (!show[k]) {
        // 看看后面 ctx 行内还有没有变更；有就继续（合并），无则收尾
        let more = false
        for (let x = k; x < Math.min(ops.length, k + ctx * 2 + 1); x++) if (marks[x]) { more = true; break }
        if (!more) break
      }
    }
    const aLen = ai - aStart
    const bLen = bi - bStart
    hunks.push(`@@ -${aStart + 1},${aLen} +${bStart + 1},${bLen} @@\n` + buf.join('\n'))
  }
  const head = `--- ${fromLabel}\n+++ ${toLabel}\n`
  const body = hunks.join('\n')
  return {
    diff: head + body,
    hunks: hunks.length,
    added: ops.filter((o) => o.t === '+').length,
    removed: ops.filter((o) => o.t === '-').length,
    same: ops.filter((o) => o.t === ' ').length,
    identical: ops.every((o) => o.t === ' '),
  }
}

/**
 * @param {{ctx:object, router:object, extractor:object, confusion:object, auditRouter:Function}} deps
 * @returns {{run:(rest:string)=>Promise<object>}}
 */
export function createDevHandler(deps = {}) {
  const { ctx, router, extractor, confusion, auditRouter } = deps
  if (!ctx) throw new Error('dev-cmd: 需要 ctx')

  async function run(rest = '') {
    const t0 = Date.now()
    const sub0 = String(rest || '').trim().split(/\s+/)[0] || ''
    // S73：devApi 开关读**原始 config**（loadSettings 的归一化对象不含 devApi 字段）
    const cfg = (() => { try { return JSON.parse(readFileSync(dataPath('config.json'), 'utf8')) } catch { return {} } })()
    const disabled = cfg.devApi === false
    let result = null
    if (disabled) {
      // 注意：禁用路径也必须写 last-result（否则 CLI 会等满超时）——统一走底部公共落盘
      result = { ok: false, code: 'E_DEV_DISABLED', text: 'dev API 已禁用（settings.devApi=false）' }
    } else {
      const parts = sub0 ? String(rest || '').trim().split(/\s+/) : []
      try {
        const sub = sub0
        if (sub === 'shot') result = await doShot(rest, t0)
        else if (sub === 'ask') result = await doAsk(rest, t0)
        else if (sub === 'prompt') result = doPrompt(rest)
        else if (sub === 'log') result = doLog(rest)
        else if (sub === 'bench') result = await doBench(rest)
        else result = { ok: false, code: 'E_USAGE', text: '用法：/dev shot [--label x] ｜ /dev ask "<问题>" [--mode auto|chat|recall] ｜ /dev prompt get|set|history|rollback ｜ /dev log tail|grep ｜ /dev bench --suite <path.json>' }
      } catch (e) {
        result = { ok: false, code: (e && e.code) || 'E_DEV', text: String((e && e.message) || e).slice(0, 200) }
      }
    }
    try { auditRouter({ kind: 'dev-agent', caller: 'dev-agent', sub: sub0, disabled, ok: result && result.ok !== false, ms: Date.now() - t0 }) } catch { /* noop */ }
    // args 回显：CLI 按 args 精确匹配取回**自己这条**命令的结果（慢命令不会串台）
    try { safeWrite(devResultFile(), JSON.stringify({ ts: Date.now(), sub: sub0, args: String(rest || ''), result }, null, 2)) } catch { /* CLI 轮询源写失败不阻断 */ }
    return result
  }

  async function doShot(rest, t0) {
    const sc = ctx && ctx.core && ctx.core.screen
    if (!sc || typeof sc.captureScreen !== 'function') return { ok: false, code: 'E_NO_SCREEN', text: '屏幕桥不可用（ctx.core.screen 缺失）' }
    const label = String(flagOf(rest, 'label', 'shot') || 'shot').replace(/[^\w-]/g, '').slice(0, 40) || 'shot'
    const r = await sc.captureScreen()
    if (!r || !r.ok || !r.pngPath) return { ok: false, code: 'E_SHOT', text: '抓屏失败：' + ((r && (r.reason || r.code)) || '未知') }
    const buf = readFileSync(r.pngPath)
    const dir = dataPath('dev-shots')
    mkdirSync(dir, { recursive: true })
    const dst = join(dir, `${tsName()}-${label}.png`)
    safeWrite(dst, buf)
    const { width, height } = pngSize(buf)
    const ms = Date.now() - t0
    try { auditRouter({ kind: 'dev-shot', caller: 'dev-agent', path: dst, bytes: buf.length, ms }) } catch { /* noop */ }
    // --no-shrink：dev shot 本就存原图（缩略仅用于送模），此处仅接受参数保持接口兼容
    void hasFlag(rest, 'no-shrink')
    return { ok: true, sub: 'shot', pngPath: dst, width, height, bytes: buf.length, ms }
  }

  async function doAsk(rest, t0) {
    const body = String(rest || '').replace(/^\s*ask\b/, '').trim()
    const qm = /^"([\s\S]*)"|^'([\s\S]*)'/.exec(body)
    let q = qm ? (qm[1] !== undefined ? qm[1] : qm[2]) : body.split(/\s+--/)[0].trim().replace(/^"|"$/g, '')
    const mode = flagOf(rest, 'mode', 'auto')
    if (!String(q || '').trim()) return { ok: false, code: 'E_EMPTY_QUESTION', text: '缺少问题：/dev ask "<问题>"' }
    let text = ''
    let source = mode
    let attribution = ''
    let degraded = false
    let failCode = 'E_INVOKE'
    if (mode === 'recall' || (mode === 'auto' && isRecallQuery(q))) {
      const r = await confusion.ask({ query: q, trigger: 'manual', consentActive: true })
      if (r.debounced || r.cooledDown) return { ok: false, code: r.debounced ? 'E_ASK_DEBOUNCE' : 'E_COOLED_DOWN', text: r.reason }
      text = String(r.question || '')
      source = 'recall'
      attribution = 'confusion-recall'
    } else {
      const sys = readActivePrompt('chat', DEV_CHAT_PROMPT)
      const pr = await router.run('reason', { messages: [{ role: 'system', content: sys }, { role: 'user', content: String(q) }], maxTokens: 1024 })
      text = pr.ok ? String(pr.text || '').trim() : ''
      attribution = (pr.providerId || '?') + '/' + (pr.model || '?')
      degraded = !pr.ok
      failCode = (pr.error && pr.error.code) || 'E_INVOKE'
    }
    // S71·P0-2：emptyReply 判定在填充错误文案**之前**（空回答也要给非空 text=错误文案）
    const emptyReply = !String(text || '').trim()
    if (emptyReply) text = degraded ? ('（chat 生成失败：' + failCode + '）') : '（空回答）模型未返回内容，请重试或换问法。'
    const frameIds = text.match(/fr-[a-z0-9]+/g) || []
    return { ok: true, sub: 'ask', text: text.slice(0, 2000), source, ms: Date.now() - t0, attribution, frameIds, emptyReply, degraded, mode, persist: true }
  }

  /** 版本引用解析：'active'/'current'/空 → 当前生效；'v1' 或 'vision-v1' → 版本文件。 */
  function resolveVersion(kind, ref) {
    const r = String(ref || '').trim()
    if (!r || r === 'active' || r === 'current') {
      const cur = currentPrompt(kind)
      return { id: cur.id, content: cur.content, src: cur.src }
    }
    const idx = loadIndex()
    const v = idx.versions.find((x) => x.id === r) || idx.versions.find((x) => x.id === `${kind}-${r}`)
    if (!v) return null
    let content = ''
    try { content = readFileSync(join(promptsDir(), v.file), 'utf8') } catch { return null }
    return { id: v.id, content, src: 'version' }
  }

  function doPrompt(rest) {
    const body = String(rest || '').replace(/^\s*prompt\b/, '').trim()
    const sub2 = (body.split(/\s+/)[0] || 'get').toLowerCase()
    const kind = String(flagOf(rest, 'kind', 'vision') || 'vision')
    if (!DEV_PROMPT_KINDS.includes(kind)) return { ok: false, code: 'E_KIND', text: 'kind 仅支持 ' + DEV_PROMPT_KINDS.join('|') }
    // S74·1-A：任何 prompt 子命令都先确保种子就位（幂等、不覆盖）
    const seed = ensureSeeded()
    if (sub2 === 'get') {
      const cur = currentPrompt(kind)
      return { ok: true, sub: 'prompt', action: 'get', kind, id: cur.id, src: cur.src, chars: cur.chars, seeded: seed.created, content: cur.content.slice(0, 4000) }
    }
    if (sub2 === 'set') {
      const f = flagOf(rest, 'file')
      if (!f || !existsSync(f)) return { ok: false, code: 'E_NO_FILE', text: '--file 缺失或不存在：' + (f || '') }
      const apply = hasFlag(rest, 'apply')
      const newContent = readFileSync(f, 'utf8')
      const cur = currentPrompt(kind)
      if (!apply) return { ok: true, sub: 'prompt', action: 'set', applied: false, kind, from: cur.id, fromChars: cur.chars, toChars: newContent.length, note: '干跑：加 --apply 才生效' }
      const idx = loadIndex()
      const n = idx.versions.filter((v) => v.kind === kind).length + 1
      const id = `${kind}-v${n}`
      mkdirSync(promptsDir(), { recursive: true })
      safeWrite(join(promptsDir(), `${id}.txt`), newContent)
      idx.versions.push({
        id, kind, file: `${id}.txt`, chars: newContent.length,
        createdAt: new Date().toISOString(), sha256: sha256(newContent), note: 'dev prompt set',
      })
      idx.active[kind] = id
      saveIndex(idx)
      writeActive(kind, newContent)
      try { auditRouter({ kind: 'prompt-set', caller: 'dev-agent', promptKind: kind, from: cur.id, to: id, chars: newContent.length }) } catch { /* noop */ }
      return { ok: true, sub: 'prompt', action: 'set', applied: true, kind, from: cur.id, to: id, chars: newContent.length }
    }
    if (sub2 === 'history') {
      const idx = loadIndex()
      const versions = idx.versions.filter((v) => v.kind === kind)
      return { ok: true, sub: 'prompt', action: 'history', kind, active: idx.active[kind] || null, seeded: seed.created, total: versions.length, versions }
    }
    if (sub2 === 'rollback') {
      const id = flagOf(rest, 'id')
      const idx = loadIndex()
      const v = idx.versions.find((x) => x.id === id) || idx.versions.find((x) => x.id === `${kind}-${String(id || '')}`)
      if (!v) return { ok: false, code: 'E_NO_VERSION', text: '版本不存在：' + (id || '') }
      const content = readFileSync(join(promptsDir(), v.file), 'utf8')
      idx.active[v.kind] = v.id
      saveIndex(idx)
      writeActive(v.kind, content)
      try { auditRouter({ kind: 'prompt-rollback', caller: 'dev-agent', promptKind: v.kind, to: v.id, chars: content.length }) } catch { /* noop */ }
      return { ok: true, sub: 'prompt', action: 'rollback', kind: v.kind, to: v.id, chars: content.length }
    }
    if (sub2 === 'diff') {
      const fromRef = flagOf(rest, 'from', 'active')
      const toRef = flagOf(rest, 'to', 'active')
      const a = resolveVersion(kind, fromRef)
      const b = resolveVersion(kind, toRef)
      if (!a) return { ok: false, code: 'E_NO_VERSION', text: 'from 版本不存在：' + String(fromRef || '') }
      if (!b) return { ok: false, code: 'E_NO_VERSION', text: 'to 版本不存在：' + String(toRef || '') }
      const d = unifiedDiff(a.content, b.content, `from:${a.id}`, `to:${b.id}`)
      try { auditRouter({ kind: 'prompt-diff', caller: 'dev-agent', promptKind: kind, from: a.id, to: b.id, added: d.added, removed: d.removed }) } catch { /* noop */ }
      return { ok: true, sub: 'prompt', action: 'diff', kind, from: a.id, to: b.id, ...d, diff: d.diff.slice(0, 8000) }
    }
    return { ok: false, code: 'E_USAGE', text: 'prompt get [--kind x] ｜ set --kind x --file f [--apply] ｜ history [--kind x] ｜ rollback --id x-vN ｜ diff --kind x --from v1 --to active' }
  }

  function readLogLines(file) {
    const p = logPath(`${file}.jsonl`)
    if (!existsSync(p)) return []
    return readFileSync(p, 'utf8').split('\n').filter((l) => l.trim()).map((l) => { try { return JSON.parse(l) } catch { return { raw: l } } })
  }

  function doLog(rest) {
    const body = String(rest || '').replace(/^\s*log\b/, '').trim()
    const sub2 = (body.split(/\s+/)[0] || 'tail').toLowerCase()
    const file = String(flagOf(rest, 'file', 'coach') || 'coach')
    if (!DEV_LOG_FILES.includes(file)) return { ok: false, code: 'E_FILE', text: 'file 仅支持 ' + DEV_LOG_FILES.join('|') }
    if (sub2 === 'tail') {
      const n = Math.max(1, Math.min(200, Number(flagOf(rest, 'n', '20')) || 20))
      const all = readLogLines(file)
      return { ok: true, sub: 'log', action: 'tail', file, n, total: all.length, items: all.slice(-n) }
    }
    if (sub2 === 'grep') {
      const pattern = flagOf(rest, 'pattern', '')
      const since = flagOf(rest, 'since', null)
      if (!pattern) return { ok: false, code: 'E_PATTERN', text: '缺少 --pattern' }
      let re = null
      try { re = new RegExp(pattern) } catch (e) { return { ok: false, code: 'E_REGEX', text: '正则无效：' + String((e && e.message) || e).slice(0, 80) } }
      const sinceMs = since ? Date.parse(since) : null
      const all = readLogLines(file)
      const items = all.filter((r) => {
        if (re && !re.test(JSON.stringify(r))) return false
        if (sinceMs && Number.isFinite(sinceMs)) { const t = Date.parse(r.ts || ''); if (Number.isFinite(t) && t < sinceMs) return false }
        return true
      }).slice(-200)
      return { ok: true, sub: 'log', action: 'grep', file, pattern, items, total: items.length }
    }
    return { ok: false, code: 'E_USAGE', text: 'log tail --file x --n N ｜ log grep --pattern re [--since ts]' }
  }

  // S74b·P0-0：bench 必须先把模型输出归一为候选 id，再比较 ——
  // 否则 "DeepSeek Harness" 永远比不上 "dsh"，基线全是假失败（主管 2026-10-26 实测 2/7）。
  const TOOL_ALIASES = [
    [/deepseek\s*harness|\bdsh\b/i, 'dsh'],
    [/research-orb|问源|\borb\b/i, 'self-orb'],
    [/microsoft\s*word|\bwps\b|\bword\b/i, 'word'],
    [/(visual\s*studio\s*code|\bvscode\b|claude\s*code|pycharm|spyder|webstorm|\bide\b)/i, 'vscode'],
    [/(microsoft\s*edge|chrome|firefox|safari|\bbrowser\b|浏览器)/i, 'browser'],
    [/(windows\s*terminal|powershell|cmd\.exe|\bterminal\b|终端)/i, 'terminal'],
    [/zotero|endnote/i, 'zotero'],
    [/unknown|未知|无法判断/i, 'unknown'],
  ]
  const normalizeToolId = (raw) => {
    const s0 = String(raw || '').trim()
    if (!s0) return 'unknown'
    for (const [re, id] of TOOL_ALIASES) if (re.test(s0)) return id
    return s0.toLowerCase()
  }

  async function doBench(rest, t0) {
    // S74·1-A：默认 suite 解析 —— `bench` / `bench --suite basic` 指向仓库内置 tests\bench\vision-basic.json
    // （S73 实测：仓库里没有 suite 文件，主管拿到 dev 接口也跑不了基线 → 内置并支持简写）
    let suitePath = flagOf(rest, 'suite')
    if (!suitePath || !existsSync(suitePath)) {
      const builtin = [
        ['basic', join(PROJECT_ROOT, 'tests', 'bench', 'vision-basic.json')],
        ['vision-basic', join(PROJECT_ROOT, 'tests', 'bench', 'vision-basic.json')],
      ].find(([alias]) => String(suitePath || '').toLowerCase() === alias || (!suitePath && alias === 'basic'))
      const cand = builtin ? builtin[1] : null
      if (cand && existsSync(cand)) suitePath = cand
      else if (cand) return { ok: false, code: 'E_SUITE', text: '内置 suite 缺失：' + cand }
      else return { ok: false, code: 'E_SUITE', text: '--suite 缺失或不存在：' + (String(flagOf(rest, 'suite') || '')) }
    }
    const repeat = Math.max(1, Math.min(5, Number(flagOf(rest, 'repeat', '1')) || 1))
    const suite = JSON.parse(readFileSync(suitePath, 'utf8'))
    if (!extractor) return { ok: false, code: 'E_NO_EXTRACTOR', text: 'extractor 不可用' }
    const suiteDir = join(suitePath, '..')
    // 套件里的 shot 允许三种写法：绝对路径 / 相对仓库根 / 相对套件目录（S74·1-A：内置套件用相对仓库根，可移植）
    const resolveShot = (p) => {
      const raw = String(p || '')
      if (!raw) return null
      if (isAbsolute(raw) && existsSync(raw)) return raw
      for (const base of [PROJECT_ROOT, suiteDir]) {
        const c = join(base, raw)
        if (existsSync(c)) return c
      }
      return null
    }
    for (const c of (suite.cases || [])) {
      const r = resolveShot(c.shot)
      if (!r) return { ok: false, code: 'E_SUITE_CASE', text: `案例 ${c.id || '?'} 的 shot 不存在：${c.shot}` }
      c.shot = r
    }
    const indexFile = join(dataPath('coach'), 'frames-index.json')
    const results = []
    for (const c of (suite.cases || [])) {
      for (let i = 0; i < repeat; i++) {
        if (results.length) await new Promise((res) => setTimeout(res, 4000)) // 案例间隔：降低 GLM 限流
        const img = join(dataPath('dev-shots'), `bench-${c.id}-${i + 1}.png`)
        mkdirSync(dataPath('dev-shots'), { recursive: true })
        safeWrite(img, readFileSync(c.shot)) // 用副本：extract 会删源图
        try { rmSync(indexFile, { force: true }) } catch { /* noop */ }
        const r0 = Date.now()
        let r = null
        try { r = await extractor.extract({ imagePath: img }) } catch (e) { r = { ok: false, text: String((e && e.message) || e).slice(0, 120) } }
        const st = (r && r.structured) || {}
        const layers = st.layers || {}
        const tool = String((layers.tool && layers.tool.name) || st.app || '')
        const line = String((layers.intent && layers.intent.line) || st.intent || '')
        // tool_id 归一：**空 = unknown**（S74·2A 的候选集口径；batch-1 先按同样语义判定，
        // 这样"空白图不许编软件名"可以直接断言 tool_id==='unknown'，不必等候选集落地）
        const toolRaw = tool.trim()
        const toolId = normalizeToolId(toolRaw)   // 归一后才是可比对的 id
        const evRaw = []
        if (Array.isArray(layers.evidence)) evRaw.push(...layers.evidence)
        if (layers.tool && Array.isArray(layers.tool.evidence)) evRaw.push(...layers.tool.evidence)
        if (layers.intent && Array.isArray(layers.intent.evidence)) evRaw.push(...layers.intent.evidence)
        const evOk = evRaw.filter((x) => String(x || '').trim().length >= 6)
        const exp = c.expect || {}
        const checks = []
        const wantTool = exp.tool_id !== undefined ? exp.tool_id : exp.tool
        if (wantTool !== undefined && wantTool !== null) {
          const w = String(wantTool).trim().toLowerCase()
          const g = toolId.toLowerCase()
          checks.push({ k: 'tool_id', want: String(wantTool), got: toolId, gotRaw: toolRaw, pass: g === w || (w !== 'unknown' && g.includes(w)) })
        }
        if (exp.line !== undefined && exp.line !== null) {
          checks.push({ k: 'line', want: String(exp.line), got: line, pass: String(line).trim().toLowerCase() === String(exp.line).trim().toLowerCase() })
        }
        if (exp.mustHaveEvidence) checks.push({ k: 'mustHaveEvidence', want: '≥1 条≥6字', got: evOk.length, pass: evOk.length >= 1 })
        if (!checks.length) checks.push({ k: 'ok', want: true, got: r.ok === true, pass: r.ok === true })
        const pass = checks.every((x) => x.pass)
        results.push({ id: c.id, run: i + 1, pass, tool: toolId, toolRaw, line, evidence: evOk.length, checks, ms: Date.now() - r0, raw: String(r.text || '').slice(0, 300) })
      }
    }
    const passRate = results.length ? results.filter((x) => x.pass).length / results.length : 0
    const out = {
      sub: 'bench', name: suite.name || 'bench', suite: suitePath, repeat, passRate,
      passed: results.filter((x) => x.pass).length, total: results.length, results,
      tools: results.map((x) => x.tool), toolRaws: results.map((x) => x.toolRaw), normalized: true, ms: Date.now() - t0,
    }
    const outPath = flagOf(rest, 'out')
    if (outPath) safeWrite(outPath, JSON.stringify(out, null, 2))
    return { ok: true, ...out }
  }

  return { run }
}
