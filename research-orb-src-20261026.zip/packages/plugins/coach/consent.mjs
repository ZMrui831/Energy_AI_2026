// packages/plugins/coach/consent.mjs
//
// S25/S26：教练线对感知同意的【只读推导】——不重复实现同意机制，只读 data/perception-config.json
// （与 perception 插件同一配置源；其 isActive 语义对齐：metadata-only 长期有效；session 看 expiresAt）。
// 推导不出（文件缺失/损坏）→ denied（fail-closed：未同意不跑）。
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { dataPath } from '../../core/src/safefs.mjs'

export function readPerceptionConsent({ root = null, now = Date.now() } = {}) {
  try {
    // S36：双模数据根（显式 root 旧布局 / 缺省 DATA_DIR）。
    // S65 修：缺省**必须走 dataPath**（认 ORB_DATA_DIR 隔离）。此前缺省 root=PROJECT_ROOT
    // → 隔离实例里 coach 读的是**真实项目**的 perception-config.json，而 perception 插件把同意
    // 写进隔离库 → 授权链路在隔离验收里全靠"真实库恰好有有效同意"才通（主管会话过期即断）。
    const p = root == null ? dataPath('perception-config.json') : join(root, 'data', 'perception-config.json')
    if (!existsSync(p)) return { mode: 'denied', active: false, source: 'missing' }
    const doc = JSON.parse(readFileSync(p, 'utf8'))
    const c = (doc && doc.consent) || {}
    const mode = typeof c.mode === 'string' ? c.mode : 'denied'
    if (mode === 'denied') return { mode, active: false, source: 'perception-config' }
    if (mode === 'metadata-only') return { mode, active: true, source: 'perception-config' }
    if (mode === 'session') {
      const active = typeof c.expiresAt === 'number' && now < c.expiresAt
      return { mode, active, source: 'perception-config' }
    }
    return { mode, active: false, source: 'unknown-mode' }
  } catch {
    return { mode: 'denied', active: false, source: 'parse-error' }
  }
}

export default { readPerceptionConsent }
