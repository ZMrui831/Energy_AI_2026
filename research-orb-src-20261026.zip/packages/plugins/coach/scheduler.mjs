// packages/plugins/coach/scheduler.mjs
//
// S25·2A 教练调度器：三触发源 interval | idle-dwell | threshold（娱乐超时）。
// 纪律（红线）：
//   · 单例：同一 store 下已有存活实例（pid 探测为真）→ 拒绝第二实例（E_ALREADY_RUNNING）。
//   · 崩溃自恢复：store 里 running=true 但 pid 已死 → 新实例接管（沿用 lastTrigger，不重复触发）。
//   · 可暂停：paused 期间三源都不触发；resume 恢复。
//   · 不改 perception 默认阈值：本模块的自有参数全部来自 data/coach/scheduler.json，
//     绝不读写 data/perception-config.json。
//   · 纯逻辑驱动：tick()/feed() 由调用方接真实定时器/1Hz 样本（本模块只注入 now/persist）。
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, safeWrite, dataPath } from '../../core/src/safefs.mjs'

export const SCHED_DEFAULTS = Object.freeze({
  intervalMs: 30 * 60 * 1000,        // 触发源1：流水线间隔（默认 30 分钟）
  idleDwellMs: 3 * 60 * 1000,        // 触发源2：停留阈值（≥3 分钟 → 困惑问询候选）
  entertainmentCapMin: 45,           // 触发源3：娱乐超时阈值（分钟）
  thresholdCooldownMs: 24 * 60 * 60 * 1000, // 触发源3 冷却（与提醒卡 24h 冷却同口径）
})

export class SchedulerError extends Error {
  constructor(code, message) { super(message); this.name = 'SchedulerError'; this.code = code }
}

function defaultState() {
  return {
    version: 1,
    running: false,
    paused: false,
    pid: null,
    startedAt: null,
    lastInterval: 0,
    lastThreshold: 0,
    idleArmed: true,   // idle 边沿武装：上次样本未越过阈值
    remindedPlans: [], // S32：已提醒过的计划 id（同一计划只提醒一次，跨重启保持）
    counters: { interval: 0, 'idle-dwell': 0, threshold: 0, 'plan-due': 0 },
  }
}

function loadState(storePath) {
  try {
    if (!existsSync(storePath)) return null
    const s = JSON.parse(readFileSync(storePath, 'utf8'))
    return s && typeof s === 'object' ? { ...defaultState(), ...s } : null
  } catch { return null }
}

/**
 * @param {{
 *   dir?: string,                    // 状态目录（默认 data\coach；测试注入 tmp）
 *   isAlive?: (pid:number) => boolean, // pid 存活探测（测试/宿主注入；默认一律视为已死 → 接管）
 *   now?: () => number,
 *   onTrigger?: async (kind, info) => void,
 *   overrides?: object,              // intervalMs/idleDwellMs/entertainmentCapMin/thresholdCooldownMs 覆盖
 * }} opts
 */
export function createScheduler(opts = {}) {
  const dir = opts.dir || dataPath('coach')
  const storePath = join(dir, 'scheduler.json')
  const now = opts.now || (() => Date.now())
  const isAlive = opts.isAlive || (() => false)
  const cfg = { ...SCHED_DEFAULTS, ...(opts.overrides || {}) }

  const st = loadState(storePath) || defaultState()

  // 单例：已有存活实例 → 拒绝；实例已死 → 崩溃自恢复（接管，沿用 lastTrigger）
  if (st.running && st.pid != null && isAlive(st.pid)) {
    throw new SchedulerError('E_ALREADY_RUNNING', `调度器已在运行（pid=${st.pid}）——单例约束，不重复启动`)
  }

  let fired = [] // 触发记录（本次实例生命周期内，供验收）

  function persist() {
    safeWrite(storePath, JSON.stringify(st, null, 2))
  }

  async function fire(kind, info = {}) {
    if (!st.running || st.paused) return false
    st.counters[kind] = (st.counters[kind] || 0) + 1
    persist()
    fired.push({ kind, at: now(), ...info })
    if (typeof opts.onTrigger === 'function') {
      try { await opts.onTrigger(kind, info) } catch { /* 触发回调失败不影响调度器状态 */ }
    }
    return true
  }

  return {
    /** 启动（接管/新启）。 */
    start() {
      st.running = true
      st.paused = false
      st.pid = process.pid
      st.startedAt = now()
      if (!st.lastInterval) st.lastInterval = now() // 首启基线：interval 从现在起算
      if (!st.lastThreshold) st.lastThreshold = now() - cfg.thresholdCooldownMs // 首启：冷却视为早已过
      persist()
      return { pid: st.pid }
    },
    /** 暂停：三源都不触发（状态保留）。 */
    pause() { st.paused = true; persist(); return true },
    /** 恢复。 */
    resume() { st.paused = false; persist(); return true },
    get paused() { return !!st.paused },
    get running() { return !!st.running },

    /** 触发源1：interval 到点判定（调用方按节拍调 tick）。 */
    async tickInterval() {
      if (!st.running || st.paused) return false
      if (now() - st.lastInterval < cfg.intervalMs) return false
      st.lastInterval = now()
      return fire('interval')
    },

    /**
     * 触发源2/3：喂一条样本 { idleMs?, entertainmentMin? }。
     * idle-dwell：边沿触发（未越线→越线那一刻触发一次；持续停留不重复）。
     * threshold：娱乐时长超阈 + 24h 冷却。
     */
    async feed(sample = {}) {
      const results = []
      if (!st.running || st.paused) return results
      const idleMs = Number.isFinite(sample.idleMs) ? sample.idleMs : null
      if (idleMs != null) {
        const over = idleMs >= cfg.idleDwellMs
        if (over && st.idleArmed) {
          st.idleArmed = false
          results.push(await fire('idle-dwell', { idleMs }))
        } else if (!over) {
          st.idleArmed = true // 退回未越线，重新武装
        }
      }
      const entMin = Number.isFinite(sample.entertainmentMin) ? sample.entertainmentMin : null
      if (entMin != null && entMin >= cfg.entertainmentCapMin) {
        if (now() - st.lastThreshold >= cfg.thresholdCooldownMs) {
          st.lastThreshold = now()
          results.push(await fire('threshold', { entertainmentMin: entMin }))
        }
      }
      // S32·2：计划到期触发（threshold 源新增）。sample.duePlans=[{id,text}]；
      // 同一计划只提醒一次（remindedPlans 去重，持久化到 scheduler.json）。
      const due = Array.isArray(sample.duePlans) ? sample.duePlans : []
      if (due.length) {
        for (const p of due) {
          const id = p && p.id
          if (!id || st.remindedPlans.includes(id)) continue
          st.remindedPlans.push(id)
          results.push(await fire('plan-due', { id, text: p.text || '' }))
        }
      }
      return results
    },

    /** 手动触发（验收/调试用；同样受 running/paused 门控）。 */
    async triggerNow(kind, info = {}) { return fire(kind, info) },

    /** 停止（进程正常退出时调用）。 */
    stop() { st.running = false; st.pid = null; persist(); return true },

    state() { return { ...st, cfg: { ...cfg } } },
    firedLog() { return [...fired] },
  }
}

export default { SCHED_DEFAULTS, SchedulerError, createScheduler }
