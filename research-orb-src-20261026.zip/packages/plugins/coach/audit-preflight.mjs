// packages/plugins/coach/audit-preflight.mjs
//
// S31·B3 审计完整性巡检：任何写 data/coach|memory|logs 的功能启动前先过此巡检。
// 基线 = data/logs/s25-audit-preflight.json（各审计 jsonl 的高水位行数）。
//
// S33·B2/E 语义：
//   · 比对口径 = live + archived（= total 高水位），轮转归档不再算丢档；
//   · 升/不变 → 放行；低于基线 → E_AUDIT_LOSS；
//   · 唯一例外：基线含 approvedLowering[file] = {to, at, reason, approvedBy} 且 total >= to，
//     即"有报批字段才允许下调"，否则一律拒绝。
//
// 不变量可配置：root / baselinePath / now 注入（验收脚本用临时根跑一致放行/删行拒绝/恢复放行）。
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../../core/src/safefs.mjs'
import { archiveStats } from '../../core/src/log-archive.mjs'

export const TRACKED = ['writes.jsonl', 'coach.jsonl', 'usage.jsonl', 'kb.jsonl', 'net.jsonl', 'tool.jsonl']

/**
 * @param {{root?:string, baselinePath?:string, now?:()=>Date}} opts
 * @returns {{ok:boolean, at:string, results:Array<{file,baseline,live,archived,total,current,ok,approved}>}}
 * @throws {Error & {code:'E_NO_BASELINE'|'E_BASELINE_PARSE'|'E_AUDIT_LOSS'}}
 */
export function auditPreflight({ root = PROJECT_ROOT, baselinePath, now = () => new Date() } = {}) {
  const bp = baselinePath || join(root, 'data', 'logs', 's25-audit-preflight.json')
  if (!existsSync(bp)) throw Object.assign(new Error('审计基线缺失：' + bp), { code: 'E_NO_BASELINE' })
  let base
  try {
    base = JSON.parse(readFileSync(bp, 'utf8'))
  } catch {
    throw Object.assign(new Error('审计基线解析失败：' + bp), { code: 'E_BASELINE_PARSE' })
  }
  const logsDir = join(root, 'data', 'logs')
  const results = []
  for (const f of TRACKED) {
    if (typeof base[f] !== 'number') continue // 非计数元字段（at/D23/approvedLowering 等）忽略
    const st = archiveStats(logsDir, f)
    const { live, archived, total } = st
    let ok = total >= base[f]
    let approved = false
    if (!ok) {
      // B2：唯有报批下调（approvedLowering）且 total 不低于报批值才放行
      const ap = base.approvedLowering && base.approvedLowering[f]
      if (ap && typeof ap.to === 'number' && total >= ap.to) { ok = true; approved = true }
    }
    results.push({ file: f, baseline: base[f], live, archived, total, current: total, ok, approved })
    if (!ok) {
      throw Object.assign(
        new Error(`审计完整性巡检失败：${f} live ${live} + archived ${archived} = total ${total} 行 < 基线 ${base[f]} 行（可能丢失审计行，且无报批下调）`),
        { code: 'E_AUDIT_LOSS', file: f, baseline: base[f], live, archived, total, current: total },
      )
    }
  }
  return { ok: true, at: now().toISOString(), results }
}

export default { auditPreflight, TRACKED }
