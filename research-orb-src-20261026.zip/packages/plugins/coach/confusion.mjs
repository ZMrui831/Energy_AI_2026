// packages/plugins/coach/confusion.mjs
//
// S25·2E 困惑问询：/coach ask 热键（主动）或同窗停留 ≥3 分钟（调度器 idle-dwell → 自动）。
// 上下文 = extract 文本（qwen 视觉优先/OCR 兜底）+ 最近 3 条轨迹；冷却期内不重复。
// 纪律：
//   · 未同意感知 → 跳过 + 审计 {kind:'skipped-no-consent', why:'coach-ask'}，绝不静默。
//   · extract 失败 → 诚实降级（问询内容说明拿不到屏幕上下文），不编造。
//   · LLM 经 router（summarize 档，旗舰）；冷却可配（默认 30 分钟）。
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, safeWrite, appendJsonl, logPath, dataPath } from '../../core/src/safefs.mjs'
import { parseQueryScope, normalizeQuery, isBjSameDay } from '../../core/src/query-scope.mjs'

// S35·A1：自动问询（idle-dwell / 困惑触发）24h 冷却
export const ASK_COOLDOWN_MS_DEFAULT = 24 * 60 * 60 * 1000
// S70·P0-1：手动 ask 与 24h 冷却解耦——只受 10s 防抖（防连点），不再被自动冷却锁死
export const MANUAL_ASK_MIN_INTERVAL_MS = 10 * 1000

export class ConfusionError extends Error {
  constructor(code, message) { super(message); this.name = 'ConfusionError'; this.code = code }
}

function audit(rec) {
  try { appendJsonl(logPath('coach.jsonl'), { ts: new Date().toISOString(), ...rec }) } catch { /* 尽力 */ }
}

function lastTrajectory(trajectoryFile, n) {
  try {
    if (!existsSync(trajectoryFile)) return []
    const rows = readFileSync(trajectoryFile, 'utf8').split('\n').filter((l) => l.trim()).map((l) => JSON.parse(l))
    return rows.slice(-n)
  } catch { return [] }
}

// ---------------------------------------------------------------------------
// S69·1C：时间范围解析（本机时区 = 北京时间 +8）+ 三源检索（trajectory / incremental / 当日记忆）
// S74·1-B Q6：改为**统一查询对象**（packages\core\src\query-scope.mjs）——
//   解析器只把自然语言映射成 scope+窗口；取数逻辑**不再看字符串**。
//   parseTimeRange 保留旧名作兼容入口，返回的既是查询对象也带 from/to/label（旧消费方不断链）。
// ---------------------------------------------------------------------------
function readJsonlRows(file) {
  try {
    if (!existsSync(file)) return []
    return readFileSync(file, 'utf8').split('\n').filter((l) => l.trim()).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
  } catch { return [] }
}

/** S73：recall 生效提示词可被 data\prompts\recall-active.txt 覆盖（dev prompt set 生效入口）。 */
function activePrompt(kind, fallback) {
  try {
    const p = dataPath('prompts', `${kind}-active.txt`)
    if (existsSync(p)) { const t = readFileSync(p, 'utf8'); if (t.trim()) return t }
  } catch { /* fallthrough */ }
  return fallback
}

/** S74·1-A：recall 提示词种子（唯一真源，data\prompts\recall-v1.txt 由此导出）。 */
export const RECALL_PROMPT = '你是科研教练。用户可能在卡壳。根据屏幕文字、最近轨迹与相关记忆，输出一段 ≤120 字的问询：先复述你观察到的状态，再问一个最可能帮他推进的具体问题。不要客套。'

export function isRecallQuery(text) {
  return /刚刚|刚才|今天|今日|昨天|上午|下午|晚上|最近\s*\d+\s*(分钟|小时|天)|干了啥|干什么|做了什么|在干嘛/.test(String(text || ''))
}

export function parseTimeRange(text, nowMs = Date.now()) {
  // S74·1-B：统一走 query-scope（北京时间切日）；返回值含 scope/start/end/includeArchive，
  // 同时保留 from/to/label —— 旧消费方（accept-s71-recall-text 等）不断链。
  return parseQueryScope(text, { nowMs })
}

function hhmmOf(ts) { const d = new Date(ts); const p = (n) => String(n).padStart(2, '0'); return `${p(d.getHours())}:${p(d.getMinutes())}` }

/** 条目时间前缀：归档/跨日作用域必须带日期（`10-24 18:33`）；today 只写 HH:MM。 */
function stampOf(e, scope) {
  const dated = scope === 'relative_day' || scope === 'archive' || scope === 'all' || e.archived === true
  if (!dated) return hhmmOf(e.ts)
  const d = new Date(e.ts)
  const p = (n) => String(n).padStart(2, '0')
  return `${p(d.getMonth() + 1)}-${p(d.getDate())} ${hhmmOf(e.ts)}`
}

export function retrieveEvents({ trajectoryFile, incrementalFile, range, query, limit = 20 }) {
  // S74·1-B：取数只看查询对象（scope + 窗口），不看原始问题字符串
  const nq = normalizeQuery(query || range)
  const rows = []
  const PLACEHOLDER_RE = /（增量抽取）|（命令触发）|（手动捕获）|（自动捕获）/
  const todayAnchor = nq.referenceTime
  for (const t of readJsonlRows(trajectoryFile)) rows.push({ ts: t.ts, window: t.window, process: t.process, intent: t.intent, structuredIntent: t.structuredIntent, evidence: t.evidence, placeholder: t.placeholder === true, src: t.source, archived: !isBjSameDay(Date.parse(t.ts), todayAnchor), __src: 'trajectory' })
  // 关键：未合并的 incremental 行也算（此前只读 trajectory → 答的全是旧事）
  for (const inc of readJsonlRows(incrementalFile)) rows.push({ ts: inc.ts, window: inc.window, process: inc.process, intent: null, structuredIntent: inc.structured && inc.structured.intent ? inc.structured.intent : '', evidence: { frameId: inc.frameId, textSha256: inc.textSha256 }, src: inc.triggerSource, placeholder: inc.placeholder === true, archived: !isBjSameDay(Date.parse(inc.ts), todayAnchor), __src: 'incremental' })
  // S71·P0-1：跳过占位行 + 命令帧（二次保险），并跳过 window/process 仍是占位串的脏行
  // S74·1-B：归档条目只有在 includeArchive（relative_day / archive / all）时才入答案
  const inRange = rows.filter((r) => {
    if (r.placeholder === true) return false
    if (r.src === 'command') return false
    if (PLACEHOLDER_RE.test(String(r.window || '')) || PLACEHOLDER_RE.test(String(r.process || ''))) return false
    if (r.archived && !nq.includeArchive && nq.scope !== 'archive' && nq.scope !== 'all') return false
    if (nq.scope === 'archive' && !r.archived) return false
    const ms = Date.parse(r.ts); return Number.isFinite(ms) && ms >= nq.from && ms < nq.to
  })
  inRange.sort((a, b) => Date.parse(b.ts) - Date.parse(a.ts))
  return inRange.slice(0, limit)
}

export function buildRecallAnswer(events, range, opts = {}) {
  const nq = normalizeQuery(range)
  const count = events.length
  if (!count) {
    const tail = opts.lastAt ? `最后一条是 ${opts.lastAt} …` : '这里还没有任何轨迹记录。'
    return `（${nq.label} · 0 条）没有记录到你在做别的，${tail}`
  }
  const lines = events.map((e) => {
    const sid = e.evidence && e.evidence.frameId ? e.evidence.frameId : '—'
    const what = String(e.intent || e.structuredIntent || e.window || e.process || '未知').replace(/\s+/g, ' ').trim()
    const appw = String(e.window || e.process || '').replace(/\s+/g, ' ').trim()
    const task = what.length > 30 ? what.slice(0, 30) + '…' : what
    const badApp = !appw || /（增量抽取|命令触发|手动捕获|自动捕获）/.test(appw)
    // S71·P0-1：可读句式，禁止"键"作连接词；无应用名时用 <task 前 30 字>
    // S74·1-B：归档条目（archived:true）必须显式标注，不得与实时条目混排无提示
    const tag = e.archived ? '〔归档〕' : ''
    const body = badApp ? `${task}（${sid}）` : `在「${appw}」——${task}（${sid}）`
    return `${stampOf(e, nq.scope)} ${body}${tag}`
  })
  // S74·1-B 回答纪律：顶部 = 实际范围 + 条数（`(今天 00:00–22:40 · 7 条)`）
  return `（${nq.label} · ${count} 条）\n${lines.join('\n')}`
}

/**
 * @param {{
 *   dir?: string,
 *   router: object,            // summarize 档
 *   extractor: object,         // 2B
 *   trajectoryFile?: string,
 *   now?: () => number,
 *   cooldownMs?: number,       // 默认 24 小时（ASK_COOLDOWN_MS_DEFAULT，每日最多一次）
 *   onAsk?: async (info) => void,  // 问询卡出口（宿主接 UI）
 * }} opts
 */
export function createConfusionCoach(opts = {}) {
  const dir = opts.dir || dataPath('coach')
  const stateFile = join(dir, 'confusion-state.json')
  const trajectoryFile = opts.trajectoryFile || join(dir, 'trajectory.jsonl')
  const incrementalFile = opts.incrementalFile || join(dir, 'incremental.jsonl')
  const now = opts.now || (() => Date.now())
  const cooldownMs = Number.isFinite(opts.cooldownMs) ? opts.cooldownMs : ASK_COOLDOWN_MS_DEFAULT
  if (!opts.router) throw new ConfusionError('E_NO_ROUTER', 'confusion: 需要注入 router')
  if (!opts.extractor) throw new ConfusionError('E_NO_EXTRACTOR', 'confusion: 需要注入 extractor')
  const router = opts.router
  const extractor = opts.extractor

  let lastAskAt = (() => {
    try {
      if (existsSync(stateFile)) {
        const s = JSON.parse(readFileSync(stateFile, 'utf8'))
        if (Number.isFinite(s.lastAskAt)) return s.lastAskAt
      }
    } catch { /* 忽略 */ }
    return 0
  })()
  // 首次：冷却视为早已过
  if (!lastAskAt) lastAskAt = now() - cooldownMs

  function persist() { safeWrite(stateFile, JSON.stringify({ lastAskAt }, null, 2)) }

  /**
   * 发起一次困惑问询。
   * @param {{imagePath:string, trigger?:'manual'|'auto-dwell', window?:string, process?:string, consentActive?:boolean, memoryHints?:string[]}} input
   * @returns {Promise<{ok:boolean, skipped?:boolean, cooledDown?:boolean, question?:string, context?:object, source?:string}>}
   */
  async function ask(input = {}) {
    const { imagePath, trigger = 'manual', window = '', process: proc = '' } = input
    const memoryHints = Array.isArray(input.memoryHints) ? input.memoryHints.filter((h) => h && String(h).trim()).slice(0, 5) : []
    if (!input.consentActive) {
      audit({ kind: 'skipped-no-consent', why: 'coach-ask', trigger })
      return { ok: false, skipped: true, reason: '感知同意未激活：不问询（已留审计）' }
    }
    // S70·P0-1：冷却解耦——手动 ask 只受 10s 防抖；自动/困惑触发才受 24h 冷却
    const isManual = trigger === 'manual'
    const gateMs = isManual ? MANUAL_ASK_MIN_INTERVAL_MS : cooldownMs
    if (now() - lastAskAt < gateMs) {
      if (isManual) {
        audit({ kind: 'ask-debounce', trigger: 'manual' })
        return { ok: false, debounced: true, reason: '操作过快：手动问询 10 秒内只受理一次（不受 24h 冷却约束）' }
      }
      const remainingMin = Math.ceil((cooldownMs - (now() - lastAskAt)) / 60000)
      audit({ kind: 'ask-cooldown', trigger: 'auto', remainingMin })
      return { ok: false, cooledDown: true, reason: `冷却中，剩余 ${remainingMin} 分钟（自动问询 24h 冷却）` }
    }
    // S69·1C：召回类问题（"刚干了啥/今天/昨天/最近 N 分钟"）走**时间范围三源检索**，不需要当前屏幕
    const recall = !!input.query && isRecallQuery(input.query)
    let extractText = ''
    let frameId = null
    let source = 'qwen'
    let degraded = false
    if (!recall) {
      try {
        const r = await extractor.extract({ imagePath })
        extractText = String(r.text || '').slice(0, 600)
        frameId = r.frameId
        source = r.source
      } catch (e) {
        degraded = true
        audit({ kind: 'ask-extract-failed', trigger, err: String((e && e.message) || e).slice(0, 120) })
      }
    }
    if (recall) {
      // S74·1-B：解析器只产查询对象；取数与展示只认 scope/窗口
      const range = parseTimeRange(input.query, now())
      audit({ kind: 'ask-range', trigger, scope: range.scope, from: new Date(range.from).toISOString(), to: new Date(range.to).toISOString(), label: range.label })
      // 三源：trajectory + incremental（未合并也算）+ 当日记忆（以下 memory 由上层 hints 注入，这里以轨迹为主）
      const events = retrieveEvents({ trajectoryFile, incrementalFile, range, limit: 20 })
      const lastAny = retrieveEvents({ trajectoryFile, incrementalFile, query: parseQueryScope('全部', { nowMs: now() }), limit: 1 })
      const answer = buildRecallAnswer(events, range, { lastAt: lastAny[0] ? stampOf(lastAny[0], 'all') : '' })
      lastAskAt = now()
      persist()
      audit({ kind: 'coach-ask', trigger, frameId: null, source: 'recall', degraded: false, llmOk: false, recall: true, eventCount: events.length, scope: range.scope, range: range.label, query: String(input.query || '').slice(0, 120) })
      if (typeof opts.onAsk === 'function') { try { await opts.onAsk({ question: answer, trigger, frameId: null }) } catch { /* 出口失败不影响返回 */ } }
      return { ok: true, question: answer, source: 'recall', degraded: false, recall: true, scope: range.scope, range: range.label, events: events.length, context: { frameId: null, recentTrajectory: events.length, extractChars: 0 } }
    }
    const recent = lastTrajectory(trajectoryFile, 3)
    // S35·B 截图压缩归类：extract 拿到文本后打 category:work|life（关键词规则，不猜）→ 入对应线账本
    try {
      const { classifyAndStore } = await import('../longterm-memory/lines.mjs')
      await classifyAndStore({ window, process: proc, text: extractText })
    } catch { /* 归类失败不影响问询主流程 */ }
    // 记忆 hints（二级记忆 recall；无记忆则回落轨迹，不注入空段）
    const hintsBlock = memoryHints.length ? `\n相关记忆：\n${memoryHints.map((h) => '· ' + String(h).slice(0, 120)).join('\n')}` : ''

    let question = ''
    let llmOk = false
    try {
      const r = await router.run('summarize', {
        messages: [
          { role: 'system', content: activePrompt('recall', RECALL_PROMPT) },
          { role: 'user', content: JSON.stringify({ screenText: extractText || '（屏幕文字抽取失败）', recentTrajectory: recent.map((t) => ({ intent: t.intent, process: t.process })), memoryHints }, null, 0) + hintsBlock },
        ],
        maxTokens: 300,
      })
      if (r.ok && r.text && r.text.trim()) { question = r.text.trim(); llmOk = true }
    } catch { /* 走降级 */ }
    if (!llmOk) {
      question = degraded
        ? '教练暂时读不到屏幕上下文（抽取失败）。你现在卡在哪一步？'
        : `教练看到你在「${window || proc || '当前窗口'}」。你现在卡在哪一步？需要我根据这段内容（${extractText.slice(0, 60)}…）帮你拆解吗？`
    } else if (degraded) {
      // LLM 成功但屏幕上下文缺失：问询必须显式声明，不许假装看到了屏幕
      question = '教练暂时读不到屏幕上下文（抽取失败）。\n' + question
    }
    if (memoryHints.length && !/记忆|建议/.test(question)) {
      // 有相关记忆但问询未涉及时，附一行可回指的提示（不编造）
      question += `\n（相关记忆：${memoryHints[0].slice(0, 60)}）`
    }

    lastAskAt = now()
    persist()
    audit({ kind: 'coach-ask', trigger, frameId, source, degraded, llmOk, recentTrajectory: recent.length, query: String(input.query || '').slice(0, 120) })
    if (typeof opts.onAsk === 'function') {
      try { await opts.onAsk({ question, trigger, frameId }) } catch { /* 出口失败不影响返回 */ }
    }
    return { ok: true, question, source, degraded, context: { frameId, recentTrajectory: recent.length, extractChars: extractText.length } }
  }

  function state() { return { lastAskAt, cooldownMs } }
  return { ask, state }
}

export default { createConfusionCoach, ASK_COOLDOWN_MS_DEFAULT, ConfusionError, RECALL_PROMPT }
