// packages/plugins/coach/chain.mjs
//
// S39·F1 证据链可视化：一条结论的链路 raw_frame→observation→summary→claim，只读真实查询。
// 纪律（红线）：
//   · 数据全部来自真实查询（claim/claim_evidence/raw_frame/observation/summary）；绝不编造节点。
//   · 已删原图：灰显 + 固定降级文案（publish.DEGRADED_EVIDENCE_COPY），不伪装能看。
//   · 无证据 → 明确显示「该结论无证据」，不空白。
//   · 只读：本模块不调用任何写入/删除接口。
import { resolveEvidence } from '../../core/src/lifecycle/publish.mjs'

const LAYER_ORDER = ['raw_frame', 'observation', 'summary', 'claim']
const LAYER_LABEL = { raw_frame: '原图（raw_frame）', observation: '观测（observation）', summary: '摘要（summary）', claim: '结论（claim）' }

/**
 * 构建一条结论的证据链（只读）。
 * @param {{claimId:string, store:object}} input
 * @returns {{ok:boolean, empty?:boolean, text?:string, claim?:object, nodes?:Array, degraded?:number}}
 */
export function buildEvidenceChain({ claimId, store }) {
  try {
    if (!store || !store._db) return { ok: false, text: '生命周期库不可用（store 未注入）' }
    const claim = store._db.prepare('SELECT id, text, status, created_at FROM claim WHERE id = ?').get(claimId)
    if (!claim) return { ok: true, empty: true, text: `未找到结论 ${claimId}` }
    const links = store._db.prepare('SELECT evidence_id AS evidenceId, layer, sha256 AS ceSha, relation FROM claim_evidence WHERE claim_id = ? ORDER BY id').all(claimId)
    const nodes = []
    let degraded = 0
    for (const link of links) {
      const layer = LAYER_ORDER.includes(link.layer) ? link.layer : 'raw_frame'
      let row = null
      try {
        if (layer === 'raw_frame') row = store.getRawFrame(link.evidenceId)
        else if (layer === 'observation') row = store.getObservation(link.evidenceId)
        else row = store._db.prepare(`SELECT id, created_at FROM ${layer} WHERE id = ?`).get(link.evidenceId)
      } catch { row = null }
      let availability = 'unregistered'
      let degradedNote = ''
      let sha = String(link.ceSha || (row && row.sha256) || '')
      if (layer === 'raw_frame') {
        let st = 'unregistered'
        try { st = resolveEvidence(store, link.evidenceId, 'raw_frame').status } catch { st = 'unregistered' }
        availability = st
        if (st === 'deleted' || st === 'missing') {
          degraded += 1
          degradedNote = '【灰显·已删原图】' + '原图已按保留策略删除；保留时间、窗口、摘要与内容哈希，无法恢复画面。'
        }
      } else {
        availability = row ? 'ready' : 'missing'
      }
      nodes.push({
        layer,
        label: LAYER_LABEL[layer],
        id: link.evidenceId,
        ts: (row && (row.created_at || row.ts)) || null,
        sha256Prefix: sha.slice(0, 12) || '（无哈希）',
        availability,
        grey: !!(degradedNote),
        degradedNote,
      })
    }
    // 结论节点自身
    nodes.push({ layer: 'claim', label: LAYER_LABEL.claim, id: claim.id, ts: claim.created_at, sha256Prefix: '（结论本体）', availability: claim.status, grey: false, degradedNote: '' })
    return { ok: true, empty: false, claim: { id: claim.id, text: String(claim.text || '').slice(0, 160), status: claim.status, createdAt: claim.created_at }, nodes, degraded, evidenceCount: links.length }
  } catch (e) {
    return { ok: false, text: '链路查询失败：' + String((e && e.message) || e).slice(0, 120) }
  }
}

/** 渲染为面板文本（每节点块：可点开的详情字段 id/ts/sha256 前缀/availability 全量展示）。 */
export function renderChainMd(chain) {
  if (!chain || !chain.ok) return chain && chain.text ? chain.text : '链路不可用'
  if (chain.empty) return chain.text
  const L = [
    `证据链（${chain.claim.id}）：`,
    `· 结论：${chain.claim.text}…【status=${chain.claim.status}】`,
    '',
  ]
  for (const n of nodesOf(chain)) {
    const grey = n.grey ? ' ▓▓ 灰显' : ''
    L.push(`  ▸ ${n.label}${grey}`)
    L.push(`      id: ${n.id}`)
    L.push(`      ts: ${n.ts || '（无时间戳）'}`)
    L.push(`      sha256: ${n.sha256Prefix}…`)
    L.push(`      availability: ${n.availability}`)
    if (n.degradedNote) L.push(`      ↓ ${n.degradedNote}`)
  }
  L.push('')
  L.push(`共 ${chain.evidenceCount} 条证据 / ${chain.degraded} 条已删原图（灰显降级）。本页只读，不触发任何删除。`)
  return L.join('\n')
}

function nodesOf(chain) {
  // 展示顺序：raw_frame → observation → summary → claim
  return [...chain.nodes].sort((a, b) => LAYER_ORDER.indexOf(a.layer) - LAYER_ORDER.indexOf(b.layer))
}

/** 无证据时的提示文本。 */
export function noEvidenceText(claimId) {
  return `该结论无证据（claim_evidence 无 ${claimId} 的引用行）。不空白、不编造：需要先挂证据（截图→raw_frame→publish）。`
}

export default { buildEvidenceChain, renderChainMd, noEvidenceText }
