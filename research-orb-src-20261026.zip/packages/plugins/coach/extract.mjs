// packages/plugins/coach/extract.mjs
//
// S25·2B 截图 → 文本：qwen 视觉优先（经 router extract 档，令牌桶 10 req/min），
// 失败回落 WinRT OCR（extract-fallback 审计）。
// 纪律（红线）：
//   · 原图删除可审计：处理后原图先复制到 data\trash\（TTL 由既有 trash 清理机制覆盖），
//     再删原件；coach.jsonl 记 {frameId, textSha256, bytes, deletedAt, ok, trashedTo}。
//     只留文本 + sha256 + 时间（frames-index.json 不含原图路径/二进制）。
//   · 同图去重：按图片 sha256 索引，重复处理直接返回缓存（不调 router、不扣配额）。
//   · 本模块不直接出网：LLM 兑现全部经注入的 router（extract 档）。
import { createHash } from 'node:crypto'
import { spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, readFileSync, writeFileSync, copyFileSync, rmSync, statSync, unlinkSync } from 'node:fs'
import { join, basename } from 'node:path'
import { PROJECT_ROOT, appendJsonl, logPath, dataPath } from '../../core/src/safefs.mjs'
import { runWinrtOcr } from './ocr.mjs'

export const FRAME_INDEX_FILE = dataPath('coach', 'frames-index.json')
export const TRASH_DIR = dataPath('trash')

export class ExtractError extends Error {
  constructor(code, message) { super(message); this.name = 'ExtractError'; this.code = code }
}

/** B2：extract 总时长硬上限（45s）。超时即中止本轮、标 extract-timeout，不写半条轨迹。 */
// S60：视觉改走智谱 GLM-5.3-Flash（推理模型），首 token 慢 → 超时从 45s 提到 90s（≥60s 要求）
export const EXTRACT_TIMEOUT_MS = 90000
function withTimeout(promise, ms, msg, code) {
  return new Promise((resolve, reject) => {
    const id = setTimeout(() => reject(Object.assign(new Error(msg), { code })), ms)
    promise.then(
      (v) => { clearTimeout(id); resolve(v) },
      (e) => { clearTimeout(id); reject(e) },
    )
  })
}

function sha256(buf) { return createHash('sha256').update(buf).digest('hex') }

function loadIndex(file) {
  try {
    if (!existsSync(file)) return {}
    return JSON.parse(readFileSync(file, 'utf8')) || {}
  } catch { return {} }
}

function saveIndex(file, idx) {
  mkdirSync(join(file, '..'), { recursive: true })
  writeFileSync(file, JSON.stringify(idx, null, 2), 'utf8')
}

/** 预制视觉 prompt（S63·P0-2 摘要化）：转录 + 压缩为 ≤300 字摘要 + 结构化字段，只输出 JSON。
 *  此前"逐字转录"单帧 922 字 / completionTokens 604 / 15.5s —— 96 次/天累积 8.8 万字会把日报归纳滚爆。 */
/** S71·2B：读取资料库（机器/应用特征表/习惯/示例），拼成注入块；≤600 token（≈2400 字符）超限裁剪。 */
export function loadVisionContext(maxChars = 2400) {
  let raw = ''
  try { raw = readFileSync(dataPath('vision-context.json'), 'utf8') } catch { return { block: '', trimmed: false, bytes: 0 } }
  let ctx = null
  try { ctx = JSON.parse(raw) } catch { return { block: '', trimmed: false, bytes: 0 } }
  const apps = Array.isArray(ctx.apps) ? ctx.apps : []
  const table = apps.map((a) => `- ${a.name}：信号[${(a.signals || []).join('、')}]`).join('\n')
  const routines = Array.isArray(ctx.routines) ? ctx.routines.map((r) => `- ${r.name}：${(r.apps || []).join('、')}`).join('\n') : ''
  const shots = Array.isArray(ctx.fewShots) ? ctx.fewShots.map((s) => `- 场景"${s.scene}"→ tool=${s.tool} task=${s.task} intent=${s.intent}`).join('\n') : ''
  let block = `【应用特征表】\n${table}\n${routines ? '【常见习惯】\n' + routines + '\n' : ''}${shots ? '【示例】\n' + shots + '\n' : ''}`
  let trimmed = false
  if (block.length > maxChars) { block = block.slice(0, maxChars) + '\n（资料库已裁剪）'; trimmed = true }
  // S73：vision 生效提示词可被 data\prompts\vision-active.txt 覆盖（dev prompt set 生效入口）
  let prompt = null
  try {
    const pp = dataPath('prompts', 'vision-active.txt')
    if (existsSync(pp)) { const t = readFileSync(pp, 'utf8'); if (t.trim()) prompt = t }
  } catch { /* fallthrough */ }
  return { block, trimmed, bytes: block.length, prompt }
}

// ---------------------------------------------------------------------------
// S74·1-A：视觉 prompt 拆成**可导出常量**（种子化唯一真源）
//   · data\prompts\vision-v1.txt 由 VISION_PROMPT_TEMPLATE 导出，与运行时**逐字一致**；
//   · `{context}` 是资料库注入位——默认分支与覆盖分支走同一占位符，
//     所以"dev prompt set 覆盖生效"后**不会丢掉【应用特征表】**（S73 的隐性缺陷，一并修掉）。
// ---------------------------------------------------------------------------
export const VISION_SYS = '你是屏幕视觉解析器。先**逐字**读窗口标题栏、左侧导航/菜单、标签页、地址栏等界面元素文字。'
export const VISION_RULE = 'identifyApp: 把上述界面原文与【应用特征表】每项的信号比对，命中最多的那项取其 name 作为 tool.name；**若窗口标题栏出现与某 signals 完全一致的字串，必须取该 name（不要因谨慎而留空）**；都不命中才留空且 confidence<0.5、uncertain:true。**禁止猜测或套用特征表以外的软件名**。'
export const VISION_SCHEMA = '只输出 JSON（不要围栏）：{"scene":"一句话画面结构","tool":{"name":"应用规范名或空","evidence":["标题/导航可见原文≥6字"]},"task":"用户此刻在做的具体任务≤30字","intent":{"line":"学习|工作|生活|其他|self","evidence":["判断依据可见文字"]},"evidence":["关键可见文字≥2条，每条≥6字"],"narrative":"≤80字叙述：在「X」做 Y","confidence":0.0,"topic":"核心主题≤30字","entities":["≤5"],"text":"转录要点≤300字，保持原文措辞"}' +
  '。若画面主体是 research-orb 自身面板（特征表 selfApps），intent.line 记为 self。'
export const VISION_CONTEXT_PLACEHOLDER = '{context}'
export const VISION_PROMPT_TEMPLATE = `${VISION_SYS}\n${VISION_RULE}\n${VISION_CONTEXT_PLACEHOLDER}${VISION_SCHEMA}`

/** 资料库注入位的实际文本：有块则带尾换行，无块则空串（模板里 `{context}` 后面紧跟 schema）。 */
function contextPart(ctxBlock) { return ctxBlock ? String(ctxBlock) + '\n' : '' }

/**
 * 视觉叙事四层 prompt（S71·2B）。tool.name 采用"与【应用特征表】信号比对"的**通用规则**，
 * 不针对任何具体应用硬编码分支；读不到就留空 + uncertain，禁止编软件名。
 */
export function visionMessages(imageBase64, mime = 'image/jpeg', ctxBlock = '', promptOverride = null) {
  const userText = promptOverride
    ? String(promptOverride).split(VISION_CONTEXT_PLACEHOLDER).join(contextPart(ctxBlock))
    : `${VISION_SYS}\n${VISION_RULE}\n${contextPart(ctxBlock)}${VISION_SCHEMA}`
  return [{
    role: 'user',
    content: [
      { type: 'image_url', image_url: { url: `data:${mime};base64,${imageBase64}` } },
      { type: 'text', text: userText },
    ],
  }]
}

/**
 * S27·问题2：送模型前把截图降采样到 ≤640 宽 JPEG q70（原图不动，仍走 trash/TTL）。
 * 零新增依赖：复用本机 GDI+（子进程 powershell System.Drawing）。
 * 坑（S24 实测）：绝对路径内联脚本串会被宿主脱敏层替换 → 用 $env: 传参。
 * @returns {string|null} 缩略图路径；失败返回 null（调用方回落原图，不阻断）。
 */
export function shrinkForModel(imagePath, maxWidth = 640, quality = 70) {
  try {
    if (!existsSync(imagePath)) return null
    const dir = dataPath('tmp', 'coach-shrink')
    mkdirSync(dir, { recursive: true })
    const out = join(dir, createHash('sha256').update(imagePath + ':' + Date.now()).digest('hex').slice(0, 12) + '.jpg')
    const script = [
      '$ErrorActionPreference="Stop"',
      'try {',
      '  Add-Type -AssemblyName System.Drawing',
      '  $src=$env:COACH_SHRINK_SRC; $dst=$env:COACH_SHRINK_DST',
      `  $mw=${maxWidth}`,
      '  $img=[System.Drawing.Image]::FromFile($src)',
      '  $w=[Math]::Min($mw,$img.Width); $h=[int]($img.Height*$w/$img.Width)',
      '  $bmp=New-Object System.Drawing.Bitmap $w,$h',
      '  $g=[System.Drawing.Graphics]::FromImage($bmp)',
      '  $g.InterpolationMode="HighQualityBicubic"',
      '  $g.DrawImage($img,0,0,$w,$h)',
      '  $enc=[System.Drawing.Imaging.Encoder]::Quality',
      '  $p=New-Object System.Drawing.Imaging.EncoderParameters(1)',
      '  $p.Param[0]=New-Object System.Drawing.Imaging.EncoderParameter($enc,' + quality + 'L)',
      '  $codec=[System.Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object { $_.MimeType -eq "image/jpeg" }',
      '  $bmp.Save($dst,$codec,$p)',
      '  $g.Dispose();$bmp.Dispose();$img.Dispose()',
      "  Write-Output 'SHRINK_OK'",
      '} catch { Write-Output ("SHRINK_ERR " + $_.Exception.Message) }',
    ].join('\n')
    const r = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], {
      timeout: 30000, encoding: 'utf8', env: { ...process.env, COACH_SHRINK_SRC: imagePath, COACH_SHRINK_DST: out },
    })
    if ((r.stdout || '').includes('SHRINK_OK') && existsSync(out) && statSync(out).size > 0) return out
    return null
  } catch { return null }
}

/** 字符级命中率：样本字符在转录中被命中的比例（去空白；用于 20 字样本验收口径）。 */
export function hitRate(sample, transcript) {
  const s = String(sample || '').replace(/\s+/g, '')
  const t = String(transcript || '').replace(/\s+/g, '')
  if (!s) return 0
  let hit = 0
  for (const ch of s) if (t.includes(ch)) hit += 1
  return hit / s.length
}

/**
 * @param {{
 *   dir?: string,               // 状态目录（默认 data\coach；frames-index.json 落这里）
 *   router: object,             // createRouter 实例（extract 档）
 *   ocr?: Function,             // OCR 兜底实现（默认 runWinrtOcr；测试注入）
 *   trashDir?: string,
 *   now?: () => number,
 * }} opts
 */
/**
 * S69·1B：真实抓帧的"空帧"守卫（15 字节等坏帧不送模）。
 * 放在 captureOne（真实抓屏路径）而非 extract——测试夹具是合成小图，不应被这道真机守卫误伤。
 * @returns {{ok:boolean, bytes:number}} ok=false 表示太小 / 读不到
 */
export function frameBytesGuard(pngPath, minBytes = 1024) {
  try { const b = statSync(pngPath).size; return { ok: b >= minBytes, bytes: b } } catch { return { ok: false, bytes: 0 } }
}

export function createExtractor(opts = {}) {
  const dir = opts.dir || dataPath('coach')
  const indexFile = join(dir, 'frames-index.json')
  const trashDir = opts.trashDir || TRASH_DIR
  const now = opts.now || (() => Date.now())
  const extractTimeoutMs = Number.isFinite(opts.extractTimeoutMs) ? opts.extractTimeoutMs : EXTRACT_TIMEOUT_MS
  if (!opts.router) throw new ExtractError('E_NO_ROUTER', 'extractor: 需要注入 router（extract 档）')
  const router = opts.router
  const ocrImpl = opts.ocr || runWinrtOcr

  function audit(rec) {
    try { appendJsonl(logPath('coach.jsonl'), { ts: new Date().toISOString(), ...rec }) } catch { /* 尽力 */ }
  }
  // S71·2B：视觉资料库（应用特征表/习惯/示例）一次加载，≤600 token 注入；超限裁剪审计
  const _vctx = loadVisionContext()
  if (_vctx.trimmed) audit({ kind: 'vision-context-trimmed', bytes: _vctx.bytes })

  /**
   * 抽取一张截图的文字。
   * @returns {Promise<{ok, cached, frameId, text, textSha256, source, ts, deleted}>}
   */
  async function extract({ imagePath }) {
    if (!imagePath || !existsSync(imagePath)) {
      throw new ExtractError('E_FRAME_NOT_FOUND', `截图不存在：${imagePath}`)
    }
    const bytes = readFileSync(imagePath)
    const hash = sha256(bytes)
    const idx = loadIndex(indexFile)
    // 去重：同图已处理 → 返回缓存（不调 router、不扣配额）；同内容副本也移入 trash（不留盘）
    if (idx[hash]) {
      const c = idx[hash]
      try {
        mkdirSync(trashDir, { recursive: true })
        const stamp = new Date(now()).toISOString().replace(/[:.]/g, '-')
        const trashedTo = join(trashDir, `${stamp}-dup-${basename(imagePath)}`)
        copyFileSync(imagePath, trashedTo)
        rmSync(imagePath, { force: true })
        audit({ kind: 'frame-dedup-deleted', frameId: c.frameId, trashedTo, bytes: bytes.length })
      } catch { /* 删除失败不影响缓存返回 */ }
      return { ok: true, cached: true, frameId: c.frameId, text: c.text, textSha256: c.textSha256, source: c.source, ts: c.ts, deleted: true }
    }

    const frameId = 'fr-' + hash.slice(0, 12)
    let text = ''
    let structured = null
    let source = 'vision'
    // S27·问题2：送模型前降采样（≤640 宽 JPEG q70）；原图不动，仍走 trash/TTL
    const shrunk = shrinkForModel(imagePath, 960, 80) // S71·2B：标题栏文字需可读，640→960
    const modelInput = shrunk || imagePath
    const mime = shrunk ? 'image/jpeg' : 'image/png'
    // S56：sent-to-model 真审计 —— 名实一致（这是压缩送模动作本身发生的那一刻）：
    //   感知卡「已压缩送模」= 这类事件数；「省 X MB」= Σ(bytesBefore − bytesAfter)。
    //   写 perception.jsonl 且 ts 用**数字**（感知卡按数字 ts 过滤今日；coach.jsonl 是 ISO 的，别混）。
    try {
      let bytesAfter = bytes.length
      if (shrunk) { try { bytesAfter = statSync(shrunk).size } catch { /* 读不到按原图 */ } }
      appendJsonl(logPath('perception.jsonl'), { ts: now(), kind: 'sent-to-model', frameId, bytesBefore: bytes.length, bytesAfter })
    } catch { /* 审计失败不阻断送模 */ }
    // 主路径：视觉档（经 router extract 档；S63 max_tokens 800→512 + 摘要化 prompt）
    let r
    try {
      r = await withTimeout(
        // S71·2B：四层 JSON + 每层 evidence 很长，推理模型 768/1024 实测均截断 → 1536（防截断，不为改断言）
        router.run('extract', { messages: visionMessages(readFileSync(modelInput).toString('base64'), mime, _vctx.block, _vctx.prompt), maxTokens: 1536 }),
        extractTimeoutMs,
        `extract 超时（${extractTimeoutMs}ms）：本轮中止，不写半条轨迹`,
        'E_EXTRACT_TIMEOUT',
      )
    } catch (e) {
      // B2：超时要显式标 extract-timeout 并审计（即使后续 OCR 兜底也不会再尝试——直接中止本轮）
      if (e && e.code === 'E_EXTRACT_TIMEOUT') {
        audit({ kind: 'extract-timeout', frameId: 'fr-' + hash.slice(0, 12), bytes: bytes.length, ms: EXTRACT_TIMEOUT_MS })
      }
      throw e
    }
    if (shrunk) { try { unlinkSync(shrunk) } catch { /* 缩略副本清理失败不影响（data/tmp 有 TTL） */ } }
    if (r.ok && r.text && r.text.replace(/\s+/g, '').length >= 4) {
      // S63·P0-3：source 取实际 providerId（router 回包），不再硬编码 'qwen'
      source = (r.providerId && String(r.providerId)) || (r.tier === 'vision' ? 'vision' : 'cheap')
      // S63·P0-2：解析结构化摘要 JSON（宽松：剥围栏取首个 {...}）；解析失败按全文处理
      const looseParse = (s) => {
        let t = String(s || '').trim()
        const m = /```(?:json)?\s*([\s\S]*?)```/.exec(t)
        if (m) t = m[1].trim()
        const b = t.indexOf('{')
        const e2 = t.lastIndexOf('}')
        if (b >= 0 && e2 > b) t = t.slice(b, e2 + 1)
        try { return JSON.parse(t) } catch { return null }
      }
      const p = looseParse(r.text)
      if (p && typeof p === 'object') {
        const toolName = (p.tool && typeof p.tool === 'object') ? String(p.tool.name || '') : String(p.app || '')
        const intentVal = (p.intent && typeof p.intent === 'object') ? String(p.intent.line || '') : String(p.intent || '')
        const task = String(p.task || p.topic || '')
        const conf = Number.isFinite(Number(p.confidence)) ? Number(p.confidence) : (toolName ? 0.8 : 0.4)
        const evid = Array.isArray(p.evidence) ? p.evidence.map((x) => String(x).slice(0, 80)).filter(Boolean).slice(0, 6) : []
        const toolEvid = Array.isArray(p.tool && p.tool.evidence) ? p.tool.evidence.map((x) => String(x).slice(0, 80)).filter(Boolean).slice(0, 4) : []
        structured = {
          // 旧字段兼容（app/intent/topic/entities）
          app: String(toolName || p.app || '').slice(0, 60),
          intent: String(intentVal || '').slice(0, 20),
          topic: task.slice(0, 60),
          entities: Array.isArray(p.entities) ? p.entities.map((x) => String(x).slice(0, 40)).slice(0, 5) : [],
          // S71·2B：四层 scene/tool/task/intent + evidence + narrative + confidence
          layers: {
            scene: String(p.scene || '').slice(0, 120),
            tool: { name: String(toolName || '').slice(0, 60), evidence: toolEvid },
            task: task.slice(0, 60),
            intent: { line: String(intentVal || '').slice(0, 20), evidence: Array.isArray(p.intent && p.intent.evidence) ? p.intent.evidence.map((x) => String(x).slice(0, 80)).slice(0, 4) : [] },
            evidence: evid,
            narrative: String(p.narrative || '').slice(0, 200),
            confidence: conf,
          },
          self: String(intentVal || '') === 'self',
          uncertain: conf < 0.5 || !toolName,
        }
        text = String(p.text || p.narrative || '').trim().slice(0, 300)
        if (!text) text = r.text.trim()
      } else {
        text = r.text.trim()
      }
    } else {
      // 兜底：WinRT OCR + extract-fallback 审计
      const o = ocrImpl(imagePath)
      audit({ kind: 'extract-fallback', frameId, from: source, to: 'winrt-ocr', reason: r && r.error ? r.error.message : 'empty-answer', ocrOk: !!o.ok })
      if (!o.ok || !String(o.text || '').trim()) {
        throw new ExtractError('E_EXTRACT_FAILED', `qwen 与 OCR 均未得到文本（qwen: ${r && r.error ? r.error.code : 'empty'}；ocr: ${o.err || '空'}）`)
      }
      text = String(o.text).trim()
      source = 'ocr'
    }

    const textSha256 = sha256(Buffer.from(text, 'utf8'))
    const ts = now()

    // 原图删除：复制到 trash（TTL 由既有清理覆盖）→ 删原件 → 审计
    // S27 健壮化：data\shots 与生命周期清理器（冻结模块）有竞态——源图可能已被清掉；
    // 此时"不保留原图"的纪律已达成，如实标注；copy 失败则直删保底，都不许静默留图。
    let deleted = false
    let trashedTo = null
    let deleteNote = ''
    try {
      if (!existsSync(imagePath)) {
        deleted = true
        deleteNote = 'source-already-gone（源图已被其它机制清理，未保留）'
      } else {
        mkdirSync(trashDir, { recursive: true })
        const stamp = new Date(ts).toISOString().replace(/[:.]/g, '-')
        trashedTo = join(trashDir, `${stamp}-${basename(imagePath)}`)
        copyFileSync(imagePath, trashedTo)
        rmSync(imagePath, { force: true })
        deleted = !existsSync(imagePath)
        if (!deleted) deleteNote = 'delete-failed'
      }
    } catch (e) {
      try { rmSync(imagePath, { force: true }) } catch { /* 仍失败则如实记 ok:false */ }
      deleted = !existsSync(imagePath)
      deleteNote = deleted ? 'copy-failed-deleted-direct（trash 副本缺失，原图已直删）' : 'delete-failed'
    }
    audit({
      kind: 'frame-processed',
      frameId,
      textSha256,
      bytes: bytes.length,
      deletedAt: deleted ? new Date(ts).toISOString() : null,
      ok: deleted,
      trashedTo: deleted ? trashedTo : null,
      source,
      ...(deleteNote ? { note: deleteNote } : {}),
    })

    idx[hash] = { frameId, text, textSha256, source, ts, bytes: bytes.length }
    saveIndex(indexFile, idx)
    return { ok: true, cached: false, frameId, text, textSha256, source, structured, ts, deleted }
  }

  return { extract, _indexFile: indexFile }
}

export default { createExtractor, visionMessages, hitRate, ExtractError, FRAME_INDEX_FILE, TRASH_DIR, VISION_PROMPT_TEMPLATE }
