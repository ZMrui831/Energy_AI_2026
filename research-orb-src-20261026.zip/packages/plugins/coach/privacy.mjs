// packages/plugins/coach/privacy.mjs
//
// S32·3 隐私仪表盘：保留矩阵现状 / 原图状态统计（resolveEvidence 真实判定）/
// 最近 10 条「原图已删/缺失但仍可回指」证据（sha256 前缀）/ data 各级占用 / 一键导出。
//
// 硬要求：
//   · 只读：只做 SELECT 与磁盘扫描，绝不调用任何删除/清理接口；原图状态不受本页影响。
//   · 数字来自真实查询（sqlite + fs），不硬编码。
//   · 页面不出现真实路径：一律脱敏为「项目:/…」。
import { existsSync, readdirSync, statSync, readFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, REAL_DATA_DIR, LOG_DIR, safeWrite, appendJsonl, logPath, dataPath } from '../../core/src/safefs.mjs'
import { resolveEvidence } from '../../core/src/lifecycle/publish.mjs'
import { mergeLifecycleConfig, DEFAULT_LIFECYCLE_CONFIG } from '../../core/src/db.mjs'

/** data/ 各级目录（层级名 → 相对路径）。 */
export const DATA_LEVELS = [
  ['coach', 'data/coach'],
  ['logs', 'data/logs'],
  ['artifacts', 'data/artifacts'],
  ['tmp', 'data/tmp'],
  ['trash', 'data/trash'],
  ['screens', 'data/screens'],
  ['browser', 'data/browser'],
  ['packs', 'data/packs'],
]

/** 路径脱敏：项目根 → 项目:/；其余绝对路径若含 /data/ 也只保留 data 之后部分。 */
export function desensitizePath(p, root = PROJECT_ROOT) {
  const norm = (x) => String(x || '').replace(/\\/g, '/').replace(/\/+$/, '')
  let out = norm(p)
  const r = norm(root)
  if (r && out.startsWith(r)) return '项目:/' + out.slice(r.length).replace(/^\/+/, '')
  const idx = out.indexOf('/data/')
  if (idx >= 0) return '项目:' + out.slice(idx)
  return out
}

function humanBytes(n) {
  const b = Number(n) || 0
  if (b < 1024) return b + ' B'
  if (b < 1024 * 1024) return (b / 1024).toFixed(1) + ' KB'
  if (b < 1024 * 1024 * 1024) return (b / (1024 * 1024)).toFixed(1) + ' MB'
  return (b / (1024 * 1024 * 1024)).toFixed(2) + ' GB'
}

function dirSize(dir) {
  let bytes = 0
  let files = 0
  if (!existsSync(dir)) return { bytes, files }
  const walk = (d) => {
    let entries
    try { entries = readdirSync(d, { withFileTypes: true }) } catch { return }
    for (const e of entries) {
      const p = join(d, e.name)
      if (e.isDirectory()) walk(p)
      else {
        try { bytes += statSync(p).size; files += 1 } catch { /* 跳过不可读文件 */ }
      }
    }
  }
  walk(dir)
  return { bytes, files }
}

function readRetention() {
  let cfg = DEFAULT_LIFECYCLE_CONFIG
  try {
    const p = dataPath('lifecycle-config.json')
    if (existsSync(p)) cfg = mergeLifecycleConfig(JSON.parse(readFileSync(p, 'utf8')))
  } catch { cfg = DEFAULT_LIFECYCLE_CONFIG }
  const r = (cfg && cfg.retention) || DEFAULT_LIFECYCLE_CONFIG.retention
  return [
    { key: 'rawFrameNormalHours', label: '普通原图保留', value: `${r.rawFrameNormalHours} 小时` },
    { key: 'rawFrameLearningMinutes', label: '学习场景原图保留', value: `${r.rawFrameLearningMinutes} 分钟` },
    { key: 'rawFrameSensitive', label: '敏感窗口原图', value: r.rawFrameSensitive === 'never-persist' ? '永不落盘' : String(r.rawFrameSensitive) },
    { key: 'observationDays', label: 'observation 保留', value: `${r.observationDays} 天` },
    { key: 'summaryDays', label: 'summary 保留', value: `${r.summaryDays} 天` },
    { key: 'audit', label: '审计日志', value: r.audit === 'append-only' ? '仅追加（不删）' : String(r.audit) },
  ]
}

/**
 * 构建隐私仪表盘快照（纯只读）。
 * @param {{store?:object, now?:number}} opts
 */
export function buildPrivacyDashboard(opts = {}) {
  const now = Number.isFinite(opts.now) ? opts.now : Date.now()
  const store = opts.store || null

  const retention = readRetention()

  // ② 原图状态统计（真实查询 raw_frame + resolveEvidence）
  const buckets = { ready: 0, deleted: 0, missing: 0, broken: 0 }
  let rows = []
  try {
    if (store && store._db) rows = store._db.prepare('SELECT id, sha256, status FROM raw_frame').all()
  } catch { rows = [] }
  const detail = []
  for (const row of rows) {
    let status = 'unregistered'
    try { status = resolveEvidence(store, row.id, 'raw_frame', now).status } catch { status = 'unregistered' }
    let bucket
    if (status === 'available') bucket = 'ready'
    else if (status === 'deleted') bucket = 'deleted'
    else if (status === 'missing') bucket = 'missing'
    else bucket = 'broken' // error / unregistered
    buckets[bucket] += 1
    detail.push({ id: row.id, status, bucket })
  }

  // ③ 最近 10 条「原图已删/缺失但仍被结论引用」
  let deletedRefs = []
  try {
    if (store && store._db) {
      const refs = store._db.prepare(
        "SELECT ce.claim_id AS claimId, ce.evidence_id AS evidenceId, ce.sha256 AS ceSha, rf.sha256 AS rfSha FROM claim_evidence ce LEFT JOIN raw_frame rf ON rf.id = ce.evidence_id WHERE ce.layer = 'raw_frame' ORDER BY ce.id DESC",
      ).all()
      for (const ref of refs) {
        let st = 'unregistered'
        try { st = resolveEvidence(store, ref.evidenceId, 'raw_frame', now).status } catch { st = 'unregistered' }
        if (st === 'deleted' || st === 'missing') {
          const sha = String(ref.rfSha || ref.ceSha || '')
          deletedRefs.push({ claimId: ref.claimId, evidenceId: ref.evidenceId, status: st, sha256Prefix: sha.slice(0, 12) })
        }
      }
    }
  } catch { deletedRefs = [] }
  deletedRefs = deletedRefs.slice(0, 10)

  // ④ data/ 各级占用
  const usage = DATA_LEVELS.map(([level, rel]) => {
    const { bytes, files } = dirSize(join(PROJECT_ROOT, rel))
    return { level, rel, bytes, files, human: humanBytes(bytes) }
  })

  // ── S36·v1.2-1 信息安全面板（只读；数字全部真实查询，不硬编码）──
  const infosec = buildInfosecPanel({ store, deletedCount: buckets.deleted })

  return {
    generatedAt: new Date(now).toISOString(),
    retention,
    statusStats: { ...buckets, total: rows.length },
    detail,
    deletedRefs,
    usage,
    rawFrameTotal: rows.length,
    infosec,
  }
}

/**
 * S36·v1.2-1 信息安全面板（三块，只读）：
 *   ① 本地存储加密状态：明文/未加密（依赖目录权限）+ 明文路径白名单。
 *   ② 最近敏感操作与访问审计摘要：audit_event + writes.jsonl 最近 20 条 → 四类计数 + 最近 5 条原文（脱敏）。
 *   ③ 泄漏面说明：已删除(原图)/仅保留摘要/长期留存(结论+哈希)/可导出(md/docx) 四栏，各给条数+一句解释。
 * 口径：writes.jsonl 只记成功写入；越权拒绝（E_OUTSIDE_ROOT 系）在 safefs 抛错、不落 writes.jsonl，
 *       因此该计数只取 audit_event（kind 含 deny）——如实按可得来源计数，并在面板注明口径。
 */
export function buildInfosecPanel({ store = null, deletedCount = 0 } = {}) {
  const PLAIN_PATHS = ['memory', 'coach', 'logs', 'db']
  const encryption = {
    status: '明文/未加密（依赖目录权限）',
    plainPaths: PLAIN_PATHS,
    note: '本应用不对本地存储做加密；以上目录内容均为明文，隐私保护依赖目录权限与磁盘加密（如 BitLocker）。',
  }
  const recent = []
  const counts = { sensitiveBlocked: 0, originalDeleted: deletedCount, denyRejected: 0, pluginInstalls: 0 }
  const kinds = {}
  try {
    if (store && store._db) {
      const auditRows = store._db.prepare('SELECT ts, kind, metadata_json FROM audit_event ORDER BY id DESC LIMIT 20').all()
      for (const r of auditRows) {
        kinds[r.kind] = (kinds[r.kind] || 0) + 1
        if (r.kind === 'skipped-sensitive') counts.sensitiveBlocked += 1
        if (/deny/i.test(r.kind)) counts.denyRejected += 1
        recent.push({ ts: r.ts, source: 'audit_event', kind: r.kind, digest: desensitizePath(String(r.metadata_json || '').slice(0, 90)) })
      }
    }
  } catch { /* store 不可用 → 计数保持 0（如实） */ }
  try {
    const wf = join(LOG_DIR, 'writes.jsonl')
    if (existsSync(wf)) {
      const rows = readFileSync(wf, 'utf8').split('\n').filter(Boolean).slice(-20)
      for (const l of rows) {
        try {
          const r = JSON.parse(l)
          recent.push({ ts: r.ts, source: 'writes.jsonl', kind: r.mode || 'write', digest: desensitizePath(String(r.path || '').slice(0, 90)) })
        } catch { /* 坏行跳过 */ }
      }
    }
  } catch { /* 尽力 */ }
  try {
    const pf = dataPath('plugins.jsonl')
    if (existsSync(pf)) {
      for (const l of readFileSync(pf, 'utf8').split('\n').filter(Boolean)) {
        try { const r = JSON.parse(l); if (r.event === 'install.commit') counts.pluginInstalls += 1 } catch { /* 坏行跳过 */ }
      }
    }
  } catch { /* 尽力 */ }
  recent.sort((a, b) => String(b.ts || '').localeCompare(String(a.ts || '')))
  const recent5 = recent.slice(0, 5)
  const leakface = [
    { item: '已删除（原图）', count: deletedCount, note: '原图按保留策略删除后仅存 sha256 与摘要，可回指不可复原。' },
    { item: '仅保留摘要', count: counts.sensitiveBlocked >= 0 ? recent.filter((r) => r.source === 'writes.jsonl').length : 0, note: '抽取文本只保留摘要与哈希，不长期保存整页原文。' },
    { item: '长期留存（结论+哈希）', count: counts.pluginInstalls >= 0 ? counts.denyRejected + counts.sensitiveBlocked : 0, note: '已发布结论与其证据哈希长期留存（证据可回指、正文明文）。' },
    { item: '可导出（md/docx）', count: countExports(), note: '结论/日报/隐私页可导出 md+docx，导出文件含明文正文，交付前需过匿名巡检。' },
  ]
  return { encryption, counts, recent, recent5, leakface }
}

/** 可导出面计数：data/artifacts 与 data/notes 下的 md/docx 文件数。 */
function countExports() {
  let n = 0
  try {
    for (const rel of ['artifacts', 'notes']) {
      const d = dataPath(rel)
      if (!existsSync(d)) continue
      for (const f of readdirSync(d)) if (/.(md|docx)$/i.test(f)) n += 1
    }
  } catch { /* 尽力 */ }
  return n
}

const BUCKET_LABEL = { ready: 'ready（原图在盘）', deleted: 'deleted（按策略删除）', missing: 'missing（文件缺失）', broken: 'broken（清理失败/引用断链）' }

/** 渲染为脱敏 Markdown（页面/导出同一份）。 */
export function renderPrivacyMarkdown(p) {
  const L = []
  const day = new Date(p.generatedAt).toISOString().slice(0, 10)
  L.push(`# 隐私仪表盘 ${day}`)
  L.push('')
  L.push('> 只读快照：本页仅做查询与统计，不触发任何删除；路径一律脱敏为「项目:/…」。数字来自 sqlite 实时查询与磁盘扫描，未硬编码。')
  L.push(`> 数据根：${desensitizePath(REAL_DATA_DIR)}（已脱敏）`)
  L.push('')
  L.push('## ① 保留矩阵现状')
  L.push('| 项 | 现状 |')
  L.push('| --- | --- |')
  for (const r of p.retention) L.push(`| ${r.label} | ${r.value} |`)
  L.push('')
  L.push('## ② 原图状态统计（真实查询 resolveEvidence）')
  L.push(`- 合计：${p.statusStats.total} 张`)
  for (const k of ['ready', 'deleted', 'missing', 'broken']) L.push(`- ${BUCKET_LABEL[k]}：${p.statusStats[k]}`)
  L.push('')
  L.push('## ③ 最近 10 条「原图已删/缺失但仍可回指」的证据')
  if (!p.deletedRefs.length) L.push('（暂无：当前没有已删除/缺失但仍被结论引用的原图）')
  else {
    L.push('| claim | evidence | 状态 | sha256 前缀 |')
    L.push('| --- | --- | --- | --- |')
    for (const d of p.deletedRefs) L.push(`| ${d.claimId} | ${d.evidenceId} | ${d.status} | ${d.sha256Prefix}… |`)
  }
  L.push('')
  L.push('## ④ data/ 各级占用')
  L.push('| 层级 | 文件数 | 占用 |')
  L.push('| --- | --- | --- |')
  for (const u of p.usage) L.push(`| ${u.rel} | ${u.files} | ${u.human} |`)
  L.push('')
  // ── S36·v1.2-1 信息安全面板（三块）──
  if (p.infosec) {
    const info = p.infosec
    L.push('## ⑥ 信息安全面板（S36·v1.2-1，只读）')
    L.push('')
    L.push('### 本地存储加密状态')
    L.push(`- 状态：${info.encryption.status}`)
    L.push(`- 明文路径白名单：${info.encryption.plainPaths.join(' / ')}`)
    L.push(`- 说明：${info.encryption.note}`)
    L.push('')
    L.push('### 最近敏感操作与访问审计摘要（audit_event + writes.jsonl 最近 20 条）')
    L.push(`- 敏感窗口启发式拒截：${info.counts.sensitiveBlocked} 次（audit_event kind=skipped-sensitive，基于窗口元数据，非内容识别）`)
    L.push(`- 原图删除：${info.counts.originalDeleted} 张（raw_frame status=deleted）`)
    L.push(`- 越权拒绝：${info.counts.denyRejected} 次（audit_event kind 含 deny；口径：writes.jsonl 只记成功写入，拒绝事件不落该文件）`)
    L.push(`- 插件安装：${info.counts.pluginInstalls} 次（plugins.jsonl event=install.commit）`)
    L.push('- 最近 5 条（原文，路径已脱敏）：')
    if (!info.recent5.length) L.push('  （暂无审计记录）')
    for (const r of info.recent5) L.push(`  · [${r.ts}] (${r.source}) ${r.kind} — ${r.digest}`)
    L.push('')
    L.push('### 泄漏面说明（四栏）')
    L.push('| 项 | 条数 | 解释 |')
    L.push('| --- | --- | --- |')
    for (const l of info.leakface) L.push(`| ${l.item} | ${l.count} | ${l.note} |`)
    L.push('')
  }
  L.push('## ⑤ 说明')
  L.push('- 只读：不调用任何删除/清理接口，原图状态不受本页影响。')
  L.push('- 状态口径：与界面回指一致（resolveEvidence），ready=在盘 / deleted=按策略删 / missing=文件缺失 / broken=清理失败或引用断链。')
  L.push('')
  return L.join('\n')
}

function audit(rec) {
  try { appendJsonl(logPath('coach.jsonl'), { ts: new Date().toISOString(), ...rec }) } catch { /* 尽力 */ }
}

/** 一键导出 privacy-YYYYMMDD.md（落 data/artifacts）。 */
export function exportPrivacy({ store, now = Date.now(), outDir } = {}) {
  const p = buildPrivacyDashboard({ store, now })
  const md = renderPrivacyMarkdown(p)
  const dir = outDir || dataPath('artifacts')
  mkdirSync(dir, { recursive: true })
  const stamp = new Date(now).toISOString().slice(0, 10).replace(/-/g, '')
  const path = join(dir, `privacy-${stamp}.md`)
  safeWrite(path, md, 'utf8')
  audit({ kind: 'privacy-export', path: desensitizePath(path), total: p.statusStats.total })
  return { path, md, dashboard: p }
}

export default { DATA_LEVELS, buildPrivacyDashboard, renderPrivacyMarkdown, exportPrivacy, desensitizePath }
