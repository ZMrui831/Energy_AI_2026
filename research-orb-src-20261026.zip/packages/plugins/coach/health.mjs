// packages/plugins/coach/health.mjs
//
// S25·2D 健康账：窗口/进程规则分类（娱乐/工作/unknown）→ 连续娱乐时长 → 超阈提醒（24h 冷却）→ 恢复记录。
// 纪律（红线）：
//   · 未超阈零打扰；同一超阈事件 24h 只提醒一次（冷却内不重复）。
//   · 分类不确定标 unknown 而不是猜；unknown 不计入娱乐也不计入工作。
//   · 参数自有（health.json / 代码默认），不碰 perception 默认阈值、不碰 timeline 冷却。
//   · 纯规则分类（零 LLM）；纯逻辑可测（now 注入）。
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, safeWrite, appendJsonl, logPath, dataPath } from '../../core/src/safefs.mjs'

export const HEALTH_DEFAULTS = Object.freeze({
  entertainmentCapMin: 90,              // 连续娱乐上限（分钟，默认 90，可配）
  sedentaryCapMin: 50,                 // 连续工作久坐上限（分钟，默认 50，可配）——触发"休息/喝水"档
  reminderCooldownMs: 24 * 60 * 60 * 1000, // 同一超阈事件 24h 冷却
})

/**
 * A2：三档健康提醒文案模板（建议语气、不得命令式；同档连续提醒轮换不同句，避免同一事件重复同一句）。
 *   · rest（久坐 50 分钟）→ 休息/喝水
 *   · walk（娱乐 90 分钟）→ 出去走走
 *   · pomodoro（25 分钟专注块完成）→ 番茄钟完成
 */
export const HEALTH_TEMPLATES = Object.freeze({
  rest: [
    '你已连续坐着约 50 分钟了。不妨站起来活动一下肩颈，顺手接杯温水上桌——补水和拉伸对身体都有好处。',
    '这边专注得挺久。建议稍作停顿，喝口水、让眼睛离开屏幕一两分钟，回来效率通常更高。',
    '连续工作 50 分钟是个不错的节点。起来走走、喝杯温水，给身体一个缓冲，再继续也不迟。',
  ],
  walk: [
    '娱乐时间已经超过 90 分钟了。可以考虑合上屏幕出门透透气，散个步回来状态会更好。',
    '你这阵子放松得有点久。要不要现在站起来、出门走几分钟，比一直坐着更解乏？',
    '连续娱乐快到 90 分钟了。建议出门走一走、看看远处，回来再玩也更尽兴。',
  ],
  pomodoro: [
    '这一枚 25 分钟番茄钟完成了，做得不错。可以花几分钟喝口水、伸个懒腰，再决定下一颗怎么安排。',
    '专注块顺利收尾。建议顺势休息一下，哪怕只是闭眼片刻，也能让下一段更扎实。',
    '25 分钟一气呵成。起来走走或喝口水都好，给刚才的投入一个小小的收尾。',
  ],
})

/** 规则表（小写包含匹配；命中即归类，都不命中 → unknown，不猜）。 */
export const RULES = Object.freeze({
  entertainment: ['netflix', 'youtube', 'bilibili', '爱奇艺', 'iqiyi', '腾讯视频', '优酷', 'douyu', '斗鱼', 'huya', 'steam', 'epicgames', 'minecraft', 'javaw', 'mpv', 'vlc', 'potplayer', '抖音', 'douyin', 'kuaishou', '快手', '游戏', 'video', 'game'],
  work: ['code', 'idea', 'pycharm', 'webstorm', 'python', 'java', 'javac', 'node', 'wps', 'winword', 'excel', 'powerpnt', 'typora', 'obsidian', 'sumatrapdf', 'acrobat', 'matlab', 'visio', 'origin', 'latex', 'texworks', 'cmd', 'powershell', 'windowsterminal'],
})

/** 分类：'entertainment' | 'work' | 'unknown'。process 优先，title 兜底；都不命中 → unknown（不猜）。 */
export function classifyWindow(processName = '', title = '') {
  const p = String(processName || '').toLowerCase()
  const t = String(title || '').toLowerCase()
  const hit = (list) => list.some((k) => p.includes(k) || t.includes(k))
  if (hit(RULES.entertainment)) return 'entertainment'
  if (hit(RULES.work)) return 'work'
  return 'unknown'
}

/**
 * @param {{dir?:string, now?:()=>number, capMin?:number, cooldownMs?:number,
 *          remind?:async (info)=>void}} opts
 * remind：提醒卡出口（宿主接 UI/通知；测试注入收集器）。未注入则只记账。
 */
export function createHealthLedger(opts = {}) {
  const dir = opts.dir || dataPath('coach')
  const stateFile = join(dir, 'health-state.json')
  const healthFile = join(dir, 'health.jsonl')
  const now = opts.now || (() => Date.now())
  const capMin = Number.isFinite(opts.capMin) ? opts.capMin : HEALTH_DEFAULTS.entertainmentCapMin
  const restCapMin = Number.isFinite(opts.restCapMin) ? opts.restCapMin : HEALTH_DEFAULTS.sedentaryCapMin
  const cooldownMs = Number.isFinite(opts.cooldownMs) ? opts.cooldownMs : HEALTH_DEFAULTS.reminderCooldownMs

  const defaults = {
    consecutiveMin: 0,            // 连续娱乐分钟
    workConsecutiveMin: 0,        // 连续工作（久坐）分钟
    lastCategory: null,
    lastReminderAt: { rest: 0, walk: 0, pomodoro: 0 }, // 各档独立 24h 冷却
    reminderCount: { rest: 0, walk: 0, pomodoro: 0 },   // 轮换计数（保证同档不重复同句）
    reminders: 0,
    recoveries: 0,
  }
  let st = (() => {
    try {
      if (existsSync(stateFile)) {
        const raw = JSON.parse(readFileSync(stateFile, 'utf8'))
        const lra = (typeof raw.lastReminderAt === 'object' && raw.lastReminderAt) ? raw.lastReminderAt : {}
        const rc = (typeof raw.reminderCount === 'object' && raw.reminderCount) ? raw.reminderCount : {}
        return { ...defaults, ...raw, lastReminderAt: { ...defaults.lastReminderAt, ...lra }, reminderCount: { ...defaults.reminderCount, ...rc } }
      }
    } catch { /* 损坏重建 */ }
    return { ...defaults }
  })()
  // 首启：各档冷却视为早已过（从未提醒过）
  for (const k of Object.keys(st.lastReminderAt)) if (!st.lastReminderAt[k]) st.lastReminderAt[k] = now() - cooldownMs

  function persist() { safeWrite(stateFile, JSON.stringify(st, null, 2)) }
  function record(rec) { try { appendJsonl(healthFile, { ts: new Date(now()).toISOString(), ...rec }) } catch { /* 尽力 */ } }

  // S35·A2：模板可配——opts.templates > data/coach/health-templates.json > 代码内置（逐档合并）
  const templates = (() => {
    const merged = {}
    for (const k of Object.keys(HEALTH_TEMPLATES)) merged[k] = [...HEALTH_TEMPLATES[k]]
    try {
      const cfgFile = join(dir, 'health-templates.json')
      if (existsSync(cfgFile)) {
        const doc = JSON.parse(readFileSync(cfgFile, 'utf8'))
        for (const k of Object.keys(merged)) if (Array.isArray(doc[k]) && doc[k].length) merged[k] = doc[k].map(String)
      }
    } catch { /* 配置损坏回落内置 */ }
    if (opts.templates && typeof opts.templates === 'object') {
      for (const k of Object.keys(merged)) if (Array.isArray(opts.templates[k]) && opts.templates[k].length) merged[k] = opts.templates[k].map(String)
    }
    return merged
  })()

  /** 选一档模板（按轮换计数，保证同档连续提醒不重复同一句）。返回 {message, templateId}。 */
  function pickTemplate(type) {
    const arr = templates[type] || []
    if (!arr.length) return { message: '', templateId: type + '-0' }
    const idx = (st.reminderCount[type] || 0) % arr.length
    st.reminderCount[type] = (st.reminderCount[type] || 0) + 1
    return { message: arr[idx], templateId: type + '-' + (idx + 1) }
  }

  /** 触发某档提醒（写入审计 + 回调出口）。 */
  async function fireReminder(type, info) {
    const { message, templateId } = pickTemplate(type)
    st.lastReminderAt[type] = now()
    st.reminders += 1
    // S35·A2：严格记录 {ts,kind,level,templateId,message}（level=档位 rest|walk|pomodoro）
    record({ kind: 'reminder', level: type, templateId, message, consecutiveMin: info.consecutiveMin, capMin: info.capMin })
    if (typeof opts.remind === 'function') {
      try { await opts.remind({ type, level: type, templateId, consecutiveMin: info.consecutiveMin, capMin: info.capMin, message }) } catch { /* 提醒出口失败不影响记账 */ }
    }
  }

  /**
   * 喂一条窗口停留样本。
   * @param {{process?:string, title?:string, dwellMin?:number}} sample
   */
  async function feed(sample = {}) {
    const category = classifyWindow(sample.process, sample.title)
    const dwellMin = Number.isFinite(sample.dwellMin) ? Math.max(0, sample.dwellMin) : 0
    record({ kind: 'window', window: String(sample.title || '').slice(0, 60), process: String(sample.process || '').slice(0, 40), category, dwellMin })

    let reminded = false
    let recovered = false
    const wasOverCap = st.consecutiveMin >= capMin && st.lastCategory === 'entertainment'

    if (category === 'entertainment') {
      st.consecutiveMin += dwellMin
      st.workConsecutiveMin = 0
      if (st.consecutiveMin >= capMin && now() - st.lastReminderAt.walk >= cooldownMs) {
        await fireReminder('walk', { consecutiveMin: st.consecutiveMin, capMin })
        reminded = true
      }
    } else if (category === 'work') {
      st.workConsecutiveMin += dwellMin
      st.consecutiveMin = 0 // 工作清零连续娱乐
      if (st.workConsecutiveMin >= restCapMin && now() - st.lastReminderAt.rest >= cooldownMs) {
        await fireReminder('rest', { consecutiveMin: st.workConsecutiveMin, capMin: restCapMin })
        reminded = true
      }
    } else {
      st.consecutiveMin = 0
      st.workConsecutiveMin = 0
    }
    // 恢复：此前在超阈娱乐中、现在离开娱乐 → 记一次恢复
    if (wasOverCap && category !== 'entertainment') {
      st.recoveries += 1
      recovered = true
      record({ kind: 'recovery', previousConsecutiveMin: st.consecutiveMin })
    }
    st.lastCategory = category
    persist()
    return { category, reminded, recovered, consecutiveMin: st.consecutiveMin, remindType: reminded ? (category === 'work' ? 'rest' : 'walk') : null }
  }

  /** A2：番茄钟完成（25 分钟专注块）→ pomodoro 档提醒（正向事件，建议休息收尾）。 */
  async function pomodoroComplete(focusMin = 25) {
    const type = 'pomodoro'
    const { message, templateId } = pickTemplate(type)
    st.lastReminderAt[type] = now()
    st.reminders += 1
    record({ kind: 'reminder', level: type, templateId, message, focusMin })
    if (typeof opts.remind === 'function') {
      try { await opts.remind({ type, level: type, templateId, focusMin, message }) } catch { /* 出口失败不影响记账 */ }
    }
    persist()
    return { type, reminded: true, templateId, message }
  }

  function state() { return { ...st, capMin, restCapMin, cooldownMs } }
  return { feed, pomodoroComplete, state, classifyWindow, HEALTH_TEMPLATES, templates: () => JSON.parse(JSON.stringify(templates)), _healthFile: healthFile }
}

export default { HEALTH_DEFAULTS, RULES, classifyWindow, createHealthLedger }
