// packages/plugins/coach/one-click.mjs
//
// S42·A1 一键成结论：应用内按钮「一键成结论」——renderer→IPC→main 调本服务；全程无 CDP、无 UI 自动化。
// 流程（5 步状态条）：取回复 → 建 claim（session）→ 挂证据（无则 evidenceMode:none 并提示）→ publish → 导出 md+docx。
// 纪律（红线）：
//   · 复用既有 registry claim 命令（timeline 插件），不新写业务。
//   · 任一步失败：明确哪步+原因；**不留半条 claim**——成功或回滚草稿（回滚只删本次自建的 draft）。
//   · 幂等：同一文本（sha256）已有成功产物 → 直接返回 existing，不重建。
//   · 每步审计（coach.jsonl one-click-*）。
import { createHash } from 'node:crypto'
import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { dataPath, safeWrite, appendJsonl, logPath } from '../../core/src/safefs.mjs'

const sha256 = (s) => createHash('sha256').update(String(s), 'utf8').digest('hex')

function audit(rec) {
  try { appendJsonl(logPath('coach.jsonl'), { ts: new Date().toISOString(), kind: 'one-click-' + rec.step, ...rec }) } catch { /* 尽力 */ }
}

function readMap() {
  try {
    const f = dataPath('coach', 'oneclick-map.json')
    return existsSync(f) ? JSON.parse(readFileSync(f, 'utf8')) : {}
  } catch { return {} }
}

function writeMap(map) {
  mkdirSync(dataPath('coach'), { recursive: true })
  safeWrite(dataPath('coach', 'oneclick-map.json'), JSON.stringify(map, null, 2), 'utf8')
}

/**
 * 一键成结论（服务函数，宿主 IPC 直调）。
 * @param {{lastAssistantText:string, evidence?:{dois?:string[], frames?:string[]}, registry?:object}} input
 * @returns {{ok:boolean, steps:Array<{step:number,name:string,ok:boolean,detail:string}>, claimId?:string, md?:string, docx?:string, already?:boolean, downgrade?:string}}
 */
export async function runOneClickClaim(input = {}) {
  const text = String(input.lastAssistantText || '').trim()
  const steps = []
  const step = (n, name, ok, detail) => { steps.push({ step: n, name, ok, detail: String(detail).slice(0, 200) }); audit({ step: n, name, ok, detail: String(detail).slice(0, 120) }) }
  const fail = (why) => ({ ok: false, steps, error: why })

  if (!text) {
    step(1, '取最后一条助手回复', false, '没有可用的助手回复')
    return fail('E_NO_REPLY')
  }
  const textSha = sha256(text)
  const map = readMap()
  if (map[textSha] && map[textSha].claimId) {
    const prev = map[textSha]
    if (existsSync(prev.md || '')) {
      step(1, '取最后一条助手回复', true, '幂等命中（同文本已建成结论）')
      return { ok: true, already: true, claimId: prev.claimId, md: prev.md, docx: prev.docx, steps }
    }
  }

  const reg = input.registry || globalThis.__researchRegistry || null
  if (!reg || typeof reg.runCommand !== 'function') {
    step(1, '取最后一条助手回复', false, '插件注册表不可用（未注入）')
    return fail('E_NO_REGISTRY')
  }
  step(1, '取最后一条助手回复', true, `${text.length} 字`)

  // 证据判定：DOI/片段/截图帧 任一 → direct；否则 none（降级提示）
  const ev = input.evidence || {}
  const dois = Array.isArray(ev.dois) ? ev.dois.filter(Boolean) : []
  const frames = Array.isArray(ev.frames) ? ev.frames.filter(Boolean) : []
  const hasEvidence = dois.length + frames.length > 0

  // step2：建 claim（session，正文即回复原文；证据随后 attach —— timeline 会自动升级 evidence_mode）
  let claimId = null
  try {
    const created = await reg.runCommand('claim', `new session ${text.slice(0, 400)}`)
    claimId = created && created.value && created.value.ui && created.value.ui.claimId
    if (!claimId) throw new Error('命令未返回 claimId：' + JSON.stringify(created && created.value || {}).slice(0, 120))
    step(2, '创建结论草稿（session）', true, `claimId=${claimId}${hasEvidence ? '' : '（evidenceMode:none）'}`)
  } catch (e) {
    step(2, '创建结论草稿（session）', false, String((e && e.message) || e))
    return fail('E_CLAIM_NEW')
  }

  // step3：挂证据 → publish（none → 设计性阻断：回滚草稿 + 提示）
  try {
    if (!hasEvidence) {
      const pub = await reg.runCommand('claim', `publish ${claimId}`)
      const blocked = pub && pub.value && pub.value.ok === false
      step(3, '挂证据→发布', false, blocked
        ? `无直接证据（evidenceMode:none）→ 发布被证据闸阻断（${pub.value.code}）：已回滚草稿，不伪装成功`
        : '无直接证据：未发布')
      rollbackDraft(reg, claimId)
      audit({ step: 3, kind: 'one-click-rollback', claimId, why: 'no-evidence' })
      return { ok: false, steps, claimId, error: 'E_NONE_EVIDENCE', downgrade: '该回复没有可挂的证据（无 DOI/无截图片段）：按纪律不进正式结论，草稿已回滚。先截图取证再一键成结论。' }
    }
    await reg.runCommand('claim', `attach ${claimId} frame ${frames[0]}`)
    for (const f of frames.slice(1)) {
      await reg.runCommand('claim', `attach ${claimId} frame ${f}`)
    }
    const pub = await reg.runCommand('claim', `publish ${claimId}`)
    if (!(pub && pub.value && pub.value.ok)) {
      const code = (pub && pub.value && pub.value.code) || 'E_PUBLISH'
      step(3, '挂证据→发布', false, `发布被拒：${code} → 回滚草稿`)
      rollbackDraft(reg, claimId)
      audit({ step: 3, kind: 'one-click-rollback', claimId, why: code })
      return { ok: false, steps, claimId, error: code }
    }
    step(3, '挂证据→发布', true, `published，证据 ${pub.value.evidenceCount} 条`)
  } catch (e) {
    step(3, '挂证据→发布', false, String((e && e.message) || e))
    rollbackDraft(reg, claimId)
    return fail('E_PUBLISH')
  }

  // step4：导出 md+docx
  let md = null
  let docx = null
  try {
    const ex = await reg.runCommand('claim', `export ${claimId}`)
    const ui = ex && ex.value && ex.value.ui
    md = (ui && ui.md) || null
    docx = (ui && ui.docx) || null
    if (!md || !existsSync(md)) throw new Error('导出未产出 md')
    step(4, '导出 md+docx', true, `${md.split(/[\\/]/).pop()}${docx ? ' + docx' : '（docx 未产出：' + String(ui.docxError || '未知').slice(0, 60) + '）'}`)
  } catch (e) {
    step(4, '导出 md+docx', false, String((e && e.message) || e))
    return { ok: false, steps, claimId, error: 'E_EXPORT' }
  }

  // step5：登记幂等映射
  map[textSha] = { claimId, md, docx, exportedAt: new Date().toISOString() }
  writeMap(map)
  step(5, '完成（幂等登记）', true, `sha256=${textSha.slice(0, 12)}…`)
  return { ok: true, steps, claimId, md, docx }
}

/** 回滚：只删本次自建的 draft claim（有 evidence 引用行先摘除），不动任何已发布数据。 */
function rollbackDraft(reg, claimId) {
  try {
    const store = (globalThis.researchOrbLifecycle && globalThis.researchOrbLifecycle.store) || null
    if (store && store._db && claimId) {
      store._db.prepare('DELETE FROM claim_evidence WHERE claim_id = ?').run(claimId)
      store._db.prepare("DELETE FROM claim WHERE id = ? AND status = 'draft'").run(claimId)
    }
  } catch { /* 回滚尽力；失败已在 step 详情里如实报告 */ }
}

export default { runOneClickClaim }
