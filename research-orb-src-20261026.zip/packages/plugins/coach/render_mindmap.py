# render_mindmap.py -- S37·B 思维导图 PNG renderer (Pillow only, zero new deps).
#
# Input : argv[1] = path to a UTF-8 JSON payload:
#   {
#     "out": "<abs path>.png",
#     "title": "研究思维导图：…",
#     "sources": "来源：memory 3 条 / blueprint 4 步 / trajectory 2 条 · 2026-10-23 · v0.7.0",
#     "contentHash": "sha256…",            # 记入 sidecar，供幂等校验
#     "root": "两周内完成微电网综述…",
#     "themes": [ {"title": "…（来源）", "source": "blueprint",
#                  "leaves": [ {"text": "…", "source": "memory"} ] } ]
#   }
# Output: writes the PNG at payload["out"] and a sibling "<out>.drawn.json"
#   recording what was actually drawn (canvas / themes / leaves / sources line /
#   contentHash / fonts) so tests can verify in-image content without eyeballing.
#
# Discipline: Chinese text via system msyh.ttc (fallback simhei.ttf); root/theme
# fonts >= 24/22px on the 1600x1000 canvas; source annotation >= 18px drawn
# INSIDE the image bottom; no network; no absolute paths inside the image.

import json
import os
import sys

from PIL import Image, ImageDraw, ImageFont

FONT_CANDIDATES = [
    "C:/Windows/Fonts/msyh.ttc",
    "C:/Windows/Fonts/simhei.ttf",
]

W, H = 1600, 1000
SOURCE_COLORS = {
    "memory": "#0f766e",
    "blueprint": "#b45309",
    "trajectory": "#1d4ed8",
    "goal": "#6d28d9",
}


def emit_fatal(reason):
    sys.stderr.write(reason + "\n")
    sys.exit(1)


def load_font(size):
    for p in FONT_CANDIDATES:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                continue
    return ImageFont.load_default()


def wrap(draw, text, font, max_w):
    lines, cur = [], ""
    for ch in text:
        if draw.textlength(cur + ch, font=font) > max_w and cur:
            lines.append(cur)
            cur = ch
        else:
            cur += ch
    if cur:
        lines.append(cur)
    return lines[:3]  # 每叶最多 3 行，防溢出画布


def main():
    if len(sys.argv) < 2:
        emit_fatal("render_mindmap.py: 缺少 payload 路径参数")
    payload_path = sys.argv[1]
    try:
        with open(payload_path, "r", encoding="utf-8") as f:
            p = json.load(f)
    except Exception as e:
        emit_fatal("render_mindmap.py: payload 不可读: %s" % e)

    out = p.get("out")
    if not out:
        emit_fatal("render_mindmap.py: payload 缺 out")
    themes = p.get("themes") or []
    if not themes:
        emit_fatal("render_mindmap.py: themes 为空（无内容可画——拒绝编数据）")

    img = Image.new("RGB", (W, H), "#f8fafc")
    draw = ImageDraw.Draw(img)
    f_title = load_font(30)
    f_root = load_font(26)
    f_theme = load_font(22)
    f_leaf = load_font(19)
    f_note = load_font(18)

    # 标题
    draw.text((40, 26), p.get("title", "研究思维导图"), fill="#0f172a", font=f_title)

    # 根节点（L1 目标）：左侧竖排大框
    root_text = str(p.get("root") or "（未设目标）")
    rx, ry, rw, rh = 40, 110, 300, 160
    draw.rounded_rectangle([rx, ry, rx + rw, ry + rh], radius=14, fill="#ede9fe", outline=SOURCE_COLORS.get("goal", "#6d28d9"), width=3)
    ty = ry + 14
    for line in wrap(draw, root_text, f_root, rw - 24):
        draw.text((rx + 12, ty), line, fill="#312e81", font=f_root)
        ty += 34

    # L2 主题列 + L3 叶子
    n = len(themes)
    col_w = (W - 80 - rw - 40) / max(1, n)
    x0 = rx + rw + 40
    leaf_total = 0
    for i, th in enumerate(themes):
        cx = x0 + i * col_w
        cy = 100 + (i % 2) * 30
        color = SOURCE_COLORS.get(th.get("source", ""), "#334155")
        draw.rounded_rectangle([cx, cy, cx + col_w - 28, cy + 56], radius=10, fill="#ffffff", outline=color, width=3)
        tyy = cy + 8
        for line in wrap(draw, str(th.get("title", "")), f_theme, col_w - 48):
            draw.text((cx + 12, tyy), line, fill="#0f172a", font=f_theme)
            tyy += 30
        # 根 → 主题连线
        draw.line([(rx + rw, ry + rh / 2), (cx, cy + 28)], fill=color, width=3)
        # L3 叶子
        ly = cy + 80
        for leaf in (th.get("leaves") or [])[:8]:
            lc = SOURCE_COLORS.get(leaf.get("source", ""), "#475569")
            for line in wrap(draw, "· " + str(leaf.get("text", "")), f_leaf, col_w - 66):
                draw.line([(cx + 24, ly + 11), (cx + 38, ly + 11)], fill=lc, width=2)
                draw.text((cx + 46, ly), line, fill="#334155", font=f_leaf)
                ly += 26
            ly += 8
            leaf_total += 1

    # 来源标注：画在图内底部（红线要求）
    src_line = str(p.get("sources") or "")
    draw.rectangle([0, H - 64, W, H], fill="#e2e8f0")
    draw.text((40, H - 50), src_line, fill="#475569", font=f_note)

    img.save(out, "PNG")

    sidecar = out + ".drawn.json"
    with open(sidecar, "w", encoding="utf-8") as f:
        json.dump({
            "canvas": {"width": W, "height": H},
            "themes": [{"title": t.get("title"), "source": t.get("source"), "leaves": len(t.get("leaves") or [])} for t in themes],
            "leafTotal": leaf_total,
            "sourcesLine": src_line,
            "root": root_text,
            "contentHash": p.get("contentHash"),
            "fonts": [FONT_CANDIDATES[0] if os.path.exists(FONT_CANDIDATES[0]) else "default"],
        }, f, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
