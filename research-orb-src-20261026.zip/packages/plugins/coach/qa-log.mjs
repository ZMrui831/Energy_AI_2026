// packages/plugins/coach/qa-log.mjs
//
// S37·A 问答入笔记（C 项）：runTurn 后把"值得留痕的问答"写入 data\coach\qa.jsonl。
// 纪律（红线）：
//   · 独立类型：source='qa'，**不写 claim、不挂证据闸、不标 published**；引用只记 evidenceIds（弱引用，可为空）。
//   · 写入时机：runTurn 成功后调用；仅当用户问题非寒暄/非纯回执（复用写侧噪声过滤的寒暄/回执闸；
//     注意问答条目本身允许是问句——与长期记忆的事实闸不同，这里问句正是要留痕的内容）。
//   · 摘要：answerDigest 走 router summarize 档，≤200 字；router 失败 → **静默跳过**（不写半条、不抛）。
//   · 失败静默：本模块任何异常都不拖停宿主对话。
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { dataPath, appendJsonl, logPath } from '../../core/src/safefs.mjs'

export const QA_MAX_DIGEST = 200

const PLEASANTRY_RE = /^(你好|您好|hi|hello|嗨|谢谢|感谢|好的|收到|嗯|哦|ok|OK|在吗|早|晚安)[\s!！。.~～]*$/
const PURE_ACK_RE = /^(收到|好的|明白了|了解|知道了|行|可以|嗯嗯|赞|thanks|thx|got it)[\s!！。.~～]*$/i
const REQUEST_RE = /^(帮我|请帮我|帮我做|替我|麻烦你)[\s\S]{0,4}(打开|删除|写入|发送|执行|运行)/

function audit(rec) {
  try { appendJsonl(logPath('coach.jsonl'), { ts: new Date().toISOString(), ...rec }) } catch { /* 尽力 */ }
}

/** 问答准入闸：寒暄/纯回执/工具型请求不入库（问句本身允许——这正是要留痕的内容）。 */
export function isQaWorthy(text) {
  const t = String(text || '').trim()
  if (!t || t.length < 4) return false
  if (PLEASANTRY_RE.test(t)) return false
  if (PURE_ACK_RE.test(t)) return false
  if (REQUEST_RE.test(t)) return false
  return true
}

/**
 * runTurn 后调用：写一条问答留痕。
 * @param {{question:string, answer:string, sessionId?:string, evidenceIds?:string[], router?:object, dir?:string}} input
 * @returns {{ok:boolean, written:boolean, skipped?:string, id?:string}}
 */
export async function appendQaTurn(input = {}) {
  try {
    const question = String(input.question || '').trim()
    const answer = String(input.answer || '')
    if (!isQaWorthy(question)) return { ok: true, written: false, skipped: 'not-qa-worthy' }
    if (!answer.trim()) return { ok: true, written: false, skipped: 'empty-answer' }
    const router = input.router || null
    if (!router) return { ok: true, written: false, skipped: 'no-router' }
    // 摘要走 summarize 档（经 router）；失败 → 静默跳过（不写半条）
    let digest = ''
    try {
      const r = await router.run('summarize', {
        messages: [
          { role: 'system', content: '把这段回答压缩成一段 ≤120 字的中文摘要，保留关键结论与数字，不要客套。只输出摘要正文。' },
          { role: 'user', content: answer.slice(0, 2000) },
        ],
        maxTokens: 220,
      })
      if (r && r.ok && typeof r.text === 'string' && r.text.trim()) digest = r.text.trim()
    } catch { digest = '' }
    if (!digest) return { ok: true, written: false, skipped: 'digest-unavailable' }
    const row = {
      ts: new Date().toISOString(),
      question: question.slice(0, 300),
      answerDigest: digest.slice(0, QA_MAX_DIGEST),
      source: 'qa',
      sessionId: String(input.sessionId || '').slice(0, 60) || null,
      evidenceIds: Array.isArray(input.evidenceIds) ? input.evidenceIds.map(String).slice(0, 10) : [],
    }
    const dir = input.dir || dataPath('coach')
    appendJsonl(join(dir, 'qa.jsonl'), row)
    audit({ kind: 'qa-logged', chars: row.question.length, digestChars: row.answerDigest.length })
    return { ok: true, written: true, id: row.ts }
  } catch {
    return { ok: true, written: false, skipped: 'error' } // 失败静默（不拖停宿主）
  }
}

/** 读取 qa.jsonl（坏行跳过；返回按时间倒序）。 */
export function readQaLog(dir) {
  const f = join(dir || dataPath('coach'), 'qa.jsonl')
  if (!existsSync(f)) return []
  const rows = []
  for (const l of readFileSync(f, 'utf8').split('\n')) {
    const t = l.trim()
    if (!t) continue
    try {
      const r = JSON.parse(l)
      if (r && r.source === 'qa' && r.ts) rows.push(r)
    } catch { /* 坏行跳过 */ }
  }
  return rows.sort((a, b) => String(b.ts).localeCompare(String(a.ts)))
}

/** /coach qa list [--limit N]：时间戳 + 问题原文 + 摘要 ≤200。 */
export function listQa({ limit = 5, dir } = {}) {
  const rows = readQaLog(dir).slice(0, Math.max(1, Math.min(50, limit)))
  if (!rows.length) return { ok: true, text: '（暂无问答留痕）', rows: [] }
  const lines = rows.map((r, i) => `${i + 1}. [${r.ts}] 问：${r.question}\n   摘要：${String(r.answerDigest).slice(0, QA_MAX_DIGEST)}${r.evidenceIds && r.evidenceIds.length ? '（弱引用：' + r.evidenceIds.join(',') + '）' : ''}`)
  return { ok: true, text: `问答留痕 ${rows.length} 条：\n` + lines.join('\n'), rows }
}

/** /coach qa search <词>：问题或摘要命中即返回。 */
export function searchQa(word, { dir } = {}) {
  const q = String(word || '').trim().toLowerCase()
  if (!q) return { ok: false, code: 'E_USAGE', text: '用法：/coach qa search <关键词>' }
  const rows = readQaLog(dir).filter((r) => String(r.question).toLowerCase().includes(q) || String(r.answerDigest).toLowerCase().includes(q)).slice(0, 10)
  if (!rows.length) return { ok: true, text: `未命中「${word.slice(0, 30)}」`, rows: [] }
  const lines = rows.map((r) => `[${r.ts}] 问：${r.question}\n   摘要：${String(r.answerDigest).slice(0, QA_MAX_DIGEST)}`)
  return { ok: true, text: `命中 ${rows.length} 条：\n` + lines.join('\n'), rows }
}

export default { isQaWorthy, appendQaTurn, readQaLog, listQa, searchQa, QA_MAX_DIGEST }
