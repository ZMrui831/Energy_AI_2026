// packages/plugins/coach/weekly.mjs
//
// S32·1 周报聚合：近 7 天 → 轨迹条数 / 专注时长 / 娱乐时长 / 平均评分 + 3 条趋势判断，
// 落 data/coach/weekly-YYYY-Www.md，并调 chart-skill 出评分趋势图 data/artifacts/weekly-*.png。
//
// 纪律（红线）：
//   · 数字只来自真实文件（trajectory.jsonl / health.jsonl / daily/*.md），不硬编码、不臆造。
//   · 缺日不报错：某天无数据 → 该日轨迹 0、评分 null（图上留缺口，不连点）。
//   · 按周幂等：同一 ISO 周 + 内容未变 → 不重写（cached），避免重复刷盘。
//   · 无评分也不崩：仍产出周报，评分标注"无（本期无日报评分）"，趋势判断如实说明。
import { existsSync, mkdirSync, readFileSync, readdirSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, safeWrite, appendJsonl, logPath, dataPath } from '../../core/src/safefs.mjs'

export const WEEKLY_DAYS = 7
export const COACH_DIR = dataPath('coach')

const pad2 = (n) => String(n).padStart(2, '0')

function audit(rec) {
  try { appendJsonl(logPath('coach.jsonl'), { ts: new Date().toISOString(), ...rec }) } catch { /* 尽力 */ }
}

function readJsonl(file) {
  try {
    if (!existsSync(file)) return []
    return readFileSync(file, 'utf8').split('\n').filter((l) => l.trim()).map((l) => {
      try { return JSON.parse(l) } catch { return null }
    }).filter(Boolean)
  } catch { return [] }
}

/** 本地日期键 YYYY-MM-DD（与 daily.dayStamp 同口径：本地时区）。 */
export function localDayKey(ms) {
  const d = new Date(ms)
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`
}

/** ISO 周键 YYYY-Www（周四所在年/周，周一为一周之始）。 */
export function isoWeekKey(ms) {
  const d = new Date(ms)
  const t = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()))
  const day = t.getUTCDay() || 7 // 周日=0 → 7
  t.setUTCDate(t.getUTCDate() + 4 - day) // 移到本周周四
  const yearStart = new Date(Date.UTC(t.getUTCFullYear(), 0, 1))
  const week = Math.ceil(((t - yearStart) / 86400000 + 1) / 7)
  return `${t.getUTCFullYear()}-W${pad2(week)}`
}

/** 从 daily-YYYYMMDD.md 里读评分："- 评分：58 / 100" → 58；unavailable → null（缺日无文件 → 不返回）。 */
function readDailyScores(dailyDir) {
  const map = new Map() // YYYYMMDD -> number|null
  try {
    if (!existsSync(dailyDir)) return map
    for (const f of readdirSync(dailyDir)) {
      const m = f.match(/^daily-(\d{8})\.md$/)
      if (!m) continue
      let body = ''
      try { body = readFileSync(join(dailyDir, f), 'utf8') } catch { continue }
      const line = body.split('\n').find((l) => /-\s*评分[:：]/.test(l)) || ''
      const mm = line.match(/评分[:：]\s*(\d+)\s*\/\s*100/)
      map.set(m[1], mm ? Number(mm[1]) : null)
    }
  } catch { /* 读不到就当无评分 */ }
  return map
}

/** 3 条趋势判断（全部由真实逐日序列计算，不写死）。 */
export function buildTrends(days, totals) {
  const half = Math.floor(days.length / 2)
  const first = days.slice(0, half)
  const second = days.slice(half)
  const sum = (arr, f) => arr.reduce((a, d) => a + (Number(f(d)) || 0), 0)

  // ① 轨迹量：前半周 vs 后半周
  const t1 = sum(first, (d) => d.trajectory)
  const t2 = sum(second, (d) => d.trajectory)
  let trend1
  if (t1 === 0 && t2 === 0) trend1 = '近 7 天无轨迹记录（未跑流水线或感知未激活）'
  else if (t2 >= t1) trend1 = `轨迹量较前半周上升（${t1} → ${t2} 条，${t1 === 0 ? '新增' : '+' + Math.round(((t2 - t1) / t1) * 100) + '%'}）`
  else trend1 = `轨迹量较前半周下降（${t1} → ${t2} 条，${Math.round(((t2 - t1) / t1) * 100)}%）`

  // ② 评分：前半周 vs 后半周平均（只取有评分的天）
  const sc = (arr) => arr.map((d) => d.score).filter((x) => Number.isFinite(x))
  const s1 = sc(first)
  const s2 = sc(second)
  const a1 = s1.length ? Math.round(s1.reduce((a, b) => a + b, 0) / s1.length) : null
  const a2 = s2.length ? Math.round(s2.reduce((a, b) => a + b, 0) / s2.length) : null
  let trend2
  if (a1 == null && a2 == null) trend2 = '本期无日报评分数据，无法判断评分趋势（缺 score-plan 产出）'
  else if (a1 == null) trend2 = `后半周平均评分 ${a2}（前半周无评分数据）`
  else if (a2 == null) trend2 = `前半周平均评分 ${a1}（后半周无评分数据）`
  else if (a2 > a1) trend2 = `评分较前半周上升（${a1} → ${a2}，+${a2 - a1}）`
  else if (a2 < a1) trend2 = `评分较前半周下降（${a1} → ${a2}，${a2 - a1}）`
  else trend2 = `评分与前半周持平（${a1}）`

  // ③ 专注/娱乐比：整周健康账时长
  const f = totals.focusMin
  const e = totals.entertainmentMin
  const denom = f + e
  const trend3 = denom === 0
    ? '本期无健康账时长数据（专注/娱乐均 0 分钟，可能未开健康采样）'
    : `专注 ${f} 分钟 vs 娱乐 ${e} 分钟，专注占比 ${Math.round((f / denom) * 100)}%`

  return [trend1, trend2, trend3]
}

/**
 * 聚合近 7 天。
 * @param {{dir?:string, now?:number|(()=>number), days?:number}} opts
 */
export function aggregateWeek(opts = {}) {
  const dir = opts.dir || COACH_DIR
  const now = typeof opts.now === 'function' ? opts.now() : (Number.isFinite(opts.now) ? opts.now : Date.now())
  const span = Number.isFinite(opts.days) ? opts.days : WEEKLY_DAYS
  const trajectory = readJsonl(join(dir, 'trajectory.jsonl'))
  const health = readJsonl(join(dir, 'health.jsonl'))
  const scores = readDailyScores(join(dir, 'daily'))

  const days = []
  for (let i = span - 1; i >= 0; i--) {
    const ms = now - i * 86400000
    const key = localDayKey(ms)              // YYYY-MM-DD
    const compact = key.replace(/-/g, '')     // YYYYMMDD
    const trajCount = trajectory.filter((r) => r && r.ts && localDayKey(Date.parse(r.ts)) === key).length
    let focusMin = 0
    let entMin = 0
    for (const h of health) {
      if (!h || h.kind !== 'window' || !h.ts) continue
      if (localDayKey(Date.parse(h.ts)) !== key) continue
      const dm = Number(h.dwellMin) || 0
      if (h.category === 'work') focusMin += dm
      else if (h.category === 'entertainment') entMin += dm
    }
    days.push({ date: key, trajectory: trajCount, focusMin, entertainmentMin: entMin, score: scores.has(compact) ? scores.get(compact) : null })
  }

  const present = days.filter((d) => Number.isFinite(d.score)).map((d) => d.score)
  const avgScore = present.length ? Math.round(present.reduce((a, b) => a + b, 0) / present.length) : null
  const totals = {
    trajectory: days.reduce((a, d) => a + d.trajectory, 0),
    focusMin: days.reduce((a, d) => a + d.focusMin, 0),
    entertainmentMin: days.reduce((a, d) => a + d.entertainmentMin, 0),
    avgScore,
  }
  return {
    weekKey: isoWeekKey(now),
    start: days[0].date,
    end: days[days.length - 1].date,
    days,
    totals,
    trends: buildTrends(days, totals),
  }
}

/** 渲染周报 Markdown（含逐日表 + 3 条趋势）。 */
export function renderWeeklyMarkdown(agg) {
  const L = []
  L.push(`# 教练周报 ${agg.weekKey}`)
  L.push('')
  L.push(`> 统计窗口：近 7 天（${agg.start} 至 ${agg.end}）｜来源：data/coach/trajectory.jsonl + health.jsonl + daily/*.md｜research-orb`)
  L.push('')
  L.push('## 汇总')
  L.push(`- 轨迹条数：${agg.totals.trajectory}`)
  L.push(`- 专注时长：${agg.totals.focusMin} 分钟`)
  L.push(`- 娱乐时长：${agg.totals.entertainmentMin} 分钟`)
  L.push(`- 平均评分：${agg.totals.avgScore == null ? '无（本期无日报评分）' : agg.totals.avgScore + ' / 100'}`)
  L.push('')
  L.push('## 逐日')
  L.push('| 日期 | 轨迹 | 专注(min) | 娱乐(min) | 评分 |')
  L.push('| --- | --- | --- | --- | --- |')
  for (const d of agg.days) {
    L.push(`| ${d.date} | ${d.trajectory} | ${d.focusMin} | ${d.entertainmentMin} | ${d.score == null ? '—' : d.score} |`)
  }
  L.push('')
  L.push('## 3 条趋势判断')
  agg.trends.forEach((t, i) => L.push(`${i + 1}. ${t}`))
  L.push('')
  return L.join('\n')
}

/**
 * 写周报（按周幂等：同周同内容不重写）。
 * @returns {{path:string, md:string, agg:object, cached:boolean}}
 */
export function writeWeeklyReport(opts = {}) {
  const dir = opts.dir || COACH_DIR
  const emitAudit = typeof opts.auditFn === 'function' ? opts.auditFn : audit
  const agg = aggregateWeek(opts)
  const md = renderWeeklyMarkdown(agg)
  mkdirSync(dir, { recursive: true })
  const path = join(dir, `weekly-${agg.weekKey}.md`)
  let cached = false
  try {
    if (existsSync(path) && readFileSync(path, 'utf8') === md) cached = true
  } catch { /* 读不到就当需重写 */ }
  if (!cached) safeWrite(path, md, 'utf8')
  emitAudit({
    kind: 'weekly-report',
    week: agg.weekKey,
    trajectory: agg.totals.trajectory,
    focusMin: agg.totals.focusMin,
    entertainmentMin: agg.totals.entertainmentMin,
    avgScore: agg.totals.avgScore,
    cached,
  })
  return { path, md, agg, cached }
}

/** 出评分趋势图（调 chart-skill；懒加载避免 coach 冷启动就拉起 docx/pillow 链）。 */
export async function buildWeeklyTrendChart({ agg, outDir, now } = {}) {
  const mod = await import('../chart-skill/lib/weekly.mjs')
  return mod.buildWeeklyTrendArtifact({
    agg,
    outDir: outDir || dataPath('artifacts'),
    now: now ? new Date(now) : new Date(),
  })
}

export default { WEEKLY_DAYS, aggregateWeek, renderWeeklyMarkdown, writeWeeklyReport, buildWeeklyTrendChart, buildTrends, localDayKey, isoWeekKey }
