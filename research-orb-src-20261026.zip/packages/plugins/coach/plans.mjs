// packages/plugins/coach/plans.mjs
//
// S32·2 计划提醒执行闭环：日报建议可提升为计划项 → 调度器到期触发 → 提醒卡（同一计划只提醒一次）
// → /coach plans done <id> 勾销 → 完成/放弃入记忆并写审计。
//
// 存储：data/coach/plans.jsonl（append-only 事件流，折叠出每计划最新态）。
//   add   → {id,text,dueAt,status:'pending',createdAt,event:'add'}
//   done  → {id,status:'done',doneAt,event:'done'}
//   drop  → {id,status:'dropped',droppedAt,event:'drop'}
//   remind→ {id,event:'remind',ts}       （同一计划仅记录一次提醒，供"只提醒一次"跨重启保持）
//
// 纪律：纯逻辑可测（now/audit/memory 注入）；不碰感知阈值、不碰调度器冷却。
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, appendJsonl, logPath, dataPath } from '../../core/src/safefs.mjs'
import { saveMemory, markDone } from './memory.mjs'

export const PLANS_FILE_NAME = 'plans.jsonl'

export class PlanError extends Error {
  constructor(code, message) { super(message); this.name = 'PlanError'; this.code = code }
}

const defaultAudit = (rec) => {
  try { appendJsonl(logPath('coach.jsonl'), { ts: new Date().toISOString(), ...rec }) } catch { /* 尽力 */ }
}

function readRows(file) {
  try {
    if (!existsSync(file)) return []
    return readFileSync(file, 'utf8').split('\n').filter((l) => l.trim()).map((l) => {
      try { return JSON.parse(l) } catch { return null }
    }).filter(Boolean)
  } catch { return [] }
}

/** 折叠事件流 → 每计划最新态（Map<id, plan>）。 */
export function foldPlans(rows) {
  const m = new Map()
  for (const r of rows) {
    if (!r || !r.id) continue
    const cur = m.get(r.id) || { id: r.id, text: '', dueAt: null, status: 'pending', createdAt: null, reminded: false }
    if (r.text != null) cur.text = String(r.text)
    if (r.dueAt != null) cur.dueAt = r.dueAt
    if (r.createdAt != null) cur.createdAt = r.createdAt
    if (r.status != null) cur.status = r.status
    if (r.event === 'remind') cur.reminded = true
    if (r.event === 'add') cur.reminded = false
    m.set(r.id, cur)
  }
  return m
}

/**
 * @param {{dir?:string, now?:()=>number, audit?:(rec)=>void, memory?:{saveMemory,markDone}, rand?:()=>string}} opts
 */
export function createPlanStore(opts = {}) {
  const dir = opts.dir || dataPath('coach')
  const file = join(dir, PLANS_FILE_NAME)
  const now = opts.now || (() => Date.now())
  const audit = opts.audit || defaultAudit
  const memory = opts.memory || { saveMemory, markDone }
  const rand = opts.rand || (() => Math.random().toString(36).slice(2, 6))
  let seq = 0

  const rows = () => readRows(file)
  const all = () => [...foldPlans(rows()).values()]

  function add(input = {}) {
    const text = String(input.text || '').trim()
    if (!text) throw new PlanError('E_EMPTY_TEXT', '计划内容不能为空')
    const id = 'pl-' + now().toString(36) + '-' + (seq++) + rand()
    let dueAt = null
    if (input.dueAt != null && input.dueAt !== '') {
      const t = typeof input.dueAt === 'number' ? input.dueAt : Date.parse(input.dueAt)
      if (!Number.isFinite(t)) throw new PlanError('E_BAD_DUE', '到期时间无法解析：' + input.dueAt)
      dueAt = new Date(t).toISOString()
    }
    const rec = { id, text, dueAt, status: 'pending', createdAt: new Date(now()).toISOString(), event: 'add', source: input.source || 'manual' }
    appendJsonl(file, { ts: new Date(now()).toISOString(), ...rec })
    audit({ kind: 'plan-add', id, text, dueAt })
    return rec
  }

  function get(id) {
    const p = foldPlans(rows()).get(id)
    return p ? { ...p } : null
  }

  function list() { return all() }

  function done(id, note = '') {
    const p = get(id)
    if (!p) throw new PlanError('E_NO_PLAN', '计划不存在：' + id)
    if (p.status === 'done') return { id, status: 'done', already: true }
    appendJsonl(file, { ts: new Date(now()).toISOString(), id, status: 'done', doneAt: new Date(now()).toISOString(), event: 'done' })
    try {
      const r = memory.saveMemory({ title: `计划完成：${p.text}`, body: `计划 ${id} 已于 ${new Date(now()).toISOString()} 完成。${note}`.trim(), kind: 'plan', dir })
      if (r && r.file && typeof memory.markDone === 'function') memory.markDone(r.file, dir)
    } catch { /* 记忆镜像失败不影响计划状态 */ }
    audit({ kind: 'plan-done', id, text: p.text })
    return { id, status: 'done' }
  }

  function drop(id, note = '') {
    const p = get(id)
    if (!p) throw new PlanError('E_NO_PLAN', '计划不存在：' + id)
    if (p.status === 'dropped') return { id, status: 'dropped', already: true }
    appendJsonl(file, { ts: new Date(now()).toISOString(), id, status: 'dropped', droppedAt: new Date(now()).toISOString(), event: 'drop' })
    try {
      memory.saveMemory({ title: `计划已放弃：${p.text}`, body: `计划 ${id} 已放弃（${new Date(now()).toISOString()}）。${note}`.trim(), kind: 'plan', dir })
    } catch { /* 记忆镜像失败不影响计划状态 */ }
    audit({ kind: 'plan-dropped', id, text: p.text })
    return { id, status: 'dropped' }
  }

  /** 到期未完成、且尚未提醒过的计划。 */
  function duePlans(at = now()) {
    return all().filter((p) => p.status === 'pending' && p.dueAt && Date.parse(p.dueAt) <= at && !p.reminded)
  }

  /** 记录"已提醒"（同一计划只提醒一次，跨重启保持）。 */
  function markReminded(id) {
    appendJsonl(file, { ts: new Date(now()).toISOString(), id, event: 'remind' })
    return { id, reminded: true }
  }

  return { add, get, list, done, drop, duePlans, markReminded, file }
}

export default { PLANS_FILE_NAME, PlanError, createPlanStore, foldPlans }
