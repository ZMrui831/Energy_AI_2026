// packages/plugins/coach/daily.mjs
//
// S25·2C 教练每日流水线：调度触发 → 截图 → extract(2B) → summarize 归纳意图 →
// 轨迹账 trajectory.jsonl → score-plan（旗舰）评分与建议 → 日报 daily-YYYYMMDD.md。
//
// 纪律（红线）：
//   · 未同意感知不跑：consent 非 active → 跳过 + 审计 {kind:'skipped-no-consent', why}，绝不静默。
//   · 日报幂等：按 日期 + 轨迹内容哈希——同日同内容重复触发不重写；内容变化才更新。
//   · 可追溯：日报中每条轨迹带 evidence.frameId + textSha256，可回指 trajectory.jsonl 行。
//   · score-plan 失败 → 日报仍生成但 score: unavailable（不许静默造假分数）。
//   · 所有 LLM 经 router（summarize/score-plan 永远旗舰）；extract 复用 2B（原图处理后即删并审计）。
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, writeFileSync, rmSync, statSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, safeWrite, appendJsonl, logPath, dataPath } from '../../core/src/safefs.mjs'
import { autoSaveFromDaily } from './memory.mjs'
import { classifyLine } from '../longterm-memory/lines.mjs'
import { readWeights } from '../../core/src/settings.mjs'
import { archiveLine, instructionLine, dayDirName } from '../../core/src/session-rhythm.mjs'
export const COACH_DIR = dataPath('coach')
export const TRAJECTORY_FILE = join(COACH_DIR, 'trajectory.jsonl')
export const DAILY_DIR = join(COACH_DIR, 'daily')

export class DailyError extends Error {
  constructor(code, message) { super(message); this.name = 'DailyError'; this.code = code }
}

function sha256(s) { return createHash('sha256').update(String(s || ''), 'utf8').digest('hex') }

function audit(rec) {
  try { appendJsonl(logPath('coach.jsonl'), { ts: new Date().toISOString(), ...rec }) } catch { /* 尽力 */ }
}

function dayStamp(ts) {
  // S74·1-B：切日统一 **北京时间**（session-rhythm 同口径），不依赖机器本地时区
  return dayDirName(ts)
}

/** 解析 LLM 输出里的第一个 JSON 对象/数组（容忍 ```json 包裹）。 */
export function parseLooseJson(text) {
  const t = String(text || '').replace(/```json|```/g, '').trim()
  const m = t.match(/[[{][\s\S]*[\]}]/)
  if (!m) return null
  try { return JSON.parse(m[0]) } catch { return null }
}

/** 从 summarize 的归纳结果里取第 i 条 intent（越界/失败给诚实占位）。 */
export function intentAt(parsed, i) {
  if (Array.isArray(parsed)) {
    const it = parsed[i]
    if (typeof it === 'string' && it.trim()) return it.trim()
    if (it && typeof it.intent === 'string' && it.intent.trim()) return it.intent.trim()
  }
  if (parsed && typeof parsed === 'object' && Array.isArray(parsed.intents)) return intentAt(parsed.intents, i)
  return '未归纳（summarize 未产出该条意图）'
}

// ── S65·P0-1 双维分类（增量路径修复）────────────────────────────────────────
// 背景：增量抽取的轨迹只有 window/process="（增量抽取）"、intent=null → 关键词规则全落 null
// → 日报双维永远 n/a（主管实测：日报 35 分但 workScore/lifeScore 两行都是 n/a）。
// 修法：视觉抽取的结构化输出自带 intent 三值（extract prompt 口径：学习|工作|生活；主管口径：学习/娱乐/其他）
// → 直接映射记忆线；映射不到（或无结构化 intent）才沿用 longterm-memory 的关键词规则兜底。
// 'other'（明确"其他"）→ **不计数**，且不再兜底猜（不猜红线）；无法识别 → null（走兜底）。
export const INTENT_LINE_MAP = Object.freeze({
  学习: 'work',
  工作: 'work',
  娱乐: 'life',
  生活: 'life',
  其他: 'other',
})

/**
 * 三值 intent → 记忆线。
 * @returns {'work'|'life'|'other'|null} 'other'=明确不计数；null=识别不出（调用方应走关键词兜底）
 */
export function intentLine(intent = '') {
  const s = String(intent || '').trim()
  if (!s) return null
  for (const k of Object.keys(INTENT_LINE_MAP)) if (s.includes(k)) return INTENT_LINE_MAP[k]
  return null
}

/**
 * 单条轨迹的记忆线：结构化 intent（视觉抽取三值）→ 归纳 intent → 关键词规则兜底。
 * 无法归类返回 null（不猜，不计入任何一维）。
 */
export function trackLine(t = {}) {
  for (const src of [t.structuredIntent, t.intent]) {
    const m = intentLine(src)
    if (m === 'work' || m === 'life') return m
    if (m === 'other') return null // 明确"其他"：不计数，不再兜底
  }
  const c = classifyLine(`${t.window || ''} ${t.process || ''} ${t.intent || ''}`)
  return c || null
}

/**
 * @param {{
 *   dir?: string,                  // 状态目录（默认 data\coach；trajectory/daily/state 落这里）
 *   router: object,                // createRouter 实例（summarize/score-plan 档）
 *   extractor: object,             // 2B createExtractor 实例（原图处理后即删并审计）
 *   now?: () => number,
 * }} opts
 */
export function createDailyPipeline(opts = {}) {
  const dir = opts.dir || COACH_DIR
  const dailyDir = join(dir, 'daily')
  const trajectoryFile = join(dir, 'trajectory.jsonl')
  const stateFile = join(dir, 'daily-state.json')
  // S61·P0-2 方案A：帧增量抽取的暂存账（增量轮只入账不归纳；日报轮合并后清空）
  const incrementalFile = join(dir, 'incremental.jsonl')
  // S69·1A：评分留痕（每次运行追加一行，供日报「评分变动」与口径自洽）
  const scoreHistoryFile = join(dir, 'score-history.jsonl')
  const readScoreHistory = () => {
    try { return readFileSync(scoreHistoryFile, 'utf8').split('\n').filter((l) => l.trim()).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean) } catch { return [] }
  }
  const now = opts.now || (() => Date.now())
  if (!opts.router) throw new DailyError('E_NO_ROUTER', 'daily: 需要注入 router')
  if (!opts.extractor) throw new DailyError('E_NO_EXTRACTOR', 'daily: 需要注入 extractor（2B）')
  const router = opts.router
  const extractor = opts.extractor

  function readTrajectory() {
    try {
      if (!existsSync(trajectoryFile)) return []
      return readFileSync(trajectoryFile, 'utf8').split('\n').filter((l) => l.trim()).map((l) => JSON.parse(l))
    } catch { return [] }
  }

  /** 读取增量暂存账（**不删**；删除延迟到轨迹落盘后，防 extract 失败丢数据——S63 实测教训）。 */
  function drainIncremental() {
    try {
      if (!existsSync(incrementalFile)) return []
      return readFileSync(incrementalFile, 'utf8').split('\n').filter((l) => l.trim()).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
    } catch { return [] }
  }

  /** 增量暂存账清空（在轨迹 append 之后调用）。 */
  function clearIncremental() {
    try { rmSync(incrementalFile, { force: true }) } catch { /* 清不掉下轮会重复合并，可容忍（evidenceKey 去重兜底） */ }
  }

  /**
   * 跑一次每日流水线。
   * @param {{consentActive:boolean, frames:Array<{imagePath,window,process}>, goal?:string}} input
   * @returns {Promise<{ok:boolean, skipped?:boolean, reason?:string, cached?:boolean, date?:string,
   *                     trajectoryCount?:number, score?:any, reportPath?:string, summary?:object}>}
   */
  async function run(input = {}) {
    const { consentActive = false, frames = [], goal = '' } = input
    if (!consentActive) {
      audit({ kind: 'skipped-no-consent', why: 'coach-daily', frames: frames.length })
      return { ok: false, skipped: true, reason: '感知同意未激活：未跑流水线（已留审计 skipped-no-consent）' }
    }
    if (!frames.length) {
      audit({ kind: 'skipped-no-frames', why: 'coach-daily' })
      return { ok: false, skipped: true, reason: '无截图帧：未跑流水线' }
    }

    // ① extract（2B：原图处理后即删并审计；同内容副本走缓存并被移入 trash）
    // S61·P0-2 方案A：增量轮（每 5 分钟）已抽取入账的行先合并进来（文本已在，不重复送模），
    // 随后统一走既有去重 → summarize 归纳 → 轨迹入账 → 评分/日报。
    const drainedRows = drainIncremental()
    const tracks = []
    // S71·P0-1：占位串不入账——应用名取 structured.app，其次 text 前 20 字，禁止（增量抽取）等占位
    const _PH = /（增量抽取）|（命令触发）|（手动捕获）|（自动捕获）/
    const pickName = (rec, field, max) => {
      const a = rec && rec.structured && rec.structured.app ? String(rec.structured.app) : ''
      const v = rec && rec[field] ? String(rec[field]) : ''
      if (v && !_PH.test(v)) return v.slice(0, max)
      if (a && !_PH.test(a)) return a.slice(0, max)
      const t = String((rec && rec.text) || '').replace(/\s+/g, ' ').trim()
      return (t ? t.slice(0, 20) : '（未知）').slice(0, max)
    }
    for (const inc of drainedRows) {
      tracks.push({
        ts: String(inc.ts || new Date(now()).toISOString()),
        window: pickName(inc, 'window', 60),
        process: pickName(inc, 'process', 40),
        intent: null,
        // S65·P0-1：带上视觉抽取的结构化 intent（学习/工作/生活/其他）→ 双维分类不再只能靠关键词兜底
        structuredIntent: inc.structured && inc.structured.intent ? String(inc.structured.intent).slice(0, 20) : '',
        level: 'direct',
        evidence: { frameId: inc.frameId, textSha256: inc.textSha256 },
        __text: String(inc.text || ''),
        __cached: true,
        // S69·1B：增量行继承其**触发来源**（命令触发的抽帧记为 command → 不入轨迹）；extract 的 source 另有其字段
        __source: String(inc.triggerSource || 'perception'),
      })
    }
    try {
      for (const f of frames) {
        // S69·1B：真实抓帧（source=perception/command）<1024 字节 → 不送模（审计 skipped-empty-frame）；
        // 测试夹具（无 source）不设此门，避免误伤合成小图。
        if (f && (f.source === 'perception' || f.source === 'command')) {
          try {
            const sz = statSync(f.imagePath).size
            if (sz < 1024) { audit({ kind: 'skipped-empty-frame', bytes: sz, frameId: f.frameId || ('bytes-' + sz) }); continue }
          } catch { /* 读不到交给 extract 报错 */ }
        }
        const r = await extractor.extract({ imagePath: f.imagePath })
        // S69·1B：失败帧不入账
        if (!r || r.ok === false) continue
        // S71·2B：识别为 orb 自身面板（intent.line='self'）→ 不入轨迹
        if (r.structured && (r.structured.self === true || (r.structured.layers && r.structured.layers.intent && r.structured.layers.intent.line === 'self'))) continue
        tracks.push({
          ts: new Date(now()).toISOString(),
          window: String(f.window || '').slice(0, 60) || '(未知窗口)',
          process: String(f.process || '').slice(0, 40) || '(未知进程)',
          intent: null,
          // S65·P0-1：本轮抓帧同样保留结构化 intent（与增量行同口径）
          structuredIntent: r.structured && r.structured.intent ? String(r.structured.intent).slice(0, 20) : '',
          level: 'direct',
          evidence: { frameId: r.frameId, textSha256: r.textSha256 },
          __text: r.text,
          __cached: r.cached === true,
          // S69·1B：帧来源（命令触发的工具帧不入轨迹）
          __source: String((f && f.source) || 'perception'),
        })
      }
    } catch (e) {
      // B2：extract 超时（45s）→ 本轮中止，绝不写半条轨迹（要害：超时即丢帧，不落盘）
      if (e && e.code === 'E_EXTRACT_TIMEOUT') {
        audit({ kind: 'daily-extract-timeout', why: 'coach-daily', frames: frames.length })
        return { ok: false, skipped: true, aborted: true, reason: 'extract 超时 45s：本轮中止，未写半条轨迹（已留审计 extract-timeout）' }
      }
      throw e
    }

    // ② 幂等判定：当日「去重证据集」哈希（排除 ts；同内容重复观测不触发重写/LLM）
    const today = dayStamp(now())
    const evidenceKey = (t) => `${t.evidence.frameId}|${t.evidence.textSha256}`
    // S69·1B：source:'command' 的帧只作审计（工具帧），不写 trajectory
    for (const t of tracks) { if (!t.line) t.line = trackLine(t) } // 提前落线标签（trackLine 以结构化 intent 为主，不依赖 LLM 归纳）
    const toolTracks = tracks.filter((t) => t.__source === 'command')
    const realTracks = tracks.filter((t) => t.__source !== 'command')
    // S74·1-B ⑦：归档行（archive:true / 非今日北京时间）**绝不**进当日实时上下文与评分基数。
    const allRows = readTrajectory()
    const archivedRows = allRows.filter((t) => t.archive === true || dayStamp(Date.parse(t.ts)) !== today)
    const existing = allRows.filter((t) => t.archive !== true && dayStamp(Date.parse(t.ts)) === today)
    const seen = new Set(existing.map(evidenceKey))
    const newTracks = realTracks.filter((t) => !seen.has(evidenceKey(t)))
    const state = (() => { try { return existsSync(stateFile) ? JSON.parse(readFileSync(stateFile, 'utf8')) : {} } catch { return {} } })()
    const reportPath = join(dailyDir, `daily-${today}.md`)
    const mergedKeys = [...new Set([...existing.map(evidenceKey), ...newTracks.map(evidenceKey)])].sort()
    const contentHash = sha256(JSON.stringify(mergedKeys))

    const allToday = [...existing, ...newTracks]
    const weights = readWeights((() => { try { return JSON.parse(readFileSync(dataPath('config.json'), 'utf8')) } catch { return null } })())
    // 行内 line 为准；老行没有 line 字段 → 现算（同规则，向后兼容）
    const lineOfRow = (t) => (t.line === 'work' || t.line === 'life' ? t.line : ('line' in t ? null : trackLine(t)))
    const dims = { work: 0, life: 0, unknown: 0 }
    for (const t of allToday) { const c = lineOfRow(t); if (c) dims[c] += 1; else dims.unknown += 1 }
    const effective = allToday.filter((t) => { const c = lineOfRow(t); return c === 'work' || c === 'life' })
    const effectiveCount = effective.length // = dims.work + dims.life（口径自洽断言）
    const cached = newTracks.length === 0 && state.date === today && state.contentHash === contentHash && existsSync(reportPath)

    let score = cached ? state.score : 'unavailable'
    let advice = []
    let scoreNote = ''

    if (!cached) {
      // ③ summarize 档归纳意图（只归纳新轨迹；失败 → 逐条诚实标注，不造假）
      let parsed = null
      try {
        const r = await router.run('summarize', {
          messages: [
            { role: 'system', content: '你是科研教练。根据每条屏幕文字转录，归纳用户当时在做什么（研究意图）。只输出 JSON 数组：["意图1","意图2",...]，条数与输入一致。' },
            { role: 'user', content: JSON.stringify(newTracks.map((t, i) => ({ i, process: t.process, text: String(t.__text).slice(0, 300) })), null, 0) },
          ],
          maxTokens: 500,
        })
        if (r.ok) parsed = parseLooseJson(r.text)
      } catch { /* 走诚实占位 */ }
      for (let i = 0; i < newTracks.length; i++) newTracks[i].intent = intentAt(parsed, i)
      for (const t of tracks) { delete t.__text; delete t.__cached; delete t.__source }

      // ④ 轨迹账（只追加新证据的真实轨迹；命令帧不入账）
      for (const t of newTracks) { try { appendJsonl(trajectoryFile, t) } catch { /* 尽力 */ } }
      // S63：轨迹落盘成功后才清增量暂存账（防 extract/归纳失败丢增量数据）
      if (drainedRows.length > 0 && newTracks.length > 0) clearIncremental()

      // ⑤ score-plan（旗舰）：评分基数 = 当日全部有效轨迹（effective）；失败 → unavailable
      try {
        const r = await router.run('score-plan', {
          messages: [
            { role: 'system', content: '你是科研教练。根据用户目标与今日研究轨迹，给出今日投入评分（0–100 整数）与明日 1–3 条具体建议。只输出 JSON：{"score":82,"advice":["...","..."]}' },
            { role: 'user', content: JSON.stringify({ goal, trajectoryCount: effectiveCount, trajectory: effective.map((t) => ({ intent: t.intent, process: t.process, line: lineOfRow(t) })) }, null, 0) },
          ],
          maxTokens: 400,
        })
        const p = r.ok ? parseLooseJson(r.text) : null
        if (p && Number.isFinite(Number(p.score))) {
          score = Number(p.score)
          advice = Array.isArray(p.advice) ? p.advice.map((a) => String(a).slice(0, 120)).slice(0, 3) : []
        } else {
          scoreNote = r.ok ? 'score-plan 输出无法解析（旗舰返回非 JSON）' : `score-plan 调用失败：${(r.error && r.error.code) || 'E_INVOKE'} ${(r.error && r.error.message) || '未知原因'}`
        }
      } catch (e) {
        scoreNote = `score-plan 调用失败：E_THROWN ${String((e && e.message) || e).slice(0, 120)}`
      }
    }

    // ⑥ scoreHistory（每次运行追加一行，含 cached）——口径自洽：trajectoryCount = work+life 行数
    const scoreVal = score === 'unavailable' ? 'unavailable' : score
    appendJsonl(scoreHistoryFile, { ts: new Date(now()).toISOString(), score: scoreVal, trajectoryCount: effectiveCount, workCount: dims.work, lifeCount: dims.life, reason: cached ? 'cached' : 'run', cached })
    const shLast3 = readScoreHistory().slice(-3)
    const hhmm = (iso) => { const d = new Date(iso); const p2 = (n) => String(n).padStart(2, '0'); return `${p2(d.getHours())}:${p2(d.getMinutes())}` }
    const scoreChange = shLast3.map((s) => `${hhmm(s.ts)} ${s.score} 分（${s.trajectoryCount} 条）${s.cached ? '（缓存）' : ''}`).join(' ← ') || '（无）'

    if (cached) {
      // 幂等：内容未变 → 不重写日报（保留 mtime），只追加审计与 scoreHistory
      audit({ kind: 'daily-report', date: today, trajectoryCount: effectiveCount, score: scoreVal, cached: true })
      return { ok: true, cached: true, date: today, trajectoryCount: effectiveCount, trajectoryTotal: allToday.length, score, reportPath, workScore: dims.work || 'n/a', lifeScore: dims.life || 'n/a', dims, toolFrames: toolTracks.length, archiveReference: archivedRows.length }
    }

    // ⑦ 双维投入（work/life 加权）
    const classifiedCount = effectiveCount
    let workScore = 'n/a'
    let lifeScore = 'n/a'
    let dualTotal = 'n/a'
    let singleDim = null
    if (classifiedCount > 0 && dims.work > 0 && dims.life > 0) {
      workScore = dims.work
      lifeScore = dims.life
      dualTotal = Math.round(100 * (dims.work * weights.work + dims.life * weights.life) / classifiedCount)
    } else if (dims.work > 0) {
      workScore = dims.work
      singleDim = 'work'
      dualTotal = Math.round(100 * dims.work / classifiedCount)
    } else if (dims.life > 0) {
      lifeScore = dims.life
      singleDim = 'life'
      dualTotal = Math.round(100 * dims.life / classifiedCount)
    }
    const dualLines = [
      '## 双维投入（work/life 加权）',
      '',
      `- workScore：${workScore}${typeof workScore === 'number' ? ' 条（工作/科研线）' : '（今日无 work 维轨迹）'}`,
      `- lifeScore：${lifeScore}${typeof lifeScore === 'number' ? ' 条（生活/娱乐线）' : '（今日无 life 维轨迹）'}`,
      `- total：${dualTotal} / 100（权重 work ${weights.work} / life ${weights.life}${weights.confirmed ? '，已确认' : '，**待用户确认**'}）${singleDim ? `｜单维：${singleDim}（另一维今日 n/a，只按本维归一）` : ''}`,
      `- 未归类：${dims.unknown} 条（三值 intent 判为"其他"或关键词规则无法归类——不猜，不计入任何一维）`,
      '',
    ]

    const lines = [
      `# 教练日报 ${today}`,
      '',
      `- 评分：${scoreVal === 'unavailable' ? 'unavailable（' + (scoreNote || 'score-plan 未产出') + '）' : scoreVal + ' / 100（score-plan · 旗舰 LLM）'}`,
      `- 轨迹：当日累计 ${allToday.length} 条（有效 work/life ${effectiveCount} 条；本轮新增 ${newTracks.length} 条；全部可回指 trajectory.jsonl）`,
      `（本轮工具触发帧 ${toolTracks.length} 条，未计入轨迹）`,
      `- 蓝图联动：建议经人确认后可 /coach blueprint edit 更新`,
      // S70·2A：归档与指令两行（北京时间切日）
      // S74·1-B ⑦：归档只作 **archive_reference**（提及，不计入当日评分基数）——
      //   日报正文带归档行数供追溯；scoring 基数 = allToday（已剔除 archivedRows）。
      `- archive_reference：${archivedRows.length} 条归档/非今日轨迹（不参与当日评分基数）｜ ${archiveLine(dataPath('sessions'), now()).replace(/^- 归档：/, '')}`,
      instructionLine(dataPath('sessions'), now()),
      '',
      ...dualLines,
      '## 评分变动（最近 3 次）',
      '',
      scoreChange,
      '',
      '## 轨迹摘要（每条可回指）',
      '',
      '| ts | 窗口 | 进程 | 归纳意图 | 线 | level | frameId | textSha256 |',
      '| --- | --- | --- | --- | --- | --- | --- | --- |',
      ...allToday.map((t) => `| ${t.ts} | ${t.window} | ${t.process} | ${t.intent} | ${lineOfRow(t) || '—'} | ${t.level} | ${t.evidence.frameId} | ${String(t.evidence.textSha256).slice(0, 16)}… |`),
      '',
      '## 明日建议',
      '',
      ...(advice.length ? advice.map((a, i) => `${i + 1}. ${a}`) : ['（score-plan 未产出建议——见评分行说明）']),
      '',
    ]
    mkdirSync(dailyDir, { recursive: true })
    safeWrite(reportPath, lines.join('\n'), 'utf8')
    safeWrite(stateFile, JSON.stringify({ date: today, contentHash, score: scoreVal, trajectoryCount: effectiveCount, updatedAt: new Date(now()).toISOString() }, null, 2))
    audit({ kind: 'daily-report', date: today, trajectoryCount: effectiveCount, score: scoreVal, cached: false, archiveReference: archivedRows.length })
    // S26·P1：日报 + 建议自动入二级记忆（daily 一条 + 每条建议一条未完成 plan）
    const saved = autoSaveFromDaily({ date: today, score, advice, trajectoryCount: effectiveCount, reportPath, goal, dir })
    audit({ kind: 'memory-auto-save', date: today, saved: saved.length })

    return { ok: true, date: today, trajectoryCount: effectiveCount, trajectoryTotal: allToday.length, score, advice, reportPath, cached: false, workScore, lifeScore, total: dualTotal, weights, singleDim, dims, toolFrames: toolTracks.length, archiveReference: archivedRows.length }
  }

  return { run, readTrajectory, trajectoryFile, dailyDir }
}

export default { createDailyPipeline, parseLooseJson, intentAt, intentLine, trackLine, INTENT_LINE_MAP, TRAJECTORY_FILE, DAILY_DIR, DailyError }
