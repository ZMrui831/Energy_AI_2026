// packages/plugins/coach/engine.mjs
//
// S25·1A 目标与蓝图引擎：goal.json + blueprint.md 的读写与再生成。
// 纪律：写盘全在 data\coach\（根内，safeWrite + 审计；dir 可注入供测试隔离）；
//       regen 经 router（reason 档永远旗舰），LLM 失败回落模板蓝图（诚实标注 source=template）；
//       不删既有用例、不改证据链。
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, safeWrite, appendJsonl, logPath, dataPath } from '../../core/src/safefs.mjs'

export const COACH_DIR = dataPath('coach')

export class CoachError extends Error {
  constructor(code, message) { super(message); this.name = 'CoachError'; this.code = code }
}

function audit(rec) {
  try { appendJsonl(logPath('coach.jsonl'), { ts: new Date().toISOString(), ...rec }) } catch { /* 尽力 */ }
}

/** 读 goal（不存在/损坏 → null）。dir 可注入（测试隔离）。 */
export function readGoal(dir = COACH_DIR) {
  try {
    const p = join(dir, 'goal.json')
    if (!existsSync(p)) return null
    const g = JSON.parse(readFileSync(p, 'utf8'))
    return g && typeof g.goal === 'string' ? g : null
  } catch { return null }
}

/** 写 goal（空/超长拒绝）。 */
export function setGoal(goalText, { source = 'command', dir = COACH_DIR } = {}) {
  const goal = String(goalText || '').trim()
  if (!goal) throw new CoachError('E_EMPTY_GOAL', '目标不能为空（例：/coach goal set 两周内完成微电网综述的初稿与文献表）')
  if (goal.length > 500) throw new CoachError('E_GOAL_TOO_LONG', `目标过长（${goal.length} 字符，上限 500）——目标要短到能贴进每次对话的 system`)
  const rec = { goal, updatedAt: new Date().toISOString(), source }
  safeWrite(join(dir, 'goal.json'), JSON.stringify(rec, null, 2))
  audit({ kind: 'goal-set', chars: goal.length, source })
  return rec
}

/** 读蓝图（不存在 → ''）。 */
export function readBlueprint(dir = COACH_DIR) {
  try {
    const p = join(dir, 'blueprint.md')
    if (!existsSync(p)) return ''
    return readFileSync(p, 'utf8')
  } catch { return '' }
}

/** 覆写蓝图（外部 /coach blueprint edit 与 regen 同一出口）。 */
export function writeBlueprint(text, { source = 'command', dir = COACH_DIR } = {}) {
  const body = String(text || '').trim()
  if (!body) throw new CoachError('E_EMPTY_BLUEPRINT', '蓝图内容不能为空')
  safeWrite(join(dir, 'blueprint.md'), body + '\n', 'utf8')
  audit({ kind: 'blueprint-write', source, chars: body.length })
  return body
}

/** 模板蓝图（regen 的 LLM 失败回落；也可作为首次 show 的种子）。 */
export function templateBlueprint(goalText) {
  const g = String(goalText || '（尚未设定目标，/coach goal set 先定一个）').trim()
  return [
    '# 研究蓝图（模板，可 /coach blueprint edit 直接编辑）',
    '',
    `- 目标：${g}`,
    '1. 定范围：把目标拆成 3–5 个可核验的子问题（每个都能挂证据）',
    '2. 找文献：/find 检索 → 优先 ✓双源；预印本标 [预印本] 并注明版本',
    '3. 立结论：每个子问题写一条 claim，证据不足就停在草稿',
    '4. 出图表：/chart bars|table 用证据链数据出图，来源标注可回指',
    '5. 沉淀：/vault write 归档到笔记库；每日看轨迹日报校准进度',
    '',
    '（此蓝图由模板生成；/coach blueprint regen 可按目标+画像重新生成）',
  ].join('\n')
}

/**
 * 再生成蓝图：经 router（reason 档，永远旗舰）；LLM 失败回落模板（source=template，诚实标注）。
 * @param {{router:object, dir?:string}} opts
 */
export async function regenBlueprint({ router, dir = COACH_DIR } = {}) {
  if (!router) throw new CoachError('E_NO_ROUTER', 'router 未注入')
  const goal = readGoal(dir)
  const goalText = goal ? goal.goal : ''
  const r = await router.run('reason', {
    messages: [
      { role: 'system', content: '你是科研教练。根据用户目标输出一份极简研究蓝图：3–5 个带序号的步骤，每步一句话，可核验、可挂证据。不要输出标题以外的多余解释。' },
      { role: 'user', content: `用户目标：${goalText || '（未设定）'}\n请输出研究蓝图。` },
    ],
  })
  if (r.ok && r.text && r.text.trim().length > 20) {
    const body = writeBlueprint(r.text.trim(), { source: 'regen-llm', dir })
    return { ok: true, source: 'llm', providerId: r.providerId, model: r.model, fallback: r.fallback, body }
  }
  const body = writeBlueprint(templateBlueprint(goalText), { source: 'regen-template', dir })
  return { ok: true, source: 'template', fallback: true, body, reason: r && r.error }
}

export default { readGoal, setGoal, readBlueprint, writeBlueprint, templateBlueprint, regenBlueprint, COACH_DIR, CoachError }
