// packages/plugins/coach/usage-card.mjs
//
// S39·F7 /usage 面板卡：读 data/logs/usage.jsonl（真实查询）→ 今日调用/成功/回落/tokens/费用区间。
// 无数据显示「暂无调用」；只读。
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { LOG_DIR } from '../../core/src/safefs.mjs'

const COST_PER_1K = { min: 0.001, max: 0.002 } // 估算口径（元/1k tokens，deepseek-chat 量级），面板如实标注"估算"

export function readUsageRows(usagePath) {
  const f = usagePath || join(LOG_DIR, 'usage.jsonl')
  if (!existsSync(f)) return []
  const rows = []
  for (const l of readFileSync(f, 'utf8').split('\n')) {
    const t = l.trim()
    if (!t) continue
    try { rows.push(JSON.parse(l)) } catch { /* 坏行跳过 */ }
  }
  return rows
}

/** 今日用量卡（真实查询 usage.jsonl；date 缺省今天）。 */
export function buildUsageCard({ date, usagePath, now = new Date() } = {}) {
  const day = date || new Date(now).toISOString().slice(0, 10)
  const rows = readUsageRows(usagePath).filter((r) => String(r.ts || '').slice(0, 10) === day)
  if (!rows.length) return { ok: true, empty: true, text: `/usage（${day}）：暂无调用`, calls: 0 }
  const ok = rows.filter((r) => r.ok === true).length
  const fallback = rows.filter((r) => r.fallback === true).length
  const tokens = rows.reduce((a, r) => a + (Number.isFinite(r.tokens) ? r.tokens : 0), 0)
  const costMin = (tokens / 1000) * COST_PER_1K.min
  const costMax = (tokens / 1000) * COST_PER_1K.max
  const byModel = {}
  for (const r of rows) {
    const k = (r.model || r.providerId || '?') + (r.ok === false ? '（失败）' : '')
    byModel[k] = (byModel[k] || 0) + 1
  }
  const card = {
    ok: true, empty: false, date: day, calls: rows.length, okCalls: ok, failed: rows.length - ok, fallback, tokens,
    costRange: [Number(costMin.toFixed(4)), Number(costMax.toFixed(4))],
    byModel,
  }
  card.text = [
    `/usage（${day}）`,
    `- 调用：${card.calls} 次（成功 ${ok} / 失败 ${card.failed}；回落 ${fallback}）`,
    `- tokens：${tokens}`,
    `- 费用区间：¥${card.costRange[0]} ~ ¥${card.costRange[1]}（估算口径：tokens×0.001~0.002/1k，非账单）`,
    `- 分模型：${Object.entries(byModel).map(([k, v]) => `${k}×${v}`).join('，') || '—'}`,
  ].join('\n')
  return card
}

export default { buildUsageCard, readUsageRows, COST_PER_1K }
