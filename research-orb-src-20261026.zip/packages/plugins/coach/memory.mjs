// packages/plugins/coach/memory.mjs
//
// S26·P1 记忆适配层：只移植"两级 + Markdown 持久化"思路（不装 dsh-local-memory、不桥接 Cordis、不引依赖）。
//   · 一级：会话注入片段（目标 + 最近 3 条轨迹 + 未完成计划，≤400 token；无则不注入）。
//   · 二级：跨会话持久 data\coach\memory\*.md（front-matter 元数据 + Markdown 正文），
//     命令 /mem save|recall|stats|list；日报/建议自动入库；/recall 检索。
import { existsSync, mkdirSync, readFileSync, writeFileSync, readdirSync, unlinkSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, safeWrite, appendJsonl, logPath, dataPath } from '../../core/src/safefs.mjs'

export const MEMORY_MAX_TOKENS = 400
const COACH_DIR = dataPath('coach')

export function estimateTokens(s) { return Math.max(0, Math.ceil((s || '').length / 2)) }

function audit(rec) {
  try { appendJsonl(logPath('coach.jsonl'), { ts: new Date().toISOString(), ...rec }) } catch { /* 尽力 */ }
}

function slug(s) {
  return String(s || 'memory').replace(/[\\/:*?"<>|\s]+/g, '-').slice(0, 40) || 'memory'
}

/** 解析一条 memory md 的 front-matter（title/ts/kind/done/tags）。 */
export function parseMemoryFile(file, body) {
  const m = String(body || '').match(/^---\n([\s\S]*?)\n---\n?([\s\S]*)$/)
  if (!m) return { file, title: file, ts: null, kind: 'note', done: false, body: String(body || '') }
  const fm = {}
  for (const line of m[1].split('\n')) {
    const i = line.indexOf(':')
    if (i > 0) fm[line.slice(0, i).trim()] = line.slice(i + 1).trim()
  }
  return {
    file,
    title: fm.title || file,
    ts: fm.ts || null,
    kind: fm.kind || 'note',
    done: fm.done === 'true',
    tags: fm.tags ? fm.tags.split(',').map((x) => x.trim()).filter(Boolean) : [],
    body: (m[2] || '').trim(),
  }
}

function memoryDir(dir) { return dir || join(COACH_DIR, 'memory') }

/** 列全部记忆（按 ts 升序）。 */
export function listMemories(dir) {
  const d = memoryDir(dir)
  if (!existsSync(d)) return []
  const out = []
  for (const f of readdirSync(d)) {
    if (!f.endsWith('.md')) continue
    try { out.push(parseMemoryFile(f, readFileSync(join(d, f), 'utf8'))) } catch { /* 跳坏文件 */ }
  }
  return out.sort((a, b) => String(a.ts || '').localeCompare(String(b.ts || '')))
}

/** 存一条记忆（save）。 */
export function saveMemory({ title, body, kind = 'note', tags = [], dir } = {}) {
  const t = String(title || '').trim()
  if (!t) throw Object.assign(new Error('记忆标题不能为空'), { code: 'E_EMPTY_TITLE' })
  const d = memoryDir(dir)
  mkdirSync(d, { recursive: true })
  const ts = new Date().toISOString()
  const file = `${ts.slice(0, 10)}-${slug(t)}.md`
  const fm = ['---', `title: ${t}`, `ts: ${ts}`, `kind: ${kind}`, `done: false`, `tags: ${tags.join(',')}`, '---', ''].join('\n')
  safeWrite(join(d, file), fm + String(body || '').trim() + '\n', 'utf8')
  audit({ kind: 'memory-save', file, kind })
  return { file, title: t, ts, kind }
}

/** 标记完成（plan 用）。 */
export function markDone(file, dir) {
  const d = memoryDir(dir)
  const p = join(d, file)
  if (!existsSync(p)) throw Object.assign(new Error('记忆不存在：' + file), { code: 'E_NO_MEMORY' })
  const body = readFileSync(p, 'utf8').replace(/\ndone: false/, '\ndone: true')
  writeFileSync(p, body, 'utf8')
  audit({ kind: 'memory-done', file })
  return { file, done: true }
}

/** 检索（recall）：标题/正文/标签包含查询词（去大小写）。 */
export function recallMemories(query, dir, limit = 5) {
  const q = String(query || '').trim().toLowerCase()
  if (!q) return []
  return listMemories(dir)
    .filter((m) => (`${m.title}\n${m.body}\n${(m.tags || []).join(' ')}`).toLowerCase().includes(q))
    .slice(-limit)
    .reverse()
}

/** 未完成计划（一级注入用）。 */
export function pendingPlans(dir, limit = 3) {
  return listMemories(dir).filter((m) => m.kind === 'plan' && !m.done).slice(-limit).reverse()
}

/** 最近 n 条轨迹（一级注入用）。 */
export function recentTrajectory(dir, n = 3) {
  try {
    const f = join(dir || COACH_DIR, 'trajectory.jsonl')
    if (!existsSync(f)) return []
    return readFileSync(f, 'utf8').split('\n').filter((l) => l.trim()).map((l) => JSON.parse(l)).slice(-n)
  } catch { return [] }
}

/**
 * 一级会话注入片段：目标 + 最近 3 条轨迹 + 未完成计划，总 ≤ maxTokens（默认 400）。
 * 三者全空 → ''（无记忆不注入）。
 */
export function readMemorySystemContext({ dir = COACH_DIR, goal = '', maxTokens = MEMORY_MAX_TOKENS } = {}) {
  try {
    const goalText = String(goal || '').trim()
    const plans = pendingPlans(dir)
    const traj = recentTrajectory(dir, 3)
    if (!goalText && !plans.length && !traj.length) return ''
    const sections = []
    if (goalText) sections.push('【当前目标】' + goalText)
    if (plans.length) sections.push('【未完成计划】\n' + plans.map((p, i) => `${i + 1}. ${p.title}`).join('\n'))
    if (traj.length) sections.push('【最近研究轨迹】\n' + traj.map((t) => `· ${t.intent || '（未归纳）'}（${t.process || '?'}）`).join('\n'))
    let joined = sections.join('\n')
    if (estimateTokens(joined) > maxTokens) {
      // 先砍轨迹，再砍计划，最后硬截断（保目标）
      let s = joined
      if (estimateTokens(s) > maxTokens) s = sections.filter((x) => !x.startsWith('【最近研究轨迹】')).join('\n')
      if (estimateTokens(s) > maxTokens) s = sections.filter((x) => x.startsWith('【当前目标】') || x.startsWith('【未完成计划】')).slice(0, 1).join('\n')
      if (estimateTokens(s) > maxTokens) s = ('【当前目标】' + goalText).slice(0, maxTokens * 2 - 1) + '…'
      joined = s
    }
    return joined
  } catch { return '' }
}

/** 日报自动入库：**只写一条 daily 记忆**（S29·0.1：禁止"一建议一文件"——建议只拼进日报正文）。
 *  未完成计划段改由 /mem save（kind:plan）人工维护；自动侧不再产 plan 文件。 */
export function autoSaveFromDaily({ date, score, advice = [], trajectoryCount = 0, reportPath = '', goal = '', dir } = {}) {
  const saved = []
  try {
    const adviceLines = advice.length
      ? ['', '## 建议（拼进正文，不单独建文件）', ...advice.map((a, i) => `${i + 1}. ${a}`)]
      : ['', '## 建议', '（score-plan 未产出建议——见日报评分行说明）']
    saved.push(saveMemory({
      title: `日报 ${date}（评分 ${score === 'unavailable' ? 'unavailable' : score}）`,
      body: [
        `- 日期：${date}`,
        `- 评分：${score === 'unavailable' ? 'unavailable' : score + ' / 100'}`,
        `- 轨迹条数：${trajectoryCount}`,
        `- 日报路径：${reportPath}`,
        goal ? `- 目标：${goal}` : '',
        ...adviceLines,
      ].filter(Boolean).join('\n'),
      kind: 'daily',
      tags: ['daily', date],
      // S67·3-B：dir 是 pipeline 的 coach 根；记忆必须落 memory/ 子目录，
      // 否则每条日报的自动记忆副本都会散落到 data\coach 根（C1/C2 失败根因）。
      dir: dir ? join(dir, 'memory') : undefined,
    }))
  } catch { /* 尽力 */ }
  return saved
}

export default { MEMORY_MAX_TOKENS, listMemories, saveMemory, markDone, recallMemories, pendingPlans, recentTrajectory, readMemorySystemContext, autoSaveFromDaily, parseMemoryFile }
