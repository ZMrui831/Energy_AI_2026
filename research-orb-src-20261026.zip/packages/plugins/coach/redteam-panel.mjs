// packages/plugins/coach/redteam-panel.mjs
//
// S39·F2 红队面板：/redteam 复跑同一脚本（tools/redteam-demo.mjs），解析 5 类攻击结果。
// 纪律：面板不新写攻击逻辑——一键复跑调的就是 redteam-demo.mjs 本体；失败显示真实失败项。
import { spawnSync } from 'node:child_process'
import { join } from 'node:path'
import { appendJsonl, logPath, PROJECT_ROOT, dataPath } from '../../core/src/safefs.mjs'

const SCRIPT = join(PROJECT_ROOT, 'tools', 'redteam-demo.mjs')

function audit(rec) {
  try { appendJsonl(logPath('coach.jsonl'), { ts: new Date().toISOString(), ...rec }) } catch { /* 尽力 */ }
}

/** 解析 redteam-demo 输出：行格式 "[防住] 标题" / "[失守] 标题"（box 首行）。 */
export function parseRedteamOutput(stdout) {
  const rows = []
  for (const line of String(stdout || '').split('\n')) {
    const m = /^\s*\[(防住|失守|信息)\]\s+(.+)$/.exec(line)
    if (m) rows.push({ result: m[1], attack: m[2].trim() })
  }
  const defended = rows.filter((r) => r.result === '防住').length
  const breached = rows.filter((r) => r.result === '失守').length
  return { rows, defended, breached, allPass: breached === 0 && defended >= 5 }
}

/** 一键复跑（调同一脚本，不新写攻击逻辑）。 */
export function runRedteamPanel({ timeoutMs = 180000 } = {}) {
  const ranAt = new Date().toISOString()
  const r = spawnSync(process.execPath, [SCRIPT], { encoding: 'utf8', timeout: timeoutMs, cwd: PROJECT_ROOT })
  const parsed = parseRedteamOutput(r.stdout)
  const failedRows = parsed.rows.filter((x) => x.result === '失守')
  const result = {
    ranAt,
    exit: r.status,
    rows: parsed.rows,
    defended: parsed.defended,
    breached: parsed.breached,
    allPass: parsed.allPass && r.status === 0,
    failedItems: failedRows.length ? failedRows.map((x) => x.attack) : (r.status !== 0 ? ['脚本退出码非 0（真实失败项见 stderr）：' + String(r.stderr || '').slice(0, 120)] : []),
  }
  audit({ kind: 'redteam-run', defended: result.defended, breached: result.breached, allPass: result.allPass })
  return result
}

/** 面板文本。 */
export function renderRedteamPanel(result) {
  const L = [`红队面板（最近复跑：${result.ranAt}）`, '']
  L.push('| 攻击 | 结果 | 防线 |')
  L.push('| --- | --- | --- |')
  for (const row of result.rows) {
    const defense = { 'A1': '权限矩阵 evaluate', 'A2': '权限矩阵 + 授权闸', 'A3': 'SQLite 触发器', 'A4': '敏感窗口判定 isSensitive', 'A5': '审计族只增不删' }
    const key = Object.keys(defense).find((k) => row.attack.includes(k)) || ''
    L.push(`| ${row.attack} | ${row.result} | ${defense[key] || '产品真实判定函数'} |`)
  }
  L.push('')
  L.push(`结果：${result.defended}/${result.defended + result.breached} 防住${result.allPass ? '（5/5）' : ''}`)
  if (result.failedItems.length) L.push('真实失败项：' + result.failedItems.join('；'))
  L.push('复跑命令：node tools\\redteam-demo.mjs（面板内"一键复跑"调的就是它）')
  return L.join('\n')
}

export default { parseRedteamOutput, runRedteamPanel, renderRedteamPanel }
