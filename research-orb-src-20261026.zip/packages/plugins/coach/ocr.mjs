// packages/plugins/coach/ocr.mjs
//
// S25·2B Windows OCR 兜底：WinRT Windows.Media.Ocr（零新增依赖，子进程 powershell）。
// 环境坑（S24-0 实测）：
//   · 必须先 Add-Type System.Runtime.WindowsRuntime（WinRT 投影前提）；
//   · 绝对路径内联进脚本串会被宿主脱敏层替换成 UNABLE_TO_MASK_PATH → 用 $env: 传参；
//   · 子进程输出编码设 UTF8。
// 纯函数式入口 runWinrtOcr(imagePath)：{ok, engine, text, err?}。
import { spawnSync } from 'node:child_process'

export function runWinrtOcr(imagePath) {
  const script = `
$ErrorActionPreference='Stop'
$imagePath = $env:COACH_OCR_IMG
try {
  [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
  Add-Type -AssemblyName System.Runtime.WindowsRuntime
  [Windows.Media.Ocr.OcrEngine,Windows.Foundation,ContentType=WindowsRuntime] | Out-Null
  [Windows.Graphics.Imaging.BitmapDecoder,Windows.Foundation,ContentType=WindowsRuntime] | Out-Null
  [Windows.Storage.StorageFile,Windows.Foundation,ContentType=WindowsRuntime] | Out-Null
  [Windows.Globalization.Language,Windows.Foundation,ContentType=WindowsRuntime] | Out-Null
  $m = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation\`1' })[0]
  function Await($op, $t) { $task = $m.MakeGenericMethod($t).Invoke($null, @($op)); $task.Wait(); $task.Result }
  $ocr = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
  $engine = 'UserProfileLanguages'
  if (-not $ocr) {
    $avail = ([Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages | ForEach-Object { $_.LanguageTag }) -join ','
    if ($avail) {
      $first = $avail.Split(',')[0].Trim()
      $ocr = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage((New-Object Windows.Globalization.Language($first)))
      $engine = 'first-of:' + $first
    }
  }
  if (-not $ocr) { Write-Output ('JSON:' + (@{ ok=$false; engine=('none; avail=' + $avail); text='' } | ConvertTo-Json -Compress)); exit 0 }
  $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($imagePath)) ([Windows.Storage.StorageFile])
  $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
  $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
  $bmp = Await ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
  $res = Await ($ocr.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
  Write-Output ('JSON:' + (@{ ok=$true; engine=$engine; text=$res.Text } | ConvertTo-Json -Compress))
} catch {
  $msg = $_.Exception.GetBaseException().Message
  Write-Output ('JSON:' + (@{ ok=$false; engine=$null; text=''; err=$msg } | ConvertTo-Json -Compress))
}
`
  const r = spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script], {
    timeout: 60000, encoding: 'utf8', env: { ...process.env, COACH_OCR_IMG: imagePath },
  })
  const line = (r.stdout || '').split('\n').find((l) => l.startsWith('JSON:'))
  if (!line) return { ok: false, engine: null, text: '', err: ((r.stderr || '') + ' ' + (r.stdout || '')).trim().slice(0, 240) }
  try { return JSON.parse(line.slice(5)) } catch { return { ok: false, engine: null, text: line.slice(5, 205) } }
}

export default { runWinrtOcr }
