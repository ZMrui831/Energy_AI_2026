// packages/plugins/coach/pdf-export.mjs
//
// S42·B2 结论导出 PDF：正文 + 证据附录（id/类型/哈希/来源）+ 页脚（时间/版本/匿名声明）。
// 管线：reportlab（专用 venv，Python 依赖允许）+ CID 中文字体（零字体文件）。
// 降级：PDF 不可用 → {ok:false, pdfError}，不阻塞 md/docx 导出。
import { spawnSync } from 'node:child_process'
import { existsSync, writeFileSync, unlinkSync } from 'node:fs'
import { join } from 'node:path'
import { homedir } from 'node:os'
import { PROJECT_ROOT } from '../../core/src/safefs.mjs'

const PY_CANDIDATES = [
  process.env.RESEARCH_VOICE_PYTHON || '',
  join(homedir(), '.workbuddy', 'binaries', 'python', 'envs', 'voice', 'Scripts', 'python.exe'),
].filter(Boolean)
const SCRIPT = join(PROJECT_ROOT, 'tools', 'ui-step', 'pdf-export.py')

/**
 * @param {{title:string, claimText:string, evidenceRows?:Array<Array<string>>, exportTime:string, version:string, outPath:string}} input
 * @returns {{ok:boolean, pdfPath?:string, pages?:number, pdfError?:string}}
 */
export function exportClaimPdf({ title, claimText, evidenceRows = [], exportTime, version, outPath }) {
  for (const py of PY_CANDIDATES) {
    if (!existsSync(py)) continue
    const probe = spawnSync(py, ['-c', 'import reportlab; print("ok")'], { encoding: 'utf8', timeout: 30000 })
    if (probe.status !== 0) continue
    const footer = `${exportTime} · research-orb ${version} · 匿名导出：本文件不含个人信息与明文路径`
    const payload = {
      out: outPath,
      title,
      body: [
        { h2: '结论正文' },
        { p: claimText },
        { h2: '证据附录' },
        { table: [['#', 'evidence_id', '层', '关系', '当前可用性', 'sha256 前 12 位'], ...evidenceRows] },
      ],
      footer,
    }
    const payloadPath = outPath.replace(/\.pdf$/, '.payload.json')
    writeFileSync(payloadPath, JSON.stringify(payload, null, 2), 'utf8')
    const r = spawnSync(py, [SCRIPT, payloadPath], { encoding: 'utf8', timeout: 60000 })
    try { unlinkSync(payloadPath) } catch { /* 尽力 */ }
    const line = String(r.stdout || '').trim().split('\n').filter(Boolean).pop()
    try {
      const parsed = JSON.parse(line)
      if (parsed.ok === true && existsSync(outPath)) return { ok: true, pdfPath: outPath, pages: parsed.pages }
      return { ok: false, pdfError: parsed.reason || 'PDF 生成失败' }
    } catch {
      return { ok: false, pdfError: String(r.stderr || r.stdout || '无输出').slice(0, 140) }
    }
  }
  return { ok: false, pdfError: 'reportlab 不可用（需专用 venv：pip install reportlab）——md/docx 不受影响' }
}

export default { exportClaimPdf }
