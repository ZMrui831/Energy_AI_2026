// packages/plugins/coach/mindmap.mjs
//
// S37·B 思维导图：/mem recall + 蓝图 + 最近轨迹 → ≥3 层层级（目标/方向 → 主题 → 事实/任务）
//   → mermaid mindmap 文本 + Pillow PNG（data/artifacts/mindmap-<ts>.png）+ 可存笔记库「研究导图/」。
// 纪律（红线）：
//   · 图内来源标注（memory/blueprint/trajectory · 时间 · 版本）必须画进 PNG（底部色带 + sidecar 记录）。
//   · 按内容哈希幂等：同一份内容（root+themes+leaves）不重复渲染，命中缓存直接返回（mtime 不变）。
//   · 空记忆/空蓝图 → 明确提示不崩（E_EMPTY_MINDMAP，附建议动作），绝不编造节点。
//   · PNG 渲染复用 chart-skill 的 Pillow 管线模式（本机 Python，零新增依赖）。
import { createHash } from 'node:crypto'
import { existsSync, mkdirSync, readFileSync, readdirSync, copyFileSync, writeFileSync } from 'node:fs'
import { spawn } from 'node:child_process'
import { join, dirname } from 'node:path'
import { dataPath, safeWrite } from '../../core/src/safefs.mjs'
import { readGoal, readBlueprint } from './engine.mjs'
import { readLongTermMemoryContext } from '../longterm-memory/context.mjs'

export const MindmapError = class MindmapError extends Error {
  constructor(code, message) { super(message); this.name = 'MindmapError'; this.code = code }
}

const PY_CANDIDATES = [
  'C:\\Program Files\\Python313\\python.exe',
  'python.exe',
  'python',
]
let pythonCache = null

function runCapture(cmd, args, timeoutMs = 20000) {
  return new Promise((resolve) => {
    try {
      const child = spawn(cmd, args, { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] })
      let out = '', err = ''
      const timer = setTimeout(() => { try { child.kill() } catch { /* 尽力 */ } }, timeoutMs)
      child.stdout.on('data', (d) => { out += String(d) })
      child.stderr.on('data', (d) => { err += String(d) })
      child.on('close', (code) => { clearTimeout(timer); resolve({ ok: code === 0, out, err }) })
      child.on('error', (e) => { clearTimeout(timer); resolve({ ok: false, err: String(e && e.message) }) })
    } catch (e) {
      resolve({ ok: false, err: String(e && e.message) })
    }
  })
}

/** 探测带 Pillow 的 Python（首个 `import PIL` 成功者，进程内缓存）。 */
export async function resolvePython() {
  if (pythonCache) return pythonCache
  const cands = [process.env.RESEARCH_CHART_PYTHON, ...PY_CANDIDATES].filter(Boolean)
  for (const cand of cands) {
    const r = await runCapture(cand, ['-c', 'import PIL; print(PIL.__version__)'], 15000)
    if (r.ok) {
      pythonCache = { path: cand, pillow: String(r.out).trim() }
      return pythonCache
    }
  }
  throw new MindmapError('E_NO_PILLOW', '找不到带 Pillow 的 Python（本机 3.13.6 应有 Pillow 13）。可设 RESEARCH_CHART_PYTHON 指定解释器')
}

const sha256 = (s) => createHash('sha256').update(String(s), 'utf8').digest('hex')

/** 数据层：goal（L1）→ 蓝图步骤/记忆事实（L2 主题）→ 记忆条目/轨迹意图（L3 叶子）。 */
export function buildMindmapData({ query = '研究 方向 综述', dir, now = new Date(), version = '0.7.0' } = {}) {
  const goal = readGoal(dir)
  const goalText = goal ? goal.goal : ''
  const bpLines = readBlueprint(dir).split('\n').map((l) => l.trim()).filter((l) => /^\d+[.、]/.test(l)).slice(0, 5)
  const memoryText = readLongTermMemoryContext({ query })
  const memFacts = memoryText.split('\n').map((l) => l.replace(/^[-·]\s*/, '').trim()).filter((l) => l.length > 4).slice(0, 6)
  const trajIntents = []
  try {
    const trajFile = dataPath('coach', 'trajectory.jsonl')
    if (existsSync(trajFile)) {
      const lines = readFileSync(trajFile, 'utf8').split('\n').filter(Boolean)
      for (let i = lines.length - 1; i >= 0 && trajIntents.length < 4; i--) {
        try {
          const r = JSON.parse(lines[i])
          const it = String(r.intent || '')
          if (it && !it.includes('（') && !trajIntents.includes(it)) trajIntents.push(it)
        } catch { /* 坏行跳过 */ }
      }
    }
  } catch { /* 尽力 */ }

  const themes = []
  for (const l of bpLines) themes.push({ title: l.replace(/^\d+[.、]\s*/, '').slice(0, 40), source: 'blueprint', leaves: [] })
  if (memFacts.length) themes.push({ title: '记忆事实（/memory recall）', source: 'memory', leaves: memFacts.map((t) => ({ text: t.slice(0, 60), source: 'memory' })) })
  if (trajIntents.length) themes.push({ title: '最近轨迹（trajectory）', source: 'trajectory', leaves: trajIntents.map((t) => ({ text: t.slice(0, 60), source: 'trajectory' })) })

  const data = {
    root: goalText || '（未设目标：/coach goal set 先定一个）',
    title: '研究思维导图：' + (goalText ? goalText.slice(0, 24) : '未设目标'),
    themes,
    sources: `来源：memory ${memFacts.length} 条 / blueprint ${bpLines.length} 步 / trajectory ${trajIntents.length} 条 · ${new Date(now).toISOString().slice(0, 10)} · v${version}`,
    generatedAt: new Date(now).toISOString(),
    counts: { memory: memFacts.length, blueprint: bpLines.length, trajectory: trajIntents.length },
  }
  // 内容哈希（不含时间戳——同内容幂等）
  data.contentHash = sha256(JSON.stringify({ root: data.root, themes: data.themes }))
  return data
}

/** mermaid mindmap 文本（缩进层级即层级）。 */
export function mindmapToMermaid(data) {
  const esc = (s) => String(s).replace(/[[\]()]/g, ' ').slice(0, 60)
  const L = ['mindmap', `  ((${esc(data.root)}))`]
  for (const th of data.themes) L.push(`    ${esc(th.title + '〔' + th.source + '〕')}`)
  for (const th of data.themes) for (const leaf of th.leaves) L.push(`      ${esc(leaf.text)}`)
  return L.join('\n')
}

function pngSize(buf) {
  if (!buf || buf.length < 24 || buf.toString('ascii', 12, 16) !== 'IHDR') throw new MindmapError('E_BAD_PNG', '不是合法 PNG')
  return { width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) }
}

/**
 * 渲染 PNG（幂等）：同 contentHash 命中缓存直接返回。
 * @returns {Promise<{ok:boolean, pngPath, mermaidPath, drawnPath, size, cached:boolean, contentHash, data}>}
 */
export async function renderMindmap({ query, dir, outDir, now = new Date(), version = '0.7.0' } = {}) {
  const data = buildMindmapData({ query, dir, now, version })
  const leafTotal = data.themes.reduce((a, t) => a + (t.leaves ? t.leaves.length : 0), 0)
  if (!data.themes.length || leafTotal === 0) {
    throw new MindmapError('E_EMPTY_MINDMAP', '记忆/蓝图/轨迹三类内容全空——无可画内容（提示：/coach goal set 设目标 + /memory 沉淀事实后再试），不编造节点')
  }
  const out = outDir || dataPath('artifacts', 'mindmap')
  mkdirSync(out, { recursive: true })
  const stamp = new Date(now).toISOString().slice(0, 19).replace(/[:T-]/g, '')
  const pngPath = join(out, `mindmap-${stamp}-${data.contentHash.slice(0, 8)}.png`)
  // 幂等：同哈希已有产物 → 直接命中
  try {
    for (const f of readdirSync(out)) {
      if (f.endsWith('.png') && f.includes(data.contentHash.slice(0, 8))) {
        const hit = join(out, f)
        const drawn = join(out, f + '.drawn.json')
        if (existsSync(hit) && existsSync(drawn)) {
          const size = pngSize(readFileSync(hit))
          return { ok: true, pngPath: hit, mermaidPath: hit.replace(/\.png$/, '.md'), drawnPath: drawn, size, cached: true, contentHash: data.contentHash, data }
        }
      }
    }
  } catch { /* 缓存探测失败 → 走渲染 */ }

  const py = await resolvePython()
  const payloadPath = join(out, `mindmap-payload-${data.contentHash.slice(0, 8)}.json`)
  safeWrite(payloadPath, JSON.stringify({ ...data, out: pngPath, contentHash: data.contentHash }, null, 2), 'utf8')
  const script = join(dirname(new URL(import.meta.url).pathname).replace(/^\/([A-Za-z]:)/, '$1'), 'render_mindmap.py')
  const r = await runCapture(py.path, [script, payloadPath], 60000)
  if (!r.ok || !existsSync(pngPath)) {
    throw new MindmapError('E_RENDER_FAILED', 'Pillow 渲染失败：' + String(r.err || r.out || '未知原因').slice(0, 160))
  }
  const size = pngSize(readFileSync(pngPath))
  if (size.width < 1600 || size.height < 1000) {
    throw new MindmapError('E_BAD_SIZE', `PNG 尺寸不合规：${size.width}x${size.height}（要求 ≥1600×1000）`)
  }
  // mermaid 文本随产物落盘
  const mermaidPath = pngPath.replace(/\.png$/, '.md')
  safeWrite(mermaidPath, [`# 思维导图（${data.generatedAt.slice(0, 10)}）`, '', '```mermaid', mindmapToMermaid(data), '```', '', `- 来源：${data.sources}`, `- contentHash：${data.contentHash}`, ''].join('\n'), 'utf8')
  // S39·F5：节点→笔记映射 sidecar（导图节点可点 → 跳对应笔记）
  const mapping = mapNodesToNotes(data, dataPath('notes'))
  const sidecarPath = pngPath.replace(/\.png$/, '.json')
  safeWrite(sidecarPath, JSON.stringify({ contentHash: data.contentHash, generatedAt: data.generatedAt, nodes: mapping }, null, 2), 'utf8')
  return { ok: true, pngPath, mermaidPath, sidecarPath, drawnPath: pngPath + '.drawn.json', size, cached: false, contentHash: data.contentHash, data }
}

/**
 * S39·F5 节点→笔记映射：每个叶子节点按"文本前 10 字出现在笔记正文"匹配 notes/ 下的 md；
 * 未命中 → noteFile:null（可点但无跳转目标，如实标注）。返回 [{nodePath, text, source, noteFile}]。
 */
export function mapNodesToNotes(data, notesDir) {
  const out = []
  let files = []
  try {
    const walk = (d) => {
      if (!existsSync(d)) return
      for (const n of readdirSync(d, { withFileTypes: true })) {
        const fp = join(d, n.name)
        if (n.isDirectory()) walk(fp)
        else if (n.name.endsWith('.md')) files.push(fp)
      }
    }
    walk(notesDir)
    const contents = files.map((f) => ({ f, text: readFileSync(f, 'utf8').replace(/\s+/g, '') }))
    // 最长公共子串（≥6 字）命中：叶子文本与笔记正文有实质重叠即关联（避免整句必须逐字相同）
    const longestCommon = (a, b) => {
      let best = ''
      for (let i = 0; i + 6 <= a.length; i++) {
        for (let len = Math.min(20, a.length - i); len >= 6; len--) {
          const sub = a.slice(i, i + len)
          if (b.includes(sub) && sub.length > best.length) { best = sub; break }
        }
        if (best.length >= 10) break
      }
      return best
    }
    for (let i = 0; i < data.themes.length; i++) {
      const th = data.themes[i]
      const thPath = `themes[${i}]/${th.title}`
      for (let j = 0; j < (th.leaves || []).length; j++) {
        const leaf = th.leaves[j]
        const norm = String(leaf.text || '').replace(/\s+/g, '')
        let hit = null
        if (norm.length >= 6) {
          for (const c of contents) {
            if (longestCommon(norm, c.text).length >= 6) { hit = c; break }
          }
        }
        out.push({ nodePath: `${thPath}/leaves[${j}]`, text: leaf.text, source: leaf.source, noteFile: hit ? hit.f : null })
      }
    }
  } catch { /* 尽力：映射失败不出错（跳转是增强功能） */ }
  return out
}

/** 存入笔记库新目录「研究导图/」（png + mermaid md + 节点映射 sidecar 同存）。 */
export function saveToNotes(rendered) {
  const notesDir = dataPath('notes', '研究导图')
  mkdirSync(notesDir, { recursive: true })
  const base = rendered.pngPath.replace(/\\/g, '/').split('/').pop().replace(/\.png$/, '')
  const pngDst = join(notesDir, base + '.png')
  const mdDst = join(notesDir, base + '.md')
  const jsonDst = join(notesDir, base + '.json')
  copyFileSync(rendered.pngPath, pngDst)
  writeFileSync(mdDst, readFileSync(rendered.mermaidPath, 'utf8'), 'utf8')
  if (rendered.sidecarPath && existsSync(rendered.sidecarPath)) writeFileSync(jsonDst, readFileSync(rendered.sidecarPath, 'utf8'), 'utf8')
  return { pngDst, mdDst, jsonDst }
}
