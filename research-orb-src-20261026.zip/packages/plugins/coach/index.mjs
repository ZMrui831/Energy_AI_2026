// packages/plugins/coach/index.mjs
//
// S25·1A/1B + 2A–2E + S26 宿主接线：/coach 目标/蓝图 + /usage + 调度器三源 + 每日流水线 +
// 困惑问询 + 健康账，全部在主进程 activate 时真实挂起（启动即挂、退出即停、崩溃自恢复）。
//
// 纪律：
//   · LLM 经 router（extract/summarize/score-plan；cheap=qwen 视觉、旗舰=deepseek）；令牌桶 10 req/min。
//   · 未同意感知不跑：consent 从 data/perception-config.json 只读推导（与感知插件同源，不另造），
//     denied → daily/ask 跳过并写审计 skipped-no-consent，绝不静默。
//   · 抓屏走宿主 ctx.screen.captureScreen()（与感知同一条屏幕桥）；原图处理后即删并审计（2B）。
//   · 分层路由：cheap=网关 qwen（视觉）；flagship=现有 deepseek-api 官方 API（secrets.deepseek，
//     api.deepseek.com 已在白名单）——S27 修复了 authRef 对象解析与 isGateway 误判（曾致 401）。
import { join } from 'node:path'
import { homedir } from 'node:os'
import { readFileSync, existsSync, mkdirSync, writeFileSync } from 'node:fs'
import { PROJECT_ROOT, logPath, dataPath } from '../../core/src/safefs.mjs'
import { createRouter, TASK_CLASSES } from '../../core/src/router.mjs'
import { readGoal, setGoal, readBlueprint, writeBlueprint, templateBlueprint, regenBlueprint, CoachError } from './engine.mjs'
import { createScheduler, SchedulerError } from './scheduler.mjs'
import { createExtractor } from './extract.mjs'
import { createDailyPipeline } from './daily.mjs'
import { createHealthLedger } from './health.mjs'
import { createConfusionCoach, isRecallQuery } from './confusion.mjs'
import { createDevHandler } from './dev-cmd.mjs'
import { listQa, searchQa } from './qa-log.mjs'
import { uiList, uiAllow, uiDeny, uiStep as uiStepFn, describeRequest as uiDescribe } from '../../../tools/ui-step/ui-step.mjs'
import { renderMindmap, saveToNotes, MindmapError } from './mindmap.mjs'
import { buildEvidenceChain, renderChainMd, noEvidenceText } from './chain.mjs'
import { runRedteamPanel, renderRedteamPanel } from './redteam-panel.mjs'
import { buildUsageCard } from './usage-card.mjs'
import { readVoiceConfig, setVoiceEnabled, gatedTranscribe, voiceStatusCard } from '../../core/src/voice-settings.mjs'
import { readPerceptionConsent } from './consent.mjs'
import { auditPreflight } from './audit-preflight.mjs'
import { listMemories, saveMemory, markDone, recallMemories, pendingPlans, readMemorySystemContext, MEMORY_MAX_TOKENS } from './memory.mjs'
import { writeWeeklyReport, buildWeeklyTrendChart } from './weekly.mjs'
import { createPlanStore } from './plans.mjs'
import { buildPrivacyDashboard, renderPrivacyMarkdown, exportPrivacy, desensitizePath } from './privacy.mjs'

export const PLUGIN_ID = 'coach'
const USAGE = '用法：/coach goal set <目标>｜/coach goal show｜/coach blueprint show|edit <全文>|regen｜/coach ask [主动问询]｜/coach weekly [周报+趋势图]｜/coach plans add|list|done|drop｜/coach run-daily [帧数]｜/coach status｜/privacy｜/mem save <标题>|<正文>｜/mem recall <关键词>｜/mem list｜/mem stats｜/mem done <file>'

/** 生命周期 store：ctx.core.lifecycle 优先（测试/显式注入），否则 globalThis 桥（宿主异步 bootstrap）。 */
export function resolveLifecycleStore(ctx) {
  const direct = (ctx && ctx.core && ctx.core.lifecycle) || null
  if (direct) return direct
  const bridge = globalThis.researchOrbLifecycle
  return bridge && bridge.store ? bridge.store : null
}
const GATEWAY_BASE = 'https://models.sjtu.edu.cn/api/v1'

/** 读 claude-settings env 的引用值（providers.json 的 ref 语法 = 来源:键名；运行时直读，值不落盘）。 */
export function resolveRef(ref) {
  try {
    const [src, key] = String(ref || '').split(':')
    if (src === 'claude-settings') {
      const p = join(homedir(), '.claude', 'settings.json')
      if (!existsSync(p)) return null
      const doc = JSON.parse(readFileSync(p, 'utf8'))
      return (doc.env && doc.env[key]) || null
    }
    if (src === 'secrets') {
      const p = dataPath('secrets.json')
      if (!existsSync(p)) return null
      const doc = JSON.parse(readFileSync(p, 'utf8'))
      return (doc && doc[key]) || null
    }
  } catch { return null }
  return null
}

/** 解析密钥引用：字符串直接用；对象（secrets.deepseek 段）取 apiKey/token。
 *  S27·问题1 根因：authRef:'secrets:deepseek' 解析回整个对象 → 'Bearer '+[object Object] → 401。 */
export function resolveAuth(ref) {
  const v = resolveRef(ref)
  if (v && typeof v === 'object') {
    if (typeof v.apiKey === 'string' && v.apiKey) return v.apiKey
    if (typeof v.token === 'string' && v.token) return v.token
    return null
  }
  return typeof v === 'string' && v ? v : null
}

/** 视觉档超时（S60：推理模型首 token 慢，≥60s；取 90s 留余量）。 */
export const VISION_TIMEOUT_MS = 90000
/** 视觉档 maxTokens 下限（S60：推理内容要先进 reasoning_content，<512 会被推理吃光 → content 为空）。 */
export const VISION_MIN_TOKENS = 512

/** 兑现函数：vision=智谱 GLM-5.3-Flash（推理模型，S60）；cheap=网关 qwen；flagship=deepseek-api。
 *  支持视觉：payload.messages 里可直接带 image_url content。
 *  net 可用走白名单受控出口；不可用（accept/探针）走直接 fetch——两条路都受 router 令牌桶约束。
 *  S62：请求体固定 `reasoning_effort:'low'`（主管三组对照：completion tokens 242→34（-86%）、
 *  延迟 6.5s→2.4s，质量不降）——**不再做"加倍 max_tokens 重试"**（E_LENGTH 与图片内容强相关，
 *  不可稳定复现；length 且有 content 就如实返回，空文本才抛错交给网关回退）。 */
export function makeInvoke(ctx) {
  const net = (ctx && ctx.net && ctx.net.available) ? ctx.net : null
  return async ({ tier, provider, payload, taskClass }) => {
    // ---- S60/S62 视觉档：智谱 GLM（低思考 + 兜底，不再重试）----
    if (tier === 'vision') {
      const baseUrl = String(provider.baseUrl || 'https://open.bigmodel.cn/api/paas/v4').replace(/\/+$/, '')
      const apiKey = resolveAuth(provider.authRef)
      const model = provider.model || 'glm-5.3-flash'
      if (!apiKey) throw Object.assign(new Error('视觉 provider 密钥不可用（期望 secrets:zhipu）'), { code: 'E_NO_AUTH' })
      const messages = payload.messages || [{ role: 'user', content: String(payload.prompt || '') }]
      const url = baseUrl + '/chat/completions'
      // maxTokens 下限 512（调用方写死小值也自动抬到下限）
      const mt0 = Math.max(VISION_MIN_TOKENS, Number(payload.maxTokens) || 0)
      // S62：reasoning_effort 默认 'low'；payload.reasoningEffort==='off' 可关闭（对照组/诊断用）
      const useEffort = payload.reasoningEffort !== 'off'
      const body = { model, messages, max_tokens: mt0 }
      if (useEffort) body.reasoning_effort = 'low'
      const init = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json; charset=utf-8', Authorization: 'Bearer ' + apiKey },
        body: JSON.stringify(body),
      }
      const res = net
        ? await net.request(url, init)
        : await fetch(url, { ...init, signal: AbortSignal.timeout(VISION_TIMEOUT_MS) })
      if (!res.ok) throw Object.assign(new Error('HTTP ' + res.status + ': ' + String(await res.text().catch(() => '')).slice(0, 120)), { code: 'E_HTTP_' + res.status })
      const doc = await res.json()
      const ch = (doc.choices && doc.choices[0]) || {}
      const msg = ch.message || {}
      let text = String(msg.content || '').trim()
      let usedReasoningFallback = false
      // content 为空但 reasoning_content 有内容 → 当兜底输出（审计标注 usedReasoningFallback）
      if (!text && String(msg.reasoning_content || '').trim()) {
        text = String(msg.reasoning_content).trim()
        usedReasoningFallback = true
      }
      if (!text) throw Object.assign(new Error('视觉模型返回空文本'), { code: 'E_EMPTY' })
      const completionTokens = doc.usage ? (doc.usage.completion_tokens ?? null) : null
      return {
        text,
        tokens: doc.usage ? (doc.usage.total_tokens ?? null) : null,
        meta: {
          usedReasoningFallback,
          finish: ch.finish_reason || null,
          maxTokens: mt0,
          reasoningEffort: useEffort ? 'low' : null,
          completionTokens,
        },
      }
    }
    // 只有 cheap 档与显式 school-gateway 走网关；flagship（deepseek-api）走官方 API
    // （S27 修复：此前的 `!provider.baseUrlRef` 会把旗舰误判成网关路径 → Bearer 拼错 → 401）
    const isGateway = tier === 'cheap' || provider.providerId === 'school-gateway'
    let baseUrl, apiKey, model
    if (isGateway) {
      baseUrl = (resolveRef(provider.baseUrlRef) || GATEWAY_BASE.replace(/\/api\/v1$/, '/api'))
      // 归一化：无论 ref 给到 …/api 还是 …/api/v1，统一收敛为 …/api/v1（避免 /api/api/v1 → 404）
      baseUrl = String(baseUrl).replace(/\/+$/, '').replace(/\/api(\/v1)?$/, '') + '/api/v1'
      apiKey = resolveAuth(provider.authRef) || resolveAuth('claude-settings:ANTHROPIC_AUTH_TOKEN')
      model = tier === 'cheap' ? (provider.model || 'qwen') : (payload.modelOverride || 'deepseek-chat')
    } else {
      // 旗舰：现有 deepseek-api 管线（secrets.deepseek：官方 baseUrl + apiKey + models）
      const sec = resolveRef(provider.authRef) || {}
      baseUrl = (typeof sec === 'object' && sec.baseUrl) || 'https://api.deepseek.com'
      apiKey = resolveAuth(provider.authRef)
      model = provider.model || (sec && Array.isArray(sec.models) && sec.models[0]) || 'deepseek-chat'
    }
    if (!apiKey) throw Object.assign(new Error('网关密钥不可用'), { code: 'E_NO_AUTH' })
    const messages = payload.messages || [{ role: 'user', content: String(payload.prompt || '') }]
    const url = baseUrl + '/chat/completions'
    // S64·P0：旗舰（deepseek-v4-pro）也是**推理模型** —— 不带 reasoning_effort 时
    // max_tokens 全被思考吃掉（finish=length、content 0 字）→ 日报 score unavailable。
    // 三档：score-plan/summarize（结构化短 JSON）= 'none'；reason 档 = 'low'；缺省 'none'。
    const EFFORT_BY_TIER = { flagship: 'none', reason: 'low' }
    const reasoningEffort = payload.reasoningEffort || EFFORT_BY_TIER[taskClass] || (tier === 'flagship' ? 'none' : null)
    // score-plan/summarize ≥800（none 下 9–60 token 就够，800 是防长回复截断的安全上限）
    const maxTokens = Math.max(tier === 'flagship' ? 800 : 0, Number(payload.maxTokens) || 0) || (payload.maxTokens || 500)
    const body = { model, messages, max_tokens: maxTokens }
    if (reasoningEffort) body.reasoning_effort = reasoningEffort
    const init = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=utf-8', Authorization: 'Bearer ' + apiKey },
      body: JSON.stringify(body),
    }
    let res
    if (net) {
      res = await net.request(url, init) // 产品路径：白名单 + 审计 + 限速
    } else {
      res = await fetch(url, { ...init, signal: AbortSignal.timeout(60000) }) // 验证路径（accept/探针）：直连，仍受 router 令牌桶约束
    }
    if (!res.ok) throw Object.assign(new Error('HTTP ' + res.status + ': ' + String(await res.text().catch(() => '')).slice(0, 120)), { code: 'E_HTTP_' + res.status })
    const doc = await res.json()
    const ch = (doc.choices && doc.choices[0]) || {}
    const msg = ch.message || {}
    let text = String(msg.content || '').trim()
    let usedReasoningFallback = false
    // S64：content 为空优先读 reasoning_content 兜底解析（与 vision 档同口径）
    if (!text && String(msg.reasoning_content || '').trim()) {
      text = String(msg.reasoning_content).trim()
      usedReasoningFallback = true
    }
    const tokens = doc.usage ? (doc.usage.total_tokens ?? null) : null
    const completionTokens = doc.usage ? (doc.usage.completion_tokens ?? null) : null
    return {
      text,
      tokens,
      meta: { reasoningEffort: reasoningEffort || null, completionTokens, usedReasoningFallback, finish: ch.finish_reason || null, maxTokens },
    }
  }
}

/** 分模型统计（/usage 出口；导出供验收复用同一口径）。path 可注入（默认读真实 usage.jsonl）。 */
export function usageStats({ path } = {}) {
  const p = path || logPath('usage.jsonl')
  const rows = []
  try {
    for (const line of readFileSync(p, 'utf8').split('\n')) {
      const t = line.trim()
      if (!t) continue
      try { rows.push(JSON.parse(t)) } catch { /* 跳坏行 */ }
    }
  } catch { return { total: 0, byModel: [] } }
  const byKey = new Map()
  for (const r of rows) {
    const k = `${r.providerId || '?'}/${r.model || '?'}`
    const cur = byKey.get(k) || { providerId: r.providerId, model: r.model, calls: 0, ok: 0, fallback: 0, tokens: 0 }
    cur.calls += 1
    if (r.ok) cur.ok += 1
    if (r.fallback) cur.fallback += 1
    if (Number.isFinite(r.tokens)) cur.tokens += r.tokens
    byKey.set(k, cur)
  }
  // B2：今日旗舰调用次数 + tokens 合计 + 费用区间（只报 token/次数，费用用区间表述）
  const today = new Date().toISOString().slice(0, 10)
  let fsCalls = 0
  let fsTokens = 0
  for (const r of rows) {
    if (r.tier === 'flagship' && typeof r.ts === 'string' && r.ts.slice(0, 10) === today) {
      fsCalls += 1
      if (Number.isFinite(r.tokens)) fsTokens += r.tokens
    }
  }
  const perM = (n) => n / 1e6
  const feeMin = perM(fsTokens) * 1 // deepseek-chat 输入约 ¥1/1M
  const feeMax = perM(fsTokens) * 4 // deepseek-chat 输出约 ¥4/1M（混合取区间）
  const feeInterval = `≈¥${feeMin.toFixed(2)}–${feeMax.toFixed(2)}（按公开价区间估算，非账单）`
  return { total: rows.length, byModel: [...byKey.values()].sort((a, b) => b.calls - a.calls), todayFlagship: { calls: fsCalls, tokens: fsTokens, feeInterval } }
}

export async function activate(ctx) {
  const log = (ctx && ctx.log) || console
  // B3：审计完整性巡检前置化——任何写 data/coach|memory|logs 的功能启动前先过巡检；
  // 失败（审计日志出现丢失行）则拒绝启动并报错，绝不静默降级。
  try {
    const pre = auditPreflight()
    log.info('[coach] 审计完整性巡检通过：' + pre.results.map((r) => `${r.file}=${r.total}(live${r.live}+arch${r.archived})≥${r.baseline}`).join(' '))
  } catch (e) {
    log.error('[coach] 审计完整性巡检失败，拒绝启动教练插件：' + (e && e.message))
    return { ok: false, code: (e && e.code) || 'E_AUDIT_PREFLIGHT', error: String((e && e.message) || e) }
  }
  // route-fallback / 教练审计落 coach.jsonl（usage 仍独立 usage.jsonl）
  const auditRouter = (rec) => {
    try { import('../../core/src/safefs.mjs').then(({ appendJsonl, logPath }) => {
      appendJsonl(logPath('coach.jsonl'), { ts: new Date().toISOString(), ...rec })
    }).catch(() => {}) } catch { /* 尽力 */ }
  }
  const router = createRouter({
    providers: (() => {
      try {
        const doc = JSON.parse(readFileSync(dataPath('providers.json'), 'utf8'))
        // S60：vision 段（智谱 GLM-5.3-Flash）——只读配置，不写回
        return { cheap: doc.cheap, flagship: doc.flagship, vision: doc.vision }
      } catch { return {} }
    })(),
    invoke: makeInvoke(ctx),
    audit: auditRouter,
  })
  const extractor = createExtractor({ router, trashDir: dataPath('trash') })
  const daily = createDailyPipeline({ router, extractor })
  const health = createHealthLedger({})
  const COACH_DIR = dataPath('coach')
  const plans = createPlanStore({ dir: COACH_DIR })

  // ---- S61·P0-2 方案A：帧增量抽取（每 5 分钟最多 1 次真实送模）----
  // 名实收敛："自动记录"不再是"等 30 分钟批处理"——视觉抽取先行入账（incremental.jsonl，
  // 不调旗舰、不生成日报），30 分钟日报轮统一归纳 + 评分 + 日报。
  // 触发条件（三条都要）：感知同意激活 + 最近 2 分钟内有感知帧登记（感知确实在跑）+ 距上次增量 ≥5 分钟。
  const INCREMENTAL_MIN_INTERVAL_MS = 5 * 60 * 1000
  const incrementalFile = join(COACH_DIR, 'incremental.jsonl')
  let lastIncrementalAt = 0
  let incrementalBusy = false
  const hasRecentPerceptionFrame = () => {
    try {
      const p = logPath('perception.jsonl')
      if (!existsSync(p)) return false
      const lines = readFileSync(p, 'utf8').trim().split('\n')
      for (let i = lines.length - 1; i >= 0 && i > Math.max(-1, lines.length - 60); i--) {
        const s = lines[i].trim()
        if (!s) continue
        try {
          const r = JSON.parse(s)
          if (r && r.kind === 'frame-registered' && Date.now() - Number(r.ts) < 2 * 60 * 1000) return true
        } catch { /* 半行跳过 */ }
      }
      return false
    } catch { return false }
  }
  const incrementalTimer = setInterval(async () => {
    if (incrementalBusy) return
    if (!consentActive()) return
    if (Date.now() - lastIncrementalAt < INCREMENTAL_MIN_INTERVAL_MS) return
    if (!hasRecentPerceptionFrame()) return
    incrementalBusy = true
    try {
      const png = await captureOne()
      if (!png) return
      lastIncrementalAt = Date.now()
      const r = await extractor.extract({ imagePath: png })
      // S63·P0-2：账内只落摘要（extract 已截 ≤300 字）+ 结构化字段；全文（若有）落 trash/incremental-raw 走 TTL
      const row = {
        ts: new Date().toISOString(),
        window: r.structured && r.structured.app ? r.structured.app : '（增量抽取）',
        process: r.structured && r.structured.intent ? r.structured.intent : '（增量抽取）',
        frameId: r.frameId,
        textSha256: r.textSha256,
        text: String(r.text || '').slice(0, 300),
        source: r.source || 'vision',
      }
      if (r.structured) row.structured = r.structured
      // 原文：模型若输出了超长全文（structured 解析失败时 text 即全文），落 trash 目录走既有 7 天 TTL
      if (String(r.text || '').length > 300) {
        try {
          const rawDir = dataPath(join('trash', 'incremental-raw'))
          mkdirSync(rawDir, { recursive: true })
          writeFileSync(join(rawDir, `${r.frameId}.txt`), String(r.text), 'utf8')
          row.rawFile = join('trash', 'incremental-raw', `${r.frameId}.txt`)
        } catch { /* raw 落盘失败不影响摘要入账 */ }
      }
      try {
        const { appendJsonl } = await import('../../core/src/safefs.mjs')
        appendJsonl(incrementalFile, row)
      } catch { /* 入账失败不影响本轮 */ }
      auditRouter({ kind: 'incremental-extract', frameId: r.frameId, source: r.source, structured: !!r.structured })
    } catch (e) {
      auditRouter({ kind: 'incremental-extract-failed', err: String((e && e.message) || e).slice(0, 120) })
    } finally {
      incrementalBusy = false
    }
  }, 60 * 1000)
  try { if (incrementalTimer && typeof incrementalTimer.unref === 'function') incrementalTimer.unref() } catch { /* noop */ }
  const confusion = createConfusionCoach({
    router, extractor,
    onAsk: async (info) => {
      try { if (ctx && ctx.ui && typeof ctx.ui.registerCard === 'function') ctx.ui.registerCard({ id: 'coach.ask', title: '教练问询（上下文感知）', body: String(info.question || '') }) } catch { /* 出口失败不影响返回 */ }
    },
  })

  // ---- A1：/coach ask 手动问询入口（被动/有按键）——与 idle-dwell 自动问询同一条 confusion.ask 路径 ----
  // 行为：感知同意校验 → 截屏 → extract（2B）→ 旗舰生成问询卡；冷却共用；未同意拒并审计。
  async function manualAsk(trigger = 'manual', { query = '' } = {}) {
    const q = String(query || '').trim()
    // S70·P0-1：召回类问题（"我刚刚干了啥"等）读本地历史，不碰屏幕——不需要 consent，也不抓屏
    if (q && isRecallQuery(q)) {
      return confusion.ask({ query: q, trigger, consentActive: true })
    }
    const c = readPerceptionConsent()
    if (!c.active) {
      auditRouter({ kind: 'skipped-no-consent', why: 'coach-ask' })
      return { ok: false, skipped: true, code: 'E_NO_CONSENT', reason: `感知同意未激活（mode=${c.mode}）：不发起问询（已留审计 skipped-no-consent）` }
    }
    const png = await captureOne()
    if (!png) return { ok: false, code: 'E_NO_FRAME', reason: '抓屏失败：无法发起问询' }
    const goalText = (readGoal() || {}).goal || '研究'
    const hints = recallMemories(goalText.slice(0, 12), undefined, 3).map((m) => `${m.title}：${String(m.body || '').slice(0, 80)}`)
    return confusion.ask({ imagePath: png, trigger, window: '（手动问询）', process: '（手动问询）', consentActive: true, memoryHints: hints })
  }

  // ---- 调度器三源（宿主接线：启动即挂、退出即停、崩溃自恢复） ----
  const consentActive = () => readPerceptionConsent().active
  const captureOne = async (retries = 2) => {
    // 屏幕桥在 ctx.core.screen（registry 白名单注入，与感知插件同一条通道）
    const sc = (ctx && ctx.core && ctx.core.screen) || (ctx && ctx.screen) || null
    let lastReason = sc ? 'capture-not-ok' : 'screen-bridge-missing'
    if (sc && typeof sc.captureScreen === 'function') {
      // S27：desktopCapturer 在窗口失焦时偶发失败——重试 retries 次（间隔 1s）
      for (let i = 0; i <= retries; i++) {
        try {
          const r = await sc.captureScreen()
          if (r && r.ok && r.pngPath) return r.pngPath
          lastReason = (r && (r.reason || r.code)) || 'capture-not-ok'
        } catch (e) { lastReason = String((e && e.message) || e).slice(0, 120) }
        if (i < retries) await new Promise((res) => setTimeout(res, 1000))
      }
    }
    // S69·1B：重试耗尽必须留痕（此前静默返回 null，命令看起来"成功"）
    auditRouter({ kind: 'daily-capture-failed', retries, reason: lastReason })
    return null
  }
  const runDailyRound = async (reason) => {
    if (!consentActive()) {
      auditRouter({ kind: 'skipped-no-consent', why: 'coach-scheduler', reason })
      return { skipped: true }
    }
    const png = await captureOne()
    if (!png) return { ok: false, reason: 'capture-failed' }
    const goal = (readGoal() || {}).goal || ''
    const r = await daily.run({ consentActive: true, goal, frames: [{ imagePath: png, window: '（自动捕获）', process: '（自动捕获）', source: 'perception' }] })
    auditRouter({ kind: 'scheduler-daily', reason, cached: r.cached, score: r.score })
    return r
  }
  let scheduler = null
  let planTimer = null
  try {
    scheduler = createScheduler({
      dir: dataPath('coach'),
      isAlive: (pid) => { try { process.kill(pid, 0); return true } catch { return false } },
      onTrigger: async (kind, info) => {
        if (kind === 'interval') return runDailyRound('interval')
        if (kind === 'idle-dwell') {
          if (!consentActive()) { auditRouter({ kind: 'skipped-no-consent', why: 'coach-scheduler', reason: 'idle-dwell' }); return { skipped: true } }
          const png = await captureOne()
          if (png) {
            // S26·P1：问询上下文接二级记忆（按目标 recall；无记忆则回落轨迹）
            const goalText = (readGoal() || {}).goal || '研究'
            const hints = recallMemories(goalText.slice(0, 12), undefined, 3).map((m) => `${m.title}：${String(m.body || '').slice(0, 80)}`)
            await confusion.ask({ imagePath: png, trigger: 'auto-dwell', window: '（自动捕获）', process: '（自动捕获）', consentActive: true, memoryHints: hints })
          }
          return
        }
        if (kind === 'threshold') {
          auditRouter({ kind: 'threshold-trigger', why: 'coach-scheduler' })
          return
        }
        if (kind === 'plan-due') {
          // S32·2：计划到期提醒卡（同一计划只提醒一次，调度器层去重）
          auditRouter({ kind: 'plan-due', id: info && info.id })
          try { plans.markReminded(info.id) } catch { /* 计划账镜像失败不影响提醒 */ }
          try {
            if (ctx && ctx.ui && typeof ctx.ui.registerCard === 'function') {
              ctx.ui.registerCard({ id: 'coach.plan-due', title: '计划到期提醒', body: `计划到期：${(info && info.text) || info.id}。完成请 /coach plans done ${info.id}（仅作提醒，不代你决定）。` })
            }
          } catch { /* 出口失败不影响调度 */ }
          return
        }
      },
    })
    scheduler.start()
    // S32·2：计划到期驱动——每 60s 把到期计划喂给调度器 threshold 源（unref，不阻塞进程退出）。
    try {
      planTimer = setInterval(() => {
        try { scheduler.feed({ duePlans: plans.duePlans() }).catch(() => {}) } catch { /* 忽略 */ }
      }, 60000)
      if (planTimer && typeof planTimer.unref === 'function') planTimer.unref()
    } catch { planTimer = null }
  } catch (e) {
    if (e instanceof SchedulerError && e.code === 'E_ALREADY_RUNNING') {
      log.warn('coach: 调度器已有存活实例（单例）——本实例不重复挂接')
      scheduler = null
    } else {
      log.warn('coach: 调度器启动失败（不影响其它命令）：' + (e && e.message))
      scheduler = null
    }
  }

  if (ctx && ctx.ui && typeof ctx.ui.registerCard === 'function') {
    ctx.ui.registerCard({ id: 'coach.status', title: '全能教练', body: '/coach goal set 定目标，/coach blueprint regen 生成蓝图；/coach run-daily 手动跑一轮；目标+蓝图摘要自动进对话 system（≤700 token）。' })
  }
  if (!(ctx && ctx.ui && typeof ctx.ui.registerCommand === 'function')) {
    log.warn('coach: 宿主未提供 ui.registerCommand')
    return { ok: false }
  }

  // S73：开发者 Agent 接口（/dev）——与 CLI tools\dev-agent.mjs 共享同一实现（不绕护栏）
  const devHandler = createDevHandler({ ctx, router, extractor, confusion, auditRouter })
  ctx.ui.registerCommand({
    name: 'dev',
    title: '开发者 Agent 接口',
    description: '/dev shot [--label x] ｜ ask "<问题>" [--mode auto|chat|recall] ｜ prompt get|set|history|rollback ｜ log tail|grep ｜ bench --suite <path.json>',
    run: (rest) => devHandler.run(rest),
  })

  ctx.ui.registerCommand({
    name: 'ui',
    title: 'UI 单步（白名单+六件套）',
    description: '/ui list｜/ui allow <窗口正则> [控件,逗号分隔] --yes｜/ui deny <窗口正则>｜/ui run <action> <窗口正则> [控件] --confirm',
    run(rest) {
      // S52·修真 bug：原来是 `const { uiList, … } = { uiList, … }` —— 右侧对象字面量引用的是
      // **自己正在声明的 const**（暂时性死区），/ui 一执行就抛
      // "Cannot access 'uiList' before initialization"。直接用 import 进来的名字即可。
      // 顺带修 `split(/s+/)`：少了反斜杠，那个正则是匹配字面 "s"，参数永远切不开。
      const parts = String(rest || '').trim().split(/\s+/)
      const sub = (parts[0] || '').toLowerCase()
      if (sub === 'list') {
        const r = uiList()
        return { ok: r.ok, text: r.text || r.reason }
      }
      if (sub === 'allow') {
        const yes = /--yes/.test(rest)
        const regex = parts[1] || ''
        const ctrls = (parts[2] || '').split(',').filter(Boolean)
        const r = uiAllow({ titleRegex: regex, allowed: ctrls, doubleConfirm: yes })
        return { ok: r.ok, text: r.ok ? r.text + '（二次确认已留审计）' : r.reason }
      }
      if (sub === 'deny') {
        const r = uiDeny({ titleRegex: parts[1] || '' })
        return { ok: r.ok, text: r.text || r.reason }
      }
      if (sub === 'run') {
        const action = parts[1] || ''
        const windowRegex = parts[2] || ''
        const controlName = parts[3] || ''
        const r = uiStep({ action, windowRegex, controlName, confirmGranted: /--confirm/.test(rest) })
        if (!r.ok && r.describe) return { ok: false, code: r.code, text: r.describe }
        return { ok: r.ok, text: (r.ok ? '已执行（前后截图：' + (r.shots || []).length + ' 张）' : '拒绝：' + (r.code || '') + ' ' + (r.reason || '')) }
      }
      return { ok: false, text: '用法：/ui list｜/ui allow｜/ui deny｜/ui run <action> <窗口> [控件] --confirm' }
    },
  })

  ctx.ui.registerCommand({
    name: 'coach',
    title: '全能教练：目标与蓝图',
    description: USAGE,
    run: async (rest = '') => {
      const parts = String(rest || '').trim().split(/\s+/).filter(Boolean)
      const sub = (parts[0] || '').toLowerCase()
      const sub2 = (parts[1] || '').toLowerCase()
      try {
        if (sub === 'goal') {
          if (sub2 === 'set') {
            const text = String(rest).trim().slice(String(rest).indexOf('set') + 3).trim()
            const rec = setGoal(text)
            return { ok: true, text: `目标已设定：${rec.goal}\n（已进入对话 system 摘要，≤700 token）` }
          }
          if (sub2 === 'show' || sub2 === '') {
            const g = readGoal()
            return { ok: true, text: g ? `目标：${g.goal}\n更新于：${g.updatedAt}（来源：${g.source}）` : '尚未设定目标。用 /coach goal set <目标> 设定。' }
          }
          return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: USAGE } }
        }
        if (sub === 'blueprint') {
          if (sub2 === 'show' || sub2 === '') {
            const bp = readBlueprint()
            return { ok: true, text: bp ? bp.slice(0, 900) : '蓝图尚未生成。用 /coach blueprint regen 生成，或 /coach blueprint edit <全文> 直接写入。' }
          }
          if (sub2 === 'edit') {
            const text = String(rest).trim().slice(String(rest).indexOf('edit') + 4).trim()
            const body = writeBlueprint(text, { source: 'command' })
            return { ok: true, text: `蓝图已写入（${body.length} 字符）。外部编辑 data\\coach\\blueprint.md 后 show 即时生效。` }
          }
          if (sub2 === 'regen') {
            const r = await regenBlueprint({ router })
            return { ok: true, text: `蓝图已再生成（来源：${r.source}${r.fallback ? '，LLM 失败回落模板' : '，' + r.providerId + '/' + r.model}）：\n${r.body.slice(0, 600)}` }
          }
          return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: USAGE } }
        }
        if (sub === 'run-daily') {
          // S63·P1-1：命令行/命令入口跑一次日报轮（抓屏 → 合并增量 → 归纳评分出日报）。
          // S69·1B：并入旧死代码块里独有的 consent 前置检查（命令入口也 upfront 报 E_NO_CONSENT）
          if (!consentActive()) { auditRouter({ kind: 'skipped-no-consent', why: 'coach-run-daily' }); return { ok: false, code: 'E_NO_CONSENT', ui: { kind: 'error', message: '感知同意未激活：不跑日报轮（已留审计）' } } }
          const png = await captureOne()
          if (!png) return { ok: false, code: 'E_NO_FRAME', ui: { kind: 'error', message: '抓屏失败：无法跑日报轮' } }
          const r = await daily.run({
            consentActive: true,
            frames: [{ imagePath: png, window: '（命令触发）', process: '（命令触发）', source: 'command' }],
            goal: (readGoal() || {}).goal || '',
          })
          if (r.skipped) return { ok: false, code: 'E_SKIPPED', ui: { kind: 'info', message: r.reason || '本轮跳过' } }
          if (!r.ok) return { ok: false, code: 'E_DAILY', ui: { kind: 'error', message: String(r.error || '日报轮失败') } }
          return { ok: true, text: `日报轮完成：轨迹 ${r.trajectoryCount} 条、评分 ${r.score}${r.cached ? '（缓存命中）' : ''}、报告 ${r.reportPath || '—'}` }
        }
        if (sub === 'run-incremental') {
          // S63·P1-1：手动触发一次增量抽取（与自动增量轮同路径，绕过 5 分钟限流的"距上次"检查由调用方自行控制；
          // 这里仍尊重 consent 与抓屏）。便于验收与演示。
          if (!consentActive()) return { ok: false, code: 'E_NO_CONSENT', ui: { kind: 'error', message: '感知同意未激活：不增量抽取' } }
          const png = await captureOne()
          if (!png) return { ok: false, code: 'E_NO_FRAME', ui: { kind: 'error', message: '抓屏失败' } }
          const r = await extractor.extract({ imagePath: png })
          // S69·1B：空帧/失败帧不入增量账（extract 已审计 skipped-empty-frame）
          if (!r || r.ok === false) return { ok: false, code: (r && r.code) || 'E_EMPTY_FRAME', ui: { kind: 'info', message: '空帧/失败帧：未入增量账' } }
          try {
            const { appendJsonl } = await import('../../core/src/safefs.mjs')
            appendJsonl(join(COACH_DIR, 'incremental.jsonl'), {
              ts: new Date().toISOString(),
              // S71·P0-1：不写占位串——应用名取 structured.app，其次 text 前 20 字
              window: (r.structured && r.structured.app) ? String(r.structured.app) : (String(r.text || '').replace(/\s+/g, ' ').trim().slice(0, 20) || '（未知）'),
              process: (r.structured && r.structured.intent) ? String(r.structured.intent) : ((r.structured && r.structured.app) ? String(r.structured.app) : (String(r.text || '').replace(/\s+/g, ' ').trim().slice(0, 20) || '（未知）')),
              frameId: r.frameId,
              textSha256: r.textSha256,
              text: String(r.text || '').slice(0, 300),
              source: r.source || 'vision',
              triggerSource: 'command', // S69·1B：命令触发 → 日报轮合并时不计入轨迹
              ...(r.structured ? { structured: r.structured } : {}),
            })
          } catch { /* 入账失败不阻断回执 */ }
          auditRouter({ kind: 'incremental-extract', frameId: r.frameId, source: r.source, trigger: 'command' })
          return { ok: true, text: `增量抽取完成：frameId=${r.frameId} source=${r.source} 摘要 ${String(r.text || '').length} 字（已入 incremental.jsonl，等日报轮合并）` }
        }
        if (sub === 'ask') {
          // S70·P0-1：取出 /coach ask 后的问题文本（此前被丢弃 → input.query 恒 undefined，召回永不触发）
          const q = parts.slice(1).join(' ').trim()
          const r = await manualAsk('manual', { query: q })
          if (r.skipped) return { ok: false, code: 'E_NO_CONSENT', ui: { kind: 'error', message: r.reason } }
          if (r.debounced) return { ok: false, code: 'E_ASK_DEBOUNCE', ui: { kind: 'info', message: r.reason } }
          if (r.cooledDown) return { ok: false, code: 'E_COOLED_DOWN', ui: { kind: 'info', message: r.reason } }
          if (!r.ok) return { ok: false, code: 'E_ASK_FAILED', ui: { kind: 'error', message: '问询生成失败（详见教练审计 coach.jsonl）' } }
          // 召回：回包 text = 召回答案本身（含范围首行 + HH:MM + frameId）
          if (r.recall) return { ok: true, text: r.question, recall: true, range: r.range, persist: true }
          // 空问题：说明"未指定问题，基于当前屏幕"
          const prefix = q ? '' : '（未指定问题，基于当前屏幕）\n'
          const nTraj = r.context ? r.context.recentTrajectory : '?'
          return { ok: true, text: `${prefix}问询卡（上下文感知，仅作参考/建议）：\n${r.question}\n\n（基于最近 ${nTraj} 条轨迹 + 相关记忆生成）`, persist: true }
        }
        if (sub === 'chain') {
          // S39·F1：证据链可视化（只读真实查询）
          const cid = parts.slice(1).join(' ').trim()
          const store = resolveLifecycleStore(ctx)
          if (!store) return { ok: false, code: 'E_NO_STORE', ui: { kind: 'error', message: '生命周期库不可用（未注入/未 bootstrap）' } }
          try {
            if (!cid) {
              const latest = store._db ? store._db.prepare('SELECT id FROM claim ORDER BY id DESC LIMIT 1').get() : null
              if (!latest) return { ok: true, text: '当前没有任何结论（claim 表为空）——先用截图→结论挂出证据链。' }
              const chain = buildEvidenceChain({ claimId: latest.id, store })
              if (chain.empty) return { ok: true, text: noEvidenceText(latest.id) }
              return { ok: true, text: renderChainMd(chain) }
            }
            const chain = buildEvidenceChain({ claimId: cid, store })
            if (!chain.ok) return { ok: false, code: 'E_CHAIN', ui: { kind: 'error', message: chain.text } }
            if (chain.empty) return { ok: true, text: noEvidenceText(cid) }
            return { ok: true, text: renderChainMd(chain) }
          } catch (e) {
            return { ok: false, code: 'E_CHAIN', ui: { kind: 'error', message: String((e && e.message) || e).slice(0, 140) } }
          }
        }
        if (sub === 'redteam') {
          // S39·F2：红队面板（一键复跑同一脚本）
          const r = runRedteamPanel()
          return { ok: true, text: renderRedteamPanel(r) }
        }
        if (sub === 'usage') {
          // S39·F7：用量卡（真实查询 usage.jsonl）
          const c = buildUsageCard({})
          return { ok: true, text: c.text }
        }
        if (sub === 'voice') {
          // S39·F4：语音隐私开关 + 状态卡
          const arg = parts.slice(1).join(' ').trim()
          if (arg === 'on' || arg === 'off') {
            const r = setVoiceEnabled(arg === 'on')
            const lines = ['语音已' + (r.config.enabled ? '开启' : '关闭') + '。']
            if (r.briefing) lines.push('（首次开启说明）' + r.briefing)
            lines.push(voiceStatusCard(r.config))
            return { ok: true, text: lines.join('\n') }
          }
          if (arg === 'test') {
            const r = gatedTranscribe({}, {})
            return { ok: r.ok, text: r.ok ? '转写放行（注入转写器后可用）' : r.reason, ...(r.ok ? {} : { code: r.code }) }
          }
          return { ok: true, text: voiceStatusCard(readVoiceConfig()) }
        }
        if (sub === 'memory' && parts.slice(1).join(' ').trim().startsWith('view')) {
          // S42·A2：四层记忆视图（只读）
          const { buildMemoryView } = await import('./memory-view.mjs')
          const v = buildMemoryView({})
          return { ok: v.ok, text: v.text }
        }
        if (sub === 'oneclick') {
          // S42·A1：一键成结论（renderer→IPC→main 直调服务；无 CDP）
          const { runOneClickClaim } = await import('./one-click.mjs')
          const ev = ctx && ctx.core && ctx.core.lastEvidence ? ctx.core.lastEvidence : {}
          const r = await runOneClickClaim({ lastAssistantText: (ctx && ctx.core && ctx.core.lastAssistantText) || parts.slice(1).join(' '), evidence: ev })
          const lines = r.steps.map((s) => `${s.ok ? '✓' : '✗'} 第${s.step}步 ${s.name}：${s.detail}`)
          if (r.downgrade) lines.push('⚠ ' + r.downgrade)
          if (r.error && !r.downgrade) lines.push('✗ 失败：' + r.error)
          if (r.md) lines.push('导出：' + r.md + (r.docx ? ' + docx' : ''))
          return { ok: r.ok, text: lines.join('\n') }
        }
        if (sub === 'mindmap') {
          // S37·B：思维导图（/mem recall + 蓝图 + 最近轨迹 → ≥3 层 → PNG + mermaid + 存笔记）
          const customOut = (rest.match(/--out\s+(\S+)/) || [])[1]
          try {
            const r = await renderMindmap({ query: '研究 方向 综述 目标' })
            const saved = saveToNotes(r)
            return { ok: true, text: [
              '思维导图已生成' + (r.cached ? '（内容哈希命中缓存，未重复渲染）' : '') + '：',
              '· PNG：' + r.pngPath + '（' + r.size.width + '×' + r.size.height + '）',
              '· mermaid：' + r.mermaidPath,
              '· 已存笔记库：' + saved.pngDst,
              '· 来源：' + r.data.sources,
              '· contentHash：' + r.contentHash.slice(0, 12),
            ].join('\n') }
          } catch (e) {
            if (e instanceof MindmapError && e.code === 'E_EMPTY_MINDMAP') {
              return { ok: true, text: '暂无可画内容：记忆/蓝图/轨迹三类全空。建议先 /coach goal set 设目标，并用对话沉淀几条事实后再试。（不编造节点）' }
            }
            return { ok: false, code: (e && e.code) || 'E_MINDMAP', ui: { kind: 'error', message: String((e && e.message) || e) } }
          }
        }
        if (sub === 'qa') {
          // S37·A：问答留痕 list/search（独立类型：不写 claim、不挂证据闸、不标 published）
          const qaRest = parts.slice(1).join(' ')
          if (qaRest.startsWith('list')) {
            const lim = Math.max(1, Math.min(50, Number((qaRest.match(/--limit\s+(\d+)/) || [])[1]) || 5))
            const r = listQa({ limit: lim })
            return { ok: true, text: r.text }
          }
          if (qaRest.startsWith('search')) {
            const word = qaRest.replace(/^search\s*/, '').trim()
            const r = searchQa(word)
            if (!r.ok) return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: r.text } }
            return { ok: true, text: r.text }
          }
          return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '用法：/coach qa list [--limit N]｜/coach qa search <关键词>' } }
        }
        if (sub === 'weekly') {
          // S32·1：周报聚合 + 评分趋势图（调 chart-skill）
          const w = writeWeeklyReport({ dir: COACH_DIR })
          let chartPath = null
          let chartErr = null
          try {
            const c = await buildWeeklyTrendChart({ agg: w.agg, outDir: dataPath('artifacts') })
            chartPath = c.pngPath
          } catch (e) { chartErr = String((e && e.message) || e) }
          const t = w.agg.totals
          return {
            ok: true,
            text: [
              `周报（${w.agg.weekKey}，${w.agg.start} ~ ${w.agg.end}）${w.cached ? '（幂等：内容未变，未重写）' : ''}：`,
              `· 轨迹：${t.trajectory} 条｜专注 ${t.focusMin} 分钟｜娱乐 ${t.entertainmentMin} 分钟｜平均评分 ${t.avgScore == null ? '无' : t.avgScore}`,
              `· 周报：${desensitizePath(w.path)}`,
              chartPath ? `· 趋势图：${desensitizePath(chartPath)}` : `· 趋势图：未生成（${chartErr}）`,
              '',
              '趋势判断：',
              ...w.agg.trends.map((x, i) => `${i + 1}. ${x}`),
            ].join('\n'),
          }
        }
        if (sub === 'plans') {
          // S32·2：计划闭环——add / list / done / drop
          const restTxt = String(rest).trim()
          const afterPlans = restTxt.slice(restTxt.toLowerCase().indexOf('plans') + 5).trim()
          const a = afterPlans.split(/\s+/).filter(Boolean)
          const op = (a[0] || 'list').toLowerCase()
          if (op === 'list' || !afterPlans) {
            const all = plans.list()
            if (!all.length) return { ok: true, text: '（暂无计划——/coach plans add <内容> [--due YYYY-MM-DD] 添加；日报建议可提升为计划）' }
            return {
              ok: true,
              text: `共 ${all.length} 条：\n` + all.slice(-15).map((p) => `· [${p.status}${p.reminded ? '·已提醒' : ''}] ${p.id} ${p.text}${p.dueAt ? '（due ' + String(p.dueAt).slice(0, 10) + '）' : ''}`).join('\n'),
            }
          }
          if (op === 'add') {
            let text = a.slice(1).join(' ').trim()
            if (!text) return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '用法：/coach plans add <内容> [--due YYYY-MM-DD]' } }
            let dueAt = null
            const di = text.indexOf('--due')
            if (di >= 0) { dueAt = text.slice(di + 5).trim(); text = text.slice(0, di).trim() }
            const rec = plans.add({ text, dueAt })
            return { ok: true, text: `计划已添加：${rec.id}｜${rec.text}${rec.dueAt ? '（到期 ' + String(rec.dueAt).slice(0, 10) + '）' : ''}` }
          }
          if (op === 'done') {
            const id = a[1]
            if (!id) return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '用法：/coach plans done <id>' } }
            const r = plans.done(id)
            return { ok: true, text: `已勾销计划 ${id}（${r.already ? '此前已完成' : '完成，已入记忆 + 审计'}）` }
          }
          if (op === 'drop') {
            const id = a[1]
            if (!id) return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '用法：/coach plans drop <id>' } }
            const r = plans.drop(id)
            return { ok: true, text: `已放弃计划 ${id}（${r.already ? '此前已放弃' : '已入记忆 + 审计'}）` }
          }
          return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '用法：/coach plans add|list|done|drop' } }
        }
        if (sub === 'status') {
          const c = readPerceptionConsent()
          const s = scheduler ? scheduler.state() : null
          const st = usageStats()
          return {
            ok: true,
            text: [
              '全能教练状态：',
              `· 感知同意：mode=${c.mode}（${c.active ? '激活' : '未激活'}，来源 ${c.source}）`,
              `· 调度器：${s ? (s.running ? (s.paused ? '运行中（已暂停）' : '运行中') : '未运行') : '未挂接'}`,
              s ? `· 触发计数：interval ${s.counters.interval}｜idle-dwell ${s.counters['idle-dwell']}｜threshold ${s.counters.threshold}` : '',
              `· LLM 调用：${st.total} 次`,
            ].filter(Boolean).join('\n'),
          }
        }
        return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: USAGE } }
      } catch (e) {
        const code = (e instanceof CoachError || e instanceof SchedulerError) ? e.code : ((e && e.code) || 'E_COACH')
        return { ok: false, code, ui: { kind: 'error', message: String((e && e.message) || e) } }
      }
    },
  })

  ctx.ui.registerCommand({
    name: 'usage',
    title: '模型用量统计',
    description: '用法：/usage（分模型统计 usage.jsonl 的调用/成功/回落/token）',
    run: async () => {
      const s = usageStats()
      const lines = [`LLM 调用统计：共 ${s.total} 次`]
      for (const m of s.byModel) {
        lines.push(`· ${m.providerId}/${m.model}：${m.calls} 次（成功 ${m.ok}，回落 ${m.fallback}，tokens ${m.tokens}）`)
      }
      if (s.byModel.length === 0) lines.push('（暂无记录）')
      if (s.todayFlagship) {
        const f = s.todayFlagship
        lines.push('')
        lines.push(`今日旗舰调用：${f.calls} 次，tokens 合计 ${f.tokens}`)
        lines.push(`费用区间（仅供参考）：${f.feeInterval}`)
      }
      return { ok: true, text: lines.join('\n') }
    },
  })

  // S32·3 隐私仪表盘（只读）：/privacy 查看；/privacy export 导出 privacy-YYYYMMDD.md
  ctx.ui.registerCommand({
    name: 'privacy',
    title: '隐私仪表盘（只读）',
    description: '用法：/privacy｜/privacy export（导出 privacy-YYYYMMDD.md，路径脱敏，只读不删）',
    run: async (rest = '') => {
      const sub = String(rest || '').trim().split(/\s+/)[0].toLowerCase()
      const store = resolveLifecycleStore(ctx)
      try {
        if (sub === 'export') {
          if (!store) return { ok: false, code: 'E_NO_STORE', ui: { kind: 'error', message: '隐私导出需要生命周期库（宿主未接入）' } }
          const r = exportPrivacy({ store })
          return { ok: true, text: `隐私仪表盘已导出：${desensitizePath(r.path)}` }
        }
        if (!store) return { ok: false, code: 'E_NO_STORE', ui: { kind: 'error', message: '隐私仪表盘需要生命周期库（宿主未接入）' } }
        const p = buildPrivacyDashboard({ store })
        return { ok: true, text: renderPrivacyMarkdown(p) }
      } catch (e) {
        return { ok: false, code: (e && e.code) || 'E_PRIVACY', ui: { kind: 'error', message: String((e && e.message) || e) } }
      }
    },
  })

  // S26·P1 二级记忆：/mem save|recall|list|stats|done（data\coach\memory\*.md）
  ctx.ui.registerCommand({
    name: 'mem',
    title: '教练记忆（两级·Markdown 持久化）',
    description: '用法：/mem save <标题> | <正文>｜/mem recall <关键词>｜/mem list｜/mem stats｜/mem done <file>',
    run: async (rest = '') => {
      const raw = String(rest || '').trim()
      const sub = (raw.split(/\s+/)[0] || '').toLowerCase()
      try {
        if (sub === 'save') {
          const body = raw.slice(4).trim()
          const sep = body.indexOf('|')
          const title = (sep > 0 ? body.slice(0, sep) : body).trim()
          const text = sep > 0 ? body.slice(sep + 1).trim() : ''
          if (!title) return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '用法：/mem save <标题> | <正文>' } }
          const r = saveMemory({ title, body: text, kind: 'note' })
          return { ok: true, text: `记忆已存：${r.file}\n（二级记忆 data\\coach\\memory\\，新进程可 recall）` }
        }
        if (sub === 'recall') {
          const q = raw.slice(6).trim()
          if (!q) return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '用法：/mem recall <关键词>' } }
          const hits = recallMemories(q, undefined, 5)
          if (!hits.length) return { ok: true, text: `未命中「${q}」的记忆` }
          return { ok: true, text: `命中 ${hits.length} 条：\n` + hits.map((h) => `· [${h.kind}${h.done ? '·已完成' : ''}] ${h.title}（${h.file}）`).join('\n') }
        }
        if (sub === 'list') {
          const all = listMemories()
          if (!all.length) return { ok: true, text: '（暂无记忆——/mem save 或跑一轮日报会自动入库）' }
          return { ok: true, text: `共 ${all.length} 条：\n` + all.slice(-10).map((h) => `· [${h.kind}${h.done ? '·done' : ''}] ${h.ts ? h.ts.slice(0, 10) : '?'} ${h.title}`).join('\n') }
        }
        if (sub === 'stats') {
          const all = listMemories()
          const plans = all.filter((m) => m.kind === 'plan')
          return { ok: true, text: `记忆统计：共 ${all.length} 条｜日报 ${all.filter((m) => m.kind === 'daily').length}｜计划 ${plans.length}（未完成 ${plans.filter((p) => !p.done).length}）` }
        }
        if (sub === 'done') {
          const file = raw.slice(5).trim()
          if (!file) return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '用法：/mem done <file>' } }
          markDone(file)
          return { ok: true, text: `已标记完成：${file}` }
        }
        return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '用法：/mem save|recall|list|stats|done' } }
      } catch (e) {
        return { ok: false, code: (e && e.code) || 'E_MEM', ui: { kind: 'error', message: String((e && e.message) || e) } }
      }
    },
  })

  // A1：可选全局快捷键 Control+Alt+Shift+Q → /coach ask（有按键手动问询）。
  // 宿主未提供 globalShortcut 时跳过（可选，不影响命令入口）。
  try {
    const gs = (ctx && ctx.globalShortcut)
    if (gs && typeof gs.register === 'function') {
      const KEY = 'Control+Alt+Shift+Q'
      try { gs.register(KEY, () => { manualAsk('manual').catch(() => {}) }) } catch { /* 快捷键注册失败不影响命令入口 */ }
    }
  } catch { /* 忽略 */ }

  return {
    ok: true,
    deactivate() {
      if (planTimer) { try { clearInterval(planTimer) } catch { /* 尽力 */ } }
      if (scheduler) { try { scheduler.stop() } catch { /* 尽力 */ } }
      log.info('[coach] 已停用：调度器停止，触发回路清理')
    },
    __router: router,
    __scheduler: scheduler,
  }
}

/** B1：教练健康检查（fail-closed 演练用）——返回子系统状态与降级提示，不抛错。 */
export function coachHealthCheck({ consent = readPerceptionConsent() } = {}) {
  const downgraded = !consent.active
  const message = downgraded
    ? `感知同意未激活（mode=${consent.mode}）：教练感知类功能（daily/ask）已降级跳过并留审计；记忆仍可查询。`
    : `感知同意已激活（mode=${consent.mode}）：教练全功能在线。`
  return {
    ok: true,
    downgraded,
    perception: { mode: consent.mode, active: consent.active, source: consent.source },
    message,
    subsystems: { router: true, scheduler: true, confusion: true, health: true, memory: true, weekly: true, plans: true, privacy: true },
  }
}

export default { activate, PLUGIN_ID, coachHealthCheck }
