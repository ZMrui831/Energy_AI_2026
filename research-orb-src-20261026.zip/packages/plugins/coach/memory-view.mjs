// packages/plugins/coach/memory-view.mjs
//
// S42·A2 四层记忆视图：/coach memory view —— 四层各显示 条目数/最近更新/预算占用 + 一句人话说明 + 注入样例（截断 20 行）。
// 纪律：只读零写入；计数与预算来自真实文件/真实查询；空层给"暂无+如何填充"；口径如实标注。
import { existsSync, readFileSync, statSync } from 'node:fs'
import { join } from 'node:path'
import { dataPath } from '../../core/src/safefs.mjs'

export const LAYER_BUDGETS = { digest: 700, memory: 300, longterm: 300, total: 1400 }
const TOKEN_PER_CHAR = 0.5 // 估算口径：中文 ≈ 0.5 token/字符（如实标注，非精确 tokenizer）

const estTokens = (s) => Math.ceil(String(s || '').length * TOKEN_PER_CHAR)

function fileMeta(p) {
  if (!existsSync(p)) return { exists: false, mtime: null, text: '' }
  const st = (() => { try { return statSync(p) } catch { return null } })()
  return { exists: true, mtime: st ? st.mtime.toISOString() : null, text: readFileSync(p, 'utf8') }
}

function countLongtermRows(text) {
  return text.split('\n').filter((l) => l.trim().startsWith('{')).length
}

function sampleOf(text, maxLines = 20) {
  const lines = String(text || '').split('\n').filter((l) => l.trim())
  return lines.slice(0, maxLines)
}

/**
 * 构建四层视图（只读）。
 * @returns {{ok:boolean, layers:Array, totalUsed:number, text:string}}
 */
export function buildMemoryView({ rootDoc = null } = {}) {
  const layers = []
  try {
    // L1 教练摘要：data/profile-digest.txt（预算 ≤700）
    const digestPath = dataPath('profile-digest.txt')
    const dMeta = fileMeta(digestPath)
    const digestUsed = estTokens(dMeta.text)
    layers.push({
      key: 'digest', label: 'L1 教练摘要', file: 'data/profile-digest.txt',
      entries: dMeta.exists ? 1 : 0, updatedAt: dMeta.mtime,
      budget: LAYER_BUDGETS.digest, used: Math.min(digestUsed, LAYER_BUDGETS.digest),
      raw: estTokens(digestUsed),
      note: '一段"你是谁、在做什么"的画像，每次对话都注入。',
      sample: sampleOf(dMeta.text),
      emptyHint: '暂无：正常使用几天后由教练线自动沉淀（或 /coach digest rebuild）。',
    })

    // L2 记忆要点：data/coach/qa.jsonl 的摘要（供问答留痕回看；注入段为关键词命中摘要）
    const qaPath = dataPath('coach', 'qa.jsonl')
    const qaMeta = fileMeta(qaPath)
    const qaRows = qaMeta.text.split('\n').filter((l) => l.trim()).length
    const qaText = qaMeta.text
    layers.push({
      key: 'memory', label: 'L2 记忆要点（问答留痕摘要）', file: 'data/coach/qa.jsonl',
      entries: qaRows, updatedAt: qaMeta.mtime,
      budget: LAYER_BUDGETS.memory, used: Math.min(estTokens(qaText), LAYER_BUDGETS.memory),
      raw: estTokens(qaText),
      note: '你问过的问题与答案摘要——按关键词命中后注入，不是全量灌入。',
      sample: sampleOf(qaText),
      emptyHint: '暂无：在对话里正常提问即可积累（/coach qa list 查看）。',
    })

    // L3 长期记忆：data/memory/<scope>/longterm.md（预算 ≤300）
    const ltPath = dataPath('memory', 'project', 'longterm.md')
    const ltMeta = fileMeta(ltPath)
    const ltRows = countLongtermRows(ltMeta.text)
    layers.push({
      key: 'longterm', label: 'L3 长期记忆', file: 'data/memory/project/longterm.md',
      entries: ltRows, updatedAt: ltMeta.mtime,
      budget: LAYER_BUDGETS.longterm, used: Math.min(estTokens(ltMeta.text), LAYER_BUDGETS.longterm),
      raw: estTokens(ltMeta.text),
      note: '带契约头的事实账本（写侧双闸治理），按 BM25 召回注入。',
      sample: sampleOf(ltMeta.text),
      emptyHint: '暂无：聊天时说一句事实（如"我的研究方向是……"）即可沉淀。',
    })

    // L4 轨迹信号：data/coach/trajectory.jsonl（总预算层展示合计）
    const trajPath = dataPath('coach', 'trajectory.jsonl')
    const tMeta = fileMeta(trajPath)
    const tRows = tMeta.text.split('\n').filter((l) => l.trim()).length
    layers.push({
      key: 'trajectory', label: 'L4 轨迹信号', file: 'data/coach/trajectory.jsonl',
      entries: tRows, updatedAt: tMeta.mtime,
      budget: LAYER_BUDGETS.total, used: 0,
      raw: estTokens(tMeta.text),
      note: '1Hz 前台窗口轨迹（只记元数据不记内容）——供主动询问与日报，不整段注入。',
      sample: sampleOf(tMeta.text),
      emptyHint: '暂无：开启屏幕感知（session 同意）后自动积累。',
    })

    const totalUsed = layers.slice(0, 3).reduce((a, l) => a + l.used, 0)
    layers[3].used = totalUsed // L4 行展示"合计注入占用"
    const L = ['四层记忆视图（只读）', '']
    for (const l of layers) {
      L.push(`▸ ${l.label}　${l.entries} 条 · 更新 ${l.updatedAt ? l.updatedAt.slice(0, 16).replace('T', ' ') : '—'} · 预算 ${l.used}/${l.budget} tok`)
      L.push(`   ${l.note}`)
      if (l.sample.length) {
        L.push('   注入样例（截断 20 行）：')
        for (const s of l.sample) L.push('     ' + s.slice(0, 90))
      } else {
        L.push(`   ${l.emptyHint}`)
      }
      L.push('')
    }
    L.push(`合计注入占用：${totalUsed}/1400 tok（估算口径：中文 ≈0.5 token/字符，非精确 tokenizer）`)
    return { ok: true, layers, totalUsed, text: L.join('\n') }
  } catch (e) {
    return { ok: false, text: '视图构建失败：' + String((e && e.message) || e).slice(0, 120) }
  }
}

export default { buildMemoryView, LAYER_BUDGETS }
