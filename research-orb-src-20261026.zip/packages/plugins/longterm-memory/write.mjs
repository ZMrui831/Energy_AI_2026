// packages/plugins/longterm-memory/write.mjs
//
// S29/S30：写侧 observeTurn({userText, assistantText}) —— runTurn 成功后调用。
// 纪律：
//   · 用户侧：事实过滤（提问/请求/寒暄/纯回执不写；内核 isNoiseFact + 我们的规则双闸）；
//   · 助手侧（S30 对齐 Node 适配器契约）：只收"语义更新"白名单（已更新|改为|现在是|改成|不再|取消），
//     纯回执（"好的"/"收到"）一律丢弃——模型回复不作为自由事实源，只承认显式更新句；
//   · 单轮合计 ≤2 条、单条 ≤400 字；writeGovernance/enabled 关 → 跳过；
//   · scope 分域（config.scope，默认 project；project 与 global 写不同文件）；
//   · 异常静默跳过（不拖停宿主对话）；diag 只记计数（含 skipped 原因）。
import { existsSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, DATA_DIR, appendJsonl, dataPath } from '../../core/src/safefs.mjs'
import { createMemory } from './core/api.js'
import { isNoiseFact as coreIsNoiseFact } from './core/compile.js'
import { readLongTermConfig, longtermFileFor } from './config.mjs'

export const LONGTERM_DIR = dataPath('memory')
export const MAX_PER_TURN = 2
export const MAX_CHARS = 400

const QUESTION_RE = /[?？]$|^(请问|问一下|什么是|为什么|怎么|如何|是否|能不能|可以不可以|吗$)/
const PLEASANTRY_RE = /^(你好|您好|hi|hello|嗨|谢谢|感谢|好的|收到|嗯|哦|ok|OK|在吗|早|晚安)[\s!！。.~～]*$/
const PURE_ACK_RE = /^(收到|好的|明白了|了解|知道了|行|可以|嗯嗯|赞|thanks|thx|got it)[\s!！。.~～]*$/i
/** S30：助手侧语义更新白名单（对齐 Node 适配器契约）——只有显式更新句才可沉淀。 */
export const ASSIST_UPDATE_RE = /(已更新|改为|现在是|改成|不再|取消)/

/** 我们的写侧双闸：先规则过滤（问句/寒暄/纯回执/过短），再交内核 isNoiseFact。 */
export function isWritableFact(text, coreNoise = null) {
  const t = String(text || '').trim()
  if (!t || t.length < 8) return false                 // 过短无信息量
  if (QUESTION_RE.test(t)) return false                // 提问不写
  if (PLEASANTRY_RE.test(t) || PURE_ACK_RE.test(t)) return false // 寒暄/纯回执不写
  if (/^[!！。.~～\s]+$/.test(t)) return false          // 纯标点
  if (typeof coreNoise === 'function') {
    try { if (coreNoise(t)) return false } catch { /* 内核判定异常不拦 */ }
  }
  return true
}

/** 助手侧准入：仅"语义更新"白名单命中且非纯回执（S30）。 */
export function isWritableAssistFact(text) {
  const t = String(text || '').trim()
  if (!t || t.length < 8) return false
  if (PURE_ACK_RE.test(t)) return false
  return ASSIST_UPDATE_RE.test(t)
}

/**
 * 一轮对话后的事实抽取写入。
 * @param {{userText?:string, assistantText?:string, root?:string, sessionId?:string}} turn
 * @returns {{written:number, skipped:string, reason?:string}}
 */
export function observeTurn(turn = {}) {
  try {
    // S36：双模数据根——显式 turn.root 保持 <root>/data 旧布局；缺省走 DATA_DIR。
    const projRoot = turn.root != null ? turn.root : undefined
    const dataRoot = projRoot != null ? join(projRoot, 'data') : DATA_DIR
    const cfg = readLongTermConfig({ root: projRoot })
    if (!cfg.enabled) return { written: 0, skipped: 'disabled', reason: 'enabled=false' }
    if (!cfg.writeGovernance) return { written: 0, skipped: 'no-governance', reason: 'writeGovernance=false' }
    // 与 mkdir/diag 同一数据根，避免双重 data 拼接
    const file = join(dataRoot, 'memory', cfg.scope, 'longterm.md')
    // 两侧候选：用户侧走事实双闸；助手侧只走语义更新白名单（S30 契约）
    const candidates = []
    if (typeof turn.userText === 'string' && turn.userText.trim()) {
      candidates.push({ text: turn.userText, side: 'user', gate: (t) => isWritableFact(t, coreIsNoiseFact) })
    }
    if (typeof turn.assistantText === 'string' && turn.assistantText.trim()) {
      candidates.push({ text: turn.assistantText, side: 'assistant', gate: (t) => isWritableAssistFact(t) })
    }
    if (!candidates.length) return { written: 0, skipped: 'no-candidate' }

    mkdirSync(join(dataRoot, 'memory', cfg.scope), { recursive: true })
    const mem = createMemory({ file, now: () => Date.now() })
    let written = 0
    let skipped = ''
    for (const c of candidates) {
      if (written >= MAX_PER_TURN) break
      const text = c.text.trim().slice(0, MAX_CHARS)
      if (!c.gate(text)) { skipped = skipped || (c.side === 'user' ? 'noise-or-question' : 'assist-not-update'); continue }
      const rec = mem.remember({ text, source: 'turn', scope: cfg.scope === 'global' ? 'global' : 'project' }, { layer: 1, importance: 0.5 })
      if (rec) written += 1
    }
    // 写入后做一次轻量维护（过期/合并），异常静默
    let live = 0
    try { live = mem.store.live().length; mem.consolidate({ now: Date.now() }) } catch { /* noop */ }
    // diag：只记计数（含 skipped 原因，不记内容）——无论写没写都记一行，便于观测"过滤是否生效"
    try { appendJsonl(join(dataRoot, 'memory', cfg.scope, 'longterm.md.diag.log'), { ts: new Date().toISOString(), scope: cfg.scope, written, live, ...(skipped ? { skipped } : {}) }) } catch { /* noop */ }
    return { written, skipped: written ? '' : (skipped || 'no-fact') }
  } catch {
    return { written: 0, skipped: 'error', reason: '静默跳过' }
  }
}

export default { observeTurn, isWritableFact, isWritableAssistFact, ASSIST_UPDATE_RE, MAX_PER_TURN, MAX_CHARS }
