// lifecycle.js — 提升/降级/合并/冲突/过期（I3/I4），全部零 LLM 启发式。
//
// M0：冲突消解 + 过期 + 打分；提升/降级最简启发式骨架（重复度 / 线索词），完整策略留 M3。
// M1（整改2）：新增重复合并的分组判定 duplicateGroups（同会话内同事实的独立条目归组）。
//
// 不变量：全部纯函数，绝不抛；不读时钟（now 由调用方传入，保证 recall 字节稳定）。
// 只依赖 node: 无。

/** 触发提升/画像的线索词（总纲 §4）。 */
export const CLUE_WORDS = ["记住", "我叫", "我喜欢", "以后都", "不要", "默认", "always", "never", "prefer"];

/** 打分权重（可配、可基准调）。 */
export const DEFAULT_WEIGHTS = { relevance: 0.5, importance: 0.3, freshness: 0.2 };
/** 新鲜度半衰期（ms），默认 7 天（对齐 §4「7 天未复现则降级」）。 */
export const DEFAULT_HALFLIFE = 7 * 24 * 3600 * 1000;

function norm(v) {
  return typeof v === "string" ? v.trim().toLowerCase() : "";
}

/**
 * 综合分：score = w1·相关度 + w2·重要度 + w3·新鲜度，夹到 [0,1]。
 * @param {object} rec 规范记录
 * @param {{relevance?: number, now?: number, weights?: object, halflife?: number}} [opts]
 * @returns {number}
 */
export function scoreRecord(rec, opts = {}) {
  if (!rec) return 0;
  const w = { ...DEFAULT_WEIGHTS, ...(opts.weights || {}) };
  const relevance = clamp01(opts.relevance);
  const importance = clamp01(rec.importance);
  const freshness = freshnessOf(rec, opts.now, opts.halflife);
  return clamp01(w.relevance * relevance + w.importance * importance + w.freshness * freshness);
}

function freshnessOf(rec, now, halflife) {
  const hl = Number.isFinite(halflife) && halflife > 0 ? halflife : DEFAULT_HALFLIFE;
  if (!Number.isFinite(now) || !Number.isFinite(rec.ts) || rec.ts <= 0) return 0; // 无时钟 → 中性 0，保证确定性
  const age = Math.max(0, now - rec.ts);
  return Math.pow(0.5, age / hl);
}

function clamp01(v) {
  const n = typeof v === "number" && Number.isFinite(v) ? v : 0;
  return n < 0 ? 0 : n > 1 ? 1 : n;
}

/**
 * 找冲突：同 (主体 s, 谓词 p) 但客体 o 不同的**存活**记录（总纲 §4）。
 * @param {object} incoming 规范化的新记录
 * @param {object[]} liveRecords 存活记录（非墓碑）
 * @returns {object|null} 被取代的旧记录，或 null
 */
export function findConflict(incoming, liveRecords) {
  if (!incoming || !norm(incoming.s) || !norm(incoming.p)) return null;
  const s = norm(incoming.s), p = norm(incoming.p), o = norm(incoming.o);
  for (const r of liveRecords || []) {
    if (!r || r.id === incoming.id || r.tombstone) continue;
    if (norm(r.s) === s && norm(r.p) === p && norm(r.o) !== o) return r;
  }
  return null;
}

/**
 * 是否命中线索词（→ 候选提升到 L2/L3）。
 * @param {object} rec
 * @returns {boolean}
 */
export function hasClue(rec) {
  const hay = [rec && rec.text, rec && rec.o].filter((x) => typeof x === "string").join(" ").toLowerCase();
  return CLUE_WORDS.some((w) => hay.includes(w.toLowerCase()));
}

/**
 * 提升/降级启发式：
 *   - 命中线索词 或 复现次数 ≥2 → 语义层(2)；跨会话复现 ≥2 且线索词 或 复现 ≥3 → 画像层(3)
 *   - 否则维持情节层(1)
 * @param {object} rec
 * @param {{repeats?: number, sessions?: number}} [stats]
 * @returns {number} 建议 layer（0..3）
 */
export function suggestLayer(rec, stats = {}) {
  const repeats = Number.isFinite(stats.repeats) ? stats.repeats : 1;
  const sessions = Number.isFinite(stats.sessions) ? stats.sessions : 1;
  const clue = hasClue(rec);
  if ((clue && sessions >= 2) || repeats >= 3) return 3;
  if (clue || repeats >= 2) return 2;
  return 1;
}

/**
 * 过期：ttl 非空且 now - ts > ttl 的存活记录应打墓碑。
 * 纯判定，不改数据（改数据由 api.consolidate 落）。
 * @param {object[]} records
 * @param {{now?: number}} opts
 * @returns {object[]} 已过期（应墓碑）的记录数组
 */
export function findExpired(records, opts = {}) {
  const now = opts.now;
  if (!Number.isFinite(now)) return [];
  const out = [];
  for (const r of records || []) {
    if (!r || r.tombstone) continue;
    if (Number.isFinite(r.ttl) && r.ttl >= 0 && Number.isFinite(r.ts) && now - r.ts > r.ttl) out.push(r);
  }
  return out;
}

// ── 重复合并（整改2）：同一会话内的重复条目按 (scope, sessionId, 归一化文本) 归组 ──

/** 记录的主会话 id：优先取 provenance 首项的 sessionId，退回 source。 */
export function primarySessionId(rec) {
  const prov = rec && Array.isArray(rec.provenance) ? rec.provenance : [];
  for (const p of prov) {
    if (p && typeof p.sessionId === "string" && p.sessionId) return p.sessionId;
  }
  return rec && typeof rec.source === "string" ? rec.source : "";
}

/** 归一化文本键：text 优先，退回 (s,p,o) 拼接；trim + 小写。 */
export function textKeyOf(rec) {
  if (!rec) return "";
  if (typeof rec.text === "string" && rec.text.trim()) return rec.text.trim().toLowerCase();
  return [rec.s, rec.p, rec.o].map((x) => (x == null ? "" : String(x).trim())).join(" ").toLowerCase();
}

/**
 * 把存活记录按 (scope, sessionId, 归一化文本) 归组，只返回长度 > 1 的重复组。
 * 纯函数，不改动入参。分组顺序确定（按组内首个出现记录）。键用 JSON.stringify 避免分隔符歧义。
 * @param {object[]} records
 * @returns {object[][]}
 */
export function duplicateGroups(records) {
  const map = new Map();
  for (const r of records || []) {
    if (!r || r.tombstone || typeof r.id !== "string") continue;
    const key = JSON.stringify([r.scope, primarySessionId(r), textKeyOf(r)]);
    let arr = map.get(key);
    if (!arr) { arr = []; map.set(key, arr); }
    arr.push(r);
  }
  const groups = [];
  for (const arr of map.values()) if (arr.length > 1) groups.push(arr);
  return groups;
}

/**
 * 为一组重复记录挑选幸存者 + 汇总合并信息（不落库，纯计算，供 api.consolidate 应用）。
 * 幸存 = firstSeen 最早（并列取 id 字典序最小）。返回：
 *   { keepId, dropIds:[...], seenCount, firstSeen, lastSeen }
 * @param {object[]} group 同一重复组（长度 ≥2）
 */
export function planMerge(group) {
  const sorted = [...group].sort((a, b) => {
    const fa = Number.isFinite(a.firstSeen) ? a.firstSeen : (Number.isFinite(a.ts) ? a.ts : Infinity);
    const fb = Number.isFinite(b.firstSeen) ? b.firstSeen : (Number.isFinite(b.ts) ? b.ts : Infinity);
    return (fa - fb) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  });
  const keep = sorted[0];
  let seenCount = 0;
  let firstSeen = Infinity;
  let lastSeen = -Infinity;
  for (const r of sorted) {
    seenCount += Number.isFinite(r.seenCount) && r.seenCount > 0 ? r.seenCount : 1;
    const fs = Number.isFinite(r.firstSeen) ? r.firstSeen : (Number.isFinite(r.ts) ? r.ts : NaN);
    const ls = Number.isFinite(r.lastSeen) ? r.lastSeen : (Number.isFinite(r.ts) ? r.ts : NaN);
    if (Number.isFinite(fs) && fs < firstSeen) firstSeen = fs;
    if (Number.isFinite(ls) && ls > lastSeen) lastSeen = ls;
  }
  return {
    keepId: keep.id,
    dropIds: sorted.slice(1).map((r) => r.id),
    seenCount,
    firstSeen: Number.isFinite(firstSeen) ? firstSeen : (keep.ts ?? null),
    lastSeen: Number.isFinite(lastSeen) ? lastSeen : (keep.ts ?? null),
  };
}
