// evict.js — P0-2 上限与淘汰（纯函数层）。
//
// 真相源仍是 Markdown（readMemoryFile 的 {ts,sessionId,title,facts[]} 形状）；本模块**不删**
// Markdown 历史，只产出「墓碑计划」：哪些事实应被标记为不活跃（injection 时过滤掉），以及
// 淘汰前后的对照统计。墓碑落在旁挂文件 <memoryFile>.tomb（与既有 <memoryFile>.forget 同类：
// 只是生命周期元数据，不是第二份事实真相源）——删掉 .tomb 里的行即可回滚。
//
// 硬约束（对齐 core 不变量）：
//   · 纯函数：不读写磁盘、不读时钟（淘汰时间戳 now 由调用方传入）→ 同输入字节相同。
//   · 绝不抛：畸形/损坏输入退化为空计划或安全默认。
//   · 只依赖同目录 core 模块 + node: 内置；禁止 cordis/electron/网络/~/.dsh。
//
// 淘汰排序（可解释、可复核）：**层 → 新鲜度 → 引用次数 → 稳定 ID**
//   1) layer 升序：易变（情节 L1）先淘汰，画像 L3 最后（「易变优先于画像保护」）。
//   2) ts 升序：同层里旧事实先淘汰。
//   3) refCount 升序：同层同新鲜度里，被引用（跨条目复现）次数少的先淘汰。
//   4) id 升序：稳定内容哈希打破并列 → 完全确定、可复现。
// layer 复用 lifecycle.suggestLayer 的阈值（线索词/复现次数/跨会话数），线索词判定沿用
// compile 的助手回执护栏（「助手: 已记住」不算画像线索）。

import { hashId } from "./schema.js";
import { suggestLayer, hasClue } from "./lifecycle.js";
import { estimateTokens, stableKey, isAssistantFact } from "./compile.js";
import { serializeMemoryFile } from "./markdown.js";

/**
 * 默认上限。**0 = 关闭该项**（默认全关 → 不淘汰 → 注入输出与改动前逐字节一致）。
 * maxCompileTokens 是编译期 token 硬上限的声明值；生产注入实际用 lib 的 memoryBudgetTokens
 * （compileFromEntries 已强制 budgetUsed ≤ budget），此处仅供报告/CLI 记录，planEviction 不消费它。
 */
export const DEFAULT_CAPS = Object.freeze({
  // rc6 P2：默认不再是「全关」，而是一组宽松上限——只防无上限增长，正常使用永不触发。
  maxFacts: 5000,
  maxEntries: 0,
  maxChars: 2000000,   // ≈1MB
  maxBytes: 0,
  maxCompileTokens: 800,
});

function num(v) {
  return typeof v === "number" && Number.isFinite(v) ? v : 0;
}

/**
 * 归一化上限配置：非法值（负数 / NaN / 非数字 / 空）回退安全默认并记 warning，绝不抛。
 * @param {object} [cfg] 任意来源的配置（lib Config / CLI / 测试）
 * @returns {{caps: {maxFacts:number,maxEntries:number,maxChars:number,maxBytes:number,maxCompileTokens:number}, warnings: string[]}}
 */
export function resolveCaps(cfg) {
  const c = cfg && typeof cfg === "object" ? cfg : {};
  const warnings = [];
  const norm = (key, dflt) => {
    const v = c[key];
    if (v === undefined || v === null || v === "") return dflt;
    const n = Number(v);
    if (!Number.isFinite(n) || n < 0) {
      warnings.push(`${key}=${safe(v)} -> ${dflt}`);
      return dflt;
    }
    return Math.trunc(n);
  };
  return {
    caps: {
      maxFacts: norm("maxFacts", DEFAULT_CAPS.maxFacts),
      maxEntries: norm("maxEntries", DEFAULT_CAPS.maxEntries),
      maxChars: norm("maxChars", DEFAULT_CAPS.maxChars),
      maxBytes: norm("maxBytes", DEFAULT_CAPS.maxBytes),
      maxCompileTokens: norm("maxCompileTokens", DEFAULT_CAPS.maxCompileTokens),
    },
    warnings,
  };
}

function safe(v) {
  try { return JSON.stringify(v); } catch { return String(v); }
}

/**
 * 事实的稳定内容 ID：hash(sessionId + 归一化正文)。同会话同正文 → 同 ID（去重/幂等），
 * 跨会话同正文 → 不同 ID（是不同条目，各自可独立淘汰/回滚）。不含时间戳 → 重序列化后不变。
 */
export function markdownFactKey(sessionId, text) {
  return hashId({
    sessionId: typeof sessionId === "string" ? sessionId : "",
    text: stableKey(typeof text === "string" ? text.trim() : ""),
  });
}

/** 把条目拍平成带层级/引用次数/新鲜度的事实项（内部用；也导出供测试复核排序）。 */
export function annotate(entries) {
  const list = Array.isArray(entries) ? entries : [];
  const items = [];
  for (let ei = 0; ei < list.length; ei++) {
    const e = list[ei];
    if (!e || !Array.isArray(e.facts)) continue;
    for (let fi = 0; fi < e.facts.length; fi++) {
      const raw = e.facts[fi];
      const text = typeof raw === "string" ? raw.trim() : "";
      if (!text) continue;
      items.push({
        pos: `${ei}:${fi}`,
        id: markdownFactKey(e.sessionId, text),
        sessionId: typeof e.sessionId === "string" ? e.sessionId : "",
        title: typeof e.title === "string" ? e.title : "",
        ts: num(e.ts),
        text,
        key: stableKey(text),
      });
    }
  }
  // 按稳定正文键聚合：跨条目复现次数(refCount)、涉及的会话数、是否画像线索。
  const byKey = new Map();
  for (const it of items) {
    let g = byKey.get(it.key);
    if (!g) { g = { sessions: new Set(), count: 0, clue: false }; byKey.set(it.key, g); }
    if (it.sessionId) g.sessions.add(it.sessionId);
    g.count++;
    if (!isAssistantFact(it.text) && hasClue({ text: it.text })) g.clue = true;
  }
  for (const it of items) {
    const g = byKey.get(it.key);
    it.refCount = g.count;
    it.sessions = g.sessions.size;
    // 复用 suggestLayer 的阈值：线索词已被助手护栏过滤（非线索时传空文本 → hasClue=false）。
    it.layer = suggestLayer({ text: g.clue ? it.text : "" }, { repeats: g.count, sessions: g.sessions.size });
  }
  return items;
}

/** 淘汰候选排序：层升 → ts 升 → refCount 升 → id 升（完全确定）。 */
export function evictionOrder(items) {
  return [...items].sort((a, b) =>
    (num(a.layer) - num(b.layer)) ||
    (num(a.ts) - num(b.ts)) ||
    (num(a.refCount) - num(b.refCount)) ||
    (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
}

/**
 * 按墓碑 ID 集合过滤出「存活条目」（注入视图）。**不改入参、不删历史**。
 * 空集合 → 原样返回同一引用 → 保证默认（无墓碑）时注入输出逐字节不变。
 * 整条事实全被墓碑的条目从存活视图里消失（但 Markdown 原文仍在）。
 */
export function applyTombstoneIds(entries, idSet) {
  const list = Array.isArray(entries) ? entries : [];
  const set = idSet instanceof Set ? idSet : new Set(Array.isArray(idSet) ? idSet : []);
  if (set.size === 0) return list;
  const out = [];
  for (const e of list) {
    if (!e || !Array.isArray(e.facts)) { out.push(e); continue; }
    const facts = e.facts.filter((f) =>
      !(typeof f === "string" && set.has(markdownFactKey(e.sessionId, f))));
    if (facts.length === 0) continue;
    out.push({ ...e, facts });
  }
  return out;
}

/**
 * 存活/墓碑对照统计。chars/bytes/estTokens 都基于**存活条目重新序列化后的 Markdown**，
 * 与磁盘上真实字节口径一致。
 * @returns {{facts:number, entries:number, tombstones:number, chars:number, bytes:number, estTokens:number, perLayer:{1:number,2:number,3:number}}}
 */
export function liveStats(entries, tombIds, items) {
  const set = tombIds instanceof Set ? tombIds : new Set(Array.isArray(tombIds) ? tombIds : []);
  const its = Array.isArray(items) ? items : annotate(entries);
  // 只对**结构合法**的条目做统计/序列化：损坏输入（null 条目、facts 非数组）在这里被剔除，
  // 避免 serializeMemoryFile 访问 e.ts 抛错 → 让 planEviction 退化到 catch 兜底（会误判为「无可淘」）。
  const liveEntries = applyTombstoneIds(entries, set).filter((e) => e && Array.isArray(e.facts));
  // facts 只数**非空字符串事实**（与 annotate 的可淘汰项、注入实际使用的一致）；
  // chars/bytes/estTokens 仍按 serializeMemoryFile 的真实字节算（含任何畸形行，忠于磁盘）。
  let facts = 0;
  for (const e of liveEntries) for (const f of e.facts) if (typeof f === "string" && f.trim()) facts++;
  const serialized = serializeMemoryFile(liveEntries);
  const perLayer = { 1: 0, 2: 0, 3: 0 };
  for (const it of its) {
    if (set.has(it.id)) continue;
    const L = perLayer[num(it.layer)] !== undefined ? num(it.layer) : 1;
    perLayer[L]++;
  }
  return {
    facts,
    entries: liveEntries.length,
    tombstones: set.size,
    chars: serialized.length,
    bytes: Buffer.byteLength(serialized, "utf8"),
    estTokens: estimateTokens(serialized),
    perLayer,
  };
}

function violatedCaps(stats, caps) {
  const v = [];
  if (caps.maxFacts > 0 && stats.facts > caps.maxFacts) v.push("facts");
  if (caps.maxEntries > 0 && stats.entries > caps.maxEntries) v.push("entries");
  if (caps.maxChars > 0 && stats.chars > caps.maxChars) v.push("chars");
  if (caps.maxBytes > 0 && stats.bytes > caps.maxBytes) v.push("bytes");
  return v;
}

/**
 * 规划淘汰：在存活事实里按 evictionOrder 逐个打墓碑，直到所有已配置上限满足（或无候选可淘）。
 * 纯函数、不落盘、不改入参。返回 before/after 对照 + 淘汰清单（含原因/排名）+ 可写入 .tomb 的行。
 * @param {object[]} entries Markdown 条目
 * @param {{caps?:object, tombstones?:Set|string[], now?:number, dryRun?:boolean}} [opts]
 *        caps 直接传上限对象，或传含上限字段的配置（走 resolveCaps）；tombstones 已有墓碑；
 *        now 淘汰时间戳（调用方给，core 不读时钟）；dryRun 仅回显（本函数恒无副作用）。
 * @returns {{caps:object, before:object, after:object, evicted:object[], tombstoneLines:string[], changed:boolean, dryRun:boolean, warnings:string[]}}
 */
export function planEviction(entries, opts = {}) {
  const o = opts && typeof opts === "object" ? opts : {};
  try {
    const { caps, warnings } = resolveCaps(o.caps && typeof o.caps === "object" ? o.caps : o);
    const existing = o.tombstones instanceof Set
      ? new Set(o.tombstones)
      : new Set(Array.isArray(o.tombstones) ? o.tombstones : []);
    const now = Number.isFinite(o.now) ? o.now : 0;
    const dryRun = o.dryRun !== false;

    const items = annotate(entries);
    const before = liveStats(entries, existing, items);
    const order = evictionOrder(items.filter((it) => !existing.has(it.id)));

    const tomb = new Set(existing);
    const evicted = [];
    for (const victim of order) {
      if (tomb.has(victim.id)) continue; // 同一事实的多处副本已随首个被淘汰（applyTombstoneIds 按 id 过滤）
      const stats = liveStats(entries, tomb, items);
      const violated = violatedCaps(stats, caps);
      if (violated.length === 0) break;
      tomb.add(victim.id);
      evicted.push({
        rank: evicted.length + 1,
        id: victim.id,
        sessionId: victim.sessionId,
        title: victim.title,
        text: victim.text,
        layer: victim.layer,
        ts: victim.ts,
        refCount: victim.refCount,
        reason: violated.join("+"),
      });
    }
    const after = liveStats(entries, tomb, items);
    return {
      caps,
      before,
      after,
      evicted,
      tombstoneLines: evicted.map((e) => tombstoneLine(e, now)),
      changed: evicted.length > 0,
      dryRun,
      warnings,
    };
  } catch {
    // 绝不抛：退化为「无淘汰」。
    const empty = { facts: 0, entries: 0, tombstones: 0, chars: 0, bytes: 0, estTokens: 0, perLayer: { 1: 0, 2: 0, 3: 0 } };
    return { caps: { ...DEFAULT_CAPS }, before: empty, after: empty, evicted: [], tombstoneLines: [], changed: false, dryRun: true, warnings: ["planEviction failed; no-op"] };
  }
}

// ── .tomb 旁挂文件行格式（TSV，行内不含裸 tab/换行）──────────────────────────
// id \t reason \t layer \t refCount \t tsEvicted
// 事实正文不写进 .tomb（它只存在于 Markdown，按 id 可回查）→ .tomb 不是第二份真相源。

/** 把一条淘汰项序列化为 .tomb 的一行。 */
export function tombstoneLine(ev, now = 0) {
  const id = String(ev && ev.id || "");
  const reason = String(ev && ev.reason || "").replace(/[\t\r\n]/g, " ");
  const layer = num(ev && ev.layer);
  const refCount = num(ev && ev.refCount);
  const ts = Number.isFinite(now) ? now : 0;
  return [id, reason, layer, refCount, ts].join("\t");
}

/**
 * 解析 .tomb 文本 → [{id, reason, layer, refCount, ts}]。# 注释、空行忽略；畸形行跳过。
 * 只认第一字段为 id（其余尽力解析），保证向前/向后兼容。
 */
export function parseTombstones(text) {
  const out = [];
  const seen = new Set();
  for (const line of String(text == null ? "" : text).split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    const parts = t.split("\t");
    const id = (parts[0] || "").trim();
    if (!id || seen.has(id)) continue;
    seen.add(id);
    out.push({
      id,
      reason: (parts[1] || "").trim(),
      layer: num(Number(parts[2])),
      refCount: num(Number(parts[3])),
      ts: num(Number(parts[4])),
    });
  }
  return out;
}

/** 把 parseTombstones 的结果取成 id 数组（注入侧过滤用）。 */
export function tombstoneIds(text) {
  return parseTombstones(text).map((t) => t.id);
}

/**
 * 人读的 before/after 对照表（CLI / 报告 / diag 用）。纯字符串拼接，无副作用。
 * @param {object} plan planEviction 的返回值
 * @returns {string}
 */
export function formatBeforeAfter(plan) {
  const p = plan && typeof plan === "object" ? plan : {};
  const b = p.before || {}, a = p.after || {};
  const caps = p.caps || {};
  const cap = (n) => (Number.isFinite(n) && n > 0 ? String(n) : "off");
  const row = (label, kb, ka) => `  ${label.padEnd(10)} ${fmt(b[kb]).padStart(9)} -> ${fmt(a[ka]).padStart(9)}`;
  const lines = [];
  lines.push(`上限: facts=${cap(caps.maxFacts)} entries=${cap(caps.maxEntries)} chars=${cap(caps.maxChars)} bytes=${cap(caps.maxBytes)} compileTokens=${cap(caps.maxCompileTokens)}`);
  lines.push("对照 (before -> after):");
  lines.push(row("live事实", "facts", "facts"));
  lines.push(row("live条目", "entries", "entries"));
  lines.push(row("墓碑", "tombstones", "tombstones"));
  lines.push(row("字符", "chars", "chars"));
  lines.push(row("字节", "bytes", "bytes"));
  lines.push(row("估算token", "estTokens", "estTokens"));
  lines.push(`  分层(after) L1易变=${fmt(pl(a, 1))} L2语义=${fmt(pl(a, 2))} L3画像=${fmt(pl(a, 3))}`);
  lines.push(`淘汰条数: ${(p.evicted || []).length}${p.changed === false ? " (无变化)" : ""}`);
  const ev = p.evicted || [];
  if (ev.length > 0) {
    lines.push("淘汰清单 (rank | 原因 | L | refCount | ts | session | 正文):");
    for (const e of ev) {
      const body = String(e.text || "").replace(/\s+/g, " ").slice(0, 40);
      lines.push(`  #${e.rank} | ${e.reason} | L${e.layer} | rc=${e.refCount} | ts=${e.ts} | ${e.sessionId || "-"} | ${body}`);
    }
  }
  if (Array.isArray(p.warnings) && p.warnings.length > 0) lines.push(`警告: ${p.warnings.join("; ")}`);
  return lines.join("\n");
}

function pl(stats, layer) {
  return stats && stats.perLayer ? num(stats.perLayer[layer]) : 0;
}
function fmt(v) {
  return Number.isFinite(v) ? String(v) : String(v == null ? 0 : v);
}
