// index-fts.js — 派生检索索引（可从真相源随时重建；丢了不影响正确性）。
//
// M2.4 起检索改为 **char 1–3 gram 混合 BM25**（Astra 卡点 1）：
//   - 中文按字符 unigram / bigram / trigram 三层建索引，查询按有效字符数取权重：
//       len=1  → 1.00 / 0 / 0
//       len=2  → 0.55 / 0.45 / 0
//       len≥3  → 0.25 / 0.55 / 0.20
//   - 每层同一套 Okapi BM25（K1=1.5, B=0.75），最终 score = Σ_n w_n · BM25_n。
//   - 高频单字降权：CJK unigram 的 IDF 上限 = 2 × 当前索引 bigram IDF 中位数。
//   - 精确代号奖励：查询含「字母+数字」或「≥2 位数字」token、且文档原文包含时，+2.0。
//   - Latin/数字整词放在 unigram 层（不参与 CJK bigram/trigram 切分）。
//
// 兼容：`search(query, { legacy: true })` 使用旧版「Latin 整词 + CJK bigram」单层 BM25，
// 供回归/召回对照；默认走 1–3 gram。两种模式都保持确定性排序（分数降序、id 升序）。
//
// 只依赖 node: 无；纯内存、绝不抛（畸形 query/记录退化为空结果或跳过）。

/** CJK 统一表意 + 扩展 A + 兼容 + 假名 + 谚文。 */
const CJK = /[㐀-䶿一-鿿豈-﫿぀-ヿ가-힯]/;
const CJK_GLOBAL = /[㐀-䶿一-鿿豈-﫿぀-ヿ가-힯]/g;
const LATIN = /[a-z0-9_]+/g;
const CODE_TOKEN = /[a-z]+\d+|\d{2,}/gi;

/** BM25 参数（经典默认，可标定）。 */
const K1 = 1.5;
const B = 0.75;

/** 精确代号奖励（每个文档最多加一次）。 */
const CODE_BONUS = 2.0;

/** 把字符串里的连续 CJK 段抽出来（保序）。 */
function cjkRuns(s) {
  const segs = [];
  let cur = "";
  for (const ch of s) {
    if (CJK.test(ch)) cur += ch;
    else if (cur) { segs.push(cur); cur = ""; }
  }
  if (cur) segs.push(cur);
  return segs;
}

function latinTokens(s) {
  const out = [];
  LATIN.lastIndex = 0;
  let m;
  while ((m = LATIN.exec(s)) !== null) out.push(m[0]);
  return out;
}

function ngrams(seg, n) {
  if (seg.length < n) return [];
  if (seg.length === n) return [seg];
  const out = [];
  for (let i = 0; i + n <= seg.length; i++) out.push(seg.slice(i, i + n));
  return out;
}

/** 旧版分词：Latin 整词 + CJK bigram（长度 1 的 CJK 段退化为单字）。仅用于 legacy 对照。 */
export function tokenize(text) {
  const s = typeof text === "string" ? text.toLowerCase() : "";
  if (!s) return [];
  const out = latinTokens(s);
  for (const seg of cjkRuns(s)) {
    if (seg.length === 1) { out.push(seg); continue; }
    out.push(...ngrams(seg, 2));
  }
  return out;
}

/** 1–3 gram 三层词元（Latin 整词放 unigram 层）。 */
function tokenizeLevels(text) {
  const s = typeof text === "string" ? text.toLowerCase() : "";
  const uni = latinTokens(s);
  const bi = [];
  const tri = [];
  for (const seg of cjkRuns(s)) {
    for (const ch of seg) uni.push(ch);
    bi.push(...ngrams(seg, 2));
    tri.push(...ngrams(seg, 3));
  }
  return { uni, bi, tri, legacy: tokenize(s) };
}

/** 一条记录的可检索文本（三元组 + text 拼接）。 */
function searchable(rec) {
  if (!rec) return "";
  return [rec.s, rec.p, rec.o, rec.text].filter((x) => typeof x === "string" && x).join(" ");
}

function termCounts(terms) {
  const map = new Map();
  for (const t of terms) map.set(t, (map.get(t) || 0) + 1);
  return map;
}

function makeLevel() {
  return {
    /** @type {Map<string, Map<string, number>>} term -> (id -> tf) */
    postings: new Map(),
    /** @type {Map<string, Map<string, number>>} id -> (term -> tf) */
    tfById: new Map(),
    /** @type {Map<string, number>} id -> 文档长度（词元总数） */
    lenById: new Map(),
    totalLen: 0,
  };
}

function levelAdd(level, id, terms) {
  const tf = termCounts(terms);
  const len = terms.length;
  level.tfById.set(id, tf);
  level.lenById.set(id, len);
  level.totalLen += len;
  for (const [t, n] of tf) {
    let p = level.postings.get(t);
    if (!p) { p = new Map(); level.postings.set(t, p); }
    p.set(id, n);
  }
}

function levelRemove(level, id) {
  const tf = level.tfById.get(id);
  if (!tf) return;
  for (const t of tf.keys()) {
    const p = level.postings.get(t);
    if (p) { p.delete(id); if (p.size === 0) level.postings.delete(t); }
  }
  level.tfById.delete(id);
  level.totalLen -= level.lenById.get(id) || 0;
  level.lenById.delete(id);
}

function idfOf(N, df) {
  return Math.log(1 + (N - df + 0.5) / (df + 0.5));
}

/** 单层 BM25 累加；opts.capIdf 可对特定 term 截断 IDF。 */
function scoreLevel(level, qTerms, weight, scores, capFn) {
  if (!weight || qTerms.length === 0) return;
  const N = level.tfById.size;
  if (N === 0) return;
  const avgdl = level.totalLen / N || 1;
  for (const t of new Set(qTerms)) {
    const p = level.postings.get(t);
    if (!p) continue;
    const df = p.size;
    let idf = idfOf(N, df);
    if (idf <= 0) continue;
    const cap = capFn ? capFn(t) : Infinity;
    if (Number.isFinite(cap) && idf > cap) idf = cap;
    if (idf <= 0) continue;
    for (const [id, tf] of p) {
      const dl = level.lenById.get(id) || 0;
      const denom = tf + K1 * (1 - B + (B * dl) / avgdl);
      const contrib = weight * idf * ((tf * (K1 + 1)) / denom);
      scores.set(id, (scores.get(id) || 0) + contrib);
    }
  }
}

function median(values) {
  if (values.length === 0) return 0;
  const s = [...values].sort((a, b) => a - b);
  const mid = s.length >> 1;
  return s.length % 2 === 1 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

/** 查询有效字符数（CJK 字符 + 字母/数字；忽略空白与标点）。 */
function effectiveLength(s) {
  const cjk = (s.match(CJK_GLOBAL) || []).length;
  const alnum = (s.match(/[a-z0-9]/g) || []).length;
  return cjk + alnum;
}

function weightsFor(len) {
  if (len <= 1) return { uni: 1, bi: 0, tri: 0 };
  if (len === 2) return { uni: 0.55, bi: 0.45, tri: 0 };
  return { uni: 0.25, bi: 0.55, tri: 0.2 };
}

// ── 检索剪枝辅助（T0/T1，本轮新增；不改变 BM25 公式/idf/k1/b/权重/代号+2.0）──
const EMPTY_MAP = new Map();

/** docId 升序数组（双指针交集用；交集本身不依赖 Set）。 */
function sortedIds(p) {
  return Array.from(p.keys()).sort();
}

/** 双指针求两有序数组交集（docId 升序），返回数组（不使用 Set）。 */
function twoPointerIntersect(a, b) {
  const out = [];
  let i = 0, j = 0;
  while (i < a.length && j < b.length) {
    if (a[i] < b[j]) i++;
    else if (a[i] > b[j]) j++;
    else { out.push(a[i]); i++; j++; }
  }
  return out;
}

/** 保留 gram 的 posting 并集（去重），用于 T0/full 的代号奖励限域与 diag.candidates。 */
function unionOfPostings(levels, kept) {
  const set = new Set();
  for (const term of kept.uni) { const p = levels.u.postings.get(term); if (p) for (const id of p.keys()) set.add(id); }
  for (const term of kept.bi) { const p = levels.b.postings.get(term); if (p) for (const id of p.keys()) set.add(id); }
  for (const term of kept.tri) { const p = levels.t.postings.get(term); if (p) for (const id of p.keys()) set.add(id); }
  return set;
}

/** 只在候选集上按全 gram 查表打分（T1）：与 scoreLevel 对同批候选文档的结果逐字节一致。 */
function scoreCandidates(candidateIds, kept, w, capUni, levels, scores) {
  scoreCandidatesLevel(levels.u, kept.uni, w.uni, capUni, candidateIds, scores);
  scoreCandidatesLevel(levels.b, kept.bi, w.bi, null, candidateIds, scores);
  scoreCandidatesLevel(levels.t, kept.tri, w.tri, null, candidateIds, scores);
}

function scoreCandidatesLevel(level, terms, weight, capFn, candidateIds, scores) {
  if (!weight || terms.length === 0 || level.tfById.size === 0) return;
  const N = level.tfById.size;
  const avgdl = level.totalLen / N || 1;
  for (const id of candidateIds) {
    let docScore = 0;
    for (const t of terms) {
      const p = level.postings.get(t);
      if (!p) continue;
      const tf = p.get(id);
      if (!tf) continue;
      const df = p.size;
      let idf = idfOf(N, df);
      if (idf <= 0) continue;
      const cap = capFn ? capFn(t) : Infinity;
      if (Number.isFinite(cap) && idf > cap) idf = cap;
      if (idf <= 0) continue;
      const dl = level.lenById.get(id) || 0;
      const denom = tf + K1 * (1 - B + (B * dl) / avgdl);
      docScore += weight * idf * ((tf * (K1 + 1)) / denom);
    }
    if (docScore > 0) scores.set(id, (scores.get(id) || 0) + docScore);
  }
}

/** 过滤零分/负分，归一化，排序（score 降序，id 升序），截断 top-k。确定性。 */
function finalize(scores, raw, k) {
  let max = 0;
  for (const s of scores.values()) if (s > max) max = s;
  const scored = [];
  for (const [id, s] of scores) {
    if (s <= 0) continue;
    scored.push({ id, relevance: raw ? s : (max > 0 ? s / max : 0) });
  }
  scored.sort((a, b2) => (b2.relevance - a.relevance) || (a.id < b2.id ? -1 : a.id > b2.id ? 1 : 0));
  const kk = Number.isFinite(k) && k > 0 ? Math.trunc(k) : Infinity;
  return scored.slice(0, kk);
}

/**
 * 创建内存 BM25 倒排索引。
 * @returns {object} index
 */
export function createIndex() {
  const u = makeLevel();
  const b = makeLevel();
  const t = makeLevel();
  const legacy = makeLevel();
  /** @type {Map<string, string>} 原文（代号奖励用） */
  const textById = new Map();

  function addDoc(id, levels, text) {
    levelAdd(u, id, levels.uni);
    levelAdd(b, id, levels.bi);
    levelAdd(t, id, levels.tri);
    levelAdd(legacy, id, levels.legacy);
    textById.set(id, text.toLowerCase());
  }

  function removeDoc(id) {
    levelRemove(u, id);
    levelRemove(b, id);
    levelRemove(t, id);
    levelRemove(legacy, id);
    textById.delete(id);
  }

  return {
    /** 索引后端标识（恒 'memory'；FTS5 探测留待将来以 peer 依赖注入，不在 core 内 import）。 */
    backend: "memory",

    /** 插入或更新一条记录的索引项。墓碑记录不建索引（不可召回）。 */
    upsert(rec) {
      if (!rec || typeof rec.id !== "string") return;
      this.delete(rec.id);
      if (rec.tombstone) return;
      const text = searchable(rec);
      addDoc(rec.id, tokenizeLevels(text), text);
    },

    /** 从索引删除一条记录。 */
    delete(id) {
      if (typeof id === "string") removeDoc(id);
    },

    /** 用一批记录整体重建索引（可从真相源重建）。 */
    rebuild(records) {
      u.postings.clear(); u.tfById.clear(); u.lenById.clear(); u.totalLen = 0;
      b.postings.clear(); b.tfById.clear(); b.lenById.clear(); b.totalLen = 0;
      t.postings.clear(); t.tfById.clear(); t.lenById.clear(); t.totalLen = 0;
      legacy.postings.clear(); legacy.tfById.clear(); legacy.lenById.clear(); legacy.totalLen = 0;
      textById.clear();
      for (const rec of records || []) this.upsert(rec);
    },

    /** 已建索引的记录数。 */
    size() {
      return u.tfById.size;
    },

    /**
     * BM25 检索。确定性：同 query 同索引 → 同结果同顺序（score 降序，其次 id 升序）。
     * 默认 1–3 gram 混合；opts.legacy === true 退回旧版 bigram-only（回归对照）。
     * 默认 relevance 归一到 [0,1]（除以本次命中的最大分）；opts.raw === true 返回原始分。
     * @param {string} query
     * @param {{k?: number, raw?: boolean, legacy?: boolean, noCodeBonus?: boolean}} [opts]
     * @returns {{id: string, relevance: number}[]}
     */
    search(query, opts = {}) {
      const q = typeof query === "string" ? query.toLowerCase() : "";
      if (!q) return [];
      const raw = !!(opts && opts.raw === true);
      const useLegacy = !!(opts && opts.legacy === true);
      // strategy: 'full'(默认，原行为) | 'skip'(T0 高频 gram 剪枝) | 'intersect'(T1 稀有 gram 交集)。
      const strategy = (opts && typeof opts.strategy === "string") ? opts.strategy : "full";
      // 观测出口：调用方传入 diag 对象则写入 pruned / candidates（不参与打分，只读）。
      const diag = (opts && opts.diag && typeof opts.diag === "object") ? opts.diag : null;
      if (diag) { diag.pruned = 0; diag.candidates = 0; }
      const scores = new Map();

      // 精确代号奖励：限定在 docSet 内（T0/T1 用并集/候选集；full 用全量）。
      // 限域后与原 O(N) 全文档遍历在「代号 token 同时也是查询 unigram」的前提下逐字节一致。
      const applyCodeBonus = (sc, codes, docSet) => {
        if (!codes || codes.length === 0) return;
        for (const id of docSet) {
          const text = textById.get(id);
          if (text && codes.some((c) => text.includes(c))) {
            sc.set(id, (sc.get(id) || 0) + CODE_BONUS);
          }
        }
      };

      if (useLegacy) {
        scoreLevel(legacy, tokenize(q), 1, scores, null);
        if (diag) diag.candidates = scores.size;
        return finalize(scores, raw, opts.k);
      }

      const levels = tokenizeLevels(q);
      const w = weightsFor(effectiveLength(q));
      const N = u.tfById.size;
      const noCode = !!(opts && opts.noCodeBonus === true);
      const codes = noCode ? [] : [...new Set(q.match(CODE_TOKEN) || [])];

      // 高频单字降权：CJK unigram 的 IDF ≤ 2 × bigram IDF 中位数。
      let bigramMedianIdf = Infinity;
      if (b.postings.size > 0) {
        const Nb = b.tfById.size;
        const vals = [];
        for (const p of b.postings.values()) vals.push(idfOf(Nb, p.size));
        bigramMedianIdf = median(vals) * 2;
      }
      const capUni = (term) => (term.length === 1 && CJK.test(term) ? bigramMedianIdf : Infinity);

      // 收集查询里每个落在索引中的 gram（跨三层）及其 df 与 docId 升序列表（双指针交集用）。
      const gramsWithDf = () => {
        const out = [];
        const push = (level, terms) => {
          for (const term of new Set(terms)) {
            const p = level.postings.get(term);
            if (!p) continue;
            out.push({ df: p.size, ids: sortedIds(p) });
          }
        };
        push(u, levels.uni); push(b, levels.bi); push(t, levels.tri);
        return out;
      };

      // —— 三种策略的打分实现（BM25 公式 / idf / k1 / b / 权重 / 代号+2.0 一律不变）——
      const fullScore = () => {
        scoreLevel(u, levels.uni, w.uni, scores, capUni);
        scoreLevel(b, levels.bi, w.bi, scores, null);
        scoreLevel(t, levels.tri, w.tri, scores, null);
        applyCodeBonus(scores, codes, textById.keys());
        if (diag) diag.candidates = scores.size;
      };

      const t0Score = () => {
        // T0：跳过 df > threshold 的高频 gram（中文"的/是/了/在"等）；稀有 token 自然保留。
        // 小库地板：仅当 N≥32 时启用 df 剪枝（threshold = 0.25*N）；N<32 时抬到 8，
        // 小库基本不剪（N=4 时 0.25*N=1<8 → threshold=8>N，一个都剪不掉；N=27 时
        // 0.25*27=6.75<8 → threshold=8，只剪真正高频的 gram）。保护：跳完后一个都不剩 → 退回 full。
        const threshold = Math.max(0.25 * N, 8);
        const kept = { uni: [], bi: [], tri: [] };
        const pruned = { uni: [], bi: [], tri: [] };
        const split = (level, terms, kArr, pArr) => {
          for (const term of new Set(terms)) {
            const p = level.postings.get(term);
            if (!p) continue;
            if (p.size > threshold) pArr.push(term); else kArr.push(term);
          }
        };
        split(u, levels.uni, kept.uni, pruned.uni);
        split(b, levels.bi, kept.bi, pruned.bi);
        split(t, levels.tri, kept.tri, pruned.tri);
        const prunedCount = pruned.uni.length + pruned.bi.length + pruned.tri.length;
        if (kept.uni.length + kept.bi.length + kept.tri.length === 0) {
          fullScore(); // 保护：全部被剪 → 全量扫描
          if (diag) diag.pruned = prunedCount;
          return;
        }
        scoreLevel(u, kept.uni, w.uni, scores, capUni);
        scoreLevel(b, kept.bi, w.bi, scores, null);
        scoreLevel(t, kept.tri, w.tri, scores, null);
        const union = unionOfPostings({ u, b, t }, kept);
        applyCodeBonus(scores, codes, union);
        if (diag) { diag.pruned = prunedCount; diag.candidates = union.size; }
      };

      const t1Score = () => {
        // T1：取查询里 df 最低的 2–3 个 gram，对其 posting（docId 升序）双指针求交集作候选集；
        // 只在候选集上做完整 BM25 打分（与 scoreLevel 对同批候选的结果逐字节一致）。
        // 兜底：交集为空 / <5 / 候选>40%总量 → 退回 T0（T0 自身还可能退回 full）。
        const grams = gramsWithDf();
        if (grams.length === 0) { fullScore(); return; }
        grams.sort((a, b2) => a.df - b2.df);
        const pick = grams.slice(0, Math.min(3, grams.length));
        let cand = pick[0].ids;
        for (let i = 1; i < pick.length; i++) cand = twoPointerIntersect(cand, pick[i].ids);
        if (cand.length === 0 || cand.length < 5 || cand.length > 0.4 * N) {
          t0Score();
          return;
        }
        scoreCandidates(cand, { uni: levels.uni, bi: levels.bi, tri: levels.tri }, w, capUni, { u, b, t }, scores);
        applyCodeBonus(scores, codes, cand);
        if (diag) { diag.pruned = 0; diag.candidates = cand.length; }
      };

      try {
        if (strategy === "intersect") t1Score();
        else if (strategy === "skip") t0Score();
        else fullScore();
      } catch {
        // 静默降级：剪枝异常 → 全量扫描（绝不抛，绝不编译失败）。
        scores.clear();
        fullScore();
      }

      return finalize(scores, raw, opts.k);
    },
  };
}
