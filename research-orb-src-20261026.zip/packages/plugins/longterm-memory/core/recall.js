// recall.js — recall(query, opts) → { text, items, meta }。
//
// 编排（M2）：
//   1) 检索：index-fts 的 BM25 相关度（query 侧）
//   2) 打分：lifecycle.scoreRecord（相关 × 重要 × 新鲜）
//   3) 分组：稳定段 = **与 query 无关**的持久事实（layer ≥ 2 的语义/画像），逐条恒定；
//            易变段 = 本轮 BM25 召回的情节事实（layer < 2），排在稳定段之后
//   4) 编译：compile 做 0/1 背包贪心 + 预算硬上限 + 缓存友好布局
//
// 关键不变量：稳定段内容只取决于记忆库与预算、**不取决于 query** →
//   「同记忆 + 不同 query」时稳定段逐字节相同 → 前缀缓存可命中（总纲 §6 指标 2）。
//
// 硬不变量（总纲 §3）：
//   1) 永不抛：整体 try/catch，任何异常退化为 { text:'', items:[], meta:空 }
//   2) text 永远是字符串
//   3) budgetTokens 是硬上限：由 compile 保证 estimateTokens(text) ≤ budgetTokens
//   4) 同输入 → 字节相同输出：不读时钟（now 来自 opts），排序全部确定性
//
// 只依赖同目录 core 模块；禁止 cordis / electron / 网络 / ~/.dsh。

import { compile, estimateTokens, renderLine } from "./compile.js";
import { scoreRecord } from "./lifecycle.js";

const num = (v) => (Number.isFinite(v) ? Number(v) : 0);

const EMPTY_META = Object.freeze({ stableBytes: 0, volatileBytes: 0, budgetUsed: 0, stableChars: 0 });
const EMPTY = Object.freeze({ text: "", items: [], meta: EMPTY_META });

/**
 * 绑定依赖，产出一个 recall(query, opts) 函数（供 api.js 门面复用）。
 * 1.0.1 P1-1：items 升级为「预算解释」——除入选项外，还给出被丢弃的候选及其原因，
 *   让宿主能回答「为什么这条没进」：
 *     items: [{ id, tokens, score, volatility?, dropped:boolean, reason:'budget'|'gate'|'dup'|null }]
 *   · dropped=false / reason=null：入选（顺序与 text 中的行一致）
 *   · 'gate'  ：被检索阈值（minRelevance）或 scope 滤掉
 *   · 'budget'：容量限制（预算装不下，或被 opts.k 截断）
 *   · 'dup'   ：预留（DSH 路径的折叠去重会用；本路径当前不产生）
 *   text / meta **与改动前逐字节相同**，老调用方（只看 text 或只数 items 的入选项）不受影响。
 *
 * @param {{store: object, index: object}} deps
 * @returns {(query?: *, opts?: object) => {text: string, items: object[], meta: object}}
 */
export function makeRecall(deps) {
  const store = deps && deps.store;
  const index = deps && deps.index;

  return function recall(query, opts = {}) {
    try {
      const o = opts && typeof opts === "object" ? opts : {};
      const q = typeof query === "string" ? query : query == null ? "" : safeString(query);
      const budget = Number.isFinite(o.budgetTokens) && o.budgetTokens > 0 ? o.budgetTokens : 0;
      if (budget <= 0) return { text: "", items: [], meta: { ...EMPTY_META } };
      if (!store || !index) return { text: "", items: [], meta: { ...EMPTY_META } };

      const scope = o.scope === "project" || o.scope === "global" ? o.scope : null;
      const scopeOk = (rec) => !scope || rec.scope === scope || rec.scope === "global";

      // 1.0.1 P1-1：预算解释收集器。被闸门/作用域滤掉的候选也要登记（dropped:true），
      // 这样宿主能回答「为什么这条没进」，而不是只看到入选的几条。
      const dropped = []; // {id, tokens, score, volatility, reason}
      const pushDropped = (id, score, volatility, reason) => {
        dropped.push({ id, tokens: 0, score: num(score), volatility, reason });
      };

      // ── 稳定段：与 query 无关，取所有存活 layer≥2 记录（画像/语义），逐条恒定 ──
      const stablePool = [];
      const stableIds = new Set();
      for (const rec of store.live()) {
        if (!rec || rec.tombstone || !(rec.layer >= 2)) continue;
        if (!scopeOk(rec)) continue;
        stableIds.add(rec.id);
        stablePool.push({
          id: rec.id, volatility: "stable", layer: rec.layer,
          text: rec.text, s: rec.s, p: rec.p, o: rec.o,
          score: scoreRecord(rec, { relevance: 0, now: o.now, weights: o.weights }),
        });
      }

      // ── 易变段：**只收 BM25 命中（relevance > 阈值）的情节事实** ──────────────────
      // M2.1 整改：撤掉 v2 之前的「relevance=0 兜底填满闲置预算」。v2 全量实测证明——
      //   D 的注入上界已达 97%（BM25 几乎不漏召），但 distractor 正确率只有 0.467（B 有 0.867）：
      //   兜底把一堆与查询无关的情节事实当成「可能相关」塞进 prompt，模型遇到「记忆里没有答案」的
      //   题目反而更敢编。正确做法是**用不满就不用满、宁可留白**——查不到就让易变段是空的，
      //   配合注入块的边界声明，让模型据此回答"记忆里没有相关信息"。budgetUsed 变小是正常且诚实的。
      const minRelevance = Number.isFinite(o.minRelevance) && o.minRelevance >= 0 ? o.minRelevance : 0;
      const relById = new Map();
      const hits = index.search(q, {});
      if (Array.isArray(hits)) for (const h of hits) relById.set(h.id, h.relevance);
      const volatilePool = [];
      for (const rec of store.live()) {
        if (!rec || rec.tombstone) continue;
        if (rec.layer >= 2) continue;          // layer≥2 归稳定段，避免重复
        if (stableIds.has(rec.id)) continue;   // 已进稳定段
        if (!scopeOk(rec)) continue;
        const relevance = relById.get(rec.id);
        if (!(relevance > minRelevance)) {
          // 未被检索命中（或不高于阈值）→ 登记为 gate 丢弃，宿主可解释
          pushDropped(rec.id, scoreRecord(rec, { relevance: relevance || 0, now: o.now, weights: o.weights }), "volatile", "gate");
          continue;
        }
        volatilePool.push({
          id: rec.id, volatility: "volatile", layer: rec.layer,
          text: rec.text, s: rec.s, p: rec.p, o: rec.o,
          score: scoreRecord(rec, { relevance, now: o.now, weights: o.weights }),
        });
      }
      if (Number.isFinite(o.k) && o.k > 0) {
        volatilePool.sort((a, b) => (b.score - a.score) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
        const cut = volatilePool.splice(Math.trunc(o.k));
        for (const c of cut) pushDropped(c.id, c.score, "volatile", "budget"); // k 截断：与预算同类的容量限制
      }

      if (stablePool.length === 0 && volatilePool.length === 0) {
        // 一条都没进池子：text 仍为空，但把被 gate 滤掉的候选回给宿主（"为什么没召回"要能解释）。
        dropped.sort((a, b) => (num(b.score) - num(a.score)) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
        return { text: "", items: dropped, meta: { ...EMPTY_META } };
      }

      const out = compile(stablePool.concat(volatilePool), { budgetTokens: budget });
      // 1.1.0-rc3 P0-c：compile 在「预算过小」时会返回**全部候选但标 dropped:true**。
      // 这里必须按 dropped 标志区分，否则会把它们当入选项（items 全被标 dropped:false）。
      const chosen = (Array.isArray(out.items) ? out.items : []).filter((it) => it && !it.dropped);
      const chosenIds = new Set(chosen.map((it) => it && it.id));
      // 进了候选池但没被 compile 选中 → 预算装不下（budget）。text 与改动前逐字节相同，
      // 只是把「为什么没进」写进 items。
      for (const c of stablePool.concat(volatilePool)) {
        if (chosenIds.has(c.id)) continue;
        pushDropped(c.id, c.score, c.volatility, "budget");
        dropped[dropped.length - 1].tokens = estimateTokens(renderLine(c));
      }
      // 排序确定：入选按 compile 顺序在前；丢弃项按 (score 降, id 升)。
      dropped.sort((a, b) => (num(b.score) - num(a.score)) || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
      const items = chosen.map((it) => ({
        id: it.id, tokens: it.tokens, score: it.score, volatility: it.volatility, dropped: false, reason: null,
      })).concat(dropped);
      return {
        text: typeof out.text === "string" ? out.text : "",
        items,
        meta: out.meta,
      };
    } catch {
      return { text: "", items: [], meta: { ...EMPTY_META } }; // 永不抛
    }
  };
}

function safeString(v) {
  try {
    if (typeof v === "string") return v;
    if (v && typeof v === "object" && typeof v.text === "string") return v.text;
    return "";
  } catch {
    return "";
  }
}

export { EMPTY };
