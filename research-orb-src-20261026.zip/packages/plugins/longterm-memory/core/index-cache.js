// index-cache.js — 阶段3 增量索引缓存（与 entries 解耦；命中 / 追加 / 重建 / 降级）。
//
// 设计（对应任务书 2.1 / 2.2 / 2.3）：
//   · 不变量（方案 A）：index-fts 的 search 取实时 N/avgdl，且 upsert/delete 正确维护
//     tfById / lenById / totalLen 与 postings；故「增量 upsert 新事实 + delete 已删事实」
//     的最终索引 == 对并集的冷 rebuild（统计量均匀、顺序无关）。命中 / 追加 路径与
//     冷重建 逐字节一致 —— 由单测（确定性、缓存一致性）强制保证。
//   · 快速判等键：(文件路径, 事实条数, 文件 mtime, 文件字节数, 末条稳定 id)。
//     绝不含 lastSeen 簿记字段；键必须含文件路径（daemon 与 bench 读不同文件，避免串扰）。
//   · 结构性变化（事实数下降 / 文件被外部重写 / 条目被删 / 缓存恢复失败）→ 重建。
//   · 纯追加增长 → 追加（仅 upsert 新增、delete 已删，不重建全量）。
//   · 内存上限：常驻 RSS 增量 > 80MB → 退回「不缓存全量重建」并打一次诊断。
//   · 并发安全：compileFromEntries 为同步调用，构建在事件循环内原子完成，本模块只保留
//     单份缓存（LRU=1）→ 天然无竞态；若未来改为异步调用，再加 in-flight promise 去重即可。
//   · 静默降级：任何异常 → 退回无缓存路径（本次全量重建），恒返回可用 index，绝不让装配失败。
//
// 只依赖 node:fs / node:process；对外 getIndex 绝不抛。

import { createIndex } from "./index-fts.js";
import { statSync } from "node:fs";

const RSS_LIMIT = 80 * 1024 * 1024; // 80MB 常驻增量上限

let baselineMem = 0;
try {
  // 基线用 heapUsed（非 RSS）：RSS 有 OS 提交滞后，紧接大分配后立即读取会漏判；
  // heapUsed 即时准确，更可靠地表达「进程内存增量」这一本意。
  if (typeof process !== "undefined" && process.memoryUsage) baselineMem = process.memoryUsage().heapUsed;
} catch {}

let cache = null; // 单份缓存：{ key, path, index, coveredIds:Set, factCount, lastId, size, mtimeMs }
let offMode = false; // RSS 超限后粘性降级
let degradedDiagEmitted = false; // rss-exceed 诊断只打一次

function buildFresh(volatileItems) {
  const index = createIndex();
  const coveredIds = new Set();
  for (const it of volatileItems) {
    if (it && typeof it.id === "string") {
      index.upsert({ id: it.id, text: it.text });
      coveredIds.add(it.id);
    }
  }
  return { index, coveredIds };
}

function statFile(sourcePath) {
  try {
    const st = statSync(sourcePath);
    return { mtimeMs: st.mtimeMs || 0, size: st.size || 0, ok: true };
  } catch {
    return { mtimeMs: 0, size: 0, ok: false };
  }
}

function computeKey(sourcePath, factCount, lastId, st) {
  const path = sourcePath || "no-path";
  return `${path}::${factCount}::${st.mtimeMs}::${st.size}::${lastId}`;
}

function rssMBNow() {
  try {
    if (typeof process !== "undefined" && process.memoryUsage) {
      return Math.round((process.memoryUsage().rss / (1024 * 1024)) * 10) / 10;
    }
  } catch {}
  return 0;
}

/** 当前 heapUsed 字节数（RSS 有 OS 提交滞后，heapUsed 即时准确，用于算增量）。 */
function heapUsedNow() {
  try {
    if (typeof process !== "undefined" && process.memoryUsage) return process.memoryUsage().heapUsed;
  } catch {}
  return 0;
}

/** heapUsed 绝对值（MB，1 位小数），供诊断观测。 */
function heapUsedMB() {
  return Math.round((heapUsedNow() / (1024 * 1024)) * 10) / 10;
}

/** 基线绝对值（MB，1 位小数），供诊断观测。 */
function baselineMB() {
  return Math.round((baselineMem / (1024 * 1024)) * 10) / 10;
}

/**
 * 重取内存基线到「当前 heapUsed」。P0.3：每次成功重建后调用。
 * 旧 bug：baselineMem 进程启动时取一次，长跑进程里 heapUsed 随运行时间自然增长，
 * 增量越算越大 → 反复误触发 rss-exceed 并粘性降级（实机 cache:"off",cacheReason:"rss-exceed"）。
 * 改成「相对上一次重建的增量」后，只有单个重建周期内缓存自身涨 >80MB 才降级。
 */
function retakeBaseline() {
  baselineMem = heapUsedNow();
}

function checkRssAndMaybeDegrade() {
  if (offMode) return false;
  const delta = heapUsedNow() - baselineMem; // 相对上一次重建（或模块加载）的增量
  if (delta > RSS_LIMIT) {
    offMode = true;
    cache = null; // 不再缓存（退回「不缓存全量重建」）
    return true;
  }
  return false;
}

/**
 * 取索引：命中 / 追加 / 重建 / 降级（同步，恒返回可用 index）。
 * @param {{sourcePath?:string|null, volatileItems:Array, factCount?:number, lastId?:string}} opts
 * @returns {{index:object, status:'hit'|'append'|'rebuild'|'off', facts:number,
 *            entries:number, rssMB:number, reason:string|null, emitDiag:boolean}}
 */
export function getIndex(opts = {}) {
  const sourcePath = (opts && typeof opts.sourcePath === "string" && opts.sourcePath) || null;
  const volatileItems = Array.isArray(opts.volatileItems) ? opts.volatileItems : [];
  const factCount = Number.isFinite(opts.factCount) ? opts.factCount : volatileItems.length;
  const lastId = (opts && typeof opts.lastId === "string") ? opts.lastId : "";

  // 无文件路径 → 无法构成安全去重键（否则不同文件 factCount/lastId 相同会碰撞串扰，
  // 见 spec「键必须含文件路径」）→ 不缓存，每次全量重建（正确，只是无缓存加速）。
  // daemon（传 memoryFile）与显式传入路径的压测才会命中缓存。
  if (!sourcePath) {
    try {
      const { index } = buildFresh(volatileItems);
      return { index, status: "off", facts: volatileItems.length, entries: factCount, rssMB: rssMBNow(), reason: "no-path", emitDiag: false };
    } catch {
      return { index: createIndex(), status: "off", facts: 0, entries: factCount, rssMB: rssMBNow(), reason: "exception", emitDiag: false };
    }
  }

  const st = statFile(sourcePath);
  const key = computeKey(sourcePath, factCount, lastId, st);
  const rssMB = rssMBNow();

  try {
    // 1) 命中：键完全一致 → 复用缓存索引（零重建）。
    if (cache && cache.key === key) {
      return { index: cache.index, status: "hit", facts: volatileItems.length, entries: factCount, rssMB, reason: null, emitDiag: false };
    }

    // 2) 降级模式：不再缓存（cache 保持 null），每次全量重建（仍返回可用 index）。
    //    注意：绝不可在此处回填 cache —— 否则下一轮命中刚写入的 key 走 hit 路径，
    //    使 offMode 粘性失效（只在首编降一次、随后又缓存）。这正是「退回不缓存全量重建」的本意：
    //    超大索引每轮现建现用、用完即弃，不常驻。
    if (offMode) {
      const { index } = buildFresh(volatileItems);
      return { index, status: "off", facts: volatileItems.length, entries: factCount, rssMB, reason: "rss-exceed", emitDiag: false };
    }

    // 3) 同文件、纯追加增长 → 增量追加（upsert 新事实、delete 已删事实，不重建全量）。
    const sameFile = cache && (cache.path || "no-path") === (sourcePath || "no-path");
    if (sameFile && factCount > cache.factCount && st.size >= cache.size && st.mtimeMs >= cache.mtimeMs) {
      const currentIds = new Set();
      for (const it of volatileItems) if (it && typeof it.id === "string") currentIds.add(it.id);
      // 新增：当前有、缓存没有 → upsert。
      for (const it of volatileItems) {
        if (it && typeof it.id === "string" && !cache.coveredIds.has(it.id)) {
          cache.index.upsert({ id: it.id, text: it.text });
          cache.coveredIds.add(it.id);
        }
      }
      // 删除：缓存有、当前没有 → delete（墓碑 / 条目被删的排除集处理，不重建）。
      for (const id of [...cache.coveredIds]) {
        if (!currentIds.has(id)) { cache.index.delete(id); cache.coveredIds.delete(id); }
      }
      cache.key = key;
      cache.factCount = factCount;
      cache.lastId = lastId;
      cache.size = st.size;
      cache.mtimeMs = st.mtimeMs;
      return { index: cache.index, status: "append", facts: volatileItems.length, entries: factCount, rssMB, reason: null, emitDiag: false };
    }

    // 4) 重建：不同文件（换库）/ 结构性变化（事实数下降、文件被外部重写、既有事实被编辑）→ 全量重建。
    const { index, coveredIds } = buildFresh(volatileItems);
    cache = { key, path: sourcePath, index, coveredIds, factCount, lastId, size: st.size, mtimeMs: st.mtimeMs };

    // 5) 内存上限：相对「上一次重建」的 heapUsed 增量 > 80MB → 退化（本次仍返回刚建好的 index，但不再缓存）。
    //    P0.3：判断用旧基线（上一次重建），判断后立即重取基线到本次重建后 —— 长跑进程里基线跟着
    //    重建走，不会因进程自然增长而误降级。同时把 heapUsed / baseline 绝对值写进出参供诊断。
    const degraded = checkRssAndMaybeDegrade();
    retakeBaseline();
    if (degraded) {
      const emit = !degradedDiagEmitted;
      degradedDiagEmitted = true;
      return { index, status: "off", facts: volatileItems.length, entries: factCount, rssMB: rssMBNow(), reason: "rss-exceed", emitDiag: emit, heapUsedMB: heapUsedMB(), baselineMB: baselineMB() };
    }
    return { index, status: "rebuild", facts: volatileItems.length, entries: factCount, rssMB, reason: null, emitDiag: true, heapUsedMB: heapUsedMB(), baselineMB: baselineMB() };
  } catch {
    // 静默降级：任何异常 → 无缓存全量重建，恒返回可用 index，绝不让调用方拿到 null。
    try {
      const { index } = buildFresh(volatileItems);
      return { index, status: "off", facts: volatileItems.length, entries: factCount, rssMB: rssMBNow(), reason: "exception", emitDiag: false };
    } catch {
      return { index: createIndex(), status: "off", facts: 0, entries: factCount, rssMB, reason: "exception", emitDiag: false };
    }
  }
}

/** 测试 / 运维：清空缓存与降级状态（保持基线 RSS 不变）。 */
export function resetCache() {
  cache = null;
  offMode = false;
  degradedDiagEmitted = false;
}

/** 观测：当前缓存状态，供诊断。 */
export function cacheState() {
  return { hasCache: !!cache, key: cache ? cache.key : null, offMode, rssMB: rssMBNow() };
}
