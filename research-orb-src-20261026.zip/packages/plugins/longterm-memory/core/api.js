// api.js — 记忆内核的唯一对外门面（总纲 §3 接口冻结草案）。
//
//   observe(event)                                        宿主原始事件 → 归一化 → remember
//   remember(fact, {scope,source,importance,ttl,tValid})  fact: {s,p,o} 或 {text}
//   forget(idOrQuery, {mode:'tombstone'|'purge'})
//   recall(query, {budgetTokens,k,scope,now})  → {text:string, items:[{id,tokens,score}]}
//   consolidate({now})                          → {promoted, merged, expired, conflicts}
//   export({format:'md'|'jsonl'})               （也接受字符串 'md'/'jsonl'）
//
// 不变量：recall 永不抛；text 永远是字符串；budgetTokens 是硬上限；同输入 → 字节相同输出。
// core 硬性约束：不 import cordis/electron/第三方；不访问网络；不读 ~/.dsh。
// 只依赖同目录 core 模块 + node: 内置。

import { createStore } from "./store-jsonl.js";
import { createIndex } from "./index-fts.js";
import { makeRecall } from "./recall.js";
import { normalizeRecord, validateRecord, stableStringify, mergeProvenance } from "./schema.js";
import { findConflict, findExpired, suggestLayer, duplicateGroups, planMerge } from "./lifecycle.js";
import { compile, estimateTokens, renderLine } from "./compile.js";

/**
 * 创建一个记忆实例（M0：内存实现；给 opts.file 时真相源落 JSONL）。
 * @param {{file?: string, now?: () => number}} [opts]
 *        now: 写入路径用的时钟（默认 Date.now）；**读取路径 recall 不用它**，以保证字节稳定。
 * @returns {object} 6 个 API + 若干只读辅助
 */
export function createMemory(opts = {}) {
  const o = opts && typeof opts === "object" ? opts : {};
  const clock = typeof o.now === "function" ? o.now : () => Date.now();
  const store = createStore({ file: o.file });
  const index = createIndex();
  // 冷启动（file 模式）：把真相源里的存活记录灌进索引
  index.rebuild(store.all());
  const recall = makeRecall({ store, index });

  /**
   * observe：宿主原始事件 → 归一化 → 写入。
   * 各宿主 adapter 负责把自家事件映射成 {text} 或 {s,p,o} + 元信息；core 只做归一化落库。
   * @param {object} event 归一化后的事实载荷
   * @returns {object|null} 写入的记录（去重/冲突后），或 null（无效事件）
   */
  function observe(event) {
    try {
      if (!event || typeof event !== "object") return null;
      const fact = {
        s: event.s, p: event.p, o: event.o, text: event.text,
      };
      const meta = {
        scope: event.scope, source: event.source, importance: event.importance,
        ttl: event.ttl, tValid: event.tValid, layer: event.layer, provenance: event.provenance,
      };
      return remember(fact, meta);
    } catch {
      return null;
    }
  }

  /**
   * remember：写入一条事实。自动去重（同 id）、自动冲突消解（同 s,p 不同 o）。
   * @param {{s?:string,p?:string,o?:string,text?:string}} fact
   * @param {{scope?:string,source?:string,importance?:number,ttl?:number,tValid?:number,layer?:number,provenance?:object}} [meta]
   * @returns {object|null} 落库后的记录，或 null（空事实）
   */
  function remember(fact, meta = {}) {
    try {
      const m = meta && typeof meta === "object" ? meta : {};
      const merged = { ...(fact || {}), ...m };
      const rec = normalizeRecord({ ...merged, ts: Number.isFinite(merged.ts) ? merged.ts : clock() });
      const v = validateRecord(rec);
      if (!v.ok) return null; // 空事实不写

      // 冲突消解（总纲 §4）：同 (s,p) 不同 o → 新事实胜出，旧的写 supersedes + 墓碑
      const conflict = findConflict(rec, store.live());
      if (conflict) {
        store.patch(conflict.id, { tombstone: true, supersedes: rec.id });
        index.delete(conflict.id);
      }

      const { record } = store.append(rec);
      index.upsert(record);
      return record;
    } catch {
      return null;
    }
  }

  /**
   * forget：遗忘。默认墓碑（可追溯、可回滚，I5）；mode:'purge' 物理删除。
   * @param {string} idOrQuery 记录 id，或一段查询文本（匹配到的存活记录一并遗忘）
   * @param {{mode?: 'tombstone'|'purge'}} [opts]
   * @returns {{forgotten: number, mode: string}}
   */
  function forget(idOrQuery, opts = {}) {
    const mode = opts && opts.mode === "purge" ? "purge" : "tombstone";
    let forgotten = 0;
    try {
      const targets = [];
      if (typeof idOrQuery === "string" && store.has(idOrQuery)) {
        targets.push(idOrQuery);
      } else if (typeof idOrQuery === "string" && idOrQuery) {
        for (const h of index.search(idOrQuery, {})) targets.push(h.id);
      }
      for (const id of targets) {
        const rec = store.get(id);
        if (!rec) continue;
        if (mode === "purge") {
          if (store.remove(id)) { index.delete(id); forgotten++; }
        } else if (!rec.tombstone) {
          store.patch(id, { tombstone: true });
          index.delete(id);
          forgotten++;
        }
      }
    } catch {}
    return { forgotten, mode };
  }

  /**
   * consolidate：维护。M1（整改2）给出真实计数：
   *   - expired：ttl 过期 → 墓碑
   *   - merged：同 (scope, sessionId, 归一化文本) 的重复条目合并（保留最早 firstSeen、累加 seenCount、
   *             合并 provenance，被合并项打墓碑）。merged = 本次并入的**多余副本**条数。
   *   - promoted：suggestLayer 建议层级高于当前 → 提升
   *   - conflicts：本轮新解决的冲突数。冲突在写入路径即时消解（见 remember），
   *             consolidate 不再重复制造冲突，故恒为真实值 0。
   * @param {{now?: number}} [opts]
   * @returns {{promoted: number, merged: number, conflicts: number, expired: number}}
   */
  function consolidate(opts = {}) {
    const now = Number.isFinite(opts && opts.now) ? opts.now : clock();
    let expired = 0, merged = 0, promoted = 0;
    try {
      // 1) 过期
      for (const rec of findExpired(store.all(), { now })) {
        store.patch(rec.id, { tombstone: true });
        index.delete(rec.id);
        expired++;
      }

      // 2) 重复合并（同会话内同事实的多条独立记录）
      for (const group of duplicateGroups(store.live())) {
        const plan = planMerge(group);
        let prov = [];
        for (const id of [plan.keepId, ...plan.dropIds]) {
          const r = store.get(id);
          if (r) prov = mergeProvenance(prov, r.provenance);
        }
        store.patch(plan.keepId, {
          seenCount: plan.seenCount,
          firstSeen: plan.firstSeen,
          lastSeen: plan.lastSeen,
          provenance: prov,
        });
        for (const dropId of plan.dropIds) {
          store.patch(dropId, { tombstone: true });
          index.delete(dropId);
          merged++;
        }
        // 幸存者的 term 集合不变（文本/三元组未动），索引无需重建
      }

      // 3) 提升建议（重复度用 seenCount 作 repeats）
      for (const rec of store.live()) {
        const suggested = suggestLayer(rec, { repeats: rec.seenCount });
        if (suggested > rec.layer) { store.patch(rec.id, { layer: suggested }); promoted++; }
      }
    } catch {}
    return { promoted, merged, conflicts: 0, expired };
  }

  /**
   * export：导出真相源。'jsonl' 含墓碑（可追溯）；'md' 只导存活记录（人读）。
   * @param {{format?: 'md'|'jsonl'}|string} [arg]
   * @returns {string}
   */
  function exportData(arg) {
    const format = typeof arg === "string" ? arg : (arg && arg.format) || "md";
    try {
      if (format === "jsonl") return store.toJsonl();
      // md
      const parts = ["# Memory Export", ""];
      for (const rec of store.live()) {
        parts.push(`## ${rec.id} (L${rec.layer}, ${rec.scope})`);
        parts.push(renderLine(rec));
        parts.push("");
      }
      return parts.join("\n");
    } catch {
      return "";
    }
  }

  return {
    observe,
    remember,
    forget,
    recall,
    consolidate,
    export: exportData,
    // ── 只读辅助（测试 / 适配器自省用；非 §3 冻结接口的一部分）──
    get size() { return store.size(); },
    get store() { return store; },
    get index() { return index; },
  };
}

// 便捷再导出：门面消费者常需要 token 估算与编译原语。
export { estimateTokens, compile, stableStringify };
