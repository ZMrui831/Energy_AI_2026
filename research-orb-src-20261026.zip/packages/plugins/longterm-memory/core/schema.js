// schema.js — 记忆内核的记录模型 / 校验 / 稳定序列化。
//
// M0（接口冻结骨架）：本文件只依赖 node: 内置模块，禁止 cordis / electron / 网络 / 第三方包，
// 禁止读 ~/.dsh。所有函数都是纯函数（同输入 → 同输出），保证「字节可复现」这条硬不变量。
//
// 记录（record）采用轻量四元组 + 双时态（总纲 §4 / I4）：
//   id           稳定内容哈希（由 identity 派生，天然去重）
//   layer        0=工作 1=情节 2=语义 3=画像
//   scope        'project' | 'global'（I6 跨项目路由）
//   s/p/o        主体 / 谓词 / 客体（可为 null；纯文本事实走 text）
//   text         事实的自然语言表述（永远是非负长度字符串）
//   importance   0..1 重要度
//   source       来源标识（如 'dsh' / 'user'）
//   ts           创建时间（epoch ms；由调用方给定，绝不在读取路径用 Date.now()）
//   tValid       有效起点（epoch ms 或 null）—— 双时态之一
//   ttl          存活毫秒数或 null（null = 不过期）
//   supersedes   写在**旧记录**上，指向取代它的新记录 id（冲突消解，总纲 §4：新的胜出，旧的写 supersedes + 墓碑）
//   tombstone    墓碑标记（遗忘后仍在真相源里可追溯，I5）
//   seenCount    该事实被观测到的次数（内容哈希去重时累加，整改1）
//   firstSeen    最早观测时间（epoch ms，稳定；不进 recall 可见文本）
//   lastSeen     最晚观测时间（epoch ms，稳定；不进 recall 可见文本）
//   provenance   [{sessionId, seq, sourceKind, model, tMs}] —— 溯源数组，按 (tMs,sessionId,seq) 排序去重、最多 8 条（整改1 / I5）

import { createHash } from "node:crypto";

/** 记录字段的规范顺序。stableStringify 会按键排序，这里仅作文档与默认骨架。 */
export const RECORD_FIELDS = [
  "id", "layer", "scope", "s", "p", "o", "text",
  "importance", "source", "ts", "firstSeen", "lastSeen", "tValid", "ttl",
  "supersedes", "tombstone", "seenCount", "provenance",
];

const SCOPES = new Set(["project", "global"]);

/**
 * 稳定序列化：递归地按键名字典序输出 JSON，保证「同输入 → 字节相同输出」。
 * - 对象键排序（数组保持顺序，因为顺序本身是语义）
 * - undefined 归一为 null（JSON 无 undefined）
 * - 数字不做美化，直接 JSON 原生表示
 * @param {*} value 任意可 JSON 化的值
 * @returns {string} 确定性 JSON 字符串
 */
export function stableStringify(value) {
  return JSON.stringify(sortDeep(value));
}

function sortDeep(v) {
  if (v === undefined) return null;
  if (Array.isArray(v)) return v.map(sortDeep);
  if (v && typeof v === "object") {
    const out = {};
    for (const k of Object.keys(v).sort()) out[k] = sortDeep(v[k]);
    return out;
  }
  return v;
}

/** 内容哈希（sha1 前 16 位十六进制）。用于派生稳定 id。 */
export function hashId(identity) {
  return createHash("sha1").update(stableStringify(identity)).digest("hex").slice(0, 16);
}

function str(v) {
  return typeof v === "string" ? v : v == null ? null : String(v);
}
function num(v, dflt) {
  return typeof v === "number" && Number.isFinite(v) ? v : dflt;
}
function clip01(v, dflt) {
  const n = num(v, dflt);
  return n < 0 ? 0 : n > 1 ? 1 : n;
}
function normText(v) {
  const s = str(v);
  return s == null ? "" : s.trim();
}

/**
 * 从 identity 字段派生稳定 id：text / s / p / o / scope 归一后哈希。
 * ts / importance 等易变字段**不进** identity，所以「同事实两次 remember」得到同 id → 天然去重。
 */
export function deriveId({ s = null, p = null, o = null, text = "", scope = "project" } = {}) {
  return hashId({
    s: s ? String(s).trim().toLowerCase() : null,
    p: p ? String(p).trim().toLowerCase() : null,
    o: o ? String(o).trim().toLowerCase() : null,
    text: normText(text).toLowerCase(),
    scope,
  });
}

/**
 * 归一化一条记录：填默认值、夹取范围、派生 id（若未给）。
 * 纯函数；绝不抛（畸形输入退化为一条空文本记录，由 validateRecord 标记不合法）。
 * @param {object} input 原始事实：{s,p,o} 或 {text}，外加 scope/source/importance/ttl/tValid/layer/ts/id/provenance/supersedes/tombstone
 * @returns {object} 规范记录
 */
export function normalizeRecord(input) {
  const src = input && typeof input === "object" ? input : {};
  const scope = SCOPES.has(src.scope) ? src.scope : "project";
  const s = str(src.s);
  const p = str(src.p);
  const o = str(src.o);
  const text = normText(src.text);
  const id = typeof src.id === "string" && src.id ? src.id : deriveId({ s, p, o, text, scope });
  const ts = num(src.ts, 0);
  const provenance = normalizeProvenance(src, ts);
  // seenCount：出现次数。给了 provenance 数组时以条数为准，至少 1。
  const seenCount = Math.max(1, Math.trunc(num(src.seenCount, provenance.length || 1)));
  // firstSeen / lastSeen：最早 / 最晚观测时间（epoch ms）。缺省用 ts；渲染稳定（不进可见文本）。
  const firstSeen = num(src.firstSeen, ts);
  const lastSeen = num(src.lastSeen, ts);
  return {
    id,
    layer: Math.min(3, Math.max(0, Math.trunc(num(src.layer, 1)))),
    scope,
    s, p, o, text,
    importance: clip01(src.importance, 0.5),
    source: str(src.source) || "unknown",
    ts,
    firstSeen,
    lastSeen,
    tValid: num(src.tValid, null),
    ttl: num(src.ttl, null),
    supersedes: str(src.supersedes),
    tombstone: src.tombstone === true,
    seenCount,
    provenance,
  };
}

/** 规范单条溯源项。兼容旧字段名（session/kind）与新字段名（sessionId/sourceKind）。 */
function provEntry(e) {
  const s = e && typeof e === "object" ? e : {};
  return {
    sessionId: str(s.sessionId || s.session),
    seq: num(s.seq, null),
    sourceKind: str(s.sourceKind || s.kind),
    model: str(s.model),
    tMs: num(s.tMs != null ? s.tMs : (s.ts != null ? s.ts : s.time), null),
  };
}

/** 溯源去重键：规范化后用稳定序列化取指纹（精确，不受字段内容分隔符影响）。 */
function provKey(e) {
  return stableStringify(e);
}

/**
 * 归一化 provenance：接受数组 / 单个对象（新旧字段名皆可）/ 顶层字段，产出**排序去重、最多 8 条**的数组。
 * 排序键 (tMs, sessionId, seq) 保证字节稳定（同输入 → 同输出，整改1 要求）。
 */
export function normalizeProvenance(src, ts = 0) {
  let raw = [];
  const p = src && src.provenance;
  if (Array.isArray(p)) raw = p.map(provEntry);
  else if (p && typeof p === "object") raw = [provEntry({ ...p, tMs: p.tMs != null ? p.tMs : ts })];
  else if (src && (src.sessionId || src.session || src.sourceKind || src.kind)) {
    raw = [provEntry({ sessionId: src.sessionId || src.session, seq: src.seq, sourceKind: src.sourceKind || src.kind, model: src.model, tMs: ts })];
  }
  return dedupSortCapProvenance(raw);
}

/** 合并两组溯源：拼接 → 排序 → 去重 → 截断到 8（整改1 的存储层去重上限）。 */
export function mergeProvenance(a, b) {
  const arr = (Array.isArray(a) ? a : []).concat(Array.isArray(b) ? b : []).map(provEntry);
  return dedupSortCapProvenance(arr);
}

/** 统计 next 相对 prev 新增了几条**不同的**观测（重放同一观测不计）。两组都应是已规范化的数组。 */
export function countNewProvenance(prev, next) {
  const keys = new Set((Array.isArray(prev) ? prev : []).map(provKey));
  let added = 0;
  for (const e of (Array.isArray(next) ? next : [])) {
    const k = provKey(e);
    if (keys.has(k)) continue;
    keys.add(k);
    added++;
  }
  return added;
}

function dedupSortCapProvenance(arr, cap = 8) {
  const seen = new Set();
  const uniq = [];
  for (const e of arr) {
    const k = provKey(e);
    if (seen.has(k)) continue;
    seen.add(k);
    uniq.push(e);
  }
  uniq.sort((x, y) =>
    (num(x.tMs, 0) - num(y.tMs, 0)) || cmpStr(x.sessionId, y.sessionId) || (num(x.seq, 0) - num(y.seq, 0)));
  return uniq.slice(0, cap);
}

function cmpStr(a, b) {
  const x = a == null ? "" : String(a);
  const y = b == null ? "" : String(b);
  return x < y ? -1 : x > y ? 1 : 0;
}

/**
 * 校验一条记录是否语义合法（id 存在、text 或三元组至少有一项非空、范围正确）。
 * @param {object} rec 规范记录
 * @returns {{ok: boolean, errors: string[]}}
 */
export function validateRecord(rec) {
  const errors = [];
  if (!rec || typeof rec !== "object") return { ok: false, errors: ["record is not an object"] };
  if (typeof rec.id !== "string" || !rec.id) errors.push("missing id");
  if (!SCOPES.has(rec.scope)) errors.push("invalid scope");
  const hasTriple = rec.s || rec.p || rec.o;
  if (!hasTriple && !(typeof rec.text === "string" && rec.text.length > 0)) {
    errors.push("empty fact: neither (s,p,o) nor text");
  }
  if (typeof rec.importance !== "number" || rec.importance < 0 || rec.importance > 1) {
    errors.push("importance out of [0,1]");
  }
  if (!(rec.layer >= 0 && rec.layer <= 3)) errors.push("layer out of [0,3]");
  if (typeof rec.tombstone !== "boolean") errors.push("tombstone not boolean");
  if (!Array.isArray(rec.provenance)) errors.push("provenance not an array");
  return { ok: errors.length === 0, errors };
}

/** 把一条记录序列化为 JSONL 的一行（稳定字节）。 */
export function recordToJsonl(rec) {
  return stableStringify(rec);
}
