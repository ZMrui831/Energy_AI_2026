// temporal.js — 阶段2 读侧：asOf 时间旅行 + 真冲突检测（零 LLM，纯规则）。
//
// 设计约束（对应任务书硬要求）：
//   · 只在 compileFromEntries 显式收到 opts.asOf 时才被调用；asOf 缺省时 compile.js 不调用本模块，
//     因此"asOf 缺省时与阶段1逐字节相同"由"不进入本模块"天然保证（golden 比对验证）。
//   · 不靠语义相似猜：冲突键 key = 去掉「值 + 日期 + 触发词 + 系词」之后的归一化主语+属性。
//   · 优先从正文已有括号日期派生 validFrom；其次行尾 <!--validFrom:...--> 标记；
//     解析不到 → validFrom=null（视为开放区间起点）；绝不用写入时间 ts 顶替。
//   · validTo：优先 <!--validTo:...--> 标记；否则由替换关系推断（更晚/替换事实的 validFrom 成为前一条的 validTo）。
//   · 真冲突：同 key 在 asOf 处仍有 ≥2 个取值不同的有效事实 → meta.conflict=true + 注入"请向用户确认"说明，不输出任一值。
//
// 仅依赖 node 内置；不依赖 cordis / 网络 / 第三方。所有解析失败静默降级（返回空/放行）。

// 容忍「日期 + 时间」：正文可能是 （2026-05-10 12:00），旧正则只吃纯日期会漏掉整段 → validFrom=null。
const DATE_FULL = /[（(]\s*(\d{4})[-./年](\d{1,2})[-./月](\d{1,2})(?:\s+\d{1,2}:\d{2}(?::\d{2})?)?\s*[日号]?\s*[）)]/;
const DATE_MONTH = /[（(]\s*(\d{4})[-./年](\d{1,2})\s*[）)]/;
const TIME_RE = /\s*\d{1,2}:\d{2}(?::\d{2})?/;
const REPLACEMENT_RE = /(改成|改为|更新为|更新成|变更为|现在代号|旧代号|已更新|变成|变为)/;
const CODE_RE = /[A-Za-z0-9]+(?:[-_][A-Za-z0-9]+)+/g;
const NUM_RE = /\b\d{2,}\b/g;
const COPULA_RE = /[是为]:?\s*/g;

/** 从正文提取 ISO 日期（优先完整日期，其次年月；返回 'YYYY-MM-DD' 或 null）。 */
export function extractDate(text) {
  const m = DATE_FULL.exec(text || "");
  if (m) return `${m[1]}-${m[2].padStart(2, "0")}-${m[3].padStart(2, "0")}`;
  const m2 = DATE_MONTH.exec(text || "");
  if (m2) return `${m2[1]}-${m2[2].padStart(2, "0")}-01`;
  return null;
}

/**
 * 剥离行尾 / 行内 <!--key:value;...--> 标记，返回 { clean, meta }。
 * 旧代码（阶段1）读带标记的新文件时：它只做 trimmed.slice(2)，会把标记连同文本一起保留，
 * 不会抛、不会丢事实（满足"向后兼容：旧代码读新文件不得抛错、不得丢事实"）。
 */
export function parseMarkers(text) {
  const meta = { validFrom: null, validTo: null, supersedes: null, supersededBy: null };
  const clean = String(text || "")
    .replace(/<!--([^>]+)-->/g, (_m, body) => {
      for (const kv of String(body).split(";")) {
        const idx = kv.indexOf(":");
        if (idx < 0) continue;
        const k = kv.slice(0, idx).trim();
        const v = kv.slice(idx + 1).trim();
        if (!v) continue;
        if (k === "validFrom") meta.validFrom = v;
        else if (k === "validTo") meta.validTo = v;
        else if (k === "supersedes") meta.supersedes = v;
        else if (k === "supersededBy") meta.supersededBy = v;
      }
      return "";
    })
    .replace(/\s+/g, " ")
    .trim();
  return { clean, meta };
}

/**
 * 解析单条事实的时间/冲突元数据（零 LLM）。
 * @returns {{clean:string, validFrom:?string, validTo:?string, supersedes:?string,
 *           supersededBy:?string, isReplacement:boolean, value:?string, key:string}}
 */
export function parseFactTemporal(text) {
  const { clean, meta } = parseMarkers(text);
  const validFrom = meta.validFrom || extractDate(clean);
  const validTo = meta.validTo || null;
  const isReplacement = REPLACEMENT_RE.test(clean);

  // 取值：替换句式取触发词之后的稀有代号/数字；否则取正文里的稀有代号/数字。
  let value = null;
  if (isReplacement) {
    const after = clean.split(REPLACEMENT_RE).slice(1).join(" ");
    value =
      [...after.matchAll(CODE_RE)].map((m) => m[0])[0] ||
      [...after.matchAll(NUM_RE)].map((m) => m[0])[0] ||
      null;
  } else {
    value = [...clean.matchAll(CODE_RE)].map((m) => m[0])[0] || [...clean.matchAll(NUM_RE)].map((m) => m[0])[0] || null;
  }

  // 构造 key：去掉值、日期、时间、触发词、系词（是/为），归一化。
  let key = clean;
  if (value) key = key.split(value).join(" ");
  key = key
    .replace(REPLACEMENT_RE, " ")
    .replace(DATE_FULL, " ")
    .replace(DATE_MONTH, " ")
    .replace(TIME_RE, " ")
    .replace(COPULA_RE, " ")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();

  return {
    clean,
    validFrom,
    validTo,
    supersedes: meta.supersedes,
    supersededBy: meta.supersededBy,
    isReplacement,
    value,
    key,
  };
}

const NULL_DATE = "9999-12-31";

function inRange(vf, vt, asOf) {
  const afterStart = !vf || vf <= asOf;
  const beforeEnd = !vt || asOf < vt;
  return afterStart && beforeEnd;
}

/**
 * asOf 时间旅行 + 真冲突检测。
 * @param {Array} entries 记忆条目（{ts,sessionId,title,facts:string[]}）
 * @param {string} asOf ISO 日期（'YYYY-MM-DD'）
 * @returns {{entries:Array, conflicts:Array<{key:string, values:string[]}>}}
 *   返回过滤后的条目（被时间淘汰的事实移除；冲突事实移除并改为"请向用户确认"说明行）；
 *   未改动入参。若 asOf 非法则原样返回（静默降级）。
 */
export function applyAsOf(entries, asOf) {
  if (typeof asOf !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(asOf)) {
    return { entries: entries || [], conflicts: [] };
  }
  const src = Array.isArray(entries) ? entries : [];

  // 条目级主导日期：条目内任一事实自带日期即作为整条（含无日期的助手回执）的兜底 validFrom。
  // 解决"助手回执行无日期 → 永远有效 → 跨时间边界泄漏未来/历史值"的问题。
  const entryDate = new Array(src.length).fill(null);
  src.forEach((e, ei) => {
    if (!e || !Array.isArray(e.facts)) return;
    for (const f of e.facts) {
      const d = extractDate(String(f == null ? "" : f));
      if (d) { entryDate[ei] = d; break; }
    }
  });

  const parsed = [];
  src.forEach((e, ei) => {
    if (!e || !Array.isArray(e.facts)) return;
    e.facts.forEach((f, fi) => {
      const p = parseFactTemporal(String(f == null ? "" : f));
      if (!p.validFrom) p.validFrom = entryDate[ei] || null; // 兜底：条目主导日期
      const idx = parsed.length;
      parsed.push({ ei, fi, raw: f, p, idx });
    });
  });

  const kept = new Array(parsed.length).fill(true);
  const byKey = new Map();
  parsed.forEach((rec) => {
    if (rec.p.key) {
      if (!byKey.has(rec.p.key)) byKey.set(rec.p.key, []);
      byKey.get(rec.p.key).push(rec.idx);
    }
  });

  const conflicts = [];
  const notesByEntry = new Map(); // ei -> [note]
  const NOTE = (key, values) =>
    `检测到关于「${key}」存在时间重叠且取值相互矛盾的多条记忆（例如 ${values.join(" / ")}），请向用户确认正确值，不要凭记忆猜测或替用户做选择。`;

  for (const [key, idxs] of byKey) {
    const group = idxs
      .map((i) => ({ i, p: parsed[i].p }))
      .sort((a, b) => (a.p.validFrom || NULL_DATE).localeCompare(b.p.validFrom || NULL_DATE));

    // 推断 validTo：更晚/替换事实的 validFrom 成为前一条的终点（处理"旧→新"替换链）。
    for (let i = 0; i < group.length - 1; i++) {
      const cur = group[i].p;
      const nxt = group[i + 1].p;
      if (cur.validTo) continue;
      if (nxt.validFrom && (nxt.isReplacement || nxt.validFrom > cur.validFrom)) {
        cur.validTo = nxt.validFrom;
      }
    }

    const validAt = group.filter((g) => inRange(g.p.validFrom, g.p.validTo, asOf));
    const distinct = new Set(validAt.map((g) => g.p.value));

    if (validAt.length >= 2 && distinct.size >= 2) {
      // 真冲突：时间重叠且值不同 → 不输出任一值，改为请用户确认。
      // 一并抑制所有携带冲突值的行（含助手回执等 echoed 行），不让任一值单独泄露。
      conflicts.push({ key, values: [...distinct] });
      const note = NOTE(key, [...distinct]);
      const valueSet = new Set(distinct);
      for (const rec of parsed) {
        if (rec.p.value && valueSet.has(rec.p.value) && kept[rec.idx]) {
          kept[rec.idx] = false;
          const ei = rec.ei;
          if (!notesByEntry.has(ei)) notesByEntry.set(ei, []);
          if (!notesByEntry.get(ei).includes(note)) notesByEntry.get(ei).push(note);
        }
      }
    } else {
      for (const g of group) if (!validAt.includes(g)) kept[g.i] = false;
    }
  }

  // 重建条目：保留 kept 事实（剥离标记），冲突 key 在所在条目追加说明行。
  // 债1：用一次 Map（键 `${ei}:${fi}`）把逐事实 O(n²) findIndex 降为 O(n)。
  const posByEiFi = new Map();
  for (const rec of parsed) posByEiFi.set(`${rec.ei}:${rec.fi}`, rec.idx);

  // 债2：覆盖率统计（asOf 不可观测性的对症修复）。
  //   dated     = 有日期事实数（validFrom 非空；含条目级主导日期兜底后的值）
  //   total     = 解析出的事实总数
  //   undatedKept = 无日期但被保留（未被冲突/时间淘汰）的事实条数
  // 这些数独立于 asOf 过滤结果，仅描述「记忆本身的时间 grounding 程度」。
  let datedCount = 0;
  for (const rec of parsed) if (rec.p.validFrom) datedCount++;
  let undatedKept = 0;
  for (const rec of parsed) if (!rec.p.validFrom && kept[rec.idx]) undatedKept++;

  const out = [];
  src.forEach((e, ei) => {
    if (!e) return;
    const facts = (Array.isArray(e.facts) ? e.facts : [])
      .filter((f, fi) => {
        const idx = posByEiFi.get(`${ei}:${fi}`);
        return idx !== undefined && kept[idx];
      })
      .map((f) => parseMarkers(String(f == null ? "" : f)).clean);
    if (notesByEntry.has(ei)) facts.push(...notesByEntry.get(ei));
    if (facts.length > 0) out.push({ ...e, facts });
  });

  return {
    entries: out,
    conflicts,
    coverage: { dated: datedCount, total: parsed.length, undatedKept },
  };
}

/** 规则命中率辅助：给定事实文本，返回其解析出的 key（供报告统计新旧 key 是否对齐）。 */
export function factKey(text) {
  return parseFactTemporal(String(text || "")).key;
}
