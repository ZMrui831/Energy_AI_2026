// store-jsonl.js — 追加写真相源（append-only source of truth）+ 崩溃安全 + 墓碑。
//
// M0：接口 + 内存实现。file 省略时纯内存跑（core-smoke 用），完全不碰磁盘。
// 提供 file 时才落盘：JSONL（一行一条稳定序列化的记录），写盘走 tmp + rename（崩溃安全）。
//
// 不变量：
//   - records() 保持插入顺序（确定性遍历）
//   - 同 id 只保留一条（去重发生在写入层）
//   - 墓碑记录**不删**：forget(mode:'tombstone') 只置位，真相源里仍可追溯（I5）
//   - 静默降级：所有磁盘 IO 失败都不抛，只返回 false / 空结果
//
// 只依赖 node:fs / node:path；禁止 cordis / electron / 网络 / ~/.dsh。

import { appendFileSync, mkdirSync, readFileSync, renameSync, unlinkSync, writeFileSync } from "node:fs";
import { dirname } from "node:path";
import { recordToJsonl, normalizeRecord, mergeProvenance, countNewProvenance } from "./schema.js";

/**
 * 创建一个真相源存储。
 * @param {{file?: string}} [opts] file 省略 = 纯内存（不落盘）
 * @returns {object} store
 */
export function createStore(opts = {}) {
  const file = typeof opts.file === "string" && opts.file ? opts.file : null;
  /** @type {Map<string, object>} id -> record，Map 保持插入顺序 */
  const byId = new Map();

  if (file) {
    // 冷启动：把已有 JSONL 读回内存（失败静默，视为空库）
    try {
      const raw = readFileSync(file, "utf8");
      for (const line of raw.split(/\r?\n/)) {
        const t = line.trim();
        if (!t) continue;
        try {
          const rec = normalizeRecord(JSON.parse(t));
          byId.set(rec.id, rec);
        } catch {}
      }
    } catch {}
  }

  return {
    /** 是否已配置落盘文件 */
    get file() { return file; },

    /** 全部记录（含墓碑），插入顺序。 */
    all() {
      return [...byId.values()];
    },

    /** 存活记录（非墓碑），插入顺序。 */
    live() {
      return [...byId.values()].filter((r) => !r.tombstone);
    },

    /** 按 id 取记录（可能 undefined）。 */
    get(id) {
      return typeof id === "string" ? byId.get(id) : undefined;
    },

    has(id) {
      return typeof id === "string" && byId.has(id);
    },

    /**
     * 追加/更新一条记录。同 id（内容哈希相同）时做**溯源合并**而非覆盖（整改1）：
     *   - provenance：并集去重排序截断 8；seenCount 累加「新增的不同观测」数
     *   - firstSeen 取更早、lastSeen 取更晚；ts 保留首次
     *   - 重放同一观测（同 sessionId/seq/model/tMs）→ seenCount 不增、provenance 不变
     * 无 prev 时直接写入。
     * @param {object} rec 规范记录
     * @returns {{record: object, created: boolean}}
     */
    append(rec) {
      const norm = rec && rec.id ? rec : normalizeRecord(rec);
      const prev = byId.get(norm.id);
      let created;
      if (prev) {
        created = false;
        const prevProv = Array.isArray(prev.provenance) ? prev.provenance : [];
        const normProv = Array.isArray(norm.provenance) ? norm.provenance : [];
        const added = countNewProvenance(prevProv, normProv);
        const fs = pickMin(firstOf(prev), firstOf(norm));
        const ls = pickMax(lastOf(prev), lastOf(norm));
        byId.set(norm.id, {
          ...norm,
          ts: prev.ts || norm.ts,
          provenance: mergeProvenance(prevProv, normProv),
          seenCount: (prev.seenCount || 1) + added,
          firstSeen: Number.isFinite(fs) ? fs : (norm.firstSeen ?? null),
          lastSeen: Number.isFinite(ls) ? ls : (norm.lastSeen ?? null),
        });
      } else {
        created = true;
        byId.set(norm.id, norm);
      }
      if (file) persist(byId, file);
      return { record: byId.get(norm.id), created };
    },

    /**
     * 就地打补丁（用于置墓碑 / 写 supersedes）。不新建记录。
     * @param {string} id
     * @param {object} patch
     * @returns {object|null} 更新后的记录，或 null（不存在）
     */
    patch(id, patch) {
      const prev = byId.get(id);
      if (!prev) return null;
      const next = { ...prev, ...(patch || {}) };
      byId.set(id, next);
      if (file) persist(byId, file);
      return next;
    },

    /** 物理删除（mode:'purge' 用）。真相源里彻底消失。 */
    remove(id) {
      const ok = byId.delete(id);
      if (ok && file) persist(byId, file);
      return ok;
    },

    /** 序列化为 JSONL 文本（含墓碑），字节稳定。 */
    toJsonl() {
      return byId.size === 0 ? "" : [...byId.values()].map(recordToJsonl).join("\n") + "\n";
    },

    /** 记录条数（含墓碑）。 */
    size() {
      return byId.size;
    },
  };
}

/** 崩溃安全落盘：tmp + rename。失败静默返回 false。 */
function persist(byId, file) {
  const tmp = `${file}.${process.pid}.${Date.now().toString(36)}.tmp`;
  try {
    mkdirSync(dirname(file), { recursive: true });
    const body = byId.size === 0 ? "" : [...byId.values()].map(recordToJsonl).join("\n") + "\n";
    writeFileSync(tmp, body, "utf8");
    renameSync(tmp, file);
    return true;
  } catch {
    try { unlinkSync(tmp); } catch {}
    return false;
  }
}

/** 追加单行的低层原语（预留给 M1 的真·append-only 日志；M0 未接线）。 */
export function appendLine(file, line) {
  try {
    mkdirSync(dirname(file), { recursive: true });
    appendFileSync(file, line.endsWith("\n") ? line : line + "\n", "utf8");
    return true;
  } catch {
    return false;
  }
}

// ── firstSeen/lastSeen 合并小工具（finite 优先，缺省退化到 ts）──────────────
function firstOf(r) {
  return Number.isFinite(r && r.firstSeen) ? r.firstSeen : (Number.isFinite(r && r.ts) ? r.ts : NaN);
}
function lastOf(r) {
  return Number.isFinite(r && r.lastSeen) ? r.lastSeen : (Number.isFinite(r && r.ts) ? r.ts : NaN);
}
function pickMin(a, b) {
  if (!Number.isFinite(a)) return b;
  if (!Number.isFinite(b)) return a;
  return a <= b ? a : b;
}
function pickMax(a, b) {
  if (!Number.isFinite(a)) return b;
  if (!Number.isFinite(b)) return a;
  return a >= b ? a : b;
}
