// packages/plugins/longterm-memory/context.mjs
//
// S29/S30：读侧 readLongTermMemoryContext —— 纯读、全 try/catch、异常返回 ''。
// 数据源：data\memory\<scope>\longterm.md（S30 scope 分域；project 与 global 互不可见）。
// scope 从 config.json 读（默认 project），也可由调用方显式覆盖；文件不存在视为空记忆，不创建。
// 编排：复用内核 createMemory（api.js 门面）recall 的 BM25 + 预算编译；现开现关（读侧低频）。
import { existsSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT } from '../../core/src/safefs.mjs'
import { createMemory } from './core/api.js'
import { readLongTermConfig, longtermFileFor } from './config.mjs'

export const LONGTERM_FILE = longtermFileFor('project')

/**
 * 读长期记忆片段（进 system）。
 * @param {{root?:string, query?:string, budgetTokens?:number, scope?:'project'|'global'}} opts
 * @returns {string} 记忆文本；空库/关闭/异常一律 ''（不注入、不抛）
 */
export function readLongTermMemoryContext(opts = {}) {
  try {
    const root = opts.root || PROJECT_ROOT
    const cfg = readLongTermConfig({ root })
    if (!cfg.enabled) return ''
    const scope = opts.scope === 'global' || opts.scope === 'project' ? opts.scope : cfg.scope
    const file = longtermFileFor(scope, root)
    if (!existsSync(file)) return '' // 文件不存在视为空记忆，不创建
    const budget = Number.isFinite(opts.budgetTokens) && opts.budgetTokens > 0 ? opts.budgetTokens : cfg.budgetTokens
    const mem = createMemory({ file, now: () => Date.now() })
    const r = mem.recall(typeof opts.query === 'string' ? opts.query : '', { budgetTokens: budget, now: Date.now() })
    const text = r && typeof r.text === 'string' ? r.text.trim() : ''
    return text
  } catch {
    return ''
  }
}

export default { readLongTermMemoryContext, LONGTERM_FILE }
