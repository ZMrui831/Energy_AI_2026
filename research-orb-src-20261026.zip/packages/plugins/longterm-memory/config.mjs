// packages/plugins/longterm-memory/config.mjs
//
// S29·2.1 配置层：data\memory\config.json（缺省 {enabled:true, budgetTokens:300, writeGovernance:true}）。
// 纯读 + 全 try/catch：文件缺失/损坏/字段非法 → 回落缺省值（fail-open 到缺省，不崩宿主）。
import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, DATA_DIR, dataPath, safeWrite } from '../../core/src/safefs.mjs'

export const LT_DEFAULTS = Object.freeze({
  enabled: true,
  budgetTokens: 300,        // 长期记忆注入预算（main.mjs 三段总预算 1400 内的一级）
  writeGovernance: true,    // 写侧治理（事实过滤/条数/字数上限）总闸
  scope: 'project',         // S30：对齐 Node 适配器契约（project|global）——多项目防串味
})

/** 真相源路径：data\memory\<scope>\longterm.md（scope 分域，project 与 global 互不可见）。 */
export function longtermFileFor(scope = 'project', root) {
  const s = scope === 'global' ? 'global' : 'project'
  // S36：双模数据根——显式 root 保持 <root>/data 旧布局；缺省走 DATA_DIR
  const base = root == null ? DATA_DIR : join(root, 'data')
  return join(base, 'memory', s, 'longterm.md')
}

export function readLongTermConfig(opts = {}) {
  const root = opts && Object.prototype.hasOwnProperty.call(opts, 'root') ? opts.root : undefined
  try {
    const base = root == null ? dataPath('memory') : join(root, 'data', 'memory')
    const p = join(base, 'config.json')
    if (!existsSync(p)) return { ...LT_DEFAULTS, source: 'default' }
    const doc = JSON.parse(readFileSync(p, 'utf8'))
    const cfg = doc && typeof doc === 'object' ? doc : {}
    return {
      enabled: typeof cfg.enabled === 'boolean' ? cfg.enabled : LT_DEFAULTS.enabled,
      budgetTokens: Number.isFinite(cfg.budgetTokens) && cfg.budgetTokens > 0 ? Math.floor(cfg.budgetTokens) : LT_DEFAULTS.budgetTokens,
      writeGovernance: typeof cfg.writeGovernance === 'boolean' ? cfg.writeGovernance : LT_DEFAULTS.writeGovernance,
      scope: cfg.scope === 'global' ? 'global' : 'project',
      source: 'file',
    }
  } catch {
    return { ...LT_DEFAULTS, source: 'parse-error' }
  }
}

export function writeLongTermConfig(patch = {}, opts = {}) {
  const root = opts && Object.prototype.hasOwnProperty.call(opts, 'root') ? opts.root : undefined
  const base = root == null ? dataPath('memory') : join(root, 'data', 'memory')
  const cur = readLongTermConfig({ root })
  const next = { ...cur, ...patch }
  delete next.source
  safeWrite(join(base, 'config.json'), JSON.stringify(next, null, 2))
  return readLongTermConfig({ root })
}

export default { LT_DEFAULTS, readLongTermConfig, writeLongTermConfig }
