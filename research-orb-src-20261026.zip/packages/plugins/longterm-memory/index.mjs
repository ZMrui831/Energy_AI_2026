// packages/plugins/longterm-memory/index.mjs
//
// S29/S30 插件入口：长期记忆（两级中的第二层，跨会话）。
// 写侧由宿主在 runTurn 成功后直接调 observeTurn（main.mjs 已接线，S30 起传 assistantText）；
// 本插件提供 /memory 命令：status/facts/on/off/budget/scope/forget/export（S30 对齐 Node 适配器契约）。
// 注：命令名是 /memory（长期记忆）；/mem 是 coach 的二级记忆命令，二者不同层，勿混。
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { join } from 'node:path'
import { PROJECT_ROOT, safeWrite, logPath, appendJsonl, dataPath } from '../../core/src/safefs.mjs'
import { readLongTermConfig, writeLongTermConfig, longtermFileFor, LT_DEFAULTS } from './config.mjs'
import { readLongTermMemoryContext } from './context.mjs'
import { observeTurn, isWritableFact, isWritableAssistFact, MAX_PER_TURN, MAX_CHARS } from './write.mjs'
import { lineStats, recallLines, LINE_NAMES } from './lines.mjs'

export const PLUGIN_ID = 'longterm-memory'

export async function activate(ctx) {
  const log = (ctx && ctx.log) || console
  if (!(ctx && ctx.ui && typeof ctx.ui.registerCommand === 'function')) {
    log.warn('longterm-memory: 宿主未提供 ui.registerCommand')
    return { ok: false }
  }

  /** 打开当前 scope 的内核实例（只读/维护用）。 */
  const openMem = async (scope) => {
    const { createMemory } = await import('./core/api.js')
    const file = longtermFileFor(scope)
    return { file, mem: existsSync(file) ? createMemory({ file, now: () => Date.now() }) : null }
  }

  ctx.ui.registerCommand({
    name: 'memory',
    title: '长期记忆（跨会话）',
    description: '用法：/memory status｜/memory facts [n] [--line work|life|all]｜/memory recall <关键词> [--line …]｜/memory on｜/memory off｜/memory budget <n>｜/memory scope <project|global>｜/memory forget <id|关键词>｜/memory export <文件>',
    run: async (rest = '') => {
      const raw = String(rest || '').trim()
      const sub = (raw.split(/\s+/)[0] || '').toLowerCase()
      const arg = raw.split(/\s+/)[1] || ''
      try {
        if (sub === 'status' || sub === '') {
          const cfg = readLongTermConfig()
          const { file, mem } = await openMem(cfg.scope)
          const live = mem ? mem.store.live().length : 0
          return {
            ok: true,
            text: [
              '长期记忆状态：',
              `· 开关：enabled=${cfg.enabled}（来源 ${cfg.source}）`,
              `· scope：${cfg.scope}（project 与 global 分域存储，互不可见）`,
              `· 注入预算：${cfg.budgetTokens} token`,
              `· 写侧治理：writeGovernance=${cfg.writeGovernance}`,
              `· 真相源：data\\memory\\${cfg.scope}\\longterm.md（存活事实 ${live} 条）`,
              ...(await (async () => { try { const st = await lineStats(); return [`· 双记忆线：work ${st.work.live} 条 / life ${st.life.live} 条（data\\memory\\work.md｜life.md）`] } catch { return [] } })()),
              '· 注入顺序：coach 摘要 → coach 记忆 → 长期记忆（总预算 1400，超限按此序裁剪）',
            ].join('\n'),
          }
        }
        if (sub === 'facts') {
          const cfg = readLongTermConfig()
          // S35·B：--line work|life 过滤双记忆线账本
          const lineArg = (raw.match(/--line\s+(work|life|all)/) || [])[1]
          if (lineArg) {
            const st = await lineStats()
            const pick = lineArg === 'all' ? [...LINE_NAMES] : [lineArg]
            const blocks = []
            for (const ln of pick) blocks.push(`[${ln}] 存活 ${st[ln].live} 条（data\\memory\\${ln}.md）`)
            return { ok: true, text: `双记忆线（--line ${lineArg}）：\n` + blocks.join('\n') + `\n（跨线召回用 /memory recall <关键词> --line work|life|all）` }
          }
          const { file, mem } = await openMem(cfg.scope)
          if (!mem) return { ok: true, text: '（暂无长期记忆）' }
          const rows = mem.store.live().slice(-(Number(arg) || 10))
          if (!rows.length) return { ok: true, text: '（暂无存活事实）' }
          return { ok: true, text: `[scope=${cfg.scope}] 存活事实 ${rows.length} 条：\n` + rows.map((r) => `· ${r.id} [L${r.layer}] ${String(r.text || '').slice(0, 80)}`).join('\n') }
        }
        if (sub === 'on' || sub === 'off') {
          const next = writeLongTermConfig({ enabled: sub === 'on' })
          return { ok: true, text: `长期记忆已${sub === 'on' ? '开启' : '关闭'}（enabled=${next.enabled}；关闭后注入为空、写侧跳过）` }
        }
        if (sub === 'budget') {
          const n = Number(arg)
          if (!Number.isFinite(n) || n <= 0) return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '用法：/memory budget <正整数>' } }
          const next = writeLongTermConfig({ budgetTokens: Math.floor(n) })
          return { ok: true, text: `注入预算已设为 ${next.budgetTokens} token` }
        }
        if (sub === 'scope') {
          if (arg !== 'project' && arg !== 'global') return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '用法：/memory scope <project|global>' } }
          const next = writeLongTermConfig({ scope: arg })
          return { ok: true, text: `scope 已切换为 ${next.scope}（读写都走 data\\memory\\${next.scope}\\longterm.md）` }
        }
        if (sub === 'forget') {
          // S30：对齐 Node 适配器契约——按 id 或关键词遗忘（默认墓碑，可追溯）；走 safefs 审计
          const q = raw.slice(6).trim()
          if (!q) return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '用法：/memory forget <id|关键词>' } }
          const cfg = readLongTermConfig()
          const { mem } = await openMem(cfg.scope)
          if (!mem) return { ok: true, text: '（暂无长期记忆）' }
          const r = mem.forget(q, { mode: 'tombstone' })
          try { appendJsonl(logPath('coach.jsonl'), { ts: new Date().toISOString(), kind: 'longterm-forget', scope: cfg.scope, query: q.slice(0, 60), forgotten: r.forgotten }) } catch { /* 尽力 */ }
          if (!r.forgotten || (Array.isArray(r.forgotten) && r.forgotten.length === 0)) return { ok: true, text: `未命中「${q}」（scope=${cfg.scope}）` }
          const list = Array.isArray(r.forgotten) ? r.forgotten.join(', ') : String(r.forgotten)
          return { ok: true, text: `已遗忘（墓碑，可追溯）：${list}（scope=${cfg.scope}；审计已留行）` }
        }
        if (sub === 'recall') {
          // S35·B：跨线召回——/memory recall <关键词> [--line work|life|all]；来源线以 [work]/[life] 标注
          const rest2 = raw.slice(6).trim()
          const lineArg = (rest2.match(/--line\s+(work|life|all)/) || [])[1] || 'all'
          const q = rest2.replace(/--line\s+(work|life|all)/g, '').trim()
          if (!q) return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '用法：/memory recall <关键词> [--line work|life|all]' } }
          const r = await recallLines(q, { line: lineArg })
          if (!r.ok) return { ok: true, text: '（召回为空：' + (r.reason || '无线内命中') + '）' }
          try { appendJsonl(logPath('coach.jsonl'), { ts: new Date().toISOString(), kind: 'longterm-recall-lines', line: lineArg, query: q.slice(0, 60) }) } catch { /* 尽力 */ }
          return { ok: true, text: `跨线召回（--line ${lineArg}；来源线已标注）：\n\n${r.text}` }
        }
        if (sub === 'export') {
          // S30：导出全部存活事实为 Markdown（不含任何路径信息，防泄漏）
          const outName = arg || `longterm-export-${new Date().toISOString().slice(0, 10)}.md`
          if (!/^[\w.-]+$/.test(outName)) return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '导出文件名只允许字母/数字/点/连字符' } }
          const cfg = readLongTermConfig()
          const { mem } = await openMem(cfg.scope)
          if (!mem) return { ok: true, text: '（暂无长期记忆可导出）' }
          const rows = mem.store.live()
          if (!rows.length) return { ok: true, text: '（暂无存活事实可导出）' }
          const body = ['# 长期记忆导出', '', `- scope：${cfg.scope}`, `- 导出时间：${new Date().toISOString()}`, `- 存活事实：${rows.length} 条`, '', ...rows.map((r) => `- [L${r.layer}] ${String(r.text || '')}`)].join('\n')
          const outPath = safeWrite(dataPath('memory', outName), body + '\n', 'utf8')
          try { appendJsonl(logPath('coach.jsonl'), { ts: new Date().toISOString(), kind: 'longterm-export', scope: cfg.scope, file: outName, count: rows.length }) } catch { /* 尽力 */ }
          return { ok: true, text: `已导出 ${rows.length} 条存活事实 → data\\memory\\${outName}（不含路径信息；审计已留行）` }
        }
        return { ok: false, code: 'E_USAGE', ui: { kind: 'error', message: '用法：/memory status｜/memory facts [n] [--line work|life|all]｜/memory recall <关键词> [--line …]｜/memory on｜/memory off｜/memory budget <n>｜/memory scope <project|global>｜/memory forget <id|关键词>｜/memory export <文件>' } }
      } catch (e) {
        return { ok: false, code: (e && e.code) || 'E_MEMORY', ui: { kind: 'error', message: String((e && e.message) || e) } }
      }
    },
  })

  return {
    ok: true,
    deactivate() { log.info('[longterm-memory] 已停用（写侧由宿主 runTurn 直接调用，无本插件持有的定时器）') },
    __read: readLongTermMemoryContext,
    __write: observeTurn,
  }
}

export default { activate, PLUGIN_ID, readLongTermMemoryContext, observeTurn, isWritableFact, isWritableAssistFact, readLongTermConfig, writeLongTermConfig, longtermFileFor, LT_DEFAULTS, MAX_PER_TURN, MAX_CHARS, lineStats, recallLines, LINE_NAMES }
