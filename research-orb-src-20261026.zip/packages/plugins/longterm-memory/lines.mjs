// packages/plugins/longterm-memory/lines.mjs
//
// S35·B 双记忆线（工作/生活）：
//   · 分类：关键词表 + 规则（不猜）——work 命中 → work；life 命中 → life；两者都命中或都不命中 → null
//     （null 表示"无法归类"，绝不强行塞进某条线；调用方按"不确定跳过"处理并留审计）。
//   · 双账本：data\memory\work.md / life.md（各自经记忆内核 createMemory({file}) 落盘，
//     内核自动写契约头（namespace/updatedAt/…），两条线互不混写）。
//   · 迁移不丢旧记忆：本模块只新增两条线账本，既有 scope 账本（project|global longterm.md）不动。
//   · recall 跨线：按线召回后合并，来源线以 [work]/[life] 标注。
import { existsSync, readFileSync, writeFileSync } from 'node:fs'
import { dataPath, appendJsonl, logPath } from '../../core/src/safefs.mjs'

/** S35·B 关键词表（小写包含匹配）。work=科研/工作；life=娱乐/生活。 */
export const LINE_KEYWORDS = Object.freeze({
  // S67·2-A：扩表——work 增补 deepseek/visual studio/terminal/zotero/endnote/overleaf/word/
  // 代码/编译/文档/日报/doi；life 增补 哔哩/聊天/视频/动漫（原有 vscode/idea/pycharm/latex/
  // wps/excel/cmd/powershell/论文/文献/综述/arxiv 与 bilibili/youtube/抖音/游戏/steam/微信/qq/
  // 音乐/网易云/淘宝/京东/剧 保留）。
  work: [
    'code', 'idea', 'pycharm', 'webstorm', 'vscode', 'python', 'java', 'node', 'wps', 'winword', 'excel',
    'powerpnt', 'typora', 'obsidian', 'sumatrapdf', 'acrobat', 'matlab', 'visio', 'origin', 'latex', 'texworks',
    'cmd', 'powershell', 'windowsterminal', 'arxiv', 'github', '论文', '文献', '综述', '实验', '数据集', '模型',
    '训练', '微电网', '电网', '仿真', 'paper', 'journal', 'citation', '文献表', '科研',
    'deepseek', 'visual studio', 'terminal', 'zotero', 'endnote', 'overleaf', 'word',
    '代码', '编译', '文档', '日报', 'doi',
  ],
  life: [
    'netflix', 'youtube', 'bilibili', '爱奇艺', 'iqiyi', '腾讯视频', '优酷', 'douyu', '斗鱼', 'huya', 'steam',
    'epicgames', 'minecraft', 'javaw', 'mpv', 'vlc', 'potplayer', '抖音', 'douyin', 'kuaishou', '快手', '游戏',
    'video', 'game', '微信', 'wechat', 'qq', '音乐', '网易云', 'spotify', '淘宝', '京东', '购物', '外卖', '美团',
    '新闻', '天气', '股票', '基金', '支付宝', '知乎', '微博', '小红书', '旅行', '航班', '火车票', '电影', '剧',
    '哔哩', '聊天', '视频', '动漫',
  ],
})

export const LINE_NAMES = Object.freeze(['work', 'life'])

/** 统计某维关键词在文本中出现的总次数（S67·2-A：多类命中取"出现次数多"的一类）。 */
function countHits(text, list) {
  let n = 0
  for (const k of list) {
    let idx = 0
    while (idx <= text.length) {
      const at = text.indexOf(k, idx)
      if (at === -1) break
      n += 1
      idx = at + k.length
    }
  }
  return n
}

/**
 * 分类（关键词表 + 规则，不猜）：
 *   · 只有一维命中 → 该维
 *   · 两维都命中 → 取出现次数多的一类；次数相同（平票）→ null（不猜）
 *   · 都不命中 → null（无法归类，绝不强行入线）
 */
export function classifyLine(text = '') {
  const t = String(text || '').toLowerCase()
  if (!t.trim()) return null
  const w = countHits(t, LINE_KEYWORDS.work)
  const l = countHits(t, LINE_KEYWORDS.life)
  if (w === 0 && l === 0) return null
  if (w === l) return null // 平票：不猜
  return w > l ? 'work' : 'life'
}

/** 双账本路径：data\memory\work.md / life.md。 */
export function ledgerFileFor(line) {
  if (line !== 'work' && line !== 'life') throw new Error(`E_BAD_LINE: 未知记忆线 -> ${line}（只允许 work|life）`)
  return dataPath('memory', `${line}.md`)
}

/** 打开某条线的账本（记忆内核；首次写自动落契约头）。 */
export async function openLedger(line) {
  const { createMemory } = await import('./core/api.js')
  const file = ledgerFileFor(line)
  return { file, mem: existsSync(file) ? createMemory({ file, now: () => Date.now() }) : createMemory({ file, now: () => Date.now() }) }
}

function audit(rec) {
  try { appendJsonl(logPath('coach.jsonl'), { ts: new Date().toISOString(), ...rec }) } catch { /* 尽力 */ }
}

/**
 * S35·B 契约头（rc7 冻结格式，对齐 core/markdown.js buildFileHeader）：
 *   <!-- dsh-local-memory | schema: 1 | namespace: memory-lines-<line> | updatedAt: <iso> -->
 * 内核 store 每次全量重写会丢掉手插的头 → 每次追加后检查补齐；
 * 内核冷启动对非 JSON 行静默跳过，头对老解析器零影响。
 */
function ensureContractHeader(file, line) {
  try {
    if (!existsSync(file)) return
    const raw = readFileSync(file, 'utf8')
    if (raw.startsWith('<!-- dsh-local-memory')) return
    const header = `<!-- dsh-local-memory | schema: 1 | namespace: memory-lines-${line} | updatedAt: ${new Date().toISOString()} -->\n`
    writeFileSync(file, header + raw, 'utf8')
  } catch { /* 尽力 */ }
}

/**
 * 向某条线追加一条事实（走记忆内核 remember，内核负责去重/层位/契约头）。
 * @returns {{ok:boolean, line?:string, id?:string, skipped?:string, reason?:string}}
 */
export async function appendLineFact(line, text, meta = {}) {
  if (line !== 'work' && line !== 'life') return { ok: false, skipped: 'bad-line', reason: `未知记忆线 ${line}` }
  const body = String(text || '').trim()
  if (body.length < 8) return { ok: false, skipped: 'too-short', reason: '事实过短（<8 字符）无信息量' }
  if (body.length > 400) return { ok: false, skipped: 'too-long', reason: `事实过长（${body.length} 字符，上限 400）` }
  const { mem } = await openLedger(line)
  const r = mem.remember({ text: body }, { source: meta.source || 'line-classify' })
  const id = r && r.id
  ensureContractHeader(ledgerFileFor(line), line)
  audit({ kind: 'line-fact', line, id, chars: body.length, source: meta.source || 'line-classify' })
  return { ok: true, line, id }
}

/**
 * 跨线召回：按线召回后合并，来源线以 [work]/[life] 标注。
 * @param {{line?:'work'|'life'|'all', budgetTokens?:number, k?:number}} opts
 * @returns {{ok:boolean, text:string, items:Array<{line,id,tokens,score,text?}>, lines:string[]}}
 */
export async function recallLines(query, opts = {}) {
  const target = opts.line === 'work' || opts.line === 'life' ? [opts.line] : [...LINE_NAMES]
  const q = String(query || '').trim()
  if (!q) return { ok: false, text: '', items: [], lines: [], reason: '查询词为空' }
  const blocks = []
  const items = []
  for (const line of target) {
    const { file, mem } = await openLedger(line)
    if (!mem) continue
    const r = mem.recall(q, { budgetTokens: opts.budgetTokens || 150, k: opts.k || 5 })
    if (r && r.text && r.text.trim()) {
      blocks.push(`[${line}]\n${r.text.trim()}`)
      for (const it of r.items || []) items.push({ line, ...it })
    } else {
      blocks.push(`[${line}]\n（无线内命中）`)
    }
    void file
  }
  return { ok: true, text: blocks.join('\n\n'), items, lines: target }
}

/** 双账本现状（各线存活事实数）。 */
export async function lineStats() {
  const out = {}
  for (const line of LINE_NAMES) {
    const { file, mem } = await openLedger(line)
    out[line] = { file: `data\\memory\\${line}.md`, live: mem ? mem.store.live().length : 0 }
  }
  return out
}

/**
 * 截图压缩归类钩子（在 extract 拿到文本后调用）：分类 → 入对应线账本（不猜：null 就跳过并留审计）。
 * @returns {{category:'work'|'life'|null, written:boolean, skipped?:string}}
 */
export async function classifyAndStore({ window = '', process = '', text = '' } = {}) {
  const category = classifyLine(`${window} ${process} ${text}`)
  if (!category) {
    audit({ kind: 'line-uncertain', window: String(window).slice(0, 60), reason: '关键词规则无法归类（不猜）' })
    return { category: null, written: false, skipped: 'uncertain' }
  }
  const digest = `${String(window).slice(0, 60)}｜${String(process).slice(0, 40)}｜${String(text).replace(/\s+/g, ' ').slice(0, 160)}`
  const r = await appendLineFact(category, digest, { source: 'screenshot-classify' })
  return { category, written: !!r.ok, skipped: r.ok ? undefined : r.skipped }
}

export default { LINE_KEYWORDS, LINE_NAMES, classifyLine, ledgerFileFor, openLedger, appendLineFact, recallLines, lineStats, classifyAndStore }
