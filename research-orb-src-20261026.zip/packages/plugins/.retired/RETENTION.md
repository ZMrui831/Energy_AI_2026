# `.retired/` 保留策略（P-R4 收口确立）

本目录由 skill 安装器的「只移不删」机制产生：卸载/退休插件时整目录原样搬入此处，用户内容永不因卸载丢失。

## 保留（canonical 证据）
- `accept-b4-skill-*`：块 4 skill 安装器「prepare → confirm → retire」端到端验收证据，长期保留。

## 不保留（验收/调试残留，每次收口即清）
- `test-b4-flow-*`、`final-b4-*` 等临时调试流或验收自清理残留：不属于 canonical 证据，发现即删。

## 约束
- `scan()` 已按点目录过滤，`.retired` 下任何内容都不会被当作插件重新加载。
- 任何目录均不得手动改回 `packages/plugins/<id>/`（恢复需用户显式操作，非自动）。
- 清理动作本身需记入 `data/logs/STAGE-LOG.md`，不留无主垃圾。
