export async function activate(ctx) {
  ctx.ui.registerCard({ id: 'demo.b4', title: 'Demo B4', body: '演示 skill（块 4 验收安装）', actions: [] })
  ctx.ui.registerCommand({ name: 'demo.b4.ping', title: 'ping', description: '演示命令', run: async () => ({ text: 'pong', ok: true }) })
  return {}
}
export default { activate }
