// packages/plugins/elder-care/index.mjs
//
// 养老（eldercare）pack 的能力实现：
//   /elder say <文本>   大字显示 + 本地 TTS 占位（本机 SAPI / edge-tts 未接入，先回显大字）
//   /elder help         一键求助占位：**仅本地记录**，不外发、不联网、不呼叫任何外部服务
//
// 纪律：数据只落 data/packs/eldercare/；本阶段不接任何远程通知（避免误报警情）。

import { join } from 'node:path'
import { APP_VERSION } from '../../core/src/version.mjs'

export const ELDER_CARE_VERSION = APP_VERSION
const PACK_ROOT = 'eldercare'

function nowIso() { return new Date().toISOString() }

export async function activate(ctx) {
  const log = ctx.log
  const packs = ctx.fs.scope('packs')
  const helpPath = join(PACK_ROOT, 'help.jsonl')

  log.info(`elder-care 已激活（v${ELDER_CARE_VERSION}），数据根 data/packs/${PACK_ROOT}/`)

  ctx.ui.registerCard({
    id: 'elder.care',
    title: '长辈陪伴',
    body: '大字朗读 / 一键求助（仅本地记录）。数据目录 data/packs/eldercare/',
    actions: ['elder'],
  })

  ctx.ui.registerCommand({
    name: 'elder',
    title: '长辈陪伴',
    description: '大字朗读与一键求助（占位）。用法：/elder say <文本>｜/elder help｜/elder list',
    run: async (rest = '') => {
      const tokens = String(rest || '').trim().split(/\s+/).filter(Boolean)
      const sub = tokens[0]

      if (sub === 'list') {
        const rows = packs.exists(helpPath)
          ? packs.read(helpPath).split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l) } catch { return null } }).filter(Boolean)
          : []
        return {
          ok: true,
          text: rows.length
            ? `求助记录（最近 ${Math.min(rows.length, 50)} 条，仅本地）：\n` + rows.slice(-50).reverse().map((e) => `· [${String(e.at).slice(5, 19)}] ${e.text}`).join('\n')
            : '暂无求助记录。',
        }
      }

      if (sub === 'help') {
        const text = tokens.slice(1).join(' ').trim() || '需要帮助'
        packs.append(helpPath, `${JSON.stringify({ at: nowIso(), text, kind: 'help' })}\n`)
        log.info(`一键求助（仅本地记录）：${text}`)
        return {
          ok: true,
          text: [
            '已记录求助（仅本地，未通知任何外部服务）：',
            `· 时间：${nowIso()}`,
            `· 内容：${text}`,
            '· 落点：data/packs/eldercare/help.jsonl',
            '',
            '提示：本阶段一键求助为占位实现，不拨号、不外发。接入真实通知需另行显式开启。',
          ].join('\n'),
          ui: { kind: 'elder-help', at: nowIso(), text },
        }
      }

      if (sub === 'say') {
        const text = tokens.slice(1).join(' ').trim()
        if (!text) return { ok: false, code: 'E_BAD_ARGS', text: '用法：/elder say <文本>（例：/elder say 该吃药了）' }
        return {
          ok: true,
          text: `（大字朗读占位）${text}`,
          ui: { kind: 'elder-say', text, big: true },
        }
      }

      return {
        ok: true,
        text: [
          '长辈陪伴用法：',
          '  /elder say <文本>   大字显示 + 本地朗读（占位）',
          '  /elder help [文本]  一键求助占位（仅本地记录）',
          '  /elder list         查看本地求助记录',
        ].join('\n'),
      }
    },
  })

  return { deactivate() { log.info('elder-care 已停用') } }
}

export default { activate }
