// packages/plugins/pack-admin/index.mjs
//
// 底座级管理命令（P-R6）：/pack、/theme、/demo、/edition。
//
// 为什么是插件而不是写进 shell：这些命令本身也是"能力"，按插件契约走受控 ctx；
// 更重要的是 shell（apps/desktop）必须零学科词、零业务词 —— 连"切 pack"这种
// 形态管理也不该硬编码在球窗口里。
//
// 切 pack 会重启渲染层的领域 UI：本插件只改 data\config.json 并返回提示，
// 真正重建窗口由主进程监听 'pack:changed' 后 reload（见 apps/desktop/main.mjs）。

import { loadSettings, saveSettings, isEnterprise } from '../../core/src/settings.mjs'
import { APP_VERSION } from '../../core/src/version.mjs'
import { listPacks } from '../../core/src/packs.mjs'
import {
  listThemes, readTheme, importTheme, exportTheme, validateTheme, themeToCss, DEFAULT_THEME,
} from '../../core/src/themes.mjs'

export const PACK_ADMIN_VERSION = APP_VERSION

function parse(rest) {
  const tokens = String(rest || '').trim().split(/\s+/).filter(Boolean)
  return { tokens, sub: tokens[0] || '', rest: tokens.slice(1) }
}

export async function activate(ctx) {
  const log = ctx.log
  log.info(`pack-admin 已激活（v${PACK_ADMIN_VERSION}）`)

  ctx.ui.registerCard({
    id: 'pack.admin',
    title: '形态与外观',
    body: '当前形态 / 主题 / 版本开关。切 pack 只改配置，不改代码。',
    actions: ['pack', 'theme'],
  })

  // ---- /pack ----
  ctx.ui.registerCommand({
    name: 'pack',
    title: '形态管理',
    description: '查看/切换形态（pack）。用法：/pack list｜/pack use <id>｜/pack current',
    run: async (rest = '') => {
      const { sub, rest: args } = parse(rest)
      const packs = listPacks()
      const cur = loadSettings()

      if (sub === 'list' || sub === '') {
        return {
          ok: true,
          text: [
            `当前形态：${cur.activePack}`,
            ...packs.map((p) => `· ${p.id}${p.id === cur.activePack ? '（当前）' : ''} —— ${p.description || p.name}`),
            '',
            '切换：/pack use <id>（会重载面板；命令表/卡片/主题随之变化）',
          ].join('\n'),
        }
      }
      if (sub === 'current') return { ok: true, text: `当前形态：${cur.activePack}｜主题：${cur.theme}｜版本：${cur.edition}` }
      if (sub === 'use') {
        const id = args[0]
        if (!id) return { ok: false, code: 'E_BAD_ARGS', text: '用法：/pack use <pack-id>（先 /pack list 看可用形态）' }
        if (!packs.some((p) => p.id === id)) {
          return { ok: false, code: 'E_NO_PACK', text: `未知形态：${id}（可用：${packs.map((p) => p.id).join(', ')}）` }
        }
        // 主题跟随 pack 的默认主题（pack.json 的 theme 字段）
        const target = packs.find((p) => p.id === id)
        saveSettings({ activePack: id, enabledPacks: [id], ...(target.theme ? { theme: target.theme } : {}) })
        ctx.onEvent && ctx.onEvent({ type: 'pack:changed', pack: id })
        return {
          ok: true,
          text: `已切换形态 → ${id}（配置已写 data/config.json）。\n命令表/面板卡片/主题将在面板重载后生效；若未自动重载，请发送 /reload 或重启应用。`,
          reload: true,
        }
      }
      return { ok: false, code: 'E_BAD_ARGS', text: '用法：/pack list｜/pack use <id>｜/pack current' }
    },
  })

  // ---- /theme ----
  ctx.ui.registerCommand({
    name: 'theme',
    title: '主题',
    description: '列出/切换/导入/导出主题。用法：/theme list｜/theme use <name>｜/theme export <name>｜/theme import <文件>',
    run: async (rest = '') => {
      const { sub, rest: args } = parse(rest)
      const cur = loadSettings()
      const themes = listThemes()

      if (sub === 'list' || sub === '') {
        return {
          ok: true,
          text: [
            `当前主题：${cur.theme}`,
            ...themes.map((t) => `· ${t.name}${t.name === cur.theme ? '（当前）' : ''}${t.ok ? '' : ' ⚠未通过校验：' + t.errors.join('；')} —— ${t.description || ''}`),
            '',
            '切换：/theme use <name>',
          ].join('\n'),
        }
      }
      if (sub === 'use') {
        const name = args[0]
        if (!name) return { ok: false, code: 'E_BAD_ARGS', text: '用法：/theme use <name>（先 /theme list）' }
        try {
          readTheme(name) // 校验不过会抛
        } catch (err) {
          return { ok: false, code: err.code || 'E_THEME', text: `拒绝切换到 ${name}：${err.message}` }
        }
        saveSettings({ theme: name })
        ctx.onEvent && ctx.onEvent({ type: 'theme:changed', theme: name })
        return { ok: true, text: `已切换主题 → ${name}（几何契约不变：球 96×96 / 展开 420×620 / 右下锚点）`, reload: true }
      }
      if (sub === 'export') {
        const name = args[0] || cur.theme
        try {
          const json = exportTheme(name)
          return { ok: true, text: `主题 ${name} 的 JSON（可保存后 /theme import 导入）：\n${json}`, json }
        } catch (err) {
          return { ok: false, code: err.code || 'E_THEME', text: `导出失败：${err.message}` }
        }
      }
      if (sub === 'import') {
        // 安全约束：不接受文件路径参数（避免路径穿越与任意文件读取）。
        // 导入内容只能来自"本进程内显式提供的 JSON 字符串"——面板/测试走同一条路。
        return {
          ok: false,
          code: 'E_USE_IMPORT_JSON',
          text: '为避免路径穿越，导入不接受文件路径。请用 /theme.import <json>（内联 JSON 字符串，经 schema 校验后才写盘）。',
        }
      }
      return { ok: false, code: 'E_BAD_ARGS', text: '用法：/theme list｜/theme use <name>｜/theme export <name>' }
    },
  })

  // ---- /theme.import（内联 JSON，schema 校验通过才写盘）----
  ctx.ui.registerCommand({
    name: 'theme.import',
    title: '导入主题',
    description: '导入主题（内联 JSON）。缺字段/非法颜色/非法主题名一律拒绝且不写盘。',
    run: async (rest = '') => {
      const raw = String(rest || '').trim()
      if (!raw) return { ok: false, code: 'E_BAD_ARGS', text: '用法：/theme.import <json>（内联 JSON 字符串）' }
      let doc
      try {
        doc = JSON.parse(raw)
      } catch {
        return { ok: false, code: 'E_THEME_BAD_JSON', text: '拒绝：不是合法 JSON（未写盘）' }
      }
      const name = typeof doc.name === 'string' && doc.name.trim() ? doc.name.trim() : null
      if (!name) return { ok: false, code: 'E_THEME_BAD_NAME', text: '拒绝：JSON 必须含合法 name 字段（未写盘）' }
      try {
        const theme = importTheme(name, doc)
        ctx.onEvent && ctx.onEvent({ type: 'theme:changed', theme: name })
        return { ok: true, text: `已导入主题 ${name}（schema 校验通过）。/theme use ${name} 即可切换。`, reload: true }
      } catch (err) {
        return { ok: false, code: err.code || 'E_THEME_SCHEMA', text: `拒绝导入：${err.message}` }
      }
    },
  })

  // ---- /demo ----
  ctx.ui.registerCommand({
    name: 'demo',
    title: '演示模式',
    description: '演示模式开关。用法：/demo start｜/demo stop｜/demo reset',
    run: async (rest = '') => {
      const { sub } = parse(rest)
      const cur = loadSettings()
      if (sub === 'start') {
        saveSettings({ demo: true })
        return { ok: true, text: '演示模式已开启：数据隔离在 data/demo/，/demo reset 可清空重建。' }
      }
      if (sub === 'stop') {
        saveSettings({ demo: false })
        return { ok: true, text: '演示模式已关闭。' }
      }
      if (sub === 'reset') {
        return {
          ok: true,
          text: '演示数据重置：请在 shell 里执行 /demo reset（主进程负责清空并重建 data/demo/）。',
          demoReset: true,
        }
      }
      return { ok: true, text: `演示模式：${cur.demo ? '开启' : '关闭'}。用法：/demo start｜/demo stop｜/demo reset` }
    },
  })

  // ---- /edition ----
  ctx.ui.registerCommand({
    name: 'edition',
    title: '版本开关',
    description: '个人版 / 企业版开关。企业版强制禁用 L2/L3/L4 图形层与无头临时 profile。',
    run: async (rest = '') => {
      const { sub, rest: args } = parse(rest)
      const cur = loadSettings()
      if (sub === 'use') {
        const want = args[0]
        if (want !== 'personal' && want !== 'enterprise') {
          return { ok: false, code: 'E_BAD_ARGS', text: '用法：/edition use personal|enterprise' }
        }
        saveSettings({ edition: want })
        return {
          ok: true,
          text: want === 'enterprise'
            ? '已切到企业版：L2/L3/L4 图形层一律禁用、无头浏览器禁用临时 profile、审计只增不删、数据不外发。'
            : '已切到个人版。',
        }
      }
      if (sub === 'status' || sub === '') {
        return {
          ok: true,
          text: [
            `当前版本：${cur.edition}`,
            `· 企业版限制：${cur.edition === 'enterprise' ? '已生效' : '未生效'}`,
            '  - L2/L3/L4 图形层能力：禁用',
            '  - 无头浏览器临时 profile：禁用（只用持久 profile）',
            '  - 审计日志：只增不删',
            '  - 数据：本地化，不外发',
          ].join('\n'),
        }
      }
      return { ok: false, code: 'E_BAD_ARGS', text: '用法：/edition status｜/edition use personal|enterprise' }
    },
  })

  return {
    deactivate() { log.info('pack-admin 已停用') },
  }
}

export default { activate }
