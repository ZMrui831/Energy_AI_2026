// packages/plugins/index.mjs —— 插件宿主对外唯一入口。

export {
  createRegistry,
  PLUGINS_DIR,
  NOTES_DIR,
  PLUGIN_LOG,
  DATA_SCOPES,
  DATA_SCOPE_NAMES,
  PluginError,
  normalizeManifest,
  assertPluginId,
  pluginDataPath,
  scopeRoot,
  scopeDataPath,
} from './registry.mjs'

export { default } from './registry.mjs'
