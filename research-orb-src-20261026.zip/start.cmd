@echo off
rem ===========================================================================
rem  research-orb launcher (phase 0)
rem  ASCII only on purpose: cmd.exe mangles non-ASCII paths and filenames.
rem  Reuses the Electron runtime already present on this machine.
rem  Offline by design: no package manager, no fetch of new runtimes,
rem  no remote update path, nothing global.
rem ===========================================================================
setlocal

set "ELECTRON_EXE=D:\AI_Workspace\dsh-orb-electron\electron.exe"
set "APP_MAIN=D:\explorer!\research-orb\apps\desktop\main.mjs"

rem Clear the inherited ELECTRON_RUN_AS_NODE. If it is set, electron.exe runs as
rem a plain Node process and the floating ball never appears.
set "ELECTRON_RUN_AS_NODE="

if not exist "%ELECTRON_EXE%" (
  echo [research-orb] ERROR: electron.exe not found:
  echo   %ELECTRON_EXE%
  exit /b 1
)

if not exist "%APP_MAIN%" (
  echo [research-orb] ERROR: main entry not found:
  echo   %APP_MAIN%
  exit /b 1
)

echo [research-orb] starting floating ball...
"%ELECTRON_EXE%" "%APP_MAIN%" --remote-debugging-port=9336 %*
set "EXIT_CODE=%ERRORLEVEL%"
echo [research-orb] exited with code %EXIT_CODE%.

if not "%EXIT_CODE%"=="0" (
  echo [research-orb] see D:\explorer!\research-orb\data\logs\app.jsonl for details
)

endlocal & exit /b %EXIT_CODE%
