# 任务：给 research-orb 加「长期记忆适配层」（不改 DSH 插件本体）

**给谁**：负责 research-orb 的 AI（Qoder / WorkBuddy / 该项目自己的 agent）
**本文件自包含**：整段复制即可。
**目标**：让 research-orb 具备**跨会话长期记忆**（记住用户是谁、偏好什么、改过什么），
把记忆块注入它自己的 system prompt，并在回合结束时写回。
**工时**：4–6 小时 ｜ **不改 DSH 侧任何文件**，只动 research-orb 仓库。

---

## 0. 这是一次"移植"，不是"再写一个记忆系统"

记忆内核已经存在且经过验证（零第三方依赖、纯 Node ESM）：
- 内核目录（只读源）：`D:\AI_Workspace\记忆插件\packages\core\`（14 个 `.js`，含 `compile.js`/`markdown.js`/`index-fts.js`/`schema.js`/`tokens.js`）
- 它做三件事：**读 Markdown 记忆 → 按 query 检索 + 预算裁剪 → 输出一段可注入的文本块**；回合结束再**过滤后写回**。
- 已在 DSH 上真机验证：注入 300 token 级别、跨会话记忆、具名拒答、提问不入库。

**你的任务是把这套内核"嫁接"到 research-orb**，并且**不许修改内核逻辑**（发现必须改的，写报告，别就地改）。

---

## 1. 现状（已核实的 research-orb 事实，别重新猜）

| 事实 | 位置 |
|---|---|
| 宿主是 Electron + Node ESM（`type: module`，v0.7.0） | `package.json` |
| **已有一层"短期记忆"**：教练记忆（目标+近 3 轨迹+未完成计划，≤400 token） | `packages/plugins/coach/memory.mjs:111` `readMemorySystemContext({goal})` |
| 宿主拼 system 的地方（**唯一注入点**） | `apps/desktop/main.mjs:874-889`，`parts = [coach | profile] + [coach memory]` → `parts.join('\n')` |
| 另一个只读上下文注入器（可参考它的契约写法） | `packages/core/src/profile-context.mjs`（纯读、全程 try/catch、异常返回 `''`） |
| **唯一写文件出口**：断言路径必须在项目根内 + 审计到 `data/logs/writes.jsonl` | `packages/core/src/safefs.mjs` |
| 测试入口 | `npm test` → `node tools/run-tests.mjs`（`tests/*.test.mjs`） |
| **不要用** `npm run selftest` 做验收 | 它会真实写 `data/`（历史事故：曾写入 `data/logs/plugins.jsonl`、`data/notes/hello/hello.md`） |

**命名冲突警告**：`readMemorySystemContext` 这个名字**已被 coach 插件占用**。
你的新入口必须用**不冲突的名字**，建议 `readLongTermMemoryContext`。

---

## 2. 要做的事（五步）

### 2.1 把内核放进来（不改内核）
在 research-orb 内新建插件目录：
```
packages\plugins\longterm-memory\
  core\            ← 从 D:\AI_Workspace\记忆插件\packages\core\ 原样复制（14 个 .js，只读，不许改）
  context.mjs      ← 读侧：读记忆 → 编译出注入块
  write.mjs        ← 写侧：回合结束写回（带治理）
  config.mjs       ← 读 data/memory/config.json（缺省安全默认）
  index.mjs        ← 导出 { readLongTermMemoryContext, observeTurn }
```
- 复制后核对：**逐文件 sha256 与源一致**（报告里贴 14 行哈希）。
- 若 research-orb 有"插件契约/注册表"（`packages/plugins/registry.mjs`），按它的契约登记为
  `id: "memory.longterm"`、`capabilities: ["memory.recall", "memory.observe"]`、`permissions: ["fs:memory"]`；
  若注册需要改宿主，**只做最小登记**，并在报告里说明改了哪几行。

### 2.2 存储位置（必须在项目根内，且走 safefs）
```
data\memory\longterm.md        ← Markdown 真相源（格式与内核一致：`## [generated <ts>] <sessionId> 第 N 轮` + `- 事实`）
data\memory\config.json        ← { "enabled": true, "budgetTokens": 300, "writeGovernance": true }
data\memory\longterm.md.diag.log  ← 只记"注入/写回/跳过"计数，不记正文
```
- **所有写入必须走 `safefs`**（`safeWrite` / `appendJsonl`），禁止直接 `writeFileSync`。
- 首次使用：目录/文件不存在 → 视为"空记忆"，**不要**创建（等第一次真正有事实要写时再建）。

### 2.3 读侧：注入块（这是核心）
新建 `readLongTermMemoryContext({ query, root, budgetTokens })`：
1. 读 `data/memory/config.json`；`enabled !== true` → 返回 `''`；
2. 读 `data/memory/longterm.md`（内核的 `readMemoryFile`）；不存在/损坏 → 返回 `''`（**绝不抛错**）；
3. 调内核 `compileFromEntries(entries, { query, budgetTokens })` → `text`；
4. 返回 `text`（非空时，报告里给一段真实样例）。
**红线**：纯读、全程 try/catch、异常一律 `''`；不写文件；不做网络请求。

### 2.4 宿主接线（只改这一处，最小 diff）
在 `apps/desktop/main.mjs` 的拼装处（`874-889` 那段 `profileSys` 之后）追加**第三段**：
```js
const ltm = readLongTermMemoryContext({ query: <本轮用户输入> }).trim()
if (ltm) parts.push(ltm)
```
- **顺序固定**：`coach/profile` → `coach memory` → **`longterm` 最后**（最贴近本轮输入，服从性最好）；
- 若该作用域拿不到"本轮用户输入"，用 `goalText` 或 `''`（内核会退化为只出稳定段，**不能因此报错**）；
- **不许**改 `agent.mjs`、不许改 coach 的 `memory.mjs`；
- 总预算：新增段 **≤300 token**，且不得让三段的合计超过 1400 token（超出就砍 `budgetTokens`）。

### 2.5 写侧：回合结束写回（带治理）
在 `runTurn` 成功结束后，调 `observeTurn({ sessionId, userText, assistantText })`：
1. **只写"事实性"内容**（与内核同规则）：
   - **保留**：命中 `我叫|我是|我的X是|我喜欢|我不喜欢|我住|我在X工作|我养|记住|代号|版本|改成|改为`
   - **丢弃**：以 `？/?` 结尾；含 `吗|呢|什么|多少|哪|谁|怎么|为什么|如何` 且 ≤80 字；以 `请|帮我|给我|看看|执行|运行` 开头；纯寒暄
   - 都未命中 → **丢弃**（宁可漏记，不可污染）
2. 助手侧：**丢弃纯回执**（"好的/已记住/不客气"），保留含更新语义的（"已更新：X 现在是 Y"）；
3. 写回时带上 `sessionId` 与时间戳，格式与内核 `readMemoryFile` 期望的 Markdown 一致；
4. 单轮最多写 2 条、单条 ≤400 字（与内核默认一致）；
5. 任何异常 → 静默跳过，**不影响对话**。

---

## 3. 验收（必须给原始输出）

| # | 项 | 门槛 |
|---|---|---|
| 1 | 内核未被修改 | 14 个 `.js` 的 sha256 与源一致（贴 14 行） |
| 2 | 读侧 | 返回块非空且 **token ≤300**；`enabled:false` → `''`；文件损坏 → `''` 且不抛错 |
| 3 | 注入生效 | 跑一轮聊天后，system 里能看到我们的块（贴出真实片段，**打码私密内容**） |
| 4 | 跨会话 | 会话 A 说「我叫小X，喜欢Y」→ 会话 B 问「我叫什么」→ 模型答出（前提：接的是模型，不是 mock） |
| 5 | 提问不入库 | 问「我叫什么？」后，`data/memory/longterm.md` 里**没有**这一句；diag 里有 `skipped:{question:n}` |
| 6 | 只写根内 | `safefs` 审计：`data/logs/writes.jsonl` 中本轮新增行全部落在 `data/memory/` 下 |
| 7 | 回归 | `npm test` 全绿（**不要跑 `npm run selftest`**）；现有 coach/profile 注入未被破坏 |
| 8 | 开关 | 把 `config.json` 的 `enabled` 改 `false` → 再跑一轮：system 里**没有**我们的块，且现有功能正常 |

---

## 4. 安全与边界（逐条遵守）

1. **只在 research-orb 仓库内改动**；`packages/plugins/longterm-memory/` 是主要新增目录，
   宿主只许改 `apps/desktop/main.mjs` 的拼装处（最小 diff）。
2. **不许改**：`packages/core/src/agent.mjs`、`packages/plugins/coach/memory.mjs`、
   `packages/core/src/safefs.mjs`（写出口本身）、`vendor/`、`.snapshots/`、`tests/` 里既有用例。
3. **不许联网**（不许加 `net` 出口、不许下载依赖）；**不许**新增第三方依赖。
4. **不许**碰 `C:\Users\...\.dsh\`（那是另一个产品）与 `D:\AI_Workspace\记忆插件\`（只读源）。
5. **不许跑 `npm run selftest`**（它会真实写 `data/`）；验收只用 `npm test` + 你新增的离线测试。
6. 记忆是**明文**存在 `data/memory/`；不采集密钥、不记 API key、不记文件内容正文。
7. 任何异常必须降级（返回 `''` / 跳过写回），**绝不拖停主进程**。
8. 报告里不许把"离线测试通过"写成"真机可用"；模型相关结论要写清用的哪个模型。

---

## 5. 交付物

1. 新增目录 `packages/plugins/longterm-memory/`（含 `core/` 原样内核 + 四个 `.mjs`）
2. `apps/desktop/main.mjs` 的最小 diff（贴 diff，不要只贴结论）
3. 新增离线测试 `tests/longterm-memory.test.mjs`（≥8 条，覆盖验收 2/5/6/8）
4. 一份 `docs/LONGTERM-MEMORY.md`：数据格式、开关、注入顺序、预算、隐私说明、排障
5. 回报：上面 8 条验收的原始输出 + 遗留问题

---

## 6. 这套适配模式要能复制（写给下一个宿主）

把上面五步抽象成**通用契约**，以后接萌源 / dsh-orb / 任何 agent 都照做：

```
① 内核随包（只读、零依赖）        → 不改内核
② 记忆文件放宿主自己的数据目录    → 不与别的宿主共享
③ 读侧：readXxxMemoryContext({query}) → 返回 '' 或 ≤预算的块，异常一律 ''
④ 注入：拼到宿主自己的 system 末尾 → 顺序 = 宿主原有段 → 记忆段（最后）
⑤ 写侧：回合结束过滤后写回        → 提问/请求/寒暄/回执一律不写
⑥ 开关 + 明文声明 + 全程降级
```

**一条硬规矩**：每个宿主一套 `data/memory/`，**绝不共享**——共享会让"这条记忆是谁写的"永远说不清。

---

## 7. 回报格式

1. **新增文件清单**（绝对路径）+ 内核 14 文件哈希
2. **宿主 diff**（`main.mjs` 那几行）
3. **8 条验收**逐条原始输出
4. **未做与未确认**（例如：模型服从性、是否需要 UI 入口、是否要接 daemon）
