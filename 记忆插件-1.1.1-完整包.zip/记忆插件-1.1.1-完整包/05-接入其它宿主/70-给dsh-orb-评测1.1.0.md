# 给 dsh-orb 的评测任务 v2：1.1.0 GA（只看「重启后窗口」，已吸收你们 6 条意见）

**给谁**：dsh-orb 维护 AI / 主管
**版本**：v2（2026-10-23，吸收 dsh-orb 6 条评审意见）
**前提**：**你们已安装 1.1.0 GA → 本文档不再要求重装**，只做「重启 + 基线取证」。
**目标**：补上 `memory written` 的「重启后新增」证据，并确认 namespace 刷新。

---

## 0. 你们 6 条意见的处置

| # | 你们的意见 | 处置 |
|---|---|---|
| 1 | `Remove-Item -Recurse -Force` 删插件目录太危险，应「临时目录 → 校验 14 哈希 → 原子替换」 | ✅ **采纳**：§5 给出安全升级法（本轮不要求你们执行，已装即跳过） |
| 2 | "重启 dsh-orb" 表述含糊，应是「**重启 DSH 客户端**」（配置只在 DSH 启动时读，helper 重启无效） | ✅ **采纳**：全文改为「重启 DSH 客户端」，并给「真的重启了」的判据 |
| 3 | diag 是**累积**文件（现 2043 行，历史 `inject enter=438`、`preset mismatch=430`、`ollama unreachable=9`），直接数总数会全部误判 | ✅ **采纳（我的硬错误）**：全部断言改为**窗口法**，并给现成工具 `tools/diag-window.mjs` |
| 4 | V5 `memory written` 说"待补"，其实历史已有 2 条，需要的是「重启后新增」 | ✅ **采纳**：V5 改为「**窗口内** `memory written ≥ 1`」 |
| 5 | `.lock/.tmp` 扫描时机：写入瞬间必有 `.tmp` | ✅ **采纳**：改为「**静默 5 秒后**再扫」 |
| 6 | 缺回滚后验证：回滚到旧版后 `memoryFile` 仍可被读取 | ✅ **采纳**：新增 **V7 回滚可读性** |

> 第 3 条我认领：我写「0 行 inject enter / 0 行 preset mismatch」时忘了 diag 会累积——**这条会被历史数据直接判错**，是任务书的硬缺陷。

---

## 1. 先取「窗口基线」（**所有断言只看窗口**）

`.diag.log` 是追加写的累积文件。插件每次启动都会打一行 `apply begin`，**以最后一行为窗口起点**。

**用我们提供的工具（推荐）**：
```powershell
# ⚠️ 该工具不在 1.1.0 评测包里（只随源码仓库），请用绝对路径：
node "D:\AI_Workspace\记忆插件\tools\diag-window.mjs"
# 机器可读
node "D:\AI_Workspace\记忆插件\tools\diag-window.mjs" --json
# diag 不在默认位置时
node "D:\AI_Workspace\记忆插件\tools\diag-window.mjs" --file "C:\Users\54958\.dsh\local-ai-memory.md.diag.log"
```
> **多进程注意**：宿主可能同时加载主进程 + helper，会各自打一行 `apply begin`；
> 窗口起点**必须取最后一条**（工具默认如此；手算时别取第一条）。
输出形如：
```
total     : 2048 行（含全部历史）
window    : 第 1944 行起 → 104 行（本次启动）
---- 窗口内计数（断言只看这里）----
     1  apply begin
     0  apply failed
     2  inject skip: injectMode=off
     0  memory written
```

**或者手动取基线**（不依赖工具）：
```powershell
$diag = "$env:USERPROFILE\.dsh\local-ai-memory.md.diag.log"
$base = (Get-Content $diag | Measure-Object).Count      # 重启前先记下
# 重启 DSH 客户端、并完成一次会话后：
$win = Get-Content $diag | Select-Object -Skip $base     # 只看重启后新增
$win | Select-String "apply begin|injectMode=off|memory written|apply failed|namespace mismatch"
```

---

## 2. 重启（**是 DSH 客户端，不是 helper**）

1. 完全退出 **DSH 客户端**（托盘退出 / 确认进程列表里没有主进程）；
2. 重新启动；
3. **确认真的重启了**（判据）：`diag-window.mjs` 的窗口里出现**新的** `apply begin` 行（`first` 行时间戳晚于你退出前的时间）。

> helper 进程重启**不会**重读 `cordis.patch.yml`，这条你们踩过，我们写进任务书。

---

## 3. 验收（V1–V7，**全部只看窗口**）

| # | 检查 | 期望 |
|---|---|---|
| **V1** | `apply begin`（窗口内） | ≥1 行，且含 `presets:["computer-use"]`、`injectMode:"off"`、`resolvedBy:"presets"`、`namespace:"dsh-orb"` |
| **V2** | 启动两行（窗口内） | `[memory] file=… schema=1 namespace=dsh-orb` 与 `[memory] config loaded \| presets=[computer-use] injectMode=off namespace=dsh-orb … \| patchPath=<unknown>` 各 ≥1 行 |
| **V3** | off 契约（窗口内） | `inject skip: injectMode=off` **≥1 行**（每个加载进程一行，进程数不限——实测见过 2 行）；`inject enter` / `inject compiled` / `inject applied` = **0**；`preset mismatch` = **0**；`provider not local` = **0** |
| **V4** | 无 ollama 噪音（窗口内） | `warn: ollama unreachable` = **0**（1.1.0 相对 rc7 的可见变化） |
| **V5** | **`memory written`（窗口内，上轮缺的）** | 在 orb 里发一句话（如「记住：我叫阿衡，喜欢冰美式」）后，窗口内出现 `memory written {"turn":…,"facts":…,"skipped":{…}}` **≥1 行** |
| **V6** | 文件头 + 告警 | 首次写入后首行 `namespace:` 变 **`dsh-orb`**；窗口内 `warn: namespace mismatch` 在**那次写入之后**不再出现；事实数 = 写入前 +1（不丢不重） |
| **V7** | **停用后可读**（降级版，只需重启 1 次） | 把 `local-memory` 段**注释掉**（不是回滚旧版）→ 重启 DSH 客户端一次 → 用你们的解析器读 `memoryFile`：首行头 + `## [generated …]` 块 + `- ` 事实行都在，条目数与注释前一致。**做完把配置恢复** |

**V7 具体做法**（5 分钟，只重启 1 次；不想做就写 N-A）：
```powershell
# 1) 记录当前可解析条目数
$before = (Get-Content "$env:USERPROFILE\.dsh\local-ai-memory.md" | Select-String '^- ').Count
# 2) 把 cordis.patch.yml 里 local-memory 整段改成注释（行首加 #），重启 DSH 客户端一次
#    —— 插件不再加载，但 memoryFile 仍在盘上，验证"我们只读，格式不依赖插件是否运行"
# 3) 用你们的解析器读一遍
$after = (Get-Content "$env:USERPROFILE\.dsh\local-ai-memory.md" | Select-String '^- ').Count
# 断言：$after -eq $before；首行仍是 <!-- dsh-local-memory | schema: 1 | …
# 4) 恢复配置（去掉注释），再重启一次——或者干脆留着，等下次需要时再开
```

**`.lock` / `.tmp` 残留检查（静默 5 秒后）**：
```powershell
Start-Sleep -Seconds 5
Get-ChildItem "$env:USERPROFILE\.dsh" -Filter "*.lock" -Recurse -ErrorAction SilentlyContinue
Get-ChildItem "$env:USERPROFILE\.dsh" -Filter "*.tmp"  -Recurse -ErrorAction SilentlyContinue
# 期望：都为空（写入瞬间存在 .tmp 是正常的，所以必须静默 5s 后再扫）
```

---

## 4. 反馈模板（照这个贴回来）

```markdown
## 环境
- 已装版本：1.1.0（贴 bundle-files.json 的 version 原文）
- 重启方式：<完全退出 DSH 客户端后重开 / 其它>
- 窗口基线：total=<n> 行，window 起于第 <n> 行、共 <n> 行

## V1 apply begin（窗口内原文一行）
<贴>

## V2 启动两行（窗口内原文）
<贴>

## V3 off 契约（窗口内计数）
- injectMode=off：<n，期望 ≥1>
- inject enter / compiled / applied：<0/0/0>
- preset mismatch：<0>
- provider not local：<0>

## V4 ollama 噪音
- warn: ollama unreachable：<0>

## V5 memory written（窗口内原文一行）
<贴>

## V6 文件头 + 告警
- 首行：<贴>
- namespace mismatch 出现在写入之前还是之后：<>
- 事实数：写入前 <n> → 写入后 <n>

## V7 回滚可读
- 回滚后条目数 <n> == 回滚前 <n>：<是/否>
- 首行头是否完整：<是/否>

## 问题
- <现象> → <试过什么> → <影响面>
```

---

## 5. 以后升级请用「安全升级法」（本轮不用执行）

```powershell
$PROFILE="C:\Users\54958\.dsh\profiles\desktop"
$PLUG=Join-Path $PROFILE "node_modules\dsh-local-memory"
$STAGE="$PLUG.new-$(Get-Date -Format yyyyMMdd-HHmmss)"
$PKG="D:\Desktop\记忆插件评测包-1.1.0"

# ① 拷到临时目录（不碰现有目录）
New-Item -ItemType Directory -Force $STAGE | Out-Null
Copy-Item "$PKG\02-插件文件\*" $STAGE -Recurse -Force

# ② 在临时目录上先做 14 哈希校验（失败就删临时目录、原目录不受影响）
powershell -NoProfile -ExecutionPolicy Bypass -File "$PKG\05-自检\verify-files.ps1"
# ⚠ 若自检脚本只认固定路径，就手工核：bundle-files.json 的 14 个 sha256 与 $STAGE 下文件逐一比对

# ③ 校验通过后再原子替换
Rename-Item $PLUG "$PLUG.old-$(Get-Date -Format yyyyMMdd-HHmmss)"
Rename-Item $STAGE $PLUG
# ④ 重启 DSH 客户端；确认 diag 窗口出现新 apply begin；一切正常后再删 .old-*
```
要点：**先校验、后替换、留旧目录可回滚**。任何一步失败都不改变正在使用的目录。

---

## 6. 边界（不变）

1. 只改 `cordis.patch.yml` 的 `local-memory` 段；不改我们源码、不改 `@deepseek-ai/*`。
2. 你们只读 `~/.dsh/local-ai-memory.md`；我们只写它 + sidecar（`.diag.log`/`.1~.3`/`.lock`/`.tmp`/`.mount-ok`）；**我们不写** `~\.dsh\dsh-orb\`。
3. 共用同一 `memoryFile` 时 namespace 必须不同（只告警、不改行为）。
4. 不放宽 provider 云端否决；不需要 `injectMode:'all'`。
5. 发现 `apply failed` 就贴整行 + 首个栈帧。
