# 任务：把记忆插件装进 dsh-orb（悬浮球 / Cordis 系），并做必要适配

**给谁**：负责 dsh-orb 的 AI（Qoder / WorkBuddy / 该项目自己的 agent）
**本文件自包含**：整段复制即可。
**工时**：3–5 小时 ｜ **主要改 dsh-orb 的配置**；记忆插件本体若有缺口，另按 §4 提需求，**不许就地改内核**。

---

## 0. 先认清：dsh-orb 不是"独立 agent"，它和 DSH 同族

已核实的架构事实（别重新猜）：

| 事实 | 证据 |
|---|---|
| dsh-orb 源码在 `D:\AI_Workspace\dsh-orb-cordis`（v0.4.13，ESM） | `package.json` |
| `D:\AI_Workspace\dsh-orb-electron` 只是**打包后的 Electron 运行时**（electron.exe + dll），不是源码 | 目录内容 |
| 它是 **Cordis + `@deepseek-ai/dsh-*`** 宿主 | `packages/bundle/node_modules/@deepseek-ai/` 下有 `dsh-system-prompt` / `dsh-agent` / `dsh-api-session-controller` |
| 内置 DSH 包版本统一为 **`0.1.7-rc.2`** | 上述包 `package.json` |
| 预设是**内联在 bundle patch 里**的 `preset-computer-use`（id `computer-use`），插件列表就在里面 | `packages/bundle/cordis.patch.yml` 第 1–30 行 |

**结论**：走「**preset 挂载**」这条路（与我们自己机器上 `preset-local-lean` 挂法一致），**不需要写适配层**。

---

## 1. 安装（三步）

### 1.1 先把运行时位置搞清楚（**不许猜**）
运行 `dsh-orb` 时到底加载哪一份，需要先确认（报告里写明结论）：
```powershell
# 可能在的位置（逐个确认哪个是运行时实际使用的）
Test-Path "D:\AI_Workspace\dsh-orb-cordis\packages\bundle\node_modules\@deepseek-ai\dsh-agent"
Get-ChildItem "D:\AI_Workspace\dsh-orb-cordis\node_modules\.pnpm" -Directory -Filter "*dsh-orb*" -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName }
# 启动脚本/入口指向哪里
Get-Content "D:\AI_Workspace\dsh-orb-cordis\package.json" -Raw -Encoding UTF8
```
判据：**哪一份 `node_modules` 里有 `@deepseek-ai/dsh-agent` 且被启动入口使用，插件就装进那一份的同级**。

### 1.2 复制 17 个文件（先备份同名目录）
从发布包 `D:\Desktop\记忆插件评测包-1.0.0\02-插件文件\`（或 `dist\dsh-local-memory-1.0.0.zip`）复制到：
```
<运行时 node_modules>\dsh-local-memory\
```
**复制后必须核对 sha256**：14 个 `.js` 与包内 `bundle-files.json` 一致（用包里自带的
`05-自检\verify-files.ps1`，把 `-root` 指向新位置；若脚本不支持参数，复制一份脚本改路径亦可）。

### 1.3 在 preset 里挂上（唯一需要改的配置）
编辑 `packages/bundle/cordis.patch.yml`，在 `preset-computer-use` 的 `plugins:` 列表**末尾**追加：

```yaml
            - id: local-memory
              name: 'dsh-local-memory'
              config:
                # 关键：必须等于这个 preset 的 id（dsh-orb 是 computer-use，不是 local-lean）
                onlyPreset: 'computer-use'
                # 记忆文件必须落在 dsh-orb 自己的目录，绝不与 DSH 共用
                memoryFile: 'D:\AI_Workspace\dsh-orb-cordis\data\memory\local-ai-memory.md'
                injectScope: 'all'
                writeGovernance: true
                sessionCompaction: true
                sessionThresholdPercent: 60
                keepRecentPercent: 20
                memoryLimitPercent: 6
                maxFactsPerTurn: 2
                maxFactChars: 400
```
> 改前把该文件备份成 `cordis.patch.yml.bak-<时间戳>`；改后 `git diff` 或文本 diff 贴进报告（**只应有这一段新增**）。

---

## 2. ⚠️ 必须先解决的前提：dsh-orb 用**云端模型**

我们插件的设计是「**只给本地模型注入**」（云端一律 `decided:"cloud"` 不注入）。
但 dsh-orb 是桌面 GUI agent，**大概率跑云端模型**（deepseek 等）。
**照现在的开关，你会看到 `inject skip: provider not local`，一条记忆都进不去。**

**所以按以下顺序做**：
1. 先确认 dsh-orb 实际用哪个 provider（看 `packages/bundle/cordis.patch.yml` 的 model 配置或 `packages/client-settings`）；
2. **若用云端** → 需要记忆插件侧新增一个开关（这是插件仓库的改动，**不在 dsh-orb 里改**）：
   - 建议名：`injectAllProviders: false`（默认 false → 维持现有语义）
   - 语义：`true` 时**跳过 provider 云端否决**，仍受 preset 过滤与预算约束
   - 申请方式：把需求写成一个 issue 式小节（`## 插件侧需求`）交回记忆插件仓库，由那边发 `1.0.1`
3. **在插件侧开关落地之前**，dsh-orb 上只能验到"插件被加载 + 能力探测通过 + 写入正常"，**不能验注入**——报告要如实这样写。

> 不许为了让注入生效去改插件的云端否决逻辑（那是 DSH 本地的安全默认）。

---

## 3. 版本兼容核对（dsh-orb 的 DSH 包是 0.1.7-rc.2，比我们验过的 0.2.1-rc.2 更老）

启动后**第一件事**看 diag 的 `capabilities` 行（插件会在 `apply()` 里探测四能力）：
```
capabilities {systemPrompt:true, assembleHook:true|false, projections:true|false, presetEvent:true|false}
```
判读：
| 现象 | 含义 | 处理 |
|---|---|---|
| `apply begin` 出现 + `capabilities` 四项在 | 老包也兼容 | 继续 |
| `assembleHook:false` | 0.1.7-rc.2 没有 `system-prompt/assemble` 瀑布 | **注入不会发生**（插件会自动降级不注入）；写入仍可用。需回报，由插件侧评估是否支持 windowed 注入 |
| `apply failed:` 出现 | 激活失败 | 把整行 + 首个栈帧贴回（rc3 之后一定有这行） |
| 完全没有 diag | 插件没被加载 | 检查 1.1 的运行时位置与 preset 挂载 |

**不许**改 `@deepseek-ai/*` 包（那是宿主依赖）。

---

## 4. 验收（按能否注入分两种口径，别混）

| # | 项 | 门槛 |
|---|---|---|
| 1 | 文件与哈希 | 17 文件就位；14 个 `.js` sha256 与 `bundle-files.json` 一致 |
| 2 | 配置 diff | `cordis.patch.yml` 只新增 local-memory 一段（贴 diff） |
| 3 | 加载成功 | `apply begin` 出现、**无** `apply failed`；`capabilities` 四个值贴出 |
| 4 | 写入可用 | 一轮对话后 `data\memory\local-ai-memory.md` 出现事实；**提问/请求不入库**（`skipped:{question:n}`） |
| 5 | **注入**（仅当 provider 为本地，或插件侧 `injectAllProviders` 已落地） | system 里出现 `## 长期记忆` 段；`inject applied` 有记录 |
| 6 | 隔离 | 不写 `C:\Users\...\.dsh\`；不与其他宿主共用记忆文件 |
| 7 | 回归 | dsh-orb 自己的 `npm run build` / `typecheck` / `test` 全绿 |
| 8 | 关闭可控 | 把 `sessionCompaction: false` 再跑一轮 → 不再注入（写入仍可保留） |

---

## 5. 安全边界（逐条遵守）

1. **只改 dsh-orb 仓库**（`D:\AI_Workspace\dsh-orb-cordis`）；改配置前必须备份。
2. **不许改** `vendor/`、`blocks.backup-*`、`.venv*`、`models/`、`node_modules/@deepseek-ai/**`。
3. **不许改记忆插件内核**（`dsh-local-memory/packages/core/*` 只读）；需要改 → 按 §2 提需求。
4. **不许碰** `C:\Users\...\.dsh\`（DSH 的地盘）与 `D:\explorer!\research-orb`。
5. 不联网、不 `pnpm/npm install`、不 `ollama pull`。
6. 不许 kill 用户进程、不许重启 dsh-orb（由用户操作）。
7. 遇到异常：插件必须**静默降级**（不注入），**绝不许拖垮 dsh-orb 启动**；若拖垮了，先回滚配置再报告。
8. 报告里分清「已验证」与「待插件侧支持」。

---

## 6. 要交的东西

1. **运行时位置结论**（哪个 node_modules 是真正被加载的，凭据是什么）
2. **`cordis.patch.yml` 的 diff**（只新增那一段）
3. **`capabilities` 实测行** + 是否出现 `apply failed`
4. **验收 8 条**逐条原始输出
5. **插件侧需求小节**（若 dsh-orb 用云端模型）：`injectAllProviders` 的语义与影响面
6. **未做与未确认**

---

## 7. 这套"DSH 系宿主"接法的通用步骤（给下一个同族项目）

```
① 确认它是 Cordis + @deepseek-ai/dsh-*（有 packages/bundle + cordis.patch.yml）
② 找到运行时真正加载的 node_modules 与 cordis.patch.yml
③ 17 文件放进该 node_modules 的 dsh-local-memory\
④ 在目标 preset 的 plugins 列表追加 local-memory，onlyPreset 填该 preset 的 id
⑤ memoryFile 指向宿主自己的 data 目录（绝不共用）
⑥ 启动看 capabilities；若 provider 是云端 → 要插件侧 injectAllProviders 才谈得上注入
```
