﻿# 05-保护源文件.ps1
#
# 作用：把 01-插件文件 下的全部文件设为「只读」，防止被误改。
# 用法：
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\05-保护源文件.ps1
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\05-保护源文件.ps1 -Unlock   # 解除（维护用）
#
# 设计说明：
#   * 本包的 01-插件文件 是「参考实现」，只允许复制，不允许修改。
#   * 只读属性不是安全边界（管理员可以改），但足以阻止"顺手改一行"这类事故，
#     也会让 copy/编辑工具在写入时报错，从而提醒改的人先复制。
#   * 解除只读后，改完请务必再跑一次本脚本恢复。

param([switch]$Unlock)

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$target = Join-Path $root "01-插件文件"

if (-not (Test-Path $target)) {
  Write-Host "未找到 01-插件文件，跳过" -ForegroundColor Yellow
  exit 1
}

$files = Get-ChildItem $target -Recurse -File
$n = 0
foreach ($f in $files) {
  $f.IsReadOnly = (-not $Unlock)
  $n++
}

if ($Unlock) {
  Write-Host ("已解除只读：" + $n + " 个文件") -ForegroundColor Yellow
  Write-Host "改完请重新运行本脚本（不带 -Unlock）恢复保护。" -ForegroundColor Yellow
} else {
  Write-Host ("已设为只读：" + $n + " 个文件") -ForegroundColor Green
  Write-Host "源文件只允许复制，不允许修改（详见 00-先读我（总说明）.md 第 9 节）。" -ForegroundColor Green
}

# 顺带做一次哈希自检（14 个运行时文件）
$selfcheck = Join-Path $root "04-自检\verify-files.ps1"
if ((Test-Path $selfcheck) -and (-not $Unlock)) {
  Write-Host ""
  Write-Host "---- 自检 ----"
  & powershell -NoProfile -ExecutionPolicy Bypass -File $selfcheck
}
