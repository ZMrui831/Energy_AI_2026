// compile.js — 预算编译（I1）+ 缓存友好稳定布局（I2）。
//
// I1 预算驱动编译：把「选哪些记忆进 prompt」当 0/1 背包 —— 价值 = score（相关×重要×新鲜，
//    由 recall 侧算好传入），成本 = token。M0 用贪心（按 score 降序）+ 稳定排序，
//    逐条累加，任何一步都保证「已选文本的 estimateTokens ≤ budgetTokens」这条硬上限。
//
// I2 缓存友好：输出**不含任何 per-call 时间戳 / 随机量**（这正是本项目实测过的真 bug：
//    注入块里带 new Date() 会毁掉整段 prompt 前缀缓存）。布局固定：稳定内容在前、
//    每行 `- <text>`，同输入 → 字节相同输出。
//
// 只依赖 node: 无；纯函数，绝不抛。
//
// token 口径说明（整改3）：estimateTokens 是**近似值**（CJK 每字≈1，其余每 4 字符≈1）。
// M2 会用真实 tokenizer 标定 —— 具体是 ollama 返回的 prompt_eval_count（见总纲 §6 指标），
// 届时把 calibrate() 的比例因子接进来；现在 messageOverhead 留出「每条消息固定开销」的钩子，
// 默认 0 保持与调用点一致（DSH 注入 blob 的每条记忆是一行，不计额外开销）。

const CJK = /[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\u3040-\u30ff\uac00-\ud7af]/g;

// v4 生产注入（compileFromEntries）：复用 core 已有的 BM25（中文 bigram）。
//   createIndex 提供 raw:true 的原始分数；hasClue 复用内核的「画像类事实」线索词定义。
import { createIndex, tokenize } from "./index-fts.js";
import { hasClue } from "./lifecycle.js";
// 阶段2 读侧：asOf 时间旅行 + 真冲突检测（仅当 opts.asOf 为合法 ISO 日期时才生效；
// 缺省时不调用，保证与阶段1逐字节相同 —— golden 比对验证）。
import { applyAsOf } from "./temporal.js";
// 阶段3：增量索引缓存（与 entries 解耦；命中/追加/重建/降级，静默降级绝不抛）。
import { getIndex } from "./index-cache.js";

// 重复折叠：先按 (sessionId, turn, 去掉角色前缀后的正文) 精确折叠，再用 Jaccard 兜底。
// 0.15 的依据：v4/真实库里「助手回执 vs 用户长句」同一事实的 Jaccard 约 0.19；0.3 会漏掉。
const DEFAULT_DUP_JACCARD = 0.15;

/**
 * 轻量 token 估算（近似，M2 用真实 tokenizer 标定）：
 *   CJK 每字 ≈ 1 token；其余连续非空白每 4 字符 ≈ 1 token；可选每条消息固定开销 messageOverhead。
 * @param {string} text
 * @param {{messageOverhead?: number}} [opts] messageOverhead 默认 0
 * @returns {number} 非负整数
 */
export function estimateTokens(text, opts = {}) {
  if (typeof text !== "string" || !text) return 0;
  const cjk = (text.match(CJK) || []).length;
  const nonCjk = text.replace(CJK, "").replace(/\s+/g, " ").trim();
  let n = cjk + Math.ceil(nonCjk.length / 4);
  const overhead = Number.isFinite(opts && opts.messageOverhead) ? opts.messageOverhead : 0;
  if (overhead) n += overhead;
  return n;
}

/**
 * 长期记忆应限制的 token 上限（从旧 lib/tokens.js 行为等价搬入 core，供注入侧使用）。
 * memoryLimitPercent 是千分比（如 6 = 0.6%）。无 context（注入路径恒如此）时收紧到
 * min(memorySoftLimit, memoryHardCap)。
 * @param {{context?: {contextWindow?: number, allocatedTokens?: number}}|null} context
 * @param {{memoryLimitPercent?: number, memoryHardCap?: number, memorySoftLimit?: number}} config
 * @returns {number}
 */
export function memoryTargetTokens(context, config) {
  const { memoryLimitPercent = 6, memoryHardCap = 500, memorySoftLimit = 2000 } = config || {};
  if (context) {
    const { contextWindow = 0, allocatedTokens = 0 } = context.context || {};
    if (contextWindow > 0) {
      const pctTokens = Math.floor((contextWindow * memoryLimitPercent) / 1000);
      return Math.min(pctTokens, memoryHardCap || pctTokens);
    }
    if (allocatedTokens > 0) return Math.min(allocatedTokens, memorySoftLimit);
  }
  return Math.min(memorySoftLimit, memoryHardCap || memorySoftLimit);
}

/** 兼容旧命名的别名（旧 lib/tokens.js 导出名，默认每条消息 4 token 开销）。 */
export function estimateTextTokens(text, { messageOverhead = 4 } = {}) {
  if (!text) return 0;
  const cjk = (text.match(CJK) || []).length;
  const nonCjk = text.replace(CJK, "").replace(/\s+/g, " ").trim();
  let n = cjk + Math.ceil(nonCjk.length / 4);
  if (messageOverhead) n += messageOverhead;
  return n;
}

/**
 * 渲染单条记忆为一行。稳定、无时间戳、确定序（同输入字节相同）。
 * M2.1：保留「说话人」结构——文本若以 `用户:`/`助手:`（半/全角冒号）开头，渲染成
 *   `- [用户] …` / `- [助手] …`，把角色从正文里提出来打标签；否则回退 `- <text>`。
 *   （v2 拍平成裸 `- 用户: xxx` 让 distractor 场景里模型更易把无关条目当答案照抄；标签化 +
 *    run-bench 侧的边界声明配合，明确「这些是检索到的历史条目」而非「这就是答案」。）
 * P0.2 治理：maxChars>0 时对「正文（去角色前缀后）」做干净硬截断（不带「已截断」后缀，
 *   避免半截话伤可读性）；maxChars=0（缺省/旧调用）→ 与改动前逐字节相同。
 * @param {{text?: string, s?: string, p?: string, o?: string}} item
 * @param {number} [maxChars] 正文硬截断上限（字符），0/缺省=不截断
 * @returns {string}
 */
const ROLE_PREFIX = /^(用户|助手)[：:]\s*/;
export function renderLine(item, maxChars = 0) {
  const raw = typeof item.text === "string" && item.text.trim()
    ? item.text.trim()
    : [item.s, item.p, item.o].filter((x) => typeof x === "string" && x).join(" ");
  const m = ROLE_PREFIX.exec(raw);
  let body = m ? raw.slice(m[0].length) : raw;
  if (maxChars > 0 && body.length > maxChars) body = body.slice(0, maxChars);
  if (m) return `- [${m[1]}] ${body}`;
  return `- ${body}`;
}

// ── P0.2 记忆治理：噪声事实识别（写入侧/注入侧共用）──────────────────────────
// 写入侧默认开；注入侧仅在 opts.dropNoise===true 时生效（缺省关 → 字节回归一致）。
//
// 噪声三类：
//   1) 助手回执：以 `助手:`/`助手：` 打头，且不含「信息更新」模式（已更新/现在是/改成/改为/
//      更新为/更新成/变更为/变成/变为 等）→ 纯「好的记住了」类回执不是用户画像，剔除；
//      含更新模式的助手事实（如「已更新：X 现在是 Y」）保留，因其携带真实变更。
//   2) 寒暄/致谢/情绪词：去除角色前缀后整串仅由礼貌短词 + 标点/emoji 构成（谢谢/不客气/你好/
//      嗯/嘻嘻/好的…），且长度 ≤ 12 字（无实体）→ 剔除。
//   3) 垃圾/指令噪声：空、例句占位、web_search 占位、你的答案不对、请只做一件事不要闲聊 等
//      明确无记忆价值的短噪声 → 剔除。
// 判定全部走「归一化正文」，不依赖 emoji（emoji 不计入实体，但也不影响前缀/长度判定）。

/** 助手回执里「携带来自用户的事实更新」的模式（命中则保留）。仅取真正改写/更新事实的句式，
 *  不含「此前就已写入…」这类元闲聊（避免误保留）。 */
const UPDATE_PATTERN = /(已更新[:：]|现在是|改成|改为|更新为|更新成|变更为|变成|变为|更新了)/;

/** 寒暄/致谢/情绪短词表（用于「整串仅由这些词 + 标点/emoji 构成」判定）。 */
const GREET_WORDS = [
  "谢谢", "多谢", "不客气", "不用谢", "你好", "您好", "您们好", "嗯", "嗯嗯", "嘻嘻",
  "好的", "好滴", "好呀", "好哒", "嘿", "嗨", "哈喽", "拜拜", "晚安", "早安", "午安",
  "辛苦了", "没关系", "没事", "没问题", "收到", "哈哈", "嘿嘿", "在吗", "在的", "呀", "啊", "哦", "嘛",
];

/** 去除标点/空白/emoji 后，整串是否仅由寒暄短词拼接而成。 */
function isPureGreeting(stripped) {
  let rest = stripped;
  while (rest.length > 0) {
    let matched = false;
    for (const w of GREET_WORDS) {
      if (rest.startsWith(w)) { rest = rest.slice(w.length); matched = true; break; }
    }
    if (!matched) return false;
  }
  return true;
}

/** 明确的垃圾/指令噪声（去角色前缀后整串匹配）。 */
const GARBAGE_NOISE = /^(例句[:：]?|web_search|web search|你的答案不对|请只做一件事.*|.*不要闲聊.*|好的，我已成功执行命令.*|已经记住了.*|好的，我已记住了.*|好的，大肥鱼.*|不客气，大肥鱼.*)$/;

/**
 * 判断一条事实是否为「噪声」（不应作为长期记忆入库/注入）。
 * @param {string} text 原始事实文本（可能带 `用户:`/`助手:` 前缀）
 * @param {{allowUpdate?: boolean}} [opt] allowUpdate 默认 true（识别更新模式并保留）
 * @returns {boolean} true=噪声，应剔除
 */
export function isNoiseFact(text, opt = {}) {
  const t = String(text || "").trim();
  if (!t) return true;
  // 助手回执（除非携带来自用户的事实更新）。
  if (/^助手[：:]/.test(t)) {
    if (opt.allowUpdate === false) return true;
    return !UPDATE_PATTERN.test(t);
  }
  const body = t.replace(/^(用户|助手)[：:]\s*/, "");
  if (!body) return true;
  // 寒暄/致谢/情绪短句：去标点/emoji 后整串仅由礼貌词构成，且长度 ≤ 12。
  const stripped = body.replace(/[！!。.~\s，,～、？?；;：:""''（）()\[\]【】…—\-_/\\|@#$%^&*+=~`😊😄☕🧊✅❤️🥰😂🙏]/g, "");
  if (stripped.length > 0 && stripped.length <= 12 && isPureGreeting(stripped)) return true;
  // 垃圾/指令噪声。
  if (GARBAGE_NOISE.test(body)) return true;
  // 过短且无任何实体（无数字、无 ≥2 连续 CJK、无 ≥2 连续拉丁）→ 视为无意义碎片。
  const hasEntity = /[0-9]|[a-zA-Z]{2,}|[一-鿿]{2,}/.test(body);
  if (body.length <= 6 && !hasEntity) return true;
  return false;
}

/** 归一化文本键（稳定排序用，绝不含时间戳）：text 优先，退回 (s,p,o)。 */
function normTextKey(c) {
  const t = typeof c.text === "string" && c.text.trim()
    ? c.text.trim()
    : [c.s, c.p, c.o].filter((x) => typeof x === "string" && x).join(" ");
  return t.toLowerCase();
}

function layerOf(c) {
  return Number.isFinite(c.layer) ? c.layer : 1;
}

/**
 * 预算编译 + 缓存友好布局（I1/I2，M2）。
 *
 * 分两段渲染，段内与段间都不含 per-call 时间戳：
 *   稳定段（volatility==='stable'）：持久画像/语义事实，排序键 (layer 降序, 归一化文本, id)，
 *     **与 query 无关** → 记忆不变时逐字节恒定 → 可命中前缀缓存。
 *   易变段（其余）：本轮召回新增/更新的行，排序键 (score 降序, id)，排在稳定段之后。
 * 预算硬上限：逐行累加，任何一步 estimateTokens(当前 text) ≤ budgetTokens；
 *   稳定段先占预算，剩余给易变段。稳定段单段超预算则按稳定键顺序截断（仍恒定）。
 * 易变段预留：稳定段最多只能用 `budget - ceil(budget·volatileReserveRatio)` 的预算，其余**留给
 *   本轮检索到的易变行**。没有这条预留，一个大的与 query 无关的稳定段（如整库多为线索/画像事实时）
 *   会把预算吃干、易变段恒为 0 字节 → 逐 query 注入同一坨固定文本，「按查询检索」形同虚设。
 *   默认 volatileReserveRatio=0.5（稳定段至多半数预算）；传 0 则退回「稳定段可吃满预算」的旧行为。
 *
 * @param {{id:string, score?:number, layer?:number, volatility?:'stable'|'volatile',
 *          text?:string, s?:string, p?:string, o?:string}[]} candidates
 * @param {{budgetTokens?: number, volatileReserveRatio?: number}} [opts]
 *        budgetTokens 硬上限；缺省/非有限 → 视为 0（返回空）。volatileReserveRatio 见上，缺省 0.5。
 * @returns {{text: string, items: {id:string,tokens:number,score:number,volatility:string}[],
 *            meta: {stableBytes:number, volatileBytes:number, budgetUsed:number, stableChars:number}}}
 */
export function compile(candidates, opts = {}) {
  const list = Array.isArray(candidates) ? candidates.filter((c) => c && typeof c.id === "string") : [];
  const budget = Number.isFinite(opts.budgetTokens) && opts.budgetTokens > 0 ? opts.budgetTokens : 0;

  const stable = list
    .filter((c) => c.volatility === "stable")
    .sort((a, b) => (layerOf(b) - layerOf(a)) || cmpStr(normTextKey(a), normTextKey(b)) || cmpStr(a.id, b.id));
  const volatile = list
    .filter((c) => c.volatility !== "stable")
    .sort((a, b) => (num(b.score) - num(a.score)) || cmpStr(a.id, b.id));

  const lines = [];
  const chosen = [];
  let stableChars = 0;
  if (budget > 0) {
    // 稳定段预算上限 = budget - 易变段预留（见函数头）。clamp 到 [0, budget]。
    const reserveRatio = Number.isFinite(opts.volatileReserveRatio) ? Math.max(0, Math.min(1, opts.volatileReserveRatio)) : 0.5;
    const stableBudget = Math.max(0, Math.min(budget, budget - Math.ceil(budget * reserveRatio)));
    for (const c of stable) {
      const line = renderLine(c);
      if (estimateTokens(lines.concat(line).join("\n")) <= stableBudget) {
        lines.push(line);
        chosen.push({ id: c.id, tokens: estimateTokens(line), score: num(c.score), volatility: "stable" });
      }
    }
    stableChars = lines.join("\n").length;
    for (const c of volatile) {
      const line = renderLine(c);
      if (estimateTokens(lines.concat(line).join("\n")) <= budget) {
        lines.push(line);
        chosen.push({ id: c.id, tokens: estimateTokens(line), score: num(c.score), volatility: "volatile" });
      }
    }
  }

  const text = lines.join("\n");
  const stableText = text.slice(0, stableChars);
  const volatileText = text.slice(stableChars);
  return {
    text,
    items: chosen,
    meta: {
      stableBytes: Buffer.byteLength(stableText, "utf8"),
      volatileBytes: Buffer.byteLength(volatileText, "utf8"),
      budgetUsed: estimateTokens(text),
      stableChars,
    },
  };
}

function cmpStr(a, b) {
  const x = a == null ? "" : String(a);
  const y = b == null ? "" : String(b);
  return x < y ? -1 : x > y ? 1 : 0;
}

function num(v) {
  return typeof v === "number" && Number.isFinite(v) ? v : 0;
}

function tokenSet(text) {
  return new Set(tokenize(text));
}

function medianOf(values) {
  if (values.length === 0) return 0;
  const s = [...values].sort((a, b) => a - b);
  const mid = s.length >> 1;
  return s.length % 2 === 1 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

function jaccard(a, b) {
  if (a.size === 0 || b.size === 0) return 0;
  let inter = 0;
  for (const x of a) if (b.has(x)) inter++;
  return inter / (a.size + b.size - inter);
}

// ─────────────────────────────────────────────────────────────────────────────
// compileFromEntries — 生产注入路径（D 进 DSH）
//
// 输入是 Markdown 记忆条目（{ts, sessionId, title, facts[]}，即 readMemoryFile 的形状），
// 输出可直接塞进 systemPrompt 的文本 + 可观测 meta。与 compile() 的区别：
//   · 稳定段由**条目内容自身**判定（跨会话重复 ≥2 或含画像线索词），不依赖外部 layer；
//   · 易变段用 core 的 BM25 对**本轮用户输入**检索，原始分数进 meta.rawTopScore；
//   · 末尾追加边界声明：检索到条目时用「部分作答契约」(BOUNDARY)；可选拒答门触发
//     （rawTopScore 低于阈值或本轮零命中）时清空易变段，只留稳定段 + 「零命中」文案 (GATED_BOUNDARY)。
// 硬约束：无 per-call 时间戳 / 随机量；同输入同预算 → 字节相同；绝不抛。
// ─────────────────────────────────────────────────────────────────────────────

const MARKER = "<!-- dsh-local-memory -->";
const HEADING = "## 长期记忆（本地模型，跨会话）";
const GUIDE = "以下是你之前会话里记住的要点，供参考；可能已过时，与用户当前说法冲突时以用户当前说法为准：";
// 1.1.1 静默背景文案（宿主配置 silentMemory:true 时启用）：
//   把「记忆」框架降级为「背景资料」，并**明确禁止复述/宣告**——解决"每轮都回一句我记得"的体验问题。
//   核心默认仍是旧文案（字节回归/golden 不变），由插件配置默认开启。
const HEADING_SILENT = "## 背景资料（用户过往提及，仅供理解）";
const GUIDE_SILENT = "以下是用户过去提到过的背景信息。仅在确实相关时自然使用；不要主动提起、不要复述、不要说「根据记忆」或「我记得」；与用户当前说法冲突时以当前说法为准：";
export const BOUNDARY_SILENT = "以上是背景资料。问题涉及其中内容时直接自然地使用；问题问的项若不在其中，就说明缺的是哪一项（例如「记忆里没有你的住址」），不要猜测、不要编造；不要复述这些背景。";
export const GATED_BOUNDARY_SILENT = "背景资料里没有与当前问题相关的内容。被问到的项若确实没有，就说明缺的是哪一项（例如「记忆里没有你的住址」），不要只回一句没有相关信息。";
// 部分作答契约：检索到条目时使用。明确「只答确有的、有的必须照常答出、缺哪部分只针对那部分说没有」，
// 避免模型把「部分信息不足」误当成「整题不能答」而全盘拒答（实测召回率杀手）。
// 缺失部分用短拒答短语「没有相关信息」（而非整句「记忆里没有相关信息」），既保持拒答可识别、
// 又避免弱模型把整句拒答照搬到整题；该短语只针对缺失项，不波及已答出的部分。
export const BOUNDARY = "以下为从长期记忆中检索到的条目，可能不完整、也可能与当前问题无关。请只依据其中确实出现的信息回答：凡是条目里有的信息，必须照常答出，不要因为另一些信息缺失就拒绝整题；对于条目里确实缺失的那部分，只需针对它说明“没有相关信息”即可；条目里没有的信息不要猜测，也不要为补全而编造。";
// 零命中文案：门控触发（压根没有相关条目）时使用，措辞更果断。与 BOUNDARY 是两段不同文字，不合并。
export const GATED_BOUNDARY = "记忆中没有与当前问题相关的条目；若确实不确定，请直接说明没有相关信息。";

// 1.1.1：显式"问记忆"的意图词。命中即强制注入（即使用户问法和记忆里的词面没有重叠，
// 例如"你还记得吗""之前我说过啥"）。与 queryOverlapsItems 是 OR 关系。
const MEMORY_INTENT = /(记得|记忆|回忆|之前|以前|上次|上回|前面说|说过|提过|我叫什么|我叫啥|我是谁|我的名字|我喜欢什么|我住|还记得|想起|早先|上一次|几点|什么时候|会议|评审|开会|有会|日程)/;
function hasMemoryIntent(query) {
  try { return MEMORY_INTENT.test(String(query == null ? "" : query)); } catch { return false; }
}

// 1.1.1：判断本轮提问与记忆条目是否有"有意义的"词面重叠。
// 中文按双字词（避免单字"我/个"乱命中），英文/数字按整词（≥2 字符）。
// 用途：skipVolatileWhenNoHit=true 时，若无重叠就认为"这轮不需要联想"，不放检索段。
function queryOverlapsItems(query, items) {
  try {
    const q = String(query == null ? "" : query).replace(/[^\p{L}\p{N}]+/gu, " ").trim().toLowerCase();
    if (!q) return false;
    const grams = new Set();
    for (const seg of q.split(/\s+/)) {
      if (!seg) continue;
      if (/^[a-z0-9]+$/.test(seg)) { if (seg.length >= 2) grams.add(seg); continue; }
      for (let i = 0; i + 1 < seg.length; i++) grams.add(seg.slice(i, i + 2));
    }
    if (!grams.size) return false;
    for (const it of items) {
      const t = String((it && it.text) || "").toLowerCase();
      for (const g of grams) if (t.includes(g)) return true;
    }
    return false;
  } catch {
    return true; // 判不出来时按"有重叠"处理：宁可注入，不要误丢
  }
}


// 旧版 BOUNDARY 四条契约约 120+ token。两个独立优化项，各有开关（A/B 用 measure-adherence.mjs）：
//   compactBoundary = 指令压缩（四条契约 → 两条更短），拒答措辞保持旧式「没有相关信息」；
//   namedRefusal    = 具名式拒答：把「没有相关信息」升级为「记忆里没有<该项>」（点名缺失项，
//                     降低「整题拒答」；外部真机现象的直接对策）。namedRefusal 蕴含 compact。
// A/B 定稿后经 DEFAULT_* 启用；旧版文案保留在 BOUNDARY/GATED_BOUNDARY 作对照与回退。
export const BOUNDARY_COMPACT = "以上是记忆条目，可能不完整。只按其中出现的信息回答：条目里有的信息照常答出；确实没有的部分，说明「没有相关信息」即可；不要猜测、不要编造。";
export const BOUNDARY_NAMED = "以上是记忆里确实存在的条目。只按其中出现的信息回答：条目里有的项照常答出；条目里没有的项，要说出缺的是哪一项、并把它点出来（例如「记忆里没有你的住址」）；不要猜测、不要编造。";
export const GATED_BOUNDARY_COMPACT = "记忆中没有与当前问题相关的条目；若确实不确定，请直接说明没有相关信息。";
export const GATED_BOUNDARY_NAMED = "记忆里没有与当前问题相关的条目。被问到的项若不在上面，请说出缺的是哪一项（例如「记忆里没有你的住址」），不要只回一句没有相关信息。";
// A/B 定稿（2026-10-22，见 docs/基准报告-v6-能力指数.md §1.2）：
//   injectSummary=true / injectTags=true / namedRefusal=true —— 8b 上 absent +30pp、distractor +24pp、recall 服从率保持 1.000；
//   代价：0.6b 的 recall 服从率崩塌（0.875→0.063，过度泛化具名拒答）——0.6b 本就「不建议」（见 RELEASE-NOTES 模型选型）。
//   compactBoundary（纯指令压缩、不具名）单独无效（absent 反而全面下降）→ 默认 false，仅保留开关供回退。
export const DEFAULT_INJECT_SUMMARY = true;
export const DEFAULT_INJECT_TAGS = true;
export const DEFAULT_COMPACT_BOUNDARY = false;
export const DEFAULT_NAMED_REFUSAL = true;
// rc6 P0-3（A/B 后定默认）：
//   summaryEmphasis = 摘要后加一行强调「回答时优先使用上面的已知事实；确有缺失才说缺哪一项」
//   summaryInBlock  = 摘要放进 <memory_facts> 块内（默认在块外：标题之后、标签之前）
export const SUMMARY_EMPHASIS = "回答时优先使用上面的已知事实；确有缺失才说缺哪一项。";
export const DEFAULT_SUMMARY_EMPHASIS = false;
export const DEFAULT_SUMMARY_IN_BLOCK = false;

/**
 * rc6：剥离写入侧时间标记（<!--supersedes:…--> / <!--supersededBy:…-->）。
 * 标记留在记忆文件里供审计，但绝不进 prompt（否则污染注入文本、白占 token、破坏字节稳定）。
 */
const TEMPORAL_MARK_RE = /<!--\s*supersedes:[\s\S]*?-->|<!--\s*supersededBy:[\s\S]*?-->/g;
export function stripTemporalMarkers(text) {
  return String(text == null ? "" : text).replace(TEMPORAL_MARK_RE, "").trim();
}

// 1.0.1 P2：重复标记 `^duplicate-of <ref>`（写入侧去重时打在既有行尾）。
// 只在**有标记**时改变结果 → 现网（无标记）逐字节不变。
const DUP_MARKER_RE = /\^duplicate-of [^\s^]+(?:\^duplicate-of [^\s^]+)*\s*$/;
export function stripDupMarkers(text) {
  return String(text == null ? "" : text).replace(DUP_MARKER_RE, "").trim();
}

/** 稳定去重键：NFKC + 小写 + 空白折叠（只用于比较，不改写展示文本）。 */export function stableKey(text) {
  return String(text)
    .normalize("NFKC")
    .toLowerCase()
    .replace(/\s+/g, " ")
    .trim();
}

/**
 * rc4 两段式摘要（rc6 扩展）：块首高显著度摘要。
 * 两路来源合并：① 「**键**：值」型画像事实；② 普通事实的零 LLM 正则抽取
 * （我叫/叫我/我喜欢/我住/我的X是）——外部真机的「记住：我叫小X，我喜欢Y」属于②，
 * rc4 只做①导致摘要行不出现。
 * 约束：最多 3 行、每行 ≤20 字；同一键多值时保留**后出现**的（最新）；无内容返回空串。
 * 只读稳定组（确定性、前缀稳定），不引入随机/时间因素。
 */
const SUMMARY_LINE_MAX = 20;
const SUMMARY_MAX_LINES = 3;
const SUMMARY_KEY_MAX = 6;
const SUMMARY_VAL_MAX = 8;

function cleanSummaryVal(v) {
  return String(v || "").replace(/[。，,！!；;]+$/, "").replace(/^(了|的)\s*/, "").trim();
}

/** 从一段文本抽取摘要对（一句里可能有多条：记住：我叫小X，我喜欢Y → 两对）。 */
function summaryPairsOf(text) {
  const s = String(text || "").trim();
  const out = [];
  const m0 = /^\*\*([^*]+)\*\*\s*[：:]\s*(.+)$/.exec(s);
  if (m0) { out.push([m0[1].trim(), cleanSummaryVal(m0[2])]); return out; }
  let m;
  if ((m = /我叫([^\s，。；,、]{1,10})/.exec(s))) out.push(["称呼", cleanSummaryVal(m[1])]);
  if ((m = /叫我([^\s，。；,、]{1,10})/.exec(s))) out.push(["称呼", cleanSummaryVal(m[1])]);
  const likes = s.match(/我喜欢([^，。；,、]{1,12})/g) || [];
  for (const l of likes) out.push(["喜好", cleanSummaryVal(l.replace(/^我喜欢/, ""))]);
  if ((m = /我住([^，。；,、]{1,12})/.exec(s))) out.push(["住址", cleanSummaryVal(m[1])]);
  if ((m = /我的?([^\s，。；,、]{2,6})是([^，。；,、]{1,12})/.exec(s))) out.push([m[1].trim(), cleanSummaryVal(m[2])]);
  return out;
}

export function buildSummaryLine(stableGroups) {
  const pairs = new Map();
  for (const it of stableGroups || []) {
    for (const p of summaryPairsOf((it && it.text) || "")) {
      const k = p[0].slice(0, SUMMARY_KEY_MAX);
      const v = p[1].slice(0, SUMMARY_VAL_MAX);
      if (!k || !v) continue;
      pairs.delete(k);            // 同一键保留最新（后出现的覆盖先出现的）
      pairs.set(k, v);
    }
  }
  if (pairs.size === 0) return "";
  const lines = [];
  let cur = "已知事实：";
  let first = true;
  for (const [k, v] of pairs) {
    const item = `${k}=${v}`;
    const next = first ? cur + item : `${cur}；${item}`;
    if (next.length > SUMMARY_LINE_MAX && !first) {
      lines.push(cur);
      if (lines.length >= SUMMARY_MAX_LINES) break;
      cur = item;
      first = false;
    } else {
      cur = next;
      first = false;
    }
  }
  if (lines.length < SUMMARY_MAX_LINES && cur) lines.push(cur);
  return lines.slice(0, SUMMARY_MAX_LINES).join("\n");
}

/** 助手回执里的「已记住」不是用户画像：线索词只用于非助手事实。 */
export function isAssistantFact(text) {
  return /^助手[：:]/.test(String(text));
}

/**
 * 事实是否携带「更新语义」（已更新 / 现在是 / 改成 / 变为 …）。
 * 写入侧治理（governTurnFacts）用它区分「纯助手回执」（丢）与「事实复述确认」（留）：
 * 助手说「已更新：项目代号现在是 V5C-KXZ1912」是在复述用户事实的变更，不是寒暄。
 */
export function hasUpdateSemantics(text) {
  return UPDATE_PATTERN.test(String(text || ""));
}

/**
 * 噪声事实的细分类型（写入侧治理 skipped:{ack,greet,dup} 计数用；非噪声返回 null）：
 *   "greet" = 纯寒暄/致谢（任一侧：去前缀、去标点后整串仅由寒暄短词构成）
 *   "ack"   = 其余噪声——实机样本几乎都是助手侧回执/指令复述/垃圾（如「好的，已记住」）
 *   null    = 不是噪声（应先过 isNoiseFact）
 */
export function noiseKindOf(text) {
  const t = String(text || "").trim();
  if (!t) return "greet";
  const body = t.replace(/^(用户|助手)[：:]\s*/, "");
  const stripped = body.replace(/[！!。.~\s，,～、？?；;：:""''（）()\[\]【】…—\-_/\\|@#$%^&*+=~`😊😄☕🧊✅❤️🥰😂🙏]/g, "");
  if (stripped.length > 0 && stripped.length <= 12 && isPureGreeting(stripped)) return "greet";
  return "ack";
}

function turnOf(title) {
  const m = /第\s*(\d+)\s*轮/.exec(String(title || ""));
  return m ? Number(m[1]) : null;
}

/** 去掉「用户: / 助手:」前缀后的正文键（同轮次重复表述折叠用）。 */
function bodyKey(text) {
  return stableKey(String(text).replace(/^(用户|助手)[：:]\s*/, ""));
}

// ── P1-2 属性覆盖门辅助函数 ────────────────────────────────────────────────

/** 小写 + NFKC 归一化。 */
function lower(s) {
  return String(s || "").normalize("NFKC").toLowerCase();
}

/** 从查询中抽取必需属性标记。 */
function requiredAttributes(query) {
  const q = lower(query);
  const out = [];
  if (/作者|谁的|谁写|谁画|提出者|发明|发现者|撰写/.test(q)) out.push("author");
  if (/日期|哪一年|哪年|何时|什么时候|年份|截至/.test(q)) out.push("date");
  if (/多少|几个|数量|行数|长度|距离|高度|硬度|多大|差值|增加|减少|折算|约合/.test(q)) out.push("number");
  if (/版本/.test(q)) out.push("version");
  if (/代号|编号|标识|代码/.test(q)) out.push("code");
  if (/名称|叫什么|叫什么/.test(q)) out.push("name");
  return out;
}

/** 判断文本是否覆盖某属性。 */
function covers(text, attr) {
  const s = lower(text);
  if (attr === "author") return /作者|written by|提出者|发明|发现者|撰写/.test(s);
  if (attr === "date") return /\d{4}[-/.]\d{1,2}[-/.]\d{1,2}|日期|年份|截至/.test(s);
  if (attr === "number") return /\d+/.test(s);
  if (attr === "version") return /\bv\d+(?:\.\d+)*\b|版本/.test(s);
  if (attr === "code") return /[a-z0-9]*[a-z][a-z0-9]*\d[a-z0-9]*|[a-z0-9]*\d[a-z0-9]*[a-z]|\d{4,}|[a-z0-9]+[-_][a-z0-9]+/.test(s);
  if (attr === "name") return /名称|叫|代号|编号/.test(s);
  return true;
}

/** 检查 top volatile fact 是否覆盖查询的全部必需属性。 */
function attributeCovered(topText, query) {
  const attrs = requiredAttributes(query);
  if (attrs.length === 0) return true; // 无必需属性 → 视为通过
  return attrs.every((a) => covers(topText, a));
}

// ───────────────────────────────────────────────────────────────────────────

/** 稀有精确代号候选 token（小写；字母+数字、≥4 位数字、≥6 位拉丁、带 -/_）。 */
function rareCodeTokens(query) {
  const raw = String(query || "").toLowerCase();
  const out = [];
  const seen = new Set();
  for (const m of raw.match(/[a-z0-9]+(?:[-_][a-z0-9]+)*/g) || []) {
    if (seen.has(m)) continue;
    const mixed = /[a-z]/.test(m) && /\d/.test(m);
    const longNumber = /^\d{4,}$/.test(m);
    const longLatin = /^[a-z]{6,}$/.test(m);
    const punctCode = /[-_]/.test(m);
    if (mixed || longNumber || longLatin || punctCode) {
      seen.add(m);
      out.push(m);
    }
  }
  return out;
}

/**
 * 从记忆条目编译注入文本（生产路径）。
 *
 * @param {{ts?:number, sessionId?:string, title?:string, facts?:string[]}[]} entries
 * @param {{query?:string, budgetTokens?:number, now?:number, gate?:{
 *   minTopScore?:number, minSeparation?:number, minRelative?:number, minPTop?:number,
 *   minRobustZ?:number, minGap?:number, gateMinFacts?:number, pTopMinCandidates?:number,
 *   rareExact?:boolean|number, rareMaxDocs?:number, dupJaccard?:number,
 *   requireAttributeCover?:boolean  // P1-2 属性覆盖门：默认 false（关闭）
 * }} [opts]
 *        query 本轮用户输入；budgetTokens 硬上限（缺省/非法 → 返回空）；
 *        任一 gate 判据默认 0/false = 不门控；rareExact 只做「稀有精确证据」正向 override；
 *        pTop 另受 pTopMinCandidates 限制；requireAttributeCover 默认 false（关闭，字节回归一致）；
 *        now 保留参数，不参与输出。
 * @returns {{text:string, items:{id:string, text:string, score:number, volatility:string}[],
 *            meta:{stableBytes:number, volatileBytes:number, budgetUsed:number, stableChars:number,
 *                  rawTopScore:number, secondScore:number, gap:number, separation:number,
 *                  pTop:number, robustZ:number, m:number, factCount:number,
 *                  rareToken:string|null, rareDocs:number, gated:boolean, items:number,
 *                  attrCovered?:boolean}}}  // P1-2 属性覆盖状态（仅当 requireAttributeCover=true 时有意义）
 */
export function compileFromEntries(entries, opts = {}) {
  // 稳定段预算占比上限（缺省 0.5 = 稳定段至多占半数预算）。与下方稳定段装配
  // `stableCap = Math.floor(budget * STABLE_CAP_RATIO)` 同源；改这里即改两处，避免写死 0.5 漂移。
  const STABLE_CAP_RATIO = 0.5;
  const t0 = typeof performance !== "undefined" ? performance.now() : Date.now();
  const emptyMeta = {
    stableBytes: 0, volatileBytes: 0, budgetUsed: 0, stableChars: 0,
    rawTopScore: 0, secondScore: 0, medianNonZero: 0, separation: 0,
    pTop: 0, robustZ: 0, m: 0, factCount: 0,
    gap: 0,     rareToken: null, rareDocs: 0, gated: false, items: 0,
    attrCovered: undefined, // P1-2 属性覆盖状态（默认关闭时 undefined）
    conflict: false, conflictKeys: [], // 阶段2：真冲突标记（缺省 false/[]，纯增量）
    // P0.2 记忆治理可观测（仅当 opts.dropNoise/foldInject 激活时有意义；缺省 0 → 字节回归一致）。
    droppedNoise: 0, folded: 0, deduped: 0,
    ms: 0, cache: "off", // 阶段3：编译耗时(ms,1位小数) + 索引缓存命中状态
    cacheReason: null, cacheFacts: 0, cacheEntries: 0, cacheRssMB: 0,
    // 本轮（T0/T1 检索剪枝）：候选规模与剪枝可观测；strategy 缺省 'intersect'（T1）。
    strategy: "intersect", pruned: 0, candidates: 0,
  };
  const elapsMs = () => {
    const t1 = typeof performance !== "undefined" ? performance.now() : Date.now();
    return Math.round((t1 - t0) * 10) / 10;
  };
  try {
    const budget = Number.isFinite(opts && opts.budgetTokens) && opts.budgetTokens > 0
      ? Math.trunc(opts.budgetTokens)
      : 0;
    if (budget <= 0) return { text: "", items: [], meta: emptyMeta };

    // P0.2 记忆治理开关（缺省全关 → 与改动前逐字节相同）：
    //   dropNoise：注入侧剔除噪声事实（助手回执/寒暄/垃圾）。
    //   foldInject：同 key 多条只出最新一条，其余折叠为「另 N 条同类已折叠」。
    //   maxFactRenderChars：每条注入事实正文硬截断到 N 字（干净截断，不带「已截断」后缀）。
    const dropNoise = !!(opts && opts.dropNoise);
    const foldInject = !!(opts && opts.foldInject);
    // rc4 服从性开关：默认 = A/B 定稿（summary+tags+named）。传 opts 可逐项覆盖（A/B 与回退用）。
    const injectSummary = opts && opts.injectSummary !== undefined ? !!opts.injectSummary : DEFAULT_INJECT_SUMMARY;
  // 1.1.1：静默背景（不宣告记忆）+ 无相关命中时不放易变段（"不需要联想"就别联想）
  const silentMemory = opts && opts.silentMemory !== undefined ? !!opts.silentMemory : false;
  const skipVolatileWhenNoHit = opts && opts.skipVolatileWhenNoHit !== undefined ? !!opts.skipVolatileWhenNoHit : false;
    const injectTags = opts && opts.injectTags !== undefined ? !!opts.injectTags : DEFAULT_INJECT_TAGS;
    const compactBoundary = opts && opts.compactBoundary !== undefined
      ? !!opts.compactBoundary
      : DEFAULT_COMPACT_BOUNDARY;
    const namedRefusal = opts && opts.namedRefusal !== undefined
      ? !!opts.namedRefusal
      : DEFAULT_NAMED_REFUSAL;
    const summaryEmphasis = opts && opts.summaryEmphasis !== undefined
      ? !!opts.summaryEmphasis
      : DEFAULT_SUMMARY_EMPHASIS;
    const summaryInBlock = opts && opts.summaryInBlock !== undefined
      ? !!opts.summaryInBlock
      : DEFAULT_SUMMARY_IN_BLOCK;
    const maxFactRenderChars = Number.isFinite(opts && opts.maxFactRenderChars)
      ? Math.max(0, Math.trunc(opts.maxFactRenderChars))
      : 0;
    let droppedNoise = 0;

    // 0b) asOf 时间旅行 + 真冲突检测（阶段2）：仅当显式传入合法 ISO 日期时生效；
    //     缺省（undefined/null/非法）时原样使用 entries，不做任何处理 → 与阶段1逐字节相同。
    const asOfArg = opts && opts.asOf;
    const asOfValid = typeof asOfArg === "string" && /^\d{4}-\d{2}-\d{2}$/.test(asOfArg);
    let workingEntries = entries;
    let asOfConflicts = [];
    let asOfCoverage = null; // 债2：asOf 时间 grounding 覆盖率（缺省为 null，meta 不出现该字段）
    if (asOfValid) {
      const r = applyAsOf(entries || [], asOfArg);
      workingEntries = r.entries;
      asOfConflicts = r.conflicts;
      asOfCoverage = r.coverage || null;
    }

    // 1) 拍平成唯一事实项（id 由条目/事实下标派生，稳定且唯一）。
    const items = [];
    for (let ei = 0; ei < (workingEntries || []).length; ei++) {
      const e = workingEntries[ei];
      if (!e || !Array.isArray(e.facts)) continue;
      for (let fi = 0; fi < e.facts.length; fi++) {
        const raw = e.facts[fi];
        const text = typeof raw === "string" ? stripDupMarkers(stripTemporalMarkers(raw)) : "";
        if (!text) continue;
        // P0.2 注入侧噪声剔除（缺省 dropNoise=false → 跳过，字节回归一致）。
        if (dropNoise && isNoiseFact(text)) { droppedNoise++; continue; }
        items.push({
          id: `e${ei}-f${fi}`,
          text,
          lower: text.toLowerCase(),
          sessionId: typeof e.sessionId === "string" ? e.sessionId : "",
          turn: turnOf(e.title),
          bodyKey: bodyKey(text),
          ts: num(e.ts),
          key: stableKey(text),
        });
      }
    }
    if (items.length === 0) return { text: "", items: [], meta: emptyMeta };

    // 2) 稳定判定：同键事实跨会话 ≥2，或（非助手事实）含画像线索词。
    //    P0.2 折叠：每个键记录 count 与 last（最新一次出现，按迭代序=条目/事实序），
    //    折叠开启时取 last 作展示行（其余折叠），关闭时取 first（与改动前一致）。
    const groups = new Map(); // key -> { first, last, count, sessions:Set, clue:boolean }
    for (const it of items) {
      let g = groups.get(it.key);
      if (!g) { g = { first: it, last: it, count: 0, sessions: new Set(), clue: false }; groups.set(it.key, g); }
      g.count++;
      g.last = it; // 迭代序靠后者为「最新」
      if (it.sessionId) g.sessions.add(it.sessionId);
      if (!isAssistantFact(it.text) && hasClue({ text: it.text })) g.clue = true;
    }
    const stableGroups = [];
    const stableKeys = new Set();
    for (const [key, g] of groups) {
      if (g.clue || g.sessions.size >= 2) {
        stableGroups.push(foldInject ? g.last : g.first);
        stableKeys.add(key);
      }
    }
    stableGroups.sort((a, b) => cmpStr(a.key, b.key) || cmpStr(a.id, b.id));

    // 3) 易变段：对非稳定事实做 BM25 检索（原始分数，不归一化）。
    //    P0.2 折叠：折叠开启时同键取最新一次（last wins），关闭时取首次（first wins，与改动前一致）。
    const volatileItems = [];
    if (foldInject) {
      const lastByKey = new Map();
      for (const it of items) {
        if (stableKeys.has(it.key)) continue;
        lastByKey.set(it.key, it); // 后写覆盖 → last wins
      }
      for (const it of lastByKey.values()) volatileItems.push(it);
    } else {
      const seenKey = new Set();
      for (const it of items) {
        if (stableKeys.has(it.key) || seenKey.has(it.key)) continue;
        seenKey.add(it.key);
        volatileItems.push(it);
      }
    }
    // 阶段3：增量索引缓存。索引与 entries 解耦：同文件同事实集 → 命中（复用，零重建）；
    // 仅追加新事实 → 追加（upsert 增量）；结构性变化 → 重建；RSS 超限或异常 → 降级为无缓存重建。
    // 关键不变量：index-fts 的 search 取实时 N/avgdl 且 upsert/delete 正确维护，
    // 故「增量 upsert 新事实 + delete 已删事实」的最终索引 == 对并集的冷 rebuild
    // （统计量均匀、顺序无关）→ 命中/追加 路径与 冷重建 逐字节一致。
    const factCountAll = items.length;
    const lastFactId = factCountAll > 0 ? items[factCountAll - 1].id : "";
    let idxResult = null;
    try {
      idxResult = getIndex({
        sourcePath: (opts && typeof opts.sourcePath === "string" && opts.sourcePath) || null,
        volatileItems,
        factCount: factCountAll,
        lastId: lastFactId,
      });
    } catch {
      idxResult = null; // 静默降级：任何异常退回无缓存路径
    }
    let idx;
    if (idxResult && idxResult.index) {
      idx = idxResult.index;
    } else {
      idx = createIndex();
      for (const it of volatileItems) idx.upsert({ id: it.id, text: it.text });
    }
    const cacheStatus = (idxResult && idxResult.status) || "off";
    const cacheReason = (idxResult && idxResult.reason) || null;
    const cacheFacts = (idxResult && idxResult.facts) || 0;
    const cacheEntries = (idxResult && idxResult.entries) || 0;
    const cacheRssMB = (idxResult && idxResult.rssMB) || 0;
    const cacheHeapUsedMB = (idxResult && Number.isFinite(idxResult.heapUsedMB)) ? idxResult.heapUsedMB : 0;
    const cacheBaselineMB = (idxResult && Number.isFinite(idxResult.baselineMB)) ? idxResult.baselineMB : 0;
    // 本轮（T0/T1 检索剪枝）：生产默认 'intersect'（T1 稀有 gram 交集候选）；
    // 可通过 opts.idxStrategy 覆盖（'full' 退回原全量扫描，'skip' 仅 T0）。
    // 约束：门控（判定器）依赖「完整候选打分分布」算出的 pTop/robustZ/m/medianNonZero，
    // 而 T1 会把打分集收缩到候选子集，导致这些特征失真、判定器行为漂移。因此——门控一旦
    // 激活，必须退回 full，保证判定器输入逐字节不变；门控关闭（生产默认，全 0/false）时才走
    // T1 提速。这与「不许改判定器」硬约束一致。
    const g0 = (opts && opts.gate) || {};
    const gateActive =
      (Number.isFinite(g0.minTop) && g0.minTop > 0) ||
      (Number.isFinite(g0.minSeparation) && g0.minSeparation > 0) ||
      (Number.isFinite(g0.minRelative) && g0.minRelative > 0) ||
      (Number.isFinite(g0.minPTop) && g0.minPTop > 0) ||
      (Number.isFinite(g0.minRobustZ) && g0.minRobustZ > 0) ||
      (Number.isFinite(g0.minGap) && g0.minGap > 0) ||
      (Number.isFinite(g0.gateMinFacts) && g0.gateMinFacts > 0) ||
      (g0.rareExact === true || (Number.isFinite(g0.rareExact) && g0.rareExact > 0)) ||
      (g0.requireAttributeCover === true);
    const idxStrategy = (opts && typeof opts.idxStrategy === "string")
      ? opts.idxStrategy
      : (gateActive ? "full" : "intersect");
    const idxDiag = {};
    const hits = idx.search(typeof opts.query === "string" ? opts.query : "", { raw: true, strategy: idxStrategy, diag: idxDiag });
    const scoreById = new Map(hits.map((h) => [h.id, h.relevance]));
    const volatileRanked = volatileItems
      .filter((it) => (scoreById.get(it.id) || 0) > 0)
      .map((it) => ({ it, score: scoreById.get(it.id) || 0 }))
      .sort((a, b) => (b.score - a.score) || cmpStr(a.it.id, b.it.id));
    const rawTopScore = volatileRanked.length > 0 ? volatileRanked[0].score : 0;

    // 4) 预算：头 + 稳定段；稳定段至多半个预算（给易变段留位）。
    // rc4：两段式摘要 + 开标签都并进 base（稳定前缀内），不新增 parts 条目，
    // 保持 foldInject 的 parts[i]↔chosen[i-1] 对齐不被打乱。
    let base = `${MARKER}\n${silentMemory ? HEADING_SILENT : HEADING}\n${silentMemory ? GUIDE_SILENT : GUIDE}`;
    const summaryText = injectSummary ? buildSummaryLine(stableGroups) : "";
    if (summaryText) {
      const block = summaryEmphasis ? `${summaryText}\n${SUMMARY_EMPHASIS}` : summaryText;
      if (summaryInBlock) {
        if (injectTags) base += `\n<memory_facts>`;
        base += `\n${block}`;
      } else {
        base += `\n${block}`;
        if (injectTags) base += `\n<memory_facts>`;
      }
    } else if (injectTags) {
      base += `\n<memory_facts>`;
    }
    const baseTokens = estimateTokens(base);
    // 1.1.0-rc3 P0-c：预算连「头部 + 1 条事实」都放不下时，语义必须被定义。
    // 旧行为：静默返回 items:[]（宿主无法回答「为什么一条都没有」）。
    // 新行为：text 仍为空串，但 items 列出**全部候选**（dropped:true, reason:'budget'），
    //         并在 meta 给出 minBudgetTokens（头部 + 最便宜一条所需）与 reason:'budget-too-small'。
    // 边界：budget <= 0 视为「未指定/关闭」，保留空 items 的旧语义（core-smoke 用例 2 依赖它）。
    // 1.1.1：**按需联想**。若本轮既没有"问记忆"的意图词，也与记忆条目没有任何双字词重叠，
    // 就直接不注入（text 为空串），而不是把背景塞进 prompt 让模型复述。
    // 这是"不需要每次看记忆"的落点：无关联回合 = 零注入、零 token、零"我记得"。
    if (skipVolatileWhenNoHit && items.length > 0 &&
        !hasMemoryIntent(opts && opts.query) && !queryOverlapsItems(opts && opts.query, items)) {
      const droppedAll = items.map((it) => ({
        id: it.id, text: it.text, key: it.key,
        tokens: (() => { try { return estimateTokens(renderLine(it, 0)); } catch { return 0; } })(),
        score: 0, volatility: "unknown", dropped: true, reason: "irrelevant",
      }));
      return {
        text: "",
        items: droppedAll,
        meta: { ...emptyMeta, reason: "irrelevant", silent: silentMemory, skipped: true, minBudgetTokens: 0 },
      };
    }

    const factTokensOf = (it) => {
      try { return estimateTokens(renderLine(it, 0)); } catch { return 0; }
    };
    // 1.1.0-rc6 minBudget 精确化（主管批准 boundaryReserve 修法；两处代数偏差经逐预算扫描实测纠正）：
    //   rc5 遗留：易变段 needOf = base+cost 漏了边界声明预留（实测 boundaryCost≈81，与 base 同量级），
    //   弱匹配易变段实际 180 才入选而公式给 min=97 → min 档 chosen=0。
    //   修正后的 needOf「恰好满足两约束」（任务书 §1.2 的设计意图；§1.2 字面式经扫描证实有两处漏项）：
    //     ① 正文放得下：B ≥ base + boundary + cost
    //        —— reserve 必须含 closingTag（injectTags 默认 true 时实际 boundaryBlock = "\n\n</memory_facts>\n\n"+文案，
    //           §1.1 字面式漏了它：78 vs 完整 82，实测 f2 阈值 180 ≈ 85+14+81）。
    //     ② 稳定段 50% 上限：floor(B*STABLE_CAP_RATIO) ≥ base+该行 ⇒ B ≥ 2*(base+cost)
    //        —— §1.2 字面式 2*cost 漏了 base（稳定行加入后 parts=base+line 须整个落在 stableCap 内；
    //           实测 f0 阈值 190 = 2×95，而 2*12=24 严重低估）。
    //   边界：budget<=0 已在上方返回旧语义；budget < minBudgetTokens → 一定 0 入选（全 dropped + reason:'budget-too-small'）。
    const boundaryReserve = estimateTokens(
      "\n\n" + (injectTags ? "</memory_facts>\n\n" : "")
        + (namedRefusal ? BOUNDARY_NAMED : compactBoundary ? BOUNDARY_COMPACT : BOUNDARY)
    );
    const candidateLines = [
      ...stableGroups.map((it) => ({ id: it.id, cost: factTokensOf(it), stable: true, score: 0 })),
      ...volatileRanked.map(({ it, score }) => ({ id: it.id, cost: factTokensOf(it), stable: false, score })),
    ];
    const needOf = (c) => {
      const fit = baseTokens + c.cost + boundaryReserve;               // 约束①：正文 + 边界预留放得下
      return c.stable ? Math.max(fit, 2 * (baseTokens + c.cost)) : fit; // 约束②：稳定段 50% 上限（floor(B/2) ≥ base+cost）
    };
    const minBudgetTokens = candidateLines.length
      ? Math.min(...candidateLines.map(needOf))
      : baseTokens;
    const budgetTooSmall = () => ({
      text: "",
      items: candidateLines.map((c) => ({
        id: c.id,
        tokens: c.cost,
        score: c.score,
        dropped: true,
        reason: "budget",
      })),
      meta: { ...emptyMeta, budgetUsed: 0, reason: "budget-too-small", minBudgetTokens },
    });
    if (budget < minBudgetTokens) return budgetTooSmall();
    if (baseTokens > budget) return budgetTooSmall();

    // 拒答判据 v3：正交信号 OR + 稀有精确证据 override。默认全 0/false = 不门控。
    const gate = (opts && opts.gate) || {};
    const minTop = Number.isFinite(gate.minTopScore) ? gate.minTopScore : 0;
    const minSep = Number.isFinite(gate.minSeparation) ? gate.minSeparation : 0;
    const minRel = Number.isFinite(gate.minRelative) ? gate.minRelative : 0;
    const minPTop = Number.isFinite(gate.minPTop) ? gate.minPTop : 0;
    const minRobustZ = Number.isFinite(gate.minRobustZ) ? gate.minRobustZ : 0;
    const minGap = Number.isFinite(gate.minGap) ? gate.minGap : 0;
    const gateMinFacts = Number.isFinite(gate.gateMinFacts) ? gate.gateMinFacts : 0;
    const pTopMinCandidates = Number.isFinite(gate.pTopMinCandidates) ? gate.pTopMinCandidates : 0;
    const dupJaccard = Number.isFinite(gate.dupJaccard) ? gate.dupJaccard : DEFAULT_DUP_JACCARD;
    const rareExactEnabled = gate.rareExact === true || (Number.isFinite(gate.rareExact) && gate.rareExact > 0);
    const rareMaxDocs = Number.isFinite(gate.rareMaxDocs) ? gate.rareMaxDocs : 3;
    // P1-2 属性覆盖门：默认 false（关闭，字节回归一致）。
    const requireAttributeCover = gate.requireAttributeCover === true;

    const factCount = items.length;
    const m = volatileRanked.length;

    // secondScore 取「第二条不同的候选事实」。同一事实的助手回执/用户长句先按
    // (sessionId, turn, 去角色前缀正文) 精确折叠，再用 token Jaccard >= dupJaccard 兜底。
    const reps = [];
    for (const cand of volatileRanked) {
      if (reps.length >= 2) break;
      const set = tokenSet(cand.it.text);
      const exactDup = reps.some((r) =>
        r.sessionId === cand.it.sessionId && r.turn === cand.it.turn && r.bodyKey === cand.it.bodyKey);
      if (exactDup || reps.some((r) => jaccard(set, r.set) >= dupJaccard)) continue;
      reps.push({
        score: cand.score, set,
        sessionId: cand.it.sessionId, turn: cand.it.turn, bodyKey: cand.it.bodyKey,
      });
    }
    const secondScore = reps.length > 1 ? reps[1].score : 0;
    const gap = rawTopScore - secondScore;
    const nonZeroScores = volatileRanked.map((x) => x.score).sort((a, b) => a - b);
    const medianNonZero = nonZeroScores.length === 0
      ? 0
      : nonZeroScores.length % 2 === 1
        ? nonZeroScores[(nonZeroScores.length - 1) / 2]
        : (nonZeroScores[nonZeroScores.length / 2 - 1] + nonZeroScores[nonZeroScores.length / 2]) / 2;
    const separation = secondScore > 0 ? rawTopScore / secondScore : (rawTopScore > 0 ? Number.POSITIVE_INFINITY : 0);

    // 尺度无关特征：pTop = top 在非零候选中的经验分位；robustZ 用 log(1+s) 的稳健 z。
    const pTop = m === 0 ? 0 : (0.5 + nonZeroScores.filter((s) => s < rawTopScore).length) / (m + 1);
    let robustZ = 0;
    if (m > 0) {
      const zs = nonZeroScores.map((s) => Math.log1p(s));
      const zTop = Math.log1p(rawTopScore);
      const medZ = medianOf(zs);
      const mad = medianOf(zs.map((z) => Math.abs(z - medZ)));
      robustZ = (zTop - medZ) / (1.4826 * mad + 1e-9);
    }

    // rareExact：查询中的稀有代号只出现在少量事实里、且 top 事实原文包含 → 直接放行。
    let rareToken = null;
    let rareDocs = 0;
    if (rareExactEnabled && volatileRanked.length > 0) {
      const topText = volatileRanked[0].it.lower;
      let observed = false;
      for (const tok of rareCodeTokens(opts && opts.query)) {
        if (!topText.includes(tok)) continue;
        let docs = 0;
        for (const it of items) if (it.lower.includes(tok)) docs++;
        if (!observed && docs > 0) {
          rareDocs = docs;
          observed = true;
        }
        if (docs > 0 && docs <= rareMaxDocs) {
          rareToken = tok;
          rareDocs = docs;
          break;
        }
      }
    }
    const rareHit = rareToken !== null;

    // P1-2 属性覆盖门：检查 top volatile fact 是否覆盖查询的全部必需属性。
    // 只在 requireAttributeCover=true 时生效；默认 false（关闭，字节回归一致）。
    const topVolatileText = volatileRanked.length > 0 ? volatileRanked[0].it.text : "";
    const attrCovered = requireAttributeCover ? attributeCovered(topVolatileText, opts && opts.query) : true;

    const pTopActive = minPTop > 0 && (pTopMinCandidates <= 0 || m >= pTopMinCandidates);
    const blockingActive =
      minTop > 0 || minSep > 0 || minRel > 0 || pTopActive || minRobustZ > 0 || minGap > 0;
    const gateOn =
      blockingActive || minPTop > 0 || minGap > 0 || rareExactEnabled || requireAttributeCover;

    // P1-2 属性覆盖门：当 requireAttributeCover=true 且 attrCovered=false 时，
    // 无论其他信号如何都必须门控（不允许 rareHit 等 override）。
    const attrBlock = requireAttributeCover && !attrCovered;

    const passed =
      !attrBlock && ( // 属性未覆盖时直接失败，不走后续判据
        rareHit ||
        (minTop > 0 && rawTopScore >= minTop) ||
        // 只有一个不同候选 = 没有竞争者，相对分离度视为通过（分数高低交给绝对/相对判据）。
        (minSep > 0 && rawTopScore > 0 && (secondScore === 0 || rawTopScore / secondScore >= minSep)) ||
        (minRel > 0 && medianNonZero > 0 && rawTopScore / medianNonZero >= minRel) ||
        (pTopActive && pTop >= minPTop) ||
        (minRobustZ > 0 && robustZ >= minRobustZ) ||
        (minGap > 0 && rawTopScore > 0 && gap >= minGap)
      );

    // 小语料没有背景分布：达到门槛时整轮不门控（连零命中也不追加拒答声明）。
    // pTop 因 m 不足被忽略时，也不许用 pTop 来门控（只启用 pTop 则整体放行）。
    const smallCorpus = gateOn && gateMinFacts > 0 && factCount < gateMinFacts;
    const gated = gateOn && !smallCorpus && (m === 0 || (blockingActive && !passed));
    // 两条路径都追加边界声明，但文案不同：检索到条目 → 部分作答契约；门控零命中 → 果断拒答。
    // rc4：compactBoundary/namedRefusal 开启时换用新版 ≤70 字边界（named 蕴含 compact）；
    // 闭标签随边界一起预留预算。
    const boundaryText = gated
      ? (silentMemory ? GATED_BOUNDARY_SILENT
          : namedRefusal ? GATED_BOUNDARY_NAMED : compactBoundary ? GATED_BOUNDARY_COMPACT : GATED_BOUNDARY)
      : (silentMemory ? BOUNDARY_SILENT
          : namedRefusal ? BOUNDARY_NAMED : compactBoundary ? BOUNDARY_COMPACT : BOUNDARY);
    const closingTag = injectTags ? "</memory_facts>\n\n" : "";
    const boundaryBlock = `\n\n${closingTag}${boundaryText}`;
    const boundaryCost = estimateTokens(boundaryBlock);
    // 给边界声明预留预算，保证 budgetUsed<=budget 硬上限（内容段最多用到 budget-boundaryCost）。
    const contentCap = Math.max(baseTokens, budget - boundaryCost);
    let stableCap = Math.min(Math.max(baseTokens, Math.floor(budget * STABLE_CAP_RATIO)), contentCap);
    if (stableCap < baseTokens) return budgetTooSmall();

    const parts = [base];
    const chosen = [];
    for (const it of stableGroups) {
      const line = renderLine(it, maxFactRenderChars);
      if (estimateTokens(parts.concat(line).join("\n")) <= stableCap) {
        parts.push(line);
        chosen.push({ id: it.id, text: it.text, score: 0, volatility: "stable", key: it.key });
      }
    }
    let stablePartCount = parts.length;
    let stableChars = parts.join("\n").length;

    // 5) 拒答门 / 易变段。gated 时易变段整体清空，只留稳定段 + 零命中文案。
    // 1.1.1：skipVolatileWhenNoHit=true 且本轮对易变段零命中（rawTopScore===0）时，
    //   也不放易变段——"跟记忆无关的问题"就别把检索结果塞进 prompt（静默背景仍保留）。
    const volatileSkipped = skipVolatileWhenNoHit && !queryOverlapsItems(opts && opts.query, items) && volatileRanked.length > 0;
    if (!gated && !volatileSkipped) {
      for (const { it, score } of volatileRanked) {
        const line = renderLine(it, maxFactRenderChars);
        if (estimateTokens(parts.concat(line).join("\n")) <= contentCap) {
          parts.push(line);
          chosen.push({ id: it.id, text: it.text, score, volatility: "volatile", key: it.key });
        }
      }
    }

    // P0.2 注入侧折叠：同 key 多条只出最新一条，其余折叠为「另 N 条同类已折叠」。
    // 仅 foldInject 时生效（缺省关 → 跳过，字节回归一致）。折叠标记紧跟代表行之后插入，
    // 位于稳定段内的折叠标记仍计入稳定区（stablePartCount 同步推进）。
    if (foldInject) {
      const foldTotal = new Map();
      for (const it of items) foldTotal.set(it.key, (foldTotal.get(it.key) || 0) + 1);
      const emitted = new Set();
      const newParts = [parts[0]];
      const newChosen = [];
      let spc = 1; // 稳定区在 newParts 中的结束下标（含 base）
      for (let i = 1; i < parts.length; i++) {
        const c = chosen[i - 1];
        newParts.push(parts[i]);
        if (c) newChosen.push(c);
        if (c && c.volatility === "stable") spc = newParts.length;
        if (c && foldTotal.get(c.key) > 1 && !emitted.has(c.key)) {
          emitted.add(c.key);
          const n = foldTotal.get(c.key) - 1;
          const note = `- （另 ${n} 条同类已折叠）`;
          newParts.push(note);
          newChosen.push({ id: `fold:${c.key}`, text: note, score: 0, volatility: "fold", key: c.key });
          if (c.volatility === "stable") spc = newParts.length;
        }
      }
      parts.length = 0; for (const p of newParts) parts.push(p);
      chosen.length = 0; for (const c of newChosen) chosen.push(c);
      stablePartCount = spc;
    }

    // P0.2 治理计数：deduped = 归一化键去重剔除的条数（恒等于 items - 不同键数）；
    //   folded = 折叠开启时折叠的条数（与 deduped 同口径，关闭时为 0）。
    const deduped = items.length - groups.size;
    const folded = foldInject ? deduped : 0;

    // 追加边界声明。预留已算过；仍有舍入差异时从尾部回退（parts 与 chosen 同步），保证放得下。
    while (parts.length > 1 && estimateTokens(parts.join("\n") + boundaryBlock) > budget) {
      parts.pop();
      chosen.pop();
    }
    // 回退可能切进稳定段：按保留的稳定行数重算 stableChars，避免稳定前缀混入易变/边界。
    stableChars = parts.slice(0, Math.min(stablePartCount, parts.length)).join("\n").length;
    const contentLen = parts.join("\n").length; // 稳定 + 易变（不含边界声明）
    if (estimateTokens(parts.join("\n") + boundaryBlock) <= budget) parts.push(boundaryBlock.slice(1));

    const text = parts.join("\n");
    const stableText = text.slice(0, stableChars);
    const volatileText = text.slice(stableChars, contentLen); // 不含边界声明
    return {
      text,
      items: (() => {
        // 1.1.0-rc4（minBudget 缺口）：items 必须恒等于候选数 —— 入选项也要登记（dropped:false），
        // 未入选的稳定段/易变段候选登记为 dropped:true,reason:'budget'。
        const pickedIds = new Set(chosen.map((c) => c && c.id));
        // 注意：必须保留原有字段（尤其 text）—— 既有断言/宿主按 items[i].text 取值。
        const list = chosen.map((c) => ({
          ...c, tokens: estimateTokens(renderLine(c, maxFactRenderChars)), dropped: false, reason: null,
        }));
        for (const it of stableGroups) {
          if (pickedIds.has(it.id)) continue;
          list.push({ id: it.id, text: it.text, key: it.key, tokens: estimateTokens(renderLine(it, maxFactRenderChars)), score: 0, volatility: "stable", dropped: true, reason: "budget" });
        }
        for (const { it, score } of volatileRanked) {
          if (pickedIds.has(it.id)) continue;
          list.push({ id: it.id, text: it.text, key: it.key, tokens: estimateTokens(renderLine(it, maxFactRenderChars)), score, volatility: "volatile", dropped: true, reason: "budget" });
        }
        return list;
      })(),
      meta: {
        // 1.1.0-rc3 P0-c：无论成功与否都报「头部 + 最便宜一条」所需预算，宿主可据此判断还能塞几条。
        minBudgetTokens,
        // 1.1.1：宿主可据此判断本轮是否走了「静默背景 / 跳过检索」
        silent: silentMemory,
        volatileSkipped,
        gated,
        stableBytes: Buffer.byteLength(stableText, "utf8"),
        // gated 时易变记忆为 0；边界声明不属于易变记忆，只计入 budgetUsed。
        volatileBytes: gated ? 0 : Buffer.byteLength(volatileText, "utf8"),
        budgetUsed: estimateTokens(text),
        stableChars,
        rawTopScore,
        secondScore,
        medianNonZero,
        separation,
        pTop,
        robustZ,
        m,
        factCount,
        gap,
        rareToken,
        rareDocs,
        gated,
        items: chosen.length,
        droppedNoise, folded, deduped, // P0.2 记忆治理计数
        attrCovered: requireAttributeCover ? attrCovered : undefined, // P1-2
        conflict: asOfConflicts.length > 0, // 阶段2：真冲突标记
        conflictKeys: asOfConflicts.map((c) => c.key), // 阶段2：冲突键（机器可读）
        // 阶段3：编译耗时 + 索引缓存可观测
        ms: elapsMs(),
        cache: cacheStatus,
        cacheReason,
        cacheEmitDiag: (idxResult && idxResult.emitDiag) || false,
        cacheFacts,
        cacheEntries,
        cacheRssMB,
        cacheHeapUsedMB,
        cacheBaselineMB,
        // 本轮（T0/T1 检索剪枝）观测：候选规模 / 跳过 gram 数 / 启用策略。
        strategy: idxStrategy,
        pruned: idxDiag.pruned || 0,
        candidates: idxDiag.candidates || 0,
        // 债2：asOf 覆盖率（仅当显式传入合法 asOf 时出现；缺省路径不出现 → 与阶段1逐字节一致）
        ...(asOfValid && asOfCoverage
          ? {
              asOfCoverage: Number((asOfCoverage.dated / asOfCoverage.total).toFixed(3)),
              asOfUndated: asOfCoverage.undatedKept,
            }
          : {}),
      },
    };
  } catch {
    // 不抛（硬约束），但用 error 标记让适配器能退回旧 blob，而不是静默注入空串。
    return { text: "", items: [], meta: { ...emptyMeta, error: true, ms: elapsMs() } };
  }
}
