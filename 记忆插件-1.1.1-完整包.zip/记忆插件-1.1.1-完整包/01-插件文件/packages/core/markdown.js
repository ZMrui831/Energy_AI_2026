// markdown.js — DSH 长期记忆的「Markdown 视图」存储逻辑（从 lib/store.js + lib/index.js 行为等价搬入 core）。
//
// 为什么在 core：持久化 / 去重 / 重复合并 / 清理迁移 / 遗忘清单 是**存储逻辑**，按 M1「内核厚、
// 适配器薄」必须落在 core，适配器（lib/index.js）只做 Cordis 事件映射 + diag + systemPrompt 注册。
// 这一层是**面向 DSH 现有 ~/.dsh/local-ai-memory.md 格式**的兼容视图；与 store-jsonl.js 的通用
// 四元组真相源并存：JSONL 是权威内核，Markdown 是 DSH 侧的人读/注入镜像。
//
// 硬约束：
//   - 只依赖 node:fs / node:os / node:path + 同目录 compile.js（token 估算）。禁止 cordis/electron/网络/第三方。
//   - 行为逐字对齐搬入前：Markdown 头、解析正则、注入 blob 文案与截断阈值、墓碑/去重语义全部不变，
//     否则 tools/plugin-harness.mjs（不可改）的 37 条断言会退化。
//   - 所有 IO 失败静默降级（读失败当空、写失败返回 false），绝不抛。

import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { estimateTextTokens, memoryTargetTokens, isNoiseFact, stableKey, noiseKindOf } from "./compile.js";
// 阶段2 写入侧（可选）：替换句式落盘时打 supersedes/supersededBy 标记，供读侧/未来审计使用。
// 仅当 opts.emitTemporalMarkers===true 时生效；默认关闭 → 序列化逐字不变 → plugin-harness 不退化。
import { factKey, parseFactTemporal } from "./temporal.js";

// 生产注入的编译入口（BM25 检索 + 稳定/易变分段 + 拒答门）。适配器只从这里取，避免直接依赖 compile。
export { compileFromEntries } from "./compile.js";
// P0.2 记忆治理：噪声识别 + 归一化键（写入侧过滤/去重与注入侧共用）。
export { isNoiseFact, stableKey } from "./compile.js";

const MEMORY_HEADER = "# Local AI Memory\n\n";

// ── 1.0.1 P0-2：文件头契约 ──────────────────────────────────────────────────
// 为什么要有头：两个外部宿主（DSH 系与非 DSH 系）都吃过「格式悄悄变了、宿主解析静默失效」的亏。
// 头写在**第一行**，是 HTML 注释 —— 不认识它的宿主当注释跳过（老解析器零影响），
// 认识它的宿主可以据此判版本/命名空间/最后写入时间，而不必猜。
//
// 固定格式（字段顺序写死，宿主可按 `|` 切分）：
//   <!-- dsh-local-memory | schema: 1 | namespace: <ns> | updatedAt: <iso> | lastWrite: <iso> <count> -->
// 可选追加字段（只在有意义时出现）：
//   lastError: <iso> <code>   上次写入失败（成功写入后清除）
//   seenCount: <n>            重复事实累计次数（P2 去重标记开启时才有）
//
// 硬约束：**读取必须容忍头缺失/畸形** —— 1.0.0 及更早的文件没有头，解析结果必须与有头文件一致
// （条目数/事实数不变）。所以头不参与条目解析，只是第一行注释。
export const FILE_SCHEMA = 1;

/**
 * 1.0.2：手写裸事实（无 `## [generated …]` 块头）被收养进这个隐式条目。
 * 存在理由：审计 E5b 证实旧实现会静默忽略并在下次整文件重写时**销毁**这些行。
 * 用固定 sessionId 是为了「同一个文件里的裸事实每次都归到同一条目」，避免越写越碎。
 */
export const LOOSE_SESSION_ID = "__loose__";
export const LOOSE_TITLE = "手写事实";

const HEADER_LINE_RE = /^<!--\s*dsh-local-memory\s*\|([\s\S]*?)-->/;

/**
 * 生成文件头行（不含换行）。
 * @param {{namespace?:string, updatedAt?:string, lastWriteAt?:string, lastWriteCount?:number,
 *          lastErrorAt?:string, lastErrorCode?:string, seenCount?:number}} [info]
 */
export function buildFileHeader(info = {}) {
  const i = info && typeof info === "object" ? info : {};
  const ns = typeof i.namespace === "string" && i.namespace ? i.namespace : "dsh";
  const parts = [
    "dsh-local-memory",
    `schema: ${FILE_SCHEMA}`,
    `namespace: ${ns}`,
    `updatedAt: ${typeof i.updatedAt === "string" && i.updatedAt ? i.updatedAt : new Date().toISOString()}`,
  ];
  const lwAt = typeof i.lastWriteAt === "string" && i.lastWriteAt ? i.lastWriteAt : "";
  const lwN = Number.isFinite(i.lastWriteCount) ? Math.max(0, Math.trunc(i.lastWriteCount)) : 0;
  if (lwAt) parts.push(`lastWrite: ${lwAt} ${lwN}`);
  if (typeof i.lastErrorAt === "string" && i.lastErrorAt && typeof i.lastErrorCode === "string" && i.lastErrorCode) {
    parts.push(`lastError: ${i.lastErrorAt} ${i.lastErrorCode}`);
  }
  if (Number.isFinite(i.seenCount) && i.seenCount > 0) parts.push(`seenCount: ${Math.trunc(i.seenCount)}`);
  return `<!-- ${parts.join(" | ")} -->`;
}

/**
 * 解析文件头（缺失/畸形时 ok=false，其余字段按缺省返回，绝不抛）。
 * @param {string} raw 文件全文
 * @returns {{ok:boolean, schema:number|null, namespace:string|null, updatedAt:string|null,
 *            lastWriteAt:string|null, lastWriteCount:number|null,
 *            lastErrorAt:string|null, lastErrorCode:string|null, seenCount:number|null, raw:string|null}}
 */
export function parseFileHeader(raw) {
  const out = {
    ok: false, schema: null, namespace: null, updatedAt: null,
    lastWriteAt: null, lastWriteCount: null,
    lastErrorAt: null, lastErrorCode: null, seenCount: null, raw: null,
  };
  try {
    if (typeof raw !== "string" || !raw) return out;
    // 只认第一行的头（此前可能有 BOM）。
    const firstLine = raw.replace(/^\uFEFF/, "").split("\n", 1)[0] || "";
    const m = HEADER_LINE_RE.exec(firstLine);
    if (!m) return out;
    out.raw = m[0];
    const fields = String(m[1] || "").split("|").map((s) => s.trim()).filter((s) => s);
    for (const f of fields) {
      const c = f.indexOf(":");
      if (c < 0) continue;
      const k = f.slice(0, c).trim();
      const v = f.slice(c + 1).trim();
      if (k === "schema") { const n = Number(v); if (Number.isFinite(n)) out.schema = n; }
      else if (k === "namespace") out.namespace = v || null;
      else if (k === "updatedAt") out.updatedAt = v || null;
      else if (k === "lastWrite") {
        const sp = v.indexOf(" ");
        if (sp > 0) { out.lastWriteAt = v.slice(0, sp); const n = Number(v.slice(sp + 1)); if (Number.isFinite(n)) out.lastWriteCount = n; }
        else { out.lastWriteAt = v; }
      } else if (k === "lastError") {
        const sp = v.indexOf(" ");
        if (sp > 0) { out.lastErrorAt = v.slice(0, sp); out.lastErrorCode = v.slice(sp + 1) || null; }
        else out.lastErrorAt = v;
      } else if (k === "seenCount") { const n = Number(v); if (Number.isFinite(n)) out.seenCount = n; }
    }
    out.ok = out.schema !== null && out.namespace !== null;
    return out;
  } catch {
    return out;
  }
}

/** 默认记忆文件路径（~/.dsh/local-ai-memory.md）。仅计算路径，不读写。 */
export function defaultMemoryFile() {
  return path.join(os.homedir(), ".dsh", "local-ai-memory.md");
}

/**
 * 从 Markdown 文件解析条目数组（只识别 `## [generated ...]` 头与 `- ` 事实行）。
 * 1.0.1：额外返回 `header`（文件头解析结果）。头缺失/畸形 → header.ok=false，条目解析照常
 * （头是第一行注释，本来就不参与解析）—— 老文件零影响。
 */
export function readMemoryFile(filePath) {
  let raw = "";
  try {
    raw = fs.readFileSync(filePath, "utf8");
  } catch {
    return { entries: [], raw: "", header: parseFileHeader("") };
  }
  const entries = [];
  let current = null;
  const loose = [];           // 裸事实行（无 `## [generated …]` 块头）—— 1.0.2 起收养，不再静默丢弃
  const lines = raw.split("\n");
  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.startsWith("## [generated ")) {
      const m = /^## \[generated (\d+)\] ([^ ]+) (.+)$/.exec(trimmed);
      if (m) {
        current = {
          ts: Number(m[1]),
          sessionId: m[2],
          title: m[3],
          facts: [],
        };
        entries.push(current);
        continue;
      }
    }
    if (trimmed.startsWith("- ")) {
      if (current) current.facts.push(trimmed.slice(2));
      else loose.push(trimmed.slice(2));   // 落在任何块头之前 = 用户手写的自由事实
    }
  }
  const header = parseFileHeader(raw);
  // 1.0.2 P0 fix（审计 E5b）：手写把 `- 用户: …` 直接放在 `# Local AI Memory` 下时，
  // 旧实现会**静默忽略**这些行，并在下一次写入整文件重写时把它们覆盖掉（真实数据丢失）。
  // 现在收养为一个隐式条目（sessionId `__loose__`），写入时按正常块落盘；header.looseFacts
  // 记录收养条数，供 apply() 打一次告警。**块头齐全的文件行为完全不变**（loose 恒为空）。
  if (loose.length > 0) {
    entries.push({ ts: 0, sessionId: LOOSE_SESSION_ID, title: LOOSE_TITLE, facts: loose });
    header.looseFacts = loose.length;
  } else {
    header.looseFacts = 0;
  }
  return { entries, raw, header };
}

/**
 * 将条目序列化为 Markdown（不带头时与搬入前 lib/store.js **逐字一致**）。
 * @param {object[]} entries
 * @param {{header?: object|false}} [opts]
 *        header = false 或省略 → 不写文件头（1.0.0 字节，供兼容比对 / 淘汰计量用）；
 *        header = {namespace,updatedAt,lastWriteAt,lastWriteCount,...} → 第一行写契约头。
 */
export function serializeMemoryFile(entries, opts = {}) {
  const h = opts && typeof opts === "object" ? opts.header : undefined;
  const head = h && h !== false ? buildFileHeader(h) + "\n" : "";
  const parts = [head + MEMORY_HEADER];
  for (const e of entries) {
    parts.push(`## [generated ${Number(e.ts)}] ${e.sessionId} ${e.title}\n`);
    for (const f of e.facts) parts.push(`- ${f}\n`);
    parts.push("\n");
  }
  return parts.join("");
}

/** 合并(或新建)一个条目。同 sessionId 则追加 facts 去重。
 *  @param {object} [opts] 阶段2：{ emitTemporalMarkers?:boolean } 默认关闭；
 *         P0.2：{ dedup?:boolean } 默认关闭（true 时改用归一化键去重，避免「X 现在是 Y」式
 *         同义改写被当新事实反复追加；关闭时逐字不变 → plugin-harness 不退化）。 */
export function upsertMemoryEntry(entries, sessionId, title, facts, opts = {}) {
  const next = [...entries];
  if (!Array.isArray(facts) || facts.length === 0) return next;
  const dedup = opts.dedup === true;
  const idx = next.findIndex((e) => e.sessionId === sessionId);
  if (idx >= 0) {
    const merged = [...next[idx].facts];
    const keys = dedup ? new Set(merged.map((f) => stableKey(f))) : null;
    for (const f of facts) {
      if (dedup) {
        const k = stableKey(f);
        if (keys.has(k)) continue;
        keys.add(k);
        merged.push(f);
      } else if (!merged.includes(f)) {
        merged.push(f);
      }
    }
    next[idx] = {
      ...next[idx],
      ts: Date.now(),
      title: title || next[idx].title,
      facts: merged,
    };
  } else {
    next.push({ ts: Date.now(), sessionId, title: title || sessionId, facts: [...facts] });
  }
  if (opts.emitTemporalMarkers === true) return decorateReplacement(next, sessionId, facts);
  return next;
}

// ── 1.0.1 P2：重复事实标记 `^duplicate-of <ref>` ─────────────────────────────
// 诉求方 dsh-orb P2-1：同 key 的事实再次出现时**不新增行**（堆行会让稳定段膨胀、重复注入），
// 而是在已有行尾追加标记，让"去重"可审计 —— 而不是像现在这样静默丢弃、事后查不到。
// 标记坐标 ref = `<sessionId>#<turn>`（重复出现的那一轮），可据此回溯来源。
// 读取侧：stripDupMarkers() 把它剥掉后再算归一化键 / 进注入，故**有标记不改变检索与去重语义**。
// 实现放在 compile.js（去重键的单一定义处），这里只再导出，避免 markdown↔compile 循环依赖。
export { stripDupMarkers } from "./compile.js";
import { stripDupMarkers } from "./compile.js";

/** 带标记行的归一化键：先剥标记再算，保证「加了标记仍被认为同一条事实」。 */
export function dupAwareKey(text) {
  return stableKey(stripDupMarkers(text));
}

/**
 * 给**已存在**的同 key 事实行追加 `^duplicate-of <ref>`；不新增行。
 * @param {object[]} entries
 * @param {string} fact 重复出现的事实原文
 * @param {string} ref 坐标串（如 `session-abc#3`）
 * @returns {{entries: object[], marked: boolean}}
 */
export function markDuplicateFact(entries, fact, ref) {
  const list = Array.isArray(entries) ? entries : [];
  const key = stableKey(String(fact || ""));
  if (!key || !ref) return { entries: list, marked: false };
  const out = list.map((e) => ({ ...e, facts: Array.isArray(e.facts) ? [...e.facts] : [] }));
  let marked = false;
  for (const e of out) {
    for (let i = 0; i < e.facts.length; i++) {
      if (dupAwareKey(e.facts[i]) !== key) continue;
      if (e.facts[i].includes(`^duplicate-of ${ref}`)) continue; // 同一坐标不重复打
      e.facts[i] = `${e.facts[i]}^duplicate-of ${ref}`;
      marked = true;
    }
  }
  return { entries: out, marked };
}

// 阶段2 写入侧：新事实是"替换"句式时，给新事实打 <!--supersedes:旧值-->，
// 给同 subject-key、不同值的既有事实打 <!--supersededBy:新值-->。零 LLM，纯规则；
// 标记是 HTML 注释，旧代码（slice(2)）读新文件不会抛、不会丢事实（向后兼容）。
const REPLACEMENT_MARKER_RE = /(改成|改为|更新为|更新成|变更为|现在代号|旧代号|已更新|变成|变为)/;
function decorateReplacement(entries, sessionId, newFacts) {
  const out = entries.map((e) => ({ ...e, facts: [...e.facts] }));
  for (const f of newFacts) {
    if (!REPLACEMENT_MARKER_RE.test(f)) continue;
    const np = parseFactTemporal(f);
    if (!np.value) continue;
    const nkey = np.key;
    // 找到 newFacts 中 f 所在条目，给 f 打 supersedes（指向被替换旧值）。
    const target = out.find((e) => e.facts.includes(f));
    let markedF = f;
    for (const e of out) {
      for (let i = 0; i < e.facts.length; i++) {
        const of = e.facts[i];
        if (of === f) continue;
        const op = parseFactTemporal(of);
        if (op.key === nkey && op.value && op.value !== np.value) {
          if (!of.includes("supersededBy")) {
            e.facts[i] = `${of}<!--supersededBy:${np.value}-->`;
          }
          if (!markedF.includes("supersedes")) {
            markedF = `${markedF}<!--supersedes:${op.value}-->`;
          }
        }
      }
    }
    if (markedF !== f && target) {
      const ti = target.facts.indexOf(f);
      if (ti >= 0) target.facts[ti] = markedF;
    }
  }
  return out;
}

/** 原子写：临时文件 + rename；失败静默返回 false。 */
export function atomicWrite(filePath, content) {
  const dir = path.dirname(filePath);
  try {
    fs.mkdirSync(dir, { recursive: true });
  } catch {
    return false;
  }
  const tmp = `${filePath}.${process.pid}.${Date.now().toString(36)}.tmp`;
  try {
    fs.writeFileSync(tmp, content, "utf8");
    fs.renameSync(tmp, filePath);
    return true;
  } catch {
    try {
      fs.unlinkSync(tmp);
    } catch {}
    return false;
  }
}

// ── 1.0.1 P0-4：并发写保护（Windows EPERM / EBUSY 真实存在）──────────────────
// 场景：DSH 宿主进程 + 另一个宿主进程（daemon / research-orb / 萌源）同时写同一个记忆文件。
// 没有锁时的失败形态不是「报错」，而是**静默丢事实**：两边各自 read → 各自 upsert → 各自 rename，
// 后写者整份覆盖先写者。所以写必须串行化，且锁内必须**重新读**最新内容（read-modify-write）。
//
// 机制（全部同步，不引入任何第三方）：
//   · lockfile `<file>.lock`，内容 {pid, ts}
//   · 空闲锁：flag:'wx' 原子创建（已存在 → EEXIST）；抢占/回收：tmp + rename 原子替换（绝不就地写、绝不留「锁短暂消失」窗口）
//   · 陈旧锁：ts 距今 > 30s（默认）视为崩溃残留 → 抢占
//   · 锁文件「存在但读不到/解析失败」≠ 陈旧：1.1.0-rc9 起加 LOCK_GRACE_MS(默认1s) 宽限期，
//     宽限期内视为「占用中」交上层退避重试，绝不误删活锁（这是负载下静默丢事实的元凶，已修）
//   · 抢占成功后再回读自证 pid===self（F3）：两个进程同时抢占时只有一个真持有，另一个交上层重试，
//     杜绝「双持锁 → 并发 read-modify-write → 丢事实」
//   · 占用中：按 [15, 45, 120, 300]ms 退避重试（最多 3 遍）；仍失败 → 返回 {ok:false, error:{code:'EBUSY'|'lock-race-lost'|...}}
//   · 失败**绝不抛**：返回错误对象，由调用方记 lastWriteError 并静默降级（不影响会话）
//   · 锁在 finally 里释放；进程内重入（同 pid）视为已持有，避免自锁
export const LOCK_STALE_MS = 30_000;
export const WRITE_BACKOFF_MS = [15, 45, 120, 300];
// 退避序列的重复遍数：外部宿主同款退避值 [15,45,120,300]ms 不变，但只走一遍（合计 480ms）
// 在 Windows 上不够用 —— 实测 2 进程 × 100 次写入时约 2~5% 的取锁因瞬时共享冲突（EBUSY）
// 四连失败，直接丢事实。多进程竞争是**常态**不是异常，故允许最多 3 遍（合计 ≤1.44s），
// 并在每步加抖动（±35%）打散两个进程的同步重试节奏（否则容易撞成周期性互等）。
export const WRITE_BACKOFF_PASSES = 3;

/** 同步睡眠（不引入 timers/promises；Atomics.wait 在 Worker/主线程都可用）。 */
function sleepSync(ms) {
  try {
    if (!Number.isFinite(ms) || ms <= 0) return;
    const buf = new Int32Array(new SharedArrayBuffer(4));
    Atomics.wait(buf, 0, 0, Math.trunc(ms));
  } catch {
    // 兜底：忙等到时（Atomics 不可用时退化为有界自旋）
    const end = Date.now() + Math.max(1, Math.trunc(ms));
    while (Date.now() < end) { /* spin */ }
  }
}

// 锁文件不可解析时的宽限期（毫秒）：宽限期内视为「占用中」而非「陈旧」，避免误抢活锁。
// 改为 0 可让 R-a 变异测试必红 —— 证明宽限期真实生效（见 tools/verify-lock-corrupt.mjs）。
export let LOCK_GRACE_MS = 1_000;

/** 锁文件 stat（不存在/无权限 → null）。 */
function statLock(lockPath) {
  try { return fs.statSync(lockPath); } catch { return null; }
}

/**
 * 读取锁文件，返回三态：
 *   { state: 'absent' }            —— 文件不存在（视为已释放）
 *   { state: 'ok', info }          —— 解析成功
 *   { state: 'unreadable' }        —— 存在但读不到/解析失败（半截写入或损坏）
 * 关键：绝不再把「解析失败」等同于「陈旧」——那是负载下误抢活锁、导致并发丢写的元凶。
 */
function readLockInfo(lockPath) {
  try {
    const raw = fs.readFileSync(lockPath, "utf8");
    const o = JSON.parse(raw);
    return o && typeof o === "object" ? { state: "ok", info: o } : { state: "unreadable" };
  } catch (e) {
    if ((e && e.code) === "ENOENT") return { state: "absent" };
    return { state: "unreadable" };
  }
}

/** 该 pid 是否还活着（0 信号探测；取不到一律按"活着"处理，绝不误抢）。 */
function pidAlive(pid) {
  try {
    if (!Number.isFinite(pid) || pid <= 0) return true;
    process.kill(pid, 0);
    return true;
  } catch (e) {
    // EPERM = 进程存在但无权发信号；ESRCH = 不存在
    return (e && e.code) === "EPERM";
  }
}

/**
 * F1 原子发布锁内容：先写临时文件，再 rename 到锁路径。
 * rename 在 Windows 上对同目录是原子替换（MoveFileExW + MOVEFILE_REPLACE_EXISTING），
 * 因此任何时刻读到的锁文件要么不存在、要么是一份完整的 JSON —— 杜绝「半截锁」被误判陈旧。
 * 抢占/回收场景下用它替换别人的锁（不先 unlink，避免制造「锁短暂消失」的窗口）。
 * @returns {{ok:boolean, code?:string}}
 */
function writeLockAtomicReplace(lockPath, payload) {
  const tmp = `${lockPath}.${process.pid}.${Date.now().toString(36)}.tmp`;
  try {
    fs.writeFileSync(tmp, payload, "utf8");
    for (let i = 0; i < 3; i++) {
      try {
        fs.renameSync(tmp, lockPath);
        return { ok: true };
      } catch (e) {
        const c = (e && e.code) || "EIO";
        // 目标被占用（共享冲突/删除挂起）→ 短暂退避后重试；其余错误直接放弃，交给上层退避
        if (c === "EEXIST" || c === "EPERM" || c === "EBUSY") { sleepSync(2); continue; }
        return { ok: false, code: c };
      }
    }
    return { ok: false, code: "EIO" };
  } catch (e) {
    return { ok: false, code: (e && e.code) || "EIO" };
  } finally {
    try { fs.unlinkSync(tmp); } catch {}
  }
}

/**
 * 尝试获取锁（一次尝试，不重试）。
 * 返回值 {ok, code}；ok=true 表示「本调用已确认自己持有锁」（含 F3 自证）。
 * 任何判定为「占用中 / 抢不到 / 竞态落败」的情形都返回 ok:false，由上层退避重试，
 * **绝不**在没确认持有的情况下返回 ok:true —— 这是消除「双持锁 → 并发丢写」的核心约束。
 * @param {string} lockPath
 * @param {number} [staleMs]
 * @param {{graceMs?:number}} [opts]
 */
export function tryAcquireLock(lockPath, staleMs = LOCK_STALE_MS, opts = {}) {
  const payload = JSON.stringify({ pid: process.pid, ts: Date.now() });
  const staleLimit = Number.isFinite(staleMs) && staleMs > 0 ? staleMs : LOCK_STALE_MS;
  const graceMs = Number.isFinite(opts && opts.graceMs) && (opts.graceMs) >= 0 ? opts.graceMs : LOCK_GRACE_MS;
  // 1) 快速路径：锁空闲 → 原子创建（flag:'wx' 保证「已存在→EEXIST」，内容单写即完整）
  try {
    fs.writeFileSync(lockPath, payload, { flag: "wx" });
    return { ok: true, code: "created" };
  } catch (e) {
    // 只有「已存在/共享冲突」才进入判新鲜度分支；其他硬错误直接放弃
    const code = (e && e.code) || "EIO";
    if (code !== "EEXIST" && code !== "EBUSY" && code !== "EPERM" && code !== "EACCES") return { ok: false, code };
  }
  // 2) 已存在/瞬态冲突：解析当前锁
  const existing = readLockInfo(lockPath);
  if (existing.state === "ok" && existing.info.pid === process.pid) return { ok: true, code: "self" };
  if (existing.state === "absent") {
    // 竞态：上一步 wx 与这里之间锁被释放 → 再尝试一次原子创建
    try { fs.writeFileSync(lockPath, payload, { flag: "wx" }); return { ok: true, code: "created-race" }; }
    catch (e2) { return { ok: false, code: (e2 && e2.code) || "EIO" }; }
  }
  // 3) 存在但不可解析：宽限期内视为「占用中」（别人正在写/刚写完），交给上层重试；
  //    持续超过宽限期仍坏 → 按损坏锁回收（lock-reclaim-corrupt）。
  //    注意：graceMs=0 表示「无宽限」（变异测试用），必须直接走回收；不能用 age<0 的边界误判占用。
  if (existing.state === "unreadable") {
    const st = statLock(lockPath);
    const mtime = st ? st.mtimeMs : 0;
    if (graceMs > 0 && Date.now() - mtime < graceMs) return { ok: false, code: "lock-unreadable" };
    // 落到下方「回收」分支，code 会被标记为 lock-reclaim-corrupt
  }
  // 4) 陈旧 / 持有者已死 / 损坏超宽限 → 回收（抢占）
  const info = existing.state === "ok" ? existing.info : null;
  const age = info && Number.isFinite(info.ts) ? Date.now() - info.ts : Number.POSITIVE_INFINITY;
  const holderDead = info && Number.isFinite(info.pid) ? !pidAlive(info.pid) : false;
  if (age < staleLimit && !holderDead) {
    // 持有者确实活着且锁新鲜 → 占用中，绝不动它
    return { ok: false, code: "EBUSY" };
  }
  const reclaimCode = holderDead ? "dead-holder-reclaimed"
    : existing.state === "unreadable" ? "lock-reclaim-corrupt" : "stale-reclaimed";
  const acq = writeLockAtomicReplace(lockPath, payload);
  if (!acq.ok) return acq; // 抢占瞬间被别人抢先（或共享冲突）→ 当作占用，交给上层退避
  // F3 自证持有：抢占（覆盖写）成功后立刻回读，确认 pid === 自己；
  // 不匹配说明两个进程同时「抢占成功」——本次视为没拿到锁，交给上层重试（杜绝双持锁）。
  const verify = readLockInfo(lockPath);
  if (verify.state !== "ok" || verify.info.pid !== process.pid) {
    return { ok: false, code: "lock-race-lost" };
  }
  return { ok: true, code: reclaimCode };
}

export function releaseLock(lockPath) {
  try {
    const lock = readLockInfo(lockPath);
    const mine = lock.state === "ok" && lock.info.pid === process.pid;
    if (lock.state === "absent" || mine) fs.unlinkSync(lockPath);
    return true;
  } catch {
    return false;
  }
}

/**
 * 在锁内执行一次同步操作（典型用途：read-modify-write）。
 * @param {string} filePath 被保护的文件（锁文件 = filePath + ".lock"）
 * @param {() => any} fn 锁内执行；抛错会被捕获并返回 ok:false（绝不外抛）
 * @param {{staleMs?:number, backoff?:number[], attempts?:number}} [opts]
 * @returns {{ok:boolean, value?:any, error?:{code:string,message?:string}, attempts:number}}
 */
export function withFileLock(filePath, fn, opts = {}) {
  const o = opts && typeof opts === "object" ? opts : {};
  const lockPath = `${filePath}.lock`;
  const staleMs = Number.isFinite(o.staleMs) && o.staleMs > 0 ? o.staleMs : LOCK_STALE_MS;
  const backoff = Array.isArray(o.backoff) && o.backoff.length > 0 ? o.backoff : WRITE_BACKOFF_MS;
  const passes = Number.isFinite(o.passes) && o.passes > 0 ? Math.trunc(o.passes) : WRITE_BACKOFF_PASSES;
  const maxAttempts = backoff.length * passes;
  try {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
  } catch {}
  let attempts = 0;
  for (;;) {
    const acq = tryAcquireLock(lockPath, staleMs, o);
    if (acq.ok) {
      try {
        const value = typeof fn === "function" ? fn() : undefined;
        return { ok: true, value, attempts };
      } catch (e) {
        return { ok: false, error: { code: String((e && e.code) || "ETHROW"), message: String((e && e.message) || e) }, attempts };
      } finally {
        releaseLock(lockPath);
      }
    }
    if (attempts >= maxAttempts) {
      return { ok: false, error: { code: acq.code || "EBUSY" }, attempts };
    }
    // 抖动 ±35%：两个进程若用完全相同的节奏重试，会周期性地同时醒来、同时抢、同时失败。
    const base = backoff[attempts % backoff.length];
    sleepSync(base * (0.65 + Math.random() * 0.7));
    attempts++;
  }
}

/**
 * 带锁的一次「读-改-写」：锁内重新读最新内容，交给 mutate(entries, raw) 返回新条目数组，
 * 再序列化 + tmp+rename 落盘。绝不用调用方传入的**旧快照**直接覆盖磁盘（那是丢事实的根因）。
 * @param {string} filePath
 * @param {(entries: object[], header: object) => object[]|null|undefined} mutate 返回新条目（null/undefined = 不写）
 * @param {{header?:object|false, staleMs?:number, backoff?:number[], namespace?:string}} [opts]
 * @returns {{ok:boolean, written:boolean, error?:{code:string,message?:string}, entries?:object[]}}
 */
export function readModifyWriteLocked(filePath, mutate, opts = {}) {
  const o = opts && typeof opts === "object" ? opts : {};
  const res = withFileLock(filePath, () => {
    const r = readMemoryFile(filePath);
    const next = typeof mutate === "function" ? mutate(r.entries, r.header) : null;
    if (!next || !Array.isArray(next)) return { written: false, entries: r.entries };
    const content = serializeMemoryFile(next, { header: o.header });
    const ok = atomicWrite(filePath, content);
    if (!ok) {
      const e = new Error("atomicWrite returned false");
      e.code = "EIO";
      throw e;
    }
    return { written: true, entries: next };
  }, o);
  if (!res.ok) return { ok: false, written: false, error: res.error, attempts: res.attempts };
  const v = res.value || {};
  return { ok: true, written: !!v.written, entries: v.entries || [], attempts: res.attempts };
}

// ── 事实文本处理（从 lib/index.js 搬入）─────────────────────────────────────

function clip(text, max) {
  const t = String(text || "").trim();
  if (!max || t.length <= max) return t;
  return `${t.slice(0, max)}…（已截断）`;
}

/** 本轮要落盘的事实：用户说了什么 + 助手答了什么。 */
export function buildTurnFacts(userText, assistantText, cfg) {
  const max = cfg.maxFactChars || 400;
  // P0.2 写入侧噪声过滤（默认关：cfg.filterNoise 未显式 true 时逐字不变 → plugin-harness 不退化）。
  const filterNoise = cfg && cfg.filterNoise === true;
  const facts = [];
  if (userText) {
    const f = `用户: ${clip(userText, max)}`;
    if (!filterNoise || !isNoiseFact(f)) facts.push(f);
  }
  if (assistantText && facts.length < (cfg.maxFactsPerTurn || 2)) {
    const f = `助手: ${clip(assistantText, max)}`;
    // 助手回执：除非携带来自用户的事实更新，否则不入库（默认关，需 cfg.filterNoise 开启）。
    if (!filterNoise || !isNoiseFact(f)) facts.push(f);
  }
  return facts.filter((f) => f.length > 4);
}

/**
 * P1 写入侧治理（插件默认开，cfg.writeGovernance !== false）：一轮候选事实过三道闸。
 * 纯函数，不读写文件；seenKeys 由调用方持有并跨轮累计（apply 时用加载到的全部事实做种子，
 * 因此跨重启也认已见过的同义事实）。返回 { facts, skipped, seenKeys }：
 * 1.0.1：传 `opts.droppedDupes`（数组）可收集被判为重复而丢弃的事实原文 —— 供 P2 的
 * `^duplicate-of` 标记回写（去重不再静默）。归一化键用 dupAwareKey（先剥重复标记）。
 *   skipped.ack  = 纯助手回执（`助手:` 且无「已更新/现在是/改为」类更新语义）被丢
 *   skipped.greet= 纯寒暄/致谢/垃圾（用户或助手侧）被丢
 *   skipped.dup  = 与已见事实归一化（NFKC+小写+空白折叠）后重复被丢
 * 带更新语义的助手事实（「已更新：X 现在是 Y」）按设计保留 —— 那是用户事实的复述确认。
 */
export function governTurnFacts(facts, opts = {}) {
  const seen = opts && opts.seenKeys instanceof Set ? opts.seenKeys : new Set();
  const out = [];
  const skipped = { ack: 0, greet: 0, dup: 0 };
  for (const f of Array.isArray(facts) ? facts : []) {
    if (typeof f !== "string" || !f.trim()) continue;
    if (isNoiseFact(f)) {
      // 纯寒暄/致谢（任一侧）→ greet；其余噪声（实机样本几乎都是助手回执/指令复述）→ ack。
      if (noiseKindOf(f) === "greet") skipped.greet++;
      else skipped.ack++;
      continue;
    }
    const k = dupAwareKey(f);
    if (seen.has(k)) { skipped.dup++; if (Array.isArray(opts.droppedDupes)) opts.droppedDupes.push(f); continue; }
    seen.add(k);
    out.push(f);
  }
  return { facts: out, skipped, seenKeys: seen };
}

/**
 * P0-1（rc6）写入侧「事实性判定」：提问/请求/寒暄不得入库。
 *
 * 外部真机缺陷：turn/end 把用户消息整体当事实写，记忆文件里出现了「用户: 我叫什么？喜欢什么？」。
 * 规则（优先级从高到低，纯函数、无副作用）：
 *   ① 问句：以 ？/? 结尾 → 丢弃（question）。**这一条优先于白名单**——「我叫什么？」含「我叫」，
 *      若按"白名单优先"会照样入库，正是外部实测的缺陷；问号是比线索词更硬的信号。
 *   ② 疑问词（吗|呢|什么|多少|哪|谁|怎么|为什么|如何）且长度 ≤80 → 丢弃（question）。
 *   ③ 请求/指令开头（请|帮我|给我|看看|执行|运行|麻烦）→ 丢弃（question）。
 *   ④ 纯寒暄（复用 isNoiseFact / noiseKindOf）→ 丢弃（greet）。
 *   ⑤ 白名单（事实形状：我叫|我是|我的X是|我喜欢|我不喜欢|我住|我在X工作|我养|记住|代号|版本|
 *      发布于|改成|改为）→ 保留。
 *   ⑥ 两者都未命中 → **默认丢弃**（宁可漏记，不可污染），计数 unknown。
 * 返回 { facts, skipped:{question,unknown,greet} }；调用方把 skipped 合并进 memory written diag。
 */
const FACT_WHITELIST = [
  /我叫/, /我是/, /我的[^，。；\n]{0,12}是/, /我喜欢/, /我不喜欢/, /我住/,
  /我在[^，。；\n]{0,12}工作/, /我养/, /记住/, /代号/, /版本/, /发布于/, /改成/, /改为/,
];
const FACT_Q_WORDS = /吗|呢|什么|多少|哪|谁|怎么|为什么|如何/;
const FACT_REQ_PREFIX = /^(请|帮我|给我|看看|执行|运行|麻烦)/;

/**
 * 1.0.2（审计 D5d）："这条是不是提问" 的**唯一实现**。
 * 写入侧 filterFactful 与修复工具 memory-cli clean 共用它 ——
 * 否则会出现「写入拦住了问句、但清理工具删不掉」的口径分裂。
 */
export function isQuestionFact(text) {
  const body = String(text || "").replace(/^(用户|助手)[：:]\s*/, "").trim();
  if (!body) return false;
  if (/[?？]\s*$/.test(body)) return true;
  return FACT_Q_WORDS.test(body) && body.length <= 80;
}

export function filterFactful(facts) {
  const out = [];
  const skipped = { question: 0, unknown: 0, greet: 0 };
  for (const raw of Array.isArray(facts) ? facts : []) {
    if (typeof raw !== "string" || !raw.trim()) continue;
    const f = raw.trim();
    const body = f.replace(/^(用户|助手)[：:]\s*/, "").trim();
    if (!body) continue;
    if (isQuestionFact(f)) { skipped.question++; continue; }
    // 白名单先于"请求开头"判定：外部实测的合法事实常写成「请记住：我的邮箱是…」「帮我记住…」，
    // 它们的句首是请求词但内容是事实，必须留下。问句判定仍在其前（见上）。
    if (FACT_WHITELIST.some((re) => re.test(body))) { out.push(f); continue; }
    if (FACT_REQ_PREFIX.test(body)) { skipped.question++; continue; }
    if (isNoiseFact(body)) {
      if (noiseKindOf(body) === "greet") skipped.greet++;
      else skipped.unknown++;
      continue;
    }
    skipped.unknown++;
  }
  return { facts: out, skipped };
}

/**
 * P0.2 记忆治理：对一组条目做「写入侧清理」——剔除噪声事实 + 跨条目归一化去重。
 * 纯函数，不读写文件；返回清理后的条目与计数（供报告/验证）。
 *
 * 三件事：
 *   1) 噪声剔除：isNoiseFact 命中（助手回执/寒暄/垃圾）的事实不保留（droppedNoise）。
 *   2) 归一化去重：去标点/全半角/空白后相同即重复，保留最早一条（按条目+事实序），其余丢弃（deduped）。
 *      —— 顺带消解「整条重复条目」（同一事实集被写了两次）这类历史冗余。
 *   3) 清理后整条无事实的条目直接丢弃。
 *
 * 缺省 filterNoise=true、dedup=true（治理默认开）；调用方可按需关闭以做对比。
 * @param {{ts?:number, sessionId?:string, title?:string, facts?:string[]}[]} entries
 * @param {{filterNoise?: boolean, dedup?: boolean}} [opts]
 * @returns {{entries: object[], droppedNoise: number, deduped: number, removedEntries: number}}
 */
export function cleanMemoryEntries(entries, opts = {}) {
  const doNoise = opts.filterNoise !== false; // 默认 true
  const doDedup = opts.dedup !== false; // 默认 true
  const seenKey = new Set();
  const out = [];
  let droppedNoise = 0;
  let deduped = 0;
  let removedEntries = 0;
  for (const e of entries || []) {
    if (!e || !Array.isArray(e.facts)) { out.push(e); continue; }
    const kept = [];
    for (const f of e.facts) {
      if (doNoise && isNoiseFact(f)) { droppedNoise++; continue; }
      if (doDedup) {
        const k = stableKey(f);
        if (seenKey.has(k)) { deduped++; continue; }
        seenKey.add(k);
      }
      kept.push(f);
    }
    if (kept.length === 0) { removedEntries++; continue; }
    out.push({ ...e, facts: kept });
  }
  return { entries: out, droppedNoise, deduped, removedEntries };
}

/**
 * 旧版缺陷留下的垃圾事实：宿主注入的合成消息被当成了用户输入。
 * 只匹配 DSH 自己那两句固定开场（"Current runtime context. ..." 与审批变更提示）。
 * @returns 清理后的数组；没有任何改动时返回 null
 */
const POLLUTED_FACT = /^用户:\s*(Current runtime context\.|The approval policy changed from )/;

export function dropPollutedFacts(entries) {
  let changed = false;
  const out = [];
  for (const e of entries || []) {
    if (!e || !Array.isArray(e.facts)) { out.push(e); continue; }
    const facts = e.facts.filter((f) => !POLLUTED_FACT.test(String(f)));
    if (facts.length === e.facts.length) { out.push(e); continue; }
    changed = true;
    if (facts.length > 0) out.push({ ...e, facts }); // 整条都是垃圾就丢掉
  }
  return changed ? out : null;
}

/**
 * 读遗忘清单文件。每行一个 sessionId 或前缀；# 开头为注释，空行忽略，行首尾空白去掉。
 * 文件不存在 / 读失败 → 返回空数组（调用方据此跳过，绝不抛）。
 * @returns {string[]} 去重后的匹配串列表
 */
export function readForgetList(forgetPath) {
  let raw;
  try { raw = fs.readFileSync(forgetPath, "utf8"); } catch { return []; }
  const out = [];
  const seenLine = new Set();
  for (const line of String(raw).split(/\r?\n/)) {
    const t = line.trim();
    if (!t || t.startsWith("#")) continue;
    if (seenLine.has(t)) continue;
    seenLine.add(t);
    out.push(t);
  }
  return out;
}

// ── 墓碑旁挂文件 <memoryFile>.tomb（P0-2 淘汰）──────────────────────────────
// 与 .forget 同类：只是生命周期元数据（哪些事实被标记为不活跃），不是第二份事实真相源。
// 事实正文仍只存在于 Markdown；删掉 .tomb 里的行即可回滚。这里只做**哑 IO**，
// 行格式与解析全在 core/evict.js（parseTombstones / tombstoneLine），避免键定义分叉。

/**
 * 读墓碑文件原文（不解析）。文件不存在 / 读失败 → 返回空串（调用方据此跳过，绝不抛）。
 * @param {string} tombPath <memoryFile>.tomb
 * @returns {string}
 */
export function readTombstoneText(tombPath) {
  try { return fs.readFileSync(tombPath, "utf8"); } catch { return ""; }
}

/**
 * 追加墓碑行（TSV，见 evict.tombstoneLine）。失败静默返回 false，绝不抛。
 * 只追加、不重写：历史墓碑保留，回滚由调用方决定（重写整份或删行）。
 * @param {string} tombPath <memoryFile>.tomb
 * @param {string} text 要追加的文本（应自带换行）
 * @returns {boolean}
 */
export function appendTombstoneText(tombPath, text) {
  if (typeof text !== "string" || !text) return false;
  try {
    fs.mkdirSync(path.dirname(tombPath), { recursive: true });
    fs.appendFileSync(tombPath, text, "utf8");
    return true;
  } catch {
    return false;
  }
}

// ── 注入文本（长期记忆 → system prompt blob）────────────────────────────────

/** 有事实的条目数（仅用于诊断日志）。 */
export function countEntries(entries) {
  let n = 0;
  for (const e of entries || []) if (e && Array.isArray(e.facts) && e.facts.length > 0) n++;
  return n;
}

/**
 * 把记忆条目序列化为一段可注入 system prompt 的文本。
 * 超出预算（memoryTargetTokens）时按比例截断。
 * 不放 new Date() 时间戳：variable 每次 assemble 都重算，时间戳每次都变，是纯噪声。
 */
export function buildMemoryBlob(entries, cfg) {
  if (!entries || entries.length === 0) return "";

  const sections = [];
  for (const e of entries) {
    if (!e || !Array.isArray(e.facts) || e.facts.length === 0) continue;
    const title = e.title || String(e.sessionId || "");
    sections.push(`### ${title}\n${e.facts.map((f) => `- ${f}`).join("\n")}`);
  }
  if (sections.length === 0) return "";

  const header = "## 长期记忆（本地模型，跨会话）\n以下是你之前会话里记住的要点，供参考；可能已过时，与用户当前说法冲突时以用户当前说法为准：\n";
  const raw = header + sections.join("\n\n");

  const maxTokens = memoryTargetTokens(null, cfg);
  const estimated = estimateTextTokens(raw);
  if (estimated <= maxTokens) return raw;

  const ratio = maxTokens / Math.max(estimated, 1);
  return `${raw.slice(0, Math.floor(raw.length * ratio))}\n\n（以上为长期记忆摘要，部分已截断）`;
}
