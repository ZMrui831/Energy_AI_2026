$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$boxRoot = Split-Path -Parent $here
$pluginDir = Get-ChildItem $boxRoot -Directory | Where-Object { Test-Path (Join-Path $_.FullName 'bundle-files.json') } | Select-Object -First 1
if (-not $pluginDir) { Write-Host "MISSING plugin folder (no bundle-files.json) under $boxRoot"; exit 1 }
$root = $pluginDir.FullName
if (-not (Test-Path $root)) { Write-Host "MISSING folder: $root"; exit 1 }
$manifestPath = Join-Path $root 'bundle-files.json'
if (-not (Test-Path $manifestPath)) { Write-Host "MISSING bundle-files.json"; exit 1 }
$manifest = Get-Content $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
$bad = 0; $n = 0
foreach ($f in $manifest.files) {
  $n++
  $rel = $f.path -replace '/', '\'
  $p = Join-Path $root $rel
  if (-not (Test-Path $p)) { Write-Host ("MISSING  {0}" -f $f.path); $bad++; continue }
  $h = (Get-FileHash $p -Algorithm SHA256).Hash.ToLower().Substring(0, 16)
  $exp = $f.sha256.ToLower()
  if ($h -ne $exp) { Write-Host ("DIFF     {0}  expect={1} actual={2}" -f $f.path, $exp, $h); $bad++ }
  else { Write-Host ("OK       {0}" -f $f.path) }
}

# rc2 mount trio: cordis.patch.yml (bundle patch) + package.json (dsh.bundle.patch field) + manifest
$patchPath = Join-Path $root 'cordis.patch.yml'
if (Test-Path $patchPath) { Write-Host "OK       cordis.patch.yml" } else { Write-Host "MISSING  cordis.patch.yml"; $bad++ }
$pkgJson = Join-Path $root 'package.json'
if (Test-Path $pkgJson) {
  $pkg = Get-Content $pkgJson -Raw -Encoding UTF8 | ConvertFrom-Json
  $declared = $pkg.dsh.bundle.patch
  if ($declared -eq './cordis.patch.yml') { Write-Host "OK       package.json (dsh.bundle.patch = $declared)" }
  else { Write-Host ("BAD      package.json dsh.bundle.patch = {0}" -f $declared); $bad++ }
} else { Write-Host "MISSING  package.json"; $bad++ }
if (Test-Path $manifestPath) { Write-Host "OK       bundle-files.json" } else { Write-Host "MISSING  bundle-files.json"; $bad++ }

Write-Host "----------------------------------------"
Write-Host ("version = {0}" -f $manifest.version)
Write-Host ("files checked = {0}, mismatched = {1}" -f $n, $bad)
if ($bad -gt 0) { Write-Host "RESULT: FAIL"; exit 1 }
Write-Host "RESULT: PASS"
