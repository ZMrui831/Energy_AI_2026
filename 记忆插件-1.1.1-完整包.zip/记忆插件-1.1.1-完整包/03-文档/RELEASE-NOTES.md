﻿# dsh-local-memory 1.1.0（GA）— 发布说明

> **GA 判定**：① P0 数据丢失已修并**在负载下复验**（用同一复现条件：修复前 4×CPU + 6 次跑批错 1 次，修复后 **0/6**）；
> ② 两个真实宿主各一轮真机 —— dsh-orb（V1 全绿、0 行 inject、0 apply failed、数据 1018B 未变，结论「未见插件侧缺陷」）；
> research-orb（内核落地、单测 15/15、注入顺序 coach→coach记忆→长期记忆）；③ release-check **27/27**，内含 ㉗ 负载门禁。

| 项 | 值 |
|---|---|
| 版本 | **1.1.0（GA）** |
| 插件身份 | **17 个文件**（14 运行时 + 3 元文件） |
| 发布 zip | 25 条目（插件 17 + extras 8：4 示例 + adapters/node + clients×3） |
| 门禁 | **27/27**（含 ㉗ 负载下并发不丢事实，无任何容错口子） |
| 兼容 | 不看版本号，看四项能力探测（systemPrompt / assembleHook / projections / presetEvent） |

**本版核心修复（P0）**：负载下 `readLockInfo` 解析失败返回 null → `age=Infinity` → 误判为陈旧锁 → 抢删**别人的活锁** → 双持锁 → 并发读改写丢事实且**报告成功**。
修法：F1 锁内容 tmp+rename 原子发布；F2 不可解析锁给 1s 宽限期（`lock-unreadable`），超期才按 `lock-reclaim-corrupt` 回收；F3 抢占后回读自证 `pid===self`（`lock-race-lost`）。
语义不变：绝不抛错、静默降级；`staleMs=30s` 不变；判定器/阈值/core 标题一行未动。

**已知限制（不打算修）**：10MB 记忆不支持（索引内存受限）；`scopeLayout` 分文件布局未实现（字段已删）；`patchPath` 恒 `<unknown>`（cordis 不向插件暴露）；完全零写盘不支持。

---
## 1.1.0-rc9：P0 数据丢失修复（负载下同会话并发写丢一条事实且报告成功）—— 阻塞 GA，修完才谈 GA

- **症状（主管实测）**：负载下 verify-concurrency 偶发 ⑨ facts=119（期望 120），且 ② 报告「全部成功、0 降级」——即报告成功的同时丢了数据。本机复现：4 个 CPU 占满进程下跑 12 次，③（200 条事实）2 次掉到 199；安静时 8/8 全过，所以前几轮门禁没抓到。
- **根因（markdown.js 生产锁）**：`readLockInfo` 解析失败返回 `null` 被当成「陈旧」→ `age=Infinity` → 进入抢占分支 `unlinkSync` 误删别人的活锁 + `{flag:'wx'}` 覆盖创建 → 两个进程同时持锁 → 并发 read-modify-write → 后写者覆盖先写者 → **静默丢事实且报告成功**。
- **修法（三处，缺一不可）**：
  - **F1 原子发布**：抢占改为 tmp + rename 原子替换（Windows MoveFileExW 原子），绝不就地写、绝不制造「锁短暂消失」窗口；任何时刻读到的锁要么不存在、要么是完整 JSON。
  - **F2 null ≠ 陈旧**：`readLockInfo` 改三态（absent / ok / unreadable）；「存在但不可解析」在 `LOCK_GRACE_MS`（默认 1s）宽限期内视为**占用中**（返回 `lock-unreadable` 交上层重试，绝不误删活锁）；持续超宽限期仍坏 → 按损坏锁回收（`lock-reclaim-corrupt`）。`age=Infinity` 永远不再直接进抢占分支。
  - **F3 抢占后自证持有**：抢占（rename）成功后立刻回读锁文件确认 `pid === process.pid`；不匹配 → 本次视为未拿到锁（`lock-race-lost`）交上层重试 —— 杜绝「两个进程同时抢占成功」的双持锁。
- **语义不变**：绝不抛错、静默降级契约不变；`staleMs=30s` 常规陈旧判定不变；判定器/生产阈值/core 编译产物标题一行未动。`lastWriteError` 新增三种真实 code：`lock-unreadable` / `lock-reclaim-corrupt` / `lock-race-lost`。
- **新增回归（本轮带来）**：
  - **R-a `tools/verify-lock-corrupt.mjs`**（8 断言）：宽限期内损坏锁不抢占（`lock-unreadable`，锁文件原样保留）；损坏锁期间现有事实不丢；超宽限期仍坏 → `lock-reclaim-corrupt` 回收且锁变回有效 JSON；恢复干净后写入正常。**变异验证**：宽限期置 0 → 同一损坏锁立即被回收（`lock-reclaim-corrupt`），证明宽限期真实生效（源码 `LOCK_GRACE_MS` 改 0 时 ① 必红）。
  - **R-b `tools/verify-lock-under-load.mjs`**：起 3 个 CPU hog（6 分钟），期间跑 verify-concurrency 5 次，断言**数据完整性**稳定：③=200、⑨=120、⑩=60、② ok=100,100 failed=0,0。刻意不把 ⑦（耗时<60s）等纯环境时序检查纳入硬门禁（负载下与数据丢失无关的抖动会让门禁在无关轴上变红）。运行 5 次（>缺陷单要求的 3）以降低假阴性。
- **门禁**：release-check 新增 ㉗ 负载下并发写不丢事实（直接跑 R-b，无任何容错口子），共 **27 条**。
- **验收**：修复前 ③ 偶发 199（12 次中 2 次）；修复后 R-b 5/5 全过（③=200 ⑨=120 ⑩=60 ②全成功）、R-a 8/8、release-check 27/27。**不打 GA，GA 由主管决定。**

## 1.1.0-rc8：示例可移植 + 两处体验（P0-a/P0-b/P0-c + P1-a/P1-b + ⑯⑰）

- **P0-a 示例可移植**：seed/inject/probe 顶部加候选根解析器（仓库布局 `examples/research-orb → 仓库根`、桌面包布局 `06-示例 → 02-插件文件`、cwd 兜底），用动态 `import(pathToFileURL(...))` 加载 core；找不到时打印候选路径并 `exit 2`（绝不静默失败）。验收：仓库布局 exit 0、桌面包布局 exit 0、空目录 exit 2 并打印路径。
- **P0-b 去重标题**：core 编译块自带 `## 长期记忆（本地模型，跨会话）`（golden-20 不破），inject.mjs 不再叠标题、只加宿主前缀；README 写明「编译块自带标题，宿主不要再加」。验收：示例输出 `## 长期记忆` 仅出现 1 次。
- **P0-c 裁剪演示**：README 加「30 秒看到裁剪」四命令（seed → budget 0 → budget 40 → budget 400）；inject.mjs 在未被裁剪时提示调小 budget。
- **P1-a extras 便利层**：把 `packages/adapters/node/index.js` 与 `packages/clients/{README,node-client,python_client}` 纳入 bundle extras（不进 files，插件身份恒 17）；verify-payload-refs R4 增加「与仓库逐字节一致」。验收：zip=17+4+4=25 条目、逐字节一致、只用解压包能 `createNodeAdapter` 端到端跑通（remember + recall）。
- **P1-b off 模式抑制 ollama 探测**：`injectMode:'off'` 时不探测 ollama、不打 `warn: ollama unreachable`；其他模式不变（实测 off 无 warn、local 有 warn）。
- **门禁**：release-check 新增 ⑯ 示例桌面包逐字节（+ 变异自检：改一字节必红）与 ⑰ 示例两布局可跑（+ 空目录 exit 2），共 26 条。
- **禁止项全部遵守**：core 编译产物标题未改、判定器/阈值未动、adapters/clients 未塞进 files、未用环境变量作示例可跑前提、未把「示例跑通」写成「宿主集成」。

## 1.1.0-rc7：⑫ 并发门禁去时序依赖（就绪栅栏 + 强制过期快照，naive 恒为 60）；删除 release-check 里 9/10 死容错；FAIL 消息带具体条目

- **背景**：主管在 rc6 上独立跑 release-check 得 23/24，红的正是 ⑫（9/10）；单独跑 verify-concurrency 连续 4 次 10/10。
  → 对照组（⑩）靠「两进程恰好重叠」制造覆盖，release-check 的负载会把调度串行化/错峰，
  后启动 worker 读到对方已写的快照 → naive=120 → 假红。"3 连绿"因此不可复现。
- **修法（⑩，verify-concurrency + worker）**：就绪栅栏（ready-<idx> 标记 + 5ms 轮询、最多 3s）
  → 双方就绪后**才**各读一次（必然同一份空快照）→ 固定等 300ms → 整体覆盖写。
  结果与调度无关：naive 恒为 **60**（一方覆盖另一方）。3s 未会合 → 该条 FAIL 并打印原因，绝不静默跳过。
  断言从 `n4 < 120` 收紧为 `n4 === 60`；加锁路径 `=== 120` 由 ⑨ 作对照。
- **修法（release-check ⑫）**：删除「9/10 也放行」的死容错（退出码全过才 0，该条件永假，
  但等于宣称允许 9/10）；FAIL 时把具体失败条目带进 detail（截 140 字）。
- **实测**：单独 5 次 10/10 且 naive facts=60 恒定；4 个 CPU 占满进程负载下 release-check ⑫ 仍 10/10；24/24 × 3（含负载）。
- 判定器/生产阈值一行未动（只改测试与门禁逻辑）。

## 1.1.0-rc6：minBudget 补边界开销（boundaryCost），min 档起保证 ≥1 入选

- **修什么**：rc5 的 minBudget 公式漏了边界声明的预留开销（实测 ≈81 tokens，与头部同量级）——
  当最便宜候选是弱匹配易变段时，`minBudgetTokens` 给出的是「理论上放得下」的值，
  实际在 contentCap（= budget − boundaryCost）里被边界块吃光 → min 档 `chosen=0`。
- **精确式**（逐预算扫描实测标定，非抬阈值）：`needOf = stable ? max(base+cost+boundaryReserve, 2*(base+cost)) : (base+cost+boundaryReserve)`；
  其中 `boundaryReserve` 按非门控边界变体 + closingTag 预留（常量、零成本、偏多不少）。
  任务书 §1.2 字面式的两处代数漏项（②漏 baseTokens、reserve 漏 closingTag）经扫描表纠正，详见 compile.js 注释。
- **4 档实测**（demo-memory.md，query「我叫什么？」）：`0`→旧语义 items:[]；`min-1`→全 dropped + `budget-too-small`；
  `min`=179→chosen=1（e0-f2 入选，items=3=候选数）；`min+1`→chosen=1。
- **回归**：core-smoke 58/58、golden-compile-20 20/20（逐字节）、plugin-harness 89、write-governance 18/18、
  offline-stub 35/35、strict-ctx 16/16；release-check 24/24 × 3。

# dsh-local-memory 1.1.0-rc2 — 发布说明（审计驱动，非功能版本）

- 版本：**1.1.0-rc2**（`bundle-files.json` / `package.json` / `cordis.patch.yml` version 同）
- 日期：2026-10-23
- 本版主题：**自检自查**。不改功能，先把「我们宣称的」和「实际证明的」之间的缝补上。
- **影响面一句话**：唯一的行为变化是**修了一个真实数据丢失**（手写裸事实行不再被静默丢弃）；
  另外删掉了两个「宣称了但没实现」的配置字段。默认配置下注入/写入输出逐字节不变（golden-20 证明）。

## 1.1.0-rc2 追加（两处小修，无行为变更）

1. **diag 幽灵字段**：`scopeLayout` 自 1.0.2 起配置已删，但 `apply begin` 仍在输出它 —— 宿主会误以为存在"分文件布局"能力。现已从 diag 移除。
2. **门禁可证伪性**：`release-check ⑧` 原为"调 ollama 真跑、不可达即 SKIP"，**永远不可能变红**。现改为 `tools/verify-adherence-offline.mjs`（12 条固定答案驱动 judge-v6，无需模型/网络）。
   变异验证：临时移除 judge-v6 的 `named` 要求 → 10/12（红）；还原 → 12/12（绿）。`release-check` 现为 **27 条**（1.1.0-rc4 起新增第 24 条 ⑮「载荷↔引用一致性」；1.1.0-rc8 新增 ⑯ 示例桌面包逐字节 + ⑰ 示例两布局可跑；1.1.0-rc9 新增 ㉗ 负载下并发写不丢事实，见上方 rc9 小节；rc1 时期为 23 条）。


## 修了什么

| # | 问题 | 现象 | 修法 | 复验 |
|---|---|---|---|---|
| 1 | **裸事实行被静默丢弃**（审计 E5b） | 手工把 `- 用户: …` 追加到 `# Local AI Memory` 下（不加 `## [generated …]` 块头）→ 读不到，**下次写入整文件重写把它删掉**，全程无告警 | `readMemoryFile` 收养为隐式条目（`sessionId='__loose__'`），`header.looseFacts` 计数，apply 打一次 `warn: N loose fact line(s) adopted`；下次写入规范化成标准块 | `audit-error-paths` E5b 由 ❌ 转 ✅；`core-smoke` 58/58、`golden-20` 20/20 不变 |
| 2 | **`scopeLayout:'split'` 是半成品** | 注释写「project 文件 + global.md 只读合并」，实际 `layout.global` **从未被读取**——global.md 完全不生效 | 删除 `scopeLayout` / `projectId` 两个字段，`resolveLayout` 收敛为 single-only；split 推迟到 1.2 与 global 合并一起实现 | `grep layout\.global` 归零；默认 `single` 路径逐字节不变 |
| 3 | **`memory-cli clean` 删不掉问句**（审计 D5d） | 写入侧 `filterFactful` 拦问句，但清理工具用 `isNoiseFact` 判定 → 老污染文件里的「我叫什么？」清不掉 | 抽出 `isQuestionFact()` 作为**唯一实现**，写入侧与 clean 共用 | `audit-lifecycle` D5d 由 ❌ 转 ✅；clean 的 dry-run/apply 条数一致 |

## 文档更正（数字曾经三个版本三个说法）

| 位置 | 原来 | 更正为 |
|---|---|---|
| `README.md` 配置表 | 「实际上限 … = 500 token」 | `memoryBudgetTokens` 默认 **800**（500 是 compile 退化到 `buildMemoryBlob` 的 fallback 值） |
| `DEEP-MEMORY.md` §0 | 「~300 token 的注入块」 | 「≤800 token（实测 276–317）」——300 是 `budgetUsed`，不是预算 |
| `DEEP-MEMORY.md` §2 | 「预算硬上限 1024」 | 「预算硬上限 **800**」 |
| `dist/INSTALL.md` 标题/正文 | 1.0.0-rc6 / rc3.zip / 「8 套回归」 | 1.1.0-rc1 / 1.1.0-rc1.zip / 10 套回归 |
| `examples/research-orb/README.md` | 未说明可移植性 | 明确「必须在仓库内跑；拷走要改 import 路径」（审计 G1' 实测拷走会 Cannot find module） |

## 新增审计套件（常驻，可反复跑）

| 文件 | 作用 | 当前结果 |
|---|---|---|
| `tools/audit-error-paths.mjs` | 维度 C：11 个错误路径场景真跑 | 11/11 |
| `tools/audit-lifecycle.mjs` | 维度 D：写/读/tomb/备份恢复/无残留/clean | 11/11 |
| `tools/audit-crosshost.mjs` | 维度 G：示例、fixtures、namespace 隔离与冲突 | 9/10（唯一失败是「拷走可跑」，已转为文档说明） |
| `tools/audit-perf.mjs` | 维度 F：1KB/62KB/1MB/10MB 四档 | 全档持平或更好（10MB 2456ms vs 基线 12612ms） |
| `tools/audit-falsifiability.mjs` | 维度 I：23 条门禁变异测试（改坏→变红→还原→复绿） | 22/23 可证伪（⑧ 因 ollama 未启动恒 SKIP） |
| `tools/audit-config-fields.mjs` | 维度 B：38 个 Config 字段枚举 | 死字段 2 个（已声明预留，保留） |

## 兼容性

- 老配置（`onlyPreset` / `injectScope`）**行为不变**：`golden-compile-20` 20/20 逐字节一致。
- 老记忆文件（无文件头）照常解析；**块头齐全的文件解析结果与 1.0.1 完全一致**。
- 已删除的 `scopeLayout` / `projectId`：老 patch 里残留不会报错（schemastery 不拦额外键），只是无效。

## 诚实边界

- 跨宿主（dsh-orb / research-orb）**仍未真机挂载**，只有离线套件与 fixtures 证据。
- 10MB 记忆**仍不支持**（2456ms/轮、堆峰值 762MB），本版给了数字但没做优化。
- ⑧ 服从性门禁在 ollama 未启动时**恒 SKIP=PASS**，当前不构成正确性证据。

---

# dsh-local-memory 1.0.1 — 发布说明（多宿主适配）

- 版本：**1.0.1**（`bundle-files.json` / `package.json` / `cordis.patch.yml` version 同）
- 日期：2026-10-23
- 本版主题：**多宿主适配** —— 两个外部宿主（DSH 系 dsh-orb、非 DSH 系 research-orb 类）诉求高度重合，
  本版把两方诉求一次性裁定并落地：**配置表达力（presets[] / injectMode）+ 文件契约（文件头）+ 并发安全（锁）**。
- **影响面一句话**：老配置（只给 `onlyPreset` / `injectScope`）**行为逐字节不变**；新宿主可用
  `presets: ['<你的 preset>']` + `injectMode: 'off'` 做到「只写不注、自己注入」，不再需要改代码。

## 1.0.1 变更清单

### P0（必做，已完成）
| 项 | 内容 | 验收 |
|---|---|---|
| P0-1 | 新增 `presets: string[]` 白名单 + `injectMode: 'off'\|'local'\|'all'`，保留 `onlyPreset`/`injectScope` 兼容；解析优先级写死；`decided` 新增 `off` / `preset-ok-all`；diag 增加 `presets`/`injectMode`/`resolvedBy` | `verify-config-matrix` 24/24（8 组） |
| P0-2 | 记忆文件头契约 `<!-- dsh-local-memory \| schema: 1 \| namespace: <ns> \| updatedAt: <iso> \| lastWrite: <iso> <count> -->`；新增 `namespace` 配置；启动打印 `[memory] file=<abs> schema=1 namespace=<ns>`（diag + stdout 各一次）；头缺失/畸形照常解析 | 配置矩阵 + fixtures 套件；老文件（无头）解析条目数不变 |
| P0-3 | `packages/README.md` 目录地图 + 每个目录「何时该改我 / 何时别改我」 | 文档；`packages/{core,adapters,clients,daemon,fixtures}/README.md` |
| P0-4 | 并发写保护：`<file>.lock`（pid+ts，>30s 陈旧抢占）+ tmp+rename + 退避 `[15,45,120,300]ms`（带抖动，最多 3 遍）+ `lastWriteError` 进 diag 与文件头 `lastError` | `verify-concurrency` 10/10（2 进程 × 100 次，0 丢失、无锁残留，**含无锁对照组证明测到了真问题**） |

### P1（已完成）
| 项 | 内容 |
|---|---|
| P1-1 | `recall()` 返回预算解释 `items:[{id,tokens,score,dropped,reason:'budget'\|'gate'\|'dup'\|null}]`，`text` 不变 |
| P1-2 | diag 轮转可配：`diagMaxBytes` 默认 2MB、`diagKeep` 默认 3（`.1/.2/.3`，超出删最旧） |
| P1-3 | `packages/fixtures/cross-host/` 4 类 × 10 条 + `tools/verify-fixtures.mjs`，跨宿主一致率 **100%** |
| P1-4 | `examples/research-orb/`（`seed.mjs` / `inject.mjs` / `probe.mjs` / README），不改 research-orb 仓库 |
| P1-5 | daemon `/health`：经核实**已有**，按诉求补 `pid/schema/namespace/facts/updatedAt`；单实例锁**已有**（`<global>.lock` + 心跳，占用时 exit 2），只补文档 |
| P1-6 | `scopeLayout: 'single'\|'split'`（默认 `single` = 1.0.0 行为）；`split` 写 `<baseDir>/project/<projectId>.md`、读合并 `<baseDir>/global.md` |

### P2（已完成，默认关闭）
- 重复事实不新增行，改在既有行尾追加 `^duplicate-of <sid>#<turn>`，累计次数写进文件头 `seenCount`。
  **默认 `markDuplicates: false`**（保持 1.0.0 字节行为）；开启后可在 `verify-fixtures` 里看到断言。
- namespace 冲突检测：同一文件被两个 namespace 打开 → diag 一行 `warn: namespace mismatch (file=… ns=A!=B)`，只警告不改行为。

### 修复（测架）
- `judge-v6 --selftest` **从来没真正跑过 v6 的 14 条**：judge-v6 import 了 judge-v5，而 v5 的入口守卫是
  `process.argv.includes('--selftest')`，一跑就在 import 阶段抢先自测并 `process.exit()`，输出的是
  "judge-v5 selftest: 13/13"。改为专属旗标 `--selftest-v6`（v3/v5 一行未动）。

## 兼容性与升级

- 老配置零漂移：`presets` 缺省 `[]` → 回落 `injectScope` / `onlyPreset`，解析结果与 1.0.0 一致
  （`verify-config-matrix` G7 组三条断言）。
- golden-compile-20 仍 **20/20 逐字节一致**（注入编译路径未动）。
- 新增文件头会让**新写的文件**多出第一行注释；读侧容忍缺失/畸形，1.0.0 的老文件照常解析、条目数不变。
- 升级：覆盖 17 个文件后重启 DSH 即可；无需迁移数据。

---

# dsh-local-memory 1.0.0 — 历史发布说明（GA / rc7）

- 版本：**1.0.0**（GA，`bundle-files.json` / `package.json` version 同）
- 日期：2026-10-23
- 本版主题：**测量工具修正**——修两个测架缺陷（不改运行时逻辑）：①`measure-adherence` 曾把未给出的开关显式传成
  false，覆盖了生产默认，导致 rc6 的「absent 残余 29.2%」与「两条优化无提升」两条结论基于错误基线；
  ②`guard-200` 用墙钟计时，负载下误报。
- **影响面一句话**：rc6 的两条结论**作废**，以 rc7 为准——生产默认（summary+tags+named）在 8b/1.7b 上
  absent 与 distractor 均为 **100%（8b）/ 93.8~100%（1.7b）**，adherence **1.000**；两条实验性开关（强调句、摘要块内）
  在生产默认之上 **Δ=0.0pp、p=1.000**，**保持关闭**。
- 兼容性：**不看版本号，看四个能力**（apply() 运行时探测，结果写 `capabilities` diag 行）：`systemPrompt`、`assembleHook`、`projections`、`presetEvent`。关键能力缺失 → 静默降级不注入（写入照常）。外部真机（DSH 0.2.1-rc.2 / cordis 4.0.5）实测四能力全在位、六场景全通。
- 依赖：仅 Node 内置（node >= 18），无第三方依赖
- **运行时字节未变**：rc7 只改测架/文档/版本号，14 个运行时文件的 sha256 与 rc6 完全一致。

## ✅ 真机验证（2026-10-23，本机 DSH 1.0.0 运行时 + ollama `qwen3:8b`，非模拟）

| 验证项 | 结论 | 证据 |
|---|---|---|
| 块首摘要（普通事实也生成） | ✅ | 注入块首行 `已知事实：称呼=大肥鱼；喜好=冰美式` |
| 具名拒答（无尖括号残留） | ✅ | 问「我住哪里？」→「记忆里没有你的住址信息。」 |
| 跨会话记忆 | ✅ | 新会话问「我叫啥？喜欢啥？」→「你叫大肥鱼，喜欢冰美式」 |
| 提问不入库 | ✅ | `diag: turn/end with no facts {"skipped":{"question":2}}`；文件里无提问 |
| 注入格式 | ✅ | `<memory_facts>…</memory_facts>` + 同键折叠（`（另 2 条同类已折叠）`） |
| 云端硬否决 | ✅ | `decided:"cloud"` + 会话不含记忆段 |

一次性数据清洗：实机记忆 **38 → 8 条事实**（删除 30 条历史噪声：助手回执/寒暄/日语示例/重复），
备份 `local-ai-memory.md.bak-20261023-002811`。此后写入侧治理保证不再复脏。


## 本版变更（rc7，相对 1.0.0-rc6）

1. **M1 修复（测架覆盖生产默认）**：`tools/measure-adherence.mjs` 改为「只把命令行显式给出的开关放进 opts」，
   新增 `--no-*`（消融）、`--flags-off`（全关，可复现 rc6 的错误配置）、`--flags-production`（显式等于默认），
   并把**生效配置**写进 JSON 的 `flags` 字段（`src: default|cli`），控制台首行打印。
2. **M2 修复（guard-200 误报）**：判据从墙钟改为 **CPU 时间**（`process.cpuUsage`，10 次一批取均值以绕过
   Windows 15.6ms 量化），阈值仍 5ms；报告同时给 CPU 与墙钟两列。连跑 3 次全 PASS。
3. **重测**：生产默认 + 两条变体，8b/1.7b × 48 题 × N=3，含配对 McNemar（§2.5，见 `docs/基准报告-v6-能力指数.md`）。
4. **文档**：v6 报告新增 §2.5「测量工具修正（rc7）」并标注 rc6 附录两条结论作废；`docs/遗留清单-rc6.md` 追加 rc7 更新（#15/#18 关闭）。

## 上版变更（rc6，相对 1.0.0-rc5）

1. **P0-1 写入侧事实性判定**（外部实测缺陷：记忆文件里出现了「用户: 我叫什么？喜欢什么？」）：
   白名单优先（我叫|我是|我的X是|我喜欢|我不喜欢|我住|我在X工作|我养|记住|代号|版本|发布于|改成|改为）
   + 黑名单兜底（问号结尾 / 疑问词且 ≤80 字 / 请求开头 / 纯寒暄），都未命中 **默认丢弃**（宁可漏记，不可污染），
   diag 计数 `skipped:{question,unknown,greet}`。问句判定**优先于白名单**——「我叫什么？」含「我叫」，
   若按字面「白名单优先」会照样入库，正是外部缺陷本身。与 rc4 的 writeGovernance（ack/greet/dup）叠加生效。
   验收：`tools/verify-write-quality.mjs` 8/8（5 类用例 + 20 条样本：提问入库率 0%、真实事实入库率 100%）。
2. **P0-2 摘要覆盖普通事实**（外部实测：`记住：我叫小X，我喜欢Y` 不生成摘要）：摘要改为
   「**键**：值 型画像事实 + 普通事实正则抽取（我叫/叫我/我喜欢/我住/我的X是）」两路合并，
   最多 3 行、每行 ≤20 字、同键保留最新。`<memory_facts>` 结构与预算硬上限不变；golden 20 基线按新格式重生成（两次逐字节一致）。
3. **P0-3 服从性两条开关 A/B**（3 模型 × 32 题 × N=3）：摘要后强调句、摘要位置（标题后 vs 块内）。
4. **P1-1 diag 轮转**：超过 256KB 不再 `writeFileSync(path,"")` 丢历史——先写 `*.diag.log.1`（覆盖旧的）、
   末尾记 `diag rotated {prevBytes}`、主文件只留该标记。验收 `tools/verify-diag-rotate.mjs` 8/8。
5. **P1-2 选型默认值 + 只写不注诊断**：默认推荐 qwen3:8b；apply 时探测一次 ollama 可达性
   （3s、静默、不关写入），不可达写 `warn: ollama unreachable; memory will be written but never injected`。
6. **P1-3 安装形态两个真机事实**：优先 portable zip（免 UAC）；desktop profile 被 Electron 独占，改完必须用户重启 GUI，CLI 不能用 desktop profile 验收。
7. **P2 收口**：evict 给宽松默认（maxFacts 5000 / maxChars 2,000,000≈1MB，只防无上限增长）；
   `.tomb` 与 `.forget` 合并到同一处读侧过滤（写入仍分文件）；0.6b 明确「不支持」。

## 上版变更（rc4，相对 1.0.0-rc3）

1. **注入格式优化（逐条 A/B，只保留有效项）**，定稿 = 块首「已知事实：…」摘要 + `<memory_facts>` 结构标签 + 具名式拒答：
   - **具名式拒答**：BOUNDARY 从 120+ 字四条契约换成 68 字两条，拒答措辞从「没有相关信息」升级为「**记忆里没有<该项>**」——8b 的 absent 类 0.575→**0.875（+30pp）**、distractor 0.762→**1.000（+23.8pp）**。
   - **两段式摘要**：块首一行「已知事实：称呼=…；喜好=…」（仅画像事实）——0.6b 服从率 0.875→0.938、refusedButPresent 减半。
   - **指令压缩（≤70 字纯压缩）：A/B 无效，已回退**（absent 两模型全面下降）；开关保留（`compactBoundary`，默认 false）。
   - 已知代价：0.6b 对具名拒答过度泛化（recall 服从率崩塌）——0.6b 本就「不建议」，见模型选型。
2. **能力指数 v6**：三臂对照（A0 无记忆 / A1 全量注入 / A2 本插件）× 64 题（recall/conflict/absent/distractor 各 16）× N=3。**8b：无记忆 9.4% → 本插件 96.9%，绝对提升 +87.5pp，缺口闭合 CI=0.966，McNemar p≈5.3×10⁻⁵¹，每轮 468 token（全量注入需 775）**；1.7b 4.7%→92.7%；0.6b 3.6%→57.3%（recall 崩塌如实报）。
3. **新工具**：`tools/measure-adherence.mjs`（服从率 + A/B 测架）、`tools/bench/{make-v6, judge-v6, run-v6, v6-stats}.mjs`（题集 64 题生成即自检 / 判定 14 自测 / 三臂 runner / Wilson+McNemar 统计）。judge-v3/v5 一行未改。
4. **字节稳定**：golden-compile-20 基线按定稿格式重生成（旧基线备份于 backups/），同输入两次编译逐字节相同。
5. release-check 增两条：⑧服从性套件冒烟、⑨v6 报告固定句在位（14 → 16 条）。

## 上版变更（rc3，相对 1.0.0-rc2）— P0：修「真实宿主上插件不激活」
  - `systemPrompt`：`ctx.systemPrompt.section`/`.variable` 可调用（`dsh-system-prompt\lib\index.js:253/310`）
  - `assembleHook`：可注册 `system-prompt/assemble`（同文件 `:398`）
  - `projections`：`ctx.sessionProjections.stateOf` 存在（dsh-session-projection）
  - `presetEvent`：`ctx.on` 可调用，顶层 `agent-preset/selected` 重发（`dsh-agent-preset-registry\lib\index.js:459`）
  - 关键能力（前两个）任一缺失 → 不抛错、diag 记 `capability missing: <name>`、静默降级为不注入（写入照常）。外部实测 DSH 0.2.1-rc.2 上四个 API 全部在位。
- 依赖：仅 Node 内置（node >= 18），无第三方依赖

## 本版变更（rc3，相对 1.0.0-rc2）— P0：修「真实宿主上插件不激活」

> 这是 rc2 唯一挡住「陌生人能用」的问题：**逻辑是对的，激活路径错了**。
> 外部用户在真实 DSH 0.2.1-rc.2（cordis 4.0.5）上装 rc2，激活即抛
> `cannot get property "sessionProjections" without inject`（详见下方「兼容性」小节）。

1. **所有可选服务改安全取值（P0）**：`inject` 保持 `["systemPrompt"]`（必需项）；
   新增 `safeGet(ctx, name)`（优先 `ctx.get(name)`，兜底 `ctx[name]`，抛错吞掉返回 undefined），
   逐个替换裸访问：`logger`(209/210) / `config`(216/218) / `sessionProjections`(276、能力探测 291) /
   `version`·`host`(296) / `systemPrompt`(289、795)。全文件审计 `tools/audit-ctx-access.mjs`：
   **裸访问 0**（改动前 24 处 / 9 行）。
2. **激活失败必须"可看见"（P0）**：`apply()` 改为「先算不依赖服务的 diag 路径 → 整个函数体在
   try/catch 里 → catch 落一行 `apply failed: <message> | <first stack frame>` + 宿主日志告警」；
   失败后不注册任何 hook、不写任何业务文件（`mount-ok` 写在函数体最后，中途失败不留"半残"标记）。
3. **加严格 ctx 回归（P0，防再犯）**：新增 `tools/verify-strict-ctx.mjs`（16 断言）——Proxy 模拟
   cordis 4.0.5（未声明服务访问即抛）；**改动前复现同一条报错，改动后全绿**；补「服务全缺」极端场景
   与「敌意宿主（注册即抛）」场景；纳入 release-check（13 → 14 条）。
4. **研发纪律**：本机服务访问语义宽松，89 条 harness 全绿也测不出这类问题——今后宿主服务访问
   一律 `safeGet`，审计脚本裸访问必须为 0。

## 上版变更（rc2，相对 1.0.0-rc1）

1. **安装形态按宿主 bundle 契约重做**（跨机装不上的根因修复）：插件包新增 `cordis.patch.yml`（真正的挂载声明：`insert local-memory` + 完整 config），`package.json` 增加 `"dsh": {"bundle": {"patch": "./cordis.patch.yml"}}` 字段；自造 JSON 清单 `dsh.bundle.patch` 改名 `bundle-files.json`（内容照旧：14 文件 + sha256）。安装路径从「编辑 local-lean preset 的 config.plugins」（新机器没有该 preset，所以装不上）改为三步：① 包放进 `<PROFILE>\node_modules\dsh-local-memory\`；② `<PROFILE>\package.json` 的 `dsh.profile.bundles` 追加 `"dsh-local-memory"`（先备份）；③ 重启 DSH。**不需要手改任何 preset。**
2. **能力探测替代假版本门槛**：删除 `compatibility.minDshVersion: 0.40.0`（无依据元数据，会把能用的机器挡在门外）；`apply()` 加一次性探测，diag 输出 `capabilities {systemPrompt, assembleHook, projections, presetEvent, version}`；探测方式见上表；关键能力缺失静默降级。
3. **`onlyPreset:""` 通配语义**（解决「没有 local-lean preset」）：空字符串 = 任意 preset（含 preset 真值缺失）都写记忆、都注入；注入侧 `presetGate` 与写入侧闸门同时加旁路；默认仍 `"local-lean"`，`cordis.patch.yml` 头注与 INSTALL.md 写明新机器建议设 `""`。
4. **`injectScope:'all'` 文案修正**：统一为「只跳过 preset 过滤；provider 云端否决仍然生效（云端模型一律不注入）」——旧文案把它说成「什么会话都注入」，不准确（外部实测即使 all，云端 provider 仍被硬否决）。
5. **文档去作者绝对路径**：`dist\*.md` 与 `cordis.patch.yml` 里的作者机绝对路径（用户主目录前缀、工作区盘符路径）全部替换为占位符 `<PROJECT>`/`<PROFILE>`/`<DSH_HOME>`/`<NODE>`；安装命令改为跨机可执行写法（`$env:USERPROFILE`、`Join-Path`）；`release-check` 新增零容忍断言。
6. **安全小节固化**：新增「安全与隐私（外部评审 + 自查）」（见下）。
7. **离线桩常驻套件**：新增 `tools/verify-offline-stub.mjs`——假 cordis ctx（on/effect/systemPrompt/sessionProjections/logger）驱动 `apply()`，无 DSH、无 ollama 可跑；断言本地注入、跨会话记得住、云端不注入、写入侧不记回执、`ms`/`cache` 字段、五轮切换不崩、别的插件 section 不被破坏；全部写临时目录（mkdtemp）跑完清理；纳入 release-check。

## 相对 rc1 保留的变更（摘要）

- 注入闸门以「会话 preset」为主判据，provider 仅作明确云端硬否决（deepseek/gpt/claude/glm）；判定顺序写死：preset-unknown / preset-mismatch → 不注入；匹配后 provider 云端 → 不注入；否则注入（认不出模型也注入，不误杀新本地模型）。
- preset 真值 4 路优先级：活投影 `sessionProjections.stateOf(session,"agentPreset")` > request/header > `agent-preset/selected` 事件 > `session/created` 头快照兜底；`preset probe` 诊断每会话一次。
- 记忆治理：注入侧 `dropNoise`/`foldInject`/干净截断；写入侧 `writeGovernance`（默认开）丢纯助手回执/寒暄、跨轮归一化去重，异常退回无过滤写入。
- `memory-cli clean`：dry-run 审阅 + `--apply` 前强制备份 + 归一化去重 + 保守「无关主题」判定。
- 内存守卫：`baselineMem` 每次成功重建后重取，长跑不误降级。
- provider 分类合并为唯一纯函数 `decideInjectionProvider`，生产闸门与离线单测共用。

## 已知限制（技术债，照实写 6 条）

1. **request/header 不含 preset**：宿主 `canonicalHeader` 只折叠 `config`(provider/model)/`tools`，故 preset 第 2 路恒空；真值依赖活投影/事件/头快照。若宿主改投影键名或暴露方式，需同步 `resolvePreset`。
2. **provider 硬否决名单只认四家**：`deepseek/gpt/claude/glm` 前缀之外的云端 provider（如 moonshot/kimi、百度千帆、阿里百炼等）不在硬否决名单里——local-lean 会话若切到这类云端模型，闸门会漏放（宁可漏拒，不误杀新本地模型的取舍后果）。
3. **实机记忆清理已落盘，但运行中进程可能再写脏**：`memory-cli clean --apply` 已于 2026-10-21 对实机文件执行（31 条事实 → 6 条，备份 `local-ai-memory.md.bak-20261021-130314`，称呼「大肥鱼」等事实受保护保留）；但 DSH 运行中进程内存里的记忆副本，仍可能在下次 `turn/end` 把旧内容重新写回——需重启 DSH 后清洗结果才稳定。
4. **「无关主题」治理覆盖面窄**：仅命中日文假名/韩文（保守，宁可漏清不误删）；其它外语例句、跨主题一次性内容不在自动清除范围。
5. **会话头快照是「起始 preset」**：`session/created` 的 `session.header.agentPreset` 是会话创建时的值；会话中途若非经 `agent-preset/selected` 事件切换，头快照可能旧于当前——由「活投影优先」缓解，但活投影不可达时（见限制 1）存在理论窗口。
6. **通配 `onlyPreset:""` 是双刃剑**：任意 preset 都写都注入，换来「无 local-lean 预设的机器开箱即用」；代价是别的模式的对话也会进本地记忆（靠 `injectScope`/`strictProvider`/云端硬否决兜底）。有 local-lean 预设的机器建议保留默认值。

## 集成验证（门 3/4，2026-10-21，对安装副本）

`tools/verify-gate34.mjs` 从**安装副本**（`<PROFILE>\node_modules\dsh-local-memory\lib\index.js`，即 DSH 进程真实加载的那份字节）导入插件，跑真实 cordis 运行时（事件载荷与 systemPrompt.variable 回调形状同 harness），先校验安装副本与工作区源码 sha256(16) 一致（`a3bd41493b87f789`，被测对象即交付对象）。四个桩场景 22 断言全过，每场景统一断言四件套：decided / 是否注入 / preset probe 的 src / 是否含长期记忆：

| 场景 | 桩 | 期望 | 结果 |
| --- | --- | --- | --- |
| A 门3 | 四路 preset 全空（无事件、无头快照、无投影） | `decided:"preset-unknown"`、不注入（空串）、probe `src="none"` `chosen=null` | PASS |
| B 门3 | `session/created` 头快照 `session.header.agentPreset="computer-use"` | `decided:"preset-mismatch"`、不注入（空串）、probe `src="sessionHead"` `fromSessionHead="computer-use"` | PASS |
| C 门4 | preset 匹配（`agent-preset/selected`=local-lean）+ `model:"totally-new-local-7b"` + provider 缺失 | `decided:"local"`、注入：含「长期记忆」且稳定画像段（线索词事实）与 query 检索段（BM25 命中情节事实）都渲染；probe `src="event"`；认不出模型也注入 | PASS |
| D 门4 | preset 匹配 + `model:"deepseek-chat"` | `decided:"cloud"`、不注入（空串）、diag `inject skip: cloud model fallback`；probe `src="event"`（preset 匹配但被 provider 硬否决） | PASS |

## 模型选型（真机实测，外部用户反馈固化）

**默认推荐：qwen3:8b**（真机六场景全通、服从率最高；本机 64 题三臂对照 96.9%）。
**qwen2.5:7b 实测服从性不稳**（同一注入下偶发「记忆里没有你的名字和喜好」——可用但不推荐作为默认）。
**≤4b 不建议**；**qwen3:0.6b 不支持**（中文答非所问 + 具名拒答指令被过度泛化，rc4 报告内 recall 服从率 0.063）。

| 模型 | 真机结论 | 建议 |
| --- | --- | --- |
| qwen3:8b | 真机六场景全通；服从率稳定 | **默认推荐** |
| qwen2.5:7b | 真机六场景通过，但同注入下偶发拒答 | 可用，不作默认 |
| qwen3:4b | 带工具的 agent 里**会乱调工具**（实测自行写了 example.txt） | 不建议在 agent preset 下用 |
| qwen3:1.7b | 离线三臂 92.7%，但小模型服从性不稳 | 仅评测/轻量问答 |
| qwen3:0.6b | 中文答非所问；具名拒答下 recall 崩塌 | **不支持** |

结论：**≥7B 且 nothink 倾向的模型**才适合带工具（agent preset）的场景；更小的模型只适合无工具的纯问答评测。

## 安装形态（真机事实，外部用户实测）

- **装 ollama 优先用 portable zip**：`ollama-windows-amd64.zip` 解压到 `D:\Ollama`，把 `OLLAMA_MODELS`
  指向 D 盘即可，无需注册表/服务。`OllamaSetup.exe` 的 `/S`、`/VERYSILENT` 在**无提权会话**里都会卡在 UAC
  （外部实测），不要用静默参数装。
- **desktop profile 被 Electron 独占**（`profile "desktop" is managed exclusively by the Electron application`）：
  改完 profile 的 `package.json` / `cordis.patch.yml` 后**必须由用户重启 GUI**；CLI 不能用 desktop profile 做验收，
  要验 BUNDLES 机制请在**临时 profile** 里验。

## 兼容性（cordis 4.0.5 严格 inject）

外部用户在真实 DSH 0.2.1-rc.2（cordis 4.0.5）上装 rc2，插件**激活即抛错**：

```
dsh: warning: 1 entry did not activate
local-memory (dsh-local-memory): Error: cannot get property "sessionProjections" without inject
    at new apply (.../dsh-local-memory/lib/index.js:276:42)
```

- **规则**：插件 `inject` 只声明**必需服务** `["systemPrompt"]`；其余服务
  （`sessionProjections` / `logger` / `version` / `host` / `config` …）**一律走安全取值**
  `safeGet(ctx, name)`（优先 `ctx.get(name)`，兜底 `ctx[name]`，取值抛错吞掉返回 undefined）。
  cordis 4.0.5 下，未声明服务的**直接属性访问会抛错**；本机语义宽松所以一直没暴露。
- **已用严格 ctx 复现并修复**：`tools/verify-strict-ctx.mjs` 用 Proxy 模拟该语义（未声明服务访问即抛），
  改动前复现同一条报错、改动后 16/16 PASS；`tools/audit-ctx-access.mjs` 审计全文件，裸访问 0。**真机需用户复测**（我们没在 DSH 0.2.1-rc.2 真机跑过）。
- **激活失败的表现与自查**：
  - 表现：DSH 启动时 stderr 一行 `1 entry did not activate`（GUI 里**没有任何提示**）。
  - 自查：看 `<memoryFile>.diag.log`（默认 `~/.dsh/local-ai-memory.md.diag.log`）里有没有
    `apply failed: <message> | <first stack frame>` 这一行 —— rc3 起激活失败一定会留这一行。
  - 命令：`Get-Content "$env:USERPROFILE\.dsh\local-ai-memory.md.diag.log" -Tail 40 | Select-String "apply failed|apply begin"`
- **外部实测确认的两条行为**（这次一并固化，避免再被当成 bug）：
  1. `injectScope:'all'` **仍受 provider 云端否决**——all 只跳过 preset 过滤，云端模型一律不注入。
  2. `onlyPreset:''` 通配**在 preset 为 null 的会话下仍会注入**（这正是通配的设计意图：
     没有 local-lean 预设的机器开箱即用）。

## 安全与隐私（外部评审 + 自查）

外部同学在离线环境（无 ollama）做了一份很有价值的安全评审，我们复核认可，固化为文档：

- **imports 白名单**：只 import `node:fs` / `node:path` / `node:os` / `node:crypto` + `@deepseek-ai/schemastery`。
- **无危险 API**：无 `http`/`net`/`child_process`，无 `eval`/`new Function`，无 base64 解码。
- **写盘边界**：只写 `memoryFile` 及其伴生文件（`.diag.log`/`.forget`/`.tomb`/`.mount-ok`）；**不碰 `.credentials.yaml`**。
- **取舍一（明文存储）**：记忆以**明文** Markdown 落在 `~/.dsh/local-ai-memory.md`——没有加密，任何能读该文件的人/进程都能看到全部记忆。选它是为了可审计、可手工编辑、可用 `memory-cli clean` 治理；敏感信息本就不该进记忆。
- **取舍二（全局事件）**：注入钩子以 `{global:true}` 收全部会话事件（这是宿主唯一被证明能到达 agent 装配的位置），靠 preset 闸门 + provider 硬否决决定注不注——事件收全 ≠ 记忆外泄，但意味着插件看得到所有会话的事件流（只读，不落盘除非过闸门）。

## 真机已验证清单（2026-10-22 更新，外部用户实测）

- ✅ **A 路挂载（`dsh.profile.bundles`）真机生效**：`--dump-config` 可见 bundle patch 插入 `id: local-memory`；运行时 `apply begin` 正常、无 `apply failed`、无 `did not activate`。（这曾是 rc2 唯一未验证项，已关闭。）
- ✅ 六场景全通（注入 / 记得住 / 云端不拒 / 不记垃圾 / ms+cache / 稳定性）——qwen2.5:7b 与 qwen3:8b。
- ⚠️ 已知残留：小模型（0.6b/4b）的服从性与工具调用问题（见「模型选型」）；注入服从率的量化与优化见 docs/基准报告-v6-能力指数.md。

## 未在真机最终确认（需重启 DSH 后验证）

- `sessionProjections.stateOf` 在本插件 preset 作用域是否可达（`preset probe` 的 `src` 会显示走了哪路）。集成验证已用桩覆盖四路优先级与判定分支，剩余不确定项只在宿主投影可达性。
- ~~宿主是否真的按 `dsh.profile.bundles` 列表加载本包的 `cordis.patch.yml`~~ → **已验证（见真机已验证清单）**。
- ~~rc3 的严格 ctx 修复是否在真机成立~~ → **已验证**：外部用户在真实 DSH 0.2.1-rc.2（cordis 4.0.5）上装 rc3，激活正常、六场景全通。
- 服从性优化（rc4）的收益边界：题集是合成的、单机、单模型家族；数字仅指「记忆类任务」，详见 docs/基准报告-v6-能力指数.md 的诚实边界一节。
- 云端 cordis 会话是否稳定产出 `decided:"preset-mismatch"` 且 system prompt 不含记忆段。
- 本地 local-lean 会话是否稳定 `decided:"local"` + 注入 + 模型复述记忆。
