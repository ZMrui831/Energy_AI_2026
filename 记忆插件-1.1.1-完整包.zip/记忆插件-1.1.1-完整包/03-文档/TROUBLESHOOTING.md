# 排障：6 个已知现象 → 看哪行 diag → 怎么办

所有诊断写在 `<memoryFile>.diag.log`（默认 `~/.dsh/local-ai-memory.md.diag.log`），每行一个 JSON 事件。
核心行：`apply failed`（**激活失败必留这一行**，先查它）、`apply begin` / `capabilities`（四能力探测，apply 时一次）、`inject enter`（闸门入口）、`preset probe`（preset 真值来源）、`inject compiled`（治理计数）、`index cache`（内存守卫）。

---

## 1. 云端会话里出现了记忆（该拦没拦）
- **看**：`inject enter` 的 `decided` 值 + `preset probe` 的 `src`/`chosen`。
- **判**：健康应为 `decided:"preset-mismatch"`（云端 preset≠local-lean）或 `decided:"cloud"`（provider 硬否决）。若 `decided:"local"` 且 `preset probe` 的 `chosen` 是 `local-lean`，说明该会话 preset 真值取错。
- **办**：看 `preset probe` 四路（fromAgent/fromHeader/fromEvent/fromSessionHead）哪路给了 local-lean；若全 null 却注入了，检查是否 `injectScope:"all"`（调试开关，生产应 `local`）。

## 2. 本地会话没有记忆（该注没注）
- **看**：`inject skip: preset unknown (no agent-preset/selected seen)`。
- **判**：`preset probe` 四路全 null → 会话 preset 一个来源都没取到（本地被误杀）。
- **办**：确认宿主是否发 `session/created` 且 `session.header.agentPreset` 有值；确认活投影可达（`sessionProjections.stateOf`）。临时把 `injectScope` 设 `all` 可验证「preset 门是否是唯一卡点」——注意 `injectScope:'all'` 只跳过 preset 过滤；provider 云端否决仍然生效（云端模型一律不注入）。若这台机器没有 local-lean 预设，把 `onlyPreset` 设 `''`（通配：任意 preset 都写都注入）。

## 3. 未知本地模型被误杀（新模型名认不出 → 不注入）
- **看**：`inject enter` 的 `decided` + `verdict`。
- **判**：preset 匹配 + 模型名认不出，应为 `verdict:"unknown"` → `decided:"local"`（默认注入）。
- **办**：若被拦，检查是否误开 `strictProvider:true`（保守旧行为，默认 false）。

## 4. `cache:"off"` / `cacheReason:"rss-exceed"` 反复出现
- **看**：`index cache` 的 `heapUsedMB` / `baselineMB` / `reason`。
- **判**：1.0.0-rc1 起内存守卫改为「每次成功重建后重取基线」，长跑进程不再因自然增长误降级。
- **办**：若仍现，说明单个重建周期内缓存自身增长 >80MB；检查 `maxFacts`/`maxEntries` 上限或语料规模，必要时配置淘汰上限。

## 5. 注入块仍有噪声（助手回执/寒暄/外语例句）
- **看**：`inject compiled` 的 `droppedNoise` / `folded` / `deduped` 三个计数。
- **判**：**不许凭观感**。`volatile:0` 只表示本轮 BM25 没命中、只注了稳定段，不等于治理生效——必须看 droppedNoise/folded 计数。
- **办**：计数>0 即治理在跑；仍残留的个例（如非假名外语）用 `memory-cli clean --file <副本> --dry-run` 审阅，确认后 `--apply`。

## 6. 记忆文件重复 / 越写越脏
- **看**：`memory written` 前的 preset 判定（turn/end 只在 preset 匹配时写；通配 `onlyPreset:''` 时任意 preset 都写）。
- **办**：`memory-cli clean --file <副本> --dry-run` 看「将删 N 条 + 逐条理由 + 去重合并」，确认称呼等事实在保留列；再 `--apply`（写前自动备份 `*.bak-<时间戳>`）。

## 7. 完全不注入，diag 里连 `inject enter` 都没有
- **看**：`apply begin` 的 `capabilities` / `capabilityInjectOk`，以及 `capability missing: <name>`。
- **判**：`systemPrompt` 或 `assembleHook` 为 `false` = 注入通道不可用（宿主未提供 systemPrompt 服务，或不分发 `system-prompt/assemble`）。
- **办**：这是**静默降级**——写入侧持久化照常工作，只是不注入。升级 DSH 到提供这两个能力的版本即可恢复，无需改配置。

## 8. 插件根本没起来（`1 entry did not activate` / 完全没有任何 diag）
- **看**：DSH 启动时的 stderr 一行 `1 entry did not activate`（GUI 里没有提示）；
  再看 `<memoryFile>.diag.log` 有没有 `apply failed: <message> | <first stack frame>`。
- **判**：有 `apply failed` = 插件激活阶段抛错了（rc3 起一定会留这一行）；
  连 diag 文件都没有 = 包没被加载（检查 `node_modules\dsh-local-memory\` 是否 17 个文件、
  `dsh.profile.bundles` 里有没有 `"dsh-local-memory"`、是否重启过 DSH）。
- **办**：按 `apply failed` 的 message 定位：
  - `cannot get property "<服务名>" without inject` = 插件访问了未声明的宿主服务
    （rc3 已全部改 `safeGet`；若仍出现，请把这一行原文发回给我们，说明还有漏网的服务访问）；
  - 其它 = 把 `apply failed` 整行发回。
  ```powershell
  Get-Content "$env:USERPROFILE\.dsh\local-ai-memory.md.diag.log" -Tail 40 |
    Select-String "apply failed|apply begin"
  ```

## 9. 注入了，但模型不照答（答「没有相关信息」/ 答错）
- **看**：diag 里有没有 `inject applied via assemble {"chars":…}`（有 = 注入**成功**，记忆块已进 system prompt）。
- **判**：注入成功但答案没用记忆里的事实 = **模型服从性问题**，不是注入缺失（外部真机实测：qwen3:4b 在长 prompt 下偶发整题拒答；0.6b 中文服从率低）。量化指标见 `docs/基准/adherence-*.json` 的 `adherence` 与 `refusedButPresent`。
- **办**（按序）：
  1. **换更大的模型**（≥7B 且 nothink 倾向，见 RELEASE-NOTES「模型选型」；qwen3:4b 另有乱调工具问题，不建议用于 agent preset）；
  2. **精简记忆条目**（`memory-cli clean --dry-run` 审阅后 `--apply`，条目越少服从率越高）；
  3. 若模型答「没有相关信息」但该项明明在记忆里：贴出该轮 `inject compiled` 与 `inject applied` 两行原文反馈给我们。

## 10. 记忆一直在写，但从来不注入（只写不注）
- **看**：`memory written` 有、`inject applied` 从来没有；diag 里可能有 `warn: ollama unreachable; memory will be written but never injected` 或 `inject skip: cloud model fallback`。
- **判**：这是**预期行为**（rc6 起明确写进 INSTALL）：没有可达的本地模型 / 当前会话用的是云端模型时，插件只写不注，避免白花 token。
- **办**：① 拉起 ollama（`ollama serve`，或 portable 版直接跑 `ollama.exe serve`）并 `ollama list` 确认模型在；
  ② 会话里把模型切成 ollama 的本地模型（默认推荐 qwen3:8b）；③ 历史记忆立刻生效，不需要重装。

## 11. 换了宿主后「preset 不匹配」，记忆不写也不注入
- **看**：diag 里 `inject skip: preset mismatch {"preset":"computer-use","expected":["local-lean"]}`，
  或 `turn/end skipped (session preset is not this plugin's)`。
- **判**：插件的白名单里没有这个宿主用的 preset id（dsh-orb 是 `computer-use`，不是 `local-lean`）。
- **办**：配 `presets: ['<你的 preset id>']`（1.0.1 起支持多个），或临时用 `onlyPreset: ''` 通配。
  配好后 diag 的 `resolvedBy` 应是 `"presets"`。

## 12. 宿主自己注入，怕插件双注入
- **办**：`injectMode: 'off'`。此时插件**永不注入**（diag 里只有一行 `inject skip: injectMode=off`，
  不会出现 `inject enter` / `inject compiled` / `inject memory into prompt`），**写入照常**。
  验证口径：`presets` 含你的 preset + `injectMode:'off'` → 无 preset mismatch、无注入记录、文件头有 `updatedAt`。

## 13. 记忆文件在别处 / 两个宿主互相覆盖
- **看**：diag 与 stdout 各有一行启动打印 ` [memory] file=<绝对路径> schema=1 namespace=<ns>`；
  文件头里的 `namespace` 是否与你配的一致。
- **判**：`namespace mismatch (file=… ns=A!=B)` 说明同一份文件被两个 namespace 打开了（多半是配置串了）。
- **办**：给每个宿主配不同的 `namespace`，或让它们各写各的文件（`memoryFile` 分开）。

## 14. 并发写导致事实丢失 / Windows EPERM、EBUSY
- **看**：diag 的 `memory write FAILED` 与文件头 `lastError: <iso> <code>`。
- **判**：1.0.1 起写入已带锁并退避重试；仍失败说明遇到了持续占用（例如另一个进程长期持锁、或磁盘/杀软拦截）。
- **办**：确认没有别的进程卡死持锁（`<file>.lock` 里 pid+ts，>30s 会被自动抢占）；
  跑 `node "<PROJECT>\tools\verify-concurrency.mjs"` 复现是否为环境特有问题。

## 15. `injectMode:'off'` 的 diag 契约（宿主断言用）
宿主若要照 diag 写断言，以下五条是 `presets` 含本宿主 preset + `injectMode:'off'` 时的**精确预期**：

① `apply begin` 含 `presets` / `injectMode:"off"` / `resolvedBy` / `namespace`
② 每进程恰好 1 行：`inject skip: injectMode=off (host injects itself)`
③ 0 行 `inject enter`；0 行 `inject compiled`；0 行 `inject applied`
④ 有 `memory written`（写入照常）
⑤ 无 `preset mismatch`、无 `cloud skip`（因为根本没走到 provider 判定）

> 实测确认（rc5，`tools/plugin-harness.mjs` 的 off 模式对照 + 独立复现）：两次调用 provider 也只留 1 行 `inject skip`，
> `inject enter/compiled/applied` 全为 0，`memory written` 正常出现，注入返回空串 `""`，记忆文件照常写入。

### 宿主 Q&A
**Q1** `off` 是否注册 assemble hook？
→ 注册（hook 在 `apply` 时无条件挂上，见 `lib/index.js:836` 的 `injectMode==="off"` 分支入口立刻返回空串），
但每次都在入口立刻返回空串——不产生 `inject enter` / `inject compiled` / `inject applied`，每进程只留一行
`inject skip: injectMode=off (host injects itself)`。开销 = 一次函数调用 + 一次 policy 读取，可忽略。

**Q2** 改 `namespace` 会不会改文件正文格式？
→ 不会。`namespace` 只出现在首行头：`<!-- dsh-local-memory | schema: 1 | namespace: <ns> | … -->`；
正文仍是 `## [generated <ts>] <sid> <title>` + `- <fact>`。注意：头里 `namespace` 与配置不一致时只在 diag 告警，不改行为；下次写入会用新 `namespace` 重写头。

**Q3** `presets:['computer-use'] + injectMode:'off'` 的 diag 预期？
→ 见上面五条；核心是 `decided:"off"`、无 `inject enter`、有 `memory written`。

**Q4** 只读消费方要不要 `readOnly`？
→ 没有 `readOnly` 字段、也不需要；但 `off` 仍会写 `memoryFile` 和 sidecar（`.diag.log/.1~.3`、瞬时 `.lock/.tmp`、`.mount-ok`）。
若要尽量干净，设 `writeSidecars:false`（见下）。

## 16. `writeSidecars` 开关与「完全零写盘」
- **`writeSidecars:false`**（默认 `true`）→ **不写** `.diag.log`（含轮转 `.1~.3`）与 `.mount-ok`；仍写 `memoryFile` 与瞬时 `.lock/.tmp`。
- **诚实边界：「完全零写盘」不支持**——写入记忆文件是插件职责，无法关闭；只读消费方应**只读文件、不挂载本插件**。
- `apply begin` 的 diag 行在 `writeSidecars:false` 下写不出去是预期的（diag 整体变 no-op），但 `writeSidecars` 字段值仍以 stdout 的
  `[memory] config loaded … writeSidecars=<bool>` 一行呈现。
- 实测（`writeSidecars` 两态对照）：`true` 下 `.diag.log` 增长（约 2KB/轮）、`.mount-ok` 生成；`false` 下两者都不出现，记忆文件两态都正常写入。

## 17. `config loaded` 启动行与 patch 路径
- 每进程启动会打印两行（diag + stdout 各一）：
  - `[memory] file=<绝对路径> schema=1 namespace=<ns>`
  - `[memory] config loaded | presets=[…] injectMode=… namespace=… writeSidecars=… | patchPath=<unknown>`
- **`patchPath` 永远打印 `<unknown>`**：cordis 不向插件暴露 patch 文件路径——不硬猜、不读 `process.argv`、不读文件系统找 patch。
  需要确认"加载了哪个配置文件"时，请对照 `apply begin` 里回显的生效配置（`presets` / `injectMode` / `namespace` / `writeSidecars`）。
- 该行**绝不抛错**；拿不到 patch 路径就打印 `<unknown>`，不影响激活。
