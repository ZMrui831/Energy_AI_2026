# 安装 dsh-local-memory 1.1.0-rc1

本插件是 DSH 的「本地模型两级记忆」插件：会话 system-prompt 注入 + 跨会话 Markdown 持久化。
只依赖 Node 内置模块，无第三方依赖。

## 前置：本地模型（ollama）

- 装 ollama **优先用 portable zip**：`ollama-windows-amd64.zip` → 解压到 `D:\Ollama`，把 `OLLAMA_MODELS` 指向 D 盘即可，无需注册表/服务。
  **不要**用 `OllamaSetup.exe /S` 或 `/VERYSILENT` —— 无提权会话会卡在 UAC（外部实测）。
- 默认推荐 `qwen3:8b`（qwen2.5:7b 服从性不稳；≤4b 不建议；0.6b 不支持，见 RELEASE-NOTES「模型选型」）。
- **没有可用本地模型时是预期行为，不是 bug**：插件**只写不注**——记忆照常写入 `~/.dsh/local-ai-memory.md`
  （diag 里 `inject skip: cloud model fallback` 或 `warn: ollama unreachable; memory will be written but never injected`）；
  之后装了本地模型并选它开会话，历史记忆立刻生效，不需要重装。

## 三步安装（宿主 bundle 契约，不需要手改任何 preset）

rc2 起挂载完全走宿主 bundle 机制：本包是一个 npm 包，`package.json` 用
`"dsh": {"bundle": {"patch": "./cordis.patch.yml"}}` 声明挂载声明文件；宿主在 profile 的
`dsh.profile.bundles` 列表里看到 `"dsh-local-memory"` 时读取并应用它。

### 1. 把包放进 profile 的 node_modules

解压 `dsh-local-memory-1.1.0-rc1.zip`，使目标 profile 的 node_modules 下出现完整包目录：

```
<PROFILE>\node_modules\dsh-local-memory\
```

解压后应得到 17 个条目：`lib/`(3) + `packages/core/`(11) + `cordis.patch.yml` + `package.json` + `bundle-files.json`。

### 2. 在 profile 的 package.json 里登记 bundle

编辑 `<PROFILE>\package.json`（**先备份原文件**），在 `dsh.profile.bundles` 数组里追加 `"dsh-local-memory"`（按顺序追加到末尾即可）：

```json
"dsh": { "profile": { "bundles": ["@deepseek-ai/dsh-base", "...", "dsh-local-memory"] } }
```

宿主组装顺序（dsh-app-boot 原文）：各 bundle patch 按 `dsh.profile.bundles` 顺序应用到空 entry 列表，
然后是 profile 自己的 patch 层，最后是 launcher 层。

### 3. 重启 DSH

配置改动需重启 DSH 才生效（Node 模块已加载的进程不会热更新）。**装完必须重启**——外部真机实测确认：不重启，bundle patch 不会被应用。

**重启后自检**（30 秒确认插件真的起来了）：

```powershell
# 1) 进程在跑且没被拒载：启动日志不应出现 "did not activate"
# 2) diag 里应有 apply begin（没有 apply failed）
Get-Content "$env:USERPROFILE\.dsh\local-ai-memory.md.diag.log" -Tail 40 |
  Select-String "apply failed|apply begin"
# 期望：有 "apply begin {...}"，没有 "apply failed"
```

> **没有 local-lean 预设的机器**（全新安装 / 别人的 profile）：把包内 `cordis.patch.yml` 里
> config 的 `onlyPreset: 'local-lean'` 改成 `onlyPreset: ''`（空字符串）。
> `''` = 通配：任意 preset（含从未选过模式的会话）都写记忆、都注入。
> 默认值 `'local-lean'` 保留给已有该预设的机器（行为与历史版本一致）。

## 兼容性：看能力，不看版本号

本插件**不设最低 DSH 版本门槛**（版本号猜不得——旧清单写的 0.40.0 无依据，外部实测
DSH 0.2.1-rc.2 上四个 API 全部在位）。改为 `apply()` 运行时一次性探测四个能力，
结果写 `capabilities` diag 行（`<memoryFile>.diag.log`）：

| 能力 | 探测方式 | 缺失后果 |
|---|---|---|
| `systemPrompt` | `typeof ctx.systemPrompt?.section === "function"`（且 `.variable` 可调用） | 关键能力：静默降级为**不注入**（写入照常） |
| `assembleHook` | 能否注册 `system-prompt/assemble`（试注册即弃） | 关键能力：静默降级为**不注入**（写入照常） |
| `projections` | `ctx.sessionProjections.stateOf` 是否存在 | 非关键：preset 真值走事件/头快照兜底（P0.3 既定行为） |
| `presetEvent` | `ctx.on` 是否可调用 | 非关键：同上 |

宿主源码位置（外部实测 + 复核）：

- `system-prompt/assemble` 瀑布：`dsh-system-prompt\lib\index.js:398`
- `systemPrompt.section` / `.variable`：同文件 `253` / `310`
- `ctx.sessionProjections.stateOf`：dsh-session-projection 服务
- 顶层 `agent-preset/selected` 重发：`dsh-agent-preset-registry\lib\index.js:459`

任一关键能力缺失时**不抛错**：diag 记 `capability missing: <name>`，插件降级为不注入，
写入侧持久化照常工作。

## 验证命令（跨机可执行）

```powershell
# 0) 定位目标 profile（DSH_HOME 默认 ~/.dsh；本例为 desktop）
$PROFILE = Join-Path $env:USERPROFILE ".dsh\profiles\desktop"
$PKG     = Join-Path $PROFILE "node_modules\dsh-local-memory"

# a) 14 个运行时文件语法全过
Get-ChildItem -Path (Join-Path $PKG "lib"), (Join-Path $PKG "packages\core") -Recurse -Filter *.js |
  ForEach-Object { node --check $_.FullName; if ($LASTEXITCODE -ne 0) { "SYNTAX FAIL: $($_.FullName)" } }

# b) 哈希与 bundle-files.json 清单逐条一致（zip 内自带清单，可完全离线校验）
$man = Get-Content (Join-Path $PKG "bundle-files.json") -Raw | ConvertFrom-Json
$bad = 0
foreach ($f in $man.files) {
  $h = (Get-FileHash (Join-Path $PKG $f.path) -Algorithm SHA256).Hash.ToLower().Substring(0, 16)
  if ($h -ne $f.sha256) { $bad++; "MISMATCH: $($f.path) got=$h want=$($f.sha256)" }
}
if ($bad -eq 0) { "HASH OK: $($man.files.Count)/$($man.files.Count)" }

# c) 挂载声明在位（宿主只认这两个文件 + bundles 登记）
Test-Path (Join-Path $PKG "cordis.patch.yml"), (Join-Path $PKG "package.json")
(Get-Content (Join-Path $PROFILE "package.json") -Raw) -match '"dsh-local-memory"'
```

工程副本（含 `tools/` 全套自检脚本）可追加跑：`node "<PROJECT>\tools\install-bundle.mjs" verify`
与 `node "<PROJECT>\tools\release-check.mjs"`（10 套回归 + 0 漂移 + bundle 自洽 + zip 校验 + 路径零容忍 + 离线桩 + 并发 + fixtures + 配置矩阵）。

## 真机观察

发一句话后看 `<memoryFile>.diag.log`（默认 `~/.dsh/local-ai-memory.md.diag.log`），每行一个 JSON 事件：

- `apply failed`：激活失败才会出现（`apply failed: <message> | <stack frame>`）——**先查这一行**；
  若 DSH 启动时只看到一行 `1 entry did not activate`，就是这里（GUI 无提示，详见 TROUBLESHOOTING 第 8 条）
- `capabilities`：四能力探测结果（apply 时一次）
- `apply begin`：`presetWildcard` / `ownPreset` / `capabilityInjectOk`
- `inject enter`：`decided` / `preset` / `presetSrc`
- `preset probe`：`fromAgent`/`fromEvent`/`fromSessionHead`/`chosen`/`src`
- `inject compiled`：`droppedNoise`/`folded`/`deduped`
- `index cache`：内存守卫（`heapUsedMB`/`baselineMB`/`reason`）

## 目录结构

```
dsh-local-memory/
├─ lib/            index.js(入口/闸门) store.js tokens.js
├─ packages/core/  compile/markdown/index-fts/index-cache/evict/... (11)
├─ cordis.patch.yml  宿主 bundle 挂载声明（insert local-memory + config）
├─ package.json      （含 "dsh": {"bundle": {"patch": "./cordis.patch.yml"}}）
└─ bundle-files.json (14 文件清单 + sha256 + 安装/回滚约定)
```

## 多宿主配置（1.0.1 起）

一个插件要同时在 DSH、dsh-orb、research-orb 这类不同宿主上工作，靠的是三组新字段：

```yaml
# cordis.patch.yml 的 config 段（或宿主自己的配置里覆盖）
presets: ['computer-use']   # preset 白名单（可多个）。非空 → 会话 preset 必须 ∈ 列表才注入/写入
injectMode: 'off'           # off=永不注入（写入照常，宿主自己注入时用）；local=默认；all=不看 provider
namespace: 'dsh-orb'        # 写进记忆文件头；不同宿主必须不同值
```

- **只想让插件「只写不注」**（你自己注入，怕双注入）：`injectMode: 'off'` + `presets: ['<你的 preset>']`。
- **一个插件服务多个 preset**：`presets: ['local-lean', 'computer-use']`（旧字段只能填一个）。
- 解析优先级写死：① `presets` 非空 → 用它；② `presets` 空 + `injectScope:'all'` → 不过滤 preset；
  ③ `presets` 空 + 其它 → 用 `[onlyPreset]`（`onlyPreset:''` = 通配）。结果进 diag：`presets` / `injectMode` / `resolvedBy`。
- **老配置不动也不会坏**：只给 `onlyPreset` / `injectScope` 的配置，行为与 1.0.0 一致。

## 记忆文件头（1.0.1 起）

写入后第一行是契约头（HTML 注释，不认识的解析器当注释跳过）：

```
<!-- dsh-local-memory | schema: 1 | namespace: dsh-orb | updatedAt: 2026-10-23T02:30:00.000Z | lastWrite: 2026-10-23T02:30:00.000Z 2 -->
```

- `updatedAt` = 最近一次写入时间；`lastWrite` = `<时间> <本次写入条数>`（写入可自证）。
- 可选：`lastError: <iso> <code>`（上次写失败，成功后清除）、`seenCount: <n>`（重复事实累计，需开 `markDuplicates`）。
- **老文件没有头也照常解析**（条目数/事实数不变），不需要迁移。

## 并发安全（1.0.1 起）

写记忆文件走 `<file>.lock`（pid+ts，>30s 陈旧自动抢占）+ tmp+rename + 退避 `[15,45,120,300]ms`。
多进程/多宿主同时写同一个文件**不会静默丢事实**。失败会记 `lastWriteError`，同时写进 diag 与文件头
`lastError`，成功写入后清除。**别绕过锁直接写**。

## 目录地图

接新宿主前先看 `packages/README.md`（core / adapters / clients / daemon / fixtures / tools 各自
「何时该改我 / 何时别改我」）；可跑的例子在 `examples/research-orb/`。
