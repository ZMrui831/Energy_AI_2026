# 升级与回滚 dsh-local-memory

## 升级（推荐：install-bundle.mjs）

安装脚本做「先备份 → 同步 → 校验」，全程不碰 preset 配置：

```powershell
# <PROJECT> = 插件工作区根目录（工程副本；zip 里不含 tools/）
node "<PROJECT>\tools\install-bundle.mjs" install
```

流程：读 `bundle-files.json`（version + 14 文件 sha256）→ 把目标目录 17 个文件（14 运行时 +
`cordis.patch.yml` + `package.json` + `bundle-files.json`）备份为 `*.bak-<时间戳>` → 用工程源覆盖 →
复核 sha256。输出 `哈希验证: 17/17 通过` 即成功，然后重启 DSH。

> 跨机覆盖安装目标：设环境变量 `DSH_INSTALL_TARGET=<PROFILE>\node_modules\dsh-local-memory`。

随时可校验「源 ↔ 安装副本」是否 0 漂移：

```powershell
node "<PROJECT>\tools\install-bundle.mjs" verify
```

一键自检（回归 + 漂移 + bundle 自洽 + zip 文件集 + 路径零容忍 + 离线桩）：

```powershell
node "<PROJECT>\tools\release-check.mjs"
```

## 升级（手动）

1. 解压新版 zip，把 17 个条目（14 运行时 + `cordis.patch.yml` + `package.json` + `bundle-files.json`）覆盖到 `<PROFILE>\node_modules\dsh-local-memory\`。
2. 按 INSTALL.md 的验证命令 b) 复核 14 文件哈希。
3. 重启 DSH。

## 回滚

### 方式 A：install-bundle.mjs rollback（推荐）

```powershell
node "<PROJECT>\tools\install-bundle.mjs" rollback
```

从目标目录里最近的 `*.bak-<时间戳>` 备份恢复，恢复后复核哈希，再重启 DSH。

### 方式 B：手动

1. 在 `<PROFILE>\node_modules\dsh-local-memory\` 找到最近的 `*.bak-<时间戳>`（如 `lib\index.js.bak-20261021-125100`）。
2. 去掉 `.bak-<时间戳>` 后缀拷回原位（覆盖）。
3. 复核 14 文件哈希；重启 DSH。

## 备份约定

- 备份名：`<原路径>.bak-YYYYMMDD-HHMMSS`（本地时间），与源文件同目录。
- 每次 `install` 都会先备份，覆盖前一版；**回滚只能回到最近一次 install 之前**。
- 更早版本请另行归档 zip / 源快照。

## 记忆文件

升级/回滚**不改** `memoryFile`（`~/.dsh/local-ai-memory.md`）。需要清理历史污染时用 `memory-cli clean`（先 dry-run 审阅，再 --apply，写前自动备份）。
