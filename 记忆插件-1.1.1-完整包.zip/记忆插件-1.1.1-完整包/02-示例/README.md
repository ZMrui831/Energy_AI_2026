# examples/research-orb — adapters/node 的真实宿主示范

> **这是示范，不是生产适配器。** 生产适配器在 `packages/adapters/node/index.js`
> （`createNodeAdapter`），目录地图与"何时该改我"见 **`packages/README.md`**。
> 本目录**不修改 research-orb 仓库**，只提供它可以照抄的接法。

## 跑起来

> **可移植（1.1.0-rc8 P0-a）**：三个脚本不再硬编码相对路径，而是自动在候选根里找 `packages/core`
> （仓库布局 `examples/research-orb → 仓库根`、桌面包布局 `06-示例 → 02-插件文件`、当前工作目录兜底）。
> 因此**既能在仓库内跑，也能整目录拷进你自己的项目 / 桌面包里直接跑**，找不到 core 时打印候选路径并 `exit 2`，不会静默失败。

```bash
cd examples/research-orb
node seed.mjs                         # 写一份带契约头的记忆文件（namespace=research-orb，带锁写入）
node inject.mjs "我叫什么？"          # 3 行注入示范：读记忆块 → 拼 system → 打印预算解释
node probe.mjs "我叫什么"            # 打印：文件路径 / schema / namespace / 条目数 / 最近 updatedAt / recall items
node probe.mjs --file <你的记忆文件>  # 换成你自己的文件（绝对路径更保险）
```

记忆文件用 `MEMORY_FILE` 环境变量覆盖（默认 `./demo-memory.md` / `./demo-memory.jsonl`）。

## 30 秒看到裁剪（P0-c）

`inject.mjs` 支持 `--budget <n>` 调小预算即能看到 `dropped / reason:'budget' / minBudgetTokens`：

```bash
node seed.mjs                                  # 先有一份记忆
node inject.mjs --budget 0                     # 全部被裁剪（reason: budget-too-small，旧语义 items:[]）
node inject.mjs --budget 40                    # 预算过小：所有条目 dropped:reason=budget
node inject.mjs --budget 400                   # 预算充足：全部入选，此时会提示「调小 budget 看裁剪效果」
```

预算下限 `minBudgetTokens`（头部 + 最便宜一条）以下会触发 `budget-too-small`；介于下限与全量之间才会真实裁剪。

## 两个文件分别演示什么

- `inject.mjs` —— **注入侧**：`recall()` 拿 `{text, items, meta}` → 拼进 system。
  `text` 恒为字符串、永不抛；`budgetTokens` 是硬上限；没有记忆时 `text` 是空串（别拼进去）。
- `probe.mjs` —— **契约侧**：读记忆文件的第一行契约头
  `<!-- dsh-local-memory | schema: 1 | namespace: <ns> | updatedAt: <iso> | lastWrite: <iso> <count> -->`，
  再打一次 recall 的 `items` 解释（`dropped` + `reason: budget|gate|dup`）——
  这就是"为什么这条没被召回"的答案。

## 接入要点（照抄前请读）

0. **编译块自带标题，宿主不要再加（1.1.0-rc8 P0-b）**：`compileFromEntries` 的产出 `text` 已经以
   `## 长期记忆（本地模型，跨会话）` 开头（core 负责，golden-20 基线锁定）。宿主拼 `system` 时**只加自己的前缀**
   （如「你是研究助手。」），不要再叠一层 `## 长期记忆…` 标题——否则会重复。本目录 `inject.mjs` 已按此修正。

1. **namespace 必须不同**：research-orb 配 `namespace: 'research-orb'`，别用默认的 `dsh`。
   同一份文件被两个 namespace 打开时，插件只在 diag 告警（`namespace mismatch`），不改行为。
2. **写入要过锁**：跨进程写同一个记忆文件时，用 `core/markdown.js` 的 `readModifyWriteLocked()`，
   别自己 read→write（会静默丢事实，Windows 上尤其）。
3. **规则别自己实现**：什么该入库由 `core` 的 `filterFactful` / `governTurnFacts` 决定，
   基线在 `packages/fixtures/cross-host/`（4 类 × 10 条），改规则要连 fixtures 一起改。
4. **daemon 可选**：只有多进程/跨语言共享时才需要 `packages/daemon/server.mjs`；
   单进程宿主直接用适配器就够。
