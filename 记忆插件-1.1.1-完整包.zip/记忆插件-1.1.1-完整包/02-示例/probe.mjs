// probe.mjs — 把「我到底连的是哪份记忆」一次问清楚。
//
// 打印：文件路径、schema、namespace、条目数、最近一次 updatedAt、一次 recall 的 items 解释。
// 两个外部宿主都吃过「以为读的是 A 文件、实际写的是 B 文件」的亏，所以这份探针值得常备。
//
// 跑：node probe.mjs [--file <markdown 记忆文件>] [查询词]
//     --file 默认 ./demo-memory.md；查询词默认「我叫什么」
//
// 可移植性（1.1.0-rc8 P0-a）：见 seed.mjs 顶部说明——自动在候选根里找 core，找不到 exit 2。

import { resolve, dirname, join, sep } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { existsSync } from 'node:fs'

const HERE = dirname(fileURLToPath(import.meta.url))
const CANDIDATE_ROOTS = [
  resolve(HERE, '..', '..'),                 // 仓库布局：examples/research-orb → 仓库根
  resolve(HERE, '..', '01-插件文件'),        // 本包布局：02-示例 → 01-插件文件
  resolve(HERE, '..', '02-插件文件'),        // 桌面包布局：06-示例 → 02-插件文件
  resolve(HERE, '..', '..', '02-插件文件'),  // 防御性备选
  process.cwd(),                             // 兜底
].map((p) => p.split(sep).join('/'))

const CORE_ROOT = CANDIDATE_ROOTS.find((r) => existsSync(join(r, 'packages/core/markdown.js')))
if (!CORE_ROOT) {
  console.error('找不到 packages/core；已尝试:\n  ' + CANDIDATE_ROOTS.join('\n  '))
  process.exit(2)
}
const { readMemoryFile, parseFileHeader, FILE_SCHEMA } = await import(
  pathToFileURL(join(CORE_ROOT, 'packages/core/markdown.js')).href
)
const { createMemory } = await import(pathToFileURL(join(CORE_ROOT, 'packages/core/api.js')).href)

const arg = (k, d) => {
  const i = process.argv.indexOf(k)
  return i >= 0 && i + 1 < process.argv.length ? process.argv[i + 1] : d
}
const FILE = resolve(arg('--file', './demo-memory.md'))
const QUERY = process.argv.slice(2).filter((a) => !a.startsWith('--') && a !== arg('--file', '')).join(' ') || '我叫什么'

// ① 文件头契约（1.0.1）：老文件没有头也必须能读
const { entries, header } = readMemoryFile(FILE)
const facts = entries.reduce((n, e) => n + ((e && e.facts) || []).length, 0)

console.log('=== 记忆文件探针 ===')
console.log('file      :', FILE)
console.log('schema    :', header && header.ok ? header.schema : `(无头/畸形头 → 按 schema ${FILE_SCHEMA} 兼容解析)`)
console.log('namespace :', (header && header.namespace) || '(无)')
console.log('entries   :', entries.length, ' facts:', facts)
console.log('updatedAt :', (header && header.updatedAt) || '(无)')
console.log('lastWrite :', (header && header.lastWriteAt) || '(无)', (header && header.lastWriteCount) != null ? header.lastWriteCount + ' 条' : '')
console.log('lastError :', (header && header.lastErrorAt) ? `${header.lastErrorAt} ${header.lastErrorCode}` : '(无)')

// ② 一次 recall 的 items 解释：把 Markdown 视图的事实灌进内核（内存态，不落盘）做一次检索
const mem = createMemory({ file: null })
for (const e of entries) for (const f of (e && e.facts) || []) mem.remember({ text: String(f).replace(/^(用户|助手)[：:]\s*/, '') })
const out = mem.recall(QUERY, { budgetTokens: 300 })
console.log('\n=== recall 预算解释 ===')
console.log('query     :', QUERY)
console.log('text      :', JSON.stringify(out.text))
console.log('items     :')
for (const it of out.items || []) {
  console.log(`  ${it.id}  ${it.dropped ? 'DROPPED' : 'CHOSEN '}  tokens=${it.tokens} score=${Number(it.score || 0).toFixed(3)} reason=${it.reason || '-'}`)
}
