// seed.mjs — 示范「怎么写一份带契约头、且并发安全的记忆文件」。
//
// 两个要点（都是外部宿主踩过的坑）：
//   ① 文件头：写进 namespace / updatedAt / lastWrite，宿主一读就知道「这是谁的文件、什么时候写的」。
//   ② 带锁写入：readModifyWriteLocked = 锁内重读 → 改 → tmp+rename，多进程下不会静默丢事实。
//
// 跑：node seed.mjs [--file ./demo-memory.md] [--namespace research-orb]
//
// 可移植性（1.1.0-rc8 P0-a）：不靠环境变量也能跑。脚本自动在以下候选根里找
// `packages/core/markdown.js`：① 仓库布局 examples/research-orb → 仓库根；
// ② 桌面包布局 06-示例 → 02-插件文件；③ 防御性备选；④ 当前工作目录。
// 都找不到时打印候选路径并 exit 2（绝不静默失败）。

import { resolve, dirname, join, sep } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { existsSync } from 'node:fs'

const HERE = dirname(fileURLToPath(import.meta.url))
const CANDIDATE_ROOTS = [
  resolve(HERE, '..', '..'),                 // 仓库布局：examples/research-orb → 仓库根
  resolve(HERE, '..', '01-插件文件'),        // 本包布局：02-示例 → 01-插件文件
  resolve(HERE, '..', '02-插件文件'),        // 桌面包布局：06-示例 → 02-插件文件（02 含 17 身份文件）
  resolve(HERE, '..', '..', '02-插件文件'),  // 防御性备选（不同桌面包嵌套）
  process.cwd(),                             // 兜底：cwd 下也能放一份 packages/core
].map((p) => p.split(sep).join('/'))

const CORE_ROOT = CANDIDATE_ROOTS.find((r) => existsSync(join(r, 'packages/core/markdown.js')))
if (!CORE_ROOT) {
  console.error('找不到 packages/core；已尝试:\n  ' + CANDIDATE_ROOTS.join('\n  '))
  process.exit(2)
}
const { readModifyWriteLocked, upsertMemoryEntry, buildFileHeader } = await import(
  pathToFileURL(join(CORE_ROOT, 'packages/core/markdown.js')).href
)

const arg = (k, d) => {
  const i = process.argv.indexOf(k)
  return i >= 0 && i + 1 < process.argv.length ? process.argv[i + 1] : d
}
const FILE = resolve(arg('--file', './demo-memory.md'))
const NS = arg('--namespace', 'research-orb') // 不同宿主必须不同值

const FACTS = [
  '用户: 我叫阿衡，住在杭州。',
  '用户: 我喜欢喝冰美式咖啡。',
  '用户: 我的项目代号改成 PRJ-9001。',
]

const now = new Date().toISOString()
const res = readModifyWriteLocked(FILE, (onDisk) => upsertMemoryEntry(onDisk, 'session-demo', '第 1 轮', FACTS, { dedup: true }), {
  header: { namespace: NS, updatedAt: now, lastWriteAt: now, lastWriteCount: FACTS.length },
})

console.log('write ok :', res.ok && res.written)
console.log('file     :', FILE)
console.log('header   :', buildFileHeader({ namespace: NS, updatedAt: now, lastWriteAt: now, lastWriteCount: FACTS.length }))
console.log('提示     : 换 --namespace 再跑一次，然后用 probe.mjs 看 namespace 字段变了。')
