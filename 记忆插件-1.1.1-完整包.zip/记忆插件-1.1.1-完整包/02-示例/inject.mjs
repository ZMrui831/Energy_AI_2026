// inject.mjs — 注入示范：读记忆文件 → 编译出注入块 → 拼 system。
//
// 设计约束（1.1.0-rc3 修复 D-1/D-2）：
//   ① **只依赖发布包内的 core**（`packages/core/*`），不 import `packages/adapters/`
//      —— 发布包 17 个文件里没有 adapters/，陌生人解压后跑示例会 exit 1（research-orb 实测）。
//   ② **默认读 Markdown 生产格式**（`<!-- 头 -->` + `## [generated …]` + `- <fact>`），
//      不再把 JSONL 演示文件当主示例（那会教错格式）。
//   ③ 可演示裁剪：`--budget <n>` 调小即能看到 dropped / reason:'budget' / minBudgetTokens。
//
// 跑：
//   node inject.mjs                                  # 默认 ./demo-memory.md，问「我叫什么？」
//   node inject.mjs --query "我住哪" --budget 12      # 演示预算过小（全部 dropped）
//   node inject.mjs --file /abs/memory.md --budget 800
//
// 真实接入时把 `system` 塞进你自己的 LLM 调用参数即可；本文件不发起任何网络请求。
//
// 可移植性（1.1.0-rc8 P0-a）：见 seed.mjs 顶部说明——自动在候选根里找 core，找不到 exit 2。

import { resolve, dirname, join, sep } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { existsSync } from 'node:fs'

const HERE = dirname(fileURLToPath(import.meta.url))
const CANDIDATE_ROOTS = [
  resolve(HERE, '..', '..'),                 // 仓库布局：examples/research-orb → 仓库根
  resolve(HERE, '..', '01-插件文件'),        // 本包布局：02-示例 → 01-插件文件
  resolve(HERE, '..', '02-插件文件'),        // 桌面包布局：06-示例 → 02-插件文件
  resolve(HERE, '..', '..', '02-插件文件'),  // 防御性备选
  process.cwd(),                             // 兜底
].map((p) => p.split(sep).join('/'))

const CORE_ROOT = CANDIDATE_ROOTS.find((r) => existsSync(join(r, 'packages/core/markdown.js')))
if (!CORE_ROOT) {
  console.error('找不到 packages/core；已尝试:\n  ' + CANDIDATE_ROOTS.join('\n  '))
  process.exit(2)
}
const { readMemoryFile } = await import(pathToFileURL(join(CORE_ROOT, 'packages/core/markdown.js')).href)
const { compileFromEntries, estimateTokens } = await import(pathToFileURL(join(CORE_ROOT, 'packages/core/compile.js')).href)

const arg = (k, d) => {
  const i = process.argv.indexOf(k)
  return i >= 0 && i + 1 < process.argv.length ? process.argv[i + 1] : d
}

const FILE = resolve(arg('--file', process.env.MEMORY_FILE || resolve(HERE, 'demo-memory.md')))
const QUERY = arg('--query', process.argv[2] && !process.argv[2].startsWith('--') ? process.argv[2] : '我叫什么？')
const BUDGET = Number(arg('--budget', '400'))

// ① 读生产格式的 Markdown 记忆（缺文件不抛：entries 为空，下面会得到空 text）
const { entries, header } = readMemoryFile(FILE)

// ② 编译注入块：text 恒为字符串；budgetTokens 是硬上限；items 解释「谁入选、谁被砍、为什么」
const out = compileFromEntries(entries, { query: QUERY, budgetTokens: BUDGET })
const text = typeof out.text === 'string' ? out.text : ''
const items = Array.isArray(out.items) ? out.items : []
const meta = out.meta || {}

// ③ 拼 system（没有记忆时 text 是空串，别拼进去）。
//    **编译块自带 `## 长期记忆（本地模型，跨会话）` 标题**（core 产出），宿主只加自己的前缀，不要再重复标题。
const system = text ? `你是研究助手。\n\n${text}` : '你是研究助手。'

console.log('--- 输入 ---')
console.log('file      :', FILE)
console.log('exists    :', entries.length > 0 ? '是' : '否（或为空文件）')
console.log('namespace :', header && header.namespace ? header.namespace : '(无文件头)')
console.log('query     :', QUERY)
console.log('budget    :', BUDGET, '  minBudgetTokens :', meta.minBudgetTokens)
console.log('--- system ---')
console.log(system)
console.log('--- 预算解释 ---')
console.log(JSON.stringify({
  reason: meta.reason || null,
  budgetUsed: meta.budgetUsed,
  minBudgetTokens: meta.minBudgetTokens,
  textLen: text.length,
  textTokens: estimateTokens(text),
  items: items.length,
  chosen: items.filter((it) => !it.dropped).map((it) => it.id),
  dropped: items.filter((it) => it.dropped).map((it) => `${it.id}:${it.reason}`),
}, null, 1))

// ④ P0-c 提示：当前预算下没有条目被裁剪时，提示用户调小 budget 看裁剪效果。
if (items.length > 0 && items.every((it) => !it.dropped)) {
  console.log('\n提示: 当前预算下没有条目被裁剪。想看裁剪效果可加 --budget 40（或更小）。')
}

// exit 0 恒成立：示例是示范，不是校验器。判断用输出里的 reason / dropped。
